const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const oldTagsGet = `  app.get("/api/ollama/tags", async (req, res) => {
    try {
      const serverUrl = (req.query.serverUrl as string) || "http://localhost:11434";
      const apiKey = (req.query.apiKey as string) || "";
      const cleanServerUrl = serverUrl.replace(/\\/+$/, "");
      
      const headers: any = {};
      if (apiKey) {
        headers["Authorization"] = \`Bearer \${apiKey}\`;
      }

      const response = await axios.get(\`\${cleanServerUrl}/api/tags\`, { 
        headers,
        timeout: 10000 
      });
      res.json(response.data);
    } catch (err: any) {
      res.status(err?.response?.status || 500).json({
        error: err?.message || "Failed to fetch tags from Ollama server"
      });
    }
  });`;

const newTagsGet = `  app.get("/api/ollama/tags", async (req, res) => {
    try {
      const serverUrl = (req.query.serverUrl as string) || "http://localhost:11434";
      const apiKey = (req.query.apiKey as string) || "";
      const cleanServerUrl = serverUrl.replace(/\\/+$/, "");
      
      const headers: any = {};
      if (apiKey) {
        headers["Authorization"] = \`Bearer \${apiKey}\`;
      }

      try {
        const response = await axios.get(\`\${cleanServerUrl}/api/tags\`, { 
          headers,
          timeout: 10000 
        });
        if (response.data && response.data.models) {
          return res.json(response.data);
        }
      } catch (err) {
        try {
          const v1Url = cleanServerUrl.endsWith('/v1') ? \`\${cleanServerUrl}/models\` : \`\${cleanServerUrl}/v1/models\`;
          const responseV1 = await axios.get(v1Url, { headers, timeout: 10000 });
          if (responseV1.data && responseV1.data.data) {
             const models = responseV1.data.data.map((m: any) => ({
                name: m.id,
                model: m.id,
                size: 0
             }));
             return res.json({ models });
          }
        } catch (v1Err) {}
        throw err;
      }
      res.json({ models: [] });
    } catch (err: any) {
      res.status(err?.response?.status || 500).json({
        error: err?.message || "Failed to fetch tags from server"
      });
    }
  });`;

const oldModelsPost = `  app.post("/api/ollama/models", async (req, res) => {
    const { endpoint = "http://127.0.0.1:11434", apiKey } = req.body;
    try {
      const url = \`\${endpoint.replace(/\\/$/, '')}/api/tags\`;
      const headers: any = {};
      if (apiKey) headers["Authorization"] = \`Bearer \${apiKey}\`;

      const response = await axios.get(url, { headers, timeout: 5000 });
      res.json(response.data);
    } catch (error: any) {
      res.status(502).json({ 
        error: \`Could not connect to Ollama at \${endpoint}. Ensure Ollama is running and OLLAMA_ORIGINS="*" is enabled.\`,
        details: error.message 
      });
    }
  });`;

const newModelsPost = `  app.post("/api/ollama/models", async (req, res) => {
    const { endpoint = "http://127.0.0.1:11434", apiKey } = req.body;
    try {
      const cleanServerUrl = endpoint.replace(/\\/+$/, "");
      const headers: any = {};
      if (apiKey) headers["Authorization"] = \`Bearer \${apiKey}\`;

      try {
        const url = \`\${cleanServerUrl}/api/tags\`;
        const response = await axios.get(url, { headers, timeout: 5000 });
        if (response.data && response.data.models) {
          return res.json(response.data);
        }
      } catch (err) {
        try {
          const v1Url = cleanServerUrl.endsWith('/v1') ? \`\${cleanServerUrl}/models\` : \`\${cleanServerUrl}/v1/models\`;
          const responseV1 = await axios.get(v1Url, { headers, timeout: 5000 });
          if (responseV1.data && responseV1.data.data) {
             const models = responseV1.data.data.map((m: any) => ({
                name: m.id,
                size: 0
             }));
             return res.json({ models });
          }
        } catch (v1Err) {}
        throw err;
      }
      res.json({ models: [] });
    } catch (error: any) {
      res.status(502).json({ 
        error: \`Could not connect to AI Provider at \${endpoint}.\`,
        details: error.message 
      });
    }
  });`;

const oldChatPost = `  app.post("/api/ollama/chat", async (req, res) => {
    const { endpoint = "http://127.0.0.1:11434", model, prompt, messages, system, apiKey } = req.body;
    try {
      const url = \`\${endpoint.replace(/\\/$/, '')}/api/chat\`;
      const payloadMessages = messages || [
        ...(system ? [{ role: "system", content: system }] : []),
        { role: "user", content: prompt }
      ];

      const headers: any = {};
      if (apiKey) headers["Authorization"] = \`Bearer \${apiKey}\`;

      const response = await axios.post(url, {
        model: model || "llama3",
        messages: payloadMessages,
        stream: false
      }, { headers, timeout: 60000 });

      res.json({
        text: response.data?.message?.content || "",
        raw: response.data
      });
    } catch (error: any) {
      console.error("Ollama Proxy Chat Error:", error.message);
      res.status(500).json({ error: error.message || "Ollama chat request failed" });
    }
  });`;

const newChatPost = `  app.post("/api/ollama/chat", async (req, res) => {
    const { endpoint = "http://127.0.0.1:11434", model, prompt, messages, system, apiKey } = req.body;
    try {
      const cleanServerUrl = endpoint.replace(/\\/+$/, "");
      const payloadMessages = messages || [
        ...(system ? [{ role: "system", content: system }] : []),
        { role: "user", content: prompt }
      ];

      const headers: any = {};
      if (apiKey) headers["Authorization"] = \`Bearer \${apiKey}\`;

      try {
        const url = \`\${cleanServerUrl}/api/chat\`;
        const response = await axios.post(url, {
          model: model || "llama3",
          messages: payloadMessages,
          stream: false
        }, { headers, timeout: 60000 });

        if (response.data && response.data.message) {
          return res.json({
            text: response.data.message.content || "",
            raw: response.data
          });
        }
      } catch (err: any) {
        try {
          const v1Url = cleanServerUrl.endsWith('/v1') ? \`\${cleanServerUrl}/chat/completions\` : \`\${cleanServerUrl}/v1/chat/completions\`;
          const responseV1 = await axios.post(v1Url, {
            model: model || "llama3",
            messages: payloadMessages,
            stream: false
          }, { headers, timeout: 60000 });

          if (responseV1.data && responseV1.data.choices && responseV1.data.choices.length > 0) {
            return res.json({
              text: responseV1.data.choices[0].message?.content || "",
              raw: responseV1.data
            });
          }
        } catch (v1Err) {}
        
        throw err;
      }
      res.status(500).json({ error: "Invalid response format from AI provider" });
    } catch (error: any) {
      console.error("Ollama Proxy Chat Error:", error.message);
      res.status(500).json({ error: error.message || "Ollama chat request failed" });
    }
  });`;

if (code.includes(oldTagsGet)) {
  code = code.replace(oldTagsGet, newTagsGet);
} else {
  console.log("Could not find oldTagsGet");
}

if (code.includes(oldModelsPost)) {
  code = code.replace(oldModelsPost, newModelsPost);
} else {
  console.log("Could not find oldModelsPost");
}

if (code.includes(oldChatPost)) {
  code = code.replace(oldChatPost, newChatPost);
} else {
  console.log("Could not find oldChatPost");
}

fs.writeFileSync('server.ts', code);
console.log("Patched server.ts");
