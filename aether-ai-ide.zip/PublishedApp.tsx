import React, { useEffect, useState } from 'react';

const PublishedApp = ({ deployId }: { deployId: string }) => {
  const [content, setContent] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchDeployment = async () => {
      try {
        const stored = localStorage.getItem('aether_deployments');
        if (stored) {
            const parsed = JSON.parse(stored);
            if (parsed[deployId]) {
                setContent(parsed[deployId].htmlContent);
            } else {
                setError('Deployment not found (404)');
            }
        } else {
            setError('Deployment not found (404)');
        }
      } catch (err: any) {
        setError('Error loading deployment: ' + err.message);
      }
    };
    fetchDeployment();
  }, [deployId]);

  if (error) {
    return (
      <div style={{ background: '#000', color: '#fff', height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: 'monospace' }}>
        {error}
      </div>
    );
  }

  if (content === null) {
    return (
      <div style={{ background: '#000', color: '#fff', height: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', fontFamily: 'monospace' }}>
        <div className="w-8 h-8 rounded-full border-4 border-t-white border-white/20 animate-spin mb-4" />
        Loading App...
      </div>
    );
  }

  return (
    <iframe 
      srcDoc={content} 
      style={{ width: '100%', height: '100vh', border: 'none', background: '#fff' }} 
      sandbox="allow-scripts allow-same-origin allow-forms"
    />
  );
};

export default PublishedApp;
