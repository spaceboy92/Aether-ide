const axios = require('axios');
(async () => {
  try {
    const res = await axios.post('http://localhost:3000/api/ollama/models', {
      endpoint: 'https://api.openai.com/v1',
      apiKey: 'sk-1234'
    });
    console.log("Success:", res.data);
  } catch (err) {
    console.log("Error status:", err.response?.status);
    console.log("Error data:", err.response?.data);
  }
})();
