import { FileNode } from './types';

export const APP_NAME = "Aether IDE";

export const DEFAULT_FILES: FileNode[] = [
  {
    id: '1',
    name: 'index.html',
    language: 'html',
    content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Application</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body class="bg-zinc-950 text-zinc-100 min-h-screen flex flex-col justify-center items-center p-6 selection:bg-orange-500/20">
    
    <main class="max-w-md w-full bg-zinc-900/80 border border-zinc-800 rounded-2xl p-8 shadow-2xl backdrop-blur-xl text-center">
        <div class="w-12 h-12 rounded-xl bg-orange-500/10 border border-orange-500/20 text-orange-400 flex items-center justify-center mx-auto mb-6">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"></path>
            </svg>
        </div>
        <h1 class="text-2xl font-bold text-white mb-2">Aether Web Sandbox</h1>
        <p class="text-xs text-zinc-400 leading-relaxed mb-6">
            Zero-compilation client-side web environment. Edit HTML, CSS, and JS files directly to build your application.
        </p>
        <div class="flex flex-col gap-3">
            <button id="counterBtn" class="w-full py-3 bg-orange-500 hover:bg-orange-400 text-black text-xs font-bold uppercase tracking-widest rounded-xl transition-all shadow-lg active:scale-95">
                Clicked <span id="countText">0</span> times
            </button>
        </div>
    </main>

    <script src="script.js"></script>
</body>
</html>`,
    lastModified: Date.now()
  },
  {
    id: '2',
    name: 'style.css',
    language: 'css',
    content: `/* Custom styles for your web application */
body {
    font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    margin: 0;
    padding: 0;
}

/* Add custom animations or overrides here */
`,
    lastModified: Date.now()
  },
  {
    id: '3',
    name: 'script.js',
    language: 'javascript',
    content: `// Interactive application script
let count = 0;
const counterBtn = document.getElementById('counterBtn');
const countText = document.getElementById('countText');

if (counterBtn && countText) {
    counterBtn.addEventListener('click', () => {
        count++;
        countText.textContent = count;
    });
}
`,
    lastModified: Date.now()
  }
];

export const SHOWCASE_BLUEPRINTS = {
  threejs_advanced: {
    id: "3d",
    name: "Heavy Mesh Engine",
    description: "High-performance procedural geometry engine with high vertex density and custom displacement mapping.",
    files: [
      {
        path: "script.js",
        code: `
import * as THREE from 'https://unpkg.com/three@0.160.0/build/three.module.js';
import { OrbitControls } from 'https://unpkg.com/three@0.160.0/examples/jsm/controls/OrbitControls.js';

const init = () => {
    const container = document.getElementById('app');
    container.style.cssText = "padding:0; border:none; background:#000; width:100%; height:100%; overflow:hidden;";
    container.innerHTML = '<div id="viewport" style="width:100%; height:100vh;"></div>';
    
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x020617);
    scene.fog = new THREE.FogExp2(0x020617, 0.05);
    
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(10, 10, 10);
    
    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    document.getElementById('viewport').appendChild(renderer.domElement);
    
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    
    // High-Density Procedural Terrain
    const size = 100;
    const segments = 128; // Heavy mesh density
    const geometry = new THREE.PlaneGeometry(size, size, segments, segments);
    
    const vertices = geometry.attributes.position.array;
    for (let i = 0; i < vertices.length; i += 3) {
        const x = vertices[i];
        const y = vertices[i + 1];
        // Complex fractal-like noise approximation
        const z = (Math.sin(x * 0.1) * Math.cos(y * 0.1) * 3) + 
                  (Math.sin(x * 0.4) * Math.sin(y * 0.3) * 1) +
                  (Math.cos(x * 1.5) * Math.sin(y * 1.2) * 0.2);
        vertices[i + 2] = z;
    }
    geometry.computeVertexNormals();
    
    const material = new THREE.MeshStandardMaterial({ 
        color: 0x00d4ff,
        wireframe: true,
        transparent: true,
        opacity: 0.3,
        emissive: 0x00d4ff,
        emissiveIntensity: 0.2
    });
    
    const terrain = new THREE.Mesh(geometry, material);
    terrain.rotation.x = -Math.PI / 2;
    scene.add(terrain);
    
    // Dynamic Vertex Clusters
    const clusterGroup = new THREE.Group();
    for(let i=0; i<40; i++) {
        const poly = new THREE.IcosahedronGeometry(Math.random() * 1.5, 3);
        const m = new THREE.MeshStandardMaterial({ 
            color: 0xffffff, 
            wireframe: true,
            emissive: 0x38bdf8,
            emissiveIntensity: 0.5
        });
        const mesh = new THREE.Mesh(poly, m);
        mesh.position.set(
            (Math.random() - 0.5) * 60,
            Math.random() * 10,
            (Math.random() - 0.5) * 60
        );
        clusterGroup.add(mesh);
    }
    scene.add(clusterGroup);
    
    const sun = new THREE.PointLight(0xffffff, 100);
    sun.position.set(10, 20, 10);
    scene.add(sun);
    
    const animate = () => {
        requestAnimationFrame(animate);
        terrain.rotation.z += 0.0005;
        clusterGroup.children.forEach((c, idx) => {
            c.rotation.y += 0.01;
            c.position.y += Math.sin(Date.now() * 0.001 + idx) * 0.02;
        });
        controls.update();
        renderer.render(scene, camera);
    };
    
    animate();
    
    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });
};

init();
        `
      }
    ]
  }
};
