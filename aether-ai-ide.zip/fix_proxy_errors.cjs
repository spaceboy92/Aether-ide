const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  `          } catch (v1Err: any) {}`,
  `          } catch (v1Err: any) {
             console.error("v1 Fallback Error:", v1Err?.message, v1Err?.response?.data);
             // If v1 fails, we should throw v1Err instead of err because v1 is the likely intended target
             err = v1Err;
          }`
);

fs.writeFileSync('server.ts', code);
console.log("Patched proxy to log v1 errors");
