
export interface CodeErrorDiagnostics {
  file: string;
  line: number;
  column: number;
  message: string;
  codeSnippet?: string;
}

export const createDiagnosticError = (
  file: string,
  line: number,
  message: string,
  column: number = 0
): CodeErrorDiagnostics => {
  return { file, line, column, message };
};

export const formatDiagnosticLog = (error: CodeErrorDiagnostics): string => {
  return `[${error.file}:${error.line}:${error.column}] ERR: ${error.message}`;
};
