export function applyPerformanceSettings() {
  const isMobile = window.innerWidth <= 768;
  const cores = navigator.hardwareConcurrency || 4;
  let isLowPerf = false;
  
  if (isMobile && cores <= 4) isLowPerf = true;
  
  if ('deviceMemory' in navigator && (navigator as any).deviceMemory !== undefined) {
      if ((navigator as any).deviceMemory < 4) isLowPerf = true;
  }

  if (isLowPerf) {
      document.body.classList.add('perf-low');
  } else {
      document.body.classList.remove('perf-low');
  }
}

export function applySearchReplaceBlocks(originalContent: string, editContent: string): string {
  if (!editContent || typeof editContent !== 'string') return originalContent || '';
  if (!editContent.includes('<<<<<<< SEARCH')) {
    return editContent;
  }

  let result = originalContent || '';
  const blockRegex = /<<<<<<< SEARCH([\s\S]*?)=======([\s\S]*?)(?:>>>>>>> REPLACE|>>>>>>>)/g;
  let match;
  let hasMatches = false;

  while ((match = blockRegex.exec(editContent)) !== null) {
    hasMatches = true;
    const searchBlock = match[1];
    const replaceBlock = match[2];

    const searchClean = searchBlock.replace(/\r\n/g, '\n');
    const replaceClean = replaceBlock.replace(/\r\n/g, '\n');
    const resultClean = result.replace(/\r\n/g, '\n');

    if (resultClean.includes(searchClean)) {
      result = resultClean.replace(searchClean, replaceClean);
    } else {
      const searchTrimmed = searchClean.trim();
      if (searchTrimmed && resultClean.includes(searchTrimmed)) {
        const index = resultClean.indexOf(searchTrimmed);
        if (index !== -1) {
          result = resultClean.substring(0, index) + replaceClean + resultClean.substring(index + searchTrimmed.length);
        }
      } else {
        console.warn("Aether IDE partial edit: Search block could not be matched inside original file:", searchClean);
      }
    }
  }

  if (!hasMatches) {
    return editContent;
  }

  return result;
}
