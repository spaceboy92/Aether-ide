export const compactContext = (content: string, limit: number = 2000) => {
  if (!content) return "";
  if (content.length <= limit) return content;
  
  // Stage 1: Removal of noise (comments, empty lines)
  let processed = content.split('\n').map(line => {
    const index = line.indexOf('//');
    if (index !== -1 && !line.includes('http://') && !line.includes('https://')) {
      return line.slice(0, index);
    }
    return line;
  }).join('\n');
  
  processed = processed.replace(/[ \t]+/g, ' ').replace(/\n\s*\n/g, '\n').trim();

  if (processed.length <= limit) return processed;
  
  const half = Math.floor(limit / 2);
  return processed.slice(0, half) + "\n\n... [NEURAL COMPACTION: MID-BLOCK PRUNED] ...\n\n" + processed.slice(-half);
};
