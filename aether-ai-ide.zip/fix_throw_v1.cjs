const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  `} catch (v1Err) {}
        throw err;`,
  `} catch (v1Err: any) {
          throw v1Err;
        }
        throw err;`
);

code = code.replace(
  `} catch (v1Err) {}
        throw err;`,
  `} catch (v1Err: any) {
          throw v1Err;
        }
        throw err;`
);

fs.writeFileSync('server.ts', code);
console.log("Patched server.ts throwing v1 errors");
