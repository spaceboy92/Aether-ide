const fs = require('fs');
let code = fs.readFileSync('components/Settings/SettingsView.tsx', 'utf8');

const target = `<Cpu size={14} className="text-orange-400" /> Ollama Mobile & Desktop Setup`;
const replacement = `<Cpu size={14} className="text-orange-400" /> Cloud AI & Local Models Setup`;

let patched = false;
if (code.includes(target)) {
  code = code.replace(target, replacement);
  patched = true;
  console.log("Patched tab title");
}

if(patched) {
  fs.writeFileSync('components/Settings/SettingsView.tsx', code);
} else {
  console.log("Could not find target");
}
