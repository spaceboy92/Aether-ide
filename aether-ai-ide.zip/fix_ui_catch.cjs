const fs = require('fs');
let code = fs.readFileSync('components/Settings/SettingsView.tsx', 'utf8');

const targetStr = `      const res = await fetch("/api/ollama/models", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ endpoint: ollamaServerUrl, apiKey: ollamaApiKey })
      });
      const data = await res.json();
      if (!res.ok || data.error) throw new Error(data.error || "Failed to sync Ollama models");`;

const newStr = `      const res = await fetch("/api/ollama/models", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ endpoint: ollamaServerUrl, apiKey: ollamaApiKey })
      });
      let data;
      const textResponse = await res.text();
      try {
        data = JSON.parse(textResponse);
      } catch (e) {
        throw new Error("Invalid URL or Provider responded with an HTML page instead of JSON.");
      }
      if (!res.ok || data.error) throw new Error(data.error || "Failed to sync Ollama models");`;

if(code.includes(targetStr)) {
  code = code.replace(targetStr, newStr);
  fs.writeFileSync('components/Settings/SettingsView.tsx', code);
  console.log("Patched UI error handling");
} else {
  console.log("Could not find target string in UI");
}
