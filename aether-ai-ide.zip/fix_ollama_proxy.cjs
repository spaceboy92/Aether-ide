const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const oldProxy = `  app.post("/api/ollama/proxy", async (req, res) => {
    try {
      const { endpoint, method = "POST", body, serverUrl = "http://localhost:11434", apiKey } = req.body;
      const cleanServerUrl = serverUrl.replace(/\\/+$/, "");
      const targetUrl = \`\${cleanServerUrl}\${endpoint}\`;

      const headers: any = {};
      if (apiKey) {
        headers["Authorization"] = \`Bearer \${apiKey}\`;
      }

      if (body?.stream) {
        res.setHeader("Content-Type", "text/plain; charset=utf-8");
        res.setHeader("Transfer-Encoding", "chunked");

        const response = await axios({
          method: method.toLowerCase(),
          url: targetUrl,
          headers,
          data: body,
          responseType: "stream",
          timeout: 300000
        });

        response.data.pipe(res);
      } else {
        const response = await axios({
          method: method.toLowerCase(),
          url: targetUrl,
          headers,
          data: body,
          timeout: 30000
        });
        res.status(response.status).json(response.data);
      }
    } catch (err: any) {
      console.error("[OLLAMA PROXY ERROR]", err?.message);
      res.status(err?.response?.status || 500).json({
        error: err?.message || "Failed to communicate with Ollama server",
        details: err?.response?.data || null
      });
    }
  });`;

const newProxy = `  app.post("/api/ollama/proxy", async (req, res) => {
    try {
      const { endpoint, method = "POST", body, serverUrl = "http://localhost:11434", apiKey } = req.body;
      const cleanServerUrl = serverUrl.replace(/\\/+$/, "");
      const targetUrl = \`\${cleanServerUrl}\${endpoint}\`;

      const headers: any = {};
      if (apiKey) {
        headers["Authorization"] = \`Bearer \${apiKey}\`;
      }

      try {
        if (body?.stream) {
          const response = await axios({
            method: method.toLowerCase(),
            url: targetUrl,
            headers,
            data: body,
            responseType: "stream",
            timeout: 300000
          });
          res.setHeader("Content-Type", "text/plain; charset=utf-8");
          res.setHeader("Transfer-Encoding", "chunked");
          response.data.pipe(res);
        } else {
          const response = await axios({
            method: method.toLowerCase(),
            url: targetUrl,
            headers,
            data: body,
            timeout: 30000
          });
          res.status(response.status).json(response.data);
        }
      } catch (err: any) {
        // Fallback for OpenAI compatible APIs if standard Ollama fails
        if (endpoint === '/api/chat') {
          try {
            const v1Url = cleanServerUrl.endsWith('/v1') ? \`\${cleanServerUrl}/chat/completions\` : \`\${cleanServerUrl}/v1/chat/completions\`;
            
            // Transform Ollama body to OpenAI body
            const oaiBody = {
               model: body.model,
               messages: body.messages,
               stream: body.stream
            };

            if (body.stream) {
               const responseV1 = await axios({
                 method: 'post',
                 url: v1Url,
                 headers,
                 data: oaiBody,
                 responseType: 'stream',
                 timeout: 300000
               });
               
               res.setHeader("Content-Type", "text/plain; charset=utf-8");
               res.setHeader("Transfer-Encoding", "chunked");

               // Transform OpenAI SSE to Ollama JSON stream format
               responseV1.data.on('data', (chunk) => {
                  const lines = chunk.toString().split('\\n');
                  for (const line of lines) {
                     if (line.trim().startsWith('data: ') && line.trim() !== 'data: [DONE]') {
                        try {
                           const data = JSON.parse(line.replace(/^data: /, ''));
                           const content = data.choices?.[0]?.delta?.content || "";
                           if (content) {
                             res.write(JSON.stringify({
                                model: body.model,
                                message: { role: 'assistant', content },
                                done: false
                             }) + '\\n');
                           }
                        } catch(e){}
                     }
                  }
               });
               responseV1.data.on('end', () => res.end());
               return;
            } else {
               const responseV1 = await axios({
                 method: 'post',
                 url: v1Url,
                 headers,
                 data: oaiBody,
                 timeout: 30000
               });
               return res.status(responseV1.status).json({
                  message: { role: 'assistant', content: responseV1.data.choices?.[0]?.message?.content || "" }
               });
            }
          } catch (v1Err: any) {}
        }
        
        console.error("[OLLAMA PROXY ERROR]", err?.message);
        res.status(err?.response?.status || 500).json({
          error: err?.message || "Failed to communicate with AI server",
          details: err?.response?.data || null
        });
      }
    } catch (err: any) {
      console.error("[OLLAMA PROXY ERROR]", err?.message);
      res.status(500).json({ error: "Internal Server Error" });
    }
  });`;

if (code.includes(oldProxy)) {
  code = code.replace(oldProxy, newProxy);
  fs.writeFileSync('server.ts', code);
  console.log("Patched server.ts proxy endpoint");
} else {
  console.log("Could not find oldProxy");
}
