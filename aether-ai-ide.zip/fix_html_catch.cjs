const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const targetStr = `      res.status(502).json({ 
        error: \`Could not connect to AI Provider at \${endpoint}.\`,
        details: error.message 
      });`;

const newStr = `      res.status(502).json({ 
        error: \`Could not connect to AI Provider at \${endpoint}.\`,
        details: error.response?.data && typeof error.response.data === 'string' && error.response.data.includes('<!DOCTYPE') ? "Received HTML error page (Check URL)" : error.message 
      });`;

code = code.replace(targetStr, newStr);
fs.writeFileSync('server.ts', code);
console.log("Patched HTML error handling");
