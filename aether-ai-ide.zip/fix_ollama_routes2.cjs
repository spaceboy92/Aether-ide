const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const targetStrModels = `    } catch (error: any) {
      res.status(502).json({ 
        error: \`Could not connect to AI Provider at \${endpoint}.\`,
        details: error.response?.data && typeof error.response.data === 'string' && error.response.data.includes('<!DOCTYPE') ? "Received HTML error page (Check URL)" : error.message 
      });
    }`;

const newStrModels = `    } catch (error: any) {
      const isHtml = error.response?.data && typeof error.response.data === 'string' && error.response.data.toLowerCase().includes('<!doctype');
      res.status(502).json({ 
        error: \`Could not connect to AI Provider at \${endpoint}.\`,
        details: isHtml ? "Received HTML error page (Check your endpoint URL)" : error.message 
      });
    }`;

if(code.includes(targetStrModels)) {
  code = code.replace(targetStrModels, newStrModels);
  console.log("Patched models route");
} else {
  console.log("Could not find target string for models route");
}

fs.writeFileSync('server.ts', code);
