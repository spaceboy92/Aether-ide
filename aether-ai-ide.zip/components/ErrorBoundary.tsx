import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      let errorMessage = "An unexpected error occurred.";
      let errorDetails = this.state.error?.message;

      // Try to parse FirestoreErrorInfo
      try {
        if (errorDetails && errorDetails.includes('operationType')) {
          const parsedError = JSON.parse(errorDetails);
          if (parsedError.error && parsedError.error.includes('Missing or insufficient permissions')) {
            errorMessage = "You don't have permission to access this data.";
            errorDetails = `Operation: ${parsedError.operationType} on ${parsedError.path}`;
          }
        }
      } catch (e) {
        // Ignore parsing errors
      }

      return (
        <div className="flex flex-col items-center justify-center min-h-[100dvh] py-8 bg-black text-white p-6 text-center space-y-6">
          <div className="w-20 h-20 rounded-full bg-red-500/10 flex items-center justify-center ring-1 ring-red-500/20">
            <AlertTriangle className="text-red-500" size={32} />
          </div>
          <div className="space-y-2 max-w-md">
            <h2 className="text-2xl font-bold tracking-tight">System Kernel Exception</h2>
            <p className="text-white/40 text-sm leading-relaxed">
              Aether Alpha encountered a critical runtime error in the current abstraction layer. 
              Your local node state and Google Drive sync remain intact.
            </p>
          </div>
          <div className="p-4 bg-white/[0.03] border border-white/5 rounded-xl font-mono text-[10px] text-red-400 max-w-lg w-full overflow-hidden text-left break-all shadow-inner">
            {this.state.error?.message}
          </div>
          <button
            onClick={() => window.location.reload()}
            className="flex items-center gap-2 px-8 py-4 bg-white text-black rounded-xl font-black hover:scale-[1.02] active:scale-[0.98] transition-all shadow-[0_0_40px_rgba(255,255,255,0.2)] uppercase tracking-widest text-[11px]"
          >
            Initialize Core Restart
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
