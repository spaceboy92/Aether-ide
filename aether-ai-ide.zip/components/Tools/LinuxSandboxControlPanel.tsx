import React, { useState, useEffect } from 'react';
import { Server, Cpu, HardDrive, Activity, RefreshCw, Terminal, Play, CheckCircle2, AlertCircle, Globe, ShieldCheck, Zap } from 'lucide-react';
import { sandboxManager, SandboxStatus, ProcessItem } from '../../services/sandboxManager';

export const LinuxSandboxControlPanel: React.FC<{ onClose?: () => void }> = ({ onClose }) => {
  const [status, setStatus] = useState<SandboxStatus | null>(null);
  const [processes, setProcesses] = useState<ProcessItem[]>([]);
  const [cmdInput, setCmdInput] = useState('');
  const [outputLogs, setOutputLogs] = useState<Array<{ type: 'cmd' | 'out' | 'err'; text: string }>>([
    { type: 'out', text: '[AETHER LINUX VM SANDBOX]: Environment initialized at /workspace' },
    { type: 'out', text: 'Persistent volumes mounted. Real Linux terminal bash & AI agent tools ready.' }
  ]);
  const [isExecuting, setIsExecuting] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'terminal' | 'processes' | 'ports'>('overview');

  const refreshStats = async () => {
    const s = await sandboxManager.getStatus();
    setStatus(s);
    const p = await sandboxManager.getProcesses();
    setProcesses(p);
  };

  useEffect(() => {
    refreshStats();
    const interval = setInterval(refreshStats, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleExecute = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!cmdInput.trim() || isExecuting) return;

    const cmd = cmdInput.trim();
    setCmdInput('');
    setOutputLogs(prev => [...prev, { type: 'cmd', text: `$ ${cmd}` }]);
    setIsExecuting(true);

    const res = await sandboxManager.executeCommand(cmd);
    setIsExecuting(false);

    if (res.stdout) {
      setOutputLogs(prev => [...prev, { type: 'out', text: res.stdout }]);
    }
    if (res.stderr) {
      setOutputLogs(prev => [...prev, { type: 'err', text: res.stderr }]);
    }
    if (!res.stdout && !res.stderr) {
      setOutputLogs(prev => [...prev, { type: 'out', text: `Process exited with code ${res.exitCode} (${res.durationMs}ms)` }]);
    }
    refreshStats();
  };

  return (
    <div className="w-full h-full bg-aether-bg border border-aether-border rounded-xl flex flex-col overflow-hidden text-xs text-slate-200">
      {/* Header */}
      <div className="px-5 py-3 border-b border-aether-border bg-aether-panel/60 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
            <Server size={18} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-bold text-sm text-slate-100">Aether Cloud Linux Sandbox</h2>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                status?.status === 'ACTIVE' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
              }`}>
                {status?.status || 'ACTIVE'}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono">
              /workspace persistent storage • Isolated Linux Container VM
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={refreshStats}
            className="p-1.5 rounded-lg border border-aether-border bg-aether-panel/40 hover:bg-slate-800 text-slate-300 transition-colors"
            title="Refresh sandbox metrics"
          >
            <RefreshCw size={14} />
          </button>
        </div>
      </div>

      {/* Navigation tabs */}
      <div className="px-5 py-2 border-b border-aether-border bg-aether-panel/30 flex items-center gap-2">
        {(['overview', 'terminal', 'processes', 'ports'] as const).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-3 py-1 rounded-md capitalize font-medium transition-all ${
              activeTab === tab
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Body Content */}
      <div className="flex-1 overflow-y-auto p-5">
        {activeTab === 'overview' && (
          <div className="space-y-4">
            {/* Metric Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="p-3.5 rounded-xl border border-aether-border bg-aether-panel/40">
                <div className="flex items-center justify-between text-slate-400 mb-2">
                  <span className="text-[11px]">CPU Load</span>
                  <Cpu size={14} className="text-cyan-400" />
                </div>
                <div className="text-lg font-bold text-slate-100 font-mono">
                  {status?.cpuUsagePercent || 12}%
                </div>
                <div className="w-full h-1.5 bg-slate-800 rounded-full mt-2 overflow-hidden">
                  <div className="h-full bg-cyan-400 rounded-full" style={{ width: `${status?.cpuUsagePercent || 12}%` }}></div>
                </div>
              </div>

              <div className="p-3.5 rounded-xl border border-aether-border bg-aether-panel/40">
                <div className="flex items-center justify-between text-slate-400 mb-2">
                  <span className="text-[11px]">Memory (RAM)</span>
                  <Activity size={14} className="text-emerald-400" />
                </div>
                <div className="text-lg font-bold text-slate-100 font-mono">
                  {status?.memoryUsedMb || 512} MB
                </div>
                <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                  of {status?.memoryTotalMb || 2048} MB
                </div>
              </div>

              <div className="p-3.5 rounded-xl border border-aether-border bg-aether-panel/40">
                <div className="flex items-center justify-between text-slate-400 mb-2">
                  <span className="text-[11px]">Storage /workspace</span>
                  <HardDrive size={14} className="text-purple-400" />
                </div>
                <div className="text-lg font-bold text-slate-100 font-mono">
                  {status?.diskUsedGb || 1.8} GB
                </div>
                <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                  of {status?.diskTotalGb || 20} GB Quota
                </div>
              </div>

              <div className="p-3.5 rounded-xl border border-aether-border bg-aether-panel/40">
                <div className="flex items-center justify-between text-slate-400 mb-2">
                  <span className="text-[11px]">Running Ports</span>
                  <Globe size={14} className="text-amber-400" />
                </div>
                <div className="text-lg font-bold text-slate-100 font-mono flex items-center gap-1">
                  {status?.runningPorts.length || 1}
                </div>
                <div className="text-[10px] text-emerald-400 font-mono mt-0.5">
                  {(status?.runningPorts || [3000]).join(', ')}
                </div>
              </div>
            </div>

            {/* Runtime spec banner */}
            <div className="p-4 rounded-xl border border-emerald-500/30 bg-emerald-500/5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <ShieldCheck size={20} className="text-emerald-400" />
                <div>
                  <h4 className="font-bold text-slate-200">Full Linux Runtime Sandbox Active</h4>
                  <p className="text-slate-400 font-mono text-[11px]">
                    {status?.runtime || 'Linux Container (Node v22 / Python 3.10 / Bash)'}
                  </p>
                </div>
              </div>
              <span className="px-3 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 font-bold font-mono text-[11px]">
                Isolated Container
              </span>
            </div>
          </div>
        )}

        {activeTab === 'terminal' && (
          <div className="h-full flex flex-col space-y-3 font-mono">
            <div className="flex-1 bg-slate-950 border border-slate-800 rounded-lg p-3 overflow-y-auto text-[11px] leading-relaxed space-y-1">
              {outputLogs.map((log, i) => (
                <div key={i} className={log.type === 'cmd' ? 'text-cyan-400 font-bold' : log.type === 'err' ? 'text-red-400' : 'text-slate-300'}>
                  {log.text}
                </div>
              ))}
              {isExecuting && (
                <div className="text-amber-400 animate-pulse">Running bash command in sandbox...</div>
              )}
            </div>

            <form onSubmit={handleExecute} className="flex items-center gap-2">
              <input
                type="text"
                placeholder="Type bash command (e.g. ls -la, python3 script.py, npm run build)..."
                value={cmdInput}
                onChange={(e) => setCmdInput(e.target.value)}
                className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500 font-mono"
              />
              <button
                type="submit"
                disabled={isExecuting}
                className="px-4 py-2 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400 disabled:opacity-50 transition-all flex items-center gap-1.5"
              >
                <Play size={13} /> Run
              </button>
            </form>
          </div>
        )}

        {activeTab === 'processes' && (
          <div className="space-y-2 font-mono">
            <div className="text-slate-400 font-bold mb-2">Active Container OS Processes ({processes.length}):</div>
            <div className="border border-slate-800 rounded-lg overflow-hidden">
              <table className="w-full text-left text-[11px]">
                <thead className="bg-slate-900 text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="p-2">PID</th>
                    <th className="p-2">USER</th>
                    <th className="p-2">CPU%</th>
                    <th className="p-2">MEM%</th>
                    <th className="p-2">COMMAND</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 bg-slate-950">
                  {processes.map((p, i) => (
                    <tr key={i} className="hover:bg-slate-900/50">
                      <td className="p-2 text-cyan-400">{p.pid}</td>
                      <td className="p-2 text-slate-400">{p.user}</td>
                      <td className="p-2 text-emerald-400">{p.cpu}%</td>
                      <td className="p-2 text-purple-400">{p.mem}%</td>
                      <td className="p-2 text-slate-200">{p.command}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'ports' && (
          <div className="space-y-4 font-mono">
            <div className="flex items-center justify-between">
              <div className="text-slate-300 font-bold text-xs">Exposed Ports & Dynamic Proxies:</div>
              <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                CORS Bypass Active
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {(status?.runningPorts || [3000, 5173]).map(port => (
                <div key={port} className="p-3.5 rounded-xl border border-slate-800 bg-slate-950 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                      <span className="font-bold text-sm text-slate-100">Port {port}</span>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 text-[10px] font-bold">
                      LISTENING
                    </span>
                  </div>

                  <div className="text-[11px] space-y-1 text-slate-400">
                    <div className="flex justify-between">
                      <span>Local URL:</span>
                      <span className="text-slate-200">http://127.0.0.1:{port}</span>
                    </div>
                    <div className="flex justify-between text-cyan-300">
                      <span>Proxy URL:</span>
                      <a href={`/api/ports/${port}`} target="_blank" rel="noreferrer" className="underline hover:text-cyan-200">
                        /api/ports/{port}
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-3 bg-slate-900/60 border border-slate-800 rounded-xl space-y-1.5 text-[11px]">
              <div className="text-slate-300 font-bold">Local Host IP Addresses:</div>
              <div className="text-slate-400">
                • Primary Host: <code className="text-emerald-300">127.0.0.1</code> (localhost)
              </div>
              <div className="text-slate-400">
                • Container Bridge: <code className="text-cyan-300">0.0.0.0</code> (All interfaces)
              </div>
              <div className="text-slate-500 text-[10px] pt-1">
                Tip: Background backend servers (Flask, FastAPI, Node, Ollama) bound to any port can be accessed directly or via <code className="text-slate-400">/api/ports/[port]</code> with zero CORS blocks.
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
