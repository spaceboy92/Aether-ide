import React, { useState, useEffect } from "react";
import {
  Server,
  Network,
  Globe,
  Radio,
  Copy,
  Check,
  RefreshCw,
  ExternalLink,
  Shield,
  Zap,
  Terminal,
  Activity,
  X,
  ArrowRight,
  Cpu,
  Wifi,
  Play,
  CheckCircle2,
  AlertTriangle,
  Layers
} from "lucide-react";

interface NetworkInterface {
  interface: string;
  address: string;
  family: string;
  internal: boolean;
  mac: string;
  netmask: string;
  cidr: string | null;
}

interface ListeningService {
  port: number;
  protocol: string;
  label: string;
  proxyUrl: string;
  directUrl: string;
}

interface NetworkInfoResponse {
  success: boolean;
  hostname: string;
  platform: string;
  arch: string;
  uptimeSeconds: number;
  clientIp: string;
  localIps: string[];
  interfaces: NetworkInterface[];
  ports: number[];
  listeningServices: ListeningService[];
  forwardingBaseUrl: string;
}

interface NetworkHubModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenInPreview?: (url: string) => void;
}

export const NetworkHubModal: React.FC<NetworkHubModalProps> = ({
  isOpen,
  onClose,
  onOpenInPreview,
}) => {
  const [networkInfo, setNetworkInfo] = useState<NetworkInfoResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [customPortInput, setCustomPortInput] = useState("");
  const [testUrlInput, setTestUrlInput] = useState("");
  const [testResult, setTestResult] = useState<{ status: "idle" | "loading" | "success" | "error"; message?: string; latency?: number }>({ status: "idle" });

  const fetchNetworkInfo = async () => {
    setIsLoading(true);
    try {
      const res = await fetch("/api/sandbox/network-info");
      if (res.ok) {
        const data = await res.json();
        setNetworkInfo(data);
      }
    } catch (err) {
      console.error("Failed to load network info:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchNetworkInfo();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleTestConnection = async () => {
    if (!testUrlInput.trim()) return;
    setTestResult({ status: "loading" });
    const startTime = performance.now();
    try {
      let targetUrl = testUrlInput.trim();
      if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
        targetUrl = "http://" + targetUrl;
      }

      // Test through CORS proxy
      const proxyTestUrl = `/api/cors-proxy?url=${encodeURIComponent(targetUrl)}`;
      const res = await fetch(proxyTestUrl, { method: "HEAD" });
      const latency = Math.round(performance.now() - startTime);

      if (res.ok || res.status < 500) {
        setTestResult({
          status: "success",
          message: `Connected successfully (HTTP ${res.status})`,
          latency,
        });
      } else {
        setTestResult({
          status: "error",
          message: `Endpoint returned HTTP ${res.status}`,
          latency,
        });
      }
    } catch (err: any) {
      setTestResult({
        status: "error",
        message: err.message || "Connection failed or refused",
      });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl max-h-[90vh] bg-zinc-950 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800/80 bg-zinc-900/50">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-cyan-500/10 border border-cyan-500/20 rounded-xl text-cyan-400">
              <Network size={20} />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                User Server Ports & Local IPs Hub
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
                  LIVE PROXY
                </span>
              </h2>
              <p className="text-xs text-zinc-400">
                Active server listening ports, network interfaces, IP addresses & dynamic port proxies
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={fetchNetworkInfo}
              disabled={isLoading}
              className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-800/80 rounded-lg transition-colors cursor-pointer"
              title="Refresh Network Stats"
            >
              <RefreshCw size={16} className={isLoading ? "animate-spin text-cyan-400" : ""} />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-800/80 rounded-lg transition-colors cursor-pointer"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Quick Metrics Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div className="p-3.5 bg-zinc-900/60 border border-zinc-800 rounded-xl flex flex-col justify-between">
              <div className="flex items-center justify-between text-zinc-400 text-xs mb-1">
                <span>Client (Public) IP</span>
                <Globe size={14} className="text-cyan-400" />
              </div>
              <div className="flex items-center justify-between">
                <span className="font-mono text-sm font-bold text-cyan-300">
                  {networkInfo?.clientIp || "127.0.0.1"}
                </span>
                <button
                  onClick={() => handleCopy(networkInfo?.clientIp || "127.0.0.1", "client-ip")}
                  className="p-1 hover:bg-zinc-800 text-zinc-500 hover:text-zinc-300 rounded"
                >
                  {copiedKey === "client-ip" ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                </button>
              </div>
            </div>

            <div className="p-3.5 bg-zinc-900/60 border border-zinc-800 rounded-xl flex flex-col justify-between">
              <div className="flex items-center justify-between text-zinc-400 text-xs mb-1">
                <span>Primary Local IP</span>
                <Wifi size={14} className="text-emerald-400" />
              </div>
              <div className="flex items-center justify-between">
                <span className="font-mono text-sm font-bold text-emerald-300">
                  {networkInfo?.localIps?.[0] || "127.0.0.1"}
                </span>
                <button
                  onClick={() => handleCopy(networkInfo?.localIps?.[0] || "127.0.0.1", "local-ip")}
                  className="p-1 hover:bg-zinc-800 text-zinc-500 hover:text-zinc-300 rounded"
                >
                  {copiedKey === "local-ip" ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                </button>
              </div>
            </div>

            <div className="p-3.5 bg-zinc-900/60 border border-zinc-800 rounded-xl flex flex-col justify-between">
              <div className="flex items-center justify-between text-zinc-400 text-xs mb-1">
                <span>Listening Ports</span>
                <Radio size={14} className="text-purple-400" />
              </div>
              <div className="flex items-center gap-1.5">
                <span className="font-mono text-sm font-bold text-purple-300">
                  {networkInfo?.ports?.length || 1} Active
                </span>
                <span className="text-[10px] text-zinc-500 font-mono">
                  ({networkInfo?.ports?.join(", ")})
                </span>
              </div>
            </div>

            <div className="p-3.5 bg-zinc-900/60 border border-zinc-800 rounded-xl flex flex-col justify-between">
              <div className="flex items-center justify-between text-zinc-400 text-xs mb-1">
                <span>Hostname & OS</span>
                <Cpu size={14} className="text-amber-400" />
              </div>
              <div className="font-mono text-xs font-semibold text-zinc-300 truncate">
                {networkInfo?.hostname || "localhost"} ({networkInfo?.platform || "linux"})
              </div>
            </div>
          </div>

          {/* Section 1: Active Listening Ports & Forwarding Proxies */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-zinc-200 flex items-center gap-2">
                <Server size={15} className="text-cyan-400" />
                Active Server Ports & Direct Forwarding Proxies
              </h3>
              <span className="text-xs text-zinc-500 font-mono">
                Bypass CORS with /api/ports/:port/
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {networkInfo?.listeningServices && networkInfo.listeningServices.length > 0 ? (
                networkInfo.listeningServices.map((srv) => (
                  <div
                    key={srv.port}
                    className="p-3.5 bg-zinc-900/80 border border-zinc-800 hover:border-zinc-700 rounded-xl space-y-2.5 transition-all"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                        <span className="font-mono text-xs font-bold text-white">
                          Port {srv.port}
                        </span>
                        <span className="text-[10px] px-2 py-0.5 bg-zinc-800 text-zinc-300 rounded-md border border-zinc-700">
                          {srv.label}
                        </span>
                      </div>
                      <span className="text-[10px] text-zinc-500 font-mono uppercase">
                        {srv.protocol}
                      </span>
                    </div>

                    <div className="space-y-1.5 text-xs font-mono">
                      <div className="flex items-center justify-between bg-zinc-950 p-1.5 rounded border border-zinc-800/80">
                        <span className="text-zinc-500">Local URL:</span>
                        <span className="text-zinc-300">{srv.directUrl}</span>
                        <button
                          onClick={() => handleCopy(srv.directUrl, `direct-${srv.port}`)}
                          className="text-zinc-500 hover:text-zinc-300 p-0.5"
                        >
                          {copiedKey === `direct-${srv.port}` ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                        </button>
                      </div>

                      <div className="flex items-center justify-between bg-cyan-950/20 p-1.5 rounded border border-cyan-500/20">
                        <span className="text-cyan-400">Proxy Path:</span>
                        <span className="text-cyan-200 truncate max-w-[200px]">{srv.proxyUrl}</span>
                        <button
                          onClick={() => handleCopy(`${window.location.origin}${srv.proxyUrl}`, `proxy-${srv.port}`)}
                          className="text-cyan-400 hover:text-cyan-200 p-0.5"
                        >
                          {copiedKey === `proxy-${srv.port}` ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 pt-1">
                      {onOpenInPreview && (
                        <button
                          onClick={() => {
                            onOpenInPreview(`workspace://${srv.proxyUrl}`);
                            onClose();
                          }}
                          className="flex-1 py-1.5 bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-300 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                        >
                          <Play size={12} />
                          Preview in IDE
                        </button>
                      )}
                      <a
                        href={srv.proxyUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="py-1.5 px-3 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors"
                      >
                        <ExternalLink size={12} />
                        New Tab
                      </a>
                    </div>
                  </div>
                ))
              ) : (
                <div className="col-span-2 p-4 text-center text-xs text-zinc-500">
                  No custom background listening ports detected yet. Launch your local server (Python/Flask/Node/FastAPI) and it will appear here automatically!
                </div>
              )}
            </div>
          </div>

          {/* Section 2: Network Interfaces & Local IP Addresses */}
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-zinc-200 flex items-center gap-2">
              <Layers size={15} className="text-emerald-400" />
              All Network Interfaces & Local IP Mappings
            </h3>

            <div className="overflow-x-auto border border-zinc-800 rounded-xl bg-zinc-900/40">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-zinc-900 text-zinc-400 border-b border-zinc-800">
                  <tr>
                    <th className="px-3 py-2">Interface</th>
                    <th className="px-3 py-2">IP Address</th>
                    <th className="px-3 py-2">Family</th>
                    <th className="px-3 py-2">Netmask</th>
                    <th className="px-3 py-2">Type</th>
                    <th className="px-3 py-2 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/60">
                  {networkInfo?.interfaces && networkInfo.interfaces.length > 0 ? (
                    networkInfo.interfaces.map((iface, idx) => (
                      <tr key={idx} className="hover:bg-zinc-800/30 transition-colors">
                        <td className="px-3 py-2 text-cyan-300 font-bold">{iface.interface}</td>
                        <td className="px-3 py-2 text-zinc-200">{iface.address}</td>
                        <td className="px-3 py-2 text-zinc-400">{iface.family}</td>
                        <td className="px-3 py-2 text-zinc-500">{iface.netmask}</td>
                        <td className="px-3 py-2">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] ${
                              iface.internal
                                ? "bg-zinc-800 text-zinc-400"
                                : "bg-emerald-500/10 text-emerald-300 border border-emerald-500/20"
                            }`}
                          >
                            {iface.internal ? "Loopback" : "External LAN"}
                          </span>
                        </td>
                        <td className="px-3 py-2 text-right">
                          <button
                            onClick={() => handleCopy(iface.address, `iface-${idx}`)}
                            className="p-1 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded"
                            title="Copy IP"
                          >
                            {copiedKey === `iface-${idx}` ? (
                              <Check size={12} className="text-emerald-400" />
                            ) : (
                              <Copy size={12} />
                            )}
                          </button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={6} className="px-3 py-4 text-center text-zinc-500">
                        Loading network interfaces...
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 3: Custom IP & Port Connectivity Tester */}
          <div className="p-4 bg-zinc-900/60 border border-zinc-800 rounded-xl space-y-3">
            <h3 className="text-sm font-bold text-zinc-200 flex items-center gap-2">
              <Zap size={15} className="text-amber-400" />
              Custom Local IP & Chat URL Connection Tester
            </h3>
            <p className="text-xs text-zinc-400">
              Test connectivity to any local IP, remote host, Ollama server, or chat endpoint with auto CORS bypass.
            </p>

            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={testUrlInput}
                onChange={(e) => setTestUrlInput(e.target.value)}
                placeholder="e.g. http://192.168.1.50:11434, http://localhost:8000, https://api.openai.com"
                className="flex-1 px-3 py-2 bg-zinc-950 border border-zinc-800 rounded-lg text-xs font-mono text-white placeholder:text-zinc-600 focus:outline-none focus:border-cyan-500"
              />
              <button
                onClick={handleTestConnection}
                disabled={testResult.status === "loading" || !testUrlInput.trim()}
                className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold rounded-lg flex items-center justify-center gap-2 transition-colors cursor-pointer disabled:opacity-50"
              >
                {testResult.status === "loading" ? (
                  <RefreshCw size={13} className="animate-spin" />
                ) : (
                  <Activity size={13} />
                )}
                Test Ping
              </button>
            </div>

            {testResult.status !== "idle" && (
              <div
                className={`p-2.5 rounded-lg text-xs flex items-center justify-between ${
                  testResult.status === "success"
                    ? "bg-emerald-500/10 border border-emerald-500/20 text-emerald-300"
                    : testResult.status === "error"
                    ? "bg-rose-500/10 border border-rose-500/20 text-rose-300"
                    : "bg-zinc-800 text-zinc-300"
                }`}
              >
                <div className="flex items-center gap-2">
                  {testResult.status === "success" && <CheckCircle2 size={14} className="text-emerald-400" />}
                  {testResult.status === "error" && <AlertTriangle size={14} className="text-rose-400" />}
                  {testResult.status === "loading" && <RefreshCw size={14} className="animate-spin text-cyan-400" />}
                  <span>{testResult.message || "Pinging target host..."}</span>
                </div>
                {testResult.latency !== undefined && (
                  <span className="font-mono text-[10px] opacity-80">{testResult.latency}ms</span>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-zinc-800 bg-zinc-900/40 flex items-center justify-between text-xs text-zinc-500">
          <div className="flex items-center gap-2">
            <Shield size={13} className="text-emerald-400" />
            <span>Automatic CORS Proxy Routing Active</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg font-medium transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
