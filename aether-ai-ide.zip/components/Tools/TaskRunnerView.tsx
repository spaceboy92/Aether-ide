import React, { useState, useEffect } from 'react';
import { Play, Loader2, CheckCircle2, Terminal as TerminalIcon, Trash2, ShieldAlert, Package, Sparkles, Box, RefreshCw } from 'lucide-react';
import { FileNode } from '../../types';

interface TaskRunnerViewProps {
  sessionId: string | null;
  files: FileNode[];
  addLog: (type: 'info' | 'success' | 'error' | 'warning', message: string, source?: string) => void;
}

interface TaskState {
  name: string;
  command: string;
  status: 'idle' | 'running' | 'completed' | 'failed';
  stdout: string;
  stderr: string;
  exitCode: number | null;
}

export const TaskRunnerView: React.FC<TaskRunnerViewProps> = ({ sessionId, files, addLog }) => {
  const [tasks, setTasks] = useState<TaskState[]>([]);
  const [activeTaskName, setActiveTaskName] = useState<string | null>(null);

  // Autonomous Package Guard State
  const [missingDeps, setMissingDeps] = useState<string[]>([]);
  const [detectedEnv, setDetectedEnv] = useState<'Node.js' | 'Rust' | 'Python' | 'Static Web'>('Node.js');
  const [isAutoInstalling, setIsAutoInstalling] = useState(false);

  // Scan dependencies and detect environment
  useEffect(() => {
    // 1. Detect environment
    const hasCargo = files.some(f => f.name === 'Cargo.toml');
    const hasRequirements = files.some(f => f.name === 'requirements.txt');
    const hasPackageJson = files.some(f => f.name === 'package.json');

    if (hasCargo) setDetectedEnv('Rust');
    else if (hasRequirements) setDetectedEnv('Python');
    else if (hasPackageJson) setDetectedEnv('Node.js');
    else setDetectedEnv('Static Web');

    // 2. Scan for imported packages
    const declaredDeps = new Set<string>();
    const pkgFile = files.find(f => f.name === 'package.json');
    if (pkgFile) {
      try {
        const parsed = JSON.parse(pkgFile.content);
        if (parsed.dependencies) Object.keys(parsed.dependencies).forEach(k => declaredDeps.add(k));
        if (parsed.devDependencies) Object.keys(parsed.devDependencies).forEach(k => declaredDeps.add(k));
      } catch (e) {}
    }

    const scannedDeps = new Set<string>();
    const nodeBuiltins = new Set(['fs', 'path', 'os', 'child_process', 'http', 'https', 'crypto', 'events', 'stream', 'util', 'url', 'buffer']);

    files.forEach(f => {
      if (f.name.endsWith('.ts') || f.name.endsWith('.tsx') || f.name.endsWith('.js') || f.name.endsWith('.jsx')) {
        const content = f.content || '';
        
        // Match import ... from 'package'
        const importRegex = /import\s+(?:[^'"]+\s+from\s+)?['"]([^'"]+)['"]/g;
        let match;
        while ((match = importRegex.exec(content)) !== null) {
          const rawDep = match[1];
          if (rawDep.startsWith('.') || rawDep.startsWith('/') || rawDep.startsWith('@/')) continue;
          const parts = rawDep.split('/');
          const rootDep = rawDep.startsWith('@') ? `${parts[0]}/${parts[1] || ''}` : parts[0];
          if (!nodeBuiltins.has(rootDep) && rootDep.trim().length > 0) {
            scannedDeps.add(rootDep);
          }
        }

        // Match require('package')
        const requireRegex = /require\s*\(\s*['"]([^'"]+)['"]\s*\)/g;
        while ((match = requireRegex.exec(content)) !== null) {
          const rawDep = match[1];
          if (rawDep.startsWith('.') || rawDep.startsWith('/') || rawDep.startsWith('@/')) continue;
          const parts = rawDep.split('/');
          const rootDep = rawDep.startsWith('@') ? `${parts[0]}/${parts[1] || ''}` : parts[0];
          if (!nodeBuiltins.has(rootDep) && rootDep.trim().length > 0) {
            scannedDeps.add(rootDep);
          }
        }
      }
    });

    if (hasPackageJson) {
      const missing = Array.from(scannedDeps).filter(d => !declaredDeps.has(d));
      setMissingDeps(missing);
    } else {
      setMissingDeps([]);
    }
  }, [files]);

  // Parse scripts dynamically from package.json in workspace
  useEffect(() => {
    const pkgFile = files.find(f => f.name === 'package.json');
    let scripts: Record<string, string> = {
      "dev": "node --import tsx server.ts",
      "build": "vite build",
      "lint": "tsc --noEmit",
      "format": "prettier --write ."
    };

    if (pkgFile) {
      try {
        const parsed = JSON.parse(pkgFile.content);
        if (parsed.scripts) {
          scripts = parsed.scripts;
        }
      } catch (e) {
        // Safe fallback
      }
    }

    const initialTasks: TaskState[] = Object.entries(scripts).map(([name, command]) => {
      const existing = tasks.find(t => t.name === name);
      return {
        name,
        command,
        status: existing?.status || 'idle',
        stdout: existing?.stdout || '',
        stderr: existing?.stderr || '',
        exitCode: existing?.exitCode ?? null
      };
    });

    setTasks(initialTasks);
  }, [files]);

  const handleAutoInstallDeps = async () => {
    if (missingDeps.length === 0) return;
    setIsAutoInstalling(true);
    addLog('info', `AI Autonomous Package Guard: Starting installation of missing libraries: [${missingDeps.join(', ')}]...`, 'PACKAGE_GUARD');

    try {
      const depString = missingDeps.join(' ');
      addLog('info', `Running installation: npm install ${depString} --save`, 'PACKAGE_GUARD');

      const response = await fetch('/api/exec', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          command: `npm install ${depString} --save`,
          sessionId: sessionId || undefined
        })
      });

      if (!response.ok) {
        throw new Error(`Package installer returned status ${response.status}`);
      }

      const data = await response.json();
      if (data.success || data.code === 0) {
        addLog('success', `AI Autonomous Package Guard: Successfully installed [${missingDeps.join(', ')}].`, 'PACKAGE_GUARD');
        setMissingDeps([]);
      } else {
        addLog('error', `AI Autonomous Package Guard: Installation failed with exit code ${data.code}. stderr: ${data.stderr}`, 'PACKAGE_GUARD');
      }
    } catch (err: any) {
      addLog('error', `AI Autonomous Package Guard failed: ${err.message}`, 'PACKAGE_GUARD');
    } finally {
      setIsAutoInstalling(false);
    }
  };

  const runTask = async (taskName: string, command: string) => {
    if (activeTaskName) {
      addLog('warning', `Another task "${activeTaskName}" is currently running. Please wait for it to complete.`, 'TASK_RUNNER');
      return;
    }

    setActiveTaskName(taskName);
    setTasks(prev => prev.map(t => t.name === taskName ? { ...t, status: 'running', stdout: '', stderr: '', exitCode: null } : t));
    addLog('info', `Running task "${taskName}": ${command}`, 'TASK_RUNNER');

    try {
      const response = await fetch('/api/exec', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          command: command,
          sessionId: sessionId || undefined
        })
      });

      if (!response.ok) {
        throw new Error(`Server execution failed with status: ${response.status}`);
      }

      const data = await response.json();
      const success = data.success ?? (data.code === 0);

      setTasks(prev => prev.map(t => {
        if (t.name === taskName) {
          return {
            ...t,
            status: success ? 'completed' : 'failed',
            stdout: data.stdout || 'Task executed successfully with empty stdout.\n',
            stderr: data.stderr || '',
            exitCode: data.code ?? (success ? 0 : 1)
          };
        }
        return t;
      }));

      if (success) {
        addLog('success', `Task "${taskName}" completed successfully.`, 'TASK_RUNNER');
      } else {
        addLog('error', `Task "${taskName}" failed with code ${data.code}. See runner logs.`, 'TASK_RUNNER');
      }

    } catch (err: any) {
      setTasks(prev => prev.map(t => {
        if (t.name === taskName) {
          return {
            ...t,
            status: 'failed',
            stderr: err.message || 'Execution error occurred'
          };
        }
        return t;
      }));
      addLog('error', `Task "${taskName}" execution failed: ${err.message}`, 'TASK_RUNNER');
    } finally {
      setActiveTaskName(null);
    }
  };

  const clearLogs = (taskName: string) => {
    setTasks(prev => prev.map(t => t.name === taskName ? { ...t, stdout: '', stderr: '', exitCode: null, status: 'idle' } : t));
  };

  return (
    <div className="flex flex-col h-full space-y-4 text-zinc-300 font-sans text-xs">
      <div className="flex-1 overflow-y-auto space-y-4 pr-1 custom-scrollbar">
        {/* Environment & Autonomous Package Guard Card */}
        <div className="p-4 rounded-xl border border-orange-500/20 bg-orange-500/[0.02] space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles size={13} className="text-orange-400 animate-pulse" />
              <span className="text-[10px] font-black uppercase text-orange-400 tracking-wider">AI Autonomous Package Guard</span>
            </div>
            <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded-full bg-white/5 text-zinc-300 border border-white/10 uppercase">
              {detectedEnv} Environment
            </span>
          </div>

          {missingDeps.length > 0 ? (
            <div className="space-y-2 bg-black/40 border border-amber-500/20 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-amber-400 font-bold flex items-center gap-1.5">
                  <Package size={12} /> Missing Imported Libraries Detected ({missingDeps.length})
                </span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {missingDeps.map(dep => (
                  <span key={dep} className="px-2 py-0.5 rounded text-[9px] font-mono font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20">
                    {dep}
                  </span>
                ))}
              </div>
              <button
                onClick={handleAutoInstallDeps}
                disabled={isAutoInstalling}
                className="w-full mt-2 py-1.5 px-3 rounded-lg bg-orange-500 hover:bg-orange-600 disabled:opacity-50 text-black font-black text-[10px] uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-all shadow-md"
              >
                {isAutoInstalling ? (
                  <>
                    <Loader2 size={12} className="animate-spin" />
                    <span>Auto-Installing Missing Dependencies...</span>
                  </>
                ) : (
                  <>
                    <RefreshCw size={12} />
                    <span>Auto-Install Missing Libraries</span>
                  </>
                )}
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-between text-[10px] text-emerald-400/90 font-mono bg-emerald-500/5 border border-emerald-500/10 rounded-lg px-3 py-2">
              <span className="flex items-center gap-1.5">
                <CheckCircle2 size={12} /> All imported dependencies are synchronized.
              </span>
              <span className="text-[8px] text-zinc-500">Auto-Resolved</span>
            </div>
          )}
        </div>

        {/* Dynamic Scripts & Tasks */}
        {tasks.map((task) => {
          const isRunning = task.status === 'running';
          const isCompleted = task.status === 'completed';
          const isFailed = task.status === 'failed';

          return (
            <div key={task.name} className="p-4 rounded-xl border border-white/5 bg-white/[0.01] hover:bg-white/[0.02] transition-all flex flex-col space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex flex-col space-y-1">
                  <span className="font-bold text-white uppercase tracking-wider text-[11px]">{task.name}</span>
                  <span className="text-[10px] text-white/40 font-mono font-medium truncate max-w-[180px]" title={task.command}>
                    {task.command}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  {task.status !== 'idle' && (
                    <button
                      onClick={() => clearLogs(task.name)}
                      className="p-1.5 rounded-lg text-white/20 hover:text-white/60 hover:bg-white/5 transition-all outline-none"
                      title="Clear logs"
                    >
                      <Trash2 size={12} />
                    </button>
                  )}

                  <button
                    onClick={() => isRunning ? null : runTask(task.name, task.command)}
                    disabled={activeTaskName !== null && !isRunning}
                    className={`
                      p-2 rounded-lg font-bold flex items-center justify-center transition-all outline-none
                      ${isRunning 
                        ? 'bg-amber-500/10 text-amber-500 border border-amber-500/30' 
                        : 'bg-orange-500/10 text-orange-500 border border-orange-500/20 hover:bg-orange-500/20 disabled:opacity-20'}
                    `}
                    title={isRunning ? "Task is running" : "Run script"}
                  >
                    {isRunning ? <Loader2 size={13} className="animate-spin" /> : <Play size={13} fill="currentColor" />}
                  </button>
                </div>
              </div>

              {/* Status Badge */}
              <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest select-none">
                {isRunning && (
                  <span className="flex items-center gap-1.5 text-amber-400">
                    <Loader2 size={12} className="animate-spin" />
                    <span>Running</span>
                  </span>
                )}
                {isCompleted && (
                  <span className="flex items-center gap-1.5 text-emerald-400">
                    <CheckCircle2 size={12} />
                    <span>Success (Code {task.exitCode})</span>
                  </span>
                )}
                {isFailed && (
                  <span className="flex items-center gap-1.5 text-red-400">
                    <ShieldAlert size={12} />
                    <span>Failed (Code {task.exitCode ?? 1})</span>
                  </span>
                )}
                {task.status === 'idle' && (
                  <span className="text-white/20">Staged</span>
                )}
              </div>

              {/* Console Output for Task */}
              {(task.stdout || task.stderr) && (
                <div className="flex flex-col space-y-1 bg-black/60 rounded-lg border border-white/5 p-3 font-mono text-[10px] leading-relaxed relative group">
                  <div className="flex items-center justify-between text-[8px] text-white/30 font-black tracking-widest uppercase select-none border-b border-white/5 pb-1 mb-1.5">
                    <span className="flex items-center gap-1">
                      <TerminalIcon size={10} />
                      Console Output
                    </span>
                  </div>
                  {task.stdout && (
                    <pre className="whitespace-pre-wrap text-zinc-400 select-text overflow-x-auto">{task.stdout}</pre>
                  )}
                  {task.stderr && (
                    <pre className="whitespace-pre-wrap text-red-400/90 select-text overflow-x-auto">{task.stderr}</pre>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
