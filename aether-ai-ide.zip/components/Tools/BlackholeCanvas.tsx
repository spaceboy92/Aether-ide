import React, { useEffect, useRef, useState } from 'react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Sparkles, 
  Sliders, 
  Maximize2, 
  Minimize2, 
  Eye, 
  Flame, 
  Disc, 
  Orbit, 
  Grid3X3, 
  Zap, 
  Download,
  Activity,
  CircleDot
} from 'lucide-react';

interface Particle {
  x: number;
  y: number;
  radius: number;
  angle: number;
  distance: number;
  speed: number;
  color: string;
  size: number;
  alpha: number;
  temperature: number; // For Doppler shift coloring
}

interface InjectedMatter {
  id: string;
  x: number;
  y: number;
  radius: number;
  angle: number;
  distance: number;
  speed: number;
  color: string;
  mass: number;
  decayRate: number;
  trail: { x: number; y: number }[];
}

interface GravityDisruption {
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  alpha: number;
  color: string;
}

export const BlackholeCanvas: React.FC<{ isEmbedded?: boolean }> = ({ isEmbedded = false }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Simulation parameters
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [particleCount, setParticleCount] = useState<number>(1400);
  const [blackholeMass, setBlackholeMass] = useState<number>(75);
  const [rotationSpeed, setRotationSpeed] = useState<number>(1.4);
  const [colorScheme, setColorScheme] = useState<'cosmic' | 'violet' | 'supernova' | 'monochrome'>('cosmic');
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  
  // Interactive control toggles
  const [showSpacetimeGrid, setShowSpacetimeGrid] = useState<boolean>(true);
  const [dopplerEffect, setDopplerEffect] = useState<boolean>(true);
  const [mouseGravityMode, setMouseGravityMode] = useState<'pull' | 'repel' | 'none'>('pull');
  const [trailLength, setTrailLength] = useState<number>(0.2); // opacity of background fill
  const [jetIntensity, setJetIntensity] = useState<number>(0.5);

  // HUD and stats
  const [hoverInfo, setHoverInfo] = useState<string>('Singularity Core Active');
  const [totalFedStars, setTotalFedStars] = useState<number>(0);
  const [lastEvent, setLastEvent] = useState<string>('Horizon Stable');

  // Interactive interaction states
  const mouseRef = useRef<{ x: number; y: number; isDown: boolean; overCanvas: boolean }>({ x: 0, y: 0, isDown: false, overCanvas: false });
  const injectedMatterRef = useRef<InjectedMatter[]>([]);
  const disruptionsRef = useRef<GravityDisruption[]>([]);
  const animationFrameRef = useRef<number | null>(null);

  // Triggers stellar accretion flare
  const triggerAccretionFlare = () => {
    setLastEvent('Energy Burst Discharge');
    const colors = colorScheme === 'supernova' 
      ? ['#f43f5e', '#fb7185', '#f43f5e', '#ffffff'] 
      : ['#06b6d4', '#22d3ee', '#a5f3fc', '#ffffff'];
    
    disruptionsRef.current.push({
      x: 0, // Central blackhole coords relative to center
      y: 0,
      radius: blackholeMass,
      maxRadius: Math.max(800, blackholeMass * 8),
      alpha: 1.0,
      color: colors[Math.floor(Math.random() * colors.length)]
    });

    // Make particles accelerate temporarily
    setTimeout(() => {
      if (lastEvent === 'Energy Burst Discharge') {
        setLastEvent('Horizon Stable');
      }
    }, 2500);
  };

  // Triggers Relativistic Jet Peak
  const triggerGammaRayBurst = () => {
    setLastEvent('Relativistic Gamma Jet Flare');
    const oldIntensity = jetIntensity;
    setJetIntensity(1.5);
    
    // Create dual polar shockwaves
    disruptionsRef.current.push({
      x: 0,
      y: -blackholeMass * 1.5,
      radius: 10,
      maxRadius: 600,
      alpha: 0.9,
      color: '#ffffff'
    });
    disruptionsRef.current.push({
      x: 0,
      y: blackholeMass * 1.5,
      radius: 10,
      maxRadius: 600,
      alpha: 0.9,
      color: '#ffffff'
    });

    setTimeout(() => {
      setJetIntensity(oldIntensity);
      setLastEvent('Horizon Stable');
    }, 2000);
  };

  // Click to inject stellar matter
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    // Relative to blackhole core
    const relX = clickX - centerX;
    const relY = clickY - centerY;

    // Compensate for 3D accretion tilt perspective (accretion is squashed on Y-axis by 0.38)
    const correctedRelY = relY / 0.38;
    const distance = Math.sqrt(relX * relX + correctedRelY * correctedRelY);

    if (distance < blackholeMass) {
      // Clicked inside event horizon! Feed instantly.
      setTotalFedStars(prev => prev + 1);
      triggerAccretionFlare();
      return;
    }

    // Spawn orbital stellar companion
    const angle = Math.atan2(correctedRelY, relX);
    const color = colorScheme === 'supernova' 
      ? `hsl(${20 + Math.random() * 20}, 100%, 65%)` 
      : colorScheme === 'violet' 
        ? `hsl(${270 + Math.random() * 30}, 100%, 75%)` 
        : `hsl(${190 + Math.random() * 40}, 100%, 60%)`;

    injectedMatterRef.current.push({
      id: Math.random().toString(),
      x: relX,
      y: relY,
      radius: Math.random() * 6 + 4,
      angle,
      distance,
      speed: (0.003 + Math.random() * 0.004) * (280 / distance) * rotationSpeed,
      color,
      mass: Math.random() * 3 + 2,
      decayRate: 0.15 + Math.random() * 0.25,
      trail: []
    });

    setLastEvent('Stellar Capturing Active');
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resizeCanvas = () => {
      if (!canvas || !canvas.parentElement) return;
      canvas.width = canvas.parentElement.clientWidth;
      canvas.height = canvas.parentElement.clientHeight;
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Initial particles population
    const particles: Particle[] = [];
    const getParticleColor = () => {
      if (colorScheme === 'violet') {
        const colors = ['#c084fc', '#e879f9', '#818cf8', '#a855f7', '#a78bfa'];
        return colors[Math.floor(Math.random() * colors.length)];
      } else if (colorScheme === 'supernova') {
        const colors = ['#f97316', '#fbbf24', '#ef4444', '#f97316', '#fcd34d'];
        return colors[Math.floor(Math.random() * colors.length)];
      } else if (colorScheme === 'monochrome') {
        const colors = ['#ffffff', '#e4e4e7', '#a1a1aa', '#f4f4f5', '#71717a'];
        return colors[Math.floor(Math.random() * colors.length)];
      } else {
        // Cosmic
        const colors = ['#38bdf8', '#818cf8', '#34d399', '#f472b6', '#22d3ee', '#fb923c'];
        return colors[Math.floor(Math.random() * colors.length)];
      }
    };

    for (let i = 0; i < particleCount; i++) {
      const distance = Math.random() * (Math.min(canvas.width, canvas.height) * 0.48) + blackholeMass;
      particles.push({
        x: 0,
        y: 0,
        radius: Math.random() * 1.5 + 0.6,
        angle: Math.random() * Math.PI * 2,
        distance,
        speed: (0.0015 + Math.random() * 0.004) * (320 / distance),
        color: getParticleColor(),
        size: Math.random() * 2.2 + 0.8,
        alpha: Math.random() * 0.8 + 0.2,
        temperature: Math.random()
      });
    }

    let frameCount = 0;

    const render = () => {
      frameCount++;
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;

      // Apply dynamic background trail blending
      ctx.fillStyle = `rgba(3, 4, 8, ${trailLength})`;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // --- 1. SPACETIME GRID LENSING WARP MESH ---
      if (showSpacetimeGrid) {
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.06)';
        ctx.lineWidth = 1;
        
        const gridGap = 35;
        const warpCorePower = blackholeMass * 1.35;
        const warpMousePower = mouseGravityMode !== 'none' && mouseRef.current.overCanvas ? 32 : 0;

        // Render latitude horizontal mesh lines
        for (let y = gridGap; y < canvas.height; y += gridGap) {
          ctx.beginPath();
          for (let x = 0; x <= canvas.width; x += 15) {
            let dx = x - centerX;
            let dy = y - centerY;
            let distToCore = Math.sqrt(dx * dx + dy * dy);

            let warpX = x;
            let warpY = y;

            // Einstein Spacetime Distortion at blackhole core
            if (distToCore > blackholeMass * 0.6) {
              const pullFactor = (warpCorePower * warpCorePower) / (distToCore * distToCore);
              const warpAmount = Math.min(distToCore, pullFactor * 40);
              warpX -= (dx / distToCore) * warpAmount;
              warpY -= (dy / distToCore) * warpAmount;
            }

            // Mouse Gravity Warp
            if (warpMousePower > 0) {
              const mdx = x - mouseRef.current.x;
              const mdy = y - mouseRef.current.y;
              const distToMouse = Math.sqrt(mdx * mdx + mdy * mdy);
              if (distToMouse > 5) {
                const mousePull = (warpMousePower * warpMousePower) / (distToMouse);
                const warpAmountMouse = Math.min(distToMouse * 0.4, mousePull * (mouseGravityMode === 'pull' ? 1.0 : -1.2));
                warpX -= (mdx / distToMouse) * warpAmountMouse;
                warpY -= (mdy / distToMouse) * warpAmountMouse;
              }
            }

            if (x === 0) ctx.moveTo(warpX, warpY);
            else ctx.lineTo(warpX, warpY);
          }
          ctx.stroke();
        }

        // Render longitude vertical mesh lines
        for (let x = gridGap; x < canvas.width; x += gridGap) {
          ctx.beginPath();
          for (let y = 0; y <= canvas.height; y += 15) {
            let dx = x - centerX;
            let dy = y - centerY;
            let distToCore = Math.sqrt(dx * dx + dy * dy);

            let warpX = x;
            let warpY = y;

            if (distToCore > blackholeMass * 0.6) {
              const pullFactor = (warpCorePower * warpCorePower) / (distToCore * distToCore);
              const warpAmount = Math.min(distToCore, pullFactor * 40);
              warpX -= (dx / distToCore) * warpAmount;
              warpY -= (dy / distToCore) * warpAmount;
            }

            if (warpMousePower > 0) {
              const mdx = x - mouseRef.current.x;
              const mdy = y - mouseRef.current.y;
              const distToMouse = Math.sqrt(mdx * mdx + mdy * mdy);
              if (distToMouse > 5) {
                const mousePull = (warpMousePower * warpMousePower) / (distToMouse);
                const warpAmountMouse = Math.min(distToMouse * 0.4, mousePull * (mouseGravityMode === 'pull' ? 1.0 : -1.2));
                warpX -= (mdx / distToMouse) * warpAmountMouse;
                warpY -= (mdy / distToMouse) * warpAmountMouse;
              }
            }

            if (y === 0) ctx.moveTo(warpX, warpY);
            else ctx.lineTo(warpX, warpY);
          }
          ctx.stroke();
        }
      }

      // --- 2. ACCRETION GLOW BACKGROUND ---
      const glowGrad = ctx.createRadialGradient(
        centerX, centerY, blackholeMass * 0.15,
        centerX, centerY, blackholeMass * 4.0
      );

      if (colorScheme === 'violet') {
        glowGrad.addColorStop(0, 'rgba(147, 51, 234, 0.95)');
        glowGrad.addColorStop(0.2, 'rgba(124, 58, 237, 0.4)');
        glowGrad.addColorStop(0.5, 'rgba(192, 132, 252, 0.15)');
        glowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      } else if (colorScheme === 'supernova') {
        glowGrad.addColorStop(0, 'rgba(239, 68, 68, 0.95)');
        glowGrad.addColorStop(0.25, 'rgba(249, 115, 22, 0.4)');
        glowGrad.addColorStop(0.6, 'rgba(251, 191, 36, 0.14)');
        glowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      } else if (colorScheme === 'monochrome') {
        glowGrad.addColorStop(0, 'rgba(244, 244, 245, 0.8)');
        glowGrad.addColorStop(0.3, 'rgba(161, 161, 170, 0.25)');
        glowGrad.addColorStop(0.8, 'rgba(63, 63, 70, 0.08)');
        glowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      } else {
        // Cosmic
        glowGrad.addColorStop(0, 'rgba(6, 182, 212, 0.95)');
        glowGrad.addColorStop(0.2, 'rgba(139, 92, 246, 0.45)');
        glowGrad.addColorStop(0.55, 'rgba(167, 139, 250, 0.12)');
        glowGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      }

      ctx.fillStyle = glowGrad;
      ctx.beginPath();
      ctx.arc(centerX, centerY, blackholeMass * 4.0, 0, Math.PI * 2);
      ctx.fill();

      // --- 3. RELATIVISTIC POLAR JETS (Pulsating)
      const pulseScalar = Math.sin(frameCount * 0.05) * 0.15 + 1.0;
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(frameCount * 0.003 * rotationSpeed);
      
      const jetGrad = ctx.createLinearGradient(0, -canvas.height / 2, 0, canvas.height / 2);
      if (colorScheme === 'supernova') {
        jetGrad.addColorStop(0, 'rgba(255, 255, 255, 0.9)');
        jetGrad.addColorStop(0.3, `rgba(239, 68, 68, ${0.45 * jetIntensity})`);
        jetGrad.addColorStop(0.5, 'rgba(255, 255, 255, 0)');
        jetGrad.addColorStop(0.7, `rgba(249, 115, 22, ${0.45 * jetIntensity})`);
        jetGrad.addColorStop(1, 'rgba(255, 255, 255, 0.9)');
      } else if (colorScheme === 'violet') {
        jetGrad.addColorStop(0, 'rgba(255, 255, 255, 0.9)');
        jetGrad.addColorStop(0.35, `rgba(168, 85, 247, ${0.5 * jetIntensity})`);
        jetGrad.addColorStop(0.5, 'rgba(255, 255, 255, 0)');
        jetGrad.addColorStop(0.65, `rgba(139, 92, 246, ${0.5 * jetIntensity})`);
        jetGrad.addColorStop(1, 'rgba(255, 255, 255, 0.9)');
      } else {
        // Cosmic
        jetGrad.addColorStop(0, 'rgba(255, 255, 255, 0.9)');
        jetGrad.addColorStop(0.3, `rgba(6, 182, 212, ${0.45 * jetIntensity})`);
        jetGrad.addColorStop(0.5, 'rgba(255, 255, 255, 0)');
        jetGrad.addColorStop(0.7, `rgba(99, 102, 241, ${0.45 * jetIntensity})`);
        jetGrad.addColorStop(1, 'rgba(255, 255, 255, 0.9)');
      }

      ctx.fillStyle = jetGrad;
      const jetWidth = (3.5 + Math.sin(frameCount * 0.08) * 1.5) * pulseScalar * jetIntensity;
      ctx.fillRect(-jetWidth / 2, -canvas.height / 2, jetWidth, canvas.height);
      ctx.restore();

      // --- 4. EXPANDING GRAVITY DISRUPTIONS / NOVAE SHOCKWAVES ---
      disruptionsRef.current.forEach((d, index) => {
        d.radius += 8;
        d.alpha -= 0.012;

        if (d.alpha <= 0) {
          disruptionsRef.current.splice(index, 1);
          return;
        }

        ctx.strokeStyle = d.color;
        ctx.lineWidth = 4 * d.alpha;
        ctx.globalAlpha = d.alpha;
        ctx.shadowBlur = 25 * d.alpha;
        ctx.shadowColor = d.color;
        
        ctx.beginPath();
        ctx.arc(centerX + d.x, centerY + d.y, d.radius, 0, Math.PI * 2);
        ctx.stroke();

        ctx.shadowBlur = 0;
        ctx.globalAlpha = 1.0;
      });

      // --- 5. INTERACTIVE MOUSE GRAVITY WELL ---
      if (mouseGravityMode !== 'none' && mouseRef.current.overCanvas) {
        ctx.beginPath();
        ctx.arc(mouseRef.current.x, mouseRef.current.y, mouseRef.current.isDown ? 14 : 7, 0, Math.PI * 2);
        ctx.fillStyle = mouseGravityMode === 'pull' 
          ? 'rgba(34, 211, 238, 0.35)' 
          : 'rgba(239, 68, 68, 0.35)';
        ctx.fill();

        ctx.strokeStyle = mouseGravityMode === 'pull' ? '#22d3ee' : '#ef4444';
        ctx.lineWidth = 1;
        ctx.stroke();

        // Pulsating gravity ring
        ctx.beginPath();
        ctx.arc(mouseRef.current.x, mouseRef.current.y, (12 + (frameCount % 24)) * 1.2, 0, Math.PI * 2);
        ctx.strokeStyle = mouseGravityMode === 'pull' ? 'rgba(34, 211, 238, 0.15)' : 'rgba(239, 68, 68, 0.15)';
        ctx.stroke();
      }

      // --- 6. ACCRETION DISK PARTICLES PHYSICS & DOPPLER ---
      particles.forEach((p) => {
        // Adjust orbital dynamics
        let orbitalSpeedFactor = 320 / p.distance;
        p.angle += p.speed * rotationSpeed * orbitalSpeedFactor;
        
        // Gravity pull toward Event Horizon
        p.distance -= 0.065 * (blackholeMass / p.distance);

        // Apply Mouse Gravity field
        if (mouseGravityMode !== 'none' && mouseRef.current.overCanvas) {
          // Relate to relative canvas coords
          const px = centerX + Math.cos(p.angle) * p.distance;
          const py = centerY + Math.sin(p.angle) * (p.distance * 0.38);

          const mdx = mouseRef.current.x - px;
          const mdy = mouseRef.current.y - py;
          const mDist = Math.sqrt(mdx * mdx + mdy * mdy);

          if (mDist < 160 && mDist > 5) {
            const force = (mouseGravityMode === 'pull' ? 1.0 : -1.8) * (80 / mDist);
            const moveX = (mdx / mDist) * force;
            const moveY = (mdy / mDist) * force;

            // Recalculate particle angular parameters based on displacement
            const newPx = px + moveX;
            const newPy = (py + moveY - centerY) / 0.38;
            p.distance = Math.sqrt(newPx * newPx + newPy * newPy);
            p.angle = Math.atan2(newPy, newPx);
          }
        }

        // Respawn particle if it crosses Event Horizon
        if (p.distance <= blackholeMass * 0.65) {
          p.distance = Math.min(canvas.width, canvas.height) * (0.35 + Math.random() * 0.16);
          p.angle = Math.random() * Math.PI * 2;
          p.alpha = Math.random() * 0.8 + 0.2;
        }

        // 3D perspective mapping (Elliptical Squashed Ring)
        const px = centerX + Math.cos(p.angle) * p.distance;
        const py = centerY + Math.sin(p.angle) * (p.distance * 0.38);

        // Relativistic Doppler Beaming Effect
        // Approaching matter shines brighter & blueshifted, receding matter is dimmer & redshifted
        const isApproaching = Math.sin(p.angle) > 0;
        const speedRatio = (blackholeMass / p.distance) * rotationSpeed;
        
        let sizeMultiplier = 1.0;
        let brightness = p.alpha;
        let finalColor = p.color;

        if (dopplerEffect) {
          // Approach (left/front depending on rotation angle/speed)
          if (isApproaching) {
            sizeMultiplier = 1.5 + (speedRatio * 0.8);
            brightness = Math.min(1.0, p.alpha * (1.6 + speedRatio * 1.5));
            // Shift color toward cyan/white
            if (colorScheme === 'cosmic') finalColor = '#ffffff';
            else if (colorScheme === 'supernova') finalColor = '#fef08a';
            else if (colorScheme === 'violet') finalColor = '#e879f9';
          } else {
            sizeMultiplier = Math.max(0.4, 0.85 - (speedRatio * 0.2));
            brightness = Math.max(0.1, p.alpha * (0.55 - speedRatio * 0.3));
          }
        }

        ctx.beginPath();
        ctx.arc(px, py, p.size * sizeMultiplier, 0, Math.PI * 2);
        ctx.fillStyle = finalColor;
        ctx.globalAlpha = brightness;
        
        if (isApproaching && speedRatio > 0.4) {
          ctx.shadowBlur = 14;
          ctx.shadowColor = finalColor;
        }
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.globalAlpha = 1.0;
      });

      // --- 7. DETAILED STELLAR Companion Matter SPIRAL SPIRITS ---
      injectedMatterRef.current.forEach((sm, index) => {
        // Orbit update with heavy friction/decay
        const orbitalDecay = sm.distance * 0.0035;
        sm.distance -= (0.45 * (blackholeMass / sm.distance)) + orbitalDecay;
        sm.angle += sm.speed * (300 / sm.distance);

        const smX = centerX + Math.cos(sm.angle) * sm.distance;
        const smY = centerY + Math.sin(sm.angle) * (sm.distance * 0.38);

        // Record high fidelity decay trail
        sm.trail.push({ x: smX, y: smY });
        if (sm.trail.length > 25) sm.trail.shift();

        // Render stellar tail ribbon
        if (sm.trail.length > 1) {
          ctx.beginPath();
          ctx.moveTo(sm.trail[0].x, sm.trail[0].y);
          for (let ti = 1; ti < sm.trail.length; ti++) {
            ctx.lineTo(sm.trail[ti].x, sm.trail[ti].y);
          }
          ctx.strokeStyle = sm.color;
          ctx.lineWidth = sm.radius * 0.45;
          ctx.lineCap = 'round';
          ctx.globalAlpha = 0.35;
          ctx.stroke();
          ctx.globalAlpha = 1.0;
        }

        // Render main star matter body
        ctx.beginPath();
        ctx.arc(smX, smY, sm.radius, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.shadowBlur = 28;
        ctx.shadowColor = sm.color;
        ctx.fill();
        
        // Star coronal atmosphere envelope
        ctx.beginPath();
        ctx.arc(smX, smY, sm.radius * 1.5, 0, Math.PI * 2);
        ctx.fillStyle = sm.color;
        ctx.globalAlpha = 0.45;
        ctx.fill();

        ctx.shadowBlur = 0;
        ctx.globalAlpha = 1.0;

        // Stellar ingestion check (Collides with event horizon)
        if (sm.distance <= blackholeMass * 0.72) {
          setTotalFedStars(prev => prev + 1);
          triggerAccretionFlare();
          injectedMatterRef.current.splice(index, 1);
        }
      });

      // --- 8. PHOTON RING & DEEP BLACK HOLE CORE ---
      // Bending light creates a prominent, crisp white photon ring exactly on the event horizon boundary
      ctx.beginPath();
      ctx.arc(centerX, centerY, blackholeMass + 2, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.95)';
      ctx.lineWidth = 3.5;
      ctx.shadowBlur = 24;
      ctx.shadowColor = '#ffffff';
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Outer corona boundary accretion edge
      ctx.beginPath();
      ctx.arc(centerX, centerY, blackholeMass + 4.5, 0, Math.PI * 2);
      ctx.strokeStyle = colorScheme === 'supernova' ? '#ea580c' : colorScheme === 'violet' ? '#7c3aed' : '#0891b2';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Deep, absolute Singularity Void (No light escapes)
      ctx.beginPath();
      ctx.arc(centerX, centerY, blackholeMass, 0, Math.PI * 2);
      ctx.fillStyle = '#010103';
      ctx.fill();

      // Core details to enhance visual quality (simulated gravitational lensing distortion ripples)
      ctx.beginPath();
      ctx.arc(centerX, centerY, blackholeMass * 0.4, 0, Math.PI * 2);
      ctx.fillStyle = '#000000';
      ctx.fill();

      if (isPlaying) {
        animationFrameRef.current = requestAnimationFrame(render);
      }
    };

    render();

    return () => {
      window.removeEventListener('resize', resizeCanvas);
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
    };
  }, [isPlaying, particleCount, blackholeMass, rotationSpeed, colorScheme, showSpacetimeGrid, dopplerEffect, mouseGravityMode, trailLength, jetIntensity]);

  // Track cursor coordinates relative to canvas
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    mouseRef.current.x = e.clientX - rect.left;
    mouseRef.current.y = e.clientY - rect.top;
    mouseRef.current.overCanvas = true;

    // Update real-time HUD message based on mouse coordinates
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;
    const dx = mouseRef.current.x - centerX;
    const dy = (mouseRef.current.y - centerY) / 0.38;
    const dist = Math.sqrt(dx * dx + dy * dy);

    if (dist < blackholeMass) {
      setHoverInfo('Singularity Core - Tidal forces infinite');
    } else if (dist < blackholeMass * 2.0) {
      setHoverInfo('Innermost Stable Circular Orbit (ISCO)');
    } else if (dist < blackholeMass * 4.0) {
      setHoverInfo('Lensing Accretion Disk');
    } else {
      setHoverInfo('Safe Orbital Field / Spacetime flat');
    }
  };

  const handleMouseEnter = () => {
    mouseRef.current.overCanvas = true;
  };

  const handleMouseLeave = () => {
    mouseRef.current.overCanvas = false;
    mouseRef.current.isDown = false;
    setHoverInfo('Singularity Core Active');
  };

  const handleMouseDown = () => {
    mouseRef.current.isDown = true;
  };

  const handleMouseUp = () => {
    mouseRef.current.isDown = false;
  };

  return (
    <div 
      ref={containerRef}
      className={`relative flex flex-col h-full w-full bg-[#030408] rounded-2xl overflow-hidden border border-white/10 shadow-2xl select-none ${
        isFullscreen ? 'fixed inset-0 z-[300] rounded-none' : ''
      }`}
      id="blackhole-simulation-root"
    >
      {/* Simulation Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between px-5 py-4 bg-[#07090e] border-b border-white/10 z-10 gap-3">
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-9 h-9 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
            <Orbit size={20} className="animate-spin-slow" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-white text-sm tracking-wide">Relativistic Singularity Playground</span>
              <span className="px-2 py-0.5 text-[9px] font-semibold font-mono bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 rounded-full uppercase">
                General Relativity V2
              </span>
            </div>
            <p className="text-xs text-zinc-400">Interactive accretion physics, Doppler shift, and dynamic spacetime lensing</p>
          </div>
        </div>

        {/* Global Controls */}
        <div className="flex items-center gap-2 self-stretch sm:self-auto justify-end">
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              isPlaying 
                ? 'bg-zinc-800 hover:bg-zinc-700 text-zinc-200' 
                : 'bg-cyan-600/90 hover:bg-cyan-500 text-white shadow-lg shadow-cyan-950/40'
            }`}
            id="toggle-physics-btn"
          >
            {isPlaying ? <Pause size={13} /> : <Play size={13} fill="currentColor" />}
            <span>{isPlaying ? 'Freeze' : 'Resume'}</span>
          </button>

          <button
            onClick={triggerGammaRayBurst}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-lg text-xs transition-all"
            title="Relativistic Polar Discharges"
            id="grb-trigger-btn"
          >
            <Zap size={13} />
            <span>Relativistic Jet</span>
          </button>

          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-zinc-300 hover:text-white transition-colors"
            title={isFullscreen ? 'Exit Fullscreen' : 'Toggle Fullscreen view'}
            id="fullscreen-toggle-btn"
          >
            {isFullscreen ? <Minimize2 size={15} /> : <Maximize2 size={15} />}
          </button>
        </div>
      </div>

      {/* Main Canvas + Control Grid */}
      <div className="relative flex-1 flex flex-col lg:flex-row w-full min-h-[450px] overflow-hidden bg-[#020204]">
        
        {/* Live Canvas */}
        <div className="relative flex-1 h-full min-h-[350px] cursor-crosshair overflow-hidden">
          <canvas 
            ref={canvasRef} 
            onClick={handleCanvasClick}
            onMouseMove={handleMouseMove}
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
            onMouseDown={handleMouseDown}
            onMouseUp={handleMouseUp}
            className="w-full h-full block" 
            id="blackhole-canvas-render"
          />

          {/* Interactive Mouse Guide Banner */}
          <div className="absolute top-4 left-4 right-4 pointer-events-none flex justify-between items-center bg-black/40 backdrop-blur-sm px-3.5 py-2 rounded-xl border border-white/5 text-[11px] text-zinc-400">
            <span className="flex items-center gap-1.5">
              <CircleDot size={11} className="text-cyan-400 animate-pulse" />
              <span>Click on space to **inject stellar matter** into decay orbits</span>
            </span>
            <span className="hidden sm:inline">Drag to warp the Spacetime mesh</span>
          </div>

          {/* Real-time Gravitational Telemetry (Left corner overlay) */}
          <div className="absolute bottom-4 left-4 p-4 bg-black/80 backdrop-blur-lg border border-white/10 rounded-2xl text-[11px] space-y-2 font-mono text-zinc-300 pointer-events-none w-56 shadow-xl">
            <div className="flex items-center gap-2 text-cyan-400 font-bold border-b border-white/5 pb-1.5">
              <Activity size={13} className="animate-pulse" />
              <span>TELEMETRY METRICS</span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-500">Mass Index:</span> 
              <span className="text-white font-semibold">{blackholeMass} M☉</span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-500">Active Dust:</span> 
              <span className="text-zinc-300">{particleCount} paths</span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-500">Orbital Speed:</span> 
              <span className="text-emerald-400">{(rotationSpeed * 0.94).toFixed(2)}c</span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-500">Companion stars:</span> 
              <span className="text-yellow-400">{injectedMatterRef.current.length} alive</span>
            </div>
            <div className="flex justify-between">
              <span className="text-zinc-500">Matter Fed:</span> 
              <span className="text-pink-400">{totalFedStars} stars</span>
            </div>
            <div className="pt-1.5 border-t border-white/5 text-[10px] text-zinc-400 flex items-center justify-between">
              <span>Horizon State:</span>
              <span className={`px-1.5 py-0.5 rounded ${
                lastEvent === 'Horizon Stable' 
                  ? 'bg-emerald-950 text-emerald-300' 
                  : lastEvent.includes('Discharge') 
                    ? 'bg-red-950 text-red-300' 
                    : 'bg-indigo-950 text-indigo-300'
              }`}>{lastEvent}</span>
            </div>
          </div>

          {/* Interactive Core Distance Hover Info bar */}
          <div className="absolute bottom-4 right-4 bg-black/80 backdrop-blur-md px-3.5 py-2 border border-white/10 rounded-xl text-[11px] text-zinc-300 font-mono flex items-center gap-2 shadow-lg">
            <Eye size={12} className="text-cyan-400" />
            <span>{hoverInfo}</span>
          </div>
        </div>

        {/* High Tech Physics Tuning Control Sidebar */}
        <div className="w-full lg:w-72 bg-[#07090e] border-t lg:border-t-0 lg:border-l border-white/10 p-5 flex flex-col justify-between text-xs text-zinc-300 overflow-y-auto space-y-6">
          <div className="space-y-5">
            <div className="flex items-center gap-2 text-cyan-400 font-bold border-b border-white/10 pb-2">
              <Sliders size={14} />
              <span>Spacetime Parameters</span>
            </div>

            {/* Mass control */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-[11px]">
                <span className="text-zinc-400">Event Horizon (Mass)</span>
                <span className="font-mono text-cyan-300 font-bold">{blackholeMass} M☉</span>
              </div>
              <input
                type="range"
                min="25"
                max="130"
                value={blackholeMass}
                onChange={(e) => setBlackholeMass(Number(e.target.value))}
                className="w-full accent-cyan-400 bg-zinc-800 rounded-lg appearance-none h-1.5 cursor-pointer"
                id="mass-slider"
              />
            </div>

            {/* Rotation speed */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-[11px]">
                <span className="text-zinc-400">Accretion Disk Spin</span>
                <span className="font-mono text-cyan-300 font-bold">{rotationSpeed.toFixed(1)}x</span>
              </div>
              <input
                type="range"
                min="0.2"
                max="4.0"
                step="0.1"
                value={rotationSpeed}
                onChange={(e) => setRotationSpeed(Number(e.target.value))}
                className="w-full accent-cyan-400 bg-zinc-800 rounded-lg appearance-none h-1.5 cursor-pointer"
                id="spin-slider"
              />
            </div>

            {/* Particle Density */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-[11px]">
                <span className="text-zinc-400">Particle Density (Dust)</span>
                <span className="font-mono text-cyan-300 font-bold">{particleCount} paths</span>
              </div>
              <input
                type="range"
                min="200"
                max="2800"
                step="100"
                value={particleCount}
                onChange={(e) => setParticleCount(Number(e.target.value))}
                className="w-full accent-cyan-400 bg-zinc-800 rounded-lg appearance-none h-1.5 cursor-pointer"
                id="density-slider"
              />
            </div>

            {/* Mouse Mode selector */}
            <div className="space-y-1.5">
              <label className="text-zinc-400 block mb-1">Mouse Spacetime Gravity Field</label>
              <div className="grid grid-cols-3 gap-1">
                {[
                  { id: 'pull', label: 'Pull Core', desc: 'Attracts matter' },
                  { id: 'repel', label: 'Repeller', desc: 'Hawking push' },
                  { id: 'none', label: 'Disabled', desc: 'Flat spacetime' }
                ].map((mode) => (
                  <button
                    key={mode.id}
                    onClick={() => setMouseGravityMode(mode.id as any)}
                    className={`py-1.5 text-[10px] rounded-lg font-medium border transition-all ${
                      mouseGravityMode === mode.id 
                        ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300' 
                        : 'bg-white/5 border-white/10 text-zinc-400 hover:text-white'
                    }`}
                    title={mode.desc}
                    id={`gravity-mode-${mode.id}`}
                  >
                    {mode.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Interactive features checkboxes */}
            <div className="space-y-3.5 pt-2 border-t border-white/5">
              {/* Spacetime Grid */}
              <label className="flex items-center gap-2 cursor-pointer group" id="grid-checkbox-container">
                <input
                  type="checkbox"
                  checked={showSpacetimeGrid}
                  onChange={(e) => setShowSpacetimeGrid(e.target.checked)}
                  className="rounded bg-zinc-800 border-white/10 text-cyan-500 focus:ring-0 cursor-pointer"
                  id="show-grid-checkbox"
                />
                <span className="text-zinc-400 group-hover:text-zinc-200 transition-colors">Show Spacetime Mesh Grid</span>
              </label>

              {/* Doppler shift */}
              <label className="flex items-center gap-2 cursor-pointer group" id="doppler-checkbox-container">
                <input
                  type="checkbox"
                  checked={dopplerEffect}
                  onChange={(e) => setDopplerEffect(e.target.checked)}
                  className="rounded bg-zinc-800 border-white/10 text-cyan-500 focus:ring-0 cursor-pointer"
                  id="doppler-checkbox"
                />
                <span className="text-zinc-400 group-hover:text-zinc-200 transition-colors">Relativistic Doppler Beaming</span>
              </label>

              {/* Jet Intensity Slider */}
              <div className="space-y-1 pt-1">
                <div className="flex justify-between text-[10px] text-zinc-400">
                  <span>Polar Jet Glow</span>
                  <span>{jetIntensity.toFixed(1)}x</span>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="2.0"
                  step="0.1"
                  value={jetIntensity}
                  onChange={(e) => setJetIntensity(Number(e.target.value))}
                  className="w-full accent-cyan-400 bg-zinc-800 rounded-lg appearance-none h-1 cursor-pointer"
                  id="jet-intensity-slider"
                />
              </div>

              {/* Motion Blur (Trails) */}
              <div className="space-y-1">
                <div className="flex justify-between text-[10px] text-zinc-400">
                  <span>Particle Trails length</span>
                  <span>{((1.0 - trailLength) * 100).toFixed(0)}%</span>
                </div>
                <input
                  type="range"
                  min="0.05"
                  max="0.8"
                  step="0.05"
                  value={trailLength}
                  onChange={(e) => setTrailLength(Number(e.target.value))}
                  className="w-full accent-cyan-400 bg-zinc-800 rounded-lg appearance-none h-1 cursor-pointer animate-none"
                  id="trail-length-slider"
                />
              </div>
            </div>
          </div>

          <div className="space-y-4 pt-4 border-t border-white/10">
            {/* Color spectrum */}
            <div className="space-y-1.5">
              <label className="text-zinc-400 block mb-1">Accretion Disk Palette</label>
              <div className="grid grid-cols-2 gap-1.5">
                {[
                  { id: 'cosmic', label: 'Cosmic Blue' },
                  { id: 'violet', label: 'Violet Ray' },
                  { id: 'supernova', label: 'Supernova' },
                  { id: 'monochrome', label: 'Einstein Mono' }
                ].map((scheme) => (
                  <button
                    key={scheme.id}
                    onClick={() => setColorScheme(scheme.id as any)}
                    className={`py-1.5 text-[10px] rounded font-medium border transition-all ${
                      colorScheme === scheme.id 
                        ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300' 
                        : 'bg-white/5 border-white/10 text-zinc-400 hover:text-white'
                    }`}
                    id={`color-scheme-${scheme.id}`}
                  >
                    {scheme.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Quick Nova flare trigger */}
            <button
              onClick={triggerAccretionFlare}
              className="w-full flex items-center justify-center gap-2 py-2.5 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white font-bold rounded-xl shadow-lg shadow-red-950/40 transition-all text-xs"
              id="nova-burst-btn"
            >
              <Flame size={13} className="animate-pulse" />
              <span>Trigger Accretion Flare</span>
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};

export default BlackholeCanvas;
