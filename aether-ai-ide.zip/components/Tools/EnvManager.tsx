import React, { useState, useEffect } from 'react';
import { X, Sliders, Eye, EyeOff, Plus, Trash2, Download, Upload, Save, Check, FileCode, AlertCircle } from 'lucide-react';
import { FileNode } from '../../types';

interface EnvManagerProps {
  files: FileNode[];
  onSaveFiles?: (files: FileNode[]) => void;
  onClose: () => void;
}

interface EnvVar {
  key: string;
  value: string;
}

export const EnvManager: React.FC<EnvManagerProps> = ({ files, onSaveFiles, onClose }) => {
  const [vars, setVars] = useState<EnvVar[]>([]);
  const [maskSecrets, setMaskSecrets] = useState<boolean>(true);
  const [newKey, setNewKey] = useState('');
  const [newValue, setNewValue] = useState('');
  const [isSaved, setIsSaved] = useState(false);
  const [filterQuery, setFilterQuery] = useState('');

  // Find existing .env file in workspace
  const envFile = files.find((f) => f.name === '.env' || f.name === '.env.local');

  useEffect(() => {
    if (envFile && envFile.content) {
      const lines = envFile.content.split('\n');
      const parsed: EnvVar[] = [];
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#')) continue;
        const eqIdx = trimmed.indexOf('=');
        if (eqIdx !== -1) {
          const k = trimmed.slice(0, eqIdx).trim();
          let v = trimmed.slice(eqIdx + 1).trim();
          if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
            v = v.slice(1, -1);
          }
          parsed.push({ key: k, value: v });
        }
      }
      setVars(parsed);
    } else {
      // Default initial environment template
      setVars([
        { key: 'PORT', value: '3000' },
        { key: 'NODE_ENV', value: 'development' },
        { key: 'GEMINI_API_KEY', value: 'AIzaSy_demo_key_sample' },
        { key: 'DATABASE_URL', value: 'postgresql://admin:secret@localhost:5432/aether_db' },
      ]);
    }
  }, [envFile]);

  const handleAddVar = () => {
    if (!newKey.trim()) return;
    const cleanKey = newKey.trim().toUpperCase().replace(/[^A-Z0-9_]/g, '_');
    if (vars.some((v) => v.key === cleanKey)) {
      alert(`Key "${cleanKey}" already exists.`);
      return;
    }
    setVars([...vars, { key: cleanKey, value: newValue }]);
    setNewKey('');
    setNewValue('');
  };

  const handleUpdateVar = (index: number, value: string) => {
    const updated = [...vars];
    updated[index].value = value;
    setVars(updated);
  };

  const handleDeleteVar = (keyToDelete: string) => {
    setVars(vars.filter((v) => v.key !== keyToDelete));
  };

  const handleSaveToWorkspace = () => {
    const envString = vars.map((v) => `${v.key}=${v.value}`).join('\n');
    let updatedFiles = [...files];
    const existingIdx = updatedFiles.findIndex((f) => f.name === '.env' || f.name === '.env.local');

    if (existingIdx !== -1) {
      updatedFiles[existingIdx] = { ...updatedFiles[existingIdx], content: envString };
    } else {
      updatedFiles.push({
        id: `f_env_${Date.now()}`,
        name: '.env',
        content: envString,
        language: 'env',
        lastModified: Date.now()
      });
    }

    if (onSaveFiles) {
      onSaveFiles(updatedFiles);
    }
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  const handleExportEnv = () => {
    const content = vars.map((v) => `${v.key}=${v.value}`).join('\n');
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = '.env';
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredVars = vars.filter((v) =>
    v.key.toLowerCase().includes(filterQuery.toLowerCase()) ||
    v.value.toLowerCase().includes(filterQuery.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 backdrop-blur-md p-4 animate-in fade-in zoom-in-95">
      <div className="w-full max-w-3xl bg-zinc-950 border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between bg-zinc-900/50">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
              <Sliders size={20} />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                Environment Variable Manager
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-semibold border border-cyan-500/30">
                  Workspace .env
                </span>
              </h2>
              <p className="text-xs text-zinc-400">Manage secrets, credentials, and feature flags synced with workspace .env</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-zinc-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Toolbar */}
        <div className="px-6 py-3 border-b border-white/5 bg-zinc-900/30 flex flex-wrap items-center justify-between gap-3">
          <input
            type="text"
            placeholder="Filter environment variables..."
            value={filterQuery}
            onChange={(e) => setFilterQuery(e.target.value)}
            className="px-3 py-1.5 bg-zinc-900 border border-white/10 rounded-lg text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-500/50 w-64"
          />

          <div className="flex items-center gap-2">
            <button
              onClick={() => setMaskSecrets(!maskSecrets)}
              className="px-3 py-1.5 rounded-lg bg-zinc-900 border border-white/10 hover:bg-white/10 text-zinc-300 text-xs font-mono flex items-center gap-2 transition-colors cursor-pointer"
              title={maskSecrets ? "Reveal Secret Values" : "Mask Secret Values"}
            >
              {maskSecrets ? <EyeOff size={14} className="text-orange-400" /> : <Eye size={14} className="text-green-400" />}
              <span>{maskSecrets ? "Masked" : "Revealed"}</span>
            </button>

            <button
              onClick={handleExportEnv}
              className="px-3 py-1.5 rounded-lg bg-zinc-900 border border-white/10 hover:bg-white/10 text-zinc-300 text-xs font-mono flex items-center gap-2 transition-colors cursor-pointer"
            >
              <Download size={14} />
              <span>Export .env</span>
            </button>

            <button
              onClick={handleSaveToWorkspace}
              className="px-4 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-200 text-xs font-bold font-mono flex items-center gap-2 transition-all cursor-pointer"
            >
              {isSaved ? <Check size={14} className="text-green-400" /> : <Save size={14} />}
              <span>{isSaved ? "Saved to Workspace!" : "Save to Workspace"}</span>
            </button>
          </div>
        </div>

        {/* List Content */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1 text-sm">
          {/* Add New Key */}
          <div className="p-4 rounded-xl bg-zinc-900/60 border border-white/5 space-y-3">
            <span className="text-xs font-bold text-zinc-300 uppercase tracking-wider font-mono">
              Add Environment Variable
            </span>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                placeholder="VARIABLE_KEY"
                value={newKey}
                onChange={(e) => setNewKey(e.target.value)}
                className="flex-1 px-3 py-2 bg-black/60 border border-white/10 rounded-lg text-xs font-mono text-cyan-300 placeholder-zinc-600 focus:outline-none focus:border-cyan-500/50 uppercase"
              />
              <input
                type="text"
                placeholder="value"
                value={newValue}
                onChange={(e) => setNewValue(e.target.value)}
                className="flex-1 px-3 py-2 bg-black/60 border border-white/10 rounded-lg text-xs font-mono text-white placeholder-zinc-600 focus:outline-none focus:border-cyan-500/50"
              />
              <button
                onClick={handleAddVar}
                className="px-4 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0"
              >
                <Plus size={16} />
                <span>Add Key</span>
              </button>
            </div>
          </div>

          {/* Table */}
          <div className="space-y-2">
            {filteredVars.map((v, idx) => (
              <div
                key={v.key}
                className="p-3 rounded-xl bg-zinc-900/40 border border-white/5 hover:border-white/10 transition-colors flex items-center justify-between gap-3"
              >
                <div className="font-mono text-xs font-bold text-cyan-400 w-1/3 truncate" title={v.key}>
                  {v.key}
                </div>
                <input
                  type={maskSecrets ? "password" : "text"}
                  value={v.value}
                  onChange={(e) => handleUpdateVar(idx, e.target.value)}
                  className="flex-1 px-3 py-1.5 bg-black/40 border border-white/5 rounded-lg text-xs font-mono text-zinc-200 focus:outline-none focus:border-cyan-500/30"
                />
                <button
                  onClick={() => handleDeleteVar(v.key)}
                  className="p-1.5 rounded-lg text-zinc-500 hover:text-red-400 hover:bg-red-500/10 transition-colors cursor-pointer"
                  title="Delete Key"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            ))}

            {filteredVars.length === 0 && (
              <div className="text-center py-8 text-zinc-500 text-xs font-mono">
                No environment variables match query.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EnvManager;
