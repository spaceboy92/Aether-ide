import React, { useState } from 'react';
import { 
  Code2, 
  Wand2, 
  Copy, 
  Check, 
  RefreshCw, 
  Sparkles, 
  FileText, 
  Search, 
  SlidersHorizontal,
  Zap,
  ArrowRight
} from 'lucide-react';

export const DataTransformerStudio: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'regex' | 'converter'>('regex');

  // RegEx Tester State
  const [pattern, setPattern] = useState<string>('([a-zA-Z0-9._%+-]+)@([a-zA-Z0-9.-]+\\.[a-zA-Z]{2,})');
  const [flags, setFlags] = useState<{ g: boolean; i: boolean; m: boolean }>({ g: true, i: true, m: false });
  const [testText, setTestText] = useState<string>(
    'Contact support at dev.team@aether.ai or admin@google.com for assistance.'
  );

  // Data Converter State
  const [sourceFormat, setSourceFormat] = useState<'json' | 'csv' | 'queryString'>('json');
  const [targetFormat, setTargetFormat] = useState<'typescript' | 'csv' | 'yaml' | 'json'>('typescript');
  const [sourceData, setSourceData] = useState<string>(
    '{\n  "id": "usr_99",\n  "username": "aether_master",\n  "role": "admin",\n  "active": true,\n  "coins": 2500\n}'
  );
  const [convertedData, setConvertedData] = useState<string>('');
  const [copied, setCopied] = useState(false);

  // Common RegEx Presets
  const presets = [
    { label: 'Email Address', pattern: '[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}' },
    { label: 'URL / Web Link', pattern: 'https?:\\/\\/(www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{1,256}\\.[a-zA-Z0-9()]{1,6}\\b([-a-zA-Z0-9()@:%_\\+.~#?&//=]*)' },
    { label: 'IPv4 Address', pattern: '\\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\b' },
    { label: 'HEX Color Code', pattern: '^#?([a-fA-F0-9]{6}|[a-fA-F0-9]{3})$' }
  ];

  // RegEx Execution
  const getMatches = () => {
    if (!pattern.trim()) return [];
    try {
      const flagStr = (flags.g ? 'g' : '') + (flags.i ? 'i' : '') + (flags.m ? 'm' : '');
      const regex = new RegExp(pattern, flagStr);
      const matches: { match: string; index: number; groups: string[] }[] = [];
      let m: RegExpExecArray | null;

      if (flags.g) {
        while ((m = regex.exec(testText)) !== null) {
          if (m.index === regex.lastIndex) regex.lastIndex++;
          matches.push({
            match: m[0],
            index: m.index,
            groups: m.slice(1)
          });
        }
      } else {
        m = regex.exec(testText);
        if (m) {
          matches.push({
            match: m[0],
            index: m.index,
            groups: m.slice(1)
          });
        }
      }
      return matches;
    } catch (e) {
      return null; // Invalid regex
    }
  };

  const matchesResult = getMatches();

  // Convert Data Execution
  const handleConvert = () => {
    try {
      if (sourceFormat === 'json') {
        const parsed = JSON.parse(sourceData);

        if (targetFormat === 'typescript') {
          if (Array.isArray(parsed)) {
            const sample = parsed[0] || {};
            const fields = Object.keys(sample).map(k => `  ${k}: ${typeof sample[k]};`).join('\n');
            setConvertedData(`export interface GeneratedData {\n${fields}\n}\n\nexport const DATA: GeneratedData[] = ${JSON.stringify(parsed, null, 2)};`);
          } else {
            const fields = Object.keys(parsed).map(k => `  ${k}: ${typeof parsed[k]};`).join('\n');
            setConvertedData(`export interface GeneratedData {\n${fields}\n}\n\nexport const DATA: GeneratedData = ${JSON.stringify(parsed, null, 2)};`);
          }
        } else if (targetFormat === 'csv') {
          const arr = Array.isArray(parsed) ? parsed : [parsed];
          if (arr.length === 0) return setConvertedData('');
          const headers = Object.keys(arr[0]).join(',');
          const rows = arr.map(obj => Object.values(obj).map(v => `"${v}"`).join(',')).join('\n');
          setConvertedData(`${headers}\n${rows}`);
        } else if (targetFormat === 'yaml') {
          const toYaml = (obj: any, indent = 0) => {
            let str = '';
            const spaces = ' '.repeat(indent);
            for (const [k, v] of Object.entries(obj)) {
              if (typeof v === 'object' && v !== null) {
                str += `${spaces}${k}:\n${toYaml(v, indent + 2)}`;
              } else {
                str += `${spaces}${k}: ${v}\n`;
              }
            }
            return str;
          };
          setConvertedData(toYaml(parsed));
        } else {
          setConvertedData(JSON.stringify(parsed, null, 2));
        }
      } else if (sourceFormat === 'queryString') {
        const params = new URLSearchParams(sourceData);
        const obj: Record<string, string> = {};
        params.forEach((v, k) => { obj[k] = v; });
        setConvertedData(JSON.stringify(obj, null, 2));
      }
    } catch (e: any) {
      setConvertedData(`// Conversion Error: ${e.message || 'Invalid input payload'}`);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0c10] text-zinc-200 select-none overflow-hidden">
      {/* Top Header */}
      <div className="p-4 border-b border-white/10 flex items-center justify-between bg-zinc-900/60 shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
            <Wand2 size={20} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              RegEx & Data Transformer Studio
              <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                TRANSFORMER
              </span>
            </h2>
            <p className="text-[11px] text-zinc-400">Test Regular Expressions and convert data payloads (JSON, CSV, TypeScript)</p>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1 bg-zinc-950 p-1 rounded-xl border border-white/10">
          <button
            onClick={() => setActiveTab('regex')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'regex' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'text-zinc-400 hover:text-white'
            }`}
          >
            RegEx Tester
          </button>
          <button
            onClick={() => setActiveTab('converter')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'converter' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'text-zinc-400 hover:text-white'
            }`}
          >
            Data Converter
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-hidden p-4">
        {/* Tab 1: RegEx Tester */}
        {activeTab === 'regex' && (
          <div className="h-full flex flex-col space-y-4 overflow-y-auto custom-scrollbar">
            {/* Presets */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 custom-scrollbar">
              <span className="text-[10px] font-bold uppercase text-zinc-500 shrink-0">Presets:</span>
              {presets.map((p, i) => (
                <button
                  key={i}
                  onClick={() => setPattern(p.pattern)}
                  className="px-2.5 py-1 rounded-md bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-zinc-300 transition-colors shrink-0 cursor-pointer"
                >
                  {p.label}
                </button>
              ))}
            </div>

            {/* Pattern Input & Flags */}
            <div className="flex items-center gap-2 bg-zinc-900 border border-white/10 rounded-xl p-2.5">
              <span className="text-amber-400 font-mono font-bold text-sm px-1">/</span>
              <input
                type="text"
                value={pattern}
                onChange={(e) => setPattern(e.target.value)}
                placeholder="Enter regex pattern (e.g. [a-z]+)"
                className="flex-1 bg-transparent border-none outline-none font-mono text-xs text-amber-200 placeholder:text-zinc-600"
              />
              <span className="text-amber-400 font-mono font-bold text-sm px-1">/</span>

              {/* Flags Checkboxes */}
              <div className="flex items-center gap-3 border-l border-white/10 pl-3">
                {(['g', 'i', 'm'] as const).map((flag) => (
                  <label key={flag} className="flex items-center gap-1 cursor-pointer font-mono text-xs text-zinc-300">
                    <input
                      type="checkbox"
                      checked={flags[flag]}
                      onChange={(e) => setFlags({ ...flags, [flag]: e.target.checked })}
                      className="accent-amber-500 rounded"
                    />
                    {flag}
                  </label>
                ))}
              </div>
            </div>

            <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-4 min-h-[250px]">
              {/* Test Text Input */}
              <div className="flex flex-col bg-zinc-900 border border-white/10 rounded-xl overflow-hidden p-3">
                <span className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-2">Test String</span>
                <textarea
                  value={testText}
                  onChange={(e) => setTestText(e.target.value)}
                  placeholder="Insert string to test regex matches against..."
                  className="w-full flex-1 bg-zinc-950 border border-white/10 rounded-lg p-3 font-mono text-xs text-zinc-200 outline-none resize-none"
                />
              </div>

              {/* Match Results Output */}
              <div className="flex flex-col bg-zinc-900 border border-white/10 rounded-xl overflow-hidden p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                    Match Analysis
                  </span>
                  <span className="text-xs font-mono text-amber-400 font-bold">
                    {matchesResult === null ? 'Invalid RegEx' : `${matchesResult.length} Match(es)`}
                  </span>
                </div>

                <div className="flex-1 bg-zinc-950 border border-white/10 rounded-lg p-3 font-mono text-xs overflow-y-auto space-y-2 custom-scrollbar">
                  {matchesResult === null && <span className="text-rose-400">Regex compilation failed. Check pattern syntax.</span>}
                  {matchesResult && matchesResult.length === 0 && <span className="text-zinc-500 italic">No matches found.</span>}
                  {matchesResult && matchesResult.map((m, idx) => (
                    <div key={idx} className="p-2 rounded bg-zinc-900 border border-white/5 space-y-1">
                      <div className="flex items-center justify-between text-amber-300 font-bold">
                        <span>Match #{idx + 1}: "{m.match}"</span>
                        <span className="text-[10px] text-zinc-500">Index {m.index}</span>
                      </div>
                      {m.groups.length > 0 && (
                        <div className="pl-2 border-l border-amber-500/30 text-[11px] text-zinc-400 space-y-0.5">
                          {m.groups.map((grp, gIdx) => (
                            <div key={gIdx}>Group ${gIdx + 1}: <span className="text-zinc-200 font-semibold">{grp}</span></div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Data Converter */}
        {activeTab === 'converter' && (
          <div className="h-full flex flex-col space-y-4 overflow-hidden">
            <div className="flex items-center justify-between bg-zinc-900 p-3 rounded-xl border border-white/10">
              <div className="flex items-center gap-2 text-xs">
                <span className="font-bold text-zinc-400 uppercase">From:</span>
                <select
                  value={sourceFormat}
                  onChange={(e) => setSourceFormat(e.target.value as any)}
                  className="bg-zinc-950 border border-white/10 rounded-lg p-1.5 font-mono text-white text-xs outline-none"
                >
                  <option value="json">JSON</option>
                  <option value="queryString">Query String</option>
                </select>

                <ArrowRight size={14} className="text-amber-400" />

                <span className="font-bold text-zinc-400 uppercase">To:</span>
                <select
                  value={targetFormat}
                  onChange={(e) => setTargetFormat(e.target.value as any)}
                  className="bg-zinc-950 border border-white/10 rounded-lg p-1.5 font-mono text-white text-xs outline-none"
                >
                  <option value="typescript">TypeScript Interfaces</option>
                  <option value="csv">CSV</option>
                  <option value="yaml">YAML</option>
                  <option value="json">Prettified JSON</option>
                </select>
              </div>

              <button
                onClick={handleConvert}
                className="px-4 py-1.5 rounded-lg bg-amber-500 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 cursor-pointer hover:bg-amber-400 transition-colors"
              >
                <Zap size={14} /> Convert Data
              </button>
            </div>

            <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-4 overflow-hidden">
              {/* Input */}
              <div className="flex flex-col bg-zinc-900 border border-white/10 rounded-xl overflow-hidden p-3">
                <span className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-2">Input Payload</span>
                <textarea
                  value={sourceData}
                  onChange={(e) => setSourceData(e.target.value)}
                  className="w-full flex-1 bg-zinc-950 border border-white/10 rounded-lg p-3 font-mono text-xs text-amber-200 outline-none resize-none"
                />
              </div>

              {/* Output */}
              <div className="flex flex-col bg-zinc-900 border border-white/10 rounded-xl overflow-hidden p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-zinc-400">Transformed Output</span>
                  {convertedData && (
                    <button
                      onClick={() => handleCopy(convertedData)}
                      className="px-2 py-1 rounded bg-white/5 hover:bg-white/10 text-xs font-medium text-zinc-300 flex items-center gap-1 cursor-pointer"
                    >
                      {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                      {copied ? 'Copied' : 'Copy'}
                    </button>
                  )}
                </div>
                <textarea
                  readOnly
                  value={convertedData}
                  placeholder="Converted output will appear here..."
                  className="w-full flex-1 bg-zinc-950 border border-white/10 rounded-lg p-3 font-mono text-xs text-cyan-200 outline-none resize-none"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DataTransformerStudio;
