import React, { useState, useEffect, useRef } from 'react';
import { Terminal as TerminalIcon, Send, X, Loader2, ChevronRight, AlertCircle, Trash2, Copy, Check, Filter } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { terminalService, TerminalEntry } from '../../services/terminalService';

const SystemTerminal: React.FC<{ onClose?: () => void }> = ({ onClose }) => {
  const [input, setInput] = useState('');
  const [logs, setLogs] = useState<TerminalEntry[]>([]);
  const [filter, setFilter] = useState<'all' | 'command' | 'error' | 'system'>('all');
  const [isExecuting, setIsExecuting] = useState(false);
  const [cwd, setCwd] = useState('/');
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);
  const [copied, setCopied] = useState(false);
  const [sandboxMode, setSandboxMode] = useState(true);
  const terminalEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Initialize socket connection and global error listener
    terminalService.initSocketListeners();

    // Sync initial logs and CWD
    setLogs(terminalService.getLogs());
    setCwd(terminalService.getCwd());

    // Subscribe to real-time logs and errors
    const unsubscribe = terminalService.subscribe(() => {
      setLogs(terminalService.getLogs());
      setCwd(terminalService.getCwd());
    });

    return () => {
      unsubscribe();
    };
  }, []);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs, isExecuting, filter]);

  const handleExecuteCommand = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isExecuting) return;

    const cmd = input.trim();
    setInput('');
    setIsExecuting(true);

    // Save to command history
    setCommandHistory(prev => [cmd, ...prev.filter(c => c !== cmd)]);
    setHistoryIndex(-1);

    try {
      const res = await terminalService.executeCommand(cmd, cwd, sandboxMode);
      if (res.cwd) {
        setCwd(res.cwd);
      }
    } catch (err: any) {
      terminalService.logError(`Execution error: ${err.message}`, 'TERMINAL');
    } finally {
      setIsExecuting(false);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (commandHistory.length > 0 && historyIndex < commandHistory.length - 1) {
        const nextIndex = historyIndex + 1;
        setHistoryIndex(nextIndex);
        setInput(commandHistory[nextIndex]);
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > 0) {
        const nextIndex = historyIndex - 1;
        setHistoryIndex(nextIndex);
        setInput(commandHistory[nextIndex]);
      } else if (historyIndex === 0) {
        setHistoryIndex(-1);
        setInput('');
      }
    }
  };

  const clearTerminal = () => {
    terminalService.clear();
  };

  const copyLogs = () => {
    const text = logs.map(l => `[${new Date(l.timestamp).toLocaleTimeString()}] [${l.type.toUpperCase()}] ${l.content}`).join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const quickCommands = [
    { label: 'AETHER CLI', cmd: 'aether help' },
    { label: 'CORE CONCEPTS', cmd: 'aether core' },
    { label: 'KEYBINDINGS', cmd: 'aether keys' },
    { label: 'DOCTOR', cmd: 'aether doctor' },
    { label: 'EXTENSIONS', cmd: 'aether ext list' },
    { label: 'TREE', cmd: 'aether tree' },
    { label: 'LS', cmd: 'ls -la' },
    { label: 'SYSINFO', cmd: 'aether sys' },
    { label: 'ERRORS', cmd: 'errors' },
    { label: 'CLEAR', cmd: 'clear' },
  ];

  const filteredLogs = logs.filter(l => {
    if (filter === 'all') return true;
    if (filter === 'command') return l.type === 'command';
    if (filter === 'error') return l.type === 'error';
    if (filter === 'system') return l.type === 'system' || l.type === 'output' || l.type === 'info';
    return true;
  });

  const errorCount = logs.filter(l => l.type === 'error').length;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 20 }}
      className="flex flex-col h-full bg-[#050505] text-zinc-300 font-mono text-[11px] selection:bg-orange-500/30 overflow-hidden relative"
      aria-label="System Terminal"
    >
      {/* Terminal Top Bar */}
      <div className="h-10 px-4 flex items-center justify-between border-b border-white/5 bg-white/[0.02] shrink-0 select-none">
        <div className="flex items-center gap-4">
          <div className="flex gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-red-500/20 border border-red-500/40" />
            <div className="w-2.5 h-2.5 rounded-full bg-amber-500/20 border border-amber-500/40" />
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/20 border border-emerald-500/40" />
          </div>
          <div className="flex items-center gap-2 ml-2">
            <TerminalIcon size={12} className="text-orange-500/60" />
            <span className="text-[9px] font-black text-white/40 uppercase tracking-[0.2em]">Aether Neural Shell</span>
          </div>
        </div>

        {/* Sandbox Mode Toggle */}
        <button
          onClick={() => {
            setSandboxMode(!sandboxMode);
            terminalService.logSystem(
              !sandboxMode 
                ? "🔒 [SECURITY CONFIRMED]: Aether Industrial gVisor Isolation Shield ENABLED. Running commands in session-isolated temporary sandbox volumes with proactive execution block policies."
                : "⚠️ [SECURITY ADVISORY]: Sandbox Boundary Protection DEACTIVATED. Command execution has host container permissions. Enter sensitive commands with care.",
              "SANDBOX"
            );
          }}
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-[8px] font-mono font-black uppercase tracking-wider transition-all cursor-pointer select-none ${
            sandboxMode 
              ? "bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20" 
              : "bg-red-500/10 border-red-500/30 text-red-400 hover:bg-red-500/20 animate-pulse"
          }`}
          title={sandboxMode ? "Securing container with Aether Sandbox isolation rules" : "Unsecured raw host process access"}
        >
          <div className={`w-1.5 h-1.5 rounded-full ${sandboxMode ? 'bg-emerald-400' : 'bg-red-400 animate-ping'}`} />
          {sandboxMode ? "gVisor VM Shield Active" : "Unsecured Host Kernel"}
        </button>

        {/* Log Filter Pills */}
        <div className="flex items-center gap-1.5 bg-black/40 border border-white/5 p-0.5 rounded-lg">
          {(['all', 'command', 'error', 'system'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wider transition-all ${
                filter === f
                  ? 'bg-orange-500/20 border border-orange-500/40 text-orange-400'
                  : 'text-white/30 hover:text-white/70'
              }`}
            >
              {f === 'error' && errorCount > 0 ? `ERRORS (${errorCount})` : f}
            </button>
          ))}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <button 
            onClick={copyLogs}
            className="p-1.5 hover:bg-white/5 rounded-lg text-white/30 hover:text-white transition-all outline-none"
            title="Copy logs to clipboard"
            aria-label="Copy logs"
          >
            {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
          </button>
          <button 
            onClick={clearTerminal}
            className="p-1.5 hover:bg-white/5 rounded-lg text-white/30 hover:text-white/80 transition-all outline-none"
            title="Clear terminal history"
            aria-label="Clear Terminal"
          >
            <Trash2 size={12} />
          </button>
          {onClose && (
            <button 
              onClick={onClose}
              className="p-1.5 hover:bg-red-500/10 rounded-lg text-white/30 hover:text-red-400 transition-all outline-none"
              aria-label="Close Terminal"
            >
              <X size={14} />
            </button>
          )}
        </div>
      </div>

      {/* Terminal Output Body */}
      <div className="flex-1 p-5 overflow-y-auto font-mono text-[11px] leading-relaxed custom-scrollbar bg-[#020202]">
        <div className="mb-5 text-orange-500/40 flex flex-col gap-1 select-none">
          <pre className="leading-tight text-[8px] sm:text-[10px]">
{`   _____        __  __                 
  /  _  \\   ___/  |/  |__   ___________ 
 /  /_\\  \\_/ __ \\   __\\  |  \\/ __ \\_  __\\
/    |    \\  ___/|  | |  |  /  ___/|  |  /
\\____|__  /\\___  >__| |____/ \\___  >__|  
        \\/     \\/                \\/      `}
          </pre>
          <div className="mt-2 flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[9px] font-black tracking-[0.2em] uppercase text-emerald-400/80">Kernel connected & Active error listener active</span>
          </div>
        </div>

        {/* Rendered Log Entries */}
        <div className="space-y-2">
          {filteredLogs.map((entry) => (
            <div key={entry.id} className="group animate-in fade-in slide-in-from-left-1 duration-200">
              <div className="flex items-start gap-2 text-zinc-400">
                <span className="text-orange-500/40 font-bold shrink-0">❯</span>
                
                {entry.type === 'command' ? (
                  <div className="flex items-center gap-2 font-bold text-zinc-100">
                    <span className="text-[9px] bg-white/5 border border-white/10 px-1.5 py-0.5 rounded text-orange-400">
                      {entry.cwd || '/'}
                    </span>
                    <span>{entry.content}</span>
                  </div>
                ) : (
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      {entry.source && (
                        <span className={`text-[8px] font-black px-1.5 py-0.2 rounded uppercase tracking-wider ${
                          entry.type === 'error'
                            ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                            : entry.type === 'system'
                            ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                            : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                        }`}>
                          {entry.source}
                        </span>
                      )}
                      <span className="text-[8px] text-white/20 font-mono">
                        {new Date(entry.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <pre className={`whitespace-pre-wrap pl-3 border-l text-[11px] font-mono leading-relaxed ${
                      entry.type === 'error'
                        ? 'border-red-500/40 text-red-400/90 bg-red-950/10 p-2 rounded-r-md'
                        : entry.type === 'system'
                        ? 'border-purple-500/40 text-purple-300/80'
                        : 'border-white/10 text-zinc-300'
                    }`}>
                      {entry.content}
                    </pre>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {isExecuting && (
          <div className="flex items-center gap-2 text-orange-500/60 italic animate-pulse mt-3 ml-1">
            <Loader2 size={11} className="animate-spin" />
            <span className="text-[9px] font-bold uppercase tracking-widest">Executing shell instruction...</span>
          </div>
        )}

        <div ref={terminalEndRef} />
      </div>

      {/* Quick Command Pills */}
      <div className="px-2 py-2 flex gap-1.5 overflow-x-auto no-scrollbar bg-black/60 border-t border-white/5 select-none shrink-0">
        {quickCommands.map((qc) => (
          <button
            key={qc.label}
            onClick={() => { setInput(qc.cmd); inputRef.current?.focus(); }}
            className="px-3 py-1.5 rounded-md bg-white/[0.03] border border-white/5 hover:bg-white/[0.07] hover:border-white/10 text-[8px] font-black text-white/40 hover:text-white transition-all uppercase tracking-widest outline-none focus-visible:ring-1 focus-visible:ring-orange-500/50"
          >
            {qc.label}
          </button>
        ))}
      </div>

      {/* Command Input Form */}
      <form onSubmit={handleExecuteCommand} className="p-3 bg-black border-t border-white/5 flex items-center gap-3 shrink-0">
        <div className="flex items-center gap-2 text-orange-500/50 shrink-0 select-none">
          <ChevronRight size={14} strokeWidth={3} />
          <span className="text-[9px] font-black tracking-widest bg-white/5 px-2 py-0.5 rounded border border-white/10 text-orange-400">
            {cwd}
          </span>
        </div>
        <input 
          ref={inputRef}
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type command (e.g., ls, sysinfo, errors, npm run, python3)..."
          className="flex-1 bg-transparent border-none outline-none text-zinc-100 text-xs placeholder:text-white/20 font-mono"
          autoFocus
          disabled={isExecuting}
          aria-label="Terminal command input"
        />
        <button 
          type="submit"
          disabled={!input.trim() || isExecuting}
          className="p-1.5 text-white/30 hover:text-orange-500 transition-all disabled:opacity-10 outline-none rounded-md"
          aria-label="Execute Command"
        >
          {isExecuting ? <Loader2 size={16} className="animate-spin text-orange-400" /> : <Send size={16} />}
        </button>
      </form>
    </motion.div>
  );
};

export default SystemTerminal;
