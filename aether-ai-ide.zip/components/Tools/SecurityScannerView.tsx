import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  ShieldAlert, 
  AlertTriangle, 
  CheckCircle2, 
  Zap, 
  Wand2, 
  FileCode, 
  Lock, 
  Key, 
  Search, 
  RefreshCw, 
  Sparkles,
  ChevronRight,
  Code2,
  Bug
} from 'lucide-react';
import { FileNode } from '../../types';

interface SecurityIssue {
  id: string;
  fileId: string;
  fileName: string;
  severity: 'critical' | 'high' | 'medium' | 'info';
  category: 'secret_leak' | 'vulnerability' | 'quality' | 'performance';
  title: string;
  description: string;
  lineNumber?: number;
  snippet?: string;
  suggestedFix?: string;
}

interface SecurityScannerViewProps {
  files: FileNode[];
  onFixIssue?: (fileId: string, fixContent?: string) => void;
  onApplyAIAutoFixAll?: () => void;
}

export const SecurityScannerView: React.FC<SecurityScannerViewProps> = ({
  files,
  onFixIssue,
  onApplyAIAutoFixAll
}) => {
  const [isScanning, setIsScanning] = useState(false);
  const [issues, setIssues] = useState<SecurityIssue[]>([]);
  const [score, setScore] = useState<number>(100);
  const [activeFilter, setActiveFilter] = useState<'all' | 'critical' | 'high' | 'medium'>('all');
  const [selectedIssue, setSelectedIssue] = useState<SecurityIssue | null>(null);

  const runAuditScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      const foundIssues: SecurityIssue[] = [];

      files.forEach((file) => {
        const content = file.content || '';
        const lines = content.split('\n');

        // 1. Secret Leak Detection
        const apiKeyRegex = /(api[_-]?key|secret|token|password|auth|private[_-]?key)\s*[:=]\s*["']([^"']{8,})["']/i;
        const hardcodedJwtRegex = /eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/;

        lines.forEach((line, idx) => {
          const lineNum = idx + 1;

          if (apiKeyRegex.test(line) && !line.includes('process.env') && !line.includes('import.meta.env')) {
            foundIssues.push({
              id: `issue_secret_${file.id}_${lineNum}`,
              fileId: file.id,
              fileName: file.name,
              severity: 'critical',
              category: 'secret_leak',
              title: 'Potential Hardcoded Secret or API Key',
              description: 'Hardcoded secret detected in source file. Move keys to environment variables (.env.example) or process.env.',
              lineNumber: lineNum,
              snippet: line.trim(),
              suggestedFix: `Replace key assignment with process.env.YOUR_API_KEY`
            });
          }

          if (hardcodedJwtRegex.test(line)) {
            foundIssues.push({
              id: `issue_jwt_${file.id}_${lineNum}`,
              fileId: file.id,
              fileName: file.name,
              severity: 'critical',
              category: 'secret_leak',
              title: 'Hardcoded JWT Bearer Token Detected',
              description: 'Exposing static authentication tokens in code allows unauthorized access.',
              lineNumber: lineNum,
              snippet: line.trim()
            });
          }

          // 2. Vulnerabilities
          if (line.includes('dangerouslySetInnerHTML')) {
            foundIssues.push({
              id: `issue_xss_${file.id}_${lineNum}`,
              fileId: file.id,
              fileName: file.name,
              severity: 'high',
              category: 'vulnerability',
              title: 'Potential XSS Risk (dangerouslySetInnerHTML)',
              description: 'Directly injecting un-sanitized HTML can allow Cross-Site Scripting (XSS) attacks.',
              lineNumber: lineNum,
              snippet: line.trim(),
              suggestedFix: 'Use DOMPurify or standard React children rendering'
            });
          }

          if (line.includes('eval(') || line.includes('new Function(')) {
            foundIssues.push({
              id: `issue_eval_${file.id}_${lineNum}`,
              fileId: file.id,
              fileName: file.name,
              severity: 'critical',
              category: 'vulnerability',
              title: 'Arbitrary Code Execution Hazard (eval / new Function)',
              description: 'Evaluating dynamic strings opens remote code execution vulnerabilities.',
              lineNumber: lineNum,
              snippet: line.trim()
            });
          }

          // 3. Code Quality & React Hooks
          if (line.includes('useEffect(') && !line.includes('],')) {
            // Simple check if missing dependency array or infinite re-render risk
            const restOfFile = lines.slice(idx, idx + 10).join(' ');
            if (restOfFile.includes('setState') || restOfFile.includes('set')) {
              foundIssues.push({
                id: `issue_rerender_${file.id}_${lineNum}`,
                fileId: file.id,
                fileName: file.name,
                severity: 'medium',
                category: 'quality',
                title: 'Potential React Infinite Re-Render Cycle',
                description: 'Updating component state inside useEffect without a strict dependency array can crash the app.',
                lineNumber: lineNum,
                snippet: line.trim(),
                suggestedFix: 'Add primitive dependencies or a ref to guard the effect'
              });
            }
          }

          if (line.includes('any') && (file.name.endsWith('.ts') || file.name.endsWith('.tsx'))) {
            foundIssues.push({
              id: `issue_type_${file.id}_${lineNum}`,
              fileId: file.id,
              fileName: file.name,
              severity: 'info',
              category: 'quality',
              title: 'Explicit "any" Type Annotation',
              description: 'Using "any" bypasses TypeScript type safety checks.',
              lineNumber: lineNum,
              snippet: line.trim()
            });
          }

          // 4. Accessibility (a11y) Audits
          if (line.includes('<img') && !line.includes('alt=') && (file.name.endsWith('.tsx') || file.name.endsWith('.jsx') || file.name.endsWith('.html'))) {
            foundIssues.push({
              id: `issue_a11y_img_${file.id}_${lineNum}`,
              fileId: file.id,
              fileName: file.name,
              severity: 'medium',
              category: 'quality',
              title: 'Missing Image "alt" Accessibility Attribute',
              description: 'Image tag missing alt text attribute for screen readers and accessibility standards.',
              lineNumber: lineNum,
              snippet: line.trim(),
              suggestedFix: 'Add alt="Descriptive label" to the <img /> tag'
            });
          }

          if (line.includes('<button') && !line.includes('aria-label') && !line.includes('title') && line.includes('/>') && (file.name.endsWith('.tsx') || file.name.endsWith('.jsx'))) {
            foundIssues.push({
              id: `issue_a11y_btn_${file.id}_${lineNum}`,
              fileId: file.id,
              fileName: file.name,
              severity: 'low' as any,
              category: 'quality',
              title: 'Interactive Icon Button Missing Accessibility Label',
              description: 'Self-closing button without text children should have an aria-label or title for screen readers.',
              lineNumber: lineNum,
              snippet: line.trim(),
              suggestedFix: 'Add aria-label="Action description" or title="..."'
            });
          }
        });
      });

      setIssues(foundIssues);

      // Calculate security score
      let calculatedScore = 100;
      foundIssues.forEach((i) => {
        if (i.severity === 'critical') calculatedScore -= 20;
        else if (i.severity === 'high') calculatedScore -= 10;
        else if (i.severity === 'medium') calculatedScore -= 5;
        else calculatedScore -= 2;
      });
      setScore(Math.max(0, calculatedScore));
      setIsScanning(false);
    }, 600);
  };

  useEffect(() => {
    runAuditScan();
  }, [files.length]);

  const filteredIssues = issues.filter((issue) => {
    if (activeFilter === 'all') return true;
    return issue.severity === activeFilter;
  });

  const getSeverityBadge = (severity: SecurityIssue['severity']) => {
    switch (severity) {
      case 'critical':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-rose-500/20 text-rose-400 border border-rose-500/30">Critical</span>;
      case 'high':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-amber-500/20 text-amber-400 border border-amber-500/30">High</span>;
      case 'medium':
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-yellow-500/20 text-yellow-400 border border-yellow-500/30">Medium</span>;
      default:
        return <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-blue-500/20 text-blue-400 border border-blue-500/30">Info</span>;
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0c10] text-zinc-200 select-none overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-white/10 flex items-center justify-between bg-zinc-900/60 shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
            <ShieldCheck size={20} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              Security & AI Code Quality Auditor
              <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                LIVE GUARD
              </span>
            </h2>
            <p className="text-[11px] text-zinc-400">Scans secrets, vulnerabilities, and anti-patterns across all workspace files</p>
          </div>
        </div>

        <button
          onClick={runAuditScan}
          disabled={isScanning}
          className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-xs font-semibold text-zinc-200 border border-white/10 flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <RefreshCw size={14} className={isScanning ? 'animate-spin text-cyan-400' : ''} />
          {isScanning ? 'Auditing...' : 'Re-Scan Codebase'}
        </button>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-hidden">
        {/* Left Column: Security Score & Summary */}
        <div className="w-full lg:w-80 p-4 border-r border-white/10 bg-zinc-900/30 flex flex-col space-y-4 shrink-0 overflow-y-auto custom-scrollbar">
          {/* Health Score Gauge */}
          <div className="p-4 rounded-2xl bg-zinc-900 border border-white/10 flex flex-col items-center justify-center text-center relative overflow-hidden shadow-xl">
            <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/5 to-transparent pointer-events-none" />
            <div className="relative z-10">
              <div className="text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-1">
                Workspace Health Score
              </div>
              <div className={`text-4xl font-extrabold font-mono tracking-tight my-2 ${
                score >= 80 ? 'text-emerald-400' : score >= 50 ? 'text-amber-400' : 'text-rose-400'
              }`}>
                {score}%
              </div>
              <div className="flex items-center gap-1.5 text-xs font-medium justify-center">
                {score === 100 ? (
                  <span className="text-emerald-400 flex items-center gap-1"><CheckCircle2 size={14} /> Pristine Codebase</span>
                ) : (
                  <span className="text-amber-400 flex items-center gap-1"><AlertTriangle size={14} /> {issues.length} Issues Detected</span>
                )}
              </div>
            </div>
          </div>

          {/* Issue Breakdown Statistics */}
          <div className="space-y-2">
            <div className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 px-1">
              Issue Breakdown
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="p-3 rounded-xl bg-zinc-900 border border-white/5 flex flex-col">
                <span className="text-xs text-zinc-400">Critical / High</span>
                <span className="text-lg font-bold font-mono text-rose-400">
                  {issues.filter(i => i.severity === 'critical' || i.severity === 'high').length}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-zinc-900 border border-white/5 flex flex-col">
                <span className="text-xs text-zinc-400">Medium / Info</span>
                <span className="text-lg font-bold font-mono text-amber-400">
                  {issues.filter(i => i.severity === 'medium' || i.severity === 'info').length}
                </span>
              </div>
            </div>
          </div>

          {/* AI One-Click Auto Fix All */}
          {issues.length > 0 && onApplyAIAutoFixAll && (
            <button
              onClick={onApplyAIAutoFixAll}
              className="w-full p-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-cyan-950/40 transition-all cursor-pointer"
            >
              <Wand2 size={16} /> Auto-Repair Issues with AI
            </button>
          )}
        </div>

        {/* Right Column: Interactive Audit Log */}
        <div className="flex-1 flex flex-col p-4 space-y-3 overflow-hidden">
          {/* Filter Bar */}
          <div className="flex items-center gap-2 border-b border-white/10 pb-3">
            <span className="text-xs font-bold text-zinc-400 uppercase tracking-wider">Filter:</span>
            {(['all', 'critical', 'high', 'medium'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setActiveFilter(f)}
                className={`
                  px-2.5 py-1 rounded-lg text-xs font-medium uppercase transition-colors cursor-pointer
                  ${activeFilter === f 
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold' 
                    : 'bg-white/5 text-zinc-400 hover:text-zinc-200 border border-transparent'}
                `}
              >
                {f} ({f === 'all' ? issues.length : issues.filter(i => i.severity === f).length})
              </button>
            ))}
          </div>

          {/* Issue List */}
          <div className="flex-1 overflow-y-auto space-y-2.5 pr-1 custom-scrollbar">
            {filteredIssues.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center py-16 text-center text-zinc-500 space-y-2">
                <CheckCircle2 size={40} className="text-emerald-400" />
                <p className="text-sm font-semibold text-zinc-300">No security issues or vulnerabilities found!</p>
                <p className="text-xs text-zinc-500">Your workspace files passed all static analysis and key leakage checks.</p>
              </div>
            ) : (
              filteredIssues.map((issue) => (
                <div
                  key={issue.id}
                  onClick={() => setSelectedIssue(issue)}
                  className={`
                    p-3.5 rounded-xl border transition-all cursor-pointer flex flex-col space-y-2
                    ${selectedIssue?.id === issue.id 
                      ? 'bg-zinc-900 border-cyan-500/60 shadow-lg shadow-black/40 ring-1 ring-cyan-500/30' 
                      : 'bg-zinc-900/60 border-white/5 hover:border-white/15 hover:bg-zinc-900'}
                  `}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {getSeverityBadge(issue.severity)}
                      <span className="text-xs font-bold text-white">{issue.title}</span>
                    </div>
                    <span className="text-[11px] font-mono text-cyan-400 flex items-center gap-1">
                      <FileCode size={12} /> {issue.fileName} {issue.lineNumber && `:${issue.lineNumber}`}
                    </span>
                  </div>

                  <p className="text-xs text-zinc-400 leading-relaxed">{issue.description}</p>

                  {issue.snippet && (
                    <div className="p-2 rounded bg-zinc-950 font-mono text-[11px] text-rose-300/90 border border-white/5 overflow-x-auto">
                      <code>{issue.snippet}</code>
                    </div>
                  )}

                  {issue.suggestedFix && (
                    <div className="text-[11px] font-mono text-emerald-400 flex items-center gap-1 pt-1">
                      <Sparkles size={12} /> Fix Suggestion: {issue.suggestedFix}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecurityScannerView;
