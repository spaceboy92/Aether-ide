import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Sparkles, Bot, Sliders, Play, Trash2, Cpu, Settings, Code, FileCode, CheckSquare, 
  Layers, Palette, Terminal, Type, HelpCircle, Laptop, Smartphone, Tablet, Monitor,
  Compass, Volume2, ShieldAlert, Wifi, WifiOff, FileDown, RefreshCw, BarChart2,
  Minimize2, Maximize2, Check, Copy, History, Plus, AlertCircle, Eye, Zap, Flame, LayoutGrid
} from "lucide-react";
import { FileNode, ChatSession } from "../../types";
import { storageService } from "../../services/storageService";

interface EvolutionCoreProps {
  files: FileNode[];
  setFiles: React.Dispatch<React.SetStateAction<FileNode[]>>;
  activeFileId: string | null;
  setActiveFileId: (id: string | null) => void;
  activeSessionId: string | null;
  addLog: (type: "info" | "success" | "warn" | "error" | "system", msg: string, source?: string) => void;
  onClose?: () => void;
}

export const EvolutionCore: React.FC<EvolutionCoreProps> = ({
  files,
  setFiles,
  activeFileId,
  setActiveFileId,
  activeSessionId,
  addLog,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<"ai" | "cascade" | "editor" | "simulator" | "diagnostics">("cascade");

  // ----------------------------------------------------
  // STATES FOR WINDSURF CASCADE & CURSOR AI IDE
  // ----------------------------------------------------
  const [plans, setPlans] = useState<Array<{ id: string; title: string; description: string; status: "pending" | "running" | "success" | "error" }>>([
    { id: "p1", title: "Audit src/types.ts for Schema Alignment", description: "Audit data models to ensure type-safe parameters exist.", status: "success" },
    { id: "p2", title: "Trace React Hook dependencies in App.tsx", description: "Inspect state variables and useEffect deps for performance.", status: "success" },
    { id: "p3", title: "Optimize and Refactor Sidebar Modes", description: "Inject 'upgrade' and modularize diagnostics layout.", status: "running" },
    { id: "p4", title: "Execute Standalone Preview Compilation", description: "Run build systems in staging to test bundle integrity.", status: "pending" }
  ]);
  const [newPlanTitle, setNewPlanTitle] = useState("");
  const [newPlanDesc, setNewPlanDesc] = useState("");
  const [surgicalLine, setSurgicalLine] = useState<number>(1);
  const [surgicalPrompt, setSurgicalPrompt] = useState("Make this element styling highly responsive and premium");
  const [activeSurgicalProposal, setActiveSurgicalProposal] = useState<{
    fileId: string;
    filePath: string;
    line: number;
    originalCode: string;
    proposedCode: string;
    status: "none" | "proposed" | "applied" | "rejected";
  } | null>(null);

  const [composerFiles, setComposerFiles] = useState<string[]>([]);
  const [composerPrompt, setComposerPrompt] = useState("Refactor layout container across components to match perfect mathematical spacing scales");
  const [composerProposals, setComposerProposals] = useState<Array<{
    id: string;
    fileId: string;
    filePath: string;
    original: string;
    proposed: string;
    status: "proposed" | "applied" | "rejected";
  }>>([]);

  const [chatInputValue, setChatInputValue] = useState("");
  const [showMentionDropdown, setShowMentionDropdown] = useState(false);
  const [mentionQuery, setMentionQuery] = useState("");
  const [inlineTerminalOutput, setInlineTerminalOutput] = useState<string[]>([
    "aether-ide ~ % npm run build",
    "vite v5.1.0 building for production...",
    "✓ 42 modules transformed.",
    "dist/assets/index-B1z9H.js    542.12 kB │ gzip: 121.45 kB",
    "dist/index.html               1.42 kB",
    "✓ built in 1.12s"
  ]);
  const [terminalCommand, setTerminalCommand] = useState("");
  const [isCascadeRunning, setIsCascadeRunning] = useState(false);

  // ----------------------------------------------------
  // STATES FOR AI ASSISTANT (10 Features)
  // ----------------------------------------------------
  const [selectedModel, setSelectedModel] = useState<string>(() => localStorage.getItem("aether_ai_model") || "Aether Gemini 2.5 Pro");
  const [aiPersonality, setAiPersonality] = useState<string>(() => localStorage.getItem("aether_ai_personality") || "Senior Architect");
  const [temperature, setTemperature] = useState<number>(0.7);
  const [customInstructions, setCustomInstructions] = useState<string>(() => localStorage.getItem("aether_custom_instructions") || "Focus on type safety and beautiful Tailwind spacing.");
  const [aiThoughts, setAiThoughts] = useState<Array<{ step: string; status: "complete" | "running" | "pending" }>>([
    { step: "Analyze Workspace Directory Tree", status: "complete" },
    { step: "Scan src/types.ts for Schema Alignment", status: "complete" },
    { step: "Trace React Hook dependencies", status: "complete" },
    { step: "Optimize CSS utility classes in App.tsx", status: "complete" },
    { step: "Synthesize executable preview bundle", status: "pending" }
  ]);
  const [tokenBudget, setTokenBudget] = useState<number>(100000);
  const [tokenUsed, setTokenUsed] = useState<number>(34212);
  const [codeScanReport, setCodeScanReport] = useState<Array<{ id: string; file: string; line: number; type: "error" | "warning" | "info"; msg: string }>>([
    { id: "1", file: "App.tsx", line: 42, type: "warning", msg: "Unused state variable 'chatCompactMode' could be trimmed." },
    { id: "2", file: "index.html", line: 8, type: "info", msg: "Missing open graph meta tags." }
  ]);
  const [isScanning, setIsScanning] = useState(false);
  const [mockPrompt, setMockPrompt] = useState("");
  const [promptHistory, setPromptHistory] = useState<string[]>([
    "Build a neon dashboard tracking server node analytics",
    "Create a responsive Kanban board with fluid drag-and-drop",
    "Design a custom SVG particle playground with friction parameters"
  ]);
  const [selectedContextFiles, setSelectedContextFiles] = useState<string[]>([]);

  // ----------------------------------------------------
  // STATES FOR CODE EDITOR (10 Features)
  // ----------------------------------------------------
  const [editorTheme, setEditorTheme] = useState<string>(() => localStorage.getItem("aether_editor_theme") || "Cyberpunk Neon");
  const [fontSize, setFontSize] = useState<number>(13);
  const [tabSpacing, setTabSpacing] = useState<number>(2);
  const [keybindings, setKeybindings] = useState<string>("VSCode Default");
  const [useSemicolons, setUseSemicolons] = useState<boolean>(true);
  const [singleQuotes, setSingleQuotes] = useState<boolean>(false);
  const [bracketColorizer, setBracketColorizer] = useState<boolean>(true);
  const [autoCloseBrackets, setAutoCloseBrackets] = useState<boolean>(true);
  const [originalBufferContent, setOriginalBufferContent] = useState<string>("");
  const [simulatedCursors, setSimulatedCursors] = useState<Array<{ name: string; line: number; col: number; color: string }>>([
    { name: "Aether Agent", line: 12, col: 45, color: "#f97316" },
    { name: "Copilot", line: 85, col: 22, color: "#06b6d4" }
  ]);

  // ----------------------------------------------------
  // STATES FOR APP SIMULATOR (10 Features)
  // ----------------------------------------------------
  const [simulatorDevice, setSimulatorDevice] = useState<"desktop" | "tablet" | "mobile" | "responsive">("desktop");
  const [simWidth, setSimWidth] = useState<number>(1024);
  const [simHeight, setSimHeight] = useState<number>(768);
  const [consoleLogs, setConsoleLogs] = useState<Array<{ time: string; type: "log" | "warn" | "error"; text: string }>>([
    { time: "20:29:45", type: "log", text: "Aether Preview Sandbox Initialized." },
    { time: "20:29:46", type: "warn", text: "Vite websocket connection failed. Running in standalone fallback mode." }
  ]);
  const [simulatedNetworkRequests, setSimulatedNetworkRequests] = useState<Array<{ id: string; endpoint: string; status: number; latency: number }>>([
    { id: "1", endpoint: "/api/health", status: 200, latency: 12 },
    { id: "2", endpoint: "/api/publish", status: 200, latency: 145 }
  ]);
  const [simulatedLocalStorage, setSimulatedLocalStorage] = useState<Record<string, string>>({
    "aether_perf_mode": "high",
    "theme_mode": "cyber_dark"
  });
  const [hmrMode, setHmrMode] = useState<"manual" | "debounce" | "auto">("debounce");
  const [customCSSFilter, setCustomCSSFilter] = useState<string>("none");
  const [simFps, setSimFps] = useState<number>(60);
  const [simMemory, setSimMemory] = useState<number>(14.5);

  // ----------------------------------------------------
  // STATES FOR DIAGNOSTICS & SYSTEM (10 Features)
  // ----------------------------------------------------
  const [allocatedThreads, setAllocatedThreads] = useState<number>(4);
  const [diagTemp, setDiagTemp] = useState<number>(42);
  const [fanSpeed, setFanSpeed] = useState<number>(1800);
  const [isGCRunning, setIsGCRunning] = useState(false);
  const [pingTimes, setPingTimes] = useState<Record<string, number>>({ "US-West": 35, "EU-West": 110, "Asia-Pac": 14 });
  const [simulatedNetworkState, setSimulatedNetworkState] = useState<"online" | "offline">("online");
  const [audioOscillatorFreq, setAudioOscillatorFreq] = useState<number>(440);
  const [audioOscType, setAudioOscType] = useState<"sine" | "square" | "sawtooth">("sine");
  const [performanceProfile, setPerformanceProfile] = useState<"turbo" | "eco" | "battery">("turbo");
  const [diagnosticsLogs, setDiagnosticsLogs] = useState<string[]>([
    "SYS_INIT: Core diagnostics node mapped to GPU accelerated layer.",
    "NETWORK: WebSocket buffer flushed successfully."
  ]);

  // ----------------------------------------------------
  // EFFECT SYNC ON BUFFER LOAD
  // ----------------------------------------------------
  useEffect(() => {
    const activeFile = files.find(f => f.id === activeFileId);
    if (activeFile) {
      setOriginalBufferContent(activeFile.content);
    }
  }, [activeFileId]);

  // Save changes helper
  const updateLocalStorage = (key: string, val: string) => {
    try {
      localStorage.setItem(key, val);
    } catch (e) {
      console.warn("Storage restricted in preview environment", e);
    }
  };

  // Sound generator (Web Audio API) - fully functional, no mocks!
  const triggerAudioDiagnostic = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) {
        addLog("error", "Web Audio API is not supported in this browser.", "DIAGNOSTICS");
        return;
      }
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gainNode = ctx.createGain();

      osc.type = audioOscType;
      osc.frequency.setValueAtTime(audioOscillatorFreq, ctx.currentTime);
      
      // Sweep effect
      osc.frequency.exponentialRampToValueAtTime(audioOscillatorFreq * 2, ctx.currentTime + 0.5);

      gainNode.gain.setValueAtTime(0.08, ctx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.6);

      osc.connect(gainNode);
      gainNode.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.6);

      addLog("success", `Diagnostic Audio Sweep Triggered: ${audioOscType.toUpperCase()} wave @ ${audioOscillatorFreq}Hz - ${audioOscillatorFreq * 2}Hz.`, "DIAGNOSTICS");
      setDiagnosticsLogs(prev => [`AUDIO: Sweep sweep frequency ${audioOscillatorFreq}Hz executed.`, ...prev]);
    } catch (err: any) {
      addLog("error", `Web Audio node block: ${err.message}`, "DIAGNOSTICS");
    }
  };

  // Run extreme memory purge / Garbage Collector
  const handleRunGC = () => {
    setIsGCRunning(true);
    addLog("info", "Extreme Memory Purge: Allocating zero-buffers and clearing diagnostic logs...", "SYSTEM");
    
    setTimeout(() => {
      const bytesReclaimed = (Math.random() * 45 + 12).toFixed(2);
      setIsGCRunning(false);
      setConsoleLogs(prev => [...prev, { time: new Date().toTimeString().split(" ")[0], type: "log", text: `Garbage collection complete. Reclaimed ${bytesReclaimed} MB of buffer space.` }]);
      addLog("success", `Extreme Memory Purge: Radically pruned systems. Reclaimed ${bytesReclaimed}MB virtual cache.`, "SYSTEM");
      setDiagnosticsLogs(prev => [`GC: Flushed memory registers. Reclaimed ${bytesReclaimed}MB.`, ...prev]);
    }, 1200);
  };

  // Code scanner
  const runCodeScan = () => {
    setIsScanning(true);
    addLog("info", "Scan pipeline initiated. Scanning mounted file buffers for security & standards...", "AI");
    setTimeout(() => {
      const foundIssues: typeof codeScanReport = [];
      files.forEach(f => {
        if (f.content.includes("console.log")) {
          foundIssues.push({
            id: Math.random().toString(),
            file: f.name,
            line: f.content.split("\n").findIndex(l => l.includes("console.log")) + 1,
            type: "info",
            msg: "Spammy console logs should be pruned prior to cloud publish."
          });
        }
        if (f.content.includes("any") && f.language === "typescript") {
          foundIssues.push({
            id: Math.random().toString(),
            file: f.name,
            line: f.content.split("\n").findIndex(l => l.includes("any")) + 1,
            type: "warning",
            msg: "Loose 'any' type definition degrades compiler integrity."
          });
        }
      });

      if (foundIssues.length === 0) {
        foundIssues.push({
          id: "ok",
          file: "Staging",
          line: 0,
          type: "info",
          msg: "Pragmatic structures scanned. 100% compiled standards rating!"
        });
      }
      setCodeScanReport(foundIssues);
      setIsScanning(false);
      addLog("success", `Scan pipeline concluded. Found ${foundIssues.filter(i => i.id !== "ok").length} potential architectural improvements.`, "AI");
    }, 1000);
  };

  // Format Code Helper (1-click inline optimization)
  const runQuickOptimize = (type: "types" | "comments" | "unlogged") => {
    const activeFile = files.find(f => f.id === activeFileId);
    if (!activeFile) {
      addLog("warn", "Staging area is empty. Mount a file buffer in the editor to optimize.", "EDITOR");
      return;
    }

    addLog("info", `Neural Optimizer: Processing ${activeFile.name}...`, "EDITOR");

    let optimized = activeFile.content;
    if (type === "unlogged") {
      // Strips out console.logs
      const lines = optimized.split("\n");
      const filtered = lines.filter(l => !l.trim().startsWith("console.log"));
      optimized = filtered.join("\n");
      addLog("success", `Neural Optimizer: Successfully stripped console logging statements from ${activeFile.name}.`, "EDITOR");
    } else if (type === "comments") {
      // Injects JSDoc header
      optimized = `/**\n * @file ${activeFile.name}\n * @description High-performance React module generated inside Aether AI IDE.\n * @timestamp ${new Date().toLocaleString()}\n */\n\n` + optimized;
      addLog("success", `Neural Optimizer: Prepended high-fidelity JSDoc headers to ${activeFile.name}.`, "EDITOR");
    } else if (type === "types") {
      // Injects typical utility types at top
      optimized = `export type AetherRecord<T> = Record<string, T>;\nexport interface IAetherNode { id: string; state: 'active' | 'stale'; }\n\n` + optimized;
      addLog("success", `Neural Optimizer: Injected structured type declarations into ${activeFile.name}.`, "EDITOR");
    }

    setFiles(prev => prev.map(f => f.id === activeFileId ? { ...f, content: optimized } : f));
  };

  // simulated cursor incrementer
  const incrementSimCursor = () => {
    setSimulatedCursors(prev => prev.map(c => ({
      ...c,
      line: Math.max(1, c.line + Math.floor(Math.random() * 3) - 1),
      col: Math.max(1, c.col + Math.floor(Math.random() * 5) - 2)
    })));
  };

  useEffect(() => {
    const interval = setInterval(() => {
      incrementSimCursor();
      // adjust diag stats marginally
      setDiagTemp(t => Math.max(35, Math.min(65, t + (Math.random() * 2 - 1))));
      setFanSpeed(s => Math.max(1200, Math.min(2800, s + Math.floor(Math.random() * 50 - 25))));
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="flex flex-col h-full bg-[#07080c] text-zinc-200 font-sans border-r border-white/5 select-none text-[11px]">
      
      {/* Mini Title bar */}
      <div className="flex items-center justify-between px-5 py-3.5 border-b border-white/5 bg-black/40">
        <div className="flex items-center gap-2">
          <Zap size={14} className="text-amber-400 animate-pulse" />
          <span className="font-black uppercase tracking-widest text-white">40-Core Upgrade Engine</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[7px] font-black px-2 py-0.5 bg-amber-500/10 text-amber-400 border border-amber-500/20 rounded-full">ACTIVE L5</span>
        </div>
      </div>

      {/* Primary Category Selector */}
      <div className="grid grid-cols-5 border-b border-white/5 bg-black/20 text-center shrink-0">
        {[
          { id: "ai", icon: Bot, label: "CoPilot" },
          { id: "cascade", icon: CheckSquare, label: "Cascade" },
          { id: "editor", icon: Code, label: "Editor" },
          { id: "simulator", icon: Laptop, label: "Simulator" },
          { id: "diagnostics", icon: Cpu, label: "Diagnostics" }
        ].map(cat => (
          <button
            key={cat.id}
            onClick={() => setActiveTab(cat.id as any)}
            className={`py-3 flex flex-col items-center gap-1.5 transition-all text-[8px] font-black uppercase tracking-widest border-b-2 ${
              activeTab === cat.id 
                ? "border-amber-500 text-amber-400 bg-white/[0.02]" 
                : "border-transparent text-zinc-500 hover:text-zinc-300 hover:bg-white/[0.01]"
            }`}
          >
            <cat.icon size={14} />
            <span>{cat.label}</span>
          </button>
        ))}
      </div>

      {/* Category Sub-Panels with 10 features each */}
      <div className="flex-1 overflow-y-auto p-4 space-y-5 custom-scrollbar pb-24">

        {/* ==================================================== */}
        {/* TAB: WINDSURF CASCADE & CURSOR AI WORKSPACE */}
        {/* ==================================================== */}
        {activeTab === "cascade" && (
          <div className="space-y-4 text-zinc-300">

            {/* Feature 1: Cascade Interactive Plan & Tasks Checklist */}
            <div className="bg-[#0b0c13] border border-white/5 p-4 rounded-xl space-y-3.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-[8px] font-black text-amber-500 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">TASK BLOCK</span>
                  <span className="font-bold text-white uppercase tracking-wider">Cascade Plan Checklist</span>
                </div>
                <button
                  onClick={() => {
                    if (plans.length === 0) return;
                    setIsCascadeRunning(true);
                    addLog("info", "Cascade: Starting concurrent task pipeline...", "CASCADE");
                    
                    let stepIdx = 0;
                    const runStep = () => {
                      if (stepIdx >= plans.length) {
                        setIsCascadeRunning(false);
                        addLog("success", "Cascade: All planned files synchronized & validated cleanly.", "CASCADE");
                        return;
                      }
                      
                      setPlans(prev => prev.map((p, idx) => idx === stepIdx ? { ...p, status: "running" } : p));
                      addLog("info", `Cascade: Processing "${plans[stepIdx].title}"`, "CASCADE");

                      setTimeout(() => {
                        setPlans(prev => prev.map((p, idx) => idx === stepIdx ? { ...p, status: "success" } : p));
                        addLog("success", `Cascade: Succeeded "${plans[stepIdx].title}"`, "CASCADE");
                        stepIdx++;
                        runStep();
                      }, 1500);
                    };
                    runStep();
                  }}
                  disabled={isCascadeRunning}
                  className="px-3 py-1 bg-amber-500 hover:bg-amber-400 disabled:bg-zinc-800 disabled:text-zinc-500 font-bold text-[8px] uppercase tracking-wider text-black rounded-lg flex items-center gap-1.5 transition-all"
                >
                  <Play size={10} className={isCascadeRunning ? "animate-spin" : ""} />
                  <span>{isCascadeRunning ? "Running..." : "Execute Plan"}</span>
                </button>
              </div>

              <div className="space-y-2 max-h-[180px] overflow-y-auto custom-scrollbar pr-1">
                {plans.map((p) => (
                  <div 
                    key={p.id} 
                    className={`p-2.5 rounded-lg border transition-all ${
                      p.status === "success" 
                        ? "bg-emerald-500/5 border-emerald-500/20 text-zinc-300" 
                        : p.status === "running"
                        ? "bg-amber-500/5 border-amber-500/30 text-white animate-pulse shadow-[0_0_15px_rgba(245,158,11,0.05)]"
                        : "bg-white/[0.01] border-white/5 text-zinc-400"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-2.5">
                        <button
                          onClick={() => {
                            setPlans(prev => prev.map(item => item.id === p.id ? { 
                              ...item, 
                              status: item.status === "success" ? "pending" : "success" 
                            } : item));
                            addLog("info", `Toggled status for task "${p.title}"`, "CASCADE");
                          }}
                          className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 mt-0.5 transition-colors ${
                            p.status === "success" ? "bg-emerald-500 border-emerald-500 text-black" : "border-white/20"
                          }`}
                        >
                          {p.status === "success" && <Check size={10} strokeWidth={3} />}
                        </button>
                        <div>
                          <p className="font-bold text-[10px] text-white leading-tight">{p.title}</p>
                          <p className="text-[8px] text-zinc-400 mt-0.5 leading-normal">{p.description}</p>
                        </div>
                      </div>

                      {/* Status Badges */}
                      <div className="flex items-center gap-1 shrink-0">
                        <button 
                          onClick={() => {
                            setPlans(prev => prev.map(item => item.id === p.id ? { ...item, status: "running" } : item));
                            addLog("info", `Set task "${p.title}" to Running.`, "CASCADE");
                          }}
                          className={`p-1 rounded text-[7px] font-black uppercase ${p.status === "running" ? "bg-amber-500 text-black" : "bg-black/30 text-zinc-500 hover:text-zinc-300"}`}
                        >
                          Run
                        </button>
                        <button
                          onClick={() => {
                            setPlans(prev => prev.filter(item => item.id !== p.id));
                            addLog("warn", `Pruned task "${p.title}" from plan array.`, "CASCADE");
                          }}
                          className="p-1 bg-black/30 text-zinc-600 hover:text-red-400 rounded"
                        >
                          <Trash2 size={10} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Add Custom Step Form */}
              <div className="bg-black/40 border border-white/[0.02] p-2.5 rounded-lg space-y-2">
                <p className="text-[8px] font-black text-zinc-400 uppercase tracking-wide">Queue New Cascade Plan Task</p>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={newPlanTitle}
                    onChange={(e) => setNewPlanTitle(e.target.value)}
                    placeholder="Task Title (e.g. Integrate API)"
                    className="bg-black/80 border border-white/10 rounded px-2 py-1 text-[9px] text-zinc-200 focus:outline-none focus:border-amber-500"
                  />
                  <input
                    type="text"
                    value={newPlanDesc}
                    onChange={(e) => setNewPlanDesc(e.target.value)}
                    placeholder="Brief description details..."
                    className="bg-black/80 border border-white/10 rounded px-2 py-1 text-[9px] text-zinc-200 focus:outline-none focus:border-amber-500"
                  />
                </div>
                <button
                  onClick={() => {
                    if (!newPlanTitle.trim()) return;
                    const nt = {
                      id: `p-${Date.now()}`,
                      title: newPlanTitle.trim(),
                      description: newPlanDesc.trim() || "Analyze and refactor codebase constraints.",
                      status: "pending" as const
                    };
                    setPlans(prev => [...prev, nt]);
                    addLog("success", `Queued new Cascade task: "${newPlanTitle}"`, "CASCADE");
                    setNewPlanTitle("");
                    setNewPlanDesc("");
                  }}
                  className="w-full py-1 bg-white/5 hover:bg-white/10 border border-white/10 font-bold text-[8px] text-white rounded uppercase"
                >
                  + Append Plan Step
                </button>
              </div>
            </div>

            {/* Feature 2: Cursor Surgical Line-Specific Code Editor */}
            <div className="bg-[#0b0c13] border border-white/5 p-4 rounded-xl space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-[8px] font-black text-amber-500 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">CURSOR INLINE</span>
                <span className="font-bold text-white uppercase tracking-wider">Surgical Line-Specific Editor</span>
              </div>
              <p className="text-[8px] text-zinc-400 leading-normal">
                Select an active workspace buffer, target a precise line number, and prompt CoPilot to perform safe, localized modifications.
              </p>

              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[8px] text-zinc-500 block mb-0.5 font-mono">Active Target Buffer</label>
                    <select
                      value={activeFileId || ""}
                      onChange={(e) => {
                        setActiveFileId(e.target.value || null);
                        addLog("info", `Surgical Editor targeting file ID: ${e.target.value}`, "CURSOR");
                      }}
                      className="w-full bg-black border border-white/10 rounded p-1 text-[8px] font-mono focus:outline-none focus:border-amber-500 text-zinc-200"
                    >
                      <option value="">-- No File selected --</option>
                      {files.map(f => (
                        <option key={f.id} value={f.id}>{f.name} ({f.language})</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-[8px] text-zinc-500 block mb-0.5 font-mono">Target Line Number</label>
                    <input
                      type="number"
                      min={1}
                      max={Math.max(1, files.find(f => f.id === activeFileId)?.content.split("\n").length || 100)}
                      value={surgicalLine}
                      onChange={(e) => setSurgicalLine(Math.max(1, Number(e.target.value)))}
                      className="w-full bg-black border border-white/10 rounded p-1 text-[8px] font-mono focus:outline-none focus:border-amber-500 text-zinc-200"
                    />
                  </div>
                </div>

                {/* Dynamically display active targeted line value */}
                {activeFileId && (
                  <div className="bg-black/60 p-2 border border-white/[0.03] rounded font-mono text-[8px] text-zinc-500">
                    <span className="text-zinc-600">Current text of line {surgicalLine}:</span>
                    <div className="text-zinc-300 truncate mt-1 pl-1 border-l border-amber-500/50">
                      {files.find(f => f.id === activeFileId)?.content.split("\n")[surgicalLine - 1] || <span className="text-zinc-700 italic">Empty or out of bounds</span>}
                    </div>
                  </div>
                )}

                <div>
                  <label className="text-[8px] text-zinc-500 block mb-0.5 font-mono">Refactoring Directives</label>
                  <textarea
                    value={surgicalPrompt}
                    onChange={(e) => setSurgicalPrompt(e.target.value)}
                    placeholder="e.g., Wrap in try-catch / Inject retry mechanism / Stylize with Tailwind orange"
                    className="w-full h-11 bg-black border border-white/10 rounded p-1.5 text-[9px] text-zinc-200 focus:outline-none focus:border-amber-500 leading-normal resize-none"
                  />
                </div>

                <button
                  onClick={() => {
                    const activeF = files.find(f => f.id === activeFileId);
                    if (!activeF) {
                      addLog("warn", "Cursor: Please mount an active file buffer to propose changes.", "CURSOR");
                      return;
                    }
                    const lines = activeF.content.split("\n");
                    const orig = lines[surgicalLine - 1] || "";
                    
                    // Apply realistic modifications based on prompt key phrases
                    let proposed = orig;
                    const pLower = surgicalPrompt.toLowerCase();
                    if (pLower.includes("color") || pLower.includes("orange") || pLower.includes("vibrant")) {
                      proposed = orig.replace(/text-zinc-\d+/g, "text-amber-400 font-black")
                                     .replace(/bg-zinc-\d+/g, "bg-amber-500/10 border-amber-500/30 text-amber-400")
                                     .replace(/text-zinc-400/g, "text-amber-400")
                                     .replace(/text-zinc-500/g, "text-amber-500");
                      if (proposed === orig) proposed = orig + " /* Injected high-contrast amber theme tag */";
                    } else if (pLower.includes("try") || pLower.includes("catch") || pLower.includes("guard")) {
                      proposed = `  try {\n    ${orig.trim()}\n  } catch (error) {\n    console.error("Surgical Guard triggered:", error);\n  }`;
                    } else if (pLower.includes("responsive") || pLower.includes("flex")) {
                      proposed = orig.replace(/w-full/g, "w-full max-w-2xl mx-auto flex flex-col md:flex-row gap-4")
                                     .replace(/p-4/g, "p-4 md:p-6 lg:p-8");
                    } else {
                      proposed = orig + ` // Surgical Optimization: ${surgicalPrompt}`;
                    }

                    setActiveSurgicalProposal({
                      fileId: activeF.id,
                      filePath: activeF.name,
                      line: surgicalLine,
                      originalCode: orig,
                      proposedCode: proposed,
                      status: "proposed"
                    });
                    addLog("info", `Cursor: Generated surgical diff proposal for ${activeF.name} at line ${surgicalLine}`, "CURSOR");
                  }}
                  className="w-full py-1.5 bg-amber-500 text-black hover:bg-amber-400 font-bold text-[8px] uppercase tracking-wider rounded"
                >
                  Propose Surgical Line Edit
                </button>
              </div>

              {/* Proposed surgical change diff display */}
              <AnimatePresence>
                {activeSurgicalProposal && (
                  <motion.div 
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="p-3 bg-black border border-white/10 rounded-lg space-y-2.5 font-mono text-[8px]"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[7px] uppercase font-black text-amber-500">PROPOSED DIFF - L{activeSurgicalProposal.line} ({activeSurgicalProposal.filePath})</span>
                      <span className={`text-[7px] uppercase font-bold px-1 rounded ${activeSurgicalProposal.status === "applied" ? "bg-emerald-500/20 text-emerald-400" : "bg-amber-500/20 text-amber-400"}`}>
                        {activeSurgicalProposal.status}
                      </span>
                    </div>

                    <div className="space-y-1 bg-zinc-950 p-2 rounded border border-white/[0.02] max-h-[120px] overflow-y-auto overflow-x-auto text-[8px] leading-normal">
                      {/* Red original */}
                      <div className="flex gap-2 text-red-400 bg-red-950/20 p-1 rounded">
                        <span className="text-zinc-600 shrink-0 font-bold">- L{activeSurgicalProposal.line}</span>
                        <pre className="whitespace-pre">{activeSurgicalProposal.originalCode || "/* empty */"}</pre>
                      </div>
                      {/* Green replacement */}
                      <div className="flex gap-2 text-emerald-400 bg-emerald-950/20 p-1 rounded">
                        <span className="text-zinc-600 shrink-0 font-bold">+ L{activeSurgicalProposal.line}</span>
                        <pre className="whitespace-pre">{activeSurgicalProposal.proposedCode}</pre>
                      </div>
                    </div>

                    {activeSurgicalProposal.status === "proposed" && (
                      <div className="grid grid-cols-2 gap-2 text-center">
                        <button
                          onClick={() => {
                            const { fileId, line, proposedCode, filePath } = activeSurgicalProposal;
                            setFiles(prev => prev.map(f => {
                              if (f.id === fileId) {
                                const lines = f.content.split("\n");
                                lines[line - 1] = proposedCode;
                                const updatedContent = lines.join("\n");
                                return { ...f, content: updatedContent, lastModified: Date.now() };
                              }
                              return f;
                            }));
                            addLog("success", `Cursor: Surgical patch applied successfully to ${filePath} line ${line}!`, "CURSOR");
                            setActiveSurgicalProposal(prev => prev ? { ...prev, status: "applied" } : null);
                            setTimeout(() => setActiveSurgicalProposal(null), 1200);
                          }}
                          className="py-1 bg-emerald-500 text-black hover:bg-emerald-400 font-bold uppercase rounded"
                        >
                          Accept & Apply
                        </button>
                        <button
                          onClick={() => {
                            addLog("info", "Cursor: Surgical proposal rejected and reverted.", "CURSOR");
                            setActiveSurgicalProposal(null);
                          }}
                          className="py-1 bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white font-bold uppercase rounded border border-white/10"
                        >
                          Reject
                        </button>
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Feature 3: Composer (Multi-file Parallel Diff Editor) */}
            <div className="bg-[#0b0c13] border border-white/5 p-4 rounded-xl space-y-3.5">
              <div className="flex items-center gap-2">
                <span className="text-[8px] font-black text-amber-500 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">COMPOSER</span>
                <span className="font-bold text-white uppercase tracking-wider">AI Multi-File Composer</span>
              </div>
              <p className="text-[8px] text-zinc-400 leading-normal">
                Edit across multiple codebase scopes simultaneously. Select context file blocks and specify your structural target.
              </p>

              {/* Context Selector checkboxes */}
              <div>
                <label className="text-[8px] text-zinc-500 block mb-1 font-mono">Select Composer Context (Multi-file)</label>
                <div className="flex flex-wrap gap-1.5 max-h-[80px] overflow-y-auto">
                  {files.map(f => {
                    const isChecked = composerFiles.includes(f.id);
                    return (
                      <button
                        key={f.id}
                        onClick={() => {
                          setComposerFiles(prev => 
                            isChecked ? prev.filter(id => id !== f.id) : [...prev, f.id]
                          );
                        }}
                        className={`px-2 py-1 text-[8px] font-mono rounded border flex items-center gap-1.5 transition-all ${
                          isChecked 
                            ? "bg-amber-500/10 border-amber-500 text-amber-400" 
                            : "bg-black/40 border-white/5 text-zinc-500 hover:text-zinc-300"
                        }`}
                      >
                        <div className={`w-2.5 h-2.5 rounded flex items-center justify-center border ${isChecked ? "bg-amber-500 border-amber-500 text-black" : "border-white/10"}`}>
                          {isChecked && <Check size={6} strokeWidth={3} />}
                        </div>
                        <span>{f.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="text-[8px] text-zinc-500 block mb-0.5 font-mono font-bold uppercase text-zinc-400">Structural Intent / Goals</label>
                <textarea
                  value={composerPrompt}
                  onChange={(e) => setComposerPrompt(e.target.value)}
                  className="w-full h-12 bg-black border border-white/10 rounded p-1.5 text-[9px] text-zinc-200 focus:outline-none focus:border-amber-500 leading-normal resize-none"
                  placeholder="e.g. Refactor app layout system to support clean typography and math grids..."
                />
              </div>

              <button
                onClick={() => {
                  if (composerFiles.length === 0) {
                    addLog("warn", "Composer: Choose at least one context file to analyze.", "COMPOSER");
                    return;
                  }
                  addLog("info", "Composer: Initiating multi-file AST parsing...", "COMPOSER");
                  
                  // Generate realistic composer proposals for selected files
                  const props = composerFiles.map((fid, idx) => {
                    const fileItem = files.find(f => f.id === fid);
                    const name = fileItem ? fileItem.name : "index.ts";
                    const origContent = fileItem ? fileItem.content : "";
                    
                    // Create simulated additions
                    const proposedText = origContent + `\n\n// COMPOSER PATCHED REGION:\n// Objective: ${composerPrompt}\nexport const getComposerMeta = () => ({\n  sync_timestamp: "${new Date().toLocaleTimeString()}",\n  ver: "3.2.1-l5"\n});\n`;
                    
                    return {
                      id: `prop-${idx}-${Date.now()}`,
                      fileId: fid,
                      filePath: name,
                      original: origContent.slice(-120) || "// empty baseline",
                      proposed: proposedText.slice(-260),
                      status: "proposed" as const
                    };
                  });
                  setComposerProposals(props);
                  addLog("success", `Composer: Synthesized parallel patch proposals for ${props.length} files.`, "COMPOSER");
                }}
                className="w-full py-1.5 bg-amber-500/10 border border-amber-500/20 text-amber-400 hover:bg-amber-500/20 rounded font-bold text-[8px] uppercase tracking-wider"
              >
                Simulate Multi-File Composer Plan
              </button>

              {/* Renders composer multi-file changes */}
              {composerProposals.length > 0 && (
                <div className="space-y-2 max-h-[220px] overflow-y-auto custom-scrollbar pt-1 pr-1 border-t border-white/5">
                  <div className="flex justify-between items-center bg-black/60 p-2 rounded">
                    <span className="text-[7px] text-zinc-400 font-bold uppercase tracking-wider">COMPOSER REVIEW BOARD ({composerProposals.length} File proposals)</span>
                    <button
                      onClick={() => {
                        composerProposals.forEach(p => {
                          if (p.status !== "proposed") return;
                          setFiles(prev => prev.map(f => {
                            if (f.id === p.fileId) {
                              const updated = f.content + `\n\n// COMPOSER PATCH:\n// Goal: ${composerPrompt}\n`;
                              return { ...f, content: updated, lastModified: Date.now() };
                            }
                            return f;
                          }));
                        });
                        setComposerProposals(prev => prev.map(p => ({ ...p, status: "applied" })));
                        addLog("success", "Composer: Synchronized and accepted all parallel codebase edits!", "COMPOSER");
                      }}
                      className="text-emerald-400 hover:text-emerald-300 font-black text-[7px] uppercase"
                    >
                      Accept All
                    </button>
                  </div>

                  {composerProposals.map((prop) => (
                    <div key={prop.id} className="p-2.5 bg-black/80 rounded-lg border border-white/5 space-y-2 font-mono text-[8px]">
                      <div className="flex justify-between items-center text-zinc-400 text-[7px]">
                        <span className="text-white font-bold">{prop.filePath}</span>
                        <span className={prop.status === "applied" ? "text-emerald-400 font-bold" : "text-amber-500"}>{prop.status.toUpperCase()}</span>
                      </div>

                      <div className="p-1.5 bg-zinc-950 rounded border border-white/[0.02] text-[7px] text-zinc-500 leading-normal max-h-[80px] overflow-y-auto max-w-full">
                        <div className="text-red-400 bg-red-950/20 p-1 rounded mb-1 truncate">
                          - {prop.original}
                        </div>
                        <div className="text-emerald-400 bg-emerald-950/20 p-1 rounded truncate">
                          + {prop.proposed}
                        </div>
                      </div>

                      {prop.status === "proposed" && (
                        <div className="flex justify-end gap-1.5 text-[7px]">
                          <button
                            onClick={() => {
                              setFiles(prev => prev.map(f => {
                                if (f.id === prop.fileId) {
                                  const updated = f.content + `\n\n// COMPOSER PATCH:\n// Goal: ${composerPrompt}\n`;
                                  return { ...f, content: updated, lastModified: Date.now() };
                                }
                                return f;
                              }));
                              setComposerProposals(prev => prev.map(p => p.id === prop.id ? { ...p, status: "applied" } : p));
                              addLog("success", `Composer: Applied changes to ${prop.filePath}`, "COMPOSER");
                            }}
                            className="px-2 py-0.5 bg-emerald-500 text-black font-black uppercase rounded"
                          >
                            Apply
                          </button>
                          <button
                            onClick={() => {
                              setComposerProposals(prev => prev.map(p => p.id === prop.id ? { ...p, status: "rejected" } : p));
                              addLog("info", `Composer: Rejected edits for ${prop.filePath}`, "COMPOSER");
                            }}
                            className="px-2 py-0.5 bg-white/5 text-zinc-400 rounded border border-white/10"
                          >
                            Skip
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Feature 4: Cascade Interactive Chat with @ Mentions */}
            <div className="bg-[#0b0c13] border border-white/5 p-4 rounded-xl space-y-3 relative">
              <div className="flex items-center gap-2">
                <span className="text-[8px] font-black text-amber-500 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">COPILOT CHAT</span>
                <span className="font-bold text-white uppercase tracking-wider">Interactive Chat & @ Mentions</span>
              </div>

              <div className="bg-black/60 p-2.5 rounded border border-white/[0.03] text-[8px] text-zinc-400 leading-normal max-h-[90px] overflow-y-auto">
                <p className="font-bold text-white text-[9px] mb-1">CoPilot Agent Assistant</p>
                <p>Hello! Type <span className="text-amber-400">@</span> to reference context files directly in your queries, e.g., <span className="font-mono text-amber-500">@App.tsx</span>. I can analyze them in parallel.</p>
              </div>

              {/* Chat Text area with @ triggers */}
              <div className="relative">
                <textarea
                  value={chatInputValue}
                  onChange={(e) => {
                    const val = e.target.value;
                    setChatInputValue(val);
                    
                    // Look for @ triggers
                    const words = val.split(/\s+/);
                    const lastWord = words[words.length - 1];
                    if (lastWord && lastWord.startsWith("@")) {
                      setShowMentionDropdown(true);
                      setMentionQuery(lastWord.slice(1).toLowerCase());
                    } else {
                      setShowMentionDropdown(false);
                    }
                  }}
                  placeholder="Ask Cascade to generate code or type @ to select context..."
                  className="w-full h-14 bg-black border border-white/10 rounded p-1.5 text-[9px] text-zinc-200 focus:outline-none focus:border-amber-500 leading-normal resize-none font-sans"
                />

                {/* File autocomplete suggestions popup */}
                <AnimatePresence>
                  {showMentionDropdown && (
                    <motion.div
                      initial={{ opacity: 0, y: 3 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="absolute bottom-full left-0 w-full bg-zinc-950 border border-white/10 rounded-lg shadow-2xl p-1 z-50 max-h-[100px] overflow-y-auto font-mono text-[8px]"
                    >
                      <p className="text-[7px] text-zinc-500 uppercase px-2 py-0.5 border-b border-white/5 mb-1">SELECT CODEBASE CONTEXT FILE</p>
                      {files
                        .filter(f => f.name.toLowerCase().includes(mentionQuery))
                        .map(f => (
                          <button
                            key={f.id}
                            onClick={() => {
                              const words = chatInputValue.split(/\s+/);
                              words[words.length - 1] = `@${f.name}`;
                              setChatInputValue(words.join(" ") + " ");
                              setShowMentionDropdown(false);
                              if (!selectedContextFiles.includes(f.id)) {
                                setSelectedContextFiles(prev => [...prev, f.id]);
                              }
                              addLog("info", `Injected ${f.name} into Copilot context stack.`, "AI");
                            }}
                            className="w-full text-left px-2 py-1 text-zinc-300 hover:bg-white/5 rounded flex justify-between"
                          >
                            <span>@{f.name}</span>
                            <span className="text-zinc-600 font-bold uppercase">{f.language}</span>
                          </button>
                        ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-[7px] text-zinc-500 uppercase font-bold tracking-wider">Context files active: {selectedContextFiles.length}</span>
                <button
                  onClick={() => {
                    if (!chatInputValue.trim()) return;
                    addLog("info", `Prompting Aether Chat: "${chatInputValue}"`, "AI");
                    setChatInputValue("");
                    setTokenUsed(u => Math.min(tokenBudget, u + Math.floor(Math.random() * 3000 + 500)));
                    
                    setTimeout(() => {
                      addLog("success", "Aether CoPilot: Code synchronization complete. All modified nodes validated.", "AI");
                    }, 800);
                  }}
                  className="px-3.5 py-1 bg-white/5 hover:bg-white/10 text-white font-bold text-[8px] uppercase rounded border border-white/10"
                >
                  Send Prompt
                </button>
              </div>
            </div>

            {/* Feature 5: Simulated Command Execution terminal */}
            <div className="bg-[#0b0c13] border border-white/5 p-4 rounded-xl space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-[8px] font-black text-amber-500 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">TERMINAL SHELL</span>
                <span className="font-bold text-white uppercase tracking-wider">Inline Action Shell</span>
              </div>
              <p className="text-[8px] text-zinc-400 leading-normal">
                Run compiler and linter commands directly in this simulated sandbox to verify codebase alignment. Try running <span className="font-mono text-amber-500">npm run build</span> or <span className="font-mono text-amber-500">tsc</span>.
              </p>

              {/* Terminal blackbox output */}
              <div className="bg-zinc-950 p-3 rounded-lg border border-white/5 font-mono text-[8px] text-emerald-400 h-[140px] overflow-y-auto space-y-1 custom-scrollbar scroll-smooth">
                {inlineTerminalOutput.map((line, i) => (
                  <p key={i} className="whitespace-pre-wrap leading-normal">{line}</p>
                ))}
              </div>

              {/* Terminal Input */}
              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!terminalCommand.trim()) return;
                  const cmd = terminalCommand.trim();
                  setInlineTerminalOutput(prev => [...prev, `aether-ide ~ % ${cmd}`]);
                  setTerminalCommand("");

                  setTimeout(() => {
                    let res: string[] = [];
                    if (cmd === "clear") {
                      setInlineTerminalOutput([]);
                      return;
                    } else if (cmd === "npm run build") {
                      res = [
                        "vite v5.1.0 building for production...",
                        "✓ 42 modules transformed.",
                        "dist/assets/index-B1z9H.js    542.12 kB │ gzip: 121.45 kB",
                        "dist/index.html               1.42 kB",
                        "✓ built in 1.12s",
                        "SUCCESS: Production output compiled."
                      ];
                      addLog("success", "Vite production compiler compiled successfully.", "SYSTEM");
                    } else if (cmd === "npm run lint" || cmd === "tsc") {
                      res = [
                        "> aether-ide@0.0.0 lint",
                        "> tsc --noEmit",
                        "Linting completed successfully. 0 errors found in workspace."
                      ];
                      addLog("success", "Diagnostics shell compiled clean.", "SYSTEM");
                    } else if (cmd === "git status") {
                      res = [
                        "On branch main",
                        "Your branch is up to date with 'origin/main'.",
                        "",
                        "Changes to be committed:",
                        "  (use \"git restore --staged <file>...\" to unstage)",
                        "\tmodified:   /components/Tools/EvolutionCore.tsx",
                        "",
                        "no other changes found in workspace"
                      ];
                    } else {
                      res = [
                        `Executing instruction '${cmd}'...`,
                        "Code execution completed.",
                        "Exit code: 0"
                      ];
                    }
                    setInlineTerminalOutput(prev => [...prev, ...res]);
                  }, 400);
                }}
                className="flex items-center gap-2"
              >
                <span className="font-mono text-[8px] text-zinc-500">~ %</span>
                <input
                  type="text"
                  value={terminalCommand}
                  onChange={(e) => setTerminalCommand(e.target.value)}
                  placeholder="Type compiler instruction (e.g. npm run build, clear)"
                  className="flex-1 bg-black border border-white/10 rounded px-2 py-1 text-[8px] font-mono text-zinc-200 focus:outline-none focus:border-amber-500"
                />
                <button
                  type="submit"
                  className="px-2.5 py-1 bg-white/5 hover:bg-white/10 text-white font-mono text-[8px] uppercase rounded border border-white/10 font-bold shrink-0"
                >
                  Enter
                </button>
              </form>
            </div>

          </div>
        )}

        {/* ==================================================== */}
        {/* TAB 1: AI ASSISTANT FEATURES (10 Features) */}
        {/* ==================================================== */}
        {activeTab === "ai" && (
          <div className="space-y-4">
            
            {/* Feature 1: Model Grid Switcher */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">01</span>
                <span className="font-bold text-white uppercase tracking-wider">Model Selector Grid</span>
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                {["Aether Gemini 2.5 Pro", "Aether Flash 2.5", "Aether DeepSeek v3", "Offline Web-LLM Llama"].map(m => (
                  <button
                    key={m}
                    onClick={() => {
                      setSelectedModel(m);
                      updateLocalStorage("aether_ai_model", m);
                      addLog("info", `AI Model Pipeline rerouted to: ${m}`, "AI");
                    }}
                    className={`px-2.5 py-2 text-[9px] font-semibold text-left rounded-lg border transition-all ${
                      selectedModel === m 
                        ? "bg-amber-500/10 border-amber-500 text-amber-400 shadow-[0_0_10px_rgba(245,158,11,0.1)]" 
                        : "bg-transparent border-white/5 text-zinc-400 hover:border-white/20 hover:text-white"
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            {/* Feature 2: Personality Matrix */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">02</span>
                <span className="font-bold text-white uppercase tracking-wider">CoPilot Persona</span>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {["Senior Architect", "Debugger bot", "UX Designer", "Pragmatist"].map(p => (
                  <button
                    key={p}
                    onClick={() => {
                      setAiPersonality(p);
                      updateLocalStorage("aether_ai_personality", p);
                      addLog("info", `CoPilot Agent Persona shifted to: ${p}`, "AI");
                    }}
                    className={`px-3 py-1 text-[8px] font-black uppercase tracking-wider rounded-full border transition-all ${
                      aiPersonality === p 
                        ? "bg-amber-500 text-black border-amber-500" 
                        : "bg-transparent border-white/10 text-zinc-400 hover:border-white/20 hover:text-white"
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            {/* Feature 3: Refactoring & Optimization Dials */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">03</span>
                <span className="font-bold text-white uppercase tracking-wider">Fast Refactoring Core</span>
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                <button 
                  onClick={() => runQuickOptimize("types")}
                  className="px-2 py-2 bg-white/5 hover:bg-white/10 border border-white/5 rounded-lg text-center font-bold text-zinc-300 hover:text-white"
                >
                  Type Guard
                </button>
                <button 
                  onClick={() => runQuickOptimize("comments")}
                  className="px-2 py-2 bg-white/5 hover:bg-white/10 border border-white/5 rounded-lg text-center font-bold text-zinc-300 hover:text-white"
                >
                  JSDoc Prep
                </button>
                <button 
                  onClick={() => runQuickOptimize("unlogged")}
                  className="px-2 py-2 bg-white/5 hover:bg-white/10 border border-white/5 rounded-lg text-center font-bold text-zinc-300 hover:text-white"
                >
                  Unlog
                </button>
              </div>
            </div>

            {/* Feature 4: Prompt Recipe Library */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">04</span>
                <span className="font-bold text-white uppercase tracking-wider">Prompt Seeds Library</span>
              </div>
              <div className="space-y-1">
                {promptHistory.map((ph, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setMockPrompt(ph);
                      addLog("success", `Seed Prompt appended to clipboard & chat buffer: "${ph}"`, "AI");
                      navigator.clipboard.writeText(ph);
                    }}
                    className="w-full text-left px-2 py-1.5 bg-black/40 border border-white/[0.02] hover:border-white/10 rounded text-zinc-400 hover:text-white truncate"
                  >
                    {ph}
                  </button>
                ))}
              </div>
            </div>

            {/* Feature 5: System Instructions Config */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">05</span>
                <span className="font-bold text-white uppercase tracking-wider">System Prompt Guard</span>
              </div>
              <textarea
                value={customInstructions}
                onChange={(e) => {
                  setCustomInstructions(e.target.value);
                  updateLocalStorage("aether_custom_instructions", e.target.value);
                }}
                className="w-full h-14 bg-black/60 border border-white/10 rounded-lg p-2 text-[9px] font-mono text-zinc-300 focus:outline-none focus:border-amber-500"
                placeholder="Adjust hidden directives..."
              />
            </div>

            {/* Feature 6: Live Thought Trace */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">06</span>
                <span className="font-bold text-white uppercase tracking-wider">Live Thought Trace</span>
              </div>
              <div className="space-y-1.5 font-mono text-[9px]">
                {aiThoughts.map((t, i) => (
                  <div key={i} className="flex items-center justify-between text-zinc-400">
                    <div className="flex items-center gap-2 truncate">
                      <div className={`w-1.5 h-1.5 rounded-full ${t.status === "complete" ? "bg-emerald-500" : t.status === "running" ? "bg-amber-500 animate-ping" : "bg-white/10"}`} />
                      <span className="truncate">{t.step}</span>
                    </div>
                    <span className="text-[7px] uppercase font-black">{t.status}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Feature 7: Token Budget Telemetry */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-[8px] font-black text-amber-500">07</span>
                  <span className="font-bold text-white uppercase tracking-wider">Token Telemetry</span>
                </div>
                <span className="text-[9px] font-mono font-bold text-amber-400">{((tokenUsed/tokenBudget)*100).toFixed(0)}% Budget</span>
              </div>
              <input 
                type="range" 
                min={50000} 
                max={500000} 
                step={10000}
                value={tokenBudget}
                onChange={(e) => setTokenBudget(Number(e.target.value))}
                className="w-full accent-amber-500 mb-2"
              />
              <div className="flex justify-between text-[8px] font-mono text-zinc-500">
                <span>Used: {tokenUsed} tkn</span>
                <span>Max: {tokenBudget} tkn</span>
              </div>
            </div>

            {/* Feature 8: Automated Bug Catcher */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-[8px] font-black text-amber-500">08</span>
                  <span className="font-bold text-white uppercase tracking-wider">Staging Lint scan</span>
                </div>
                <button 
                  onClick={runCodeScan}
                  disabled={isScanning}
                  className="px-2 py-0.5 bg-amber-500 text-black font-black text-[8px] rounded uppercase hover:bg-amber-400"
                >
                  {isScanning ? "Scanning..." : "Run"}
                </button>
              </div>
              <div className="space-y-1 max-h-[80px] overflow-y-auto">
                {codeScanReport.map(report => (
                  <div key={report.id} className="p-1.5 rounded bg-black/40 text-[9px] border border-white/[0.02]">
                    <div className="flex justify-between items-center mb-0.5">
                      <span className="text-[8px] font-bold text-amber-400 truncate">{report.file} : L{report.line}</span>
                      <span className="text-[7px] uppercase font-bold text-zinc-500">{report.type}</span>
                    </div>
                    <p className="text-zinc-400 text-[8px]">{report.msg}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Feature 9: AI Mock data / SVG generator */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">09</span>
                <span className="font-bold text-white uppercase tracking-wider">AI Mock Data Sandbox</span>
              </div>
              <button
                onClick={() => {
                  const randomData = JSON.stringify({
                    timestamp: Date.now(),
                    nodes: Array.from({ length: 4 }).map((_, i) => ({ id: `node-${i}`, ping: Math.floor(Math.random() * 40 + 5) }))
                  }, null, 2);
                  const dataFileName = "mock-telemetry.json";
                  const existingFile = files.find(f => f.name === dataFileName);
                  
                  if (existingFile) {
                    setFiles(prev => prev.map(f => f.name === dataFileName ? { ...f, content: randomData } : f));
                    addLog("success", `AI Mock Sandbox: Overwrote existing ${dataFileName} with fresh telemetry structures.`, "AI");
                  } else {
                    const nf: FileNode = {
                      id: "f-mock",
                      name: dataFileName,
                      content: randomData,
                      language: "json",
                      lastModified: Date.now()
                    };
                    setFiles(prev => [...prev, nf]);
                    setActiveFileId(nf.id);
                    addLog("success", `AI Mock Sandbox: Successfully injected fresh mock dataset into workspace: ${dataFileName}`, "AI");
                  }
                }}
                className="w-full py-1.5 bg-amber-500/10 border border-amber-500/20 text-amber-400 hover:bg-amber-500/20 rounded-lg text-center font-bold"
              >
                Incorporate Mock Dataset
              </button>
            </div>

            {/* Feature 10: Chat Context Injector */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">10</span>
                <span className="font-bold text-white uppercase tracking-wider">Token Context Builder</span>
              </div>
              <div className="space-y-1.5 max-h-[80px] overflow-y-auto">
                {files.map(f => {
                  const isChecked = selectedContextFiles.includes(f.id);
                  return (
                    <div 
                      key={f.id} 
                      onClick={() => {
                        setSelectedContextFiles(prev => 
                          isChecked ? prev.filter(id => id !== f.id) : [...prev, f.id]
                        );
                        addLog("info", `${isChecked ? 'Removed' : 'Added'} ${f.name} ${isChecked ? 'from' : 'to'} AI context array.`, "AI");
                      }}
                      className={`flex items-center gap-2 p-1.5 rounded bg-black/40 border transition-all cursor-pointer ${isChecked ? 'border-amber-500/50' : 'border-transparent'}`}
                    >
                      <div className={`w-3 h-3 rounded flex items-center justify-center border ${isChecked ? 'bg-amber-500 border-amber-500 text-black' : 'border-white/20'}`}>
                        {isChecked && <Check size={8} />}
                      </div>
                      <span className="text-[8px] truncate font-mono text-zinc-300">{f.name}</span>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>
        )}

        {/* ==================================================== */}
        {/* TAB 2: CODE EDITOR FEATURES (10 Features) */}
        {/* ==================================================== */}
        {activeTab === "editor" && (
          <div className="space-y-4">
            
            {/* Feature 1: Symbol Tree */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">01</span>
                <span className="font-bold text-white uppercase tracking-wider">Buffer Symbol Tree</span>
              </div>
              <div className="space-y-1 max-h-[100px] overflow-y-auto font-mono text-[9px]">
                {files.find(f => f.id === activeFileId)?.content.split("\n")
                  .map((l, i) => ({ text: l.trim(), line: i + 1 }))
                  .filter(l => l.text.startsWith("const ") || l.text.startsWith("export const ") || l.text.startsWith("function ") || l.text.startsWith("interface "))
                  .map((sym, idx) => (
                    <div 
                      key={idx} 
                      onClick={() => {
                        addLog("info", `Symbol Jumper: Simulated trace to line ${sym.line} of active buffer.`, "EDITOR");
                      }}
                      className="p-1 rounded bg-black/30 hover:bg-white/5 hover:text-white text-zinc-400 flex justify-between cursor-pointer"
                    >
                      <span className="truncate">{sym.text.slice(0, 32)}</span>
                      <span className="text-amber-500 text-[8px]">L{sym.line}</span>
                    </div>
                  )) || <span className="text-zinc-600 block text-center p-2">No functional symbols in buffer</span>}
              </div>
            </div>

            {/* Feature 2: Tabbed Workspace */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">02</span>
                <span className="font-bold text-white uppercase tracking-wider">Tabbed Workspace</span>
              </div>
              <div className="flex flex-wrap gap-1">
                {files.map(f => (
                  <button
                    key={f.id}
                    onClick={() => {
                      setActiveFileId(f.id);
                      addLog("info", `Workspace Tab Switched: ${f.name}`, "EDITOR");
                    }}
                    className={`px-2 py-1 text-[8px] rounded border font-mono truncate max-w-[90px] ${
                      activeFileId === f.id 
                        ? "bg-white text-black border-white" 
                        : "bg-black/40 border-white/5 text-zinc-400 hover:text-white"
                    }`}
                  >
                    {f.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Feature 3: Typography Configurator */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-[8px] font-black text-amber-500">03</span>
                  <span className="font-bold text-white uppercase tracking-wider">Typography Config</span>
                </div>
                <span className="text-[9px] font-mono text-amber-400">{fontSize}px</span>
              </div>
              <div className="flex items-center gap-3">
                <button onClick={() => setFontSize(p => Math.max(10, p-1))} className="w-8 py-1 bg-white/5 rounded border border-white/10 hover:bg-white/10">-</button>
                <div className="flex-1 text-center font-bold">{fontSize}px</div>
                <button onClick={() => setFontSize(p => Math.min(24, p+1))} className="w-8 py-1 bg-white/5 rounded border border-white/10 hover:bg-white/10">+</button>
              </div>
            </div>

            {/* Feature 4: Keybinding Emulation */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">04</span>
                <span className="font-bold text-white uppercase tracking-wider">Hotkeys Mode</span>
              </div>
              <div className="grid grid-cols-3 gap-1">
                {["VSCode Default", "Vim Keybinds", "Sublime Core"].map(k => (
                  <button
                    key={k}
                    onClick={() => {
                      setKeybindings(k);
                      addLog("success", `Keybinding profile initialized: ${k}`, "EDITOR");
                    }}
                    className={`py-1 rounded text-[8px] font-black uppercase tracking-wider border ${
                      keybindings === k 
                        ? "bg-amber-500/10 border-amber-500 text-amber-400" 
                        : "bg-transparent border-white/5 text-zinc-400 hover:text-white"
                    }`}
                  >
                    {k.split(" ")[0]}
                  </button>
                ))}
              </div>
            </div>

            {/* Feature 5: Boilerplate Snippet Library */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">05</span>
                <span className="font-bold text-white uppercase tracking-wider">Inject Boilerplate</span>
              </div>
              <div className="grid grid-cols-2 gap-1.5">
                {[
                  { name: "Tailwind Card", snippet: `<div className="p-6 bg-zinc-900 border border-white/5 rounded-2xl shadow-xl">\n  <h4 className="text-lg font-bold text-white">Title</h4>\n  <p className="text-zinc-400 mt-2">Description</p>\n</div>` },
                  { name: "Debounced Resize", snippet: `useEffect(() => {\n  const handler = () => {\n    // Debounced dimensions logic\n  };\n  window.addEventListener('resize', handler);\n  return () => window.removeEventListener('resize', handler);\n}, []);` }
                ].map((s, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      const activeFile = files.find(f => f.id === activeFileId);
                      if (activeFile) {
                        setFiles(prev => prev.map(f => f.id === activeFileId ? { ...f, content: f.content + "\n" + s.snippet } : f));
                        addLog("success", `Boilerplate Injected: Added "${s.name}" to ${activeFile.name}`, "EDITOR");
                      } else {
                        addLog("warn", "Staging buffer empty. Cannot inject boilerplate snippet.", "EDITOR");
                      }
                    }}
                    className="py-1 px-2 text-[8px] font-bold bg-white/5 hover:bg-white/10 rounded border border-white/10 hover:text-white text-zinc-400 truncate"
                  >
                    + {s.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Feature 6: Prettier Settings Visual Dashboard */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">06</span>
                <span className="font-bold text-white uppercase tracking-wider">Prettier Settings</span>
              </div>
              <div className="flex items-center justify-between gap-4 font-mono text-[9px]">
                <div className="flex items-center gap-1.5">
                  <button 
                    onClick={() => { setUseSemicolons(!useSemicolons); addLog("info", `Prettier semicolons toggled: ${!useSemicolons}`, "EDITOR"); }}
                    className={`w-4 h-4 rounded border flex items-center justify-center ${useSemicolons ? "bg-amber-500 border-amber-500 text-black" : "border-white/20"}`}
                  >
                    {useSemicolons && <Check size={8} />}
                  </button>
                  <span>Semicolons</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <button 
                    onClick={() => { setSingleQuotes(!singleQuotes); addLog("info", `Prettier singleQuotes toggled: ${!singleQuotes}`, "EDITOR"); }}
                    className={`w-4 h-4 rounded border flex items-center justify-center ${singleQuotes ? "bg-amber-500 border-amber-500 text-black" : "border-white/20"}`}
                  >
                    {singleQuotes && <Check size={8} />}
                  </button>
                  <span>SingleQuotes</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-zinc-500">Tab:</span>
                  <button 
                    onClick={() => { setTabSpacing(t => t === 2 ? 4 : 2); addLog("info", `Tab spacing switched to: ${tabSpacing === 2 ? 4 : 2}`, "EDITOR"); }}
                    className="px-2 py-0.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded font-bold"
                  >
                    {tabSpacing}
                  </button>
                </div>
              </div>
            </div>

            {/* Feature 7: Auto-Close & Brackets configuration */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">07</span>
                <span className="font-bold text-white uppercase tracking-wider">Autocomplete Controls</span>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center justify-between">
                  <span>Match Brackets</span>
                  <button 
                    onClick={() => setBracketColorizer(!bracketColorizer)}
                    className={`w-8 h-4 rounded-full p-0.5 transition-colors duration-200 focus:outline-none ${bracketColorizer ? "bg-amber-500" : "bg-zinc-800"}`}
                  >
                    <div className={`w-3 h-3 rounded-full bg-black transition-transform duration-200 transform ${bracketColorizer ? "translate-x-4" : "translate-x-0"}`} />
                  </button>
                </div>
                <div className="flex items-center justify-between">
                  <span>Auto Close</span>
                  <button 
                    onClick={() => setAutoCloseBrackets(!autoCloseBrackets)}
                    className={`w-8 h-4 rounded-full p-0.5 transition-colors duration-200 focus:outline-none ${autoCloseBrackets ? "bg-amber-500" : "bg-zinc-800"}`}
                  >
                    <div className={`w-3 h-3 rounded-full bg-black transition-transform duration-200 transform ${autoCloseBrackets ? "translate-x-4" : "translate-x-0"}`} />
                  </button>
                </div>
              </div>
            </div>

            {/* Feature 8: Git Diff Live Visualizer */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-[8px] font-black text-amber-500">08</span>
                  <span className="font-bold text-white uppercase tracking-wider">Git Buffer telemetry</span>
                </div>
                <span className="text-[8px] font-mono text-emerald-400">UNCOMMITTED CHANGES</span>
              </div>
              <div className="p-2 bg-black/40 rounded border border-white/[0.02] font-mono text-[8px] space-y-1">
                {activeFileId ? (
                  <>
                    <div className="flex justify-between text-emerald-400">
                      <span>Injected Lines:</span>
                      <span>+{Math.floor(Math.random() * 8 + 1)}</span>
                    </div>
                    <div className="flex justify-between text-red-400">
                      <span>Removed Lines:</span>
                      <span>-{Math.floor(Math.random() * 3)}</span>
                    </div>
                  </>
                ) : (
                  <span className="text-zinc-500 block text-center">Staging is empty</span>
                )}
              </div>
            </div>

            {/* Feature 9: Editor Theme Customizer */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">09</span>
                <span className="font-bold text-white uppercase tracking-wider">Editor Theme Matrix</span>
              </div>
              <div className="flex flex-wrap gap-1">
                {["Cyberpunk Neon", "Aether Twilight", "Solarized light", "Nord Frost"].map(theme => (
                  <button
                    key={theme}
                    onClick={() => {
                      setEditorTheme(theme);
                      updateLocalStorage("aether_editor_theme", theme);
                      addLog("success", `Editor theme shifted: ${theme}`, "EDITOR");
                    }}
                    className={`px-2 py-1 text-[8px] font-black uppercase tracking-wider rounded border transition-all ${
                      editorTheme === theme 
                        ? "bg-amber-500 border-amber-500 text-black" 
                        : "bg-black/40 border-white/10 text-zinc-400 hover:text-white"
                    }`}
                  >
                    {theme}
                  </button>
                ))}
              </div>
            </div>

            {/* Feature 10: Collab Cursor Simulator */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">10</span>
                <span className="font-bold text-white uppercase tracking-wider">Active Cursor Nodes</span>
              </div>
              <div className="space-y-1 text-[9px] font-mono text-zinc-400">
                {simulatedCursors.map((c, i) => (
                  <div key={i} className="flex justify-between items-center bg-black/20 p-1 rounded">
                    <span style={{ color: c.color }} className="font-bold">{c.name}</span>
                    <span>Line {c.line} : Col {c.col}</span>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* ==================================================== */}
        {/* TAB 3: SIMULATOR & PREVIEW (10 Features) */}
        {/* ==================================================== */}
        {activeTab === "simulator" && (
          <div className="space-y-4">
            
            {/* Feature 1: Viewport Switcher */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">01</span>
                <span className="font-bold text-white uppercase tracking-wider">Viewport Presets</span>
              </div>
              <div className="grid grid-cols-4 gap-1 text-center font-bold text-[8px] tracking-wider">
                {[
                  { id: "desktop", icon: Monitor, label: "PC", w: 1280, h: 720 },
                  { id: "tablet", icon: Tablet, label: "IPAD", w: 768, h: 1024 },
                  { id: "mobile", icon: Smartphone, label: "PHONE", w: 375, h: 812 },
                  { id: "responsive", icon: Laptop, label: "RESP", w: 1024, h: 768 }
                ].map(dev => {
                  const Icon = dev.icon;
                  const isActive = simulatorDevice === dev.id;
                  return (
                    <button
                      key={dev.id}
                      onClick={() => {
                        setSimulatorDevice(dev.id as any);
                        setSimWidth(dev.w);
                        setSimHeight(dev.h);
                        addLog("info", `Preview layout updated: ${dev.label} Preset (${dev.w}x${dev.h})`, "PREVIEW");
                      }}
                      className={`py-2 rounded border flex flex-col items-center gap-1.5 transition-all ${
                        isActive 
                          ? "bg-amber-500 border-amber-500 text-black" 
                          : "bg-black/40 border-white/5 text-zinc-500 hover:text-white"
                      }`}
                    >
                      <Icon size={12} />
                      <span>{dev.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Feature 2: Collapsible Interactive Console */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-[8px] font-black text-amber-500">02</span>
                  <span className="font-bold text-white uppercase tracking-wider">Developer Console</span>
                </div>
                <button 
                  onClick={() => setConsoleLogs([])}
                  className="text-zinc-600 hover:text-white text-[8px] font-black uppercase"
                >
                  Flush
                </button>
              </div>
              <div className="p-2 bg-black/60 rounded border border-white/5 font-mono text-[8px] space-y-1 max-h-[80px] overflow-y-auto">
                {consoleLogs.map((log, i) => (
                  <div key={i} className={`flex items-start gap-1 ${log.type === "warn" ? "text-amber-400" : log.type === "error" ? "text-red-400" : "text-zinc-300"}`}>
                    <span className="text-zinc-600 shrink-0">[{log.time}]</span>
                    <span>{log.text}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Feature 3: Capture Screenshot Exporter */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">03</span>
                <span className="font-bold text-white uppercase tracking-wider">Canvas Snapshot</span>
              </div>
              <button
                onClick={() => {
                  addLog("success", "Preview Canvas Snapshot: Executed and pushed image buffer to local filesystem stream.", "PREVIEW");
                }}
                className="w-full py-1.5 bg-amber-500/10 border border-amber-500/20 text-amber-400 hover:bg-amber-500/20 rounded-lg text-center font-bold"
              >
                Capture Mock Mockup PNG
              </button>
            </div>

            {/* Feature 4: Network monitor Simulation */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">04</span>
                <span className="font-bold text-white uppercase tracking-wider">Simulated Network pipeline</span>
              </div>
              <div className="space-y-1 font-mono text-[8px] text-zinc-400">
                {simulatedNetworkRequests.map(req => (
                  <div key={req.id} className="flex justify-between bg-black/20 p-1 rounded">
                    <span>GET {req.endpoint}</span>
                    <span className="text-emerald-400">{req.status} ({req.latency}ms)</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Feature 5: Smart CSS Filter / Glow Injector */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">05</span>
                <span className="font-bold text-white uppercase tracking-wider">Aesthetic Canvas Filters</span>
              </div>
              <div className="grid grid-cols-3 gap-1">
                {["none", "grayscale(50%)", "hue-rotate(90deg)"].map(filt => (
                  <button
                    key={filt}
                    onClick={() => {
                      setCustomCSSFilter(filt);
                      addLog("success", `CSS Canvas Filter applied: ${filt}`, "PREVIEW");
                    }}
                    className={`py-1 text-[8px] font-bold border rounded truncate ${
                      customCSSFilter === filt 
                        ? "bg-amber-500/10 border-amber-500 text-amber-400" 
                        : "bg-transparent border-white/5 text-zinc-400 hover:text-white"
                    }`}
                  >
                    {filt === "none" ? "Original" : filt.split("(")[0]}
                  </button>
                ))}
              </div>
            </div>

            {/* Feature 6: State Time-travel storage viewer */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-[8px] font-black text-amber-500">06</span>
                  <span className="font-bold text-white uppercase tracking-wider">Local Storage Viewer</span>
                </div>
                <button 
                  onClick={() => {
                    setSimulatedLocalStorage({});
                    addLog("success", "Mock Simulator Storage swept clean.", "PREVIEW");
                  }}
                  className="text-red-400 hover:text-red-300 text-[8px] font-black uppercase"
                >
                  Clear
                </button>
              </div>
              <div className="space-y-1 font-mono text-[8px]">
                {Object.keys(simulatedLocalStorage).length > 0 ? (
                  Object.entries(simulatedLocalStorage).map(([k, v]) => (
                    <div key={k} className="flex justify-between bg-black/20 p-1 rounded text-zinc-400">
                      <span className="text-amber-500">{k}</span>
                      <span>"{v}"</span>
                    </div>
                  ))
                ) : (
                  <span className="text-zinc-600 block text-center">Storage Cache empty</span>
                )}
              </div>
            </div>

            {/* Feature 7: HMR Configuration Hub */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">07</span>
                <span className="font-bold text-white uppercase tracking-wider">HMR Re-build mode</span>
              </div>
              <div className="grid grid-cols-3 gap-1">
                {["manual", "debounce", "auto"].map(m => (
                  <button
                    key={m}
                    onClick={() => {
                      setHmrMode(m as any);
                      addLog("success", `HMR Refresh set to: ${m.toUpperCase()}`, "PREVIEW");
                    }}
                    className={`py-1 text-[8px] font-bold border rounded uppercase ${
                      hmrMode === m 
                        ? "bg-amber-500/10 border-amber-500 text-amber-400" 
                        : "bg-transparent border-white/5 text-zinc-400 hover:text-white"
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            {/* Feature 8: Render performance profiler */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">08</span>
                <span className="font-bold text-white uppercase tracking-wider">Rendering Performance</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-center font-mono text-[9px] text-zinc-400">
                <div className="bg-black/40 p-1.5 border border-white/[0.02] rounded">
                  <span className="text-zinc-500 block text-[7px] uppercase tracking-wider">SIM_FPS</span>
                  <span className="text-emerald-400 font-bold">{simFps} Hz</span>
                </div>
                <div className="bg-black/40 p-1.5 border border-white/[0.02] rounded">
                  <span className="text-zinc-500 block text-[7px] uppercase tracking-wider">DOM_MEM_LOAD</span>
                  <span className="text-cyan-400 font-bold">{simMemory} MB</span>
                </div>
              </div>
            </div>

            {/* Feature 9: Interactive Component Hierarchy Tree */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">09</span>
                <span className="font-bold text-white uppercase tracking-wider">Iframe Element Inspector</span>
              </div>
              <div className="p-2 bg-black/40 rounded border border-white/[0.02] font-mono text-[8px] text-zinc-500">
                <span className="text-amber-500 font-bold">&lt;App&gt;</span>
                <div className="pl-3">
                  <span className="text-cyan-400">&lt;MainHeader /&gt;</span>
                  <div className="pl-3">
                    <span className="text-zinc-400">&lt;div className="tabs" /&gt;</span>
                  </div>
                  <span className="text-cyan-400">&lt;PreviewPane /&gt;</span>
                </div>
              </div>
            </div>

            {/* Feature 10: QR Code Share Generator */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">10</span>
                <span className="font-bold text-white uppercase tracking-wider">QR Code Share Node</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-white flex items-center justify-center rounded-lg p-1">
                  {/* Standard simulated block-qr code rendering using simple grid lines */}
                  <div className="grid grid-cols-4 gap-0.5 w-full h-full">
                    {[1,0,1,1, 0,1,0,0, 1,1,1,0, 0,0,1,1].map((b, i) => (
                      <div key={i} className={`rounded-[1px] ${b === 1 ? 'bg-black' : 'bg-white'}`} />
                    ))}
                  </div>
                </div>
                <div className="flex-1 text-[8px] text-zinc-400 uppercase tracking-wide leading-relaxed">
                  <p className="font-bold text-white">Scan to mirror</p>
                  <p>Open physical smart phone camera on local wifi zone.</p>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* ==================================================== */}
        {/* TAB 4: DIAGNOSTICS & SYSTEM HEALTH (10 Features) */}
        {/* ==================================================== */}
        {activeTab === "diagnostics" && (
          <div className="space-y-4">
            
            {/* Feature 1: Thread Allocation */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-[8px] font-black text-amber-500">01</span>
                  <span className="font-bold text-white uppercase tracking-wider">Thread Allocation</span>
                </div>
                <span className="text-[9px] font-mono font-bold text-amber-400">{allocatedThreads} Workers</span>
              </div>
              <input 
                type="range" 
                min={1} 
                max={16} 
                step={1}
                value={allocatedThreads}
                onChange={(e) => {
                  setAllocatedThreads(Number(e.target.value));
                  addLog("system", `System thread allotment altered: ${e.target.value} concurrent Web Workers active.`, "SYSTEM");
                }}
                className="w-full accent-amber-500 mb-1"
              />
              <div className="flex justify-between text-[7px] font-mono text-zinc-500">
                <span>Min: 1</span>
                <span>Max: 16 threads</span>
              </div>
            </div>

            {/* Feature 2: Cyberpunk Heatmap Diagnostic */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">02</span>
                <span className="font-bold text-white uppercase tracking-wider">System Temperature Node</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-center font-mono text-[9px]">
                <div className="p-1.5 bg-black/40 rounded border border-white/[0.02]">
                  <span className="text-zinc-500 block text-[7px] uppercase tracking-wider">Core Temperature</span>
                  <span className={`font-bold ${diagTemp > 50 ? 'text-red-400' : 'text-amber-400'}`}>{diagTemp.toFixed(1)} °C</span>
                </div>
                <div className="p-1.5 bg-black/40 rounded border border-white/[0.02]">
                  <span className="text-zinc-500 block text-[7px] uppercase tracking-wider">GPU Fan Speed</span>
                  <span className="text-cyan-400 font-bold">{fanSpeed} RPM</span>
                </div>
              </div>
            </div>

            {/* Feature 3: Extreme Memory GC */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">03</span>
                <span className="font-bold text-white uppercase tracking-wider">Extreme Memory Purge</span>
              </div>
              <button
                onClick={handleRunGC}
                disabled={isGCRunning}
                className="w-full py-2 bg-amber-500 text-black hover:bg-amber-400 disabled:bg-zinc-800 disabled:text-zinc-500 rounded-lg text-center font-black uppercase tracking-widest"
              >
                {isGCRunning ? "Flushing registers..." : "Purge diagnostics heap"}
              </button>
            </div>

            {/* Feature 4: Latency Radar */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">04</span>
                <span className="font-bold text-white uppercase tracking-wider">Endpoint Ping Diagnostics</span>
              </div>
              <div className="grid grid-cols-3 gap-1 font-mono text-[8px] text-zinc-400 text-center">
                {Object.entries(pingTimes).map(([server, ping]) => (
                  <div key={server} className="p-1 rounded bg-black/30 border border-white/[0.02]">
                    <span className="text-zinc-500 block">{server}</span>
                    <span className="text-emerald-400 font-bold">{ping}ms</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Feature 5: Browser Telemetry Terminal */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">05</span>
                <span className="font-bold text-white uppercase tracking-wider">Client Browser Diagnostics</span>
              </div>
              <div className="p-2 bg-black/40 rounded border border-white/[0.02] font-mono text-[8px] text-zinc-500 space-y-1">
                <div className="flex justify-between">
                  <span>Concurrences:</span>
                  <span className="text-zinc-300">{navigator.hardwareConcurrency || 8} Logical CPUs</span>
                </div>
                <div className="flex justify-between">
                  <span>Agent Platform:</span>
                  <span className="text-zinc-300 truncate max-w-[140px]">{navigator.platform}</span>
                </div>
              </div>
            </div>

            {/* Feature 6: Connectivity State Emulator */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">06</span>
                <span className="font-bold text-white uppercase tracking-wider">Connectivity Override</span>
              </div>
              <button
                onClick={() => {
                  const targetState = simulatedNetworkState === "online" ? "offline" : "online";
                  setSimulatedNetworkState(targetState);
                  addLog(targetState === "online" ? "success" : "warn", `Aether Network State Overridden: ${targetState.toUpperCase()}`, "SYSTEM");
                }}
                className={`w-full py-1.5 rounded-lg border font-bold uppercase transition-all flex items-center justify-center gap-2 ${
                  simulatedNetworkState === "online" 
                    ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/20" 
                    : "bg-red-500/10 border-red-500/20 text-red-400 hover:bg-red-500/20"
                }`}
              >
                {simulatedNetworkState === "online" ? <Wifi size={12} /> : <WifiOff size={12} />}
                <span>Set {simulatedNetworkState === "online" ? "Offline Mode" : "Online Mode"}</span>
              </button>
            </div>

            {/* Feature 7: Filterable diagnostic feed */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">07</span>
                <span className="font-bold text-white uppercase tracking-wider">Internal Diagnostics logs</span>
              </div>
              <div className="p-2 bg-black/60 rounded border border-white/5 font-mono text-[8px] text-zinc-400 space-y-1 max-h-[80px] overflow-y-auto">
                {diagnosticsLogs.map((log, i) => (
                  <p key={i} className="truncate">{log}</p>
                ))}
              </div>
            </div>

            {/* Feature 8: Sound sweeps synthesizer */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-[8px] font-black text-amber-500">08</span>
                  <span className="font-bold text-white uppercase tracking-wider">Audio Diagnostics</span>
                </div>
                <button 
                  onClick={triggerAudioDiagnostic}
                  className="px-2 py-0.5 bg-amber-500 text-black font-black text-[8px] rounded uppercase hover:bg-amber-400"
                >
                  Sweep
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2 mb-2">
                <div>
                  <span className="text-[8px] text-zinc-500 block mb-1 font-mono">Wave Type</span>
                  <select 
                    value={audioOscType}
                    onChange={(e) => setAudioOscType(e.target.value as any)}
                    className="w-full bg-black border border-white/10 rounded p-1 text-[8px] focus:outline-none focus:border-amber-500"
                  >
                    <option value="sine">Sine</option>
                    <option value="square">Square</option>
                    <option value="sawtooth">Sawtooth</option>
                  </select>
                </div>
                <div>
                  <span className="text-[8px] text-zinc-500 block mb-1 font-mono">Frequency</span>
                  <input 
                    type="number" 
                    min={100} 
                    max={2000} 
                    step={100}
                    value={audioOscillatorFreq}
                    onChange={(e) => setAudioOscillatorFreq(Number(e.target.value))}
                    className="w-full bg-black border border-white/10 rounded p-1 text-[8px] focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>
              </div>
            </div>

            {/* Feature 9: Power balancing settings */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">09</span>
                <span className="font-bold text-white uppercase tracking-wider">Core Energy Mode</span>
              </div>
              <div className="grid grid-cols-3 gap-1">
                {[
                  { id: "eco", label: "ECO Balanced" },
                  { id: "turbo", label: "TURBO OVERCLOCK" },
                  { id: "battery", label: "POWER SAVER" }
                ].map(prof => (
                  <button
                    key={prof.id}
                    onClick={() => {
                      setPerformanceProfile(prof.id as any);
                      addLog("success", `Power profile shifted: ${prof.label}`, "SYSTEM");
                    }}
                    className={`py-1 text-[8px] font-bold border rounded truncate uppercase ${
                      performanceProfile === prof.id 
                        ? "bg-amber-500/10 border-amber-500 text-amber-400 shadow-[0_0_10px_rgba(245,158,11,0.1)]" 
                        : "bg-transparent border-white/5 text-zinc-400 hover:text-white"
                    }`}
                  >
                    {prof.id}
                  </button>
                ))}
              </div>
            </div>

            {/* Feature 10: Diagnostic Report exporter */}
            <div className="bg-white/[0.02] border border-white/5 p-3 rounded-xl">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-[8px] font-black text-amber-500">10</span>
                <span className="font-bold text-white uppercase tracking-wider">Package Diagnostics</span>
              </div>
              <button
                onClick={() => {
                  const report = {
                    timestamp: new Date().toLocaleString(),
                    activeSessionId,
                    filesCount: files.length,
                    activeModel: selectedModel,
                    allocatedThreads,
                    gpuFanSpeed: fanSpeed,
                    coreTemperature: `${diagTemp.toFixed(1)} °C`,
                    performanceProfile,
                    networkState: simulatedNetworkState,
                    telemetryBudget: `${tokenUsed} / ${tokenBudget}`
                  };
                  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(report, null, 2));
                  const dlAnchor = document.createElement('a');
                  dlAnchor.setAttribute("href", dataStr);
                  dlAnchor.setAttribute("download", `aether-diagnostics-${activeSessionId || "system"}.json`);
                  document.body.appendChild(dlAnchor);
                  dlAnchor.click();
                  dlAnchor.remove();
                  addLog("success", "Diagnostics Report: Bundled system logs, thread matrix, and telemetry stats successfully.", "SYSTEM");
                }}
                className="w-full py-1.5 bg-amber-500/10 border border-amber-500/20 text-amber-400 hover:bg-amber-500/20 rounded-lg text-center font-bold"
              >
                Export Diagnostics Report JSON
              </button>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
