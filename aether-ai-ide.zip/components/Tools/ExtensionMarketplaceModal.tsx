import React, { useState, useEffect } from 'react';
import { X, Search, Download, Check, Sparkles, Layers, Palette, Key, Code, ShieldCheck } from 'lucide-react';
import { extensionManager, AetherExtension } from '../../services/extensionSystem';

interface ExtensionMarketplaceModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ExtensionMarketplaceModal: React.FC<ExtensionMarketplaceModalProps> = ({ isOpen, onClose }) => {
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'theme' | 'keymap' | 'snippet' | 'linter'>('all');
  const [extensions, setExtensions] = useState<AetherExtension[]>(extensionManager.getExtensions());

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
    }
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleToggle = (id: string) => {
    extensionManager.toggleInstall(id);
    setExtensions([...extensionManager.getExtensions()]);
  };

  const filtered = extensions.filter(e => {
    const matchesTab = activeTab === 'all' || e.category === activeTab;
    const matchesSearch = e.name.toLowerCase().includes(search.toLowerCase()) || e.description.toLowerCase().includes(search.toLowerCase());
    return matchesTab && matchesSearch;
  });

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        className="w-full max-w-4xl h-[680px] bg-aether-bg border border-aether-border rounded-xl shadow-2xl flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="px-6 py-4 border-b border-aether-border flex items-center justify-between bg-aether-panel/50">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-aether-accent/10 border border-aether-accent/30 text-aether-accent">
              <Layers size={20} />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
                Aether Extension Marketplace
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  Open Engine
                </span>
              </h2>
              <p className="text-xs text-slate-400">Install community themes, keymaps, snippet packs, and linters</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Controls Bar */}
        <div className="px-6 py-3 border-b border-aether-border bg-aether-panel/30 flex items-center gap-4">
          <div className="relative flex-1">
            <Search size={15} className="absolute left-3 top-2.5 text-slate-400" />
            <input 
              type="text"
              placeholder="Search extensions, themes, keymaps..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-aether-bg border border-aether-border rounded-lg pl-9 pr-4 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-aether-accent"
            />
          </div>

          <div className="flex items-center gap-1 bg-aether-bg p-1 rounded-lg border border-aether-border text-xs">
            {(['all', 'theme', 'keymap', 'snippet', 'linter'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-3 py-1 rounded-md capitalize font-medium transition-all ${
                  activeTab === tab 
                    ? 'bg-aether-accent text-slate-950 shadow-sm font-bold' 
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Grid List */}
        <div className="flex-1 overflow-y-auto p-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map(ext => (
            <div 
              key={ext.id}
              className="p-4 rounded-xl border border-aether-border bg-aether-panel/40 hover:border-aether-accent/50 transition-all flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div className="flex items-center gap-3">
                    <span className="text-2xl p-2 rounded-lg bg-slate-800/80 border border-slate-700/50">
                      {ext.icon}
                    </span>
                    <div>
                      <h3 className="text-sm font-bold text-slate-100 group-hover:text-aether-accent transition-colors">
                        {ext.name}
                      </h3>
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono mt-0.5">
                        <span>v{ext.version}</span>
                        <span>•</span>
                        <span>by {ext.author}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleToggle(ext.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                      ext.installed
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 hover:bg-red-500/10 hover:text-red-400 hover:border-red-500/30'
                        : 'bg-aether-accent text-slate-950 hover:bg-cyan-400 shadow-md'
                    }`}
                  >
                    {ext.installed ? (
                      <>
                        <Check size={13} /> Installed
                      </>
                    ) : (
                      <>
                        <Download size={13} /> Install
                      </>
                    )}
                  </button>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed mb-3">
                  {ext.description}
                </p>
              </div>

              <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 pt-2 border-t border-slate-800/60">
                <span className="uppercase px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                  {ext.category}
                </span>
                <span className="flex items-center gap-1 text-emerald-400">
                  <ShieldCheck size={12} /> Verified Extension
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-aether-border bg-aether-panel/50 flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1.5 text-slate-300">
            <Sparkles size={14} className="text-aether-accent" />
            Active Extensions: {extensions.filter(e => e.installed).length} / {extensions.length}
          </span>
          <span className="font-mono text-[10px] text-slate-500">Aether Open Extension Architecture v2.0</span>
        </div>

      </div>
    </div>
  );
};
