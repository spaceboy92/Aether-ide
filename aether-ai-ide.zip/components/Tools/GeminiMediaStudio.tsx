import React, { useState } from "react";
import {
  Sparkles,
  Video,
  Image as ImageIcon,
  Download,
  Loader2,
  Check,
  RefreshCw,
  Wand2,
  Film,
  Maximize2,
  Layers,
  Upload,
  Play,
  Share2,
  FolderPlus,
  Volume2,
  VolumeX,
  Globe,
  Search,
  ExternalLink,
  Mic
} from "lucide-react";
import { FileNode } from "../../types";

interface GeminiMediaStudioProps {
  files?: FileNode[];
  setFiles?: React.Dispatch<React.SetStateAction<FileNode[]>>;
  onSaveToWorkspace?: (filename: string, content: string) => void;
}

export const GeminiMediaStudio: React.FC<GeminiMediaStudioProps> = ({
  files,
  setFiles,
  onSaveToWorkspace
}) => {
  const [activeTab, setActiveTab] = useState<"image" | "video" | "audio" | "search">("image");

  // Image Generation State
  const [imagePrompt, setImagePrompt] = useState("A futuristic cyberpunk city with neon reflections in 3D WebGL style");
  const [aspectRatio, setAspectRatio] = useState("1:1");
  const [isHighQuality, setIsHighQuality] = useState(false);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [imageError, setImageError] = useState<string | null>(null);

  // Video Generation State
  const [videoPrompt, setVideoPrompt] = useState("A neon hologram cat driving a fast hovercar through a sci-fi tunnel");
  const [videoAspectRatio, setVideoAspectRatio] = useState("16:9");
  const [videoResolution, setVideoResolution] = useState("720p");
  const [isGeneratingVideo, setIsGeneratingVideo] = useState(false);
  const [videoStatusText, setVideoStatusText] = useState("");
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [videoError, setVideoError] = useState<string | null>(null);

  // Audio / Speech State
  const [ttsText, setTtsText] = useState("Welcome to Aether AI Studio. All neural systems and Gemini AI models are fully operational.");
  const [ttsVoice, setTtsVoice] = useState("Kore");
  const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);
  const [audioPlaying, setAudioPlaying] = useState(false);

  // Search Grounding State
  const [searchQuery, setSearchQuery] = useState("Latest React 19 features and Vite 6 updates");
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<{ text: string; sources: { title: string; uri: string }[] } | null>(null);
  const [searchError, setSearchError] = useState<string | null>(null);

  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  // Generate Image Handler
  const handleGenerateImage = async () => {
    if (!imagePrompt.trim()) return;
    setIsGeneratingImage(true);
    setImageError(null);

    try {
      const response = await fetch("/api/ai/image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: imagePrompt,
          aspectRatio,
          highQuality: isHighQuality
        })
      });

      const data = await response.json();
      if (!response.ok || data.error) {
        throw new Error(data.error || "Failed to generate image");
      }

      setGeneratedImageUrl(data.imageUrl);
      showToast("Gemini image generated successfully!");
    } catch (err: any) {
      setImageError(err.message || "Image generation failed");
    } finally {
      setIsGeneratingImage(false);
    }
  };

  // Generate Video Handler
  const handleGenerateVideo = async () => {
    if (!videoPrompt.trim()) return;
    setIsGeneratingVideo(true);
    setVideoError(null);
    setVideoUrl(null);
    setVideoStatusText("Initializing Veo 3D / Omni video synthesis engine...");

    try {
      const initRes = await fetch("/api/video/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: videoPrompt,
          aspectRatio: videoAspectRatio,
          resolution: videoResolution
        })
      });

      const initData = await initRes.json();
      if (!initRes.ok || initData.error) {
        throw new Error(initData.error || "Video initialization failed");
      }

      const operationName = initData.operationName;
      setVideoStatusText("Generating video frames... (Polling Gemini API)");

      let done = false;
      let attempts = 0;

      while (!done && attempts < 30) {
        await new Promise((r) => setTimeout(r, 6000));
        attempts++;

        const statusRes = await fetch("/api/video/status", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ operationName })
        });

        const statusData = await statusRes.json();
        setVideoStatusText(`Synthesizing frame sequence... Progress step ${attempts}/30`);

        if (statusData.done) {
          done = true;
          if (statusData.error) {
            throw new Error(statusData.error.message || "Video rendering failed");
          }
        }
      }

      setVideoStatusText("Fetching final MP4 video stream...");
      const downloadRes = await fetch("/api/video/download", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ operationName })
      });

      if (!downloadRes.ok) {
        throw new Error("Failed to download generated video");
      }

      const blob = await downloadRes.blob();
      const localUrl = URL.createObjectURL(blob);
      setVideoUrl(localUrl);
      showToast("Google Veo Video generated successfully!");
    } catch (err: any) {
      setVideoError(err.message || "Video generation failed");
    } finally {
      setIsGeneratingVideo(false);
      setVideoStatusText("");
    }
  };

  // Generate TTS Audio Handler
  const handleGenerateTTS = async () => {
    if (!ttsText.trim()) return;
    setIsGeneratingAudio(true);
    setAudioError(null);

    try {
      const response = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: ttsText, voice: ttsVoice })
      });

      const data = await response.json();
      if (!response.ok || data.error) {
        throw new Error(data.error || "Neural speech generation failed");
      }

      if (data.audio) {
        const binaryString = atob(data.audio);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        const view = new DataView(bytes.buffer);
        for (let i = 0; i < len; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }

        const numSamples = len / 2;
        const float32Data = new Float32Array(numSamples);
        for (let i = 0; i < numSamples; i++) {
          const sample = view.getInt16(i * 2, true);
          float32Data[i] = sample / 32768.0;
        }

        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        const audioCtx = new AudioContextClass();
        const audioBuffer = audioCtx.createBuffer(1, numSamples, 24000);
        audioBuffer.getChannelData(0).set(float32Data);

        const source = audioCtx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioCtx.destination);
        setAudioPlaying(true);
        source.onended = () => setAudioPlaying(false);
        source.start();

        showToast("Gemini 24kHz neural speech generated & playing!");
      }
    } catch (err: any) {
      setAudioError(err.message || "Speech synthesis failed");
    } finally {
      setIsGeneratingAudio(false);
    }
  };

  // Grounded Search Handler
  const handleGroundedSearch = async () => {
    if (!searchQuery.trim()) return;
    setIsSearching(true);
    setSearchError(null);
    setSearchResults(null);

    try {
      const response = await fetch("/api/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: searchQuery })
      });

      const data = await response.json();
      if (!response.ok || data.error) {
        throw new Error(data.error || "Search grounding failed");
      }

      setSearchResults({
        text: data.text,
        sources: data.sources || []
      });
      showToast("Grounded search results fetched!");
    } catch (err: any) {
      setSearchError(err.message || "Search failed");
    } finally {
      setIsSearching(false);
    }
  };

  // Save generated asset to Workspace
  const handleSaveToWorkspace = (type: "image" | "video") => {
    const filename = type === "image" ? `generated_asset_${Date.now()}.png` : `generated_video_${Date.now()}.mp4`;
    const content = type === "image" ? (generatedImageUrl || "") : (videoUrl || "");

    if (onSaveToWorkspace) {
      onSaveToWorkspace(filename, content);
    } else if (setFiles) {
      const newFile: FileNode = {
        id: `asset_${Date.now()}`,
        name: filename,
        content: content,
        language: type === "image" ? "png" : "mp4",
        lastModified: Date.now()
      };
      setFiles((prev) => [...prev, newFile]);
    }
    showToast(`Saved ${filename} to workspace files!`);
  };

  return (
    <div className="w-full h-full bg-zinc-950 text-zinc-100 flex flex-col font-sans overflow-hidden border border-zinc-900 rounded-xl">
      {/* Header Tabs */}
      <div className="h-12 bg-zinc-900/80 border-b border-zinc-800 px-4 flex items-center justify-between shrink-0 overflow-x-auto custom-scrollbar">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab("image")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === "image"
                ? "bg-sky-500/20 text-sky-400 border border-sky-500/30"
                : "text-zinc-500 hover:text-zinc-300"
            }`}
          >
            <ImageIcon size={14} /> Image Gen
          </button>
          <button
            onClick={() => setActiveTab("video")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === "video"
                ? "bg-purple-500/20 text-purple-400 border border-purple-500/30"
                : "text-zinc-500 hover:text-zinc-300"
            }`}
          >
            <Film size={14} /> Google Veo Video
          </button>
          <button
            onClick={() => setActiveTab("audio")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === "audio"
                ? "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                : "text-zinc-500 hover:text-zinc-300"
            }`}
          >
            <Volume2 size={14} /> Neural Voice TTS
          </button>
          <button
            onClick={() => setActiveTab("search")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === "search"
                ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                : "text-zinc-500 hover:text-zinc-300"
            }`}
          >
            <Globe size={14} /> Web Search Grounding
          </button>
        </div>

        <span className="text-[10px] font-mono bg-zinc-800/80 text-zinc-400 px-2 py-1 rounded-lg shrink-0 hidden sm:inline-block">
          @google/genai Full AI Suite
        </span>
      </div>

      {/* Main Studio Area */}
      <div className="flex-1 p-4 overflow-y-auto custom-scrollbar relative">
        {toastMsg && (
          <div className="absolute top-4 right-4 z-50 bg-emerald-500 text-black px-4 py-2 rounded-xl text-xs font-black uppercase tracking-wider shadow-2xl flex items-center gap-2">
            <Check size={14} /> {toastMsg}
          </div>
        )}

        {activeTab === "image" && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-5 space-y-4 shadow-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sky-400 text-xs font-black uppercase tracking-wider">
                  <Wand2 size={16} /> Gemini Flash Image Studio
                </div>
                <div className="flex items-center gap-2">
                  <label className="text-[10px] text-zinc-400 font-bold uppercase flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={isHighQuality}
                      onChange={(e) => setIsHighQuality(e.target.checked)}
                      className="accent-sky-500"
                    />
                    High Quality 1K
                  </label>
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase tracking-wider text-zinc-500 block mb-1">
                  Image Prompt / Asset Description
                </label>
                <textarea
                  value={imagePrompt}
                  onChange={(e) => setImagePrompt(e.target.value)}
                  rows={3}
                  className="w-full bg-black/60 border border-zinc-800 rounded-xl p-3 text-zinc-100 text-xs font-mono focus:outline-none focus:border-sky-500"
                  placeholder="Describe the 2D texture, 3D model skin, UI icon, or concept art..."
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase tracking-wider text-zinc-500">
                    Aspect Ratio:
                  </span>
                  {["1:1", "16:9", "9:16", "4:3"].map((ratio) => (
                    <button
                      key={ratio}
                      onClick={() => setAspectRatio(ratio)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-mono ${
                        aspectRatio === ratio
                          ? "bg-sky-500 text-black font-bold"
                          : "bg-zinc-800 text-zinc-400 hover:text-zinc-200"
                      }`}
                    >
                      {ratio}
                    </button>
                  ))}
                </div>

                <button
                  onClick={handleGenerateImage}
                  disabled={isGeneratingImage}
                  className="px-6 py-2.5 bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-black font-black text-xs uppercase tracking-wider rounded-xl transition-all flex items-center gap-2 cursor-pointer"
                >
                  {isGeneratingImage ? <Loader2 size={15} className="animate-spin" /> : <Sparkles size={15} />}
                  {isGeneratingImage ? "Generating Image..." : "Generate Image"}
                </button>
              </div>

              {imageError && (
                <div className="p-3 bg-red-500/10 border border-red-500/30 text-red-400 text-xs rounded-xl font-mono">
                  Error: {imageError}
                </div>
              )}
            </div>

            {generatedImageUrl && (
              <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-5 flex flex-col items-center gap-4">
                <div className="max-w-xl max-h-[450px] overflow-hidden rounded-xl border border-zinc-800 bg-black/60 shadow-2xl">
                  <img src={generatedImageUrl} alt="Generated Asset" className="w-full h-auto object-contain" />
                </div>
                <div className="flex items-center gap-3">
                  <a
                    href={generatedImageUrl}
                    download="gemini_generated_asset.png"
                    className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-bold uppercase rounded-xl flex items-center gap-1.5"
                  >
                    <Download size={14} /> Download PNG
                  </a>
                  <button
                    onClick={() => handleSaveToWorkspace("image")}
                    className="px-4 py-2 bg-sky-500/20 text-sky-400 border border-sky-500/30 hover:bg-sky-500/30 text-xs font-bold uppercase rounded-xl flex items-center gap-1.5 cursor-pointer"
                  >
                    <FolderPlus size={14} /> Save to Workspace
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === "video" && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-5 space-y-4 shadow-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-purple-400 text-xs font-black uppercase tracking-wider">
                  <Film size={16} /> Google Veo Video Generator
                </div>
                <span className="text-[10px] font-mono text-zinc-500">
                  Model: veo-3.1-lite-generate-preview
                </span>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase tracking-wider text-zinc-500 block mb-1">
                  Video Scene Description
                </label>
                <textarea
                  value={videoPrompt}
                  onChange={(e) => setVideoPrompt(e.target.value)}
                  rows={3}
                  className="w-full bg-black/60 border border-zinc-800 rounded-xl p-3 text-zinc-100 text-xs font-mono focus:outline-none focus:border-purple-500"
                  placeholder="Describe camera movement, lighting, subject action, and cinematic style..."
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-black uppercase tracking-wider text-zinc-500">
                      Aspect:
                    </span>
                    {["16:9", "9:16"].map((ratio) => (
                      <button
                        key={ratio}
                        onClick={() => setVideoAspectRatio(ratio)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-mono ${
                          videoAspectRatio === ratio
                            ? "bg-purple-500 text-black font-bold"
                            : "bg-zinc-800 text-zinc-400 hover:text-zinc-200"
                        }`}
                      >
                        {ratio}
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-black uppercase tracking-wider text-zinc-500">
                      Res:
                    </span>
                    {["720p", "1080p"].map((res) => (
                      <button
                        key={res}
                        onClick={() => setVideoResolution(res)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-mono ${
                          videoResolution === res
                            ? "bg-purple-500 text-black font-bold"
                            : "bg-zinc-800 text-zinc-400 hover:text-zinc-200"
                        }`}
                      >
                        {res}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={handleGenerateVideo}
                  disabled={isGeneratingVideo}
                  className="px-6 py-2.5 bg-purple-500 hover:bg-purple-400 disabled:opacity-50 text-black font-black text-xs uppercase tracking-wider rounded-xl transition-all flex items-center gap-2 cursor-pointer"
                >
                  {isGeneratingVideo ? <Loader2 size={15} className="animate-spin" /> : <Video size={15} />}
                  {isGeneratingVideo ? "Synthesizing Video..." : "Generate Veo Video"}
                </button>
              </div>

              {isGeneratingVideo && (
                <div className="p-4 bg-purple-500/10 border border-purple-500/30 rounded-xl text-purple-300 text-xs font-mono flex items-center gap-3">
                  <Loader2 size={18} className="animate-spin shrink-0 text-purple-400" />
                  <span>{videoStatusText}</span>
                </div>
              )}

              {videoError && (
                <div className="p-3 bg-red-500/10 border border-red-500/30 text-red-400 text-xs rounded-xl font-mono">
                  Error: {videoError}
                </div>
              )}
            </div>

            {videoUrl && (
              <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-5 flex flex-col items-center gap-4">
                <div className="max-w-2xl overflow-hidden rounded-xl border border-zinc-800 bg-black shadow-2xl">
                  <video src={videoUrl} controls autoPlay loop className="w-full h-auto rounded-xl" />
                </div>

                <div className="flex items-center gap-3">
                  <a
                    href={videoUrl}
                    download="veo_generated_video.mp4"
                    className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-bold uppercase rounded-xl flex items-center gap-1.5"
                  >
                    <Download size={14} /> Download MP4
                  </a>
                  <button
                    onClick={() => handleSaveToWorkspace("video")}
                    className="px-4 py-2 bg-purple-500/20 text-purple-400 border border-purple-500/30 hover:bg-purple-500/30 text-xs font-bold uppercase rounded-xl flex items-center gap-1.5 cursor-pointer"
                  >
                    <FolderPlus size={14} /> Save Video to Workspace
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === "audio" && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-5 space-y-4 shadow-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-amber-400 text-xs font-black uppercase tracking-wider">
                  <Volume2 size={16} /> Gemini 3.1 Neural Voice Synthesizer
                </div>
                <span className="text-[10px] font-mono text-zinc-500">
                  Model: gemini-3.1-flash-tts-preview (24kHz PCM)
                </span>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase tracking-wider text-zinc-500 block mb-1">
                  Text to Synthesize
                </label>
                <textarea
                  value={ttsText}
                  onChange={(e) => setTtsText(e.target.value)}
                  rows={3}
                  className="w-full bg-black/60 border border-zinc-800 rounded-xl p-3 text-zinc-100 text-xs font-mono focus:outline-none focus:border-amber-500"
                  placeholder="Enter script, instructions, or narration..."
                />
              </div>

              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-black uppercase tracking-wider text-zinc-500">
                    Voice Actor:
                  </span>
                  {["Kore", "Puck", "Charon", "Fenrir", "Zephyr"].map((voice) => (
                    <button
                      key={voice}
                      onClick={() => setTtsVoice(voice)}
                      className={`px-3 py-1 rounded-lg text-xs font-mono ${
                        ttsVoice === voice
                          ? "bg-amber-500 text-black font-bold"
                          : "bg-zinc-800 text-zinc-400 hover:text-zinc-200"
                      }`}
                    >
                      {voice}
                    </button>
                  ))}
                </div>

                <button
                  onClick={handleGenerateTTS}
                  disabled={isGeneratingAudio}
                  className="px-6 py-2.5 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-black font-black text-xs uppercase tracking-wider rounded-xl transition-all flex items-center gap-2 cursor-pointer"
                >
                  {isGeneratingAudio ? <Loader2 size={15} className="animate-spin" /> : <Mic size={15} />}
                  {isGeneratingAudio ? "Synthesizing Speech..." : "Synthesize & Play Voice"}
                </button>
              </div>

              {audioError && (
                <div className="p-3 bg-red-500/10 border border-red-500/30 text-red-400 text-xs rounded-xl font-mono">
                  Error: {audioError}
                </div>
              )}

              {audioPlaying && (
                <div className="p-3 bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs rounded-xl font-mono flex items-center gap-2 animate-pulse">
                  <Volume2 size={16} /> Playing 24kHz Neural Audio output...
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === "search" && (
          <div className="max-w-4xl mx-auto space-y-6">
            <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-5 space-y-4 shadow-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-emerald-400 text-xs font-black uppercase tracking-wider">
                  <Globe size={16} /> Real-Time Gemini Web Search Grounding
                </div>
                <span className="text-[10px] font-mono text-zinc-500">
                  Tool: googleSearch
                </span>
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleGroundedSearch()}
                  className="flex-1 bg-black/60 border border-zinc-800 rounded-xl px-4 py-2.5 text-zinc-100 text-xs font-mono focus:outline-none focus:border-emerald-500"
                  placeholder="Search live docs, API specs, latest tech news..."
                />
                <button
                  onClick={handleGroundedSearch}
                  disabled={isSearching}
                  className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-black font-black text-xs uppercase tracking-wider rounded-xl transition-all flex items-center gap-2 cursor-pointer"
                >
                  {isSearching ? <Loader2 size={15} className="animate-spin" /> : <Search size={15} />}
                  {isSearching ? "Searching..." : "Search Web"}
                </button>
              </div>

              {searchError && (
                <div className="p-3 bg-red-500/10 border border-red-500/30 text-red-400 text-xs rounded-xl font-mono">
                  Error: {searchError}
                </div>
              )}
            </div>

            {searchResults && (
              <div className="bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6 space-y-4 shadow-xl">
                <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-2">
                  <Sparkles size={14} /> Grounded Insights & Synthesis
                </h4>
                <div className="text-xs text-zinc-200 leading-relaxed font-sans whitespace-pre-wrap bg-black/40 p-4 rounded-xl border border-zinc-800/80">
                  {searchResults.text}
                </div>

                {searchResults.sources.length > 0 && (
                  <div className="space-y-2 pt-2 border-t border-zinc-800">
                    <span className="text-[10px] font-black uppercase tracking-wider text-zinc-500 block">
                      Live Grounded Sources ({searchResults.sources.length}):
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {searchResults.sources.map((src, idx) => (
                        <a
                          key={idx}
                          href={src.uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-emerald-400 border border-emerald-500/20 text-[11px] rounded-lg flex items-center gap-1.5 truncate max-w-md"
                        >
                          <ExternalLink size={12} className="shrink-0" />
                          <span className="truncate">{src.title || src.uri}</span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
