import React, { useState } from 'react';
import { 
  Palette, 
  Sparkles, 
  Copy, 
  Check, 
  Code2, 
  FolderPlus, 
  Layers, 
  Sun, 
  Moon, 
  Sliders, 
  Eye, 
  Wand2,
  Box,
  Type,
  LayoutGrid
} from 'lucide-react';
import { FileNode } from '../../types';

interface UIComponentStudioProps {
  onAddFileToWorkspace?: (file: FileNode) => void;
}

export const UIComponentStudio: React.FC<UIComponentStudioProps> = ({ onAddFileToWorkspace }) => {
  const [componentType, setComponentType] = useState<'button' | 'card' | 'badge' | 'modal' | 'input'>('button');
  
  // Customization State
  const [text, setText] = useState('Launch Neural Engine');
  const [variant, setVariant] = useState<'gradient' | 'solid' | 'outline' | 'glass'>('gradient');
  const [primaryColor, setPrimaryColor] = useState<'cyan' | 'purple' | 'emerald' | 'amber' | 'rose' | 'indigo'>('cyan');
  const [borderRadius, setBorderRadius] = useState<'rounded-none' | 'rounded-lg' | 'rounded-xl' | 'rounded-2xl' | 'rounded-full'>('rounded-xl');
  const [shadow, setShadow] = useState<'none' | 'sm' | 'lg' | 'glow'>('glow');
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [copied, setCopied] = useState(false);

  // Generate Tailwind Class string
  const getTailwindClasses = () => {
    let classes = 'font-semibold transition-all cursor-pointer flex items-center justify-center gap-2 ';

    // Size & Padding based on component type
    if (componentType === 'button') {
      classes += 'px-5 py-2.5 text-xs uppercase tracking-wider ';
    } else if (componentType === 'card') {
      classes += 'p-6 text-left flex-col items-start gap-3 w-full max-w-sm ';
    } else if (componentType === 'badge') {
      classes += 'px-2.5 py-1 text-[10px] uppercase font-bold tracking-widest font-mono ';
    } else if (componentType === 'input') {
      classes += 'px-4 py-2.5 text-xs w-full max-w-sm outline-none ';
    } else if (componentType === 'modal') {
      classes += 'p-6 text-left flex-col items-start gap-4 w-full max-w-md ';
    }

    // Border Radius
    classes += `${borderRadius} `;

    // Color & Variant
    if (variant === 'gradient') {
      if (primaryColor === 'cyan') classes += 'bg-gradient-to-r from-cyan-500 to-blue-600 text-black hover:from-cyan-400 hover:to-blue-500 ';
      else if (primaryColor === 'purple') classes += 'bg-gradient-to-r from-purple-500 to-indigo-600 text-white hover:from-purple-400 hover:to-indigo-500 ';
      else if (primaryColor === 'emerald') classes += 'bg-gradient-to-r from-emerald-400 to-teal-600 text-black hover:from-emerald-300 hover:to-teal-500 ';
      else if (primaryColor === 'amber') classes += 'bg-gradient-to-r from-amber-400 to-orange-500 text-black hover:from-amber-300 hover:to-orange-400 ';
      else if (primaryColor === 'rose') classes += 'bg-gradient-to-r from-rose-500 to-pink-600 text-white hover:from-rose-400 hover:to-pink-500 ';
      else classes += 'bg-gradient-to-r from-indigo-500 to-violet-600 text-white hover:from-indigo-400 hover:to-violet-500 ';
    } else if (variant === 'solid') {
      if (primaryColor === 'cyan') classes += 'bg-cyan-500 text-black hover:bg-cyan-400 ';
      else if (primaryColor === 'purple') classes += 'bg-purple-600 text-white hover:bg-purple-500 ';
      else if (primaryColor === 'emerald') classes += 'bg-emerald-500 text-black hover:bg-emerald-400 ';
      else if (primaryColor === 'amber') classes += 'bg-amber-500 text-black hover:bg-amber-400 ';
      else if (primaryColor === 'rose') classes += 'bg-rose-600 text-white hover:bg-rose-500 ';
      else classes += 'bg-indigo-600 text-white hover:bg-indigo-500 ';
    } else if (variant === 'outline') {
      if (primaryColor === 'cyan') classes += 'border border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10 ';
      else if (primaryColor === 'purple') classes += 'border border-purple-500/50 text-purple-300 hover:bg-purple-500/10 ';
      else if (primaryColor === 'emerald') classes += 'border border-emerald-500/50 text-emerald-400 hover:bg-emerald-500/10 ';
      else if (primaryColor === 'amber') classes += 'border border-amber-500/50 text-amber-400 hover:bg-amber-500/10 ';
      else if (primaryColor === 'rose') classes += 'border border-rose-500/50 text-rose-400 hover:bg-rose-500/10 ';
      else classes += 'border border-indigo-500/50 text-indigo-400 hover:bg-indigo-500/10 ';
    } else if (variant === 'glass') {
      classes += 'bg-white/5 backdrop-blur-md border border-white/10 text-white hover:bg-white/10 ';
    }

    // Shadow
    if (shadow === 'sm') classes += 'shadow-md ';
    else if (shadow === 'lg') classes += 'shadow-2xl ';
    else if (shadow === 'glow') {
      if (primaryColor === 'cyan') classes += 'shadow-lg shadow-cyan-500/30 ';
      else if (primaryColor === 'purple') classes += 'shadow-lg shadow-purple-500/30 ';
      else if (primaryColor === 'emerald') classes += 'shadow-lg shadow-emerald-500/30 ';
      else if (primaryColor === 'amber') classes += 'shadow-lg shadow-amber-500/30 ';
      else if (primaryColor === 'rose') classes += 'shadow-lg shadow-rose-500/30 ';
      else classes += 'shadow-lg shadow-indigo-500/30 ';
    }

    return classes.trim();
  };

  // Generate Component JSX Code
  const getGeneratedComponentCode = () => {
    const tailwind = getTailwindClasses();
    const componentName = componentType.charAt(0).toUpperCase() + componentType.slice(1);

    if (componentType === 'button') {
      return `import React from 'react';\nimport { Sparkles } from 'lucide-react';\n\nexport const Custom${componentName}: React.FC<{ onClick?: () => void }> = ({ onClick }) => {\n  return (\n    <button\n      onClick={onClick}\n      className="${tailwind}"\n    >\n      <Sparkles size={16} />\n      <span>${text}</span>\n    </button>\n  );\n};\n\nexport default Custom${componentName};`;
    } else if (componentType === 'card') {
      return `import React from 'react';\nimport { Layers } from 'lucide-react';\n\nexport const Custom${componentName}: React.FC = () => {\n  return (\n    <div className="${tailwind}">\n      <div className="flex items-center gap-2 text-sm font-bold">\n        <Layers size={18} />\n        <span>${text}</span>\n      </div>\n      <p className="text-xs text-zinc-400 leading-relaxed">\n        High-performance modular component built with Tailwind CSS and React.\n      </p>\n    </div>\n  );\n};\n\nexport default Custom${componentName};`;
    } else if (componentType === 'badge') {
      return `import React from 'react';\n\nexport const Custom${componentName}: React.FC = () => {\n  return (\n    <span className="${tailwind}">\n      ${text}\n    </span>\n  );\n};\n\nexport default Custom${componentName};`;
    } else if (componentType === 'input') {
      return `import React, { useState } from 'react';\n\nexport const Custom${componentName}: React.FC = () => {\n  const [val, setVal] = useState('');\n  return (\n    <input\n      type="text"\n      value={val}\n      onChange={(e) => setVal(e.target.value)}\n      placeholder="${text}"\n      className="${tailwind}"\n    />\n  );\n};\n\nexport default Custom${componentName};`;
    } else {
      return `import React from 'react';\nimport { X } from 'lucide-react';\n\nexport const Custom${componentName}: React.FC<{ onClose?: () => void }> = ({ onClose }) => {\n  return (\n    <div className="${tailwind}">\n      <div className="flex items-center justify-between w-full border-b border-white/10 pb-3">\n        <h3 className="text-sm font-bold text-white">${text}</h3>\n        <button onClick={onClose} className="p-1 hover:bg-white/10 rounded cursor-pointer"><X size={16} /></button>\n      </div>\n      <p className="text-xs text-zinc-300">Modal dialog content goes here...</p>\n    </div>\n  );\n};\n\nexport default Custom${componentName};`;
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(getGeneratedComponentCode());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleInjectComponent = () => {
    if (!onAddFileToWorkspace) return;
    const fileName = `Custom${componentType.charAt(0).toUpperCase() + componentType.slice(1)}.tsx`;
    onAddFileToWorkspace({
      id: `f_ui_${Date.now()}`,
      name: fileName,
      language: 'typescript',
      content: getGeneratedComponentCode(),
      lastModified: Date.now()
    });
    alert(`Created UI Component file "${fileName}" in workspace!`);
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0c10] text-zinc-200 select-none overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-white/10 flex items-center justify-between bg-zinc-900/60 shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-pink-500/10 border border-pink-500/30 text-pink-400">
            <Palette size={20} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              Tailwind UI Component & Theme Studio
              <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-pink-500/20 text-pink-300 border border-pink-500/30">
                UI DESIGNER
              </span>
            </h2>
            <p className="text-[11px] text-zinc-400">Design accessible UI components, customize Tailwind styling, and export React code</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {onAddFileToWorkspace && (
            <button
              onClick={handleInjectComponent}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-400 hover:to-rose-500 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-pink-950/40 transition-all cursor-pointer"
            >
              <FolderPlus size={14} /> Add to Project
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-hidden">
        {/* Left Column: Controls */}
        <div className="w-full lg:w-80 p-4 border-r border-white/10 bg-zinc-900/30 flex flex-col space-y-4 shrink-0 overflow-y-auto custom-scrollbar">
          {/* Component Category */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">Component Archetype</label>
            <div className="grid grid-cols-3 gap-1.5">
              {(['button', 'card', 'badge', 'input', 'modal'] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setComponentType(t)}
                  className={`p-2 rounded-lg text-xs font-medium uppercase transition-colors cursor-pointer ${
                    componentType === t ? 'bg-pink-500/20 text-pink-300 border border-pink-500/40 font-bold' : 'bg-zinc-950 text-zinc-400 border border-white/5'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Label Text Input */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">Component Text</label>
            <input
              type="text"
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="w-full bg-zinc-950 border border-white/10 rounded-lg p-2 text-xs text-white outline-none focus:border-pink-500"
            />
          </div>

          {/* Variant Style */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">Style Variant</label>
            <div className="grid grid-cols-2 gap-1.5">
              {(['gradient', 'solid', 'outline', 'glass'] as const).map((v) => (
                <button
                  key={v}
                  onClick={() => setVariant(v)}
                  className={`p-2 rounded-lg text-xs font-medium uppercase transition-colors cursor-pointer ${
                    variant === v ? 'bg-pink-500/20 text-pink-300 border border-pink-500/40 font-bold' : 'bg-zinc-950 text-zinc-400 border border-white/5'
                  }`}
                >
                  {v}
                </button>
              ))}
            </div>
          </div>

          {/* Color Palette */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">Accent Tone</label>
            <div className="grid grid-cols-3 gap-1.5">
              {(['cyan', 'purple', 'emerald', 'amber', 'rose', 'indigo'] as const).map((c) => (
                <button
                  key={c}
                  onClick={() => setPrimaryColor(c)}
                  className={`p-2 rounded-lg text-xs font-medium uppercase transition-colors cursor-pointer capitalize ${
                    primaryColor === c ? 'bg-pink-500/20 text-pink-300 border border-pink-500/40 font-bold' : 'bg-zinc-950 text-zinc-400 border border-white/5'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>

          {/* Corner Radius */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">Border Radius</label>
            <div className="grid grid-cols-3 gap-1.5">
              {(['rounded-none', 'rounded-lg', 'rounded-xl', 'rounded-2xl', 'rounded-full'] as const).map((r) => (
                <button
                  key={r}
                  onClick={() => setBorderRadius(r)}
                  className={`p-1.5 rounded-lg text-[10px] font-mono transition-colors cursor-pointer ${
                    borderRadius === r ? 'bg-pink-500/20 text-pink-300 border border-pink-500/40 font-bold' : 'bg-zinc-950 text-zinc-400 border border-white/5'
                  }`}
                >
                  {r.replace('rounded-', '') || 'square'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Live Preview & Code */}
        <div className="flex-1 flex flex-col p-4 space-y-4 overflow-hidden">
          {/* Live Component Preview Stage */}
          <div className="flex-1 flex flex-col bg-zinc-900 border border-white/10 rounded-2xl overflow-hidden min-h-[220px]">
            <div className="p-3 border-b border-white/10 bg-zinc-950/80 flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-1.5">
                <Eye size={14} className="text-pink-400" /> Interactive Canvas Stage
              </span>
              <button
                onClick={() => setIsDarkMode(!isDarkMode)}
                className="p-1.5 rounded bg-white/5 hover:bg-white/10 text-xs text-zinc-300 flex items-center gap-1 cursor-pointer"
              >
                {isDarkMode ? <Moon size={14} /> : <Sun size={14} />}
                {isDarkMode ? 'Dark' : 'Light'}
              </button>
            </div>

            <div className={`flex-1 flex items-center justify-center p-8 transition-colors ${
              isDarkMode ? 'bg-[#0a0c10]' : 'bg-zinc-100 text-zinc-900'
            }`}>
              {/* Component Render */}
              {componentType === 'button' && (
                <button className={getTailwindClasses()}>
                  <Sparkles size={16} />
                  <span>{text}</span>
                </button>
              )}

              {componentType === 'card' && (
                <div className={`${getTailwindClasses()} ${isDarkMode ? 'bg-zinc-900/90' : 'bg-white text-zinc-900 border-zinc-200 shadow-xl'}`}>
                  <div className="flex items-center gap-2 text-sm font-bold">
                    <Layers size={18} className="text-pink-400" />
                    <span>{text}</span>
                  </div>
                  <p className="text-xs opacity-75 leading-relaxed">
                    High-performance modular UI component generated visually in Aether IDE.
                  </p>
                </div>
              )}

              {componentType === 'badge' && (
                <span className={getTailwindClasses()}>
                  {text}
                </span>
              )}

              {componentType === 'input' && (
                <input
                  type="text"
                  placeholder={text}
                  className={`${getTailwindClasses()} ${isDarkMode ? 'bg-zinc-950 text-white' : 'bg-white text-zinc-900 border-zinc-300'}`}
                />
              )}

              {componentType === 'modal' && (
                <div className={`${getTailwindClasses()} ${isDarkMode ? 'bg-zinc-900' : 'bg-white text-zinc-900 border-zinc-200 shadow-2xl'}`}>
                  <div className="flex items-center justify-between w-full border-b border-white/10 pb-3">
                    <h3 className="text-sm font-bold">{text}</h3>
                  </div>
                  <p className="text-xs opacity-80">Interactive dialog preview component.</p>
                </div>
              )}
            </div>
          </div>

          {/* Generated Code Panel */}
          <div className="h-48 bg-zinc-900 border border-white/10 rounded-2xl flex flex-col overflow-hidden">
            <div className="p-3 border-b border-white/10 bg-zinc-950/80 flex items-center justify-between">
              <span className="text-xs font-mono text-pink-300 font-bold flex items-center gap-1.5">
                <Code2 size={14} /> React + Tailwind Source Code
              </span>
              <button
                onClick={handleCopyCode}
                className="px-2.5 py-1 rounded bg-white/5 hover:bg-white/10 text-xs font-medium text-zinc-300 flex items-center gap-1 cursor-pointer"
              >
                {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                {copied ? 'Copied' : 'Copy Code'}
              </button>
            </div>

            <pre className="flex-1 p-3 font-mono text-xs text-pink-200/90 overflow-auto custom-scrollbar whitespace-pre-wrap">
              {getGeneratedComponentCode()}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UIComponentStudio;
