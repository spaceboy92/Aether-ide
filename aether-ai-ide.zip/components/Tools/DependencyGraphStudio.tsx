import React, { useMemo } from 'react';
import { 
  Network, 
  FileCode, 
  GitFork, 
  Layers, 
  Search, 
  Info, 
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { FileNode } from '../../types';

interface DependencyGraphStudioProps {
  files: FileNode[];
}

interface FileDependency {
  source: string;
  target: string;
}

export const DependencyGraphStudio: React.FC<DependencyGraphStudioProps> = ({ files }) => {
  // Analyze dependencies across workspace files
  const { nodes, edges, entrypoints } = useMemo(() => {
    const fileList = files.filter(f => f.name.endsWith('.ts') || f.name.endsWith('.tsx') || f.name.endsWith('.js') || f.name.endsWith('.jsx'));
    const edgesList: FileDependency[] = [];
    const entryList: string[] = [];

    fileList.forEach(file => {
      if (file.name === 'App.tsx' || file.name === 'main.tsx' || file.name === 'index.ts' || file.name === 'server.ts') {
        entryList.push(file.name);
      }

      // Regex to extract local relative imports
      const importRegex = /import\s+.*?\s+from\s+['"](\.\/|\.\.\/)(.*?)['"]/g;
      let match;
      while ((match = importRegex.exec(file.content)) !== null) {
        let importedPath = match[2];
        // clean up extension if omitted
        if (!importedPath.includes('.')) {
          importedPath += '.tsx';
        } else {
          importedPath = importedPath.split('/').pop() || importedPath;
        }

        edgesList.push({
          source: file.name,
          target: importedPath
        });
      }
    });

    return {
      nodes: fileList,
      edges: edgesList,
      entrypoints: entryList.length > 0 ? entryList : ['App.tsx']
    };
  }, [files]);

  return (
    <div className="flex flex-col h-full bg-[#0a0c10] text-zinc-200 select-none overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-white/10 flex items-center justify-between bg-zinc-900/60 shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-400">
            <Network size={20} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              Code Architecture & Module Graph Visualizer
              <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                ARCHITECTURE
              </span>
            </h2>
            <p className="text-[11px] text-zinc-400">Automated workspace AST parser mapping file import trees and component dependencies</p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-purple-300 bg-purple-500/10 px-3 py-1.5 rounded-xl border border-purple-500/20">
          <span>{nodes.length} Modules parsed</span>
          <span>•</span>
          <span>{edges.length} Import links</span>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-hidden">
        {/* Module Tree Sidebar */}
        <div className="w-full lg:w-80 p-4 border-r border-white/10 bg-zinc-900/30 flex flex-col space-y-4 shrink-0 overflow-y-auto custom-scrollbar">
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">Workspace Entrypoints</label>
            <div className="space-y-1">
              {entrypoints.map(ep => (
                <div key={ep} className="p-2 rounded-lg bg-purple-500/20 border border-purple-500/40 text-purple-200 text-xs font-mono font-bold flex items-center justify-between">
                  <span className="flex items-center gap-1.5"><FileCode size={14} /> {ep}</span>
                  <span className="text-[9px] uppercase bg-purple-500/30 px-1 rounded">Entry</span>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">Parsed Files ({nodes.length})</label>
            <div className="space-y-1 max-h-80 overflow-y-auto custom-scrollbar pr-1">
              {nodes.map(node => (
                <div key={node.id} className="p-2 rounded-lg bg-zinc-950 border border-white/5 text-xs text-zinc-300 font-mono flex items-center justify-between hover:border-purple-500/30 transition-colors">
                  <span className="truncate">{node.name}</span>
                  <span className="text-[10px] text-zinc-500">{node.content.length} bytes</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Node Graph Stage */}
        <div className="flex-1 p-6 flex flex-col bg-zinc-950 overflow-auto custom-scrollbar items-center justify-start">
          <div className="w-full max-w-4xl space-y-6">
            <div className="text-center space-y-1">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center justify-center gap-2">
                <GitFork size={16} className="text-purple-400" /> Module Dependency Hierarchy
              </h3>
              <p className="text-xs text-zinc-400">Visual mapping of component relationships based on import references</p>
            </div>

            {/* Dependency Mapping Grid */}
            <div className="space-y-4">
              {nodes.map(node => {
                const dependencies = edges.filter(e => e.source === node.name);
                return (
                  <div key={node.id} className="p-4 rounded-xl bg-zinc-900 border border-white/10 hover:border-purple-500/40 transition-all space-y-3">
                    <div className="flex items-center justify-between border-b border-white/10 pb-2">
                      <div className="flex items-center gap-2">
                        <FileCode size={16} className="text-purple-400" />
                        <span className="font-mono text-xs font-bold text-white">{node.name}</span>
                      </div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 text-zinc-400">
                        {dependencies.length} Imports
                      </span>
                    </div>

                    {dependencies.length > 0 ? (
                      <div className="flex flex-wrap gap-2 pt-1">
                        {dependencies.map((dep, idx) => (
                          <div key={idx} className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-purple-500/10 border border-purple-500/30 text-xs font-mono text-purple-300">
                            <ArrowRight size={12} className="text-purple-400" />
                            <span>{dep.target}</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-[11px] text-zinc-500 italic">Leaf component (No local sub-imports)</p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DependencyGraphStudio;
