import React, { useState, useEffect } from 'react';
import { 
  X, 
  GitBranch, 
  GitCommit, 
  GitPullRequest, 
  Github, 
  Check, 
  RefreshCw, 
  ArrowUpRight, 
  Lock, 
  Globe, 
  Plus, 
  CheckCircle2, 
  ExternalLink,
  ShieldCheck,
  Zap,
  FolderGit2
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { gitHubService, GitHubRepo, GitHubCommitLog, GitHubSyncState } from '../../services/githubService';
import { FileNode } from '../../types';

interface GitHubSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  files: FileNode[];
  currentSessionTitle?: string;
}

export const GitHubSyncModal: React.FC<GitHubSyncModalProps> = ({
  isOpen,
  onClose,
  files,
  currentSessionTitle = 'Aether Micro-App',
}) => {
  const [syncState, setSyncState] = useState<GitHubSyncState>(gitHubService.getState());
  const [repos, setRepos] = useState<GitHubRepo[]>([]);
  const [commitHistory, setCommitHistory] = useState<GitHubCommitLog[]>([]);
  const [tokenInput, setTokenInput] = useState('');
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // New Repo Form
  const [showCreateRepo, setShowCreateRepo] = useState(false);
  const [newRepoName, setNewRepoName] = useState(
    currentSessionTitle.toLowerCase().replace(/[^a-z0-9]/g, '-') || 'my-micro-app'
  );
  const [isPrivate, setIsPrivate] = useState(true);

  // Commit Form
  const [commitMessage, setCommitMessage] = useState(`feat: sync ${currentSessionTitle} micro-app workspace`);
  const [isPushing, setIsPushing] = useState(false);
  const [pushResult, setPushResult] = useState<{ success: boolean; url?: string; count?: number; error?: string } | null>(null);

  useEffect(() => {
    if (isOpen) {
      loadData();
    }
  }, [isOpen]);

  const loadData = async () => {
    const state = gitHubService.getState();
    setSyncState(state);
    setCommitHistory(gitHubService.getCommitHistory());
    const list = await gitHubService.listUserRepos();
    setRepos(list);
  };

  const handleConnectToken = async () => {
    if (!tokenInput.trim()) return;
    setIsAuthenticating(true);
    setAuthError(null);

    const res = await gitHubService.authenticate(tokenInput.trim());
    setIsAuthenticating(false);

    if (res.success) {
      setTokenInput('');
      loadData();
    } else {
      setAuthError(res.error || 'Authentication failed. Please check your GitHub token.');
    }
  };

  const handleCreateRepo = async () => {
    if (!newRepoName.trim()) return;
    setIsPushing(true);
    const res = await gitHubService.createRepository(newRepoName.trim(), isPrivate);
    setIsPushing(false);

    if (res.success && res.repo) {
      setShowCreateRepo(false);
      loadData();
    } else {
      setAuthError(res.error || 'Failed to create repository');
    }
  };

  const handlePushToGitHub = async () => {
    setIsPushing(true);
    setPushResult(null);

    const res = await gitHubService.commitAndPush(
      files,
      commitMessage || 'feat: automated micro-app update',
      syncState.selectedBranch || 'main'
    );

    setIsPushing(false);
    if (res.success) {
      setPushResult({
        success: true,
        url: res.commitUrl,
        count: res.filesCount,
      });
      loadData();
    } else {
      setPushResult({
        success: false,
        error: res.error || 'Push failed',
      });
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="bg-[#0b0d13] border border-white/10 rounded-2xl w-full max-w-2xl overflow-hidden shadow-[0_0_60px_rgba(0,0,0,0.8)] flex flex-col max-h-[90vh]"
        >
          {/* Header */}
          <div className="p-5 border-b border-white/10 bg-zinc-950/70 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white">
                <Github size={22} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-white tracking-tight">GitHub Two-Way Sync</h3>
                  <span className="px-2 py-0.5 rounded-full text-[9px] font-mono font-bold bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                    Pro Workflow
                  </span>
                </div>
                <p className="text-xs text-zinc-400">
                  Continuous versioning, direct commits, and repo generation for client projects
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-zinc-400 hover:text-white p-2 rounded-xl hover:bg-white/5 transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          <div className="p-6 space-y-6 overflow-y-auto flex-1">
            {/* 1. Connection Status */}
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                {syncState.avatarUrl ? (
                  <img
                    src={syncState.avatarUrl}
                    alt={syncState.username || 'User'}
                    className="w-10 h-10 rounded-xl border border-white/20 object-cover"
                  />
                ) : (
                  <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-zinc-400">
                    <Github size={20} />
                  </div>
                )}
                <div>
                  <div className="text-sm font-semibold text-white">
                    {syncState.username ? `@${syncState.username}` : 'GitHub Not Linked'}
                  </div>
                  <div className="text-xs text-zinc-400">
                    {syncState.username ? 'Connected with Personal Access Token' : 'Link GitHub for direct two-way commits'}
                  </div>
                </div>
              </div>

              {syncState.username ? (
                <button
                  onClick={() => {
                    gitHubService.disconnect();
                    loadData();
                  }}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold text-red-400 hover:bg-red-500/10 border border-red-500/20 transition-all"
                >
                  Disconnect
                </button>
              ) : (
                <div className="flex gap-2">
                  <input
                    type="password"
                    placeholder="ghp_xxxx (GitHub PAT)"
                    value={tokenInput}
                    onChange={(e) => setTokenInput(e.target.value)}
                    className="px-3 py-1.5 rounded-lg bg-black/60 border border-white/15 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-white/40 w-44 font-mono"
                  />
                  <button
                    onClick={handleConnectToken}
                    disabled={isAuthenticating || !tokenInput}
                    className="px-4 py-1.5 rounded-lg bg-white text-black font-bold text-xs hover:bg-zinc-200 transition-all disabled:opacity-50"
                  >
                    {isAuthenticating ? 'Linking...' : 'Connect'}
                  </button>
                </div>
              )}
            </div>

            {authError && (
              <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-xs text-red-400">
                {authError}
              </div>
            )}

            {/* 2. Repository Selection & Creation */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
                  <FolderGit2 size={13} className="text-cyan-400" />
                  Target Repository
                </label>
                <button
                  onClick={() => setShowCreateRepo(!showCreateRepo)}
                  className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1"
                >
                  <Plus size={13} />
                  New Repository
                </button>
              </div>

              {showCreateRepo ? (
                <div className="p-4 rounded-xl bg-cyan-950/20 border border-cyan-500/30 space-y-3">
                  <div className="text-xs font-bold text-cyan-300">Create & Link New Repository</div>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newRepoName}
                      onChange={(e) => setNewRepoName(e.target.value)}
                      placeholder="repo-name"
                      className="flex-1 px-3 py-2 rounded-lg bg-black/60 border border-white/15 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-cyan-400 font-mono"
                    />
                    <button
                      onClick={() => setIsPrivate(!isPrivate)}
                      className={`px-3 py-2 rounded-lg border text-xs font-semibold flex items-center gap-1.5 ${
                        isPrivate ? 'bg-white/5 border-white/20 text-white' : 'bg-cyan-500/10 border-cyan-500/30 text-cyan-300'
                      }`}
                    >
                      {isPrivate ? <Lock size={12} /> : <Globe size={12} />}
                      {isPrivate ? 'Private' : 'Public'}
                    </button>
                  </div>
                  <div className="flex justify-end gap-2 pt-1">
                    <button
                      onClick={() => setShowCreateRepo(false)}
                      className="px-3 py-1.5 rounded-lg text-xs text-zinc-400 hover:text-white"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleCreateRepo}
                      disabled={isPushing || !newRepoName}
                      className="px-4 py-1.5 rounded-lg bg-cyan-500 text-black font-bold text-xs hover:bg-cyan-400 transition-all disabled:opacity-50"
                    >
                      {isPushing ? 'Creating...' : 'Create & Select'}
                    </button>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {repos.slice(0, 4).map((repo) => {
                    const isSelected = syncState.selectedRepo === repo.full_name;
                    return (
                      <button
                        key={repo.id}
                        onClick={() => {
                          gitHubService.saveState({
                            selectedRepo: repo.full_name,
                            selectedBranch: repo.default_branch,
                          });
                          loadData();
                        }}
                        className={`p-3 rounded-xl border text-left transition-all ${
                          isSelected
                            ? 'bg-cyan-500/10 border-cyan-500/50 text-white shadow-lg shadow-cyan-950/30'
                            : 'bg-white/[0.02] border-white/10 text-zinc-400 hover:text-white hover:bg-white/[0.05]'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-semibold text-xs text-white truncate max-w-[180px]">{repo.name}</span>
                          {repo.private ? <Lock size={11} className="text-zinc-500" /> : <Globe size={11} className="text-cyan-400" />}
                        </div>
                        <div className="text-[10px] text-zinc-500 truncate mt-1">{repo.full_name}</div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* 3. Commit & Push Section */}
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
                  <GitCommit size={13} className="text-emerald-400" />
                  Commit & Push Workspace
                </label>
                <div className="text-xs font-mono text-zinc-500">
                  Branch: <span className="text-white font-bold">{syncState.selectedBranch || 'main'}</span>
                </div>
              </div>

              <input
                type="text"
                value={commitMessage}
                onChange={(e) => setCommitMessage(e.target.value)}
                placeholder="Commit message..."
                className="w-full px-3 py-2 rounded-lg bg-black/60 border border-white/15 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-emerald-400"
              />

              <div className="flex items-center justify-between pt-1">
                <div className="flex items-center gap-2 text-xs text-zinc-400">
                  <ShieldCheck size={14} className="text-emerald-400" />
                  <span>{files.length} project modules ready</span>
                </div>

                <button
                  onClick={handlePushToGitHub}
                  disabled={isPushing}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 text-black font-bold text-xs hover:opacity-90 transition-all flex items-center gap-1.5 shadow-lg shadow-emerald-950/40 disabled:opacity-50"
                >
                  {isPushing ? (
                    <>
                      <RefreshCw size={13} className="animate-spin" />
                      Pushing Commits...
                    </>
                  ) : (
                    <>
                      <Zap size={13} />
                      Push to GitHub
                    </>
                  )}
                </button>
              </div>

              {pushResult && (
                <div
                  className={`p-3 rounded-lg text-xs flex items-center justify-between ${
                    pushResult.success
                      ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400'
                      : 'bg-red-500/10 border border-red-500/20 text-red-400'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {pushResult.success ? <CheckCircle2 size={15} /> : <X size={15} />}
                    <span>
                      {pushResult.success
                        ? `Pushed ${pushResult.count} files to ${syncState.selectedRepo || 'repo'} successfully.`
                        : pushResult.error}
                    </span>
                  </div>
                  {pushResult.url && (
                    <a
                      href={pushResult.url}
                      target="_blank"
                      rel="noreferrer"
                      className="text-xs underline font-bold flex items-center gap-1"
                    >
                      View on GitHub <ExternalLink size={12} />
                    </a>
                  )}
                </div>
              )}
            </div>

            {/* 4. Recent Commits History */}
            <div className="space-y-2">
              <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
                Recent Synced Commits
              </label>
              <div className="space-y-1.5">
                {commitHistory.slice(0, 3).map((commit) => (
                  <div
                    key={commit.sha}
                    className="p-2.5 rounded-lg bg-black/40 border border-white/5 flex items-center justify-between text-xs font-mono"
                  >
                    <div className="flex items-center gap-2 text-zinc-300 truncate max-w-[340px]">
                      <GitCommit size={13} className="text-zinc-500 shrink-0" />
                      <span className="text-cyan-400 font-bold">{commit.sha.substring(0, 7)}</span>
                      <span className="truncate">{commit.message}</span>
                    </div>
                    <span className="text-[10px] text-zinc-500 shrink-0">
                      {new Date(commit.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="p-4 bg-zinc-950/80 border-t border-white/10 flex items-center justify-between text-[11px] text-zinc-400">
            <div className="flex items-center gap-1.5">
              <Check size={13} className="text-emerald-400" />
              <span>Two-Way Branch Sync & PR Handshake Ready</span>
            </div>
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white font-semibold text-xs transition-colors"
            >
              Done
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
