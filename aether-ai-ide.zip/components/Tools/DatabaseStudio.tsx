import React, { useState, useEffect } from 'react';
import { 
  Database, 
  HardDrive, 
  Table, 
  FileJson, 
  Plus, 
  Trash2, 
  Edit3, 
  Save, 
  RefreshCw, 
  Search, 
  Sparkles, 
  Code2, 
  Layers, 
  Check, 
  Download,
  Copy,
  FolderOpen
} from 'lucide-react';
import { FileNode } from '../../types';

interface StorageItem {
  key: string;
  value: string;
  sizeBytes: number;
}

interface DatabaseStudioProps {
  files: FileNode[];
  onAddFileToWorkspace?: (file: FileNode) => void;
}

export const DatabaseStudio: React.FC<DatabaseStudioProps> = ({
  files,
  onAddFileToWorkspace
}) => {
  const [activeTab, setActiveTab] = useState<'browser_storage' | 'er_diagram' | 'mock_generator'>('browser_storage');
  const [storageItems, setStorageItems] = useState<StorageItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [editingKey, setEditingKey] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const [newKey, setNewKey] = useState('');
  const [newValue, setNewValue] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  // Mock Data Generator State
  const [mockType, setMockType] = useState<'users' | 'products' | 'chat_messages' | 'analytics_logs'>('users');
  const [mockCount, setMockCount] = useState<number>(5);
  const [mockFormat, setMockFormat] = useState<'json' | 'typescript'>('json');
  const [generatedData, setGeneratedData] = useState<string>('');
  const [copied, setCopied] = useState(false);

  // Load Browser LocalStorage
  const refreshStorage = () => {
    try {
      const items: StorageItem[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key) {
          const value = localStorage.getItem(key) || '';
          items.push({
            key,
            value,
            sizeBytes: new Blob([key + value]).size
          });
        }
      }
      setStorageItems(items);
    } catch (e) {
      console.warn("LocalStorage access error:", e);
    }
  };

  useEffect(() => {
    refreshStorage();
  }, []);

  const handleSaveEdit = (key: string) => {
    try {
      localStorage.setItem(key, editValue);
      setEditingKey(null);
      refreshStorage();
    } catch (e) {
      alert("Failed to write to LocalStorage");
    }
  };

  const handleDeleteStorageKey = (key: string) => {
    try {
      localStorage.removeItem(key);
      refreshStorage();
    } catch (e) {}
  };

  const handleAddStorageKey = () => {
    if (!newKey.trim()) return;
    try {
      localStorage.setItem(newKey.trim(), newValue);
      setNewKey('');
      setNewValue('');
      setShowAddModal(false);
      refreshStorage();
    } catch (e) {}
  };

  // Mock Generator Logic
  const generateMockDataset = () => {
    let result: any[] = [];
    
    if (mockType === 'users') {
      const names = ['Alex Vance', 'Elena Rostova', 'Marcus Brody', 'Sophia Chen', 'David Kim', 'Aria Montgomery', 'Liam Thorne', 'Maya Patel'];
      const roles = ['Administrator', 'Lead Architect', 'Product Designer', 'Security Analyst', 'Fullstack Engineer'];
      for (let i = 0; i < mockCount; i++) {
        const name = names[i % names.length] + (i >= names.length ? ` ${i+1}` : '');
        result.push({
          id: `usr_${Date.now()}_${i+1}`,
          name,
          email: `${name.toLowerCase().replace(/\s+/g, '.')}@aether.ai`,
          role: roles[i % roles.length],
          status: i % 2 === 0 ? 'ACTIVE' : 'OFFLINE',
          createdAt: new Date(Date.now() - i * 86400000).toISOString()
        });
      }
    } else if (mockType === 'products') {
      const categories = ['AI Models', 'Developer SDKs', 'Cloud Nodes', 'Neural Services'];
      for (let i = 0; i < mockCount; i++) {
        result.push({
          id: `prd_${Date.now()}_${i+1}`,
          title: `Aether ${categories[i % categories.length]} Unit ${i+1}`,
          category: categories[i % categories.length],
          price: Math.floor(Math.random() * 490) + 10,
          inStock: true,
          rating: (4.2 + (i % 8) * 0.1).toFixed(1)
        });
      }
    } else if (mockType === 'chat_messages') {
      const phrases = [
        'Initialize neural connection to server node.',
        'Refactoring React component hooks for zero-error execution.',
        'Compiling WebAssembly bundle for 3D physics pipeline.',
        'Deployment complete. Live preview ready at port 3000.'
      ];
      for (let i = 0; i < mockCount; i++) {
        result.push({
          id: `msg_${Date.now()}_${i+1}`,
          sender: i % 2 === 0 ? 'user' : 'ai_assistant',
          text: phrases[i % phrases.length],
          timestamp: new Date(Date.now() - (mockCount - i) * 60000).toLocaleTimeString()
        });
      }
    } else {
      for (let i = 0; i < mockCount; i++) {
        result.push({
          id: `log_${Date.now()}_${i+1}`,
          endpoint: i % 2 === 0 ? '/api/ai/generate' : '/api/health',
          statusCode: 200,
          latencyMs: Math.floor(Math.random() * 120) + 15,
          timestamp: new Date().toISOString()
        });
      }
    }

    if (mockFormat === 'typescript') {
      const interfaceName = mockType === 'users' ? 'User' : mockType === 'products' ? 'Product' : mockType === 'chat_messages' ? 'ChatMessage' : 'AnalyticsLog';
      const tsCode = `export interface ${interfaceName} {\n${Object.keys(result[0] || {}).map(k => `  ${k}: ${typeof (result[0] as any)[k]};`).join('\n')}\n}\n\nexport const MOCK_${mockType.toUpperCase()}: ${interfaceName}[] = ${JSON.stringify(result, null, 2)};`;
      setGeneratedData(tsCode);
    } else {
      setGeneratedData(JSON.stringify(result, null, 2));
    }
  };

  useEffect(() => {
    generateMockDataset();
  }, [mockType, mockCount, mockFormat]);

  const handleInjectMockFile = () => {
    if (!onAddFileToWorkspace) return;
    const fileName = mockFormat === 'typescript' ? `mock${mockType.charAt(0).toUpperCase() + mockType.slice(1)}.ts` : `mock${mockType.charAt(0).toUpperCase() + mockType.slice(1)}.json`;
    onAddFileToWorkspace({
      id: `f_mock_${Date.now()}`,
      name: fileName,
      language: mockFormat === 'typescript' ? 'typescript' : 'json',
      content: generatedData,
      lastModified: Date.now()
    });
    alert(`Created file "${fileName}" in your workspace!`);
  };

  const filteredStorage = storageItems.filter(item => 
    item.key.toLowerCase().includes(searchQuery.toLowerCase()) || 
    item.value.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full bg-[#0a0c10] text-zinc-200 select-none overflow-hidden">
      {/* Top Header */}
      <div className="p-4 border-b border-white/10 flex items-center justify-between bg-zinc-900/60 shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-400">
            <Database size={20} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              Database & Storage Studio
              <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30">
                DATA ENGINE
              </span>
            </h2>
            <p className="text-[11px] text-zinc-400">Inspect browser storage, model relational schemas, and generate mock datasets</p>
          </div>
        </div>

        {/* Studio Sub-Tabs */}
        <div className="flex items-center gap-1 bg-zinc-950 p-1 rounded-xl border border-white/10">
          {[
            { id: 'browser_storage', label: 'Storage Inspector', icon: HardDrive },
            { id: 'er_diagram', label: 'Schema Model', icon: Layers },
            { id: 'mock_generator', label: 'Mock Dataset Studio', icon: FileJson }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`
                  px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer
                  ${activeTab === tab.id 
                    ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-md' 
                    : 'text-zinc-400 hover:text-white'}
                `}
              >
                <Icon size={14} /> {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      <div className="flex-1 overflow-hidden p-4">
        {/* Tab 1: Storage Inspector */}
        {activeTab === 'browser_storage' && (
          <div className="flex flex-col h-full space-y-3">
            <div className="flex items-center justify-between gap-3 bg-zinc-900/60 p-3 rounded-xl border border-white/10">
              <div className="flex items-center gap-2 flex-1 bg-zinc-950 px-3 py-1.5 rounded-lg border border-white/10">
                <Search size={14} className="text-zinc-500" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter LocalStorage keys or values..."
                  className="bg-transparent border-none outline-none text-xs text-white placeholder:text-zinc-600 w-full font-mono"
                />
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowAddModal(true)}
                  className="px-3 py-1.5 rounded-lg bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <Plus size={14} /> Add Storage Item
                </button>
                <button
                  onClick={refreshStorage}
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-zinc-300 transition-colors cursor-pointer"
                  title="Refresh Storage"
                >
                  <RefreshCw size={14} />
                </button>
              </div>
            </div>

            {/* Storage Table */}
            <div className="flex-1 bg-zinc-900/40 border border-white/10 rounded-xl overflow-y-auto custom-scrollbar">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-white/10 bg-zinc-900/80 text-[10px] font-bold uppercase tracking-wider text-zinc-400">
                    <th className="p-3">Key</th>
                    <th className="p-3">Value</th>
                    <th className="p-3 text-right">Size</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5 text-xs font-mono">
                  {filteredStorage.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="p-8 text-center text-zinc-500 italic">
                        No storage items found matching query.
                      </td>
                    </tr>
                  ) : (
                    filteredStorage.map((item) => (
                      <tr key={item.key} className="hover:bg-white/[0.02] transition-colors">
                        <td className="p-3 font-bold text-purple-400 max-w-[180px] truncate">{item.key}</td>
                        <td className="p-3 text-zinc-300 max-w-[320px] truncate">
                          {editingKey === item.key ? (
                            <input
                              type="text"
                              value={editValue}
                              onChange={(e) => setEditValue(e.target.value)}
                              className="w-full bg-zinc-950 border border-purple-500/50 rounded px-2 py-1 text-xs text-white"
                            />
                          ) : (
                            item.value
                          )}
                        </td>
                        <td className="p-3 text-right text-zinc-500">{item.sizeBytes} B</td>
                        <td className="p-3 text-right">
                          <div className="flex items-center justify-end gap-1">
                            {editingKey === item.key ? (
                              <button
                                onClick={() => handleSaveEdit(item.key)}
                                className="p-1 text-emerald-400 hover:bg-white/10 rounded cursor-pointer"
                              >
                                <Save size={14} />
                              </button>
                            ) : (
                              <button
                                onClick={() => {
                                  setEditingKey(item.key);
                                  setEditValue(item.value);
                                }}
                                className="p-1 text-zinc-400 hover:text-white hover:bg-white/10 rounded cursor-pointer"
                              >
                                <Edit3 size={14} />
                              </button>
                            )}
                            <button
                              onClick={() => handleDeleteStorageKey(item.key)}
                              className="p-1 text-zinc-500 hover:text-rose-400 hover:bg-white/10 rounded cursor-pointer"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 2: Schema Model / ER Diagram */}
        {activeTab === 'er_diagram' && (
          <div className="h-full flex flex-col space-y-4 overflow-y-auto custom-scrollbar">
            <div className="p-4 rounded-xl bg-purple-500/10 border border-purple-500/30 text-xs text-purple-300 flex items-center justify-between">
              <span>Interactive Relational Model generated from workspace interfaces and data models.</span>
              <span className="font-mono text-[10px] uppercase font-bold bg-purple-500/20 px-2 py-0.5 rounded">
                ENTITIES: 4
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                {
                  title: 'UserSession',
                  fields: [
                    { name: 'id', type: 'string (PK)', key: true },
                    { name: 'title', type: 'string' },
                    { name: 'messages', type: 'ChatMessage[]' },
                    { name: 'lastUpdated', type: 'timestamp' }
                  ]
                },
                {
                  title: 'FileNode',
                  fields: [
                    { name: 'id', type: 'string (PK)', key: true },
                    { name: 'name', type: 'string' },
                    { name: 'content', type: 'text' },
                    { name: 'language', type: 'string' }
                  ]
                },
                {
                  title: 'UserProfile',
                  fields: [
                    { name: 'id', type: 'string (PK)', key: true },
                    { name: 'email', type: 'string' },
                    { name: 'coins', type: 'number' },
                    { name: 'performanceMode', type: 'string' }
                  ]
                },
                {
                  title: 'TerminalLog',
                  fields: [
                    { name: 'id', type: 'string (PK)', key: true },
                    { name: 'time', type: 'string' },
                    { name: 'type', type: 'enum' },
                    { name: 'message', type: 'string' }
                  ]
                }
              ].map((schema, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-zinc-900 border border-white/10 flex flex-col space-y-3">
                  <div className="flex items-center justify-between border-b border-white/10 pb-2">
                    <span className="font-bold text-white text-xs flex items-center gap-1.5">
                      <Table size={14} className="text-purple-400" /> {schema.title}
                    </span>
                  </div>

                  <div className="space-y-1 font-mono text-[11px]">
                    {schema.fields.map((f, i) => (
                      <div key={i} className="flex items-center justify-between p-1 rounded hover:bg-white/5">
                        <span className={f.key ? 'text-amber-400 font-bold' : 'text-zinc-300'}>
                          {f.key && '🔑 '}{f.name}
                        </span>
                        <span className="text-zinc-500">{f.type}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 3: Mock Data Generator */}
        {activeTab === 'mock_generator' && (
          <div className="h-full flex flex-col lg:flex-row gap-4 overflow-hidden">
            {/* Options Panel */}
            <div className="w-full lg:w-80 p-4 rounded-xl bg-zinc-900 border border-white/10 flex flex-col space-y-4 shrink-0">
              <h3 className="text-xs font-bold uppercase tracking-wider text-purple-400 flex items-center gap-2">
                <Sparkles size={16} /> Data Configuration
              </h3>

              <div>
                <label className="text-[11px] font-bold text-zinc-400 uppercase block mb-1">Entity Type</label>
                <select
                  value={mockType}
                  onChange={(e) => setMockType(e.target.value as any)}
                  className="w-full bg-zinc-950 border border-white/10 rounded-lg p-2 text-xs text-white font-medium outline-none"
                >
                  <option value="users">Users & Accounts</option>
                  <option value="products">E-Commerce Products</option>
                  <option value="chat_messages">AI Chat Messages</option>
                  <option value="analytics_logs">System & Analytics Logs</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-zinc-400 uppercase block mb-1">Record Count ({mockCount})</label>
                <input
                  type="range"
                  min="1"
                  max="20"
                  value={mockCount}
                  onChange={(e) => setMockCount(parseInt(e.target.value))}
                  className="w-full accent-purple-500 cursor-pointer"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-zinc-400 uppercase block mb-1">Output Format</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setMockFormat('json')}
                    className={`p-2 rounded-lg text-xs font-mono font-bold border transition-colors cursor-pointer ${
                      mockFormat === 'json' ? 'bg-purple-500/20 text-purple-300 border-purple-500/40' : 'bg-zinc-950 text-zinc-400 border-white/10'
                    }`}
                  >
                    JSON
                  </button>
                  <button
                    onClick={() => setMockFormat('typescript')}
                    className={`p-2 rounded-lg text-xs font-mono font-bold border transition-colors cursor-pointer ${
                      mockFormat === 'typescript' ? 'bg-purple-500/20 text-purple-300 border-purple-500/40' : 'bg-zinc-950 text-zinc-400 border-white/10'
                    }`}
                  >
                    TypeScript
                  </button>
                </div>
              </div>

              {onAddFileToWorkspace && (
                <button
                  onClick={handleInjectMockFile}
                  className="w-full p-3 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-purple-950/40 transition-all cursor-pointer mt-auto"
                >
                  <FolderOpen size={16} /> Save File to Project
                </button>
              )}
            </div>

            {/* Preview Panel */}
            <div className="flex-1 bg-zinc-900 border border-white/10 rounded-xl flex flex-col overflow-hidden">
              <div className="p-3 border-b border-white/10 bg-zinc-950/80 flex items-center justify-between">
                <span className="text-xs font-mono text-purple-300 font-bold">
                  Generated Payload Output
                </span>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(generatedData);
                    setCopied(true);
                    setTimeout(() => setCopied(false), 2000);
                  }}
                  className="px-2.5 py-1 rounded bg-white/5 hover:bg-white/10 text-xs font-medium text-zinc-300 flex items-center gap-1 cursor-pointer transition-colors"
                >
                  {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                  {copied ? 'Copied' : 'Copy'}
                </button>
              </div>

              <div className="flex-1 p-3 font-mono text-xs text-purple-200 overflow-auto custom-scrollbar whitespace-pre-wrap">
                {generatedData}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Add Storage Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-[1000] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-zinc-900 border border-white/10 rounded-2xl p-5 space-y-4 shadow-2xl">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Add LocalStorage Key</h3>
            <input
              type="text"
              placeholder="Key Name (e.g. user_theme)"
              value={newKey}
              onChange={(e) => setNewKey(e.target.value)}
              className="w-full bg-zinc-950 border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono outline-none focus:border-purple-500"
            />
            <input
              type="text"
              placeholder="Key Value (e.g. dark)"
              value={newValue}
              onChange={(e) => setNewValue(e.target.value)}
              className="w-full bg-zinc-950 border border-white/10 rounded-lg p-2.5 text-xs text-white font-mono outline-none focus:border-purple-500"
            />
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowAddModal(false)}
                className="px-4 py-2 rounded-lg bg-white/5 text-xs font-medium text-zinc-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleAddStorageKey}
                className="px-4 py-2 rounded-lg bg-purple-500 text-xs font-bold text-white hover:bg-purple-400"
              >
                Add Key
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DatabaseStudio;
