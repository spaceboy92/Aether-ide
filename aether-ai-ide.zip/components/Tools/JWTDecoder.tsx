import React, { useState, useMemo } from 'react';
import { X, KeyRound, Copy, Check, AlertCircle, Clock, ShieldCheck, FileJson, Sparkles } from 'lucide-react';

interface JWTDecoderProps {
  onClose: () => void;
}

const SAMPLE_JWT = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkFldGhlciBEZXZlbG9wZXIiLCJyb2xlIjoiQWRtaW4iLCJpYXQiOjE1MTYyMzkwMDAsImV4cCI6MjUyNDYwODAwMH0.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c";

export const JWTDecoder: React.FC<JWTDecoderProps> = ({ onClose }) => {
  const [token, setToken] = useState<string>(SAMPLE_JWT);
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const decoded = useMemo(() => {
    if (!token.trim()) return null;
    const parts = token.trim().split('.');
    if (parts.length !== 3) return { error: "Invalid JWT structure (must contain exactly 3 dot-separated parts)" };

    try {
      const base64UrlDecode = (str: string) => {
        let base64 = str.replace(/-/g, '+').replace(/_/g, '/');
        while (base64.length % 4) {
          base64 += '=';
        }
        return decodeURIComponent(
          atob(base64)
            .split('')
            .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
            .join('')
        );
      };

      const headerObj = JSON.parse(base64UrlDecode(parts[0]));
      const payloadObj = JSON.parse(base64UrlDecode(parts[1]));
      const signatureStr = parts[2];

      let expStatus = "NO_EXP";
      let expDate: Date | null = null;
      let isExpired = false;

      if (payloadObj.exp) {
        expDate = new Date(payloadObj.exp * 1000);
        isExpired = Date.now() > payloadObj.exp * 1000;
        expStatus = isExpired ? "EXPIRED" : "VALID";
      }

      return {
        header: headerObj,
        payload: payloadObj,
        signature: signatureStr,
        expStatus,
        expDate,
        isExpired,
        alg: headerObj.alg || "UNKNOWN",
      };
    } catch (err: any) {
      return { error: `Decode failed: ${err.message || 'Invalid Base64Url string'}` };
    }
  }, [token]);

  const copyToClipboard = (text: string, section: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(section);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 backdrop-blur-md p-4 animate-in fade-in zoom-in-95">
      <div className="w-full max-w-4xl bg-zinc-950 border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between bg-zinc-900/50">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-orange-500/10 border border-orange-500/20 text-orange-400">
              <KeyRound size={20} />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                JWT Token Decoder & Inspector
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-orange-500/20 text-orange-300 font-semibold border border-orange-500/30">
                  Tool
                </span>
              </h2>
              <p className="text-xs text-zinc-400">Decode, inspect claims, algorithm, and validity of JSON Web Tokens instantly.</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg text-zinc-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-sm">
          {/* Input Field */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-bold text-zinc-300 uppercase tracking-wider font-mono">
                Encoded Token (Paste JWT)
              </label>
              <button
                onClick={() => setToken(SAMPLE_JWT)}
                className="text-[11px] text-orange-400 hover:underline flex items-center gap-1 font-mono cursor-pointer"
              >
                <Sparkles size={12} />
                Load Sample JWT
              </button>
            </div>
            <textarea
              value={token}
              onChange={(e) => setToken(e.target.value)}
              placeholder="Paste eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
              className="w-full h-24 p-3 bg-zinc-900/90 border border-white/10 rounded-xl font-mono text-xs text-orange-200 focus:outline-none focus:border-orange-500/50 transition-all resize-none"
            />
          </div>

          {/* Decoding Errors */}
          {decoded?.error && (
            <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 flex items-center gap-3">
              <AlertCircle size={18} className="shrink-0" />
              <div className="font-mono text-xs">{decoded.error}</div>
            </div>
          )}

          {/* Decoded Results */}
          {decoded && !decoded.error && (
            <div className="space-y-6">
              {/* Token Status Badges */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-3 rounded-xl bg-zinc-900/70 border border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-zinc-400 text-xs">
                    <ShieldCheck size={16} className="text-orange-400" />
                    <span>Algorithm</span>
                  </div>
                  <span className="font-mono font-bold text-xs text-orange-300 uppercase">{decoded.alg}</span>
                </div>

                <div className="p-3 rounded-xl bg-zinc-900/70 border border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-zinc-400 text-xs">
                    <Clock size={16} className="text-blue-400" />
                    <span>Expiration</span>
                  </div>
                  {decoded.expStatus === 'VALID' ? (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-green-500/20 text-green-400 border border-green-500/30">
                      VALID
                    </span>
                  ) : decoded.expStatus === 'EXPIRED' ? (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-500/20 text-red-400 border border-red-500/30">
                      EXPIRED
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-zinc-500/20 text-zinc-400 border border-zinc-500/30">
                      NO EXPIRY
                    </span>
                  )}
                </div>

                <div className="p-3 rounded-xl bg-zinc-900/70 border border-white/5 flex items-center justify-between">
                  <div className="flex items-center gap-2 text-zinc-400 text-xs">
                    <FileJson size={16} className="text-purple-400" />
                    <span>Expires At</span>
                  </div>
                  <span className="font-mono text-[11px] text-zinc-300">
                    {decoded.expDate ? decoded.expDate.toLocaleTimeString() : 'N/A'}
                  </span>
                </div>
              </div>

              {/* Grid Layout for Header, Payload, Signature */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Header */}
                <div className="p-4 rounded-xl bg-zinc-900/80 border border-red-500/20 space-y-2">
                  <div className="flex items-center justify-between border-b border-white/5 pb-2">
                    <span className="text-xs font-bold font-mono text-red-400 uppercase tracking-wider">
                      Header: Algorithm & Type
                    </span>
                    <button
                      onClick={() => copyToClipboard(JSON.stringify(decoded.header, null, 2), 'header')}
                      className="p-1 rounded hover:bg-white/10 text-zinc-400 hover:text-white transition-colors"
                      title="Copy Header JSON"
                    >
                      {copiedSection === 'header' ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
                    </button>
                  </div>
                  <pre className="font-mono text-xs text-red-300 overflow-x-auto p-2 bg-black/40 rounded-lg">
                    {JSON.stringify(decoded.header, null, 2)}
                  </pre>
                </div>

                {/* Payload */}
                <div className="p-4 rounded-xl bg-zinc-900/80 border border-purple-500/20 space-y-2">
                  <div className="flex items-center justify-between border-b border-white/5 pb-2">
                    <span className="text-xs font-bold font-mono text-purple-400 uppercase tracking-wider">
                      Payload: Claims & Data
                    </span>
                    <button
                      onClick={() => copyToClipboard(JSON.stringify(decoded.payload, null, 2), 'payload')}
                      className="p-1 rounded hover:bg-white/10 text-zinc-400 hover:text-white transition-colors"
                      title="Copy Payload JSON"
                    >
                      {copiedSection === 'payload' ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
                    </button>
                  </div>
                  <pre className="font-mono text-xs text-purple-300 overflow-x-auto p-2 bg-black/40 rounded-lg max-h-60">
                    {JSON.stringify(decoded.payload, null, 2)}
                  </pre>
                </div>
              </div>

              {/* Signature */}
              <div className="p-4 rounded-xl bg-zinc-900/80 border border-cyan-500/20 space-y-2">
                <div className="flex items-center justify-between border-b border-white/5 pb-2">
                  <span className="text-xs font-bold font-mono text-cyan-400 uppercase tracking-wider">
                    Signature Verification Hash
                  </span>
                  <button
                    onClick={() => copyToClipboard(decoded.signature || '', 'sig')}
                    className="p-1 rounded hover:bg-white/10 text-zinc-400 hover:text-white transition-colors"
                    title="Copy Signature"
                  >
                    {copiedSection === 'sig' ? <Check size={14} className="text-green-400" /> : <Copy size={14} />}
                  </button>
                </div>
                <div className="font-mono text-xs text-cyan-300 break-all p-2 bg-black/40 rounded-lg">
                  {decoded.signature || 'Unsigned Token'}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default JWTDecoder;
