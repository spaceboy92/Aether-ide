import React, { useState } from 'react';
import { 
  Volume2, 
  Play, 
  Square, 
  Sparkles, 
  Copy, 
  Check, 
  Download, 
  Sliders, 
  Radio, 
  Zap, 
  Music, 
  Music2,
  FolderPlus
} from 'lucide-react';
import { FileNode } from '../../types';

interface AudioSynthStudioProps {
  onAddFileToWorkspace?: (file: FileNode) => void;
}

export const AudioSynthStudio: React.FC<AudioSynthStudioProps> = ({ onAddFileToWorkspace }) => {
  const [preset, setPreset] = useState<'laser' | 'ui_click' | 'powerup' | 'alarm' | 'ambient'>('ui_click');
  const [frequency, setFrequency] = useState<number>(440);
  const [duration, setDuration] = useState<number>(0.2);
  const [waveType, setWaveType] = useState<OscillatorType>('sine');
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  // Web Audio Synthesizer Trigger
  const playSynthesizedSound = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;

      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = waveType;
      
      // Preset frequencies & modulation
      if (preset === 'laser') {
        osc.frequency.setValueAtTime(800, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(100, ctx.currentTime + duration);
      } else if (preset === 'powerup') {
        osc.frequency.setValueAtTime(200, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(1200, ctx.currentTime + duration);
      } else if (preset === 'alarm') {
        osc.frequency.setValueAtTime(frequency, ctx.currentTime);
        osc.frequency.setValueAtTime(frequency * 1.5, ctx.currentTime + duration / 2);
      } else {
        osc.frequency.setValueAtTime(frequency, ctx.currentTime);
      }

      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + duration);

      setIsPlaying(true);
      setTimeout(() => setIsPlaying(false), duration * 1000);
    } catch (e) {
      console.warn("Audio Context playback error:", e);
    }
  };

  const getAudioCode = () => {
    return `// Web Audio API Procedural Sound Synthesizer\nexport const play${preset.charAt(0).toUpperCase() + preset.slice(1)}Sound = () => {\n  const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;\n  if (!AudioCtx) return;\n  const ctx = new AudioCtx();\n  const osc = ctx.createOscillator();\n  const gain = ctx.createGain();\n\n  osc.type = '${waveType}';\n  osc.frequency.setValueAtTime(${frequency}, ctx.currentTime);\n  gain.gain.setValueAtTime(0.3, ctx.currentTime);\n  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + ${duration});\n\n  osc.connect(gain);\n  gain.connect(ctx.destination);\n  osc.start();\n  osc.stop(ctx.currentTime + ${duration});\n};\n`;
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(getAudioCode());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleInjectFile = () => {
    if (!onAddFileToWorkspace) return;
    const fileName = `audioSynth.ts`;
    onAddFileToWorkspace({
      id: `f_sound_${Date.now()}`,
      name: fileName,
      language: 'typescript',
      content: getAudioCode(),
      lastModified: Date.now()
    });
    alert(`Created file "${fileName}" in workspace!`);
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0c10] text-zinc-200 select-none overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-white/10 flex items-center justify-between bg-zinc-900/60 shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
            <Volume2 size={20} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              Web Audio & Sound FX Studio
              <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                AUDIO SYNTH
              </span>
            </h2>
            <p className="text-[11px] text-zinc-400">Synthesize UI clicks, game sound effects, and audio feedback procedurally</p>
          </div>
        </div>

        {onAddFileToWorkspace && (
          <button
            onClick={handleInjectFile}
            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-black text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-cyan-950/40 transition-all cursor-pointer"
          >
            <FolderPlus size={14} /> Export Audio Module
          </button>
        )}
      </div>

      <div className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-hidden">
        {/* Left Column: Sound Controls */}
        <div className="w-full lg:w-80 p-4 border-r border-white/10 bg-zinc-900/30 flex flex-col space-y-4 shrink-0 overflow-y-auto custom-scrollbar">
          {/* Preset Selector */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">Sound FX Preset</label>
            <div className="grid grid-cols-2 gap-1.5">
              {(['ui_click', 'laser', 'powerup', 'alarm', 'ambient'] as const).map((p) => (
                <button
                  key={p}
                  onClick={() => {
                    setPreset(p);
                    if (p === 'ui_click') { setFrequency(600); setDuration(0.08); setWaveType('sine'); }
                    else if (p === 'laser') { setFrequency(800); setDuration(0.25); setWaveType('sawtooth'); }
                    else if (p === 'powerup') { setFrequency(300); setDuration(0.4); setWaveType('triangle'); }
                    else if (p === 'alarm') { setFrequency(900); setDuration(0.5); setWaveType('square'); }
                    else { setFrequency(220); setDuration(1.2); setWaveType('sine'); }
                  }}
                  className={`p-2 rounded-lg text-xs font-medium uppercase transition-colors cursor-pointer ${
                    preset === p ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold' : 'bg-zinc-950 text-zinc-400 border border-white/5'
                  }`}
                >
                  {p.replace('_', ' ')}
                </button>
              ))}
            </div>
          </div>

          {/* Waveform Selector */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider block">Oscillator Waveform</label>
            <div className="grid grid-cols-2 gap-1.5">
              {(['sine', 'square', 'sawtooth', 'triangle'] as const).map((w) => (
                <button
                  key={w}
                  onClick={() => setWaveType(w)}
                  className={`p-2 rounded-lg text-xs font-mono font-medium uppercase transition-colors cursor-pointer ${
                    waveType === w ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold' : 'bg-zinc-950 text-zinc-400 border border-white/5'
                  }`}
                >
                  {w}
                </button>
              ))}
            </div>
          </div>

          {/* Frequency Slider */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-[11px] font-bold text-zinc-400 uppercase">
              <span>Frequency ({frequency} Hz)</span>
            </div>
            <input
              type="range"
              min="100"
              max="2000"
              value={frequency}
              onChange={(e) => setFrequency(parseInt(e.target.value))}
              className="w-full accent-cyan-500 cursor-pointer"
            />
          </div>

          {/* Duration Slider */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-[11px] font-bold text-zinc-400 uppercase">
              <span>Duration ({duration.toFixed(2)}s)</span>
            </div>
            <input
              type="range"
              min="0.05"
              max="2.0"
              step="0.05"
              value={duration}
              onChange={(e) => setDuration(parseFloat(e.target.value))}
              className="w-full accent-cyan-500 cursor-pointer"
            />
          </div>

          {/* Play Test Button */}
          <button
            onClick={playSynthesizedSound}
            className={`w-full p-3 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer shadow-xl ${
              isPlaying ? 'bg-emerald-500 text-black shadow-emerald-950/40' : 'bg-gradient-to-r from-cyan-500 to-blue-600 text-black hover:from-cyan-400 hover:to-blue-500 shadow-cyan-950/40'
            }`}
          >
            <Play size={16} className={isPlaying ? 'animate-bounce' : ''} />
            {isPlaying ? 'Synthesizing...' : 'Play Sound FX'}
          </button>
        </div>

        {/* Right Column: Generated Synthesizer Code */}
        <div className="flex-1 flex flex-col p-4 space-y-4 overflow-hidden">
          <div className="flex-1 bg-zinc-900 border border-white/10 rounded-2xl flex flex-col overflow-hidden">
            <div className="p-3 border-b border-white/10 bg-zinc-950/80 flex items-center justify-between">
              <span className="text-xs font-mono text-cyan-300 font-bold flex items-center gap-1.5">
                <Music size={14} /> Web Audio API TypeScript Code
              </span>
              <button
                onClick={handleCopyCode}
                className="px-2.5 py-1 rounded bg-white/5 hover:bg-white/10 text-xs font-medium text-zinc-300 flex items-center gap-1 cursor-pointer"
              >
                {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                {copied ? 'Copied' : 'Copy Code'}
              </button>
            </div>

            <pre className="flex-1 p-4 font-mono text-xs text-cyan-200/90 overflow-auto custom-scrollbar whitespace-pre-wrap">
              {getAudioCode()}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AudioSynthStudio;
