import React, { useState } from 'react';
import { 
  Send, 
  Clock, 
  Code2, 
  Copy, 
  Check, 
  Plus, 
  Trash2, 
  RefreshCw, 
  Globe, 
  FileJson, 
  Sliders, 
  History, 
  Sparkles,
  Zap,
  CheckCircle2,
  AlertTriangle,
  XCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface KeyValue {
  id: string;
  key: string;
  value: string;
  active: boolean;
}

interface RequestHistoryItem {
  id: string;
  timestamp: string;
  method: string;
  url: string;
  status: number | null;
  timeMs: number | null;
}

export const ApiPlayground: React.FC = () => {
  const [method, setMethod] = useState<'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH'>('GET');
  const [url, setUrl] = useState('/api/health');
  const [activeTab, setActiveTab] = useState<'params' | 'headers' | 'body' | 'history'>('params');
  const [responseTab, setResponseTab] = useState<'body' | 'headers' | 'raw'>('body');

  const [params, setParams] = useState<KeyValue[]>([
    { id: '1', key: 'format', value: 'json', active: true },
    { id: '2', key: 'verbose', value: 'true', active: false }
  ]);

  const [headers, setHeaders] = useState<KeyValue[]>([
    { id: '1', key: 'Content-Type', value: 'application/json', active: true },
    { id: '2', key: 'Accept', value: 'application/json', active: true }
  ]);

  const [bodyContent, setBodyContent] = useState<string>('{\n  "query": "Aether AI Test",\n  "model": "gemini-3.7-flash"\n}');
  const [isLoading, setIsLoading] = useState(false);
  const [response, setResponse] = useState<{
    status: number;
    statusText: string;
    timeMs: number;
    headers: Record<string, string>;
    data: any;
    error?: string;
  } | null>(null);

  const [history, setHistory] = useState<RequestHistoryItem[]>([
    { id: 'h1', timestamp: '10:42 AM', method: 'GET', url: '/api/health', status: 200, timeMs: 42 },
    { id: 'h2', timestamp: '10:45 AM', method: 'POST', url: '/api/ai/generate', status: 200, timeMs: 310 }
  ]);

  const [copied, setCopied] = useState(false);

  const predefinedEndpoints = [
    { label: 'System Health', method: 'GET', url: '/api/health' },
    { label: 'AI Generate Task', method: 'POST', url: '/api/ai/generate-task' },
    { label: 'Publish Applet', method: 'POST', url: '/api/publish' },
    { label: 'JSONPlaceholder Test', method: 'GET', url: 'https://jsonplaceholder.typicode.com/todos/1' },
    { label: 'GitHub Octocat API', method: 'GET', url: 'https://api.github.com/users/octocat' }
  ];

  const handleSend = async () => {
    setIsLoading(true);
    const startTime = performance.now();

    // Construct URL with query parameters
    let finalUrl = url;
    const activeParams = params.filter(p => p.active && p.key.trim());
    if (activeParams.length > 0) {
      const searchParams = new URLSearchParams();
      activeParams.forEach(p => searchParams.append(p.key, p.value));
      const separator = finalUrl.includes('?') ? '&' : '?';
      finalUrl += separator + searchParams.toString();
    }

    // Construct headers
    const reqHeaders: Record<string, string> = {};
    headers.filter(h => h.active && h.key.trim()).forEach(h => {
      reqHeaders[h.key] = h.value;
    });

    try {
      const options: RequestInit = {
        method,
        headers: reqHeaders
      };

      if (['POST', 'PUT', 'PATCH'].includes(method) && bodyContent.trim()) {
        options.body = bodyContent;
      }

      const res = await fetch(finalUrl, options);
      const endTime = performance.now();
      const timeMs = Math.round(endTime - startTime);

      const resHeaders: Record<string, string> = {};
      res.headers.forEach((val, key) => {
        resHeaders[key] = val;
      });

      let data: any;
      const contentType = res.headers.get('content-type') || '';
      if (contentType.includes('application/json')) {
        data = await res.json();
      } else {
        data = await res.text();
      }

      const resObj = {
        status: res.status,
        statusText: res.statusText || (res.status === 200 ? 'OK' : 'Response Received'),
        timeMs,
        headers: resHeaders,
        data
      };

      setResponse(resObj);

      setHistory(prev => [
        {
          id: Date.now().toString(),
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          method,
          url: finalUrl,
          status: res.status,
          timeMs
        },
        ...prev.slice(0, 19)
      ]);

    } catch (err: any) {
      const endTime = performance.now();
      setResponse({
        status: 0,
        statusText: 'Network Error / Cors Issue',
        timeMs: Math.round(endTime - startTime),
        headers: {},
        data: null,
        error: err.message || 'Failed to fetch'
      });

      setHistory(prev => [
        {
          id: Date.now().toString(),
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          method,
          url: finalUrl,
          status: 0,
          timeMs: Math.round(endTime - startTime)
        },
        ...prev.slice(0, 19)
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrettifyBody = () => {
    try {
      const parsed = JSON.parse(bodyContent);
      setBodyContent(JSON.stringify(parsed, null, 2));
    } catch (e) {
      // Invalid JSON, leave as is
    }
  };

  const getStatusBadge = (status: number) => {
    if (status >= 200 && status < 300) {
      return (
        <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
          <CheckCircle2 size={12} /> {status} {response?.statusText}
        </span>
      );
    }
    if (status >= 400 && status < 500) {
      return (
        <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30 flex items-center gap-1">
          <AlertTriangle size={12} /> {status} {response?.statusText}
        </span>
      );
    }
    return (
      <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-rose-500/10 text-rose-400 border border-rose-500/30 flex items-center gap-1">
        <XCircle size={12} /> {status || 'ERR'} {response?.statusText}
      </span>
    );
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0c10] text-zinc-200 select-none overflow-hidden">
      {/* Top Header */}
      <div className="p-4 border-b border-white/10 flex items-center justify-between bg-zinc-900/60 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
            <Globe size={18} />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              HTTP & REST API Playground
              <span className="text-[9px] uppercase font-mono px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                PRO STUDIO
              </span>
            </h2>
            <p className="text-[11px] text-zinc-400">Test backend endpoints, headers, and payload structures in real-time</p>
          </div>
        </div>

        {/* Quick presets */}
        <div className="hidden lg:flex items-center gap-1.5">
          <span className="text-[10px] uppercase font-bold text-zinc-500 mr-1">Endpoints:</span>
          {predefinedEndpoints.map((ep, i) => (
            <button
              key={i}
              onClick={() => {
                setMethod(ep.method as any);
                setUrl(ep.url);
              }}
              className="px-2 py-1 rounded-md text-[10px] font-medium bg-white/5 hover:bg-white/10 text-zinc-300 hover:text-white border border-white/10 transition-colors"
            >
              {ep.label}
            </button>
          ))}
        </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-hidden">
        {/* Left / Top: Request Builder */}
        <div className="flex-1 flex flex-col p-4 space-y-4 border-r border-white/10 overflow-y-auto custom-scrollbar">
          {/* Method & URL Bar */}
          <div className="flex items-center gap-2">
            <select
              value={method}
              onChange={(e) => setMethod(e.target.value as any)}
              className={`
                px-3 py-2 rounded-xl font-mono font-bold text-xs border outline-none cursor-pointer transition-all
                ${method === 'GET' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : ''}
                ${method === 'POST' ? 'bg-blue-500/10 text-blue-400 border-blue-500/30' : ''}
                ${method === 'PUT' ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' : ''}
                ${method === 'DELETE' ? 'bg-rose-500/10 text-rose-400 border-rose-500/30' : ''}
                ${method === 'PATCH' ? 'bg-purple-500/10 text-purple-400 border-purple-500/30' : ''}
              `}
            >
              <option value="GET" className="bg-zinc-900 text-emerald-400">GET</option>
              <option value="POST" className="bg-zinc-900 text-blue-400">POST</option>
              <option value="PUT" className="bg-zinc-900 text-amber-400">PUT</option>
              <option value="DELETE" className="bg-zinc-900 text-rose-400">DELETE</option>
              <option value="PATCH" className="bg-zinc-900 text-purple-400">PATCH</option>
            </select>

            <div className="flex-1 flex items-center bg-zinc-900 border border-white/10 rounded-xl px-3 py-2 text-xs font-mono text-zinc-200 focus-within:border-cyan-500/50 transition-colors">
              <input
                type="text"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://api.example.com/v1/resource or /api/health"
                className="w-full bg-transparent border-none outline-none text-zinc-100 placeholder:text-zinc-600 font-mono"
              />
            </div>

            <button
              onClick={handleSend}
              disabled={isLoading || !url.trim()}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-cyan-950/40 transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
            >
              {isLoading ? (
                <>
                  <RefreshCw size={14} className="animate-spin" /> Requesting...
                </>
              ) : (
                <>
                  <Send size={14} /> Send
                </>
              )}
            </button>
          </div>

          {/* Request Configuration Tabs */}
          <div className="flex-1 flex flex-col bg-zinc-900/40 border border-white/10 rounded-xl overflow-hidden min-h-[280px]">
            <div className="flex items-center gap-1 border-b border-white/10 px-3 bg-zinc-900/80">
              {[
                { id: 'params', label: `Params (${params.filter(p => p.active).length})` },
                { id: 'headers', label: `Headers (${headers.filter(h => h.active).length})` },
                { id: 'body', label: 'Body (JSON)' },
                { id: 'history', label: `History (${history.length})` }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`
                    px-3 py-2.5 text-xs font-medium border-b-2 transition-colors cursor-pointer
                    ${activeTab === tab.id 
                      ? 'border-cyan-400 text-cyan-300 font-semibold' 
                      : 'border-transparent text-zinc-400 hover:text-zinc-200'}
                  `}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="flex-1 p-3 overflow-y-auto custom-scrollbar">
              {activeTab === 'params' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-[11px] font-bold text-zinc-400 uppercase tracking-wider px-1">
                    <span>Query Parameters</span>
                    <button
                      onClick={() => setParams(prev => [...prev, { id: Date.now().toString(), key: '', value: '', active: true }])}
                      className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 cursor-pointer"
                    >
                      <Plus size={12} /> Add Parameter
                    </button>
                  </div>
                  {params.map((p, index) => (
                    <div key={p.id} className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={p.active}
                        onChange={(e) => {
                          const newP = [...params];
                          newP[index].active = e.target.checked;
                          setParams(newP);
                        }}
                        className="accent-cyan-500 rounded cursor-pointer"
                      />
                      <input
                        type="text"
                        placeholder="Key"
                        value={p.key}
                        onChange={(e) => {
                          const newP = [...params];
                          newP[index].key = e.target.value;
                          setParams(newP);
                        }}
                        className="flex-1 bg-zinc-950 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs font-mono text-zinc-200 focus:border-cyan-500/50 outline-none"
                      />
                      <input
                        type="text"
                        placeholder="Value"
                        value={p.value}
                        onChange={(e) => {
                          const newP = [...params];
                          newP[index].value = e.target.value;
                          setParams(newP);
                        }}
                        className="flex-1 bg-zinc-950 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs font-mono text-zinc-200 focus:border-cyan-500/50 outline-none"
                      />
                      <button
                        onClick={() => setParams(params.filter(x => x.id !== p.id))}
                        className="p-1.5 text-zinc-500 hover:text-rose-400 rounded hover:bg-white/5 cursor-pointer"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'headers' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-[11px] font-bold text-zinc-400 uppercase tracking-wider px-1">
                    <span>HTTP Request Headers</span>
                    <button
                      onClick={() => setHeaders(prev => [...prev, { id: Date.now().toString(), key: '', value: '', active: true }])}
                      className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 cursor-pointer"
                    >
                      <Plus size={12} /> Add Header
                    </button>
                  </div>
                  {headers.map((h, index) => (
                    <div key={h.id} className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={h.active}
                        onChange={(e) => {
                          const newH = [...headers];
                          newH[index].active = e.target.checked;
                          setHeaders(newH);
                        }}
                        className="accent-cyan-500 rounded cursor-pointer"
                      />
                      <input
                        type="text"
                        placeholder="Header Name"
                        value={h.key}
                        onChange={(e) => {
                          const newH = [...headers];
                          newH[index].key = e.target.value;
                          setHeaders(newH);
                        }}
                        className="flex-1 bg-zinc-950 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs font-mono text-zinc-200 focus:border-cyan-500/50 outline-none"
                      />
                      <input
                        type="text"
                        placeholder="Header Value"
                        value={h.value}
                        onChange={(e) => {
                          const newH = [...headers];
                          newH[index].value = e.target.value;
                          setHeaders(newH);
                        }}
                        className="flex-1 bg-zinc-950 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs font-mono text-zinc-200 focus:border-cyan-500/50 outline-none"
                      />
                      <button
                        onClick={() => setHeaders(headers.filter(x => x.id !== h.id))}
                        className="p-1.5 text-zinc-500 hover:text-rose-400 rounded hover:bg-white/5 cursor-pointer"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'body' && (
                <div className="flex flex-col h-full space-y-2">
                  <div className="flex items-center justify-between text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
                    <span>JSON Payload</span>
                    <button
                      onClick={handlePrettifyBody}
                      className="flex items-center gap-1 text-xs text-cyan-400 hover:text-cyan-300 font-mono cursor-pointer"
                    >
                      <Sparkles size={12} /> Prettify JSON
                    </button>
                  </div>
                  <textarea
                    value={bodyContent}
                    onChange={(e) => setBodyContent(e.target.value)}
                    placeholder="Enter JSON payload..."
                    rows={8}
                    className="w-full flex-1 bg-zinc-950 border border-white/10 rounded-xl p-3 font-mono text-xs text-cyan-200 focus:border-cyan-500/50 outline-none resize-none"
                  />
                </div>
              )}

              {activeTab === 'history' && (
                <div className="space-y-1.5">
                  <div className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider px-1 mb-2">
                    Recent Requests
                  </div>
                  {history.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => {
                        setUrl(item.url);
                        setMethod(item.method as any);
                      }}
                      className="flex items-center justify-between p-2 rounded-lg bg-zinc-950/60 border border-white/5 hover:border-white/15 cursor-pointer transition-all hover:bg-zinc-900/80"
                    >
                      <div className="flex items-center gap-2 font-mono text-xs">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          item.method === 'GET' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-blue-500/20 text-blue-400'
                        }`}>
                          {item.method}
                        </span>
                        <span className="text-zinc-200 font-medium truncate max-w-[200px]">{item.url}</span>
                      </div>
                      <div className="flex items-center gap-3 text-[11px] font-mono text-zinc-400">
                        {item.status !== null && (
                          <span className={item.status === 200 ? 'text-emerald-400' : 'text-rose-400'}>
                            {item.status}
                          </span>
                        )}
                        {item.timeMs !== null && <span>{item.timeMs}ms</span>}
                        <span className="text-[10px] text-zinc-500">{item.timestamp}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right / Bottom: Response Inspector */}
        <div className="flex-1 flex flex-col p-4 bg-zinc-950/40 min-h-[300px]">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                Response Output
              </span>
              {response && getStatusBadge(response.status)}
              {response && response.timeMs && (
                <span className="flex items-center gap-1 text-xs font-mono text-zinc-400">
                  <Clock size={12} className="text-cyan-400" /> {response.timeMs} ms
                </span>
              )}
            </div>

            {response && (
              <button
                onClick={() => handleCopy(typeof response.data === 'object' ? JSON.stringify(response.data, null, 2) : String(response.data))}
                className="px-2.5 py-1 rounded bg-white/5 hover:bg-white/10 text-xs font-medium text-zinc-300 flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                {copied ? 'Copied' : 'Copy Response'}
              </button>
            )}
          </div>

          <div className="flex-1 flex flex-col bg-zinc-900 border border-white/10 rounded-xl overflow-hidden">
            <div className="flex items-center gap-1 border-b border-white/10 px-3 bg-zinc-950/80">
              {['body', 'headers', 'raw'].map((t) => (
                <button
                  key={t}
                  onClick={() => setResponseTab(t as any)}
                  className={`
                    px-3 py-2 text-xs font-medium border-b-2 uppercase transition-colors cursor-pointer
                    ${responseTab === t ? 'border-cyan-400 text-cyan-300 font-bold' : 'border-transparent text-zinc-400 hover:text-zinc-200'}
                  `}
                >
                  {t}
                </button>
              ))}
            </div>

            <div className="flex-1 p-3 overflow-auto custom-scrollbar font-mono text-xs">
              {!response && !isLoading && (
                <div className="h-full flex flex-col items-center justify-center text-zinc-500 space-y-2 py-12">
                  <Zap size={32} className="text-zinc-700" />
                  <p className="text-xs">Send an HTTP request above to view status, headers, and payload response.</p>
                </div>
              )}

              {isLoading && (
                <div className="h-full flex flex-col items-center justify-center text-cyan-400 space-y-3 py-12">
                  <RefreshCw size={28} className="animate-spin text-cyan-400" />
                  <p className="text-xs font-mono uppercase tracking-wider">Dispatching request to server target...</p>
                </div>
              )}

              {response && responseTab === 'body' && (
                <pre className="text-cyan-300 whitespace-pre-wrap font-mono text-xs">
                  {typeof response.data === 'object' 
                    ? JSON.stringify(response.data, null, 2) 
                    : String(response.data || response.error || 'Empty Response')}
                </pre>
              )}

              {response && responseTab === 'headers' && (
                <div className="space-y-1">
                  {Object.entries(response.headers).map(([k, v]) => (
                    <div key={k} className="flex gap-2">
                      <span className="text-purple-400 font-bold">{k}:</span>
                      <span className="text-zinc-300">{v}</span>
                    </div>
                  ))}
                </div>
              )}

              {response && responseTab === 'raw' && (
                <pre className="text-zinc-300 whitespace-pre-wrap font-mono text-xs">
                  {`HTTP Status: ${response.status} ${response.statusText}\nLatency: ${response.timeMs}ms\n\nHeaders:\n${JSON.stringify(response.headers, null, 2)}\n\nPayload:\n${typeof response.data === 'object' ? JSON.stringify(response.data, null, 2) : String(response.data)}`}
                </pre>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ApiPlayground;
