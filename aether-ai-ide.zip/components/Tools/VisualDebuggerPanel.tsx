import React, { useState } from 'react';
import { Play, Pause, SkipForward, ArrowDown, ArrowUp, Bug, Trash2, Eye, Code, Shield } from 'lucide-react';

interface VariableWatch {
  name: string;
  type: string;
  value: string;
}

interface VisualDebuggerPanelProps {
  filePath?: string;
  breakpoints: number[];
  onClearBreakpoints: () => void;
  onRemoveBreakpoint: (line: number) => void;
}

export const VisualDebuggerPanel: React.FC<VisualDebuggerPanelProps> = ({
  filePath = 'main.ts',
  breakpoints,
  onClearBreakpoints,
  onRemoveBreakpoint
}) => {
  const [isPaused, setIsPaused] = useState(false);
  const [activeCallStack, setActiveCallStack] = useState<string[]>([
    'main() [line 12]',
    'handleExecute() [line 45]',
    'eventLoop() [line 102]'
  ]);
  const [variables, setVariables] = useState<VariableWatch[]>([
    { name: 'status', type: 'string', value: '"running"' },
    { name: 'sessionCount', type: 'number', value: '42' },
    { name: 'payload', type: 'object', value: '{ id: "ae-102", ready: true }' }
  ]);
  const [newVarName, setNewVarName] = useState('');

  const handleAddWatch = () => {
    if (!newVarName.trim()) return;
    setVariables(prev => [...prev, { name: newVarName.trim(), type: 'expression', value: 'undefined' }]);
    setNewVarName('');
  };

  return (
    <div className="h-full w-full bg-aether-bg border border-aether-border rounded-lg flex flex-col overflow-hidden text-xs">
      
      {/* Debug Control Bar */}
      <div className="px-4 py-2 border-b border-aether-border bg-aether-panel/80 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bug size={15} className="text-aether-accent" />
          <span className="font-bold text-slate-200 uppercase tracking-wider text-[11px]">DAP Visual Debugger</span>
          <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
            isPaused ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
          }`}>
            {isPaused ? 'PAUSED' : 'ACTIVE'}
          </span>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1">
          <button
            onClick={() => setIsPaused(!isPaused)}
            className="p-1.5 rounded hover:bg-slate-800 text-slate-200 transition-colors"
            title={isPaused ? "Resume (F5)" : "Pause Execution"}
          >
            {isPaused ? <Play size={14} className="text-emerald-400 fill-current" /> : <Pause size={14} className="text-amber-400" />}
          </button>
          <button
            className="p-1.5 rounded hover:bg-slate-800 text-slate-300 transition-colors"
            title="Step Over (F10)"
          >
            <SkipForward size={14} />
          </button>
          <button
            className="p-1.5 rounded hover:bg-slate-800 text-slate-300 transition-colors"
            title="Step Into (F11)"
          >
            <ArrowDown size={14} />
          </button>
          <button
            className="p-1.5 rounded hover:bg-slate-800 text-slate-300 transition-colors"
            title="Step Out (Shift+F11)"
          >
            <ArrowUp size={14} />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        
        {/* Active Breakpoints */}
        <div className="p-3 rounded-lg border border-aether-border bg-aether-panel/40">
          <div className="flex items-center justify-between mb-2">
            <span className="font-bold text-slate-300 text-[11px] flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
              Breakpoints ({breakpoints.length})
            </span>
            {breakpoints.length > 0 && (
              <button 
                onClick={onClearBreakpoints}
                className="text-[10px] text-red-400 hover:text-red-300 transition-colors flex items-center gap-1"
              >
                <Trash2 size={11} /> Clear All
              </button>
            )}
          </div>

          {breakpoints.length === 0 ? (
            <p className="text-[11px] text-slate-500 italic">Click editor gutter margin to toggle line breakpoints</p>
          ) : (
            <div className="space-y-1">
              {breakpoints.map(line => (
                <div key={line} className="flex items-center justify-between px-2.5 py-1 rounded bg-slate-800/60 border border-slate-700/50 font-mono text-[11px]">
                  <span className="text-slate-300">{filePath} : <strong className="text-red-400">Line {line}</strong></span>
                  <button 
                    onClick={() => onRemoveBreakpoint(line)}
                    className="text-slate-500 hover:text-red-400"
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Variable Watcher */}
        <div className="p-3 rounded-lg border border-aether-border bg-aether-panel/40">
          <div className="flex items-center justify-between mb-2">
            <span className="font-bold text-slate-300 text-[11px] flex items-center gap-1.5">
              <Eye size={12} className="text-aether-accent" />
              Watch Expressions
            </span>
          </div>

          <div className="space-y-1.5 mb-2">
            {variables.map((v, i) => (
              <div key={i} className="flex items-center justify-between px-2.5 py-1.5 rounded bg-slate-900 border border-slate-800 font-mono text-[11px]">
                <span className="text-cyan-400 font-bold">{v.name}</span>
                <span className="text-emerald-300">{v.value}</span>
              </div>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <input 
              type="text"
              placeholder="Add expression to watch..."
              value={newVarName}
              onChange={(e) => setNewVarName(e.target.value)}
              className="flex-1 bg-slate-900 border border-slate-800 rounded px-2 py-1 text-[11px] text-slate-200 placeholder-slate-500 focus:outline-none focus:border-aether-accent"
            />
            <button
              onClick={handleAddWatch}
              className="px-2.5 py-1 rounded bg-aether-accent text-slate-950 font-bold text-[10px]"
            >
              Add
            </button>
          </div>
        </div>

        {/* Call Stack */}
        <div className="p-3 rounded-lg border border-aether-border bg-aether-panel/40">
          <span className="font-bold text-slate-300 text-[11px] flex items-center gap-1.5 mb-2">
            <Code size={12} className="text-purple-400" />
            Call Stack
          </span>
          <div className="space-y-1 font-mono text-[11px]">
            {activeCallStack.map((frame, idx) => (
              <div key={idx} className="px-2.5 py-1 rounded bg-slate-900/60 border border-slate-800/80 text-slate-400 flex items-center gap-2">
                <span className="text-slate-600">#{idx}</span>
                <span className="text-slate-200">{frame}</span>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
