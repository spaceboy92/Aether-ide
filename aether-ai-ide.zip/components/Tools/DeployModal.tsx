import React, { useState, useEffect } from 'react';
import { 
  X, 
  Globe, 
  Rocket, 
  Check, 
  Copy, 
  ExternalLink, 
  Shield, 
  Lock, 
  Sparkles, 
  RefreshCw, 
  Server, 
  QrCode, 
  Activity, 
  Clock,
  ArrowRight,
  Layers,
  CheckCircle2,
  Download
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { deploymentService, DeploymentRecord, DeploymentConfig } from '../../services/deploymentService';
import { FileNode } from '../../types';

interface DeployModalProps {
  isOpen: boolean;
  onClose: () => void;
  files: FileNode[];
  currentSessionTitle?: string;
}

export const DeployModal: React.FC<DeployModalProps> = ({
  isOpen,
  onClose,
  files,
  currentSessionTitle = 'Client Micro-App',
}) => {
  const [config, setConfig] = useState<DeploymentConfig>(deploymentService.getConfig());
  const [deployments, setDeployments] = useState<DeploymentRecord[]>([]);
  const [isDeploying, setIsDeploying] = useState(false);
  const [deployProgress, setDeployProgress] = useState<{ step: string; percent: number }>({
    step: '',
    percent: 0,
  });
  const [activeDeployment, setActiveDeployment] = useState<DeploymentRecord | null>(null);
  const [copied, setCopied] = useState(false);
  const [showQr, setShowQr] = useState(false);
  const [manifestTarget, setManifestTarget] = useState<'vercel' | 'netlify' | 'docker' | 'firebase'>('vercel');
  const [copiedManifest, setCopiedManifest] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const initialCfg = deploymentService.getConfig();
      const slug = currentSessionTitle.toLowerCase().replace(/[^a-z0-9]/g, '-') || 'app';
      const updated = {
        ...initialCfg,
        appName: currentSessionTitle,
        subdomainSlug: slug,
      };
      setConfig(updated);
      setDeployments(deploymentService.getDeployments());
    }
  }, [isOpen, currentSessionTitle]);

  const handleStartDeploy = async () => {
    setIsDeploying(true);
    setDeployProgress({ step: 'Initializing micro-app build...', percent: 10 });

    try {
      const record = await deploymentService.deployMicroApp(files, config, (step, percent) => {
        setDeployProgress({ step, percent });
      });

      setIsDeploying(false);
      setActiveDeployment(record);
      setDeployments(deploymentService.getDeployments());
    } catch (e) {
      setIsDeploying(false);
      console.error(e);
    }
  };

  const handleCopyUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCopyManifest = () => {
    const manifest = deploymentService.generateDeploymentManifests(manifestTarget);
    navigator.clipboard.writeText(manifest.content);
    setCopiedManifest(true);
    setTimeout(() => setCopiedManifest(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="bg-[#0b0d13] border border-white/10 rounded-2xl w-full max-w-2xl overflow-hidden shadow-[0_0_60px_rgba(0,0,0,0.8)] flex flex-col max-h-[92vh]"
        >
          {/* Header */}
          <div className="p-5 border-b border-white/10 bg-zinc-950/70 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500/20 to-emerald-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shadow-lg shadow-cyan-950/40">
                <Rocket size={22} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-white tracking-tight">1-Click Cloud Hosting & Edge Deployment</h3>
                  <span className="px-2 py-0.5 rounded-full text-[9px] font-mono font-bold bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
                    Edge CDN
                  </span>
                </div>
                <p className="text-xs text-zinc-400">
                  Instant public subdomains, client preview portals, and multi-cloud manifests
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-zinc-400 hover:text-white p-2 rounded-xl hover:bg-white/5 transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          <div className="p-6 space-y-6 overflow-y-auto flex-1">
            {/* Deploy Success Banner */}
            {activeDeployment && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 rounded-xl bg-gradient-to-r from-emerald-950/40 via-cyan-950/30 to-black border border-emerald-500/40 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs">
                    <CheckCircle2 size={16} />
                    <span>Micro-App Successfully Deployed!</span>
                  </div>
                  <div className="flex items-center gap-2 text-[10px] text-zinc-400">
                    <Activity size={12} className="text-emerald-400" />
                    <span>{activeDeployment.latencyMs}ms Edge Response</span>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex-1 px-3 py-2 rounded-lg bg-black/60 border border-emerald-500/30 font-mono text-xs text-white truncate">
                    {activeDeployment.url}
                  </div>
                  <button
                    onClick={() => handleCopyUrl(activeDeployment.url)}
                    className="px-3 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs font-semibold flex items-center gap-1.5"
                  >
                    {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                    {copied ? 'Copied' : 'Copy'}
                  </button>
                  <a
                    href={activeDeployment.blobUrl || activeDeployment.url}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-2 rounded-lg bg-emerald-500 text-black text-xs font-bold flex items-center gap-1 hover:bg-emerald-400"
                  >
                    Visit <ExternalLink size={13} />
                  </a>
                  <button
                    onClick={() => {
                      const htmlStr = deploymentService.generateStandaloneBundleHtml(files, config);
                      const b = new Blob([htmlStr], { type: 'text/html' });
                      const a = document.createElement('a');
                      a.href = URL.createObjectURL(b);
                      a.download = `${config.subdomainSlug || 'micro-app'}-bundle.html`;
                      a.click();
                    }}
                    className="px-3 py-2 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-xs font-bold flex items-center gap-1 hover:bg-cyan-500/30"
                    title="Download offline-ready micro-app HTML package"
                  >
                    <Download size={13} />
                    Download
                  </button>
                  <button
                    onClick={() => setShowQr(!showQr)}
                    className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-zinc-300"
                    title="View QR Code for mobile device preview"
                  >
                    <QrCode size={15} />
                  </button>
                </div>

                {showQr && (
                  <div className="p-3 bg-black/80 rounded-xl border border-white/10 flex items-center gap-4">
                    <div className="w-20 h-20 bg-white rounded-lg p-1.5 flex items-center justify-center">
                      {/* Stylized QR placeholder */}
                      <img
                        src={`https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${encodeURIComponent(
                          activeDeployment.url
                        )}`}
                        alt="QR Code"
                        className="w-full h-full"
                      />
                    </div>
                    <div className="text-xs text-zinc-400 space-y-1">
                      <div className="font-bold text-white">Scan with Mobile Phone</div>
                      <div>Test your responsive micro-app instantly on physical iOS & Android devices.</div>
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {/* Subdomain & URL Configuration */}
            <div className="space-y-3">
              <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
                <Globe size={13} className="text-cyan-400" />
                Edge Subdomain & URL Route
              </label>
              <div className="flex items-center gap-2">
                <div className="relative flex-1 flex items-center">
                  <input
                    type="text"
                    value={config.subdomainSlug}
                    onChange={(e) =>
                      setConfig({ ...config, subdomainSlug: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '-') })
                    }
                    placeholder="my-client-app"
                    className="w-full pl-3 pr-28 py-2 rounded-lg bg-black/60 border border-white/15 text-xs text-white font-mono placeholder:text-zinc-600 focus:outline-none focus:border-cyan-400"
                  />
                  <span className="absolute right-3 text-xs text-zinc-500 font-mono pointer-events-none">
                    .aether.app
                  </span>
                </div>
              </div>
            </div>

            {/* Target Cloud Engine */}
            <div className="space-y-3">
              <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
                <Server size={13} className="text-emerald-400" />
                Target Deployment Engine
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: 'aether-edge', label: 'Aether Edge', badge: 'Zero Config', fast: true },
                  { id: 'vercel', label: 'Vercel Edge', badge: 'Next/Vite' },
                  { id: 'netlify', label: 'Netlify', badge: 'SPA Deploy' },
                  { id: 'firebase', label: 'Firebase', badge: 'Google Cloud' },
                ].map((target) => {
                  const isSelected = config.target === target.id;
                  return (
                    <button
                      key={target.id}
                      onClick={() => setConfig({ ...config, target: target.id as any })}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        isSelected
                          ? 'bg-cyan-500/10 border-cyan-500/50 text-white shadow-lg shadow-cyan-950/30'
                          : 'bg-white/[0.02] border-white/10 text-zinc-400 hover:text-white hover:bg-white/[0.05]'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white">{target.label}</span>
                        {target.fast && <Sparkles size={11} className="text-emerald-400" />}
                      </div>
                      <span className="text-[10px] text-zinc-500 block mt-1">{target.badge}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Agency Client Presentation & Security */}
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Shield size={14} className="text-cyan-400" />
                  <span className="text-xs font-bold text-white">Agency Client Portal Settings</span>
                </div>
                <button
                  onClick={() => setConfig({ ...config, agencyMode: !config.agencyMode })}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold border transition-all ${
                    config.agencyMode
                      ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-300'
                      : 'bg-white/5 border-white/10 text-zinc-400'
                  }`}
                >
                  {config.agencyMode ? 'Agency Mode Enabled' : 'Solo Mode'}
                </button>
              </div>

              {config.agencyMode && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  <div>
                    <label className="text-[10px] text-zinc-400 uppercase tracking-wider font-bold block mb-1">
                      Agency Whitelabel Name
                    </label>
                    <input
                      type="text"
                      value={config.agencyName || ''}
                      onChange={(e) => setConfig({ ...config, agencyName: e.target.value })}
                      placeholder="e.g. Apex Digital Studio"
                      className="w-full px-3 py-1.5 rounded-lg bg-black/60 border border-white/15 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-zinc-400 uppercase tracking-wider font-bold block mb-1">
                      Client Review Password
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="password"
                        value={config.password || ''}
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            isPasswordProtected: !!e.target.value,
                            password: e.target.value,
                          })
                        }
                        placeholder="Optional client password"
                        className="w-full px-3 py-1.5 rounded-lg bg-black/60 border border-white/15 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-cyan-400 font-mono"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Deploy Trigger Button & Progress */}
            {isDeploying ? (
              <div className="p-4 rounded-xl bg-cyan-950/20 border border-cyan-500/30 space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-cyan-300">
                  <div className="flex items-center gap-2">
                    <RefreshCw size={13} className="animate-spin" />
                    <span>{deployProgress.step}</span>
                  </div>
                  <span>{deployProgress.percent}%</span>
                </div>
                <div className="w-full h-1.5 bg-black rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-cyan-400 to-emerald-400"
                    style={{ width: `${deployProgress.percent}%` }}
                    transition={{ duration: 0.3 }}
                  />
                </div>
              </div>
            ) : (
              <button
                onClick={handleStartDeploy}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-500 via-emerald-500 to-teal-400 text-black font-extrabold text-sm hover:opacity-90 transition-all flex items-center justify-center gap-2 shadow-xl shadow-cyan-950/50 active:scale-[0.99]"
              >
                <Rocket size={16} />
                <span>Deploy Micro-App to Global Edge (1-Click)</span>
              </button>
            )}

            {/* Manifest Exporter Tab */}
            <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-zinc-300">
                  <Layers size={13} className="text-cyan-400" />
                  <span>Export Cloud Manifests</span>
                </div>
                <div className="flex gap-1.5">
                  {(['vercel', 'netlify', 'docker', 'firebase'] as const).map((t) => (
                    <button
                      key={t}
                      onClick={() => setManifestTarget(t)}
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold uppercase ${
                        manifestTarget === t ? 'bg-cyan-500 text-black font-bold' : 'text-zinc-400 hover:text-white'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex items-center justify-between text-xs text-zinc-400">
                <span className="font-mono text-[11px] text-zinc-300">
                  {deploymentService.generateDeploymentManifests(manifestTarget).filename}
                </span>
                <button
                  onClick={handleCopyManifest}
                  className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1"
                >
                  {copiedManifest ? <Check size={12} /> : <Copy size={12} />}
                  {copiedManifest ? 'Copied' : 'Copy Config'}
                </button>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="p-4 bg-zinc-950/80 border-t border-white/10 flex items-center justify-between text-[11px] text-zinc-400">
            <div className="flex items-center gap-2">
              <Clock size={13} className="text-emerald-400" />
              <span>Global CDN Edge Propagation: &lt; 2.5s</span>
            </div>
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white font-semibold text-xs transition-colors"
            >
              Close
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
