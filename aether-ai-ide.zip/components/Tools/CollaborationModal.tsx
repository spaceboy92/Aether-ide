import React, { useState, useEffect } from 'react';
import { 
  X, 
  Users, 
  Link, 
  Check, 
  Copy, 
  Presentation, 
  MessageSquare, 
  ShieldCheck, 
  Sparkles, 
  Plus, 
  Trash2, 
  CheckCircle2, 
  Lock, 
  Eye, 
  Layers,
  Palette
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { multiplayerService, MultiplayerRoom, PeerUser, FeedbackPin } from '../../services/multiplayerService';

interface CollaborationModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentSessionTitle?: string;
  onLaunchPresentationMode?: () => void;
}

export const CollaborationModal: React.FC<CollaborationModalProps> = ({
  isOpen,
  onClose,
  currentSessionTitle = 'Client Micro-App',
  onLaunchPresentationMode,
}) => {
  const [room, setRoom] = useState<MultiplayerRoom>(multiplayerService.getRoom());
  const [copied, setCopied] = useState(false);
  const [newPeerName, setNewPeerName] = useState('');
  const [newPeerRole, setNewPeerRole] = useState<PeerUser['role']>('client_reviewer');
  const [showAddPeer, setShowAddPeer] = useState(false);
  const [newPinComment, setNewPinComment] = useState('');

  useEffect(() => {
    if (isOpen) {
      setRoom(multiplayerService.getRoom());
      const unsub = multiplayerService.subscribe((r) => setRoom({ ...r }));
      return () => unsub();
    }
  }, [isOpen]);

  const shareableUrl = `${window.location.origin}/?room=${room.roomId}&title=${encodeURIComponent(currentSessionTitle)}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareableUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleAddPeer = () => {
    if (!newPeerName.trim()) return;
    multiplayerService.addPeer(newPeerName.trim(), newPeerRole);
    setNewPeerName('');
    setShowAddPeer(false);
    setRoom({ ...multiplayerService.getRoom() });
  };

  const handleAddQuickPin = () => {
    if (!newPinComment.trim()) return;
    multiplayerService.addFeedbackPin({
      authorName: 'Client Reviewer',
      authorRole: 'client_reviewer',
      xPercent: 50,
      yPercent: 30,
      comment: newPinComment.trim(),
      deviceViewport: 'desktop',
    });
    setNewPinComment('');
    setRoom({ ...multiplayerService.getRoom() });
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          className="bg-[#0b0d13] border border-white/10 rounded-2xl w-full max-w-2xl overflow-hidden shadow-[0_0_60px_rgba(0,0,0,0.8)] flex flex-col max-h-[92vh]"
        >
          {/* Header */}
          <div className="p-5 border-b border-white/10 bg-zinc-950/70 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400 shadow-lg shadow-purple-950/40">
                <Users size={22} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-white tracking-tight">Real-Time Multiplayer & Client Pairing</h3>
                  <span className="px-2 py-0.5 rounded-full text-[9px] font-mono font-bold bg-purple-500/10 border border-purple-500/20 text-purple-400">
                    Live Sync
                  </span>
                </div>
                <p className="text-xs text-zinc-400">
                  Collaborative code pairing, interactive client feedback pins, and whitelabel presentation mode
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-zinc-400 hover:text-white p-2 rounded-xl hover:bg-white/5 transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          <div className="p-6 space-y-6 overflow-y-auto flex-1">
            {/* 1. Live Room Share Box */}
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Link size={13} className="text-purple-400" />
                  Live Room Link & Token
                </label>
                <span className="text-[10px] font-mono text-zinc-500">
                  ID: <span className="text-white font-bold">{room.roomId}</span>
                </span>
              </div>

              <div className="flex gap-2">
                <div className="flex-1 bg-black/60 border border-white/15 rounded-lg px-3 py-2 text-xs text-zinc-300 font-mono truncate">
                  {shareableUrl}
                </div>
                <button
                  onClick={handleCopyLink}
                  className="px-4 py-2 rounded-lg bg-purple-500 text-black font-bold text-xs hover:bg-purple-400 transition-all flex items-center gap-1.5 shrink-0"
                >
                  {copied ? <Check size={14} /> : <Copy size={14} />}
                  {copied ? 'Copied' : 'Copy Link'}
                </button>
              </div>
            </div>

            {/* 2. Agency Client Presentation Mode Banner */}
            <div className="p-4 rounded-xl bg-gradient-to-r from-purple-950/30 via-indigo-950/20 to-black border border-purple-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Presentation size={16} className="text-purple-400" />
                  <span className="text-sm font-bold text-white">Agency Whitelabel Showcase</span>
                </div>
                <p className="text-xs text-zinc-400">
                  Clean full-screen presentation view for clients without code distractions, with sticky feedback tools
                </p>
              </div>
              <button
                onClick={() => {
                  multiplayerService.togglePresentationMode(true);
                  if (onLaunchPresentationMode) onLaunchPresentationMode();
                  onClose();
                }}
                className="px-4 py-2 rounded-xl bg-white text-black font-bold text-xs hover:bg-zinc-200 transition-all flex items-center gap-1.5 shrink-0 shadow-lg shadow-white/10"
              >
                <Eye size={14} />
                Launch Presentation View
              </button>
            </div>

            {/* 3. Active Collaborators & Peers */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Users size={13} className="text-cyan-400" />
                  Connected Peers ({room.peers.length})
                </label>
                <button
                  onClick={() => setShowAddPeer(!showAddPeer)}
                  className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1"
                >
                  <Plus size={13} />
                  Simulate Client/Pair
                </button>
              </div>

              {showAddPeer && (
                <div className="p-3 rounded-xl bg-cyan-950/20 border border-cyan-500/30 space-y-2">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={newPeerName}
                      onChange={(e) => setNewPeerName(e.target.value)}
                      placeholder="Stakeholder / Engineer Name..."
                      className="flex-1 px-3 py-1.5 rounded-lg bg-black/60 border border-white/15 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-cyan-400"
                    />
                    <select
                      value={newPeerRole}
                      onChange={(e) => setNewPeerRole(e.target.value as any)}
                      className="px-2 py-1.5 rounded-lg bg-black/60 border border-white/15 text-xs text-white focus:outline-none"
                    >
                      <option value="client_reviewer">Client Reviewer</option>
                      <option value="editor">Editor (Pair)</option>
                      <option value="spectator">Spectator</option>
                    </select>
                    <button
                      onClick={handleAddPeer}
                      className="px-3 py-1.5 rounded-lg bg-cyan-500 text-black font-bold text-xs"
                    >
                      Add
                    </button>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {room.peers.map((peer) => (
                  <div
                    key={peer.id}
                    className="p-3 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <div className="relative">
                        <img
                          src={peer.avatarUrl}
                          alt={peer.name}
                          className="w-8 h-8 rounded-lg object-cover border border-white/20"
                        />
                        <div
                          className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-black"
                          style={{ backgroundColor: peer.color }}
                        />
                      </div>
                      <div>
                        <div className="text-xs font-semibold text-white truncate max-w-[140px]">{peer.name}</div>
                        <div className="text-[10px] text-zinc-400 capitalize">
                          {peer.role.replace('_', ' ')}
                        </div>
                      </div>
                    </div>

                    {peer.role !== 'host' && (
                      <button
                        onClick={() => {
                          multiplayerService.removePeer(peer.id);
                          setRoom({ ...multiplayerService.getRoom() });
                        }}
                        className="text-zinc-500 hover:text-red-400 p-1.5 rounded"
                      >
                        <Trash2 size={13} />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* 4. Client Feedback Pin Manager */}
            <div className="p-4 rounded-xl bg-white/[0.02] border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-bold text-zinc-300">
                  <MessageSquare size={14} className="text-emerald-400" />
                  <span>Client Feedback Pins & Annotations ({room.feedbackPins.length})</span>
                </div>
              </div>

              <div className="flex gap-2">
                <input
                  type="text"
                  value={newPinComment}
                  onChange={(e) => setNewPinComment(e.target.value)}
                  placeholder="Drop a new client feedback note..."
                  className="flex-1 px-3 py-1.5 rounded-lg bg-black/60 border border-white/15 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:border-emerald-400"
                />
                <button
                  onClick={handleAddQuickPin}
                  disabled={!newPinComment.trim()}
                  className="px-3 py-1.5 rounded-lg bg-emerald-500 text-black font-bold text-xs hover:bg-emerald-400 transition-all disabled:opacity-50"
                >
                  Pin Note
                </button>
              </div>

              <div className="space-y-2 pt-1">
                {room.feedbackPins.map((pin) => (
                  <div
                    key={pin.id}
                    className={`p-2.5 rounded-lg border flex items-center justify-between text-xs transition-all ${
                      pin.resolved
                        ? 'bg-white/[0.01] border-white/5 opacity-60 text-zinc-500'
                        : 'bg-emerald-500/[0.04] border-emerald-500/30 text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate max-w-[380px]">
                      <button
                        onClick={() => {
                          multiplayerService.toggleResolvePin(pin.id);
                          setRoom({ ...multiplayerService.getRoom() });
                        }}
                        className={`w-4 h-4 rounded flex items-center justify-center border shrink-0 ${
                          pin.resolved
                            ? 'bg-emerald-500 border-emerald-500 text-black'
                            : 'border-zinc-500 hover:border-emerald-400'
                        }`}
                      >
                        {pin.resolved && <Check size={11} strokeWidth={3} />}
                      </button>
                      <span className={pin.resolved ? 'line-through text-zinc-500' : 'text-zinc-200'}>
                        {pin.comment}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 text-[10px] text-zinc-500 shrink-0">
                      <span>{pin.authorName}</span>
                      <button
                        onClick={() => {
                          multiplayerService.deletePin(pin.id);
                          setRoom({ ...multiplayerService.getRoom() });
                        }}
                        className="text-zinc-500 hover:text-red-400"
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="p-4 bg-zinc-950/80 border-t border-white/10 flex items-center justify-between text-[11px] text-zinc-400">
            <div className="flex items-center gap-1.5">
              <ShieldCheck size={13} className="text-emerald-400" />
              <span>Zero-Latency WebRTC & Secure Client Review Channels</span>
            </div>
            <button
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white font-semibold text-xs transition-colors"
            >
              Done
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
