import React, { useState, useEffect } from "react";
import { detectProviderFromEndpoint } from "../../services/aiService";
import {
  Cpu,
  RefreshCw,
  CheckCircle2,
  XCircle,
  Server,
  Zap,
  Globe,
  Bot,
  Settings,
  X,
  Play,
  Terminal,
  ShieldCheck,
  Check
} from "lucide-react";

interface OllamaModel {
  name: string;
  size: number;
  digest?: string;
  modified_at?: string;
  model?: string;
}

interface OllamaIntegrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectLocalModel?: (modelName: string, endpoint: string) => void;
  activeModel?: string;
}

export const OllamaIntegrationModal: React.FC<OllamaIntegrationModalProps> = ({
  isOpen,
  onClose,
  onSelectLocalModel,
  activeModel
}) => {
  const [endpoint, setEndpoint] = useState("https://openrouter.ai/api/v1");
  const [isConnected, setIsConnected] = useState<boolean | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [models, setModels] = useState<OllamaModel[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [testPrompt, setTestPrompt] = useState("Explain how Aether AI works in one sentence.");
  const [testResponse, setTestResponse] = useState<string | null>(null);
  const [isTesting, setIsTesting] = useState(false);

  // Auto-scan on load or endpoint change
  const scanCloudProvider = async (customEndpoint?: string) => {
    const targetUrl = customEndpoint || endpoint;
    const apiKey = localStorage.getItem('ollama_api_key') || '';
    setIsScanning(true);
    setErrorMessage(null);
    setIsConnected(null);

    try {
      const res = await fetch("/api/ollama/models", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ endpoint: targetUrl, apiKey })
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || "Failed to reach Ollama endpoint");
      }

      const fetchedModels = data.models || [];
      setModels(fetchedModels);
      setIsConnected(true);

      // Auto-sync discovered models to aether registry
      if (fetchedModels.length > 0) {
        try {
          let customList: any[] = [];
          
          fetchedModels.forEach((m: OllamaModel) => {
            const rawName = m.name || m.model;
            if (!rawName) return;
            const cleanName = rawName.replace(/^ollama_/i, '');
            const providerInfo = detectProviderFromEndpoint(targetUrl, cleanName);

            if (!customList.some((c: any) => c.id === cleanName)) {
              customList.push({
                id: cleanName,
                name: `${cleanName} (${providerInfo.providerName})`,
                description: `${providerInfo.providerName} Model${m.size ? ' (' + (m.size / (1024*1024*1024)).toFixed(2) + ' GB)' : ''}`,
                type: providerInfo.type,
                tier: 'free',
                isCustom: true
              });
            }
          });
          
          localStorage.setItem('aether_custom_ai_models', JSON.stringify(customList));
          window.dispatchEvent(new Event('aether_custom_models_updated'));
        } catch (e) {}
      }
    } catch (err: any) {
      setIsConnected(false);
      setErrorMessage(
        err.message ||
          "Could not connect to Ollama. Make sure Ollama is running (`ollama serve`) and CORS is allowed (`OLLAMA_ORIGINS=\"*\"`)."
      );
    } finally {
      setIsScanning(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      scanCloudProvider();
    }
  }, [isOpen]);

  // Test prompt execution
  const handleTestLocalModel = async (modelName: string) => {
    setIsTesting(true);
    setTestResponse(null);
    const apiKey = localStorage.getItem('ollama_api_key') || '';

    try {
      const res = await fetch("/api/ollama/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          endpoint,
          model: modelName,
          prompt: testPrompt,
          apiKey
        })
      });

      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || "Ollama chat error");
      }

      setTestResponse(data.text || "No response received.");
    } catch (err: any) {
      setTestResponse(`Error: ${err.message}`);
    } finally {
      setIsTesting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 select-none">
      <div className="w-full max-w-2xl bg-zinc-950 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col font-sans">
        {/* Header */}
        <div className="h-14 bg-zinc-900/80 border-b border-zinc-800 px-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-orange-500/10 border border-orange-500/20 text-orange-400 flex items-center justify-center">
              <Cpu size={18} />
            </div>
            <div>
              <h3 className="text-sm font-black text-white uppercase tracking-wider">
                Local Ollama / Custom LLM Integrator
              </h3>
              <p className="text-[10px] text-zinc-400 font-mono">
                Connect your local machine's Ollama models to Aether AI Agent
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-lg transition-all cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6 overflow-y-auto max-h-[80vh] custom-scrollbar">
          {/* Endpoint Input */}
          <div className="space-y-2">
            <div className="flex items-end justify-between">
              <label className="text-[10px] font-black uppercase tracking-wider text-zinc-400 flex items-center justify-between">
                <span>AI Provider Endpoint URL</span>
              </label>
              <select 
                className="bg-black text-[10px] text-zinc-300 border border-zinc-800 rounded px-1.5 py-0.5 cursor-pointer focus:outline-none focus:border-orange-500 outline-none"
                onChange={e => {
                  if (e.target.value && e.target.value !== 'custom') {
                    setEndpoint(e.target.value);
                  } else if (e.target.value === 'custom') {
                    setEndpoint('');
                  }
                }}
                value={
                  ['https://api.openai.com/v1', 'https://api.groq.com/openai/v1', 'https://openrouter.ai/api/v1', 'https://api.together.xyz/v1', 'https://api.deepseek.com/v1'].includes(endpoint) ? endpoint : 'custom'
                }
              >
                <option value="custom">Custom / Other</option>
                <option value="https://openrouter.ai/api/v1">OpenRouter</option>
                <option value="https://api.groq.com/openai/v1">Groq</option>
                <option value="https://api.openai.com/v1">OpenAI</option>
                <option value="https://api.together.xyz/v1">Together AI</option>
                <option value="https://api.deepseek.com/v1">DeepSeek</option>
                
              </select>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={endpoint}
                onChange={(e) => setEndpoint(e.target.value)}
                className="flex-1 bg-black/60 border border-zinc-800 rounded-xl px-3.5 py-2 text-xs font-mono text-zinc-200 focus:outline-none focus:border-orange-500"
                placeholder="e.g. https://openrouter.ai/api/v1"
              />
              <button
                onClick={() => scanCloudProvider()}
                disabled={isScanning}
                className="px-4 py-2 bg-orange-500 hover:bg-orange-400 disabled:opacity-50 text-black text-xs font-black uppercase tracking-wider rounded-xl transition-all flex items-center gap-2 cursor-pointer shrink-0"
              >
                <RefreshCw size={14} className={isScanning ? "animate-spin" : ""} />
                {isScanning ? "Scanning..." : "Detect Models"}
              </button>
            </div>
          </div>

          {/* Connection Status Banner */}
          {isConnected === true && (
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-xl text-xs flex items-center justify-between">
              <div className="flex items-center gap-2 font-bold">
                <CheckCircle2 size={16} /> Provider Connected! ({models.length} Models Found)
              </div>
              <span className="text-[10px] font-mono bg-emerald-500/20 px-2 py-0.5 rounded">
                Server Ready
              </span>
            </div>
          )}

          {isConnected === false && (
            <div className="p-4 bg-red-500/10 border border-red-500/30 text-red-400 rounded-xl text-xs space-y-2 font-mono">
              <div className="flex items-center gap-2 font-bold">
                <XCircle size={16} /> Ollama Connection Failed
              </div>
              <p className="text-[11px] leading-relaxed text-red-300/80">{errorMessage}</p>
              <div className="p-2 bg-black/40 rounded-lg text-[10px] text-zinc-400 space-y-1">
                <p className="font-bold text-zinc-300">Quick Setup Instructions:</p>
                <p>1. Open terminal on your host machine and run: <code className="text-orange-400">OLLAMA_ORIGINS="*" ollama serve</code></p>
                <p>2. Verify model is installed: <code className="text-orange-400">ollama run llama3</code> or <code className="text-orange-400">ollama run mistral</code></p>
              </div>
            </div>
          )}

          {/* Detected Models List */}
          {models.length > 0 && (
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-wider text-zinc-400">
                Available Local Ollama Models
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {models.map((m) => {
                  const sizeGb = (m.size / (1024 * 1024 * 1024)).toFixed(2);
                  const isSelected = activeModel === m.name;

                  return (
                    <div
                      key={m.name}
                      className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                        isSelected
                          ? "bg-orange-500/15 border-orange-500/50 text-orange-400"
                          : "bg-zinc-900/60 border-zinc-800 hover:border-zinc-700 text-zinc-300"
                      }`}
                    >
                      <div className="truncate">
                        <div className="font-bold font-mono text-xs truncate">{m.name}</div>
                        <div className="text-[9px] text-zinc-500 font-mono">{sizeGb} GB</div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => handleTestLocalModel(m.name)}
                          disabled={isTesting}
                          className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[10px] font-mono rounded cursor-pointer"
                          title="Test connection"
                        >
                          Test
                        </button>
                        <button
                          onClick={() => {
                            if (onSelectLocalModel) onSelectLocalModel(m.name, endpoint);
                          }}
                          className={`px-3 py-1 rounded text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                            isSelected
                              ? "bg-orange-500 text-black font-bold"
                              : "bg-orange-500/20 text-orange-400 hover:bg-orange-500/30"
                          }`}
                        >
                          {isSelected ? "Active" : "Use Model"}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Test Prompt Output */}
          {testResponse && (
            <div className="p-3 bg-black/60 border border-zinc-800 rounded-xl space-y-1">
              <span className="text-[9px] font-black uppercase tracking-wider text-orange-400 block">
                Local Ollama Test Output
              </span>
              <p className="text-xs font-mono text-zinc-300 whitespace-pre-wrap">{testResponse}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
