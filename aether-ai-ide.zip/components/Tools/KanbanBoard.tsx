
import React, { useState } from 'react';
import { Plus, X, Layout, Bot, RefreshCw } from 'lucide-react';
import { motion } from 'motion/react';
import { getTaskLists, getTasks, createTask, deleteTask as deleteGoogleTask, updateTask } from '../../services/workspaceService';

interface Task {
    id: string;
    content: string;
    column: 'todo' | 'progress' | 'done';
    priority?: 'low' | 'medium' | 'high';
}

interface KanbanBoardProps {
    onExecuteTask?: (taskContent: string) => void;
}

const KanbanBoard: React.FC<KanbanBoardProps> = ({ onExecuteTask }) => {
    const [tasks, setTasks] = useState<Task[]>([
        { id: '1', content: 'Initialize Project Repository', column: 'done', priority: 'high' },
        { id: '2', content: 'Design System Architecture', column: 'progress', priority: 'high' },
        { id: '3', content: 'Implement Authentication', column: 'todo', priority: 'medium' },
        { id: '4', content: 'Fix CSS Grid Issues', column: 'todo', priority: 'low' },
    ]);

    const moveTask = (id: string, targetCol: Task['column']) => {
        setTasks(tasks.map(t => t.id === id ? { ...t, column: targetCol } : t));
    };

    const changePriority = (id: string, prio: 'low' | 'medium' | 'high') => {
        setTasks(tasks.map(t => t.id === id ? { ...t, priority: prio } : t));
    };

    const addTask = (col: Task['column']) => {
        const text = prompt("Enter task details:");
        if (text) {
            setTasks([...tasks, { id: Date.now().toString(), content: text, column: col }]);
        }
    };

    const deleteTask = (id: string) => {
        setTasks(tasks.filter(t => t.id !== id));
    };

    const exportTasks = () => {
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(tasks, null, 2));
        const downloadAnchorNode = document.createElement('a');
        downloadAnchorNode.setAttribute("href", dataStr);
        downloadAnchorNode.setAttribute("download", "kanban_tasks.json");
        document.body.appendChild(downloadAnchorNode);
        downloadAnchorNode.click();
        downloadAnchorNode.remove();
    };

    const clearBoard = () => {
        if(confirm('Are you sure you want to clear all tasks?')) {
            setTasks([]);
        }
    };

    const [isSyncing, setIsSyncing] = useState(false);
    const syncTasks = async () => {
        setIsSyncing(true);
        try {
            const lists = await getTaskLists();
            if (!lists.items || lists.items.length === 0) return;
            const tasksListId = lists.items[0].id;
            const remoteTasks = await getTasks(tasksListId);
            
            if (remoteTasks.items) {
                const mapped: Task[] = remoteTasks.items.map((t: any) => ({
                    id: t.id,
                    content: t.title,
                    column: t.status === 'needsAction' ? 'todo' : 'done',
                    priority: 'medium'
                }));
                // Combine with existing non-conflicting tasks
                const existingMap = new Map(tasks.map(t => [t.id, t]));
                mapped.forEach(t => existingMap.set(t.id, t));
                setTasks(Array.from(existingMap.values()));
            }
        } catch (error) {
            console.error("Failed to sync tasks:", error);
            alert("Failed to sync tasks. Ensure you are signed in.");
        } finally {
            setIsSyncing(false);
        }
    };

    const renderColumn = (id: Task['column'], title: string, colorClass: string, borderColor: string) => (
        <div className="w-[85vw] sm:w-[320px] shrink-0 min-w-[280px] flex flex-col bg-aether-panel border border-aether-border rounded-xl overflow-hidden h-full snap-center relative">
            <div className={`p-4 border-b border-white/5 flex justify-between items-center ${colorClass}`}>
                <h3 className="text-[11px] sm:text-xs font-bold uppercase tracking-widest text-white">{title}</h3>
                <span className="text-[10px] bg-black/40 px-2 py-0.5 rounded-full text-white/90 font-mono">{tasks.filter(t => t.column === id).length}</span>
            </div>
            <div className="flex-1 p-3 sm:p-4 space-y-3 overflow-y-auto custom-scrollbar bg-black/20">
                {tasks.filter(t => t.column === id).map((task, index) => (
                    <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.05 }}
                        whileHover={{ scale: 1.02 }}
                        key={task.id} 
                        className={`bg-[#0a0a0a] border border-white/5 p-4 rounded-lg group hover:border-aether-accent/40 transition-all shadow-sm relative overflow-hidden flex flex-col cursor-grab active:cursor-grabbing`}
                    >
                        <div className={`absolute left-0 top-0 bottom-0 w-1 ${borderColor}`}></div>
                        <div className="flex justify-between items-start gap-3 mb-4">
                            <p className="text-sm text-aether-text leading-relaxed font-medium flex-1 break-words max-h-32 overflow-y-auto custom-scrollbar pr-1">{task.content}</p>
                            <button onClick={() => deleteTask(task.id)} className="opacity-40 hover:opacity-100 text-aether-muted hover:text-red-400 transition-opacity p-1 -mr-2 -mt-1"><X size={14} /></button>
                        </div>
                        <div className="flex justify-between items-end mt-auto">
                            <div className="flex flex-col gap-2">
                                <select 
                                    value={task.priority || 'medium'}
                                    onChange={(e) => changePriority(task.id, e.target.value as 'low'|'medium'|'high')}
                                    className={`text-[9px] uppercase font-bold tracking-widest px-1.5 py-0.5 rounded outline-none border-none bg-black/40 cursor-pointer ${
                                        task.priority === 'high' ? 'text-red-400' : 
                                        task.priority === 'low' ? 'text-blue-400' : 'text-yellow-400'
                                    }`}
                                >
                                    <option value="low">Low Priority</option>
                                    <option value="medium">Medium Prio</option>
                                    <option value="high">High Priority</option>
                                </select>
                                <button 
                                    onClick={() => onExecuteTask?.(task.content)}
                                    className="flex items-center gap-1 text-[10px] uppercase font-bold tracking-widest text-aether-accent opacity-70 hover:opacity-100 hover:scale-105 transition-all bg-aether-accent/10 px-2.5 py-1.5 rounded-md w-fit"
                                >
                                    <Bot size={12} /> Assign AI
                                </button>
                            </div>
                            <div className="flex flex-col gap-1.5 items-end justify-end md:opacity-40 group-hover:opacity-100 transition-opacity">
                                {id !== 'todo' && <button onClick={() => moveTask(task.id, 'todo')} className="text-[9px] px-2 py-1.5 bg-white/5 hover:bg-white/10 rounded uppercase font-bold text-aether-muted hover:text-white transition-colors">Todo</button>}
                                {id !== 'progress' && <button onClick={() => moveTask(task.id, 'progress')} className="text-[9px] px-2 py-1.5 bg-white/5 hover:bg-white/10 rounded uppercase font-bold text-aether-muted hover:text-white transition-colors">Doing</button>}
                                {id !== 'done' && <button onClick={() => moveTask(task.id, 'done')} className="text-[9px] px-2 py-1.5 bg-white/5 hover:bg-white/10 rounded uppercase font-bold text-aether-muted hover:text-white transition-colors">Done</button>}
                            </div>
                        </div>
                    </motion.div>
                ))}
                <button onClick={() => addTask(id)} className="w-full py-3.5 border border-dashed border-white/10 rounded-lg text-xs text-aether-muted hover:text-white hover:border-aether-accent/50 hover:bg-aether-accent/5 transition-all flex items-center justify-center gap-2 font-medium">
                    <Plus size={14} /> Create Task
                </button>
            </div>
        </div>
    );

    return (
        <div className="flex-1 flex flex-col bg-[#050505] overflow-hidden">
             <div className="h-12 border-b border-aether-border flex items-center px-4 sm:px-6 gap-3 bg-black/40 shrink-0">
                <Layout size={16} className="text-aether-accent" />
                <span className="text-[10px] sm:text-xs font-bold text-white uppercase tracking-widest">Project Kanban Board</span>
                <div className="flex-1"></div>
                <button onClick={syncTasks} disabled={isSyncing} className={`text-[10px] uppercase font-bold tracking-widest text-[#00ffd4] hover:text-[#00ffd4]/80 transition-colors bg-[#00ffd4]/5 hover:bg-[#00ffd4]/10 px-2 flex items-center gap-1 py-1 rounded ${isSyncing ? 'opacity-50' : ''}`}><RefreshCw size={10} className={isSyncing ? "animate-spin" : ""} /> Sync</button>
                <button onClick={exportTasks} className="text-[10px] uppercase font-bold tracking-widest text-white/50 hover:text-white transition-colors bg-white/5 hover:bg-white/10 px-2 py-1 rounded">Export</button>
                <button onClick={clearBoard} className="text-[10px] uppercase font-bold tracking-widest text-red-500/50 hover:text-red-400 transition-colors bg-red-500/10 hover:bg-red-500/20 px-2 py-1 rounded">Clear</button>
             </div>
             <div className="flex-1 flex w-full overflow-x-auto overflow-y-hidden p-4 sm:p-6 gap-4 sm:gap-6 snap-x snap-mandatory overscroll-x-contain touch-pan-x">
                {renderColumn('todo', 'Backlog', 'bg-red-900/10', 'bg-red-500')}
                {renderColumn('progress', 'In Progress', 'bg-blue-900/10', 'bg-blue-500')}
                {renderColumn('done', 'Completed', 'bg-green-900/10', 'bg-green-500')}
             </div>
        </div>
    );
};

export default KanbanBoard;
