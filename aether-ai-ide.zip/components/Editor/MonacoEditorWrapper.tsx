
import React, { useRef, useEffect, useState } from 'react';
import Editor, { DiffEditor, OnMount, loader } from '@monaco-editor/react';
import { Zap, Bug, Sparkles, GitCompare, Check, X, Wand2, Scissors } from 'lucide-react';
import { aiCompletionEngine } from '../../services/aiCompletionEngine';
import { workspaceLSP } from '../../services/workspaceLSP';
import { BUILTIN_EXTENSIONS } from '../../services/extensionSystem';
import { InlineAICodeGenerator } from './InlineAICodeGenerator';

// Configure monaco-editor loader to use cdnjs and setup MonacoEnvironment for cross-origin worker safety
loader.config({
  paths: {
    vs: 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/vs'
  }
});

if (typeof window !== 'undefined') {
  const monacoBase = 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min';
  (window as any).MonacoEnvironment = (window as any).MonacoEnvironment || {
    getWorkerUrl: function (_workerId: string, label: string) {
      let workerScript = `${monacoBase}/vs/base/worker/workerMain.js`;
      if (label === 'json') workerScript = `${monacoBase}/vs/language/json/json.worker.js`;
      if (label === 'css' || label === 'scss' || label === 'less') workerScript = `${monacoBase}/vs/language/css/css.worker.js`;
      if (label === 'html' || label === 'handlebars' || label === 'razor') workerScript = `${monacoBase}/vs/language/html/html.worker.js`;
      if (label === 'typescript' || label === 'javascript') workerScript = `${monacoBase}/vs/language/typescript/ts.worker.js`;

      const blobContent = `
        self.MonacoEnvironment = { baseUrl: '${monacoBase}/' };
        try {
          importScripts('${workerScript}');
        } catch (e) {
          // Gracefully fallback to main thread parsing if cross-origin importScripts is restricted in sandbox
        }
      `;
      return `data:text/javascript;charset=utf-8,${encodeURIComponent(blobContent)}`;
    }
  };
}

interface MonacoEditorProps {
  code: string;
  originalCode?: string;
  diffMode?: boolean;
  onAcceptDiff?: () => void;
  onRejectDiff?: () => void;
  language: string;
  filePath?: string;
  onChange: (value: string | undefined) => void;
  onSave?: (value: string) => void;
  readOnly?: boolean;
  isAIWriting?: boolean;
  onMount?: OnMount;
  fontFamily?: string;
  fontSize?: number;
  lineHeight?: number;
  minimapEnabled?: boolean;
  vimMode?: boolean;
  ligatures?: boolean;
  breakpoints?: number[];
  onToggleBreakpoint?: (lineNumber: number) => void;
}

const MonacoEditorWrapper: React.FC<MonacoEditorProps> = ({ 
  code, 
  originalCode,
  diffMode = false,
  onAcceptDiff,
  onRejectDiff,
  language, 
  filePath = 'active.ts',
  onChange, 
  onSave,
  readOnly = false, 
  isAIWriting = false,
  onMount,
  fontFamily,
  fontSize = 14,
  lineHeight,
  minimapEnabled,
  vimMode,
  ligatures,
  breakpoints = [],
  onToggleBreakpoint
}) => {
  const editorRef = useRef<any>(null);
  const monacoRef = useRef<any>(null);
  const [showInlineAI, setShowInlineAI] = useState(false);
  const [selectedSnippet, setSelectedSnippet] = useState<string>("");

  useEffect(() => {
    // Index active file into Workspace LSP Engine
    workspaceLSP.indexFile(filePath, code);
  }, [code, filePath]);

  useEffect(() => {
    const handleCustomTrigger = () => {
      handleOpenInlineAI();
    };
    window.addEventListener('aether:open-surgical-ai', handleCustomTrigger);
    return () => {
      window.removeEventListener('aether:open-surgical-ai', handleCustomTrigger);
    };
  }, [filePath, code]);

  const handleOpenInlineAI = () => {
    if (editorRef.current) {
      const selection = editorRef.current.getSelection();
      const model = editorRef.current.getModel();
      if (selection && model && !selection.isEmpty()) {
        const text = model.getValueInRange(selection);
        setSelectedSnippet(text);
      } else {
        setSelectedSnippet("");
      }
    }
    setShowInlineAI(true);
  };

  const handleApplyInlineCode = (newCode: string, mode: 'replace' | 'insert' | 'diff') => {
    if (!editorRef.current) {
      onChange(newCode);
      setShowInlineAI(false);
      return;
    }

    if (mode === 'diff' && onAcceptDiff) {
      // Trigger diff view
      onChange(newCode);
      setShowInlineAI(false);
      return;
    }

    const selection = editorRef.current.getSelection();
    if (selectedSnippet && selection && !selection.isEmpty()) {
      editorRef.current.executeEdits('inline-ai', [{
        range: selection,
        text: newCode,
        forceMoveMarkers: true
      }]);
    } else {
      onChange(newCode);
    }

    setShowInlineAI(false);
  };

  const handleEditorDidMount: OnMount = (editor, monaco) => {
    editorRef.current = editor;
    monacoRef.current = monaco;

    try {
      // Define custom Themes (Aether, Dracula, Tokyo Night, One Dark Pro)
      monaco.editor.defineTheme('aether-dark', {
        base: 'vs-dark',
        inherit: true,
        rules: [
          { token: 'comment', foreground: '6272a4' },
          { token: 'keyword', foreground: 'ff79c6' },
          { token: 'string', foreground: 'f1fa8c' },
          { token: 'number', foreground: 'bd93f9' },
          { token: 'type', foreground: '8be9fd' },
        ],
        colors: {
          'editor.background': '#0f1115',
          'editor.foreground': '#e2e8f0',
          'editorCursor.foreground': '#00d4ff',
          'editor.lineHighlightBackground': '#161b22',
          'editorLineNumber.foreground': '#4b5563',
          'editor.selectionBackground': '#2a2f3a',
          'editorIndentGuide.background': '#2a2f3a',
          'editorIndentGuide.activeBackground': '#00d4ff'
        }
      });

      BUILTIN_EXTENSIONS.filter(e => e.category === 'theme' && e.themeConfig).forEach(t => {
        monaco.editor.defineTheme(t.id, {
          base: t.themeConfig!.base,
          inherit: true,
          rules: [],
          colors: t.themeConfig!.colors
        });
      });

      monaco.editor.setTheme('aether-dark');

      // 1. Register AI Fast Inline Completion Provider (Sub-100ms)
      if (!(window as any).__aether_ai_completion_registered && monaco.languages) {
        (window as any).__aether_ai_completion_registered = true;

        const languagesToRegister = ['typescript', 'javascript', 'python', 'rust', 'cpp', 'html', 'css'];
        languagesToRegister.forEach(lang => {
          monaco.languages.registerInlineCompletionsProvider(lang, {
            provideInlineCompletions: async (model: any, position: any) => {
              const textBefore = model.getValueInRange({
                startLineNumber: 1,
                startColumn: 1,
                endLineNumber: position.lineNumber,
                endColumn: position.column
              });

              const textAfter = model.getValueInRange({
                startLineNumber: position.lineNumber,
                startColumn: position.column,
                endLineNumber: model.getLineCount(),
                endColumn: model.getLineMaxColumn(model.getLineCount())
              });

              const completionText = await aiCompletionEngine.getAICompletion(
                textBefore,
                textAfter,
                lang,
                filePath
              );

              if (!completionText) return { items: [] };

              return {
                items: [
                  {
                    insertText: completionText,
                    range: {
                      startLineNumber: position.lineNumber,
                      startColumn: position.column,
                      endLineNumber: position.lineNumber,
                      endColumn: position.column
                    }
                  }
                ]
              };
            },
            freeInlineCompletions: () => {}
          });
        });
      }

      // 2. Register Workspace LSP (Go To Definition & Hover Docs across workspace)
      if (!(window as any).__aether_lsp_registered && monaco.languages) {
        (window as any).__aether_lsp_registered = true;

        ['typescript', 'javascript', 'python', 'rust'].forEach(lang => {
          monaco.languages.registerDefinitionProvider(lang, {
            provideDefinition: (model: any, position: any) => {
              const word = model.getWordAtPosition(position);
              if (!word) return null;

              const symbol = workspaceLSP.findDefinition(word.word);
              if (!symbol) return null;

              return {
                uri: monaco.Uri.parse(`file:///${symbol.filePath}`),
                range: new monaco.Range(
                  symbol.lineNumber,
                  symbol.column,
                  symbol.lineNumber,
                  symbol.column + symbol.name.length
                )
              };
            }
          });

          monaco.languages.registerHoverProvider(lang, {
            provideHover: (model: any, position: any) => {
              const word = model.getWordAtPosition(position);
              if (!word) return null;

              const symbol = workspaceLSP.findDefinition(word.word);
              if (!symbol) return null;

              return {
                range: new monaco.Range(
                  position.lineNumber,
                  word.startColumn,
                  position.lineNumber,
                  word.endColumn
                ),
                contents: [
                  { value: `**Workspace Symbol**: \`${symbol.name}\`` },
                  { value: `\`\`\`${lang}\n${symbol.signature || symbol.name}\n\`\`\`` },
                  { value: symbol.documentation || `Defined in \`${symbol.filePath}\` at line ${symbol.lineNumber}` }
                ]
              };
            }
          });
        });
      }

      // 3. Breakpoint Gutter Margin Handler (DAP Debugger)
      editor.onMouseDown((e: any) => {
        if (e.target.type === monaco.editor.MouseTargetType.GUTTER_GLYPH_MARGIN) {
          const line = e.target.position.lineNumber;
          if (onToggleBreakpoint) {
            onToggleBreakpoint(line);
          }
        }
      });

      // Register Save keybinding action (Ctrl/Cmd+S)
      editor.addAction({
        id: 'save-and-format-action',
        label: 'Format and Save Buffers',
        keybindings: [
          monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS
        ],
        run: (ed: any) => {
          const value = ed.getValue();
          if (onSave) {
            onSave(value);
          }
        }
      });

      // Register Inline AI Generator action (Ctrl/Cmd+K)
      editor.addAction({
        id: 'inline-ai-generator-action',
        label: 'Surgical AI Edit & Precision Code Generator',
        keybindings: [
          monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyK
        ],
        contextMenuGroupId: '1_modification',
        contextMenuOrder: 1.5,
        run: () => {
          handleOpenInlineAI();
        }
      });

    } catch (e) {
      console.warn("Monaco initialization warning:", e);
    }

    if (onMount) {
      onMount(editor, monaco);
    }
  };

  return (
    <div className="h-full w-full overflow-hidden rounded-lg border border-aether-border bg-aether-bg shadow-inner relative flex flex-col">
      {/* Inline AI Generator Floating Overlay */}
      {showInlineAI && (
        <InlineAICodeGenerator
          filePath={filePath}
          language={language}
          currentCode={code}
          selectedText={selectedSnippet}
          onApplyGeneratedCode={handleApplyInlineCode}
          onClose={() => setShowInlineAI(false)}
        />
      )}

      {/* Quick Trigger Button in Top Right */}
      {!diffMode && !showInlineAI && (
        <button
          onClick={handleOpenInlineAI}
          className="absolute top-2 right-12 z-10 px-2.5 py-1 rounded-md bg-[#090b12]/85 hover:bg-orange-500/20 border border-orange-500/40 hover:border-orange-500/60 text-orange-300 text-[11px] font-mono flex items-center gap-1.5 backdrop-blur-md shadow-md transition-all cursor-pointer group select-none"
          title="Trigger Surgical AI Code Edit (Ctrl+K)"
        >
          <Scissors size={12} className="text-orange-400 group-hover:rotate-12 transition-transform" />
          <span>Surgical AI</span>
          <span className="text-[9px] text-white/40 bg-white/10 px-1 rounded font-mono">⌘K</span>
        </button>
      )}

      {isAIWriting && (
        <div className="absolute top-4 right-4 z-10 bg-aether-panel/90 backdrop-blur border border-aether-accent text-aether-accent px-3 py-1.5 rounded-full flex items-center gap-2 text-xs font-bold animate-pulse shadow-[0_0_15px_rgba(0,212,255,0.3)]">
            <Zap size={14} fill="currentColor" />
            AI WRITING...
        </div>
      )}
      
      {/* Glow Overlay when AI is active */}
      {isAIWriting && (
          <div className="absolute inset-0 z-0 pointer-events-none border-2 border-aether-accent/30 rounded-lg shadow-[inset_0_0_20px_rgba(0,212,255,0.1)]"></div>
      )}

      {(diffMode || originalCode) && (
        <div className="bg-cyan-950/80 border-b border-cyan-500/30 px-3 py-1.5 flex items-center justify-between text-xs shrink-0 z-10">
          <div className="flex items-center gap-2 text-cyan-300 font-bold font-mono text-[11px]">
            <GitCompare size={14} />
            <span>Surgical Diff Review</span>
            <span className="text-[10px] font-normal text-zinc-400">(Original vs Modified)</span>
          </div>
          <div className="flex items-center gap-2">
            {onRejectDiff && (
              <button
                onClick={onRejectDiff}
                className="px-2.5 py-1 rounded bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 font-bold text-[10px] flex items-center gap-1 transition-colors cursor-pointer"
              >
                <X size={12} /> Reject Changes
              </button>
            )}
            {onAcceptDiff && (
              <button
                onClick={onAcceptDiff}
                className="px-2.5 py-1 rounded bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-300 font-bold text-[10px] flex items-center gap-1 transition-colors cursor-pointer"
              >
                <Check size={12} /> Accept & Merge
              </button>
            )}
          </div>
        </div>
      )}

      {diffMode || originalCode ? (
        <DiffEditor
          height="100%"
          width="100%"
          language={language}
          original={originalCode || ''}
          modified={code}
          theme="aether-dark"
          options={{
            renderSideBySide: true,
            fontSize: fontSize,
            fontFamily: fontFamily || "'JetBrains Mono', monospace",
            scrollBeyondLastLine: false,
            automaticLayout: true,
            readOnly: true
          }}
        />
      ) : (
        <Editor
          height="100%"
          width="100%"
          language={language}
          value={code}
          onChange={onChange}
          onMount={handleEditorDidMount}
          theme="aether-dark"
          options={{
            minimap: { enabled: minimapEnabled ?? true },
            fontSize: fontSize,
            lineHeight: lineHeight ? Math.round(fontSize * lineHeight) : undefined,
            fontFamily: fontFamily || "'JetBrains Mono', monospace",
            fontLigatures: ligatures ?? true,
            scrollBeyondLastLine: false,
            glyphMargin: true,
            automaticLayout: true,
            readOnly: readOnly || isAIWriting, // Lock editor when AI is writing
            padding: { top: 16, bottom: 16 },
            smoothScrolling: true,
            cursorBlinking: 'smooth',
            cursorSmoothCaretAnimation: 'on'
          }}
        />
      )}
    </div>
  );
};

export default MonacoEditorWrapper;

