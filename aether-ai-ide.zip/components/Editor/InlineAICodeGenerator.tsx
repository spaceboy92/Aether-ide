import React, { useState, useRef, useEffect, useMemo } from "react";
import { 
  Sparkles, 
  Play, 
  Check, 
  X, 
  RotateCcw, 
  Zap, 
  Terminal, 
  Loader2, 
  ArrowRight,
  Scissors,
  Wand2,
  Bug,
  Code2,
  FileCode,
  Layers,
  ChevronRight,
  CheckCircle2,
  AlertCircle,
  Copy,
  Sliders
} from "lucide-react";
import { chatWithAIStream } from "../../services/geminiService";
import { 
  extractSurgicalHunks, 
  applySearchReplace, 
  applySurgicalEditWithDetails, 
  SurgicalHunk 
} from "../../services/fileService";

export interface InlineAICodeGeneratorProps {
  filePath: string;
  language: string;
  currentCode: string;
  selectedText?: string;
  onApplyGeneratedCode: (newCode: string, mode: 'replace' | 'insert' | 'diff') => void;
  onClose: () => void;
}

type EditPresetMode = 'surgical' | 'refactor' | 'fix' | 'types' | 'test' | 'custom';

const QUICK_PRESETS: { id: EditPresetMode; label: string; icon: any; prompt: string; desc: string }[] = [
  { 
    id: 'surgical', 
    label: 'Surgical Edit', 
    icon: Scissors, 
    prompt: 'Surgically modify only the necessary lines using precision SEARCH/REPLACE blocks. Preserve all existing working code.', 
    desc: 'Targeted block/line changes with zero truncation'
  },
  { 
    id: 'refactor', 
    label: 'Refactor & Clean', 
    icon: Wand2, 
    prompt: 'Refactor and modernize this code for performance, readability, and clean architecture without breaking existing behavior.', 
    desc: 'Improve structure, optimize loops & memoization'
  },
  { 
    id: 'fix', 
    label: 'Fix Bugs', 
    icon: Bug, 
    prompt: 'Identify any subtle bugs, race conditions, edge cases, or potential memory leaks, and surgically fix them.', 
    desc: 'Diagnose runtime errors & apply fixes'
  },
  { 
    id: 'types', 
    label: 'Types & Docs', 
    icon: Code2, 
    prompt: 'Add strict TypeScript types, explicit return signatures, and concise JSDoc documentation to all functions.', 
    desc: 'Enforce type safety & documentation'
  }
];

export const InlineAICodeGenerator: React.FC<InlineAICodeGeneratorProps> = ({
  filePath,
  language,
  currentCode,
  selectedText,
  onApplyGeneratedCode,
  onClose,
}) => {
  const [prompt, setPrompt] = useState("");
  const [activeMode, setActiveMode] = useState<EditPresetMode>(selectedText ? 'surgical' : 'refactor');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedCode, setGeneratedCode] = useState("");
  const [streamThoughts, setStreamThoughts] = useState("");
  const [generationSteps, setGenerationSteps] = useState<{ step: string; status: string }[]>([]);
  const [copied, setCopied] = useState(false);
  const [activeHunkTab, setActiveHunkTab] = useState<number>(0);

  const inputRef = useRef<HTMLInputElement>(null);
  const codeEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  useEffect(() => {
    if (codeEndRef.current && isGenerating) {
      codeEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [generatedCode, isGenerating]);

  // Analyze parsed surgical hunks from output
  const surgicalHunks = useMemo<SurgicalHunk[]>(() => {
    if (!generatedCode) return [];
    return extractSurgicalHunks(generatedCode);
  }, [generatedCode]);

  const hasSurgicalHunks = surgicalHunks.length > 0;

  // Compute final preview content
  const surgicalResult = useMemo(() => {
    if (!generatedCode) return null;
    if (hasSurgicalHunks) {
      return applySurgicalEditWithDetails(currentCode, generatedCode);
    }
    return null;
  }, [currentCode, generatedCode, hasSurgicalHunks]);

  const handleGenerate = async (customPromptOverride?: string) => {
    const finalPromptText = customPromptOverride || prompt.trim();
    if (!finalPromptText || isGenerating) return;

    setIsGenerating(true);
    setGeneratedCode("");
    setStreamThoughts("");
    setActiveHunkTab(0);
    setGenerationSteps([{ step: `Analyzing ${filePath}...`, status: "active" }]);

    const modePromptPrefix = activeMode === 'surgical'
      ? `SURGICAL EDIT MANDATE: Modify only the target code using precision SEARCH/REPLACE blocks:\n<<<<<<< SEARCH\n[exact lines to match from target file with 2-3 lines of surrounding context]\n=======\n[replacement lines]\n>>>>>>> REPLACE\n`
      : activeMode === 'refactor'
      ? `REFACTORING MANDATE: Produce clean, modern, high-performance ${language} code.\n`
      : activeMode === 'fix'
      ? `BUGFIX MANDATE: Diagnose and fix errors, returning surgical SEARCH/REPLACE blocks or clean code.\n`
      : ``;

    const fullPrompt = `You are an elite surgical code modification engine.
FILE PATH: "${filePath}" (Language: ${language})
${selectedText 
  ? `TARGET SELECTED SNIPPET (LINES TO SURGICALLY MODIFY):\n\`\`\`${language}\n${selectedText}\n\`\`\`\n` 
  : `FILE CONTEXT (EXCERPT):\n\`\`\`${language}\n${currentCode.slice(0, 3500)}\n\`\`\`\n`}

${modePromptPrefix}
USER INSTRUCTION / EDIT GOAL:
${finalPromptText}

CRITICAL RULES:
1. For surgical edits, output one or more <<<<<<< SEARCH ... ======= ... >>>>>>> REPLACE blocks matching the exact context in the file.
2. If rewriting the snippet or file, output clean, production-ready code in standard code blocks.
3. Zero placeholder comments (no "// ... rest of code"). Complete implementation only.`;

    try {
      await chatWithAIStream(
        fullPrompt,
        [{ id: 'active-file', name: filePath, path: filePath, content: currentCode, language, lastModified: Date.now() }],
        [],
        [],
        (thoughts, message, steps, codeFragment) => {
          if (thoughts) setStreamThoughts(thoughts);
          if (steps && steps.length > 0) setGenerationSteps(steps);

          if (codeFragment) {
            try {
              if (codeFragment.startsWith('{')) {
                const parsed = JSON.parse(codeFragment);
                const firstVal = Object.values(parsed)[0];
                if (firstVal) {
                  setGeneratedCode(String(firstVal));
                  return;
                }
              }
            } catch {}
          }

          // Check for code blocks or raw search-replace blocks
          if (message.includes('<<<<<<< SEARCH') || message.includes('@@')) {
            setGeneratedCode(message);
          } else {
            const codeMatch = message.match(/```(?:[a-zA-Z0-9_-]+)?\n([\s\S]*?)(?:```|$)/);
            if (codeMatch && codeMatch[1]) {
              setGeneratedCode(codeMatch[1]);
            } else if (!message.trim().startsWith('{')) {
              setGeneratedCode(message);
            }
          }
        },
        [],
        'gemini-3.7-flash'
      );
    } catch (err: any) {
      setGeneratedCode(`// Surgical edit error: ${err.message || 'Service unavailable'}\n// Please try again.`);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleApply = (mode: 'replace' | 'insert' | 'diff') => {
    if (!generatedCode) return;

    if (hasSurgicalHunks) {
      const merged = applySearchReplace(currentCode, generatedCode);
      onApplyGeneratedCode(merged, mode === 'diff' ? 'diff' : 'replace');
    } else if (selectedText && mode === 'replace') {
      onApplyGeneratedCode(generatedCode, 'replace');
    } else {
      onApplyGeneratedCode(generatedCode, mode);
    }
    onClose();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (generatedCode && !isGenerating) {
        handleApply('replace');
      } else {
        handleGenerate();
      }
    } else if (e.key === 'Escape') {
      onClose();
    }
  };

  const copyCode = () => {
    navigator.clipboard.writeText(generatedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const lineCount = generatedCode ? generatedCode.split('\n').length : 0;
  const fileName = filePath.split('/').pop() || filePath;

  return (
    <div className="absolute top-3 left-1/2 -translate-x-1/2 z-50 w-[95%] max-w-3xl rounded-xl bg-[#080a11]/95 backdrop-blur-2xl border border-orange-500/40 shadow-[0_24px_70px_rgba(0,0,0,0.85)] overflow-hidden animate-in fade-in zoom-in-95 duration-150 font-sans select-none">
      
      {/* Top Header Bar */}
      <div className="flex items-center justify-between px-3 py-2 bg-gradient-to-r from-orange-950/40 via-black/80 to-zinc-950/60 border-b border-orange-500/25">
        <div className="flex items-center gap-2">
          <div className="flex items-center justify-center w-6 h-6 rounded-lg bg-orange-500/20 text-orange-400 border border-orange-500/30 shrink-0">
            <Scissors size={13} className={isGenerating ? "animate-spin" : ""} />
          </div>
          <div>
            <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-white">
              <span>Surgical AI Code Editor</span>
              <span className="text-[10px] text-orange-400/80 bg-orange-500/10 px-1.5 py-0.2 rounded border border-orange-500/20">
                {fileName}
              </span>
              {selectedText && (
                <span className="text-[9px] text-emerald-400 bg-emerald-500/10 px-1.5 py-0.2 rounded border border-emerald-500/20">
                  {selectedText.split('\n').length} lines selected
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-white/10 transition-all cursor-pointer"
            title="Close (Esc)"
          >
            <X size={14} />
          </button>
        </div>
      </div>

      {/* Preset Action Selector Pills */}
      <div className="flex items-center gap-1.5 px-3 py-1.5 bg-black/40 border-b border-white/5 overflow-x-auto text-[11px] font-mono">
        {QUICK_PRESETS.map(preset => {
          const Icon = preset.icon;
          const isActive = activeMode === preset.id;
          return (
            <button
              key={preset.id}
              onClick={() => {
                setActiveMode(preset.id);
                setPrompt(preset.prompt);
              }}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition-all cursor-pointer shrink-0 ${
                isActive
                  ? "bg-orange-500/20 text-orange-300 border border-orange-500/40 font-bold"
                  : "bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white border border-transparent"
              }`}
              title={preset.desc}
            >
              <Icon size={12} className={isActive ? "text-orange-400" : "text-zinc-400"} />
              <span>{preset.label}</span>
            </button>
          );
        })}
      </div>

      {/* Input Field & Run Button */}
      <div className="flex items-center gap-2 p-3 bg-[#05060b] border-b border-white/5">
        <input
          ref={inputRef}
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={
            selectedText 
              ? `Surgically edit selected code (e.g. "Add error handling", "Optimize loop", "Make async")...`
              : `Surgical edit instruction for ${fileName} (e.g. "Fix collision logic", "Add particle burst")...`
          }
          className="flex-1 bg-transparent border-none text-white text-xs font-mono placeholder:text-zinc-500 focus:outline-none"
        />

        <button
          onClick={() => handleGenerate()}
          disabled={isGenerating || !prompt.trim()}
          className="px-3.5 py-1.5 rounded-lg bg-orange-500 hover:bg-orange-600 disabled:opacity-40 text-white font-mono text-xs font-bold flex items-center gap-1.5 transition-all shadow-md cursor-pointer disabled:cursor-not-allowed shrink-0"
        >
          {isGenerating ? <Loader2 size={13} className="animate-spin" /> : <Play size={12} fill="currentColor" />}
          <span>{isGenerating ? "Executing..." : "Apply AI"}</span>
        </button>
      </div>

      {/* Live Stream Status Bar */}
      {(isGenerating || generatedCode || streamThoughts) && (
        <div className="p-3 bg-[#030407] space-y-2.5">
          {/* Status info row */}
          <div className="flex items-center justify-between text-[11px] font-mono text-zinc-400 pb-1 border-b border-white/5">
            <div className="flex items-center gap-2">
              <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9.5px] font-bold ${
                isGenerating 
                  ? "bg-orange-500/20 text-orange-400 border border-orange-500/30 animate-pulse" 
                  : "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
              }`}>
                {isGenerating ? <Zap size={10} className="animate-bounce" /> : <Check size={10} />}
                {isGenerating ? "GENERATING SURGICAL EDIT" : "SURGICAL EDIT READY"}
              </span>

              {hasSurgicalHunks && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9.5px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  <Scissors size={10} />
                  {surgicalHunks.length} {surgicalHunks.length === 1 ? 'Hunk' : 'Hunks'}
                </span>
              )}

              {streamThoughts && (
                <span className="text-[10.5px] text-zinc-400 truncate max-w-xs italic hidden sm:inline">
                  💭 {streamThoughts.slice(0, 70)}...
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5">
              {lineCount > 0 && (
                <span className="text-[10px] text-orange-400/90 font-mono bg-orange-500/10 px-2 py-0.5 rounded border border-orange-500/20">
                  {lineCount} lines
                </span>
              )}
              <button
                onClick={copyCode}
                className="p-1 rounded text-zinc-400 hover:text-white hover:bg-white/10 transition-colors"
                title="Copy code to clipboard"
              >
                {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
              </button>
            </div>
          </div>

          {/* Hunks Navigation Tab (if surgical hunks detected) */}
          {hasSurgicalHunks && surgicalHunks.length > 1 && (
            <div className="flex items-center gap-1 bg-black/40 p-1 rounded-lg border border-white/5 text-[10px] font-mono overflow-x-auto">
              <span className="text-zinc-500 px-1.5 font-bold uppercase text-[9px]">Hunks:</span>
              {surgicalHunks.map((hunk, idx) => (
                <button
                  key={hunk.id}
                  onClick={() => setActiveHunkTab(idx)}
                  className={`px-2 py-0.5 rounded transition-all cursor-pointer ${
                    activeHunkTab === idx
                      ? "bg-purple-500/30 text-purple-200 border border-purple-400/40 font-bold"
                      : "bg-white/5 hover:bg-white/10 text-zinc-400"
                  }`}
                >
                  Hunk #{idx + 1} (+{hunk.diffStats?.added || 0}, -{hunk.diffStats?.removed || 0})
                </button>
              ))}
            </div>
          )}

          {/* Code & Diff Window */}
          {hasSurgicalHunks ? (
            /* Surgical Hunks View (Shows exact Search block in red and Replace block in green) */
            <div className="space-y-2">
              {surgicalHunks.slice(activeHunkTab, activeHunkTab + 1).map((hunk) => (
                <div key={hunk.id} className="rounded-lg border border-white/10 overflow-hidden text-xs font-mono bg-black/70">
                  {/* Search / Target Block */}
                  {hunk.searchBlock && (
                    <div className="border-b border-rose-500/20 bg-rose-950/20">
                      <div className="px-3 py-1 bg-rose-950/40 border-b border-rose-500/20 flex items-center justify-between text-[10px] text-rose-300 font-bold">
                        <span>- SEARCH / REMOVE ({hunk.diffStats?.removed || 0} lines)</span>
                      </div>
                      <pre className="p-2.5 text-rose-200/90 overflow-x-auto whitespace-pre leading-relaxed m-0 text-[11px]">
                        {hunk.searchBlock}
                      </pre>
                    </div>
                  )}

                  {/* Replace / Insertion Block */}
                  <div className="bg-emerald-950/20">
                    <div className="px-3 py-1 bg-emerald-950/40 border-b border-emerald-500/20 flex items-center justify-between text-[10px] text-emerald-300 font-bold">
                      <span>+ REPLACE / INSERT ({hunk.diffStats?.added || 0} lines)</span>
                    </div>
                    <pre className="p-2.5 text-emerald-200 overflow-x-auto whitespace-pre leading-relaxed m-0 text-[11px]">
                      {hunk.replaceBlock}
                    </pre>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            /* Standard Code Window */
            generatedCode && (
              <div className="relative max-h-60 overflow-y-auto rounded-lg bg-[#020306] border border-white/10 p-3 font-mono text-xs text-zinc-200 leading-relaxed">
                <pre className="whitespace-pre m-0">
                  {generatedCode}
                  {isGenerating && (
                    <span className="inline-block w-2 h-4 bg-orange-400 ml-1 translate-y-0.5 animate-pulse rounded-xs shadow-[0_0_8px_rgba(249,115,22,0.8)]" />
                  )}
                </pre>
                <div ref={codeEndRef} />
              </div>
            )
          )}

          {/* Action Buttons when code is generated */}
          {generatedCode && !isGenerating && (
            <div className="flex items-center justify-between gap-2 pt-1 border-t border-white/5">
              <div className="text-[10px] font-mono text-zinc-400 flex items-center gap-1.5">
                {surgicalResult?.isSurgical ? (
                  <span className="text-emerald-400 font-semibold flex items-center gap-1">
                    <CheckCircle2 size={11} /> {surgicalResult.summary}
                  </span>
                ) : (
                  <span>Ready to apply to {fileName}</span>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleApply('diff')}
                  className="px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/30 font-mono text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer"
                  title="Review changes in Monaco Side-by-Side Diff"
                >
                  <span>Diff Inspector</span>
                  <ArrowRight size={12} />
                </button>

                <button
                  onClick={() => handleApply('replace')}
                  className="px-4 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white font-mono text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-emerald-950/40 transition-all cursor-pointer"
                >
                  <Check size={13} />
                  <span>{hasSurgicalHunks ? "Apply Surgical Patch" : "Apply Code (Enter)"}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
