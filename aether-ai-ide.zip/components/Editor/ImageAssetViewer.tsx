import React, { useState, useEffect, useRef } from 'react';
import { 
  Image as ImageIcon, 
  Download, 
  Copy, 
  Check, 
  ZoomIn, 
  ZoomOut, 
  Maximize2, 
  RotateCw, 
  Sparkles, 
  Code, 
  Layers, 
  Trash2,
  ExternalLink,
  Eye
} from 'lucide-react';
import { FileNode } from '../../types';

interface ImageAssetViewerProps {
  file: FileNode;
  onDeleteFile?: (id: string) => void;
  onRegenerateImage?: (prompt: string, fileName: string) => void;
  onInsertCodeSnippet?: (snippet: string) => void;
  onUpdateContent?: (newContent: string) => void;
}

export const ImageAssetViewer: React.FC<ImageAssetViewerProps> = ({
  file,
  onDeleteFile,
  onRegenerateImage,
  onInsertCodeSnippet
}) => {
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [bgPattern, setBgPattern] = useState<'checker' | 'dark' | 'white'>('checker');
  const [copied, setCopied] = useState<'path' | 'tag' | 'import' | null>(null);
  const [imageMeta, setImageMeta] = useState<{ width: number; height: number; loaded: boolean }>({
    width: 0,
    height: 0,
    loaded: false
  });
  const [showPromptInput, setShowPromptInput] = useState(false);
  const [regenPrompt, setRegenPrompt] = useState('');

  const imgRef = useRef<HTMLImageElement>(null);

  // Extract proper image source URL from file content or data URL
  const imageSrc = file.content?.startsWith('http') || file.content?.startsWith('data:') 
    ? file.content 
    : `data:image/png;base64,${file.content}`;

  useEffect(() => {
    setZoom(1);
    setRotation(0);
    setImageMeta({ width: 0, height: 0, loaded: false });
  }, [file.id]);

  const handleImageLoad = (e: React.SyntheticEvent<HTMLImageElement>) => {
    const img = e.currentTarget;
    setImageMeta({
      width: img.naturalWidth || img.width,
      height: img.naturalHeight || img.height,
      loaded: true
    });
  };

  const copyToClipboard = (text: string, type: 'path' | 'tag' | 'import') => {
    navigator.clipboard.writeText(text);
    setCopied(type);
    setTimeout(() => setCopied(null), 2000);
  };

  const handleDownload = () => {
    const link = document.createElement('a');
    link.href = imageSrc;
    link.download = file.name.split('/').pop() || 'asset.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const cleanPath = file.name.startsWith('/') ? file.name.slice(1) : file.name;
  const fileName = cleanPath.split('/').pop() || 'image.png';
  const varName = fileName.replace(/\.[^/.]+$/, '').replace(/[^a-zA-Z0-9]/g, '_');

  return (
    <div className="h-full w-full flex flex-col bg-[#0b0c10] text-zinc-200 overflow-hidden select-none">
      {/* Top Asset Toolbar */}
      <div className="h-11 bg-zinc-950 border-b border-zinc-800/80 px-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-6 h-6 rounded-lg bg-pink-500/10 border border-pink-500/20 text-pink-400 flex items-center justify-center shrink-0">
            <ImageIcon size={13} />
          </div>
          <span className="font-bold text-xs text-white truncate max-w-[200px] sm:max-w-xs">{cleanPath}</span>
          {imageMeta.loaded && (
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-zinc-400 shrink-0">
              {imageMeta.width} × {imageMeta.height} px
            </span>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Zoom Controls */}
          <div className="flex items-center gap-0.5 bg-zinc-900 border border-zinc-800 rounded-lg p-0.5 mr-2">
            <button
              onClick={() => setZoom(prev => Math.max(0.2, prev - 0.2))}
              className="p-1 hover:bg-zinc-800 rounded text-zinc-400 hover:text-white transition-colors"
              title="Zoom Out"
            >
              <ZoomOut size={13} />
            </button>
            <span className="text-[10px] font-mono px-1 text-zinc-400 min-w-[3.5ch] text-center">
              {Math.round(zoom * 100)}%
            </span>
            <button
              onClick={() => setZoom(prev => Math.min(4, prev + 0.2))}
              className="p-1 hover:bg-zinc-800 rounded text-zinc-400 hover:text-white transition-colors"
              title="Zoom In"
            >
              <ZoomIn size={13} />
            </button>
            <button
              onClick={() => { setZoom(1); setRotation(0); }}
              className="p-1 hover:bg-zinc-800 rounded text-zinc-400 hover:text-white transition-colors text-[10px]"
              title="Reset View"
            >
              1:1
            </button>
            <button
              onClick={() => setRotation(r => (r + 90) % 360)}
              className="p-1 hover:bg-zinc-800 rounded text-zinc-400 hover:text-white transition-colors"
              title="Rotate 90°"
            >
              <RotateCw size={13} />
            </button>
          </div>

          {/* Background switcher */}
          <div className="flex items-center gap-0.5 bg-zinc-900 border border-zinc-800 rounded-lg p-0.5 mr-2">
            <button
              onClick={() => setBgPattern('checker')}
              className={`px-1.5 py-0.5 text-[10px] font-bold rounded ${bgPattern === 'checker' ? 'bg-amber-500/20 text-amber-400' : 'text-zinc-500 hover:text-zinc-300'}`}
              title="Checkerboard Background"
            >
              Grid
            </button>
            <button
              onClick={() => setBgPattern('dark')}
              className={`px-1.5 py-0.5 text-[10px] font-bold rounded ${bgPattern === 'dark' ? 'bg-amber-500/20 text-amber-400' : 'text-zinc-500 hover:text-zinc-300'}`}
              title="Dark Background"
            >
              Dark
            </button>
            <button
              onClick={() => setBgPattern('white')}
              className={`px-1.5 py-0.5 text-[10px] font-bold rounded ${bgPattern === 'white' ? 'bg-amber-500/20 text-amber-400' : 'text-zinc-500 hover:text-zinc-300'}`}
              title="White Background"
            >
              Light
            </button>
          </div>

          {/* Download */}
          <button
            onClick={handleDownload}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-zinc-300 hover:text-white text-xs font-semibold transition-colors"
            title="Download Image File"
          >
            <Download size={12} />
            <span className="hidden sm:inline">Download</span>
          </button>

          {/* AI Regenerate Prompt Toggle */}
          {onRegenerateImage && (
            <button
              onClick={() => setShowPromptInput(!showPromptInput)}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-gradient-to-r from-orange-500/20 to-pink-500/20 border border-orange-500/30 text-orange-400 hover:text-orange-300 text-xs font-bold transition-all shadow-sm"
              title="Regenerate with AI"
            >
              <Sparkles size={12} className="animate-pulse" />
              <span className="hidden sm:inline">AI Regenerate</span>
            </button>
          )}

          {/* Delete Asset */}
          {onDeleteFile && (
            <button
              onClick={() => {
                if (window.confirm(`Delete image asset '${fileName}'?`)) {
                  onDeleteFile(file.id);
                }
              }}
              className="p-1.5 rounded-lg text-zinc-500 hover:text-red-400 hover:bg-red-500/10 transition-colors"
              title="Delete Asset"
            >
              <Trash2 size={13} />
            </button>
          )}
        </div>
      </div>

      {/* AI Prompt Input Bar (Expandable) */}
      {showPromptInput && onRegenerateImage && (
        <div className="bg-zinc-900/90 border-b border-zinc-800 p-3 flex gap-2 items-center animate-in slide-in-from-top-2">
          <Sparkles size={14} className="text-orange-400 shrink-0" />
          <input
            type="text"
            value={regenPrompt}
            onChange={(e) => setRegenPrompt(e.target.value)}
            placeholder={`Describe edits or new prompt for ${fileName}...`}
            className="flex-1 bg-black/60 border border-zinc-700 rounded-lg px-3 py-1.5 text-xs text-white placeholder-zinc-500 outline-none focus:border-orange-500"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && regenPrompt.trim()) {
                onRegenerateImage(regenPrompt, fileName);
                setShowPromptInput(false);
              }
            }}
          />
          <button
            onClick={() => {
              if (regenPrompt.trim()) {
                onRegenerateImage(regenPrompt, fileName);
                setShowPromptInput(false);
              }
            }}
            className="px-3 py-1.5 bg-orange-500 hover:bg-orange-400 text-black text-xs font-bold rounded-lg transition-colors shrink-0"
          >
            Generate
          </button>
          <button
            onClick={() => setShowPromptInput(false)}
            className="px-2 py-1.5 text-zinc-500 hover:text-zinc-300 text-xs"
          >
            Cancel
          </button>
        </div>
      )}

      {/* Main Canvas Area */}
      <div 
        className={`flex-1 overflow-auto flex items-center justify-center p-8 relative ${
          bgPattern === 'checker' 
            ? 'bg-[radial-gradient(#1e222d_1px,transparent_1px)] [background-size:16px_16px] bg-[#07080b]' 
            : bgPattern === 'dark' 
            ? 'bg-zinc-950' 
            : 'bg-zinc-100'
        }`}
      >
        <div 
          className="relative transition-transform duration-100 ease-out flex items-center justify-center"
          style={{
            transform: `scale(${zoom}) rotate(${rotation}deg)`
          }}
        >
          <img
            ref={imgRef}
            src={imageSrc}
            alt={cleanPath}
            onLoad={handleImageLoad}
            className="max-h-[68vh] max-w-[80vw] object-contain rounded-lg shadow-2xl border border-white/10"
            style={{ imageRendering: zoom > 2 ? 'pixelated' : 'auto' }}
          />
        </div>
      </div>

      {/* Bottom Code Integration & Quick Snippet Footer */}
      <div className="bg-zinc-950 border-t border-zinc-800/80 p-3 px-4 flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[11px] font-bold text-zinc-500 uppercase tracking-wider flex items-center gap-1">
            <Code size={12} className="text-amber-400" /> Insert Code:
          </span>

          {/* Copy HTML <img> tag */}
          <button
            onClick={() => copyToClipboard(`<img src="/${cleanPath}" alt="${varName}" />`, 'tag')}
            className="px-2.5 py-1 rounded bg-zinc-900 border border-zinc-800 hover:border-amber-500/40 text-zinc-300 hover:text-white font-mono text-[11px] flex items-center gap-1.5 transition-colors"
          >
            {copied === 'tag' ? <Check size={11} className="text-emerald-400" /> : <Copy size={11} />}
            <span>&lt;img src="/{cleanPath}" /&gt;</span>
          </button>

          {/* Copy React Import */}
          <button
            onClick={() => copyToClipboard(`import ${varName} from '/${cleanPath}';`, 'import')}
            className="px-2.5 py-1 rounded bg-zinc-900 border border-zinc-800 hover:border-amber-500/40 text-zinc-300 hover:text-white font-mono text-[11px] flex items-center gap-1.5 transition-colors"
          >
            {copied === 'import' ? <Check size={11} className="text-emerald-400" /> : <Copy size={11} />}
            <span>import {varName} from '/{cleanPath}'</span>
          </button>

          {/* Copy Raw Path */}
          <button
            onClick={() => copyToClipboard(`/${cleanPath}`, 'path')}
            className="px-2 py-1 rounded bg-zinc-900 border border-zinc-800 hover:border-amber-500/40 text-zinc-400 hover:text-white font-mono text-[11px] flex items-center gap-1 transition-colors"
          >
            {copied === 'path' ? <Check size={11} className="text-emerald-400" /> : <Copy size={11} />}
            <span>/{cleanPath}</span>
          </button>
        </div>

        {onInsertCodeSnippet && (
          <button
            onClick={() => onInsertCodeSnippet(`<img src="/${cleanPath}" alt="${varName}" className="w-full h-auto rounded-xl shadow-lg" />`)}
            className="px-3 py-1 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-400 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5"
          >
            <Sparkles size={11} /> Paste into Current File
          </button>
        )}
      </div>
    </div>
  );
};
