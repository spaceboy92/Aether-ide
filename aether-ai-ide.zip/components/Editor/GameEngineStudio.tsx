
import React, { useState, useEffect, useRef } from 'react';
import { Play, Code, MessageSquare, Loader2, Sparkles, Gamepad2, X, Maximize2, Save, Send, Terminal } from 'lucide-react';
import { generateContentStream } from '../../services/aiService';
import { generateId } from '../../utils/id';

interface GameEngineStudioProps {
  type: '2D' | '3D';
  onSave?: () => void;
  onClose: () => void;
  onInjectCode?: (snippet: string) => void;
  initialPrompt?: string | null;
}

interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
}

const GameEngineStudio: React.FC<GameEngineStudioProps> = ({ type, onClose, initialPrompt }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState(initialPrompt || '');
  const [isProcessing, setIsProcessing] = useState(false);
  const [gameCode, setGameCode] = useState<string>('');
  const [srcDoc, setSrcDoc] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'preview' | 'code'>('preview');

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isProcessing]);

  useEffect(() => {
    if (initialPrompt && messages.length === 0) {
      handleGenerateGame(initialPrompt);
    }
  }, [initialPrompt]);

  const extractCode = (text: string) => {
    const match = text.match(/```(?:html|javascript|js)?\n([\s\S]*?)```/);
    if (match && match[1]) {
      return match[1];
    }
    // If no code block, maybe the whole text is html
    if (text.includes('<!DOCTYPE html>') || text.includes('<html>')) {
      return text;
    }
    return '';
  };

  const updatePreview = (code: string) => {
    setGameCode(code);
    
    // Inject some basic error catching for the iframe
    const errorCatchingCode = `
      <script>
        window.onerror = function(msg, url, lineNo, columnNo, error) {
          console.error('Game Error:', msg, 'at line:', lineNo);
          return false;
        };
      </script>
    `;
    
    let html = code;
    if (html.includes('<head>')) {
      html = html.replace('<head>', '<head>' + errorCatchingCode);
    } else {
      html = errorCatchingCode + html;
    }
    
    setSrcDoc(html);
  };

  const handleGenerateGame = async (promptOverride?: string) => {
    const promptText = promptOverride || input;
    if (!promptText.trim() || isProcessing) return;

    const userMsg: Message = { id: generateId('msg'), role: 'user', text: promptText };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsProcessing(true);

    const systemPrompt = `You are an expert game developer. 
Your task is to create a fully functional HTML5 ${type} game based on the user's request.
The game project MUST be cleanly structured into modular files: index.html for DOM markup linking style.css and script.js, style.css for custom CSS and animations, and script.js for game logic and engine rendering loops.
DO NOT use external assets (images, sounds) unless they are generated procedurally (e.g., using Canvas API) or use reliable public CDNs.
Use standard web APIs (Canvas API for 2D, Three.js via CDN for 3D).
GRAPHICS STYLE MANDATE: By default, construct REALISTIC environments with natural sun lighting, realistic PBR materials, grass/asphalt/dirt ground textures, realistic architecture, and natural foliage unless the user explicitly requests cyberpunk, neon, or stylized graphics.
Include game loops, score tracking, player controls, and win/loss states.`;

    try {
      const stream = generateContentStream(
        'gemini-3.1-pro-preview',
        `User request: ${promptText}\n\nCurrent game code (if any, modify this):\n\`\`\`html\n${gameCode}\n\`\`\`\n\nPlease provide the updated complete HTML code.`,
        { systemInstruction: systemPrompt, temperature: 0.7, maxOutputTokens: 65536 }
      );

      let fullResponse = '';
      for await (const chunk of stream) {
        fullResponse += chunk;
      }

      const modelMsg: Message = { id: generateId('msg'), role: 'model', text: 'Game generated successfully! Check the preview.' };
      setMessages(prev => [...prev, modelMsg]);

      const extracted = extractCode(fullResponse);
      if (extracted) {
        updatePreview(extracted);
        setActiveTab('preview');
      }

    } catch (err: any) {
      setMessages(prev => [...prev, { id: generateId('msg'), role: 'model', text: `Error generating game: ${err.message}` }]);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="h-full w-full flex bg-[#0a0a0a] text-white overflow-hidden border border-white/10 rounded-xl">
      {/* Left Panel: Chat & Generation */}
      <div className="w-1/3 flex flex-col border-r border-white/10 bg-[#111]">
        <div className="h-12 border-b border-white/10 flex items-center justify-between px-4 shrink-0 bg-black/40">
          <div className="flex items-center gap-2">
            <Gamepad2 size={16} className="text-purple-500" />
            <span className="text-xs font-bold uppercase tracking-widest text-white/80">Aether {type} Engine</span>
          </div>
          <button onClick={onClose} className="p-1 hover:text-red-400 text-white/40 transition-colors">
            <X size={16} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4 custom-scrollbar">
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center opacity-50 space-y-4">
              <Sparkles size={32} className="text-purple-400" />
              <p className="text-xs max-w-[200px]">Describe the game you want to build. The AI will generate a complete, playable web game.</p>
            </div>
          )}
          {messages.map(msg => (
            <div key={msg.id} className={`flex flex-col gap-1 ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
              <span className={`text-[9px] uppercase tracking-wider font-bold ${msg.role === 'user' ? 'text-purple-400' : 'text-emerald-400'}`}>
                {msg.role}
              </span>
              <div className={`p-3 rounded-xl max-w-[90%] text-xs leading-relaxed ${msg.role === 'user' ? 'bg-purple-500/20 text-white' : 'bg-white/5 text-white/80'}`}>
                {msg.text}
              </div>
            </div>
          ))}
          {isProcessing && (
            <div className="flex items-center gap-2 text-purple-400 text-xs">
              <Loader2 size={14} className="animate-spin" /> Compiling game logic...
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-3 border-t border-white/10 bg-black/40">
          <form 
            onSubmit={(e) => { e.preventDefault(); handleGenerateGame(); }}
            className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-xl p-1 pr-2 focus-within:border-purple-500/50 transition-colors"
          >
            <input
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              placeholder="e.g., A retro snake game with neon graphics..."
              className="flex-1 bg-transparent border-none outline-none text-xs px-3 py-2 text-white placeholder:text-white/30"
              disabled={isProcessing}
            />
            <button
              type="submit"
              disabled={isProcessing || !input.trim()}
              className="p-2 bg-purple-500 hover:bg-purple-400 text-white rounded-lg disabled:opacity-50 transition-colors"
            >
              <Send size={14} />
            </button>
          </form>
        </div>
      </div>

      {/* Right Panel: Preview & Code */}
      <div className="flex-1 flex flex-col min-w-0 bg-black relative">
        <div className="absolute top-4 left-4 z-10 flex bg-black/80 backdrop-blur-md rounded-lg border border-white/10 p-1">
          <button
            onClick={() => setActiveTab('preview')}
            className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase tracking-widest transition-colors flex items-center gap-2 ${activeTab === 'preview' ? 'bg-white/10 text-white' : 'text-white/40 hover:text-white'}`}
          >
            <Play size={12} /> Preview
          </button>
          <button
            onClick={() => setActiveTab('code')}
            className={`px-3 py-1.5 rounded text-[10px] font-bold uppercase tracking-widest transition-colors flex items-center gap-2 ${activeTab === 'code' ? 'bg-white/10 text-white' : 'text-white/40 hover:text-white'}`}
          >
            <Code size={12} /> Code
          </button>
        </div>

        <div className="flex-1 overflow-hidden relative">
          {activeTab === 'preview' ? (
            srcDoc ? (
              <iframe
                srcDoc={srcDoc}
                className="w-full h-full border-none bg-white"
                sandbox="allow-scripts allow-same-origin"
                title="Game Preview"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-white/20">
                <div className="text-center">
                  <Gamepad2 size={48} className="mx-auto mb-4 opacity-50" />
                  <p className="text-sm font-mono uppercase tracking-widest">No Game Loaded</p>
                </div>
              </div>
            )
          ) : (
            <div className="w-full h-full bg-[#1e1e1e] p-4 overflow-auto pt-16 custom-scrollbar">
              <pre className="text-xs font-mono text-green-400">
                {gameCode || '// No code generated yet'}
              </pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GameEngineStudio;
