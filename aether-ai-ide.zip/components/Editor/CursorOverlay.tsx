import React from 'react';
import { motion } from 'motion/react';

interface Cursor {
  userId: string;
  userName: string;
  position: { x: number, y: number };
  color: string;
}

interface CursorOverlayProps {
  cursors: Cursor[];
}

const CursorOverlay: React.FC<CursorOverlayProps> = ({ cursors }) => {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {cursors.map((cursor) => (
        <motion.div 
          key={cursor.userId}
          initial={{ opacity: 0 }}
          animate={{ 
            opacity: 1,
            x: cursor.position.x,
            y: cursor.position.y 
          }}
          transition={{ duration: 0.1, ease: 'linear' }}
          className="absolute z-[9999]"
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M5.65376 12.3673H5.46026L5.31717 12.4976L0.500002 16.8829L0.500002 1.19841L11.7841 12.3673H5.65376Z" fill={cursor.color} stroke="white" strokeWidth="1"/>
          </svg>
          <div 
            className="ml-4 mt-2 px-1.5 py-0.5 rounded text-[8px] font-bold text-white whitespace-nowrap shadow-lg border border-white/10"
            style={{ backgroundColor: cursor.color }}
          >
            {cursor.userName}
          </div>
        </motion.div>
      ))}
    </div>
  );
};

export default CursorOverlay;
