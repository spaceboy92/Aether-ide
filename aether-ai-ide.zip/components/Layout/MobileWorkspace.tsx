import React, { useState, useEffect, useMemo, Suspense, lazy, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  FileNode, 
  ChatSession, 
  AgentAction 
} from "../../types";
import { storageService } from "../../services/storageService";
const { saveFile } = storageService;
import { 
  FolderOpen, 
  Code2, 
  Wand2, 
  Activity,
  Cpu,
  RefreshCw,
  Plus,
  Play,
  Settings,
  Eye,
  ChevronDown,
  Terminal,
  Bot,
  Layers,
  Sparkles,
  Palette,
  Check,
  FileCode,
  Sliders,
  LogOut,
  FolderTree,
  Search,
  History,
  Globe,
  ShieldAlert,
  Database,
  Volume2,
  Network,
  Gauge,
  LayoutGrid,
  Menu,
  ChevronLeft,
  Wrench,
  Flame,
  ShieldCheck,
  AlertTriangle,
  X
} from "lucide-react";

import FileExplorer from "../Files/FileExplorer";
import MonacoEditorWrapper from "../Editor/MonacoEditorWrapper";
import { PreviewPane } from "../Preview/PreviewPane";
import AIAssistant from "../AI/AIAssistant";
import SystemLoader from "../UI/SystemLoader";

// Lazy loaded features
const MasterpieceUI = lazy(() => import("../Studio/MasterpieceUI"));
const SearchView = lazy(() => import("../Files/SearchView"));
const SettingsView = lazy(() => import("../Settings/SettingsView"));
const ExtensionsView = lazy(() => import("../Settings/ExtensionsView"));
const CustomizerView = lazy(() => import("../Settings/CustomizerView"));
const FileHistoryView = lazy(() => import("../Files/FileHistoryView"));
const SystemTerminal = lazy(() => import("../Tools/SystemTerminal"));
const LinuxSystemStudio = lazy(() => import("../Tools/LinuxSystemStudio"));
const EvolutionCore = lazy(() => import("../Tools/EvolutionCore").then(m => ({ default: m.EvolutionCore })));
const TaskRunnerView = lazy(() => import("../Tools/TaskRunnerView").then(m => ({ default: m.TaskRunnerView })));
const ApiPlayground = lazy(() => import("../Tools/ApiPlayground"));
const SecurityScannerView = lazy(() => import("../Tools/SecurityScannerView"));
const DatabaseStudio = lazy(() => import("../Tools/DatabaseStudio"));
const DataTransformerStudio = lazy(() => import("../Tools/DataTransformerStudio"));
const UIComponentStudio = lazy(() => import("../Tools/UIComponentStudio"));
const AudioSynthStudio = lazy(() => import("../Tools/AudioSynthStudio"));
const DependencyGraphStudio = lazy(() => import("../Tools/DependencyGraphStudio"));
const PerformanceProfiler = lazy(() => import("../Tools/PerformanceProfiler"));

interface MobileWorkspaceProps {
  user: any;
  files: FileNode[];
  setFiles: any;
  activeFileId: string | null;
  setActiveFileId: (id: string | null) => void;
  activeSessionId: string | null;
  setActiveSessionId: (id: string | null) => void;
  sessions: ChatSession[];
  setSessions: any;
  isProcessing: boolean;
  isSyncing: boolean;
  connectionStatus: "online" | "offline";
  googleDriveConnected: boolean;
  activeUsers: any[];
  systemStats: any;
  activeFont: string;
  minimapEnabled: boolean;
  perfMode: 'high' | 'low';
  onTogglePerfMode: () => void;
  chatCompactMode: boolean;
  onToggleChatCompact: () => void;
  onOptimizeMemory: () => void;
  autoPilotMode?: boolean;
  setAutoPilotMode?: (val: boolean) => void;
  addLog: (type: any, msg: string, source?: string) => void;
  handleRenameFile: (id: string, name: string) => void;
  handleExportProject: () => void;
  handleApplyTemplate: (type: string) => void;
  handleAgentAction: any;
  handleUploadFiles: (files: any) => void;
  createNewSession: any;
  handleDeleteSession: (id: string) => void;
  handleRenameSession?: (id: string, newTitle: string) => void;
  sendMessage: (msg: string, attachments?: { mimeType: string, data: string }[], modelId?: string, isCompactMode?: boolean) => void;
  stopProcessing: () => void;
  autoSave: any;
  handleCommandPaletteSelect: (cmdId: string, payload?: any) => void;
  focusMode: boolean;
  setFocusMode: (val: boolean) => void;
  zenMode: boolean;
  setZenMode: (val: boolean) => void;
  onOpenHealth: () => void;
  onOpenSettings: () => void;
  sidebarMode: any;
  setSidebarMode: (mode: any) => void;
  onUpdateUser: (user: any) => void;
  onLogout: () => void;
  onNuclearReset: () => void;
  onClearAllSessions: () => void;
  onSyncNow: () => void;
}

const MobileWorkspace: React.FC<MobileWorkspaceProps> = ({
  user,
  files,
  setFiles,
  activeFileId,
  setActiveFileId,
  activeSessionId,
  setActiveSessionId,
  sessions,
  setSessions,
  isProcessing,
  isSyncing,
  connectionStatus,
  googleDriveConnected,
  activeUsers,
  systemStats,
  activeFont,
  perfMode,
  onTogglePerfMode,
  chatCompactMode,
  onToggleChatCompact,
  autoPilotMode = false,
  setAutoPilotMode,
  addLog,
  handleRenameFile,
  handleExportProject,
  handleApplyTemplate,
  handleAgentAction,
  handleUploadFiles,
  createNewSession,
  handleDeleteSession,
  handleRenameSession,
  sendMessage,
  stopProcessing,
  onUpdateUser,
  onLogout,
  onNuclearReset,
  onClearAllSessions,
  onSyncNow
}) => {
  // Mobile active tabs
  const [activeTab, setActiveTab] = useState<'dashboard' | 'assistant' | 'editor' | 'preview' | 'tools'>(() => {
    return (localStorage.getItem("aether_mobile_active_tab") as any) || "dashboard";
  });

  // Track slide-over file explorer drawer state within Editor
  const [showExplorerDrawer, setShowExplorerDrawer] = useState(false);

  // Active overlay feature sheet selected from the "More" tab
  const [activeFeature, setActiveFeature] = useState<string | null>(null);

  // Track session dropdown/popover menu state
  const [sessionDropdownOpen, setSessionDropdownOpen] = useState(false);

  // Tool explorer search
  const [toolSearchQuery, setToolSearchQuery] = useState("");

  const activeFile = useMemo(() => files.find((f) => f.id === activeFileId), [files, activeFileId]);
  const activeSession = useMemo(() => sessions.find((s) => s.id === activeSessionId), [sessions, activeSessionId]);

  useEffect(() => {
    localStorage.setItem("aether_mobile_active_tab", activeTab);
  }, [activeTab]);

  useEffect(() => {
    const handleSwitchMobileTab = (e: any) => {
      if (e.detail && e.detail.tab) {
        setActiveTab(e.detail.tab);
        setActiveFeature(null);
      }
    };
    window.addEventListener('aether-switch-mobile-tab', handleSwitchMobileTab);
    return () => window.removeEventListener('aether-switch-mobile-tab', handleSwitchMobileTab);
  }, []);

  useEffect(() => {
    if (!activeSessionId) {
      setActiveTab("dashboard");
      setActiveFeature(null);
    } else {
      setActiveTab((prev) => (prev === "dashboard" ? "assistant" : prev));
    }
  }, [activeSessionId]);

  const handleFormatActiveFile = useCallback(() => {
    addLog("success", "Code formatted with standard Aether beautifier.", "FORMATTER");
  }, [addLog]);

  const handleSelectPaletteCommand = useCallback((cmd: string) => {
    addLog("info", `Executing workflow command: ${cmd}`, "SYSTEM");
  }, [addLog]);

  // Premium labeled list matching high-fidelity iOS grouping styles
  const featuresList = [
    { id: 'settings', title: 'Settings', icon: Settings, desc: 'Tweak performance parameters, sandbox engines & connection paths.', color: 'text-orange-400 bg-orange-500/10 border-orange-500/20' },
    { id: 'customizer', title: 'Theme customizer', icon: Palette, desc: 'Switch fonts, workspace styles, and glowing borders.', color: 'text-pink-400 bg-pink-500/10 border-pink-500/20' },
    { id: 'terminal', title: 'Neural Terminal', icon: Terminal, desc: 'Standard system console command prompt utility.', color: 'text-amber-400 bg-amber-500/10 border-amber-500/20' },
    { id: 'search', title: 'Global Search', icon: Search, desc: 'Analyze and lookup references across index trees.', color: 'text-sky-400 bg-sky-500/10 border-sky-500/20' },
    { id: 'database', title: 'Database Studio', icon: Database, desc: 'Realtime query engine for persistent key-value tables.', color: 'text-violet-400 bg-violet-500/10 border-violet-500/20' },
    { id: 'api_playground', title: 'API Playground', icon: Globe, desc: 'Test requests, JSON webhooks & payloads.', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' },
    { id: 'security', title: 'Security Auditor', icon: ShieldCheck, desc: 'Verify secret isolation, keys & permission parameters.', color: 'text-rose-400 bg-rose-500/10 border-rose-500/20' },
    { id: 'uistudio', title: 'UI component studio', icon: Layers, desc: 'Generate rapid vector wireframes and mock components.', color: 'text-teal-400 bg-teal-500/10 border-teal-500/20' },
    { id: 'datatransformer', title: 'Data Transformer', icon: Wand2, desc: 'Format and parse XML, CSV, Markdown, or JSON.', color: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/20' },
    { id: 'audiosynth', title: 'Audio Synthesizer', icon: Volume2, desc: 'Custom synthesis module for notification feedback.', color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20' },
    { id: 'dependencygraph', title: 'Architecture Graph', icon: Network, desc: 'Interactive node visualizer for project structures.', color: 'text-purple-400 bg-purple-500/10 border-purple-500/20' },
    { id: 'profiler', title: 'Performance Metrics', icon: Gauge, desc: 'Inspect framerate delays, execution loops & hot leaks.', color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20' },
    { id: 'evolution', title: 'Evolution Engine', icon: Cpu, desc: 'Engage iterative AI diagnostic pipelines.', color: 'text-red-400 bg-red-500/10 border-red-500/20' },
    { id: 'tasks', title: 'Task Runner', icon: Play, desc: 'Trigger bundlers, linter checks & custom tests.', color: 'text-green-400 bg-green-500/10 border-green-500/20' },
    { id: 'history', title: 'Revisions', icon: History, desc: 'Manage automated rollback points and snapshots.', color: 'text-blue-400 bg-blue-500/10 border-blue-500/20' },
    { id: 'linux', title: 'Linux System Studio', icon: Activity, desc: 'Inspect base containers CPU, Disk, and hardware.', color: 'text-emerald-500 bg-emerald-500/10 border-emerald-500/20' }
  ];

  const filteredFeatures = useMemo(() => {
    if (!toolSearchQuery.trim()) return featuresList;
    return featuresList.filter(f => 
      f.title.toLowerCase().includes(toolSearchQuery.toLowerCase()) || 
      f.desc.toLowerCase().includes(toolSearchQuery.toLowerCase())
    );
  }, [toolSearchQuery]);

  return (
    <div id="mobile-workspace-root" className="w-full h-full flex flex-col bg-[#020304] text-zinc-100 select-none overflow-hidden relative font-sans">
      
      {/* Dynamic Ambient Background Glow for iOS look */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[180px] h-[60px] rounded-full bg-gradient-to-b from-orange-500/8 to-transparent blur-2xl pointer-events-none z-0" />

      {/* 1. iOS-Style Translucent Blurred Header with Hairline Inset */}
      <header className="flex h-14 items-center justify-between px-4 shrink-0 relative z-[70] border-b border-white/[0.04] bg-[#07090d]/75 backdrop-blur-3xl shadow-sm">
        <div className="flex items-center gap-3">
          {/* Glowing Aether Brand Icon */}
          <motion.div 
            whileTap={{ scale: 0.90 }}
            className="w-7 h-7 rounded-xl bg-gradient-to-b from-orange-400 to-orange-600 flex items-center justify-center shadow-[0_2px_8px_rgba(249,115,22,0.3)] cursor-pointer"
          >
            <Sparkles size={13} className="text-black stroke-[3]" />
          </motion.div>
          
          {/* iOS-Style Pill Workspace Dropdown */}
          <div className="relative">
            <motion.button 
              whileTap={{ scale: 0.96 }}
              onClick={() => setSessionDropdownOpen(!sessionDropdownOpen)}
              className="flex items-center gap-1.5 px-3 py-1 bg-white/[0.04] hover:bg-white/[0.08] active:bg-white/[0.12] border border-white/[0.06] rounded-full text-[11px] font-bold text-zinc-200 transition-all max-w-[145px] truncate"
            >
              <span className="truncate">{activeSession?.title || "Project Hub"}</span>
              <ChevronDown size={12} className="text-zinc-500 shrink-0" />
            </motion.button>

            {/* Translucent Action Sheet Dropdown */}
            <AnimatePresence>
              {sessionDropdownOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setSessionDropdownOpen(false)} />
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95, y: -8 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: -8 }}
                    transition={{ type: "spring", stiffness: 450, damping: 28 }}
                    className="absolute left-0 mt-3 w-64 bg-[#0a0c10]/95 border border-white/[0.08] rounded-3xl shadow-[0_15px_40px_rgba(0,0,0,0.7)] z-50 py-2.5 backdrop-blur-2xl overflow-hidden"
                  >
                    <div className="px-3.5 pb-2 text-[9px] font-black text-zinc-500 uppercase tracking-widest border-b border-white/[0.04] mb-1.5 flex items-center justify-between">
                      <span>Aether Workspaces</span>
                      <span className="text-[8px] bg-orange-500/15 text-orange-400 px-1.5 py-0.5 rounded-full font-mono font-bold">
                        {sessions.length}
                      </span>
                    </div>
                    <div className="max-h-56 overflow-y-auto custom-scrollbar space-y-0.5 px-1.5">
                      {sessions.map((session) => (
                        <button
                          key={session.id}
                          onClick={() => {
                            setActiveSessionId(session.id);
                            setSessionDropdownOpen(false);
                            setActiveTab("assistant");
                          }}
                          className={`w-full text-left px-3 py-2 rounded-2xl text-xs flex items-center justify-between transition-all ${
                            session.id === activeSessionId 
                              ? "bg-gradient-to-r from-orange-500/10 to-amber-500/5 text-orange-300 font-bold" 
                              : "text-zinc-400 hover:text-white hover:bg-white/[0.03]"
                          }`}
                        >
                          <span className="truncate pr-3">{session.title || "Untitled Project"}</span>
                          {session.id === activeSessionId && <Check size={12} className="text-orange-400 shrink-0 stroke-[2.5]" />}
                        </button>
                      ))}
                    </div>
                    <div className="border-t border-white/[0.04] mt-2 pt-2 px-1.5">
                      <button
                        onClick={() => {
                          createNewSession();
                          setSessionDropdownOpen(false);
                          setActiveTab("assistant");
                        }}
                        className="w-full text-left px-3 py-2 text-xs text-orange-400 hover:text-orange-300 hover:bg-white/5 flex items-center gap-2 font-bold transition-colors rounded-2xl"
                      >
                        <Plus size={13} className="stroke-[2.5]" />
                        New workspace
                      </button>
                    </div>
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Top Header Controls */}
        <div className="flex items-center gap-2">
          {setAutoPilotMode && activeSessionId && (
            <motion.button
              whileTap={{ scale: 0.94 }}
              onClick={() => setAutoPilotMode(!autoPilotMode)}
              className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[9px] font-bold uppercase tracking-wider border transition-all ${
                autoPilotMode 
                  ? "bg-emerald-500/15 border-emerald-500/25 text-emerald-400 shadow-[0_0_8px_rgba(16,185,129,0.15)]" 
                  : "bg-white/[0.02] border-white/[0.04] text-zinc-500"
              }`}
            >
              <Bot size={11} className={autoPilotMode ? "animate-pulse" : ""} />
              <span>Pilot</span>
            </motion.button>
          )}

          <motion.button 
            whileTap={{ scale: 0.92 }}
            onClick={onTogglePerfMode}
            className={`p-1.5 rounded-xl border transition-all ${
              perfMode === 'low' 
                ? "bg-amber-500/15 border-amber-500/25 text-amber-400" 
                : "bg-white/[0.03] border-white/[0.06] text-zinc-400 hover:bg-white/[0.08]"
            }`}
          >
            <Cpu size={13} />
          </motion.button>
        </div>
      </header>

      {/* 2. Enhanced Viewport Canvas Area */}
      <main className="flex-1 w-full min-h-0 relative overflow-hidden bg-[#020304] z-10">
        <AnimatePresence mode="wait">
          
          {/* A. DASHBOARD / PROJECT HUB */}
          {activeTab === 'dashboard' && (
            <motion.div 
              key="dashboard"
              initial={{ opacity: 0, scale: 0.99, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.99, y: -8 }}
              transition={{ type: "spring", stiffness: 420, damping: 28 }}
              className="w-full h-full flex flex-col overflow-hidden"
            >
              <Suspense fallback={<SystemLoader message="Initializing system cluster..." />}>
                <MasterpieceUI
                  onStart={(p) => {
                    createNewSession(p);
                    setActiveTab("assistant");
                  }}
                  sessions={sessions}
                  onSelectSession={(id) => {
                    setActiveSessionId(id);
                    setActiveTab("assistant");
                  }}
                  onOpenSettings={() => {
                    setActiveTab("tools");
                    setActiveFeature("settings");
                  }}
                  onShowGallery={() => {}}
                  onViewAllSessions={() => {
                    setActiveTab("tools");
                    setActiveFeature("history");
                  }}
                  onDeleteSession={handleDeleteSession}
                  onRenameSession={handleRenameSession}
                />
              </Suspense>
            </motion.div>
          )}

          {/* B. CO-PILOT ASSISTANT */}
          {activeTab === 'assistant' && (
            <motion.div 
              key="assistant"
              initial={{ opacity: 0, scale: 0.99, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.99, y: -8 }}
              transition={{ type: "spring", stiffness: 420, damping: 28 }}
              className="w-full h-full flex flex-col overflow-hidden"
            >
              <Suspense fallback={<SystemLoader message="Powering AI assistant..." />}>
                <AIAssistant
                  user={user}
                  files={files}
                  activeFileId={activeFileId}
                  setActiveFileId={setActiveFileId}
                  onCommandSelect={handleSelectPaletteCommand}
                  onAgentAction={handleAgentAction}
                  sessions={sessions}
                  activeSessionId={activeSessionId}
                  onCreateSession={() => createNewSession()}
                  onClose={() => {}}
                  onUpdateSession={(s) =>
                    setSessions((prev: ChatSession[]) =>
                      prev.map((x) => (x.id === s.id ? s : x)),
                    )
                  }
                  onForkSession={(forked) => {
                    setSessions((prev: ChatSession[]) => [forked, ...prev]);
                    setActiveSessionId(forked.id);
                  }}
                  isProcessing={isProcessing}
                  isCompactMode={chatCompactMode}
                  onToggleCompactMode={onToggleChatCompact}
                  onSendMessage={(userMsg, atts, modelId, isCompact) => {
                    sendMessage(userMsg, atts, modelId, isCompact);
                  }}
                  onStopProcessing={stopProcessing}
                  onUploadFiles={handleUploadFiles}
                  onRedirectToGameEngine={() => {
                    setActiveTab("preview");
                  }}
                />
              </Suspense>
            </motion.div>
          )}

          {/* C. UNIFIED MONACO COMPILER & FILE EXPLORER */}
          {activeTab === 'editor' && (
            <motion.div 
              key="editor"
              initial={{ opacity: 0, scale: 0.99, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.99, y: -8 }}
              className="w-full h-full flex flex-col overflow-hidden relative"
            >
              {/* Slide-over File Explorer Drawer */}
              <AnimatePresence>
                {showExplorerDrawer && (
                  <>
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      onClick={() => setShowExplorerDrawer(false)}
                      className="absolute inset-0 bg-black/60 backdrop-blur-sm z-30"
                    />
                    <motion.div
                      initial={{ x: "-100%" }}
                      animate={{ x: 0 }}
                      exit={{ x: "-100%" }}
                      transition={{ type: "spring", stiffness: 350, damping: 30 }}
                      className="absolute left-0 top-0 bottom-0 w-[85%] max-w-[320px] bg-[#07090d] border-r border-white/10 z-40 shadow-2xl flex flex-col"
                    >
                      <div className="h-11 px-3 border-b border-white/[0.06] flex items-center justify-between shrink-0 bg-[#0a0c10]">
                        <span className="text-[11px] font-bold text-amber-400 uppercase tracking-widest flex items-center gap-1.5">
                          <FolderTree size={13} />
                          Workspace Files ({files.length})
                        </span>
                        <button
                          onClick={() => setShowExplorerDrawer(false)}
                          className="p-1 text-zinc-400 hover:text-white rounded-lg hover:bg-white/10"
                        >
                          <X size={14} />
                        </button>
                      </div>
                      <div className="flex-1 overflow-hidden">
                        <FileExplorer
                          projectId={activeSessionId}
                          files={files}
                          activeFileId={activeFileId}
                          onSelectFile={(f) => {
                            setActiveFileId(f.id);
                            setShowExplorerDrawer(false);
                          }}
                          onCreateFile={(name, lang) => {
                            const id = "f-" + Math.random().toString(36).substr(2, 9);
                            const newF: FileNode = { id, name, content: "", language: lang, lastModified: Date.now() };
                            setFiles((prev: FileNode[]) => [...prev, newF]);
                            setActiveFileId(newF.id);
                            setShowExplorerDrawer(false);
                          }}
                          onDeleteFile={(id) => {
                            setFiles((prev: FileNode[]) => prev.filter(f => f.id !== id));
                            if (activeFileId === id) setActiveFileId(null);
                          }}
                          onRenameFile={handleRenameFile}
                          onExport={handleExportProject}
                          onApplyTemplate={handleApplyTemplate}
                          onFilesUpdated={(updated) => setFiles(updated)}
                        />
                      </div>
                    </motion.div>
                  </>
                )}
              </AnimatePresence>

              {activeFile ? (
                <div className="w-full h-full flex flex-col overflow-hidden bg-[#040609]">
                  {/* iOS Style Editor Header with Files Drawer Toggle */}
                  <div className="h-11 px-3 border-b border-white/[0.04] bg-[#07090c] flex items-center justify-between shrink-0">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setShowExplorerDrawer(!showExplorerDrawer)}
                        className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/20 text-[10px] font-bold transition-all cursor-pointer"
                        title="Toggle Files Drawer"
                      >
                        <FolderTree size={12} />
                        <span>Files ({files.length})</span>
                      </button>
                      <div className="h-3.5 w-px bg-white/10" />
                      <FileCode size={13} className="text-sky-400" />
                      <span className="text-[11px] font-bold text-zinc-300 truncate max-w-[140px]">
                        {activeFile.name}
                      </span>
                    </div>
                    <motion.button
                      whileTap={{ scale: 0.94 }}
                      onClick={handleFormatActiveFile}
                      className="px-2.5 py-1 rounded-full bg-white/[0.04] hover:bg-white/[0.08] active:bg-white/[0.12] text-[10px] font-bold text-zinc-300 border border-white/[0.06] transition-all cursor-pointer"
                    >
                      Format code
                    </motion.button>
                  </div>

                  <div className="flex-1 w-full relative min-h-0 bg-[#020305]">
                    <Suspense fallback={<SystemLoader message="Initializing Monaco syntax compiler..." />}>
                      <MonacoEditorWrapper
                        onMount={() => {}}
                        code={activeFile.content}
                        language={activeFile.language}
                        filePath={activeFile.name}
                        breakpoints={[]}
                        onToggleBreakpoint={() => {}}
                        onChange={(c) => {
                          if (activeFileId) {
                            const updatedContent = c || "";
                            const nf = files.map((f) =>
                              f.id === activeFileId
                                ? { ...f, content: updatedContent }
                                : f,
                            );
                            setFiles(nf);
                            const fileToUpdate = nf.find((f) => f.id === activeFileId)!;
                            saveFile(activeSessionId!, fileToUpdate);
                          }
                        }}
                        onSave={handleFormatActiveFile}
                        fontFamily={activeFont}
                        fontSize={11}
                        lineHeight={1.5}
                        minimapEnabled={false}
                        ligatures={true}
                        vimMode={false}
                      />
                    </Suspense>
                  </div>
                </div>
              ) : (
                <div className="w-full h-full flex flex-col bg-[#040609]">
                  <div className="h-11 px-3 border-b border-white/[0.04] bg-[#07090c] flex items-center justify-between shrink-0">
                    <span className="text-[11px] font-bold text-zinc-400 flex items-center gap-1.5">
                      <FolderTree size={13} className="text-amber-400" />
                      Workspace File Directory
                    </span>
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <FileExplorer
                      projectId={activeSessionId}
                      files={files}
                      activeFileId={activeFileId}
                      onSelectFile={(f) => {
                        setActiveFileId(f.id);
                      }}
                      onCreateFile={(name, lang) => {
                        const id = "f-" + Math.random().toString(36).substr(2, 9);
                        const newF: FileNode = { id, name, content: "", language: lang, lastModified: Date.now() };
                        setFiles((prev: FileNode[]) => [...prev, newF]);
                        setActiveFileId(newF.id);
                      }}
                      onDeleteFile={(id) => {
                        setFiles((prev: FileNode[]) => prev.filter(f => f.id !== id));
                        if (activeFileId === id) setActiveFileId(null);
                      }}
                      onRenameFile={handleRenameFile}
                      onExport={handleExportProject}
                      onApplyTemplate={handleApplyTemplate}
                      onFilesUpdated={(updated) => setFiles(updated)}
                    />
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {/* E. MOBILE LIVE PREVIEW */}
          {activeTab === 'preview' && (
            <motion.div 
              key="preview"
              initial={{ opacity: 0, scale: 0.99, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.99, y: -8 }}
              className="w-full h-full flex flex-col overflow-hidden relative"
            >
              <div className="absolute top-2.5 left-2.5 z-30 pointer-events-none flex items-center gap-1.5 bg-[#07090c]/85 backdrop-blur-md border border-white/[0.06] px-2.5 py-1 rounded-full shadow-lg">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_rgba(52,211,153,0.5)]" />
                <span className="text-[8px] uppercase font-black tracking-widest text-zinc-200">Runtime active</span>
              </div>

              <Suspense fallback={<SystemLoader message="Mounting virtual preview container..." />}>
                <PreviewPane 
                  files={files} 
                  setFiles={setFiles}
                  autoPilotMode={autoPilotMode}
                  activeSessionId={activeSessionId}
                  onLog={addLog} 
                  onOpenDeploy={() => {}}
                />
              </Suspense>
            </motion.div>
          )}

          {/* F. INTEGRATED TOOLS CLUSTER SHEET */}
          {activeTab === 'tools' && (
            <motion.div 
              key="tools"
              initial={{ opacity: 0, scale: 0.99, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.99, y: -8 }}
              transition={{ type: "spring", stiffness: 420, damping: 28 }}
              className="w-full h-full flex flex-col overflow-hidden p-4"
            >
              <AnimatePresence mode="wait">
                {!activeFeature ? (
                  <motion.div 
                    key="tools-grid"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="w-full h-full flex flex-col overflow-hidden"
                  >
                    {/* Header */}
                    <div className="mb-3 px-1 shrink-0">
                      <h2 className="text-[11px] font-black uppercase tracking-[0.15em] text-zinc-400 flex items-center gap-1.5">
                        <Wrench size={13} className="text-orange-500" />
                        Cluster Console
                      </h2>
                      <p className="text-[9px] text-zinc-500 mt-0.5 leading-relaxed">Integrated diagnostic sub-systems.</p>
                      
                      {/* Search box resembling Apple Settings Search */}
                      <div className="relative mt-3">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-zinc-500">
                          <Search size={12} />
                        </span>
                        <input
                          type="text"
                          value={toolSearchQuery}
                          onChange={(e) => setToolSearchQuery(e.target.value)}
                          placeholder="Search controls..."
                          className="w-full pl-8 pr-8 py-1.5 bg-white/[0.03] hover:bg-white/[0.05] focus:bg-black/50 border border-white/[0.06] rounded-full text-[11px] font-medium placeholder-zinc-500 outline-none transition-all focus:border-orange-500/20"
                        />
                        {toolSearchQuery && (
                          <button 
                            onClick={() => setToolSearchQuery("")}
                            className="absolute inset-y-0 right-0 flex items-center pr-3 text-zinc-400 hover:text-white"
                          >
                            <X size={12} />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* iOS Grouped List-styled Cards */}
                    <div className="flex-1 overflow-y-auto space-y-1.5 pb-6 custom-scrollbar pr-0.5">
                      {filteredFeatures.map((feat) => {
                        const IconComponent = feat.icon;
                        return (
                          <motion.button
                            key={feat.id}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => setActiveFeature(feat.id)}
                            className="w-full text-left p-3 bg-white/[0.02] border border-white/[0.04] active:bg-white/[0.06] rounded-2xl flex items-center gap-3 transition-all cursor-pointer relative overflow-hidden group"
                          >
                            <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 border border-white/[0.05] ${feat.color}`}>
                              <IconComponent size={14} className="stroke-[2.2]" />
                            </div>
                            <div className="min-w-0 flex-1">
                              <h3 className="text-xs font-bold text-zinc-200 tracking-wide flex items-center justify-between">
                                <span>{feat.title}</span>
                              </h3>
                              <p className="text-[9px] text-zinc-500 truncate mt-0.5">{feat.desc}</p>
                            </div>
                            <ChevronLeft size={11} className="rotate-180 text-zinc-600 transition-colors shrink-0 mr-1" />
                          </motion.button>
                        );
                      })}

                      {filteredFeatures.length === 0 && (
                        <div className="py-12 text-center text-[10px] text-zinc-600 font-mono">
                          No diagnostic tools found
                        </div>
                      )}
                    </div>
                  </motion.div>
                ) : (
                  /* Dynamic iOS Sliding Bottom Sheet with grabber bar */
                  <motion.div 
                    key="active-tool-panel"
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 30 }}
                    transition={{ type: "spring", stiffness: 450, damping: 32 }}
                    className="w-full h-full flex flex-col overflow-hidden bg-[#050608] border border-white/[0.08] rounded-[28px] shadow-2xl relative"
                  >
                    {/* iOS grabber bar decoration */}
                    <div className="w-10 h-1 bg-white/10 rounded-full mx-auto mt-2 shrink-0" />

                    {/* Sheet Header */}
                    <div className="h-11 border-b border-white/[0.04] px-4 flex items-center justify-between shrink-0 bg-[#07090d]">
                      <button 
                        onClick={() => {
                          setActiveFeature(null);
                          setToolSearchQuery("");
                        }}
                        className="flex items-center gap-1 text-[11px] text-orange-400 hover:text-orange-300 font-bold active:scale-95 transition-all"
                      >
                        <ChevronLeft size={14} className="stroke-[2.5]" />
                        <span>Tools</span>
                      </button>
                      <h3 className="text-[10px] font-black uppercase tracking-widest text-zinc-400">
                        {featuresList.find(f => f.id === activeFeature)?.title}
                      </h3>
                      <div className="w-10" /> {/* Spacer */}
                    </div>

                    <div className="flex-1 overflow-y-auto custom-scrollbar p-3.5 relative bg-[#020304]">
                      <Suspense fallback={
                        <div className="p-8 text-[9px] font-mono text-zinc-500 text-center flex flex-col items-center justify-center h-full">
                          <div className="w-5 h-5 rounded-full border-2 border-white/5 border-t-orange-500 animate-spin mb-3" />
                          <span className="tracking-widest uppercase">Mounting tool module...</span>
                        </div>
                      }>
                        {activeFeature === 'settings' && (
                          <SettingsView 
                            user={user} 
                            onUpdateUser={onUpdateUser} 
                            onLogout={onLogout} 
                            onNuclearReset={onNuclearReset}
                            onClearAllSessions={onClearAllSessions}
                            onSyncNow={onSyncNow}
                            isSyncing={isSyncing}
                            onClose={() => setActiveFeature(null)}
                          />
                        )}

                        {activeFeature === 'customizer' && (
                          <CustomizerView 
                            user={user} 
                            onUpdateUser={onUpdateUser} 
                            onClose={() => setActiveFeature(null)}
                          />
                        )}

                        {activeFeature === 'terminal' && (
                          <SystemTerminal onClose={() => setActiveFeature(null)} />
                        )}

                        {activeFeature === 'search' && (
                          <SearchView 
                            files={files} 
                            onSelectFile={(id) => { 
                              setActiveFileId(id); 
                              setActiveTab("editor"); 
                              setActiveFeature(null); 
                            }} 
                          />
                        )}

                        {activeFeature === 'database' && (
                          <DatabaseStudio
                            files={files}
                            onAddFileToWorkspace={(newFile) => {
                              setFiles((prev: FileNode[]) => [...prev, newFile]);
                              setActiveFileId(newFile.id);
                              setActiveTab("editor");
                              setActiveFeature(null);
                              addLog("success", `Created database node: ${newFile.name}`, "DATABASE");
                            }}
                          />
                        )}

                        {activeFeature === 'api_playground' && (
                          <ApiPlayground />
                        )}

                        {activeFeature === 'security' && (
                          <SecurityScannerView
                            files={files}
                            onFixIssue={(fileId) => {
                              addLog("info", `Applying security fix to file: ${fileId}`);
                            }}
                            onApplyAIAutoFixAll={() => {
                              addLog("success", "AI Auto-Repair sequence engaged.", "SECURITY");
                            }}
                          />
                        )}

                        {activeFeature === 'uistudio' && (
                          <UIComponentStudio
                            onAddFileToWorkspace={(newFile) => {
                              setFiles((prev: FileNode[]) => [...prev, newFile]);
                              setActiveFileId(newFile.id);
                              setActiveTab("editor");
                              setActiveFeature(null);
                              addLog("success", `Added UI template: ${newFile.name}`, "UI_STUDIO");
                            }}
                          />
                        )}

                        {activeFeature === 'datatransformer' && (
                          <DataTransformerStudio />
                        )}

                        {activeFeature === 'audiosynth' && (
                          <AudioSynthStudio />
                        )}

                        {activeFeature === 'dependencygraph' && (
                          <DependencyGraphStudio files={files} />
                        )}

                        {activeFeature === 'profiler' && (
                          <PerformanceProfiler files={files} />
                        )}

                        {activeFeature === 'evolution' && (
                          <EvolutionCore
                            files={files}
                            setFiles={setFiles}
                            activeFileId={activeFileId}
                            setActiveFileId={setActiveFileId}
                            activeSessionId={activeSessionId}
                            addLog={addLog}
                            onClose={() => setActiveFeature(null)}
                          />
                        )}

                        {activeFeature === 'tasks' && (
                          <div className="h-full flex flex-col">
                            <TaskRunnerView sessionId={activeSessionId} files={files} addLog={addLog} />
                          </div>
                        )}

                        {activeFeature === 'history' && (
                          <FileHistoryView 
                            activeFileId={activeFileId} 
                            files={files} 
                            onFilesUpdated={setFiles} 
                            sessionId={activeSessionId} 
                            addLog={addLog} 
                          />
                        )}

                        {activeFeature === 'linux' && (
                          <LinuxSystemStudio onClose={() => setActiveFeature(null)} />
                        )}
                      </Suspense>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* 3. Floating Frosted iOS dock with glass shadow styling */}
      <nav id="mobile-bottom-nav" className="h-16 bg-[#08090c]/80 border-t border-white/[0.04] backdrop-blur-3xl flex items-center justify-around px-3 shrink-0 pb-safe z-50 shadow-[0_-5px_30px_rgba(0,0,0,0.6)]">
        {[
          { id: 'dashboard', label: 'HUB', icon: LayoutGrid },
          { id: 'assistant', label: 'Assistant', icon: Bot },
          { id: 'editor', label: 'Editor', icon: Code2 },
          { id: 'preview', label: 'Preview', icon: Eye }
        ].filter((tab) => {
          if (!activeSessionId && ['assistant', 'editor', 'preview'].includes(tab.id)) {
            return false;
          }
          return true;
        }).map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id as any);
                setActiveFeature(null);
              }}
              className="flex flex-col items-center justify-center gap-1 w-13 h-12 rounded-2xl relative transition-all duration-200 cursor-pointer"
            >
              {isActive && (
                <motion.div 
                  layoutId="mobileTabActive"
                  className="absolute inset-0 bg-gradient-to-tr from-orange-500/10 to-amber-500/5 border border-white/[0.04] rounded-2xl shadow-sm"
                  transition={{ type: 'spring', bounce: 0.1, duration: 0.4 }}
                />
              )}
              
              <tab.icon 
                size={15} 
                className={`relative z-10 transition-all duration-200 ${
                  isActive ? "text-orange-400 scale-105" : "text-zinc-500 hover:text-zinc-300"
                }`}
                style={{
                  filter: isActive ? "drop-shadow(0 0 6px rgba(249,115,22,0.3))" : undefined
                }}
              />
              <span 
                className={`text-[9px] font-bold relative z-10 tracking-wide transition-colors duration-200 ${
                  isActive ? "text-orange-400 font-extrabold" : "text-zinc-500"
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </nav>
    </div>
  );
};

export default MobileWorkspace;
