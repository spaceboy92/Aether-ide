
import React, { useState } from 'react';
import { X, Globe, Link, Check, Shield, Users, Lock, ChevronRight, Share2, Mail, Twitter, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  sessionTitle: string;
  shareUrl: string;
}

const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose, sessionTitle, shareUrl }) => {
  const [copied, setCopied] = useState(false);
  const [access, setAccess] = useState<'private' | 'public'>('private');

  const handleCopy = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <motion.div 
          initial={{ opacity: 0, scale: 0.9, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.9, y: 20 }}
          className="bg-[#0f0f0f] border border-white/10 rounded-2xl w-full max-w-md overflow-hidden shadow-[0_0_50px_rgba(0,0,0,0.5)]"
        >
          {/* Header */}
          <div className="p-6 border-b border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-aether-accent/10 flex items-center justify-center text-aether-accent">
                <Share2 size={20} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white tracking-tight">Neural Share</h3>
                <p className="text-xs text-aether-muted">Distribute synapse: {sessionTitle}</p>
              </div>
            </div>
            <button onClick={onClose} className="text-aether-muted hover:text-white transition-colors">
              <X size={20} />
            </button>
          </div>

          {/* Content */}
          <div className="p-6 space-y-6">
            {/* Access Control */}
            <div className="space-y-3">
              <label className="text-[10px] uppercase tracking-[0.2em] font-bold text-aether-muted">Access Level</label>
              <div className="grid grid-cols-2 gap-3">
                <button 
                  onClick={() => setAccess('private')}
                  className={`p-4 rounded-xl border transition-all text-left ${access === 'private' ? 'bg-aether-accent/5 border-aether-accent text-white' : 'bg-white/5 border-white/5 text-aether-muted hover:bg-white/10'}`}
                >
                  <Lock size={18} className={access === 'private' ? 'text-aether-accent' : ''} />
                  <div className="mt-2 font-bold text-sm">Restricted</div>
                  <div className="text-[10px] opacity-70">Only you can view</div>
                </button>
                <button 
                  onClick={() => setAccess('public')}
                  className={`p-4 rounded-xl border transition-all text-left ${access === 'public' ? 'bg-aether-accent/5 border-aether-accent text-white' : 'bg-white/5 border-white/5 text-aether-muted hover:bg-white/10'}`}
                >
                  <Globe size={18} className={access === 'public' ? 'text-aether-accent' : ''} />
                  <div className="mt-2 font-bold text-sm">Public Node</div>
                  <div className="text-[10px] opacity-70">Anyone with the link</div>
                </button>
              </div>
            </div>

            {/* Link Box */}
            <div className="space-y-3">
              <label className="text-[10px] uppercase tracking-[0.2em] font-bold text-aether-muted">Neural Link</label>
              <div className="flex gap-2">
                <div className="flex-1 bg-black/50 border border-white/10 rounded-xl p-3 text-xs text-aether-muted truncate font-mono">
                  {shareUrl}
                </div>
                <button 
                  onClick={handleCopy}
                  className="px-4 bg-aether-accent text-black font-bold rounded-xl hover:opacity-90 transition-all active:scale-95 flex items-center justify-center min-w-[80px]"
                >
                  {copied ? <Check size={18} /> : 'Copy'}
                </button>
              </div>
            </div>

            {/* Social / Quick Share */}
            <div className="flex items-center justify-between pt-2">
              <div className="flex gap-4">
                <button className="text-aether-muted hover:text-white transition-colors"><Twitter size={18} /></button>
                <button className="text-aether-muted hover:text-white transition-colors"><Mail size={18} /></button>
              </div>
              <div className="flex items-center gap-1 text-[10px] text-aether-muted italic">
                <Shield size={10} />
                <span>Encrypted transit active</span>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="p-4 bg-white/5 flex items-center justify-center gap-2">
            <Sparkles size={14} className="text-aether-accent animate-pulse" />
            <p className="text-[10px] text-aether-muted tracking-widest font-bold">AETHER NETWORK STATUS: NOMINAL</p>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default ShareModal;
