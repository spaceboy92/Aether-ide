import React, { Suspense } from "react";
import { X, Folder, Search, Layers, Settings, Activity, ShoppingBag, Cpu, CloudUpload, TrendingUp, Globe, ShieldCheck, Database, Wand2, Gauge, Palette, Volume2, Network } from "lucide-react";
import SystemLoader from "../UI/SystemLoader";
import { motion, AnimatePresence } from "motion/react";

interface ResponsiveSidebarProps {
  sidebarMode: string | null;
  setSidebarMode: (mode: any) => void;
  activeSessionId?: string | null;
  children?: React.ReactNode;
  title?: string;
}

const sidebarConfig: Record<string, { title: string; icon: any; width: string }> = {
  files: { title: "Files", icon: Folder, width: "md:w-[280px] max-w-[90vw]" },
  search: { title: "Global Search", icon: Search, width: "md:w-[320px] max-w-[90vw]" },
  api_playground: { title: "REST API Playground", icon: Globe, width: "md:w-[720px] max-w-[95vw]" },
  security: { title: "Security & AI Auditor", icon: ShieldCheck, width: "md:w-[680px] max-w-[95vw]" },
  database: { title: "Database & Storage Studio", icon: Database, width: "md:w-[680px] max-w-[95vw]" },
  datatransformer: { title: "RegEx & Transformer", icon: Wand2, width: "md:w-[680px] max-w-[95vw]" },
  uistudio: { title: "UI Component & Theme Studio", icon: Palette, width: "md:w-[760px] max-w-[95vw]" },
  audiosynth: { title: "Web Audio Sound FX Studio", icon: Volume2, width: "md:w-[680px] max-w-[95vw]" },
  dependencygraph: { title: "Code Architecture Visualizer", icon: Network, width: "md:w-[720px] max-w-[95vw]" },
  profiler: { title: "Performance Profiler", icon: Gauge, width: "md:w-[620px] max-w-[95vw]" },
  health: { title: "System Health", icon: Activity, width: "md:w-[320px] max-w-[90vw]" },
  marketplace: { title: "Marketplace", icon: ShoppingBag, width: "md:w-[400px] max-w-[90vw]" },
  evolution: { title: "Evolution Engine", icon: Cpu, width: "md:w-[600px] max-w-[90vw]" },
  deployment: { title: "Deployment", icon: CloudUpload, width: "md:w-[400px] max-w-[90vw]" },
  analytics: { title: "Analytics", icon: TrendingUp, width: "md:w-[400px] max-w-[90vw]" },
  pitchstudio: { title: "Investor Pitch & ROI Simulator", icon: TrendingUp, width: "md:w-[840px] max-w-[95vw]" },
  architect: { title: "AI Enterprise Architect", icon: Network, width: "md:w-[800px] max-w-[95vw]" },
  settings: { title: "Settings", icon: Settings, width: "md:w-[480px] max-w-[95vw]" },
  customizer: { title: "Customization", icon: Layers, width: "md:w-[480px] max-w-[95vw]" },
};

const ResponsiveSidebar: React.FC<ResponsiveSidebarProps> = ({
  sidebarMode,
  setSidebarMode,
  activeSessionId,
  children,
  title,
}) => {
  const config = sidebarMode ? (sidebarConfig[sidebarMode] || { title: "Info", icon: Layers, width: "md:w-[320px] max-w-[90vw]" }) : null;

  return (
    <AnimatePresence>
      {sidebarMode && config && (
        <motion.div 
          initial={{ x: -400, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: -400, opacity: 0 }}
          transition={{ type: "spring", stiffness: 350, damping: 30 }}
          className={`absolute inset-y-0 left-0 w-full ${config.width} md:relative macos-glass-panel my-2 ml-2 rounded-3xl border border-white/10 z-40 flex flex-col shadow-2xl overflow-hidden`}
        >
          <div className="h-12 flex items-center justify-between px-6 border-b border-white/10 shrink-0 bg-white/[0.02] backdrop-blur-xl">
            <div className="flex items-center gap-2.5">
              {config.icon && <config.icon size={15} className="text-cyan-400" />}
              <span className="text-[11px] font-bold text-white uppercase tracking-wider">
                {config.title}
              </span>
            </div>
            <button
              onClick={() => setSidebarMode(null)}
              className="p-1.5 rounded-full text-white/40 hover:text-white hover:bg-white/10 transition-all cursor-pointer"
              title="Close Panel"
            >
              <X size={14} />
            </button>
          </div>
          <div className="flex-1 flex flex-col min-h-0 relative pb-[calc(5rem+env(safe-area-inset-bottom))] md:pb-0 overflow-y-auto custom-scrollbar">
            <Suspense fallback={<SystemLoader message={`LOADING ${config.title.toUpperCase()}...`} />}>
              {children}
            </Suspense>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ResponsiveSidebar;
