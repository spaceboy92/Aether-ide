import React, { useState, useEffect, useMemo, Suspense, lazy, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  FileNode, 
  ChatSession, 
  AgentAction 
} from "../../types";
import { storageService } from "../../services/storageService";
const { saveFile, deleteFile } = storageService;
import { 
  FolderOpen, 
  HelpCircle, 
  Code2, 
  Wand2, 
  Zap, 
  Activity,
  Compass,
  Cpu,
  RefreshCw,
  BookOpen,
  LayoutGrid,
  PanelLeft,
  PanelLeftClose,
  PanelRight,
  PanelRightClose,
  X,
  Settings2,
  Minimize2,
  Wind,
  CloudLightning,
  ChevronLeft,
  ChevronRight,
  Sliders,
  SlidersHorizontal,
  Keyboard,
  Music,
  Gamepad2,
  Plus,
  Play,
  RotateCcw,
  Settings,
  Eye,
  ChevronDown,
  Terminal,
  Bot,
  Cloud,
  BarChart3,
  Layers,
  Maximize2,
  Sparkles,
  Laptop,
  GripVertical,
  GripHorizontal,
  SplitSquareHorizontal,
  SplitSquareVertical,
  Columns,
  Square,
  ZoomIn,
  ZoomOut,
  Palette,
  Check,
  Camera,
  Scissors
} from "lucide-react";
import MainHeader from "./MainHeader";
import { 
  WorkspaceConfig, 
  DEFAULT_WORKSPACE_CONFIG,
  ACCENT_PALETTES 
} from "./WorkspaceSlidersModal";
const WorkspaceSlidersModal = lazy(() => import("./WorkspaceSlidersModal").then(m => ({ default: m.WorkspaceSlidersModal })));

import FileExplorer from "../Files/FileExplorer";
import MonacoEditorWrapper from "../Editor/MonacoEditorWrapper";
import CursorOverlay from "../Editor/CursorOverlay";
import { socketService } from "../../services/socketService";
import { multiplayerService } from "../../services/multiplayerService";
import { PreviewPane } from "../Preview/PreviewPane";
import AIAssistant from "../AI/AIAssistant";

// Lazy-loaded secondary subcomponents for layout columns
const SearchView = lazy(() => import("../Files/SearchView"));
const SettingsView = lazy(() => import("../Settings/SettingsView"));
const ExtensionsView = lazy(() => import("../Settings/ExtensionsView"));
const CustomizerView = lazy(() => import("../Settings/CustomizerView"));
const FileHistoryView = lazy(() => import("../Files/FileHistoryView"));
const SystemTerminal = lazy(() => import("../Tools/SystemTerminal"));
const BlackholeCanvas = lazy(() => import("../Tools/BlackholeCanvas"));
const LinuxSystemStudio = lazy(() => import("../Tools/LinuxSystemStudio"));
const ImageAssetViewer = lazy(() => import("../Editor/ImageAssetViewer").then(m => ({ default: m.ImageAssetViewer })));
const Studio3DGameEngine = lazy(() => import("../Studio/Studio3DGameEngine").then(m => ({ default: m.Studio3DGameEngine })));
const MasterpieceUI = lazy(() => import("../Studio/MasterpieceUI"));
const AppGallery = lazy(() => import("../Gallery/AppGallery"));
const EvolutionCore = lazy(() => import("../Tools/EvolutionCore").then(m => ({ default: m.EvolutionCore })));
const ResourceDashboard = lazy(() => import("../UI/ResourceDashboard"));
const EnvironmentPanel = lazy(() => import("../UI/EnvironmentPanel").then(m => ({ default: m.EnvironmentPanel })));
import SystemLoader from "../UI/SystemLoader";
import { terminalService } from "../../services/terminalService";
import ActivityBar from "./ActivityBar";
import { formatterService } from "../../services/formatterService";
const TaskRunnerView = lazy(() => import("../Tools/TaskRunnerView").then(m => ({ default: m.TaskRunnerView })));
const ApiPlayground = lazy(() => import("../Tools/ApiPlayground"));
const SecurityScannerView = lazy(() => import("../Tools/SecurityScannerView"));
const DatabaseStudio = lazy(() => import("../Tools/DatabaseStudio"));
const DataTransformerStudio = lazy(() => import("../Tools/DataTransformerStudio"));
const UIComponentStudio = lazy(() => import("../Tools/UIComponentStudio"));
const AudioSynthStudio = lazy(() => import("../Tools/AudioSynthStudio"));
const DependencyGraphStudio = lazy(() => import("../Tools/DependencyGraphStudio"));
const JWTDecoder = lazy(() => import("../Tools/JWTDecoder").then(m => ({ default: m.JWTDecoder })));
const EnvManager = lazy(() => import("../Tools/EnvManager").then(m => ({ default: m.EnvManager })));
const CommandPalette = lazy(() => import("../CommandPalette/CommandPalette").then(m => ({ default: m.CommandPalette })));
const PerformanceProfiler = lazy(() => import("../Tools/PerformanceProfiler"));
const GitHubSyncModal = lazy(() => import("../Tools/GitHubSyncModal").then(m => ({ default: m.GitHubSyncModal })));
const DeployModal = lazy(() => import("../Tools/DeployModal").then(m => ({ default: m.DeployModal })));
const CollaborationModal = lazy(() => import("../Tools/CollaborationModal").then(m => ({ default: m.CollaborationModal })));
const MoatInspectorModal = lazy(() => import("../Tools/MoatInspectorModal").then(m => ({ default: m.MoatInspectorModal })));
const ExtensionMarketplaceModal = lazy(() => import("../Tools/ExtensionMarketplaceModal").then(m => ({ default: m.ExtensionMarketplaceModal })));
const VisualDebuggerPanel = lazy(() => import("../Tools/VisualDebuggerPanel").then(m => ({ default: m.VisualDebuggerPanel })));
const LinuxSandboxControlPanel = lazy(() => import("../Tools/LinuxSandboxControlPanel").then(m => ({ default: m.LinuxSandboxControlPanel })));

interface GameTemplate {
  id: string;
  name: string;
  tag: string;
  icon: any;
  description: string;
  prompt: string;
}

const MODERN_GAME_TEMPLATES: GameTemplate[] = [
  { 
    id: 'plasma-orbit', 
    name: 'Plasma Orbit Engine', 
    tag: 'Web GL', 
    icon: Zap,
    description: 'High-performance particle system with relativistic gravity effects.',
    prompt: 'Create a high-performance WebGL particle system featuring a central gravitational attractor. Implement velocity-based color shifting (blueshift/redshift) and high-density glow effects using canvas compositing.'
  },
  { 
    id: 'cyber-synth', 
    name: 'Cyber Synth UI', 
    tag: 'React', 
    icon: Music,
    description: 'Neon-infused layout with reactive audio visualizers.',
    prompt: 'Design a futuristic dashboard with neon accents. Include a real-time audio visualizer component that reacts to system sounds or mic input using the Web Audio API.'
  },
  { 
    id: 'neural-flow', 
    name: 'Neural Flow', 
    tag: 'Canvas', 
    icon: Wand2,
    description: 'Organic, generative abstract shapes that flow with user interaction.',
    prompt: 'Implement a generative art canvas that creates flowing, organic bezier curves. The curves should avoid the mouse cursor and transition through a sunset color palette.'
  }
];

interface PCWorkspaceProps {
  user: any;
  files: FileNode[];
  setFiles: any;
  activeFileId: string | null;
  setActiveFileId: (id: string | null) => void;
  activeSessionId: string | null;
  setActiveSessionId: (id: string | null) => void;
  sessions: ChatSession[];
  setSessions: any;
  isProcessing: boolean;
  isSyncing: boolean;
  connectionStatus: "online" | "offline";
  googleDriveConnected: boolean;
  activeUsers: any[];
  systemStats: any;
  activeFont: string;
  minimapEnabled: boolean;
  perfMode: 'high' | 'low';
  onTogglePerfMode: () => void;
  chatCompactMode: boolean;
  onToggleChatCompact: () => void;
  onOptimizeMemory: () => void;
  autoPilotMode?: boolean;
  setAutoPilotMode?: (val: boolean) => void;
  addLog: (type: any, msg: string, source?: string) => void;
  handleRenameFile: (id: string, name: string) => void;
  handleExportProject: () => void;
  handleApplyTemplate: (type: string) => void;
  handleAgentAction: any;
  handleUploadFiles: (files: any) => void;
  createNewSession: any;
  handleDeleteSession: (id: string) => void;
  handleRenameSession?: (id: string, newTitle: string) => void;
  sendMessage: (msg: string, attachments?: { mimeType: string, data: string }[], modelId?: string, isCompactMode?: boolean) => void;
  stopProcessing: () => void;
  autoSave: any;
  handleCommandPaletteSelect: (cmdId: string, payload?: any) => void;
  focusMode: boolean;
  setFocusMode: (val: boolean) => void;
  zenMode: boolean;
  setZenMode: (val: boolean) => void;
  onOpenHealth: () => void;
  onOpenSettings: () => void;
  sidebarMode: any;
  setSidebarMode: (mode: any) => void;
  onUpdateUser: (user: any) => void;
  onLogout: () => void;
  onNuclearReset: () => void;
  onClearAllSessions: () => void;
  onSyncNow: () => void;
}

const PCWorkspace: React.FC<PCWorkspaceProps> = ({
  user,
  files,
  setFiles,
  activeFileId,
  setActiveFileId,
  activeSessionId,
  setActiveSessionId,
  sessions,
  setSessions,
  isProcessing,
  isSyncing,
  connectionStatus,
  googleDriveConnected,
  activeUsers,
  systemStats,
  activeFont,
  minimapEnabled,
  perfMode,
  onTogglePerfMode,
  chatCompactMode,
  onToggleChatCompact,
  onOptimizeMemory,
  autoPilotMode = true,
  setAutoPilotMode,
  addLog,
  handleRenameFile,
  handleExportProject,
  handleApplyTemplate,
  handleAgentAction,
  handleUploadFiles,
  createNewSession,
  handleDeleteSession,
  handleRenameSession,
  sendMessage,
  stopProcessing,
  autoSave,
  handleCommandPaletteSelect,
  focusMode,
  setFocusMode,
  zenMode,
  setZenMode,
  onOpenHealth,
  onOpenSettings,
  sidebarMode,
  setSidebarMode,
  onUpdateUser,
  onLogout,
  onNuclearReset,
  onClearAllSessions,
  onSyncNow,
}) => {
  // Load workspace configuration from localStorage
  const [config, setConfig] = useState<WorkspaceConfig>(() => {
    try {
      const saved = localStorage.getItem("aether_pc_workspace_config");
      if (saved) {
        return { ...DEFAULT_WORKSPACE_CONFIG, ...JSON.parse(saved) };
      }
    } catch (e) {
      console.warn("Failed to load workspace config from storage", e);
    }
    return DEFAULT_WORKSPACE_CONFIG;
  });

  // Auto-save configuration changes
  const updateConfig = useCallback((newConfig: WorkspaceConfig) => {
    setConfig(newConfig);
    try {
      localStorage.setItem("aether_pc_workspace_config", JSON.stringify(newConfig));
    } catch (e) {
      console.warn("Failed to save workspace config", e);
    }
  }, []);

  const handleResetDefaults = () => {
    updateConfig(DEFAULT_WORKSPACE_CONFIG);
    addLog("info", "Workspace sliders and layout configuration reset to defaults.", "WORKSPACE");
  };

  // Collapsing states
  const [sidebarOpen, setSidebarOpen] = useState(!focusMode && (typeof window === 'undefined' || window.innerWidth >= 1024));
  const [chatOpen, setChatOpen] = useState(!focusMode && (typeof window === 'undefined' || window.innerWidth >= 1024));
  const [terminalOpen, setTerminalOpen] = useState(false);
  const [envOpen, setEnvOpen] = useState(false);
  const [showHealth, setShowHealth] = useState(false);
  const [showSlidersModal, setShowSlidersModal] = useState(false);
  const [showQuickSlidersPopover, setShowQuickSlidersPopover] = useState(false);

  // Pro / Sticky Workflows & Moat Modals
  const [showGitHubModal, setShowGitHubModal] = useState(false);
  const [showDeployModal, setShowDeployModal] = useState(false);
  const [showCollaborationModal, setShowCollaborationModal] = useState(false);
  const [showMoatModal, setShowMoatModal] = useState(false);
  const [showCommandPalette, setShowCommandPalette] = useState(false);
  const [showExtensionMarketplace, setShowExtensionMarketplace] = useState(false);
  const [showVisualDebugger, setShowVisualDebugger] = useState(false);
  const [showLinuxSandbox, setShowLinuxSandbox] = useState(false);
  const [fileBreakpoints, setFileBreakpoints] = useState<Record<string, number[]>>({});

  // ==========================================
  // REAL-TIME COLLABORATIVE SYNCING MODULE
  // ==========================================
  const [collaboratorCursors, setCollaboratorCursors] = useState<any[]>([]);

  useEffect(() => {
    socketService.connect();
    
    if (activeSessionId && user) {
      socketService.joinSession(activeSessionId);
      socketService.registerUser({
        id: user.uid || user.id || "anonymous",
        name: user.displayName || user.name || "Collaborator",
        photoURL: user.photoURL || ""
      });
    }

    // Capture other users' live cursors
    socketService.onCursor((data) => {
      const roomInstance = multiplayerService.getRoom();
      const peersList = roomInstance ? roomInstance.peers : [];
      const peer = peersList.find(p => p.id === data.userId || p.id === `peer_${data.userId}`);
      const name = peer ? peer.name : `Collaborator ${String(data.userId).substring(0, 4)}`;
      const color = peer ? peer.color : "#9333EA";

      setCollaboratorCursors(prev => {
        const filtered = prev.filter(c => c.userId !== data.userId);
        return [...filtered, {
          userId: data.userId,
          userName: name,
          position: data.position,
          color: color
        }];
      });
    });

    return () => {
      socketService.off('user-cursor-moved');
    };
  }, [activeSessionId, user]);

  const handleEditorMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!activeSessionId || !user) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const lastEmit = (window as any).__last_cursor_emit || 0;
    const now = Date.now();
    if (now - lastEmit > 40) { // 40ms throttling provides silky smooth 25 FPS tracking
      (window as any).__last_cursor_emit = now;
      socketService.emitCursor(
        activeSessionId,
        user.uid || user.id || "anonymous",
        { x, y }
      );
    }
  };

  const handleSelectPaletteCommand = (commandId: string, payload?: any) => {
    if (commandId === 'open-chat') {
      setChatOpen(true);
    } else if (commandId === 'open-evolution') {
      setSidebarMode('evolution');
      setSidebarOpen(true);
    } else if (commandId === 'open-tasks') {
      setSidebarMode('tasks');
      setSidebarOpen(true);
    } else if (commandId === 'open-security') {
      setSidebarMode('security');
      setSidebarOpen(true);
    } else if (commandId === 'open-profiler') {
      setSidebarMode('profiler');
      setSidebarOpen(true);
    } else if (commandId === 'open-history') {
      setSidebarMode('history');
      setSidebarOpen(true);
    } else if (commandId === 'open-database') {
      setSidebarMode('database');
      setSidebarOpen(true);
    } else if (commandId === 'open-uistudio') {
      setSidebarMode('uistudio');
      setSidebarOpen(true);
    } else if (commandId === 'open-audiosynth') {
      setSidebarMode('audiosynth');
      setSidebarOpen(true);
    } else if (commandId === 'open-dependencygraph') {
      setSidebarMode('dependencygraph');
      setSidebarOpen(true);
    } else if (commandId === 'open-api-playground') {
      setSidebarMode('api_playground');
      setSidebarOpen(true);
    } else if (commandId === 'open-datatransformer') {
      setSidebarMode('datatransformer');
      setSidebarOpen(true);
    } else if (commandId === 'open-files') {
      setSidebarMode('files');
      setSidebarOpen(true);
    } else if (commandId === 'open-search') {
      setSidebarMode('search');
      setSidebarOpen(true);
    } else if (commandId === 'toggle-terminal') {
      setTerminalOpen(prev => !prev);
    } else if (commandId === 'open-settings') {
      setSidebarMode('settings');
      setSidebarOpen(true);
    } else if (commandId === 'toggle-sidebar') {
      setSidebarOpen(prev => !prev);
    } else if (commandId === 'deploy-app' || commandId === 'deploy') {
      setShowDeployModal(true);
    } else if (commandId === 'format-doc') {
      handleFormatActiveFile();
    } else if (commandId === 'install-package') {
      setTerminalOpen(true);
      const pkg = prompt("Enter package name to install (e.g. lodash, lucide-react):");
      if (pkg) {
        window.dispatchEvent(new CustomEvent("aether_run_terminal_cmd", { detail: `npm install ${pkg}` }));
      }
    } else if (commandId === 'run-doctor') {
      setTerminalOpen(true);
      window.dispatchEvent(new CustomEvent("aether_run_terminal_cmd", { detail: "aether doctor" }));
    } else if (commandId === 'create-rust-file') {
      const rustStarter = `// Rust Native Program\nfn main() {\n    println!("Hello from Aether IDE Rust Native Runner!");\n    let numbers = vec![1, 2, 3, 4, 5];\n    let sum: i32 = numbers.iter().sum();\n    println!("Sum of numbers: {}", sum);\n}\n`;
      const newFileId = `f_rust_${Date.now()}`;
      const newRustFile: FileNode = {
        id: newFileId,
        name: "main.rs",
        language: "rust",
        content: rustStarter,
        lastModified: Date.now()
      };
      setFiles(prev => [...prev.filter(f => f.name !== "main.rs"), newRustFile]);
      setActiveFileId(newFileId);
      setActiveRightTab("editor");
      addLog("success", "Created and opened main.rs with Rust support.");
    } else if (commandId === 'export-zip') {
      handleExportProject();
    } else if (commandId === 'open-marketplace' || commandId === 'open-extensions') {
      setSidebarMode('extensions');
      setSidebarOpen(true);
    } else if (commandId === 'clear-chat') {
      if (activeSessionId) {
        const curr = sessions.find(s => s.id === activeSessionId);
        if (curr) {
          setSessions(prev => prev.map(s => s.id === activeSessionId ? { ...s, messages: [] } : s));
          addLog("system", "Session chat messages cleared.");
        }
      }
    } else if (commandId === 'open-3d-engine') {
      setActiveRightTab("preview");
      addLog("info", "Mounted 3D Studio Engine Viewport.");
    } else if (commandId === 'new-file') {
      const id = "f-" + Math.random().toString(36).substr(2, 9);
      const newFile: FileNode = {
        id,
        name: "UntitledComponent.tsx",
        content: "// New Component File\nimport React from 'react';\n\nexport default function UntitledComponent() {\n  return <div>Component</div>;\n}\n",
        language: "typescript",
        lastModified: Date.now(),
      };
      setFiles(prev => [...prev, newFile]);
      setActiveFileId(id);
      setActiveRightTab("editor");
    } else if (commandId.startsWith('open-file-')) {
      const fileName = payload || commandId.replace('open-file-', '');
      const matched = files.find(f => f.name === fileName);
      if (matched) {
        setActiveFileId(matched.id);
        setActiveRightTab('editor');
      }
    }
  };
  
  // Workspace tabs: dashboard, editor, preview, gallery, split
  const [activeRightTab, setActiveRightTab] = useState<"dashboard" | "editor" | "preview" | "gallery" | "split">("dashboard");
  const [splitSubTab, setSplitSubTab] = useState<"preview" | "game">("preview");

  // Web-related files check: Preview tab only shows when web files are present
  const hasWebFiles = useMemo(() => {
    if (!files || files.length === 0) return true;
    return files.some((f) => {
      const name = f.name.toLowerCase();
      const ext = name.split('.').pop() || '';
      if (['html', 'htm', 'jsx', 'tsx', 'vue', 'svelte', 'css', 'scss', 'js', 'ts'].includes(ext)) {
        return true;
      }
      const content = (f.content || "").toLowerCase();
      return content.includes('<html') || content.includes('<div') || content.includes('react') || content.includes('vite') || content.includes('express');
    });
  }, [files]);

  useEffect(() => {
    if (!hasWebFiles && (activeRightTab === "preview" || activeRightTab === "split")) {
      setActiveRightTab("editor");
    }
  }, [hasWebFiles, activeRightTab]);

  useEffect(() => {
    if (!activeSessionId) {
      setActiveRightTab("dashboard");
      setChatOpen(false);
      setSidebarOpen(false);
    } else {
      setActiveRightTab((prev) => (prev === "dashboard" ? "editor" : prev));
      setChatOpen(true);
      setSidebarOpen(true);
    }
  }, [activeSessionId]);

  // Dragging / Resizing states
  const [isResizingSidebar, setIsResizingSidebar] = useState(false);
  const [isResizingChat, setIsResizingChat] = useState(false);
  const [isResizingSplit, setIsResizingSplit] = useState(false);
  const [isResizingTerminal, setIsResizingTerminal] = useState(false);

  // Template draft & context prompt
  const [selectedTemplateDraft, setSelectedTemplateDraft] = useState<string | null>(null);
  const [injectedContextPrompt, setInjectedContextPrompt] = useState("");

  const centerAreaRef = useRef<HTMLDivElement>(null);

  const handleLaunchGalleryApp = async (app: any) => {
    const seedFiles = app.files.map((file: any) => ({
      id: "f-" + Math.random().toString(36).substr(2, 9),
      name: file.name,
      content: file.content,
      language: file.language,
      lastModified: Date.now(),
    }));
    await createNewSession({ title: app.title }, seedFiles);
    setActiveRightTab("preview");
    setChatOpen(true);
    addLog("success", `Successfully launched ${app.title} from App Gallery.`);
  };

  useEffect(() => {
    if (focusMode) {
      setSidebarOpen(false);
      setChatOpen(false);
    } else {
      setSidebarOpen(true);
      setChatOpen(true);
    }
  }, [focusMode]);

  useEffect(() => {
    if (sidebarOpen && !sidebarMode) {
      setSidebarMode('files');
    }
  }, [sidebarOpen, sidebarMode, setSidebarMode]);

  const activeFile = files.find((f) => f.id === activeFileId);

  const getFileLengthMeta = () => {
    if (!activeFile) return "No Buffers Mounted";
    const lineCount = activeFile.content.split("\n").length;
    const charCount = activeFile.content.length;
    return `${lineCount} lines · ${charCount} chars`;
  };

  const handleFormatActiveFile = async (currentVal?: string) => {
    if (!activeFileId || !activeFile) return;
    addLog("info", `Formatting active buffer: ${activeFile.name}...`, "EDITOR");
    try {
      const codeToFormat = currentVal !== undefined ? currentVal : activeFile.content;
      const formatted = await formatterService.formatFile(codeToFormat, activeFile.language);
      
      const nf = files.map((f) =>
        f.id === activeFileId
          ? { ...f, content: formatted }
          : f
      );
      setFiles(nf);
      
      await saveFile(activeSessionId!, { ...activeFile, content: formatted });
      addLog("success", `Successfully formatted and saved ${activeFile.name}`, "EDITOR");
    } catch (err: any) {
      addLog("error", `Formatting failed: ${err.message || err}`, "EDITOR");
    }
  };

  const handleApplyPresetTemplate = (tmpl: GameTemplate) => {
    setSelectedTemplateDraft(tmpl.id);
    setInjectedContextPrompt(tmpl.prompt);
    navigator.clipboard.writeText(tmpl.prompt);
    addLog("success", `Modern Code Generator targeted: "${tmpl.name}". Parameter seeds appended automatically!`, "STUDIO");
  };

  // Keyboard Shortcuts & Global Mouse Move Resizing Engine
  useEffect(() => {
    const handleCustomEvents = (e: any) => {
      if (e.type === 'aether_run_terminal_cmd') {
        const cmd = e.detail;
        if (cmd) {
          setTerminalOpen(true);
          terminalService.executeCommand(cmd);
        }
      } else if (e.type === 'aether-open-chat') {
        setChatOpen(true);
      }
    };

    window.addEventListener('aether_run_terminal_cmd', handleCustomEvents);
    window.addEventListener('aether-open-chat', handleCustomEvents);

    const handleShortcuts = (e: KeyboardEvent) => {
      const isInput = ['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName) || (e.target as HTMLElement)?.isContentEditable;

      // Command Palette: Cmd+K or Cmd+P or Ctrl+K or Ctrl+P
      if ((e.ctrlKey || e.metaKey) && (e.key.toLowerCase() === "k" || e.key.toLowerCase() === "p")) {
        e.preventDefault();
        setShowCommandPalette(prev => !prev);
      }

      // Open Extensions: Ctrl + Shift + X
      if (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === "x") {
        e.preventDefault();
        setSidebarMode('extensions');
        setSidebarOpen(true);
      }

      // Toggle File Explorer: Ctrl + B or Alt + Shift + F
      if ((e.altKey && e.shiftKey && e.key.toLowerCase() === "f") || (!isInput && (e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "b")) {
        e.preventDefault();
        setSidebarOpen(prev => !prev);
      }
      // Toggle Chat: Alt + Shift + C or Ctrl + Shift + C
      if ((e.altKey && e.shiftKey && e.key.toLowerCase() === "c") || ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === "c")) {
        e.preventDefault();
        setChatOpen(prev => !prev);
      }
      // Toggle Terminal: Alt + Shift + T or Ctrl + ` or Ctrl + Shift + T
      if ((e.altKey && e.shiftKey && e.key.toLowerCase() === "t") || ((e.ctrlKey || e.metaKey) && (e.key === "`" || (e.shiftKey && e.key.toLowerCase() === "t")))) {
        e.preventDefault();
        setTerminalOpen(prev => !prev);
      }
      // Toggle Sliders Modal: Alt + Shift + S or Ctrl + Shift + M
      if ((e.altKey && e.shiftKey && e.key.toLowerCase() === "s") || ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === "m")) {
        e.preventDefault();
        setShowSlidersModal(prev => !prev);
      }
      // Toggle Zen Mode: Ctrl + Shift + Z
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === "z") {
        e.preventDefault();
        setZenMode(!zenMode);
      }
      // Escape to dismiss open overlays
      if (e.key === "Escape") {
        setShowHealth(false);
        setShowSlidersModal(false);
        setShowQuickSlidersPopover(false);
      }
    };
    
    const handleMouseMove = (e: MouseEvent) => {
      // 1. Resizing Sidebar (Left)
      if (isResizingSidebar) {
        const activityBarWidth = config.showActivityBar ? 48 : 0;
        const newWidth = e.clientX - activityBarWidth;
        const clampedWidth = Math.max(200, Math.min(newWidth, 650));
        setConfig(prev => {
          const updated = { ...prev, sidebarWidth: clampedWidth };
          try { localStorage.setItem("aether_pc_workspace_config", JSON.stringify(updated)); } catch {}
          return updated;
        });
      }

      // 2. Resizing AI Co-Pilot (Right)
      if (isResizingChat) {
        const newWidth = window.innerWidth - e.clientX;
        const clampedWidth = Math.max(260, Math.min(newWidth, 800));
        setConfig(prev => {
          const updated = { ...prev, chatWidth: clampedWidth };
          try { localStorage.setItem("aether_pc_workspace_config", JSON.stringify(updated)); } catch {}
          return updated;
        });
      }

      // 3. Resizing Central Split (Editor vs Preview)
      if (isResizingSplit && centerAreaRef.current) {
        const rect = centerAreaRef.current.getBoundingClientRect();
        if (config.splitOrientation === "horizontal") {
          const relativeX = e.clientX - rect.left;
          const ratio = relativeX / rect.width;
          const clampedRatio = Math.max(0.15, Math.min(ratio, 0.85));
          setConfig(prev => {
            const updated = { ...prev, splitRatio: clampedRatio };
            try { localStorage.setItem("aether_pc_workspace_config", JSON.stringify(updated)); } catch {}
            return updated;
          });
        } else {
          const relativeY = e.clientY - rect.top;
          const ratio = relativeY / rect.height;
          const clampedRatio = Math.max(0.15, Math.min(ratio, 0.85));
          setConfig(prev => {
            const updated = { ...prev, splitRatio: clampedRatio };
            try { localStorage.setItem("aether_pc_workspace_config", JSON.stringify(updated)); } catch {}
            return updated;
          });
        }
      }

      // 4. Resizing Terminal (Bottom)
      if (isResizingTerminal) {
        const newHeight = window.innerHeight - e.clientY - 32; // 32 is footer height
        const clampedHeight = Math.max(120, Math.min(newHeight, window.innerHeight * 0.82));
        setConfig(prev => {
          const updated = { ...prev, terminalHeight: clampedHeight };
          try { localStorage.setItem("aether_pc_workspace_config", JSON.stringify(updated)); } catch {}
          return updated;
        });
      }
    };

    const handleMouseUp = () => {
      setIsResizingSidebar(false);
      setIsResizingChat(false);
      setIsResizingSplit(false);
      setIsResizingTerminal(false);
    };

    window.addEventListener("keydown", handleShortcuts);
    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("mouseup", handleMouseUp);
    return () => {
      window.removeEventListener("keydown", handleShortcuts);
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleMouseUp);
      window.removeEventListener("aether_open_core_concepts", handleCustomEvents);
      window.removeEventListener("aether_run_terminal_cmd", handleCustomEvents);
      window.removeEventListener("aether-open-chat", handleCustomEvents);
    };
  }, [isResizingSidebar, isResizingChat, isResizingSplit, isResizingTerminal, config.showActivityBar, config.splitOrientation, zenMode, setZenMode]);

  const isDraggingAny = isResizingSidebar || isResizingChat || isResizingSplit || isResizingTerminal;

  return (
    <div 
      className={`w-full h-full flex flex-col overflow-hidden bg-[#030304] text-zinc-100 font-sans z-15 relative ${zenMode ? 'cursor-none' : ''}`}
      style={{
        // Custom CSS variables for dynamic workspace theming
        '--workspace-accent': config.accentColor,
        '--workspace-radius': `${config.borderRadius}px`,
        '--workspace-opacity': `${config.panelOpacity / 100}`,
        '--workspace-blur': `${config.backdropBlur}px`,
      } as React.CSSProperties}
    >
      
      {/* Invisible Fullscreen Pointer Capture Overlay to prevent iframe mouse trapping during slider drag */}
      {isDraggingAny && (
        <div 
          className={`fixed inset-0 z-[999] select-none ${
            isResizingTerminal ? 'cursor-ns-resize' : (isResizingSplit && config.splitOrientation === 'vertical' ? 'cursor-ns-resize' : 'cursor-ew-resize')
          }`}
          style={{ pointerEvents: 'all' }}
        />
      )}

      {/* Workspace Sliders & Tuning Modal */}
      <Suspense fallback={null}>
        <WorkspaceSlidersModal
          isOpen={showSlidersModal}
          onClose={() => setShowSlidersModal(false)}
          config={config}
          onChangeConfig={updateConfig}
          onResetDefaults={handleResetDefaults}
          activeRightTab={activeRightTab}
          onChangeRightTab={setActiveRightTab}
        />
      </Suspense>

      {!focusMode && (
        <MainHeader
          activeSession={sessions.find(s => s.id === activeSessionId)} 
          activeSessionId={activeSessionId}
          activeTab={activeRightTab}
          setActiveTab={(tab) => {
            if (tab === "dashboard" || tab === "editor" || tab === "preview" || tab === "gallery") {
              setActiveRightTab(tab as any);
            } else if (tab === "chat") {
              setChatOpen(!chatOpen);
            }
          }}
          setShowMobileMenu={() => {}}
          setActiveSessionId={setActiveSessionId}
          handleShareSession={() => {}}
          handleDownloadProject={handleExportProject}
          systemStats={systemStats}
          onOpenSettings={onOpenSettings}
          focusMode={focusMode}
          setFocusMode={setFocusMode}
          zenMode={zenMode}
          setZenMode={setZenMode}
          autoPilotMode={autoPilotMode}
          setAutoPilotMode={setAutoPilotMode}
          onOpenHealth={() => setShowHealth(true)}
          onOpenGitHub={() => setShowGitHubModal(true)}
          onOpenDeploy={() => setShowDeployModal(true)}
          onOpenCollaboration={() => setShowCollaborationModal(true)}
          onOpenMoat={() => setShowMoatModal(true)}
          onOpenExtensions={() => setShowExtensionMarketplace(true)}
          onOpenDebugger={() => setShowVisualDebugger(!showVisualDebugger)}
          onOpenSandbox={() => setShowLinuxSandbox(true)}
          chatOpen={chatOpen}
          setChatOpen={setChatOpen}
          sidebarOpen={sidebarOpen}
          setSidebarOpen={setSidebarOpen}
          hasWebFiles={hasWebFiles}
        />
      )}

      {/* 1. WORKSPACE SUB-HEADER WITH ADVANCED CONTROLS & SLIDERS QUICK LAUNCH */}
      {!focusMode && config.showSubHeader && (
        <header className="h-10 shrink-0 flex items-center justify-between px-4 sm:px-5 bg-white/[0.01] border-b border-white/5 select-none z-20">
          
          {/* Left Sub-Header Actions */}
          <div className="flex items-center gap-3">
            {activeSessionId && (
              <button
                onClick={() => {
                  setActiveSessionId(null);
                  setActiveRightTab("dashboard");
                }}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-orange-500/15 border border-orange-500/30 text-[10px] font-black tracking-widest text-orange-400 hover:bg-orange-500/25 active:scale-95 transition-all cursor-pointer mr-1"
                title="Close Chat & Back to HUB"
              >
                <ChevronLeft size={12} className="stroke-[3px]" />
                <span>CLOSE</span>
              </button>
            )}

            <button
              onClick={() => {
                if (activeSessionId) {
                  setSidebarOpen(!sidebarOpen);
                } else {
                  addLog("warning", "Open a project workspace session in HUB to browse files.", "WORKSPACE");
                }
              }}
              disabled={!activeSessionId}
              className={`p-1.5 rounded-lg transition-all outline-none focus-visible:ring-2 cursor-pointer ${
                !activeSessionId 
                  ? "opacity-20 cursor-not-allowed text-white/10" 
                  : (sidebarOpen ? "bg-white/5 text-orange-400" : "text-white/20 hover:text-white/60")
              }`}
              style={{
                color: (sidebarOpen && activeSessionId) ? config.accentColor : undefined
              }}
              title={!activeSessionId ? "Open a session to view explorer" : (sidebarOpen ? "Hide Left Sidebar (Alt+Shift+F)" : "Show Left Sidebar (Alt+Shift+F)")}
              aria-label={sidebarOpen ? "Hide File Explorer" : "Show File Explorer"}
              aria-pressed={sidebarOpen && !!activeSessionId}
            >
              {sidebarOpen ? <PanelLeftClose size={14} /> : <PanelLeft size={14} />}
            </button>
            
            <div className="h-4 w-px bg-white/5" />
            
            <div className="flex items-center gap-2">
              <span className="text-[9px] font-black text-white/30 uppercase tracking-[0.2em]">
                WORKSPACE
              </span>
              <span className="text-[9px] font-black text-white/50 uppercase tracking-[0.2em] hidden lg:inline">
                / {activeSessionId ? "ACTIVE_NODE" : "STANDALONE"}
              </span>
            </div>
          </div>

          {/* Center: Interactive Workspace View Switcher (Dashboard, Editor, Preview, Split Dual View, Gallery) */}
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-black/60 p-1 rounded-xl border border-white/5 shadow-inner">
              {(() => {
                let tabs = [
                  { id: 'dashboard', label: 'HUB', title: 'Cluster Dashboard' },
                  { id: 'editor', label: 'CODE', title: 'Monaco Code Editor' },
                  ...(hasWebFiles ? [
                    { id: 'preview', label: 'PREVIEW', title: 'Live Fullscreen App Preview' },
                    { id: 'split', label: 'SPLIT', title: 'Side-by-Side Dual Code & Live Preview' }
                  ] : []),
                  { id: 'gallery', label: 'GALLERY', title: 'App Gallery' }
                ];
                
                if (activeSessionId) {
                  // Hide/close the HUB tab button from the switcher when inside a chat!
                  tabs = tabs.filter(t => t.id !== 'dashboard');
                } else {
                  // When no chat is loaded, block code/preview/split entirely (only allow HUB and optionally Gallery)
                  tabs = tabs.filter(t => t.id === 'dashboard' || t.id === 'gallery');
                }

                return tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => {
                      setActiveRightTab(tab.id as any);
                      if (tab.id === 'preview' && window.innerWidth < 1200) {
                        setSidebarOpen(false);
                        setChatOpen(false);
                      }
                    }}
                    title={tab.title}
                    className={`px-3 py-1 rounded-lg text-[10px] font-black tracking-wider transition-all outline-none cursor-pointer ${
                      activeRightTab === tab.id 
                        ? "bg-white text-black shadow-lg" 
                        : "text-white/40 hover:text-white/90"
                    }`}
                    style={{
                      backgroundColor: activeRightTab === tab.id ? '#ffffff' : undefined,
                      color: activeRightTab === tab.id ? '#000000' : undefined
                    }}
                    aria-pressed={activeRightTab === tab.id}
                  >
                    {tab.label}
                  </button>
                ));
              })()}
            </div>
          </div>

          {/* Right Sub-Header Actions: Viewport Maximize, AI Co-Pilot Toggle, Tools */}
          <div className="flex items-center gap-2">
            {/* FULL VIEWPORT / MAXIMIZE CANVAS TOGGLE */}
            <button
              onClick={() => {
                if (sidebarOpen || chatOpen) {
                  setSidebarOpen(false);
                  setChatOpen(false);
                  addLog("info", "Maximized central workspace (Edge-to-Edge full viewport).", "WORKSPACE");
                } else {
                  setSidebarOpen(true);
                  setChatOpen(true);
                  addLog("info", "Restored standard sidebars.", "WORKSPACE");
                }
              }}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[9px] font-black uppercase tracking-widest border transition-all cursor-pointer ${
                !sidebarOpen && !chatOpen
                  ? "bg-cyan-500/20 text-cyan-300 border-cyan-500/40 shadow-[0_0_12px_rgba(6,182,212,0.25)]"
                  : "bg-white/[0.04] hover:bg-white/[0.08] text-white/70 hover:text-white border-white/10"
              }`}
              title={!sidebarOpen && !chatOpen ? "Restore Sidebars" : "Maximize Canvas (Full Viewport 100%)"}
            >
              {!sidebarOpen && !chatOpen ? <Minimize2 size={11} className="text-cyan-400" /> : <Maximize2 size={11} className="text-zinc-400" />}
              <span className="hidden sm:inline">{!sidebarOpen && !chatOpen ? "Restore" : "Full View"}</span>
            </button>

            <div className="h-4 w-px bg-white/5" />

            {/* AI Co-Pilot Button */}
            {activeSessionId && (
              <button
                onClick={() => {
                  if (activeRightTab === "dashboard") {
                    setActiveRightTab("editor");
                    setChatOpen(true);
                  } else {
                    setChatOpen(!chatOpen);
                  }
                }}
                className={`flex items-center gap-2 px-3 py-1 rounded-lg transition-all text-[9px] font-black uppercase tracking-widest outline-none cursor-pointer ${
                  chatOpen && activeRightTab !== "dashboard" 
                    ? "bg-orange-500/15 text-orange-400 border border-orange-500/30 shadow-[0_0_15px_rgba(249,115,22,0.15)]" 
                    : "text-white/30 hover:text-white/60 border border-transparent hover:bg-white/5"
                }`}
                aria-label="Toggle AI Co-Pilot"
                aria-pressed={chatOpen && activeRightTab !== "dashboard"}
              >
                <div className={`w-1.5 h-1.5 rounded-full ${chatOpen && activeRightTab !== "dashboard" ? 'bg-orange-400 animate-pulse' : 'bg-white/20'}`} />
                <span>CO-PILOT</span>
              </button>
            )}
            
            {activeSessionId && <div className="h-4 w-px bg-white/5" />}

            {/* Quick Tools Drawer Toggles */}
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setTerminalOpen(!terminalOpen)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition-all text-[8px] font-black uppercase tracking-widest cursor-pointer ${
                  terminalOpen 
                    ? "bg-orange-500/15 text-orange-400 border border-orange-500/30" 
                    : "text-white/30 hover:text-white/60 border border-transparent hover:bg-white/5"
                }`}
                title="Toggle System Terminal Drawer"
                aria-pressed={terminalOpen}
              >
                <Terminal size={11} />
                <span className="hidden md:inline">SHELL</span>
              </button>

              <button
                onClick={() => setEnvOpen(!envOpen)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg transition-all text-[8px] font-black uppercase tracking-widest cursor-pointer ${
                  envOpen 
                    ? "bg-orange-500/15 text-orange-400 border border-orange-500/30" 
                    : "text-white/30 hover:text-white/60 border border-transparent hover:bg-white/5"
                }`}
                title="Toggle Nodes & Environment"
                aria-pressed={envOpen}
              >
                <Cpu size={11} />
                <span className="hidden md:inline">NODES</span>
              </button>
            </div>

          </div>
        </header>
      )}

      {/* 2. THE THREE-WAY RESIZABLE SPLIT INTERACTION DOCK */}
      <div className="flex-1 flex overflow-hidden min-w-0 bg-transparent relative z-10">
        
        {/* Far Left Activity Bar (VS Code Icon Strip) */}
        {!focusMode && config.showActivityBar && (
          <ActivityBar 
            activeMode={sidebarOpen ? sidebarMode : null} 
            onChange={(mode) => {
              if (!mode) {
                setSidebarOpen(false);
              } else {
                setSidebarMode(mode);
                setSidebarOpen(true);
              }
            }} 
          />
        )}

        {/* PANEL A: Collapsible & Resizable Left Sidebar Content */}
        <AnimatePresence initial={false}>
          {sidebarOpen && sidebarMode && (
            <>
              {/* Mobile Backdrop Overlay */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setSidebarOpen(false)}
                className="fixed inset-0 bg-black/70 backdrop-blur-sm z-30 md:hidden"
              />
              <motion.div
                initial={{ x: -320, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: -320, opacity: 0 }}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
                style={{ 
                  width: config.sidebarWidth,
                  maxWidth: "min(100vw, 480px)",
                  backgroundColor: `rgba(10, 10, 15, ${config.panelOpacity > 90 ? 0.95 : 0.85})`,
                  backdropFilter: `blur(${config.backdropBlur}px)`
                }}
                className="h-full shrink-0 border-r border-white/10 flex flex-col overflow-hidden absolute md:relative left-0 top-0 bottom-0 z-40 shadow-2xl md:shadow-none w-full md:w-auto"
              >
                {/* Quick Sidebar Header */}
                <div className="h-9 shrink-0 px-3.5 bg-black/80 border-b border-white/10 flex items-center justify-between text-[11px] font-bold tracking-wider uppercase select-none">
                  <span className="text-zinc-200 tracking-widest truncate">
                    {sidebarMode === 'files' ? 'Explorer' :
                     sidebarMode === 'search' ? 'Search' :
                     sidebarMode === 'history' ? 'Source Control' :
                     sidebarMode === 'chat' ? 'AI Assistant' :
                     sidebarMode === 'tasks' ? 'Task Runner' :
                     sidebarMode === 'terminal' ? 'Terminal' :
                     sidebarMode === 'settings' ? 'Settings' :
                     sidebarMode === 'uistudio' ? 'Tools & Extensions' :
                     sidebarMode}
                  </span>
                  <button 
                    onClick={() => setSidebarOpen(false)}
                    className="p-1 hover:text-white rounded hover:bg-white/10 text-zinc-400 transition-colors cursor-pointer"
                    title="Collapse Sidebar"
                  >
                    <PanelLeftClose size={14} />
                  </button>
                </div>

              <div className="flex-1 overflow-hidden">
                <Suspense fallback={<div className="p-5 font-mono text-[10px] text-white/20 animate-pulse uppercase tracking-widest text-center mt-12">Initializing neural panel...</div>}>
                  {sidebarMode === 'files' && (
                    <FileExplorer
                      files={files}
                      activeFileId={activeFileId}
                      onSelectFile={(f) => {
                        setActiveFileId(f.id);
                        setActiveRightTab("editor");
                        if (window.innerWidth < 768) setSidebarOpen(false);
                      }}
                      onCreateFile={(name, lang) => {
                        const id = "f-" + Math.random().toString(36).substr(2, 9);
                        const nf = {
                          id,
                          name,
                          content: "",
                          language: lang,
                          lastModified: Date.now(),
                        };
                        setFiles(prev => [...prev, nf]);
                        setActiveFileId(id);
                      }}
                      onDeleteFile={(id) => {
                        setFiles(prev => prev.filter((f) => f.id !== id));
                        if (activeFileId === id) setActiveFileId(null);
                      }}
                      onRenameFile={handleRenameFile}
                      onExport={handleExportProject}
                      onApplyTemplate={handleApplyTemplate}
                      projectId={activeSessionId!}
                    />
                  )}

                  {sidebarMode === 'search' && <SearchView files={files} onSelectFile={(id) => { setActiveFileId(id); setActiveRightTab("editor"); if (window.innerWidth < 768) setSidebarOpen(false); }} />}

                  {sidebarMode === 'linux' && (
                    <LinuxSystemStudio onClose={() => setSidebarMode(null)} />
                  )}

                  {sidebarMode === 'extensions' && (
                    <ExtensionsView onClose={() => setSidebarMode(null)} />
                  )}

                  {sidebarMode === 'blackhole' && (
                    <BlackholeCanvas />
                  )}
                  
                  {sidebarMode === 'settings' && (
                    <SettingsView 
                      user={user} 
                      onUpdateUser={onUpdateUser} 
                      onLogout={onLogout} 
                      onNuclearReset={onNuclearReset}
                      onClearAllSessions={onClearAllSessions}
                      onSyncNow={onSyncNow}
                      isSyncing={isSyncing}
                      onClose={() => setSidebarMode(null)}
                    />
                  )}
                  
                  {sidebarMode === 'customizer' && (
                    <CustomizerView 
                      user={user} 
                      onUpdateUser={onUpdateUser} 
                      onClose={() => setSidebarMode(null)}
                    />
                  )}

                  {sidebarMode === 'history' && (
                    <FileHistoryView 
                      activeFileId={activeFileId} 
                      files={files} 
                      onFilesUpdated={setFiles} 
                      sessionId={activeSessionId} 
                      addLog={addLog} 
                    />
                  )}

                  {sidebarMode === 'tasks' && (
                    <div className="p-6 h-full flex flex-col">
                      <h2 className="text-[10px] font-black text-white/40 uppercase tracking-[0.2em] mb-6">Task Runner</h2>
                      <div className="flex-1 bg-black/40 rounded-xl border border-white/5 p-4 overflow-hidden">
                        <TaskRunnerView sessionId={activeSessionId} files={files} addLog={addLog} />
                      </div>
                    </div>
                  )}

                  {sidebarMode === 'terminal' && (
                    <div className="p-6 h-full flex flex-col">
                      <h2 className="text-[10px] font-black text-white/40 uppercase tracking-[0.2em] mb-6">Neural Terminal</h2>
                      <div className="flex-1 bg-black/40 rounded-xl border border-white/5 p-4 overflow-hidden">
                        <SystemTerminal onClose={() => setSidebarMode(null)} />
                      </div>
                    </div>
                  )}

                  {sidebarMode === 'evolution' && (
                    <EvolutionCore
                      files={files}
                      setFiles={setFiles}
                      activeFileId={activeFileId}
                      setActiveFileId={setActiveFileId}
                      activeSessionId={activeSessionId}
                      addLog={addLog}
                      onClose={() => setSidebarMode(null)}
                    />
                  )}

                  {sidebarMode === 'api_playground' && (
                    <ApiPlayground />
                  )}

                  {sidebarMode === 'security' && (
                    <SecurityScannerView
                      files={files}
                      onFixIssue={(fileId) => {
                        addLog("info", `Fixing issue in file ${fileId}`);
                      }}
                      onApplyAIAutoFixAll={() => {
                        addLog("success", "AI Auto-Repair sequence engaged for all workspace files.", "SECURITY");
                      }}
                    />
                  )}

                  {sidebarMode === 'database' && (
                    <DatabaseStudio
                      files={files}
                      onAddFileToWorkspace={(newFile) => {
                        setFiles((prev: FileNode[]) => [...prev, newFile]);
                        setActiveFileId(newFile.id);
                        addLog("success", `Created data file ${newFile.name}`, "DATABASE");
                      }}
                    />
                  )}

                  {sidebarMode === 'datatransformer' && (
                    <DataTransformerStudio />
                  )}

                  {sidebarMode === 'uistudio' && (
                    <UIComponentStudio
                      onAddFileToWorkspace={(newFile) => {
                        setFiles((prev: FileNode[]) => [...prev, newFile]);
                        setActiveFileId(newFile.id);
                        addLog("success", `Created UI component file ${newFile.name}`, "UI_STUDIO");
                      }}
                    />
                  )}

                  {sidebarMode === 'audiosynth' && (
                    <AudioSynthStudio
                      onAddFileToWorkspace={(newFile) => {
                        setFiles((prev: FileNode[]) => [...prev, newFile]);
                        setActiveFileId(newFile.id);
                        addLog("success", `Created Audio module file ${newFile.name}`, "AUDIO_SYNTH");
                      }}
                    />
                  )}

                  {sidebarMode === 'dependencygraph' && (
                    <DependencyGraphStudio files={files} />
                  )}

                  {sidebarMode === 'jwt_decoder' && (
                    <JWTDecoder onClose={() => setSidebarMode(null)} />
                  )}

                  {sidebarMode === 'env_manager' && (
                    <EnvManager
                      files={files}
                      onSaveFiles={(updatedFiles) => setFiles(updatedFiles)}
                      onClose={() => setSidebarMode(null)}
                    />
                  )}

                  {sidebarMode === 'profiler' && (
                    <PerformanceProfiler files={files} />
                  )}

                  {['agents', 'deployment', 'analytics', 'marketplace'].includes(sidebarMode) && (
                    <div className="p-8 h-full flex flex-col items-center justify-center text-center">
                      <div className="w-16 h-16 rounded-3xl bg-white/[0.02] border border-white/5 flex items-center justify-center mb-6 shadow-2xl">
                        {sidebarMode === 'agents' && <Bot size={24} className="text-orange-500/40" />}
                        {sidebarMode === 'evolution' && <Zap size={24} className="text-amber-500/40" />}
                        {sidebarMode === 'deployment' && <Cloud size={24} className="text-blue-500/40" />}
                        {sidebarMode === 'analytics' && <BarChart3 size={24} className="text-emerald-500/40" />}
                        {sidebarMode === 'marketplace' && <Layers size={24} className="text-purple-500/40" />}
                      </div>
                      <h2 className="text-[10px] font-black text-white/60 uppercase tracking-[0.3em] mb-3">{sidebarMode}_SUBSYSTEM</h2>
                      <p className="text-[9px] font-medium text-white/20 max-w-xs leading-relaxed uppercase tracking-widest">
                        Neural handshake in progress. This core module is being synchronized with the global agentic grid.
                      </p>
                      <div className="mt-8 flex items-center gap-2">
                        <motion.div 
                          animate={{ 
                            scale: [1, 1.2, 1],
                            opacity: [0.5, 1, 0.5]
                          }}
                          transition={{ 
                            duration: 2, 
                            repeat: Infinity,
                            ease: "easeInOut"
                          }}
                          className="w-1.5 h-1.5 rounded-full bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.8)]" 
                        />
                        <span className="text-[8px] font-black text-white/20 tracking-[0.3em] uppercase">Neural Handshake Active</span>
                      </div>
                    </div>
                  )}
                </Suspense>
              </div>
            </motion.div>
          </>
        )}
        </AnimatePresence>

        {/* SIDEBAR DRAGGABLE RESIZE GUTTER */}
        {sidebarOpen && sidebarMode && (
          <div
            onMouseDown={() => setIsResizingSidebar(true)}
            onDoubleClick={() => updateConfig({ ...config, sidebarWidth: DEFAULT_WORKSPACE_CONFIG.sidebarWidth })}
            className={`w-1.5 shrink-0 relative cursor-col-resize hover:bg-orange-500/40 transition-colors z-20 group flex items-center justify-center ${
              isResizingSidebar ? 'bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.8)]' : 'bg-transparent'
            }`}
            title="Drag to resize sidebar width (Double-click to reset 300px)"
          >
            <div className="w-0.5 h-6 bg-white/20 group-hover:bg-orange-400 rounded-full transition-colors" />
          </div>
        )}

        {/* PANEL C: REST OF CORE AREA (Takes remaining width of workspace) */}
        <div className="flex-1 w-full h-full min-h-full min-w-0 flex flex-col overflow-hidden bg-transparent relative">
          
          {/* MAIN DYNAMIC CONTENT CONTAINER */}
          <div ref={centerAreaRef} className="flex-1 w-full h-full min-h-full flex overflow-hidden min-w-0 relative">
            <AnimatePresence mode="wait">
              
              {/* COLUMN 0: DASHBOARD PAGE */}
              {activeRightTab === "dashboard" && (
                <motion.div
                  key="dashboard"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.15 }}
                  className="h-full flex-1 min-w-0 flex flex-col overflow-hidden bg-transparent"
                >
                  <Suspense fallback={
                    <div className="p-8 text-xs font-mono text-white/30 text-center animate-pulse flex flex-col items-center justify-center h-full">
                      <div className="w-6 h-6 rounded-full border-2 border-white/5 border-t-orange-500 animate-spin mb-3" />
                      <span>Loading Aether Dashboard...</span>
                    </div>
                  }>
                    <MasterpieceUI
                      onStart={(p, atts) => {
                        createNewSession(p, undefined, atts);
                        setChatOpen(true);
                        setActiveRightTab("editor");
                      }}
                      sessions={sessions}
                      onSelectSession={(id) => {
                        setActiveSessionId(id);
                        setChatOpen(true);
                        setActiveRightTab("editor");
                      }}
                      onOpenSettings={onOpenSettings}
                      onShowGallery={() => setActiveRightTab("gallery")}
                      onViewAllSessions={() => setSidebarMode("history")}
                      onDeleteSession={handleDeleteSession}
                      onRenameSession={handleRenameSession}
                    />
                  </Suspense>
                </motion.div>
              )}

              {/* COLUMN 3: GALLERY PAGE */}
              {activeRightTab === "gallery" && (
                <motion.div
                  key="gallery"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.15 }}
                  className="h-full flex-1 min-w-0 flex flex-col overflow-hidden bg-transparent"
                >
                  <Suspense fallback={
                    <div className="p-8 text-xs font-mono text-white/30 text-center animate-pulse flex flex-col items-center justify-center h-full">
                      <div className="w-6 h-6 rounded-full border-2 border-white/5 border-t-orange-500 animate-spin mb-3" />
                      <span>Loading Aether App Gallery...</span>
                    </div>
                  }>
                    <AppGallery 
                      onBack={() => setActiveRightTab("dashboard")} 
                      onLaunchApp={handleLaunchGalleryApp} 
                    />
                  </Suspense>
                </motion.div>
              )}

              {/* COLUMN 1: MONACO EDITOR (SINGLE) */}
              {activeRightTab === "editor" && (
                <motion.div
                  key="editor"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.15 }}
                  className="h-full flex-1 min-w-0 flex flex-col overflow-hidden relative"
                >
                  {/* Editor Breadcrumbs & Customizer Controls */}
                  <div className="flex h-8 shrink-0 bg-black/40 border-b border-white/5 px-4 items-center justify-between text-[10px] select-none">
                    <div className="flex items-center gap-2 truncate text-white/40">
                      <Code2 size={12} className="text-orange-500/60" />
                      {activeFile ? (
                        <div className="flex items-center gap-2">
                          <span className="font-black tracking-widest text-white/80 uppercase">{activeFile.name}</span>
                          <div className="h-3 w-px bg-white/10" />
                          <span className="text-[9px] font-bold text-white/20 uppercase tracking-widest">{activeFile.language}</span>
                        </div>
                      ) : (
                        <span className="font-black tracking-widest uppercase">STAGING_AREA</span>
                      )}
                    </div>

                    <div className="flex items-center gap-3">
                      {activeFile && (
                        <>
                          <button 
                            onClick={() => window.dispatchEvent(new CustomEvent('aether:open-surgical-ai'))}
                            className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-md border border-purple-500/30 bg-purple-500/10 hover:bg-purple-500/20 text-purple-300 hover:text-purple-200 transition-all text-[9px] font-black uppercase tracking-widest outline-none cursor-pointer"
                            title="Surgical AI Edit & Precision Code Generator (Ctrl+K)"
                          >
                            <Scissors size={10} className="text-purple-400" />
                            <span>Surgical AI</span>
                          </button>

                          <button 
                            onClick={() => handleFormatActiveFile()}
                            className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-md border border-orange-500/20 bg-orange-500/5 hover:bg-orange-500/15 text-orange-500/80 hover:text-orange-400 transition-all text-[9px] font-black uppercase tracking-widest outline-none cursor-pointer"
                            title="Tidy & Format Code"
                          >
                            <Sparkles size={11} className="animate-pulse text-orange-500" />
                            <span>Tidy</span>
                          </button>
                        </>
                      )}

                      {/* Font Size Micro-steppers */}
                      {activeFileId && (
                        <div className="flex items-center gap-2 bg-white/[0.03] border border-white/5 px-2 py-0.5 rounded-md text-[9px] font-black uppercase tracking-widest">
                          <span className="text-white/20">FONT</span>
                          <div className="flex items-center gap-1">
                            <button 
                              onClick={() => updateConfig({ ...config, editorFontSize: Math.max(10, config.editorFontSize - 1) })} 
                              className="w-4 h-4 flex items-center justify-center hover:bg-white/10 rounded cursor-pointer"
                              title="Decrease font size"
                            >
                              -
                            </button>
                            <span className="text-white/60 min-w-[2ch] text-center">{config.editorFontSize}px</span>
                            <button 
                              onClick={() => updateConfig({ ...config, editorFontSize: Math.min(26, config.editorFontSize + 1) })} 
                              className="w-4 h-4 flex items-center justify-center hover:bg-white/10 rounded cursor-pointer"
                              title="Increase font size"
                            >
                              +
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  <div 
                    className="flex-1 w-full overflow-hidden relative bg-[#010101]"
                    onMouseMove={handleEditorMouseMove}
                  >
                    {activeFile ? (
                      activeFile.isBinary || activeFile.language === 'image' || ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'].some(ext => activeFile.name.toLowerCase().endsWith('.' + ext)) ? (
                        <Suspense fallback={<div className="p-8 text-[10px] font-black text-white/20 text-center animate-pulse uppercase tracking-[0.3em] flex items-center justify-center h-full">Loading Visual Asset...</div>}>
                          <ImageAssetViewer
                            file={activeFile}
                            onUpdateContent={(newContent) => {
                              if (activeFileId) {
                                const nf = files.map((f) =>
                                  f.id === activeFileId
                                    ? { ...f, content: newContent }
                                    : f,
                                );
                                setFiles(nf);
                                const fileToUpdate = nf.find((f) => f.id === activeFileId)!;
                                saveFile(activeSessionId!, fileToUpdate);
                              }
                            }}
                          />
                        </Suspense>
                      ) : (
                        <Suspense fallback={<div className="p-8 text-[10px] font-black text-white/20 text-center animate-pulse uppercase tracking-[0.3em] flex items-center justify-center h-full">Mounting neural buffers...</div>}>
                          <MonacoEditorWrapper
                            onMount={() => {}}
                            code={activeFile.content}
                            language={activeFile.language}
                            filePath={activeFile.name}
                            breakpoints={fileBreakpoints[activeFile.name] || []}
                            onToggleBreakpoint={(line) => {
                              setFileBreakpoints(prev => {
                                const current = prev[activeFile.name] || [];
                                const exists = current.includes(line);
                                const next = exists ? current.filter(l => l !== line) : [...current, line];
                                return { ...prev, [activeFile.name]: next };
                              });
                            }}
                            onChange={(c) => {
                              if (activeFileId) {
                                const updatedContent = c || "";
                                const nf = files.map((f) =>
                                  f.id === activeFileId
                                    ? { ...f, content: updatedContent }
                                    : f,
                                );
                                setFiles(nf);
                                const fileToUpdate = nf.find((f) => f.id === activeFileId)!;
                                saveFile(activeSessionId!, fileToUpdate);
                              }
                            }}
                            onSave={handleFormatActiveFile}
                            fontFamily={config.editorFont || activeFont}
                            fontSize={config.editorFontSize}
                            lineHeight={config.editorLineHeight}
                            minimapEnabled={config.minimapEnabled}
                            ligatures={config.ligaturesEnabled}
                            vimMode={user?.editorSettings?.vimMode ?? false}
                          />
                          <CursorOverlay cursors={collaboratorCursors} />
                        </Suspense>
                      )
                    ) : (
                      <div className="flex-1 h-full flex flex-col items-center justify-center p-8 select-none text-center">
                        <div className="w-16 h-16 rounded-3xl bg-white/[0.02] border border-white/5 flex items-center justify-center mb-6 shadow-2xl">
                          <Code2 size={24} className="text-white/10" />
                        </div>
                        <h2 className="text-xs font-black text-white/60 uppercase tracking-[0.3em] mb-3">No active buffer</h2>
                        <p className="text-[10px] font-medium text-white/20 max-w-xs leading-relaxed uppercase tracking-widest">Select a cluster node from the navigation interface to initialize the editor workspace.</p>
                        <button
                          onClick={() => {
                            const id = "f-" + Math.random().toString(36).substr(2, 9);
                            const nf = {
                              id,
                              name: "main.ts",
                              content: "// Neural Engine Start\n",
                              language: "typescript",
                              lastModified: Date.now(),
                            };
                            setFiles(prev => [...prev, nf]);
                            setActiveFileId(id);
                          }}
                          className="mt-8 px-6 py-2.5 bg-orange-600 hover:bg-orange-500 text-white font-black text-[9px] uppercase tracking-[0.25em] rounded-xl transition-all shadow-[0_0_20px_rgba(234,88,12,0.2)] active:scale-95 cursor-pointer"
                        >
                          Initialize New Core
                        </button>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

              {/* COLUMN 2: LIVE RUNTIME PREVIEW (SINGLE VIEW) */}
              {activeRightTab === "preview" && (
                <motion.div 
                  key="preview"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.15 }}
                  style={{ width: "100%", height: "100%", minHeight: "100%" }}
                  className="w-full h-full min-h-full flex-1 min-w-0 flex flex-col overflow-hidden bg-transparent"
                >
                  {/* Switcher Header */}
                  <div className="h-8 shrink-0 bg-black/60 border-b border-white/5 px-3 flex items-center justify-between select-none">
                    <div className="flex items-center gap-1.5">
                      <Camera size={10} className="text-cyan-400" />
                      <span className="text-[9px] font-black uppercase tracking-wider text-white">Live Web Runtime</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-[8px] font-mono text-cyan-400 uppercase tracking-widest bg-cyan-500/10 border border-cyan-500/20 px-2 py-0.5 rounded">
                        Full Viewport
                      </span>
                    </div>
                  </div>

                  <div className="flex-1 w-full h-full min-h-full overflow-hidden relative">
                    <Suspense fallback={
                      <div className="p-8 text-xs font-mono text-white/30 text-center animate-pulse flex flex-col items-center justify-center h-full">
                        <div className="w-6 h-6 rounded-full border-2 border-white/5 border-t-cyan-500 animate-spin mb-3" />
                        <span>Initializing web preview environment...</span>
                      </div>
                    }>
                      <PreviewPane 
                        files={files} 
                        setFiles={setFiles}
                        autoPilotMode={autoPilotMode}
                        activeSessionId={activeSessionId}
                        onLog={addLog} 
                        onOpenDeploy={() => setShowDeployModal(true)}
                      />
                    </Suspense>
                  </div>
                </motion.div>
              )}

              {/* COLUMN 4: DUAL SPLIT VIEW (Code + Live Preview Side-by-Side) */}
              {activeRightTab === "split" && (
                <motion.div
                  key="split"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.15 }}
                  className={`h-full flex-1 min-w-0 flex overflow-hidden bg-transparent ${
                    config.splitOrientation === "vertical" ? "flex-col" : "flex-row"
                  }`}
                >
                  {/* Left/Top: Editor in Split */}
                  <div 
                    style={{
                      flex: `${config.splitRatio} 1 0%`,
                      minWidth: config.splitOrientation === "horizontal" ? 200 : undefined,
                      minHeight: config.splitOrientation === "vertical" ? 150 : undefined,
                    }}
                    className="h-full flex flex-col overflow-hidden bg-[#010101] border-r border-white/5"
                  >
                    <div className="h-8 shrink-0 bg-black/50 border-b border-white/5 px-3 flex items-center justify-between text-[10px] select-none">
                      <div className="flex items-center gap-2 truncate text-white/50">
                        <Code2 size={12} className="text-orange-500/70" />
                        <span className="font-bold tracking-wider text-white/80 uppercase truncate">
                          {activeFile?.name || "Code Buffer"}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        {activeFile && (
                          <button
                            onClick={() => handleFormatActiveFile()}
                            className="text-[9px] font-mono text-orange-400 hover:text-orange-300 bg-orange-500/10 px-2 py-0.5 rounded border border-orange-500/20"
                            title="Format active code"
                          >
                            Format
                          </button>
                        )}
                      </div>
                    </div>

                    <div 
                      className="flex-1 w-full overflow-hidden relative"
                      onMouseMove={handleEditorMouseMove}
                    >
                      {activeFile ? (
                        <Suspense fallback={<div className="p-4 text-xs font-mono text-white/30">Loading buffer...</div>}>
                          <MonacoEditorWrapper
                            onMount={() => {}}
                            code={activeFile.content}
                            language={activeFile.language}
                            onChange={(c) => {
                              if (activeFileId) {
                                const updatedContent = c || "";
                                const nf = files.map((f) => f.id === activeFileId ? { ...f, content: updatedContent } : f);
                                setFiles(nf);
                                const fileToUpdate = nf.find((f) => f.id === activeFileId)!;
                                saveFile(activeSessionId!, fileToUpdate);
                              }
                            }}
                            onSave={handleFormatActiveFile}
                            fontFamily={config.editorFont || activeFont}
                            fontSize={config.editorFontSize}
                            lineHeight={config.editorLineHeight}
                            minimapEnabled={false}
                            ligatures={config.ligaturesEnabled}
                            vimMode={user?.editorSettings?.vimMode ?? false}
                          />
                          <CursorOverlay cursors={collaboratorCursors} />
                        </Suspense>
                      ) : (
                        <div className="flex-1 h-full flex items-center justify-center p-4 text-center text-white/30 text-xs font-mono">
                          Select a file from the explorer
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Split Resizer Divider */}
                  <div
                    onMouseDown={() => setIsResizingSplit(true)}
                    onDoubleClick={() => updateConfig({ ...config, splitRatio: 0.5 })}
                    className={`shrink-0 relative group flex items-center justify-center transition-colors z-20 ${
                      config.splitOrientation === "horizontal"
                        ? "w-1.5 cursor-col-resize hover:bg-cyan-500/40"
                        : "h-1.5 cursor-row-resize hover:bg-cyan-500/40"
                    } ${isResizingSplit ? "bg-cyan-500 shadow-[0_0_10px_rgba(6,182,212,0.8)]" : "bg-white/5"}`}
                    title="Drag to resize split panes (Double click to reset 50/50)"
                  >
                    <div className={`bg-white/30 group-hover:bg-cyan-400 rounded-full transition-colors ${
                      config.splitOrientation === "horizontal" ? "w-0.5 h-6" : "h-0.5 w-6"
                    }`} />
                  </div>

                  {/* Right/Bottom: Preview in Split */}
                  <div
                    style={{
                      flex: `${1 - config.splitRatio} 1 0%`,
                      minWidth: config.splitOrientation === "horizontal" ? 200 : undefined,
                      minHeight: config.splitOrientation === "vertical" ? 150 : undefined,
                    }}
                    className="h-full flex flex-col overflow-hidden bg-[#07090e]"
                  >
                    <div className="h-8 shrink-0 bg-black/50 border-b border-white/5 px-3 flex items-center justify-between text-[10px] select-none">
                      <div className="flex items-center gap-1.5 text-cyan-400">
                        <Camera size={11} />
                        <span className="font-bold tracking-wider uppercase text-white/80">Live Preview</span>
                      </div>
                      <span className="text-[8px] font-mono text-white/30">
                        Ratio: {Math.round(config.splitRatio * 100)} / {Math.round((1 - config.splitRatio) * 100)}
                      </span>
                    </div>

                    <div className="flex-1 w-full h-full min-h-full overflow-hidden relative">
                      <Suspense fallback={<div className="p-4 text-xs font-mono text-white/30">Loading preview...</div>}>
                        <PreviewPane 
                          files={files} 
                          setFiles={setFiles}
                          autoPilotMode={autoPilotMode}
                          activeSessionId={activeSessionId}
                          onLog={addLog} 
                        />
                      </Suspense>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* COLUMN 3: APP GALLERY */}

            </AnimatePresence>
          </div>

          {/* Bottom Tool Drawer (System Terminal & Shell) */}
          <AnimatePresence>
            {terminalOpen && (
              <motion.div 
                initial={{ y: "100%" }}
                animate={{ y: 0 }}
                exit={{ y: "100%" }}
                transition={{ type: 'spring', damping: 25, stiffness: 200 }}
                className="fixed bottom-8 left-0 right-0 z-50 bg-[#050505] border-t border-white/10 shadow-[0_-10px_40px_rgba(0,0,0,0.8)] flex flex-col"
                style={{ height: config.terminalHeight }}
              >
                {/* Resize Handle with slider indicator */}
                <div 
                  onMouseDown={() => setIsResizingTerminal(true)}
                  onDoubleClick={() => updateConfig({ ...config, terminalHeight: 280 })}
                  className="absolute -top-1.5 left-0 right-0 h-3 cursor-ns-resize hover:bg-orange-500/40 transition-colors z-[60] flex items-center justify-center"
                  title="Drag to resize terminal height (Double-click to reset 280px)"
                  aria-label="Resize Terminal"
                >
                  <div className="w-16 h-1 bg-white/20 hover:bg-orange-400 rounded-full" />
                </div>

                {/* Drawer Tab Switcher Bar */}
                <div className="flex items-center justify-between px-4 py-1.5 bg-[#090b10] border-b border-white/10 text-xs select-none">
                  <div className="flex items-center gap-3">
                    <div className="px-2 py-0.5 text-xs font-bold text-orange-400 flex items-center gap-1.5">
                      <Terminal size={13} />
                      <span className="text-[10px] font-black uppercase tracking-wider">System Shell Terminal</span>
                    </div>

                    <span className="text-[9px] font-mono text-white/30">Height: {config.terminalHeight}px</span>
                  </div>

                  <div className="flex items-center gap-2">
                    {[180, 280, 420].map((h) => (
                      <button
                        key={h}
                        onClick={() => updateConfig({ ...config, terminalHeight: h })}
                        className={`px-2 py-0.5 rounded text-[9px] font-mono border ${
                          config.terminalHeight === h ? 'bg-orange-500/20 border-orange-500/40 text-orange-300' : 'bg-white/5 border-white/5 text-white/30 hover:text-white'
                        }`}
                      >
                        {h}px
                      </button>
                    ))}
                    <button
                      onClick={() => setTerminalOpen(false)}
                      className="text-zinc-400 hover:text-white text-xs px-2.5 py-0.5 rounded hover:bg-white/10"
                    >
                      Close ×
                    </button>
                  </div>
                </div>

                <div className="flex-1 overflow-hidden">
                  <Suspense fallback={<div className="p-4 text-xs font-mono text-zinc-500">Loading terminal module...</div>}>
                    <SystemTerminal onClose={() => setTerminalOpen(false)} />
                  </Suspense>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Workspace Footer with Status Metrics */}
          {config.showFooter && (
            <footer className="h-8 bg-black/60 border-t border-white/5 px-6 flex items-center justify-between text-[9px] text-white/30 select-none font-black uppercase tracking-[0.2em] relative z-[40]">
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <span className="text-orange-500/80">PIPELINE_OK</span>
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500/20 flex items-center justify-center">
                    <div className="w-1 h-1 rounded-full bg-emerald-500 shadow-[0_0_5px_rgba(16,185,129,0.5)]" />
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-white/10">|</span>
                  <span className="text-white/60 font-mono tracking-tight">{getFileLengthMeta()}</span>
                </div>
                <div className="flex items-center gap-3 hidden sm:flex">
                  <span className="text-white/10">|</span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-white/20">GRID_LATENCY:</span>
                    <span className="text-blue-400">12MS</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="hidden lg:flex items-center gap-5">
                  <div className="flex items-center gap-2">
                    <span className="text-[8px] text-white/20">MEM</span>
                    <div className="w-16 h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div initial={{ width: 0 }} animate={{ width: "42%" }} className="h-full bg-blue-500/60 shadow-[0_0_8px_rgba(59,130,246,0.3)]" />
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[8px] text-white/20">CPU</span>
                    <div className="w-16 h-1 bg-white/5 rounded-full overflow-hidden">
                      <motion.div initial={{ width: 0 }} animate={{ width: "16%" }} className="h-full bg-orange-500/60 shadow-[0_0_8px_rgba(249,115,22,0.3)]" />
                    </div>
                  </div>
                </div>
                <span className="text-white/10 hidden lg:inline">|</span>
                <div className="flex items-center gap-2">
                  <div className={`w-1.5 h-1.5 rounded-full shadow-[0_0_8px_rgba(16,185,129,0.3)] ${isProcessing ? "bg-amber-400 animate-ping" : "bg-emerald-400"}`} />
                  <span className="text-white/60">{isProcessing ? "SYNTHESIZING" : "STANDBY"}</span>
                </div>
              </div>
            </footer>
          )}

        </div>

        {/* AI CHAT DRAGGABLE RESIZE GUTTER */}
        {chatOpen && activeRightTab !== "dashboard" && (
          <div
            onMouseDown={() => setIsResizingChat(true)}
            onDoubleClick={() => updateConfig({ ...config, chatWidth: DEFAULT_WORKSPACE_CONFIG.chatWidth })}
            className={`w-1.5 shrink-0 relative cursor-col-resize hover:bg-orange-500/40 transition-colors z-20 group flex items-center justify-center ${
              isResizingChat ? 'bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.8)]' : 'bg-transparent'
            }`}
            title="Drag to resize AI Co-Pilot width (Double-click to reset 360px)"
          >
            <div className="w-0.5 h-6 bg-white/20 group-hover:bg-orange-400 rounded-full transition-colors" />
          </div>
        )}

        {/* PANEL B: AI Chat Panel (Resizable Far Right Column) */}
        <AnimatePresence initial={false}>
          {envOpen && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 320, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.2, ease: "easeOut" }}
              className="h-full shrink-0 border-l border-zinc-900 bg-zinc-900/20 flex flex-col overflow-hidden relative"
            >
              <EnvironmentPanel files={files} projectName={activeSessionId || "Aether Project"} />
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence initial={false}>
          {chatOpen && activeRightTab !== "dashboard" && (
            <>
              {/* Mobile Backdrop Overlay for AI Chat Drawer */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setChatOpen(false)}
                className="fixed inset-0 bg-black/70 backdrop-blur-sm z-30 lg:hidden"
              />
              <motion.div
                initial={{ x: 360, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                exit={{ x: 360, opacity: 0 }}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
                style={{ 
                  width: config.chatWidth,
                  maxWidth: "min(90vw, 480px)",
                  backgroundColor: `rgba(18, 18, 22, ${config.panelOpacity > 80 ? 0.95 : 0.88})`,
                  backdropFilter: `blur(${config.backdropBlur}px)`
                }}
                className="h-full shrink-0 border-l border-white/10 flex flex-col overflow-hidden absolute lg:relative right-0 top-0 bottom-0 z-40 shadow-2xl lg:shadow-none"
              >
                <div className="h-10 shrink-0 px-4 bg-black/60 border-b border-white/5 flex items-center justify-between text-[10px] font-black uppercase tracking-[0.2em] text-white/40 select-none">
                  <div className="flex items-center gap-2.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.8)] animate-pulse" />
                    <span className="text-white/90 font-bold tracking-wider">AI CO-PILOT</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[8px] font-mono text-white/30 hidden sm:inline">{config.chatWidth}px</span>
                    <button
                      onClick={() => setChatOpen(false)}
                      className="px-2 py-1 flex items-center gap-1.5 rounded-lg bg-white/10 hover:bg-rose-500/20 text-white/80 hover:text-rose-300 transition-all cursor-pointer border border-white/10 hover:border-rose-500/30 font-bold"
                      title="Close AI Assistant (Esc)"
                    >
                      <X size={13} />
                      <span className="text-[9px] uppercase tracking-wider">Close</span>
                    </button>
                  </div>
                </div>

              {/* Template selection state toast within standard workspace */}
              {selectedTemplateDraft && (
                <div className="bg-orange-950/20 border-b border-orange-500/20 p-2.5 px-4 text-[10px] font-mono text-orange-300 flex items-center justify-between">
                  <span className="truncate">Active preset parameters active!</span>
                  <div className="w-1.5 h-1.5 rounded-full bg-orange-400 animate-ping" />
                </div>
              )}

              <div className="flex-1 w-full overflow-hidden relative flex flex-col min-h-0">
                <Suspense fallback={<div className="p-6 text-xs text-zinc-500 text-center animate-pulse mt-10">Starting communication channel...</div>}>
                  <AIAssistant
                    user={user}
                    files={files}
                    activeFileId={activeFileId}
                    setActiveFileId={setActiveFileId}
                    onCommandSelect={handleSelectPaletteCommand}
                    onAgentAction={handleAgentAction}
                    sessions={sessions}
                    activeSessionId={activeSessionId}
                    onCreateSession={() => createNewSession()}
                    onClose={() => setChatOpen(false)}
                    onUpdateSession={(s) =>
                      setSessions((prev) =>
                        prev.map((x) => (x.id === s.id ? s : x)),
                      )
                    }
                    onForkSession={(forked) => {
                      setSessions((prev) => [forked, ...prev]);
                      setActiveSessionId(forked.id);
                    }}
                    isProcessing={isProcessing}
                    isCompactMode={chatCompactMode}
                    onToggleCompactMode={onToggleChatCompact}
                    onSendMessage={(userMsg, atts, modelId, isCompact) => {
                      const compositeMsg = injectedContextPrompt
                        ? `${userMsg}\n\n[PROMPT BOILERPLATE TEMPLATE MODULE ENFORCED]:\n${injectedContextPrompt}`
                        : userMsg;
                      sendMessage(compositeMsg, atts, modelId, isCompact);
                    }}
                    onStopProcessing={stopProcessing}
                    onUploadFiles={handleUploadFiles}
                    onRedirectToGameEngine={(prompt) => {
                      setInjectedContextPrompt(prompt);
                      setActiveRightTab("preview");
                      setChatOpen(true);
                      addLog("info", `Autonomous Game Director engaged: Redirected request to Live Preview Workspace.`, "GAME_ENGINE");
                    }}
                    activeRightTab={activeRightTab}
                    splitSubTab={splitSubTab}
                  />
                </Suspense>
              </div>
            </motion.div>
          </>
        )}
        </AnimatePresence>

      </div>

      {/* Floating widgets are handled automatically by the orchestrator */}

      {/* Resource Diagnostics Overlay */}
      <AnimatePresence>
        {showHealth && (
          <div className="fixed inset-0 z-[300] flex items-center justify-center p-6 sm:p-20 bg-black/60 backdrop-blur-md">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="w-full max-w-2xl bg-zinc-900 border border-white/10 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-full"
            >
              <div className="h-12 shrink-0 bg-black border-b border-white/5 flex items-center justify-between px-6">
                 <span className="text-[10px] font-black uppercase tracking-[0.2em] text-white/40">Hardware Abstraction Layer</span>
                 <button onClick={() => setShowHealth(false)} className="text-white/20 hover:text-white transition-colors">
                   <Plus className="rotate-45" size={18} />
                 </button>
              </div>
              <div className="flex-1 overflow-y-auto custom-scrollbar overflow-x-hidden">
                 <Suspense fallback={<div className="p-6 text-xs text-white/30 text-center animate-pulse font-mono">Loading Hardware Diagnostics...</div>}>
<ResourceDashboard 
                  stats={systemStats}
                  onClose={() => setShowHealth(false)}
                  activeSessionId={activeSessionId}
                  perfMode={perfMode}
                  onTogglePerfMode={onTogglePerfMode}
                  chatCompactMode={chatCompactMode}
                  onToggleChatCompact={onToggleChatCompact}
                  onOptimizeMemory={onOptimizeMemory}
                 />
                 </Suspense>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Sticky Workflows & Moat Modals */}
      <Suspense fallback={null}>
        <GitHubSyncModal
          isOpen={showGitHubModal}
          onClose={() => setShowGitHubModal(false)}
          files={files}
          currentSessionTitle={sessions.find(s => s.id === activeSessionId)?.title}
        />

        <DeployModal
          isOpen={showDeployModal}
          onClose={() => setShowDeployModal(false)}
          files={files}
          currentSessionTitle={sessions.find(s => s.id === activeSessionId)?.title}
        />

        <CollaborationModal
          isOpen={showCollaborationModal}
          onClose={() => setShowCollaborationModal(false)}
          currentSessionTitle={sessions.find(s => s.id === activeSessionId)?.title}
          onLaunchPresentationMode={() => {
            setActiveRightTab('preview');
            setSidebarOpen(false);
            setChatOpen(false);
          }}
        />

        <MoatInspectorModal
          isOpen={showMoatModal}
          onClose={() => setShowMoatModal(false)}
          files={files}
          currentSessionTitle={sessions.find(s => s.id === activeSessionId)?.title}
        />

        <ExtensionMarketplaceModal
          isOpen={showExtensionMarketplace}
          onClose={() => setShowExtensionMarketplace(false)}
        />

        {showLinuxSandbox && (
          <div 
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-in fade-in duration-200"
            onClick={() => setShowLinuxSandbox(false)}
          >
            <div 
              className="w-full max-w-4xl h-[650px] shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <LinuxSandboxControlPanel onClose={() => setShowLinuxSandbox(false)} />
            </div>
          </div>
        )}

        {showVisualDebugger && (
          <div className="fixed bottom-12 right-6 z-50 w-96 h-96 shadow-2xl animate-in slide-in-from-bottom duration-200">
            <VisualDebuggerPanel
              filePath={files.find(f => f.id === activeFileId)?.name || 'active.ts'}
              breakpoints={fileBreakpoints[files.find(f => f.id === activeFileId)?.name || ''] || []}
              onClearBreakpoints={() => {
                const fname = files.find(f => f.id === activeFileId)?.name;
                if (fname) setFileBreakpoints(prev => ({ ...prev, [fname]: [] }));
              }}
              onRemoveBreakpoint={(line) => {
                const fname = files.find(f => f.id === activeFileId)?.name;
                if (fname) {
                  setFileBreakpoints(prev => ({
                    ...prev,
                    [fname]: (prev[fname] || []).filter(l => l !== line)
                  }));
                }
              }}
            />
          </div>
        )}

        <CommandPalette
          isOpen={showCommandPalette}
          onClose={() => setShowCommandPalette(false)}
          onSelectCommand={handleSelectPaletteCommand}
          files={files}
        />
      </Suspense>

      {/* Focus Mode Overlay Controls */}
      <AnimatePresence>
        {focusMode && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="fixed bottom-10 left-1/2 -translate-x-1/2 z-[200] flex items-center gap-3"
          >
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setFocusMode(false)}
              className="px-6 py-3 bg-white text-black text-[10px] font-black uppercase tracking-[0.2em] rounded-full shadow-2xl shadow-white/10 flex items-center gap-2"
            >
              <Minimize2 size={14} />
              Exit Focus
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setZenMode(!zenMode)}
              className={`p-3 rounded-full shadow-2xl transition-all ${zenMode ? 'bg-emerald-500 text-black' : 'bg-black/60 text-white border border-white/10'}`}
            >
              <Wind size={16} />
            </motion.button>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
};

export default PCWorkspace;
