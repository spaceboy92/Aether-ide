import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { User, Globe } from 'lucide-react';

interface PresenceUser {
  id: string;
  name: string;
  photoURL: string;
}

interface PresenceBarProps {
  users: PresenceUser[];
}

const PresenceBar: React.FC<PresenceBarProps> = ({ users }) => {
  return (
    <div className="flex items-center gap-3 px-4 py-2 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-md">
        <div className="flex items-center gap-2 pr-3 border-r border-white/10">
            <Globe size={14} className="text-emerald-500 animate-pulse" />
            <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Global Link</span>
        </div>
        <div className="flex -space-x-2">
            <AnimatePresence>
                {users.map((u, i) => (
                    <motion.div 
                        key={u.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 10 }}
                        title={u.name}
                        className="relative group"
                    >
                        <img 
                            src={u.photoURL || `https://ui-avatars.com/api/?name=${u.name}&background=random`} 
                            alt={u.name} 
                            className="w-7 h-7 rounded-lg border-2 border-black object-cover cursor-pointer hover:scale-110 transition-transform"
                        />
                        <div className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-emerald-500 border-2 border-black rounded-full" />
                        
                        {/* Tooltip */}
                        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-white text-black text-[9px] font-bold rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
                            {u.name}
                        </div>
                    </motion.div>
                ))}
            </AnimatePresence>
            {users.length === 0 && (
                <div className="w-7 h-7 rounded-lg bg-white/5 border-2 border-black flex items-center justify-center">
                    <User size={12} className="text-white/20" />
                </div>
            )}
        </div>
        <div className="text-[10px] font-bold text-emerald-500/80 uppercase tracking-widest ml-1">
            {users.length} Node{users.length !== 1 ? 's' : ''} Active
        </div>
    </div>
  );
};

export default PresenceBar;
