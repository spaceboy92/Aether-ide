import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Command, FileText, Settings, Zap, History, Globe, X, Keyboard, BookOpen, Terminal, Blocks, ShieldCheck, Cpu, Database, Wand2, Gauge, Palette, Volume2, Network } from 'lucide-react';
import { FileNode } from '../../types';

interface CommandPaletteProps {
  files: FileNode[];
  onOpenFile: (fileId: string) => void;
  onExecuteCommand: (cmd: string) => void;
}

const CommandPalette: React.FC<CommandPaletteProps> = ({ files, onOpenFile, onExecuteCommand }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Toggle palette on cmd/ctrl+k or cmd/ctrl+p
      if ((e.metaKey || e.ctrlKey) && (e.key === 'k' || e.key === 'p')) {
        e.preventDefault();
        setIsOpen(prev => !prev);
      }
      if (e.key === 'Escape') setIsOpen(false);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
      setSelectedIndex(0);
    }
  }, [isOpen]);

  const commands = [
    { id: 'api_playground', label: 'Open REST API Playground', icon: Globe, action: () => onExecuteCommand('open-api-playground') },
    { id: 'security_auditor', label: 'Run Security & AI Quality Audit', icon: ShieldCheck, action: () => onExecuteCommand('open-security-auditor') },
    { id: 'database_studio', label: 'Open Database & Storage Studio', icon: Database, action: () => onExecuteCommand('open-database-studio') },
    { id: 'regex_studio', label: 'Open RegEx & Data Transformer', icon: Wand2, action: () => onExecuteCommand('open-regex-studio') },
    { id: 'ui_studio', label: 'Open UI Component & Theme Studio', icon: Palette, action: () => onExecuteCommand('open-ui-studio') },
    { id: 'audio_synth', label: 'Open Web Audio Sound FX Studio', icon: Volume2, action: () => onExecuteCommand('open-audio-synth') },
    { id: 'dependency_graph', label: 'Open Module Graph Visualizer', icon: Network, action: () => onExecuteCommand('open-dependency-graph') },
    { id: 'performance_profiler', label: 'Open Performance Profiler', icon: Gauge, action: () => onExecuteCommand('open-profiler') },
    { id: 'extensions', label: 'Open Extensions Marketplace', icon: Blocks, action: () => onExecuteCommand('open-extensions') },
    { id: 'doctor', label: 'Run Aether System Health Doctor', icon: ShieldCheck, action: () => onExecuteCommand('run-doctor') },
    { id: 'new_session', label: 'Start New AI Session', icon: Zap, action: () => onExecuteCommand('new_session') },
    { id: 'settings', label: 'Open System Settings', icon: Settings, action: () => onExecuteCommand('open_settings') },
    { id: 'deploy', label: 'Global Deployment', icon: Globe, action: () => onExecuteCommand('deploy') },
    { id: 'format_doc', label: 'AI Code Auto-Format', icon: FileText, action: () => onExecuteCommand('format-doc') },
    { id: 'explain_code', label: 'AI Explain Codebase', icon: Zap, action: () => onExecuteCommand('explain_code') },
    { id: 'optimize_code', label: 'AI Optimize Performance', icon: Zap, action: () => onExecuteCommand('optimize_code') },
    { id: 'generate_tests', label: 'AI Generate Tests', icon: FileText, action: () => onExecuteCommand('generate_tests') }
  ];

  const filteredFiles = files.filter(f => f.name.toLowerCase().includes(query.toLowerCase())).slice(0, 5);
  const filteredCommands = commands.filter(c => c.label.toLowerCase().includes(query.toLowerCase()));
  
  const results = [...filteredCommands, ...filteredFiles.map(f => ({ ...f, label: f.name, id: f.id, icon: FileText, action: () => onOpenFile(f.id) }))];

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => (prev + 1) % results.length);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => (prev - 1 + results.length) % results.length);
    } else if (e.key === 'Enter') {
      const selected = results[selectedIndex];
      if (selected) {
        selected.action();
        setIsOpen(false);
      }
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsOpen(false)}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[9998]"
          />
          <motion.div 
            initial={{ opacity: 0, scale: 0.95, y: -20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -20 }}
            className="fixed top-24 left-1/2 -translate-x-1/2 w-full max-w-[620px] macos-glass border border-white/20 rounded-3xl shadow-[0_25px_60px_rgba(0,0,0,0.8)] overflow-hidden z-[9999]"
          >
            <div className="flex items-center gap-3 p-4 border-b border-white/5">
              <Search size={20} className="text-white/20" />
              <input 
                ref={inputRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Search files or execute commands... (Ctrl+P)"
                className="flex-1 bg-transparent border-none outline-none text-white font-medium placeholder:text-white/10"
              />
              <div className="flex items-center gap-1 px-1.5 py-0.5 bg-white/5 border border-white/10 rounded text-[10px] text-white/40 font-bold">
                <Command size={10} />
                <span>P</span>
              </div>
            </div>

            <div className="max-h-[400px] overflow-y-auto p-2">
              {results.length > 0 ? (
                results.map((res, i) => (
                  <div 
                    key={res.id}
                    onMouseEnter={() => setSelectedIndex(i)}
                    onClick={() => { res.action(); setIsOpen(false); }}
                    className={`flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all ${i === selectedIndex ? 'bg-white/10 text-white' : 'text-white/40 hover:bg-white/5'}`}
                  >
                    <res.icon size={16} />
                    <span className="flex-1 text-sm font-medium">{res.label}</span>
                    {i === selectedIndex && <div className="text-[10px] font-bold text-aether-accent uppercase tracking-widest">Enter</div>}
                  </div>
                ))
              ) : (
                <div className="p-8 text-center text-white/20 italic text-sm">No results found mapping cognitive pathways...</div>
              )}
            </div>

            <div className="p-2 border-t border-white/5 flex items-center justify-between">
                <div className="flex gap-4">
                    <span className="text-[10px] text-white/20 uppercase font-bold flex items-center gap-1.5">
                        <kbd className="px-1 py-0.5 bg-white/5 rounded border border-white/10">↑↓</kbd> Navigate
                    </span>
                    <span className="text-[10px] text-white/20 uppercase font-bold flex items-center gap-1.5">
                        <kbd className="px-1 py-0.5 bg-white/5 rounded border border-white/10">ESC</kbd> Close
                    </span>
                </div>
                <div className="text-[10px] text-aether-accent font-bold uppercase tracking-widest flex items-center gap-1">
                    <Zap size={10} /> Aether Index v1.0
                </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default CommandPalette;
