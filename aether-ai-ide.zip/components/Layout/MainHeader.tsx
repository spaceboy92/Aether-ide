import React, { useState, useEffect } from "react";
import { 
  ChevronLeft, Share2, Download, Smartphone, Camera, MessageSquare, Code2, Github, Sparkles, Workflow, Settings,
  Maximize2, Minimize2, Wind, Activity, Rocket, Users, ShieldCheck, Wifi, Battery, Command, Search, Sliders, Moon, Volume2, Cpu, Check, Terminal, Globe, Zap, PanelLeft, PanelLeftClose, PanelRightClose, PanelRight, X
} from "lucide-react";
import AppLogo from "../UI/AppLogo";
import DynamicIsland from "../UI/DynamicIsland";
import { motion, AnimatePresence } from "motion/react";

interface MainHeaderProps {
  activeSession: any;
  activeSessionId: string | null;
  activeTab: string;
  setActiveTab: (tab: any) => void;
  setShowMobileMenu: (show: boolean) => void;
  setActiveSessionId: (id: string | null) => void;
  handleShareSession: () => void;
  handleDownloadProject: () => void;
  systemStats: any;
  onOpenSettings?: () => void;
  focusMode: boolean;
  setFocusMode: (val: boolean) => void;
  zenMode: boolean;
  setZenMode: (val: boolean) => void;
  autoPilotMode?: boolean;
  setAutoPilotMode?: (val: boolean) => void;
  onOpenHealth?: () => void;
  onOpenGitHub?: () => void;
  onOpenDeploy?: () => void;
  onOpenCollaboration?: () => void;
  onOpenMoat?: () => void;
  onOpenExtensions?: () => void;
  onOpenDebugger?: () => void;
  onOpenSandbox?: () => void;
  chatOpen?: boolean;
  setChatOpen?: (val: boolean) => void;
  sidebarOpen?: boolean;
  setSidebarOpen?: (val: boolean) => void;
  hasWebFiles?: boolean;
}

export const MainHeader: React.FC<MainHeaderProps> = ({
  activeSession,
  activeSessionId,
  activeTab,
  setActiveTab,
  setShowMobileMenu,
  setActiveSessionId,
  handleShareSession,
  handleDownloadProject,
  systemStats,
  onOpenSettings,
  focusMode,
  setFocusMode,
  zenMode,
  setZenMode,
  autoPilotMode = true,
  setAutoPilotMode,
  onOpenHealth,
  onOpenGitHub,
  onOpenDeploy,
  onOpenCollaboration,
  onOpenMoat,
  onOpenExtensions,
  onOpenDebugger,
  onOpenSandbox,
  chatOpen = true,
  setChatOpen,
  sidebarOpen = true,
  setSidebarOpen,
  hasWebFiles = true,
}) => {
  const [showAppleMenu, setShowAppleMenu] = useState(false);
  const [showControlCenter, setShowControlCenter] = useState(false);
  const [currentTime, setCurrentTime] = useState("");

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const tabs = [
    { id: "editor", icon: Code2, label: "Code" },
    ...(hasWebFiles ? [
      { id: "preview", icon: Camera, label: "Preview" },
      { id: "split", icon: Workflow, label: "Split" }
    ] : []),
    { id: "chat", icon: MessageSquare, label: "Assistant" },
  ];

  return (
    <header className="flex h-10 items-center justify-between px-2 sm:px-3 shrink-0 relative z-[60] macos-glass border-b border-white/10 text-xs select-none max-w-full">
      {/* Left Section: Aether Logo, Session Info & Sidebar Toggle */}
      <div className="flex items-center gap-1.5 sm:gap-2.5">
        {/* Logo & Dropdown */}
        <div className="relative">
          <button 
            onClick={() => setShowAppleMenu(!showAppleMenu)}
            className="p-1 hover:bg-white/10 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer font-bold text-white/90"
            title="Aether Preferences"
          >
            <AppLogo size={18} />
            <span className="font-bold text-sm tracking-tight text-white hidden xl:inline">Aether</span>
          </button>

          {/* System Dropdown Menu */}
          <AnimatePresence>
            {showAppleMenu && (
              <motion.div 
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 5 }}
                className="absolute left-0 top-9 w-60 macos-glass border border-white/15 rounded-2xl p-2 shadow-2xl z-50 text-[11px] text-zinc-200"
              >
                <div className="px-2.5 py-1.5 font-bold text-white border-b border-white/10 mb-1 flex items-center justify-between">
                  <span>Aether IDE</span>
                  <span className="text-[9px] text-cyan-400 font-mono">v4.8</span>
                </div>
                <button onClick={() => { onOpenSettings?.(); setShowAppleMenu(false); }} className="w-full text-left px-2.5 py-2 rounded-xl hover:bg-blue-600 hover:text-white transition-colors cursor-pointer flex items-center justify-between font-medium">
                  <span>Settings...</span>
                  <Settings size={13} />
                </button>
                <button onClick={() => { onOpenHealth?.(); setShowAppleMenu(false); }} className="w-full text-left px-2.5 py-2 rounded-xl hover:bg-blue-600 hover:text-white transition-colors cursor-pointer flex items-center justify-between font-medium">
                  <span>System Status</span>
                  <Activity size={13} />
                </button>
                <div className="my-1 border-t border-white/10" />
                <button onClick={() => { handleDownloadProject(); setShowAppleMenu(false); }} className="w-full text-left px-2.5 py-2 rounded-xl hover:bg-blue-600 hover:text-white transition-colors cursor-pointer flex items-center justify-between font-medium">
                  <span>Export ZIP Archive</span>
                  <Download size={13} />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Sidebar Quick Toggle Button */}
        {setSidebarOpen && (
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-[10px] font-bold border transition-all cursor-pointer ${
              sidebarOpen 
                ? "bg-blue-500/20 text-blue-300 border-blue-500/40 shadow-sm" 
                : "bg-white/5 text-zinc-400 hover:text-white border-white/10"
            }`}
            title={sidebarOpen ? "Close File Explorer Sidebar" : "Open File Explorer Sidebar"}
          >
            {sidebarOpen ? <PanelLeftClose size={13} /> : <PanelLeft size={13} />}
            <span className="hidden lg:inline">{sidebarOpen ? "Files" : "Files"}</span>
          </button>
        )}
      </div>

      {/* Center Section: Dynamic Island & iOS Segmented Tab Control */}
      <div className="flex items-center gap-2 sm:gap-3">
        <div className="hidden md:block">
          <DynamicIsland
            activeSessionTitle={activeSession?.title}
            systemStats={systemStats}
            autoPilotMode={autoPilotMode}
            setAutoPilotMode={setAutoPilotMode}
            focusMode={focusMode}
            setFocusMode={setFocusMode}
            zenMode={zenMode}
            setZenMode={setZenMode}
            onOpenDeploy={onOpenDeploy}
            onOpenHealth={onOpenHealth}
          />
        </div>

        {activeSessionId && (
          <div className="flex items-center p-0.5 bg-black/40 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-inner max-w-full">
            {tabs.map((tab) => {
              const isActive = tab.id === 'chat' ? chatOpen : activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    if (tab.id === 'chat') {
                      if (setChatOpen) setChatOpen(!chatOpen);
                    } else {
                      setActiveTab(tab.id as any);
                    }
                  }}
                  className={`relative px-2 sm:px-3 py-1 rounded-xl text-[10px] font-semibold transition-all flex items-center gap-1.5 cursor-pointer ${
                    isActive ? "text-white shadow-md font-bold" : "text-zinc-400 hover:text-white"
                  }`}
                >
                  {isActive && (
                    <motion.div 
                      layoutId="macos-active-tab-indicator"
                      className="absolute inset-0 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl shadow-md border border-white/20"
                      transition={{ type: 'spring', bounce: 0.15, duration: 0.4 }}
                    />
                  )}
                  <span className="relative z-10 flex items-center gap-1 sm:gap-1.5">
                    <tab.icon size={12} />
                    <span className="hidden sm:inline">{tab.label}</span>
                  </span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* Right Section: AI Chat Toggle, Deploy & Control Center */}
      <div className="flex items-center gap-1.5 sm:gap-2 font-sans text-xs text-zinc-300">
        {/* Prominent AI Chat Toggle Button (Desktop only - mobile uses central tab bar) */}
        {setChatOpen && (
          <button
            onClick={() => setChatOpen(!chatOpen)}
            className={`hidden md:flex items-center gap-1.5 px-3 py-1 rounded-xl text-[11px] font-bold border transition-all cursor-pointer shadow-sm ${
              chatOpen 
                ? "bg-gradient-to-r from-orange-500/25 to-amber-500/25 text-orange-300 border-orange-500/50 shadow-[0_0_12px_rgba(249,115,22,0.2)]" 
                : "bg-white/5 text-zinc-300 hover:text-white border-white/10 hover:bg-white/10"
            }`}
            title={chatOpen ? "Close Assistant Panel" : "Open Assistant Panel"}
          >
            <MessageSquare size={13} className={chatOpen ? "text-orange-400" : "text-zinc-400"} />
            <span>Assistant</span>
            {chatOpen ? <PanelRightClose size={12} className="text-orange-400/80" /> : <PanelRight size={12} className="text-zinc-500" />}
          </button>
        )}

        {/* Linux Sandbox Button */}
        {onOpenSandbox && (
          <button onClick={onOpenSandbox} className="hidden xl:flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-[10px] hover:bg-emerald-500/20 cursor-pointer font-bold transition-all" title="Aether Cloud Linux Sandbox Control Panel">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Linux VM</span>
          </button>
        )}

        {/* Extensions Button */}
        {onOpenExtensions && (
          <button onClick={onOpenExtensions} className="hidden xl:flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-300 text-[10px] hover:bg-purple-500/20 cursor-pointer font-bold transition-all" title="Extension Marketplace">
            <Sparkles size={12} />
            <span>Marketplace</span>
          </button>
        )}

        {/* Debugger Button */}
        {onOpenDebugger && (
          <button onClick={onOpenDebugger} className="hidden xl:flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-[10px] hover:bg-amber-500/20 cursor-pointer font-bold transition-all" title="DAP Visual Debugger">
            <Cpu size={12} />
            <span>Debugger</span>
          </button>
        )}

        {/* Quick Deploy Button */}
        {onOpenDeploy && (
          <button onClick={onOpenDeploy} className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-[10px] hover:bg-cyan-500/20 cursor-pointer font-bold transition-all">
            <Rocket size={12} />
            <span>Deploy</span>
          </button>
        )}

        {/* Control Center Toggle */}
        <div className="relative">
          <button 
            onClick={() => setShowControlCenter(!showControlCenter)}
            className="p-1.5 hover:bg-white/10 rounded-xl transition-colors cursor-pointer text-zinc-300 flex items-center gap-1"
            title="Control Center"
          >
            <Sliders size={14} />
          </button>

          {/* Control Center Popover */}
          <AnimatePresence>
            {showControlCenter && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 10 }}
                className="absolute right-0 top-9 w-72 macos-glass border border-white/15 rounded-2xl p-3 shadow-2xl z-50 text-xs text-zinc-200 font-sans space-y-3"
              >
                <div className="flex items-center justify-between border-b border-white/10 pb-2">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    <Sliders size={14} className="text-blue-400" /> Control Center
                  </span>
                  <span className="text-[10px] text-zinc-400 font-mono">Status</span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button 
                    onClick={() => setZenMode(!zenMode)}
                    className={`p-2.5 rounded-xl border flex flex-col items-start gap-1 transition-all cursor-pointer ${
                      zenMode ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300' : 'bg-white/5 border-white/10 text-zinc-300 hover:bg-white/10'
                    }`}
                  >
                    <Wind size={16} />
                    <span className="text-[11px] font-bold">Zen Workspace</span>
                    <span className="text-[9px] opacity-70">{zenMode ? 'On' : 'Off'}</span>
                  </button>

                  <button 
                    onClick={() => setFocusMode(!focusMode)}
                    className={`p-2.5 rounded-xl border flex flex-col items-start gap-1 transition-all cursor-pointer ${
                      focusMode ? 'bg-purple-500/20 border-purple-500/40 text-purple-300' : 'bg-white/5 border-white/10 text-zinc-300 hover:bg-white/10'
                    }`}
                  >
                    <Maximize2 size={16} />
                    <span className="text-[11px] font-bold">Focus Mode</span>
                    <span className="text-[9px] opacity-70">{focusMode ? 'On' : 'Off'}</span>
                  </button>
                </div>

                <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 space-y-1.5">
                  <div className="flex justify-between text-[10px] text-zinc-400 font-mono">
                    <span>CPU LOAD</span>
                    <span className="text-emerald-400">{systemStats.cpu}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-black/40 rounded-full overflow-hidden">
                    <div className="h-full bg-blue-500 transition-all duration-500" style={{ width: `${systemStats.cpu}%` }} />
                  </div>
                </div>

                <div className="pt-1 flex justify-between items-center text-[10px] text-zinc-400 border-t border-white/10">
                  <span className="flex items-center gap-1"><Wifi size={12} className="text-emerald-400" /> Connected</span>
                  <span className="flex items-center gap-1"><Battery size={12} className="text-emerald-400" /> 100%</span>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Time Display */}
        <span className="hidden sm:inline font-semibold text-white tracking-tight ml-1">{currentTime || "10:28 AM"}</span>
      </div>
    </header>
  );
};

export default MainHeader;
