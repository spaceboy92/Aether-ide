import React from 'react';
import { 
  FolderClosed, 
  Search, 
  Bot, 
  Settings, 
  Terminal, 
  Blocks, 
  GitBranch, 
  Cpu
} from 'lucide-react';
import { motion } from 'motion/react';

export type SidebarMode = 
  | 'files' 
  | 'search' 
  | 'chat'
  | 'history' 
  | 'tasks' 
  | 'uistudio'
  | 'terminal' 
  | 'settings' 
  | string;

interface ActivityBarProps {
  activeMode: SidebarMode | null;
  onChange: (mode: SidebarMode | null) => void;
}

export interface ActivityItem {
  id: SidebarMode;
  label: string;
  icon: any;
  shortcut?: string;
}

export const ActivityBar: React.FC<ActivityBarProps> = ({ activeMode, onChange }) => {
  // Essential VS Code Sidebar Navigation Items
  const primaryItems: ActivityItem[] = [
    { id: 'files', label: 'Explorer', icon: FolderClosed },
    { id: 'search', label: 'Search', icon: Search },
    { id: 'history', label: 'Source Control', icon: GitBranch },
    { id: 'chat', label: 'AI Assistant', icon: Bot },
    { id: 'tasks', label: 'Task Runner', icon: Cpu },
    { id: 'uistudio', label: 'Tools & Extensions', icon: Blocks },
  ];

  const secondaryItems: ActivityItem[] = [
    { id: 'terminal', label: 'Terminal', icon: Terminal },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <aside 
      className="hidden md:flex flex-col items-center justify-between py-2 px-1 bg-zinc-950/80 border-r border-white/10 shrink-0 w-12 z-30 select-none transition-all"
      aria-label="Activity Bar"
    >
      {/* Primary Navigation Icons */}
      <div className="flex flex-col items-center gap-1 w-full">
        {primaryItems.map((item) => {
          const isActive = activeMode === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => onChange(isActive ? null : item.id)}
              className={`
                relative group w-10 h-10 rounded-lg flex items-center justify-center transition-all cursor-pointer
                ${isActive 
                  ? 'text-white bg-white/10' 
                  : 'text-zinc-400 hover:text-zinc-100 hover:bg-white/5'}
              `}
              title={item.label}
              aria-label={item.label}
              aria-pressed={isActive}
            >
              {/* VS Code Active Bar Indicator */}
              {isActive && (
                <motion.div 
                  layoutId="active-sidebar-indicator"
                  className="absolute left-0 top-2 bottom-2 w-0.5 bg-cyan-400 rounded-r-full shadow-[0_0_8px_rgba(34,211,238,0.8)]" 
                />
              )}

              <Icon size={19} className={isActive ? 'text-cyan-400' : 'text-zinc-400 group-hover:text-zinc-200'} />

              {/* Clean Tooltip */}
              <div className="absolute left-12 top-1/2 -translate-y-1/2 hidden group-hover:block px-2 py-1 rounded bg-zinc-900 border border-zinc-700 text-[11px] font-medium text-white whitespace-nowrap shadow-xl z-50 pointer-events-none">
                {item.label}
              </div>
            </button>
          );
        })}
      </div>

      {/* Secondary Bottom Icons (Terminal & Settings) */}
      <div className="flex flex-col items-center gap-1 w-full pt-2 border-t border-white/10">
        {secondaryItems.map((item) => {
          const isActive = activeMode === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => onChange(isActive ? null : item.id)}
              className={`
                relative group w-10 h-10 rounded-lg flex items-center justify-center transition-all cursor-pointer
                ${isActive 
                  ? 'text-white bg-white/10' 
                  : 'text-zinc-400 hover:text-zinc-100 hover:bg-white/5'}
              `}
              title={item.label}
              aria-label={item.label}
              aria-pressed={isActive}
            >
              {isActive && (
                <motion.div 
                  layoutId="active-sidebar-indicator"
                  className="absolute left-0 top-2 bottom-2 w-0.5 bg-cyan-400 rounded-r-full shadow-[0_0_8px_rgba(34,211,238,0.8)]" 
                />
              )}

              <Icon size={19} className={isActive ? 'text-cyan-400' : 'text-zinc-400 group-hover:text-zinc-200'} />

              <div className="absolute left-12 top-1/2 -translate-y-1/2 hidden group-hover:block px-2 py-1 rounded bg-zinc-900 border border-zinc-700 text-[11px] font-medium text-white whitespace-nowrap shadow-xl z-50 pointer-events-none">
                {item.label}
              </div>
            </button>
          );
        })}
      </div>
    </aside>
  );
};

export default ActivityBar;

