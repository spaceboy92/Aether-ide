import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Sliders, 
  X, 
  RotateCcw, 
  Layout, 
  Type, 
  Sparkles, 
  Layers, 
  Save, 
  Bookmark, 
  Trash2, 
  SplitSquareVertical, 
  SplitSquareHorizontal, 
  Maximize2, 
  Eye, 
  Terminal, 
  Bot, 
  Check, 
  Palette,
  Columns,
  Square
} from "lucide-react";

export interface WorkspaceConfig {
  sidebarWidth: number;
  chatWidth: number;
  splitRatio: number; // 0.2 to 0.8 (percentage of left panel in split mode)
  splitOrientation: "horizontal" | "vertical";
  terminalHeight: number;
  editorFontSize: number;
  editorLineHeight: number;
  editorFont: string;
  minimapEnabled: boolean;
  ligaturesEnabled: boolean;
  panelOpacity: number; // 30 to 100
  backdropBlur: number; // 0 to 32
  borderRadius: number; // 0 to 20
  uiDensity: "compact" | "comfortable" | "spacious";
  accentColor: string;
  glowIntensity: number; // 0 to 100
  showActivityBar: boolean;
  showFooter: boolean;
  showSubHeader: boolean;
}

export const DEFAULT_WORKSPACE_CONFIG: WorkspaceConfig = {
  sidebarWidth: 300,
  chatWidth: 360,
  splitRatio: 0.5,
  splitOrientation: "horizontal",
  terminalHeight: 280,
  editorFontSize: 13,
  editorLineHeight: 1.6,
  editorFont: "'JetBrains Mono', monospace",
  minimapEnabled: true,
  ligaturesEnabled: true,
  panelOpacity: 85,
  backdropBlur: 16,
  borderRadius: 12,
  uiDensity: "comfortable",
  accentColor: "#f97316", // Aether Orange
  glowIntensity: 70,
  showActivityBar: true,
  showFooter: true,
  showSubHeader: true
};

export const ACCENT_PALETTES = [
  { name: "Aether Orange", color: "#f97316", glow: "rgba(249, 115, 22, 0.4)" },
  { name: "Cyber Cyan", color: "#06b6d4", glow: "rgba(6, 182, 212, 0.4)" },
  { name: "Matrix Emerald", color: "#10b981", glow: "rgba(16, 185, 129, 0.4)" },
  { name: "Deep Violet", color: "#8b5cf6", glow: "rgba(139, 92, 246, 0.4)" },
  { name: "Crimson Rose", color: "#f43f5e", glow: "rgba(244, 63, 94, 0.4)" },
  { name: "Solar Amber", color: "#f59e0b", glow: "rgba(245, 158, 11, 0.4)" },
  { name: "Electric Blue", color: "#3b82f6", glow: "rgba(59, 130, 246, 0.4)" },
  { name: "Monochrome Silver", color: "#e4e4e7", glow: "rgba(228, 228, 231, 0.3)" }
];

export const WORKSPACE_PRESETS: { name: string; desc: string; icon: any; config: Partial<WorkspaceConfig> }[] = [
  {
    name: "Full Studio Tri-Pane",
    desc: "Balanced 3-column workspace with file explorer, split code/preview, and AI copilot.",
    icon: Columns,
    config: {
      sidebarWidth: 280,
      chatWidth: 340,
      splitRatio: 0.5,
      splitOrientation: "horizontal",
      editorFontSize: 13,
      terminalHeight: 240,
      uiDensity: "comfortable"
    }
  },
  {
    name: "Pure Code Focus",
    desc: "Maximized central code view with generous typography and no visual distractions.",
    icon: Square,
    config: {
      sidebarWidth: 220,
      chatWidth: 280,
      splitRatio: 0.7,
      editorFontSize: 15,
      editorLineHeight: 1.7,
      uiDensity: "spacious"
    }
  },
  {
    name: "AI Pair Architect",
    desc: "Expansive AI assistant panel with side-by-side prompt tuning and direct code sync.",
    icon: Bot,
    config: {
      sidebarWidth: 240,
      chatWidth: 500,
      splitRatio: 0.4,
      editorFontSize: 13,
      uiDensity: "comfortable"
    }
  },
  {
    name: "Live Web & Game Canvas",
    desc: "Prioritizes live interactive runtime preview with a compact code buffer.",
    icon: Eye,
    config: {
      sidebarWidth: 240,
      chatWidth: 300,
      splitRatio: 0.35,
      splitOrientation: "horizontal",
      editorFontSize: 12
    }
  },
  {
    name: "DevOps & Shell Matrix",
    desc: "Extended bottom terminal drawer with high-density system metrics.",
    icon: Terminal,
    config: {
      sidebarWidth: 260,
      chatWidth: 320,
      terminalHeight: 460,
      editorFontSize: 12,
      uiDensity: "compact"
    }
  }
];

interface WorkspaceSlidersModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: WorkspaceConfig;
  onChangeConfig: (newConfig: WorkspaceConfig) => void;
  onResetDefaults: () => void;
  activeRightTab: "dashboard" | "editor" | "preview" | "gallery" | "split";
  onChangeRightTab: (tab: "dashboard" | "editor" | "preview" | "gallery" | "split") => void;
}

export const WorkspaceSlidersModal: React.FC<WorkspaceSlidersModalProps> = ({
  isOpen,
  onClose,
  config,
  onChangeConfig,
  onResetDefaults,
  activeRightTab,
  onChangeRightTab
}) => {
  const [activeTab, setActiveTab] = useState<"layout" | "editor" | "style" | "presets">("layout");
  const [customSlots, setCustomSlots] = useState<{ id: string; name: string; config: WorkspaceConfig }[]>(() => {
    try {
      const saved = localStorage.getItem("aether_workspace_custom_slots");
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [slotNameInput, setSlotNameInput] = useState("");

  const updateSetting = <K extends keyof WorkspaceConfig>(key: K, value: WorkspaceConfig[K]) => {
    onChangeConfig({
      ...config,
      [key]: value
    });
  };

  const handleSaveSlot = () => {
    const name = slotNameInput.trim() || `Layout ${customSlots.length + 1}`;
    const newSlot = {
      id: Date.now().toString(),
      name,
      config: { ...config }
    };
    const updated = [...customSlots, newSlot];
    setCustomSlots(updated);
    try {
      localStorage.setItem("aether_workspace_custom_slots", JSON.stringify(updated));
    } catch (e) {
      console.warn("Could not save slots", e);
    }
    setSlotNameInput("");
  };

  const handleDeleteSlot = (id: string) => {
    const updated = customSlots.filter(s => s.id !== id);
    setCustomSlots(updated);
    try {
      localStorage.setItem("aether_workspace_custom_slots", JSON.stringify(updated));
    } catch (e) {
      console.warn("Could not delete slot", e);
    }
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-[250] flex items-center justify-center p-4 sm:p-6 bg-black/75 backdrop-blur-md animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <motion.div 
        initial={{ scale: 0.94, opacity: 0, y: 10 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.94, opacity: 0, y: 10 }}
        transition={{ type: "spring", damping: 25, stiffness: 300 }}
        className="w-full max-w-3xl bg-[#090b10] border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[88vh] text-zinc-100"
      >
        {/* Modal Header */}
        <div className="h-14 shrink-0 px-6 bg-black/60 border-b border-white/10 flex items-center justify-between select-none">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-orange-500/10 border border-orange-500/30 flex items-center justify-center text-orange-400">
              <Sliders size={16} />
            </div>
            <div>
              <h2 className="text-xs font-black uppercase tracking-[0.2em] text-white/90">
                Workspace Tuning & Sliders
              </h2>
              <p className="text-[10px] text-white/40 tracking-wider">
                Full dynamic control over panel widths, split ratio, typography, and theme
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onResetDefaults}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest text-white/40 hover:text-orange-400 hover:bg-white/5 border border-transparent hover:border-white/5 transition-all"
              title="Reset all workspace sliders to factory defaults"
            >
              <RotateCcw size={11} />
              <span>Reset</span>
            </button>

            <div className="h-4 w-px bg-white/10 mx-1" />

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-lg text-white/40 hover:text-white hover:bg-white/10 flex items-center justify-center transition-colors"
              aria-label="Close"
            >
              <X size={16} />
            </button>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="h-11 shrink-0 px-6 bg-white/[0.02] border-b border-white/5 flex items-center gap-2 select-none overflow-x-auto">
          {[
            { id: "layout", label: "Panels & Sliders", icon: Layout },
            { id: "editor", label: "Editor & Code", icon: Type },
            { id: "style", label: "Aesthetics & Glow", icon: Palette },
            { id: "presets", label: "Saved Presets", icon: Bookmark },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all cursor-pointer ${
                  isActive 
                    ? "bg-white text-black shadow-lg" 
                    : "text-white/40 hover:text-white/80 hover:bg-white/5"
                }`}
              >
                <Icon size={13} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Modal Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar text-xs">
          
          {/* TAB 1: PANELS & SLIDERS */}
          {activeTab === "layout" && (
            <div className="space-y-6">
              
              {/* Workspace Split Mode Switcher */}
              <div className="bg-black/40 border border-white/5 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <SplitSquareHorizontal size={14} className="text-orange-400" />
                    <span className="text-[11px] font-black uppercase tracking-widest text-white/90">
                      Center Workspace Layout Mode
                    </span>
                  </div>
                  <span className="text-[9px] font-mono text-orange-400/80 bg-orange-500/10 px-2 py-0.5 rounded border border-orange-500/20">
                    Active: {activeRightTab.toUpperCase()}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
                  {[
                    { id: "editor", label: "Code Editor", desc: "Monaco IDE" },
                    { id: "preview", label: "Web Preview", desc: "Live App Runtime" },
                    { id: "dashboard", label: "Cluster Hub", desc: "Projects & Stats" }
                  ].map((mode) => (
                    <button
                      key={mode.id}
                      onClick={() => onChangeRightTab(mode.id as any)}
                      className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                        activeRightTab === mode.id
                          ? "bg-orange-500/10 border-orange-500/50 text-white shadow-[0_0_15px_rgba(249,115,22,0.15)]"
                          : "bg-white/[0.02] border-white/5 text-white/50 hover:text-white hover:bg-white/5"
                      }`}
                    >
                      <div className="font-bold text-[10px] uppercase tracking-wider">{mode.label}</div>
                      <div className="text-[8px] text-white/30 mt-0.5">{mode.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* SLIDER 1: Left Sidebar Width */}
              <div className="bg-black/30 border border-white/5 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-white/80 block">
                      Left Sidebar Explorer Width
                    </label>
                    <span className="text-[9px] text-white/30">Files, extensions, linux terminal studio</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-orange-400 text-xs font-bold">{config.sidebarWidth}px</span>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min={200}
                    max={600}
                    step={10}
                    value={config.sidebarWidth}
                    onChange={(e) => updateSetting("sidebarWidth", parseInt(e.target.value))}
                    className="flex-1 accent-orange-500 cursor-pointer h-1.5 bg-white/10 rounded-lg"
                  />
                </div>

                <div className="flex items-center gap-1.5 flex-wrap pt-1">
                  <span className="text-[9px] text-white/30 uppercase tracking-wider mr-1">Presets:</span>
                  {[240, 300, 380, 480].map((w) => (
                    <button
                      key={w}
                      onClick={() => updateSetting("sidebarWidth", w)}
                      className={`px-2 py-1 rounded-md text-[9px] font-mono border transition-all ${
                        config.sidebarWidth === w
                          ? "bg-orange-500/20 border-orange-500/40 text-orange-300"
                          : "bg-white/5 border-white/5 text-white/40 hover:text-white hover:bg-white/10"
                      }`}
                    >
                      {w}px
                    </button>
                  ))}
                </div>
              </div>

              {/* SLIDER 2: Right AI Assistant Width */}
              <div className="bg-black/30 border border-white/5 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-white/80 block">
                      Right AI Co-Pilot Panel Width
                    </label>
                    <span className="text-[9px] text-white/30">Autonomous agent chat and neural code generation</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-orange-400 text-xs font-bold">{config.chatWidth}px</span>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min={260}
                    max={750}
                    step={10}
                    value={config.chatWidth}
                    onChange={(e) => updateSetting("chatWidth", parseInt(e.target.value))}
                    className="flex-1 accent-orange-500 cursor-pointer h-1.5 bg-white/10 rounded-lg"
                  />
                </div>

                <div className="flex items-center gap-1.5 flex-wrap pt-1">
                  <span className="text-[9px] text-white/30 uppercase tracking-wider mr-1">Presets:</span>
                  {[280, 360, 480, 600].map((w) => (
                    <button
                      key={w}
                      onClick={() => updateSetting("chatWidth", w)}
                      className={`px-2 py-1 rounded-md text-[9px] font-mono border transition-all ${
                        config.chatWidth === w
                          ? "bg-orange-500/20 border-orange-500/40 text-orange-300"
                          : "bg-white/5 border-white/5 text-white/40 hover:text-white hover:bg-white/10"
                      }`}
                    >
                      {w}px
                    </button>
                  ))}
                </div>
              </div>

              {/* SLIDER 3: Split View Ratio & Orientation */}
              <div className="bg-black/30 border border-white/5 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-white/80 block">
                      Dual Split Ratio (Code vs Preview)
                    </label>
                    <span className="text-[9px] text-white/30">Applies when Dual Split View is active</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-orange-400 text-xs font-bold">
                      {Math.round(config.splitRatio * 100)}% / {Math.round((1 - config.splitRatio) * 100)}%
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <span className="text-[9px] font-mono text-white/40">Code</span>
                  <input
                    type="range"
                    min={20}
                    max={80}
                    step={2}
                    value={Math.round(config.splitRatio * 100)}
                    onChange={(e) => updateSetting("splitRatio", parseInt(e.target.value) / 100)}
                    className="flex-1 accent-orange-500 cursor-pointer h-1.5 bg-white/10 rounded-lg"
                  />
                  <span className="text-[9px] font-mono text-white/40">Preview</span>
                </div>

                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-[9px] text-white/30 uppercase tracking-wider mr-1">Ratios:</span>
                    {[
                      { label: "30 / 70", ratio: 0.3 },
                      { label: "50 / 50", ratio: 0.5 },
                      { label: "70 / 30", ratio: 0.7 }
                    ].map((r) => (
                      <button
                        key={r.label}
                        onClick={() => updateSetting("splitRatio", r.ratio)}
                        className={`px-2 py-1 rounded-md text-[9px] font-mono border transition-all ${
                          Math.abs(config.splitRatio - r.ratio) < 0.05
                            ? "bg-orange-500/20 border-orange-500/40 text-orange-300"
                            : "bg-white/5 border-white/5 text-white/40 hover:text-white hover:bg-white/10"
                        }`}
                      >
                        {r.label}
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center gap-1 bg-black/60 p-1 rounded-lg border border-white/5">
                    <button
                      onClick={() => updateSetting("splitOrientation", "horizontal")}
                      className={`px-2 py-1 rounded flex items-center gap-1 text-[9px] font-bold ${
                        config.splitOrientation === "horizontal"
                          ? "bg-white/10 text-orange-400"
                          : "text-white/30 hover:text-white"
                      }`}
                      title="Side-by-side split"
                    >
                      <SplitSquareHorizontal size={11} />
                      <span>Horizontal</span>
                    </button>
                    <button
                      onClick={() => updateSetting("splitOrientation", "vertical")}
                      className={`px-2 py-1 rounded flex items-center gap-1 text-[9px] font-bold ${
                        config.splitOrientation === "vertical"
                          ? "bg-white/10 text-orange-400"
                          : "text-white/30 hover:text-white"
                      }`}
                      title="Stacked top/bottom split"
                    >
                      <SplitSquareVertical size={11} />
                      <span>Vertical</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* SLIDER 4: Terminal Height */}
              <div className="bg-black/30 border border-white/5 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-white/80 block">
                      Bottom Terminal Shell Height
                    </label>
                    <span className="text-[9px] text-white/30">System shell drawer expandable height</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-orange-400 text-xs font-bold">{config.terminalHeight}px</span>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min={140}
                    max={600}
                    step={10}
                    value={config.terminalHeight}
                    onChange={(e) => updateSetting("terminalHeight", parseInt(e.target.value))}
                    className="flex-1 accent-orange-500 cursor-pointer h-1.5 bg-white/10 rounded-lg"
                  />
                </div>

                <div className="flex items-center gap-1.5 flex-wrap pt-1">
                  <span className="text-[9px] text-white/30 uppercase tracking-wider mr-1">Presets:</span>
                  {[180, 280, 380, 520].map((h) => (
                    <button
                      key={h}
                      onClick={() => updateSetting("terminalHeight", h)}
                      className={`px-2 py-1 rounded-md text-[9px] font-mono border transition-all ${
                        config.terminalHeight === h
                          ? "bg-orange-500/20 border-orange-500/40 text-orange-300"
                          : "bg-white/5 border-white/5 text-white/40 hover:text-white hover:bg-white/10"
                      }`}
                    >
                      {h}px
                    </button>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: EDITOR & CODE */}
          {activeTab === "editor" && (
            <div className="space-y-6">
              
              {/* Font Size Slider */}
              <div className="bg-black/30 border border-white/5 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-white/80 block">
                      Editor Buffer Font Size
                    </label>
                    <span className="text-[9px] text-white/30">Micro & macro scale text rendering in Monaco</span>
                  </div>
                  <span className="font-mono text-orange-400 text-xs font-bold">{config.editorFontSize}px</span>
                </div>

                <div className="flex items-center gap-4">
                  <button
                    onClick={() => updateSetting("editorFontSize", Math.max(10, config.editorFontSize - 1))}
                    className="w-7 h-7 rounded bg-white/5 border border-white/10 hover:bg-white/10 flex items-center justify-center font-bold"
                  >
                    -
                  </button>
                  <input
                    type="range"
                    min={10}
                    max={26}
                    step={1}
                    value={config.editorFontSize}
                    onChange={(e) => updateSetting("editorFontSize", parseInt(e.target.value))}
                    className="flex-1 accent-orange-500 cursor-pointer h-1.5 bg-white/10 rounded-lg"
                  />
                  <button
                    onClick={() => updateSetting("editorFontSize", Math.min(26, config.editorFontSize + 1))}
                    className="w-7 h-7 rounded bg-white/5 border border-white/10 hover:bg-white/10 flex items-center justify-center font-bold"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Line Height Slider */}
              <div className="bg-black/30 border border-white/5 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-white/80 block">
                      Code Line Height Multiplier
                    </label>
                    <span className="text-[9px] text-white/30">Vertical spacing ratio between code lines</span>
                  </div>
                  <span className="font-mono text-orange-400 text-xs font-bold">{config.editorLineHeight.toFixed(1)}x</span>
                </div>

                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min={12}
                    max={24}
                    step={1}
                    value={Math.round(config.editorLineHeight * 10)}
                    onChange={(e) => updateSetting("editorLineHeight", parseInt(e.target.value) / 10)}
                    className="flex-1 accent-orange-500 cursor-pointer h-1.5 bg-white/10 rounded-lg"
                  />
                </div>
              </div>

              {/* Font Family Selection */}
              <div className="bg-black/30 border border-white/5 rounded-xl p-4 space-y-3">
                <label className="text-[10px] font-black uppercase tracking-widest text-white/80 block">
                  Code Monospace Font Family
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { label: "JetBrains Mono", value: "'JetBrains Mono', monospace" },
                    { label: "Fira Code", value: "'Fira Code', monospace" },
                    { label: "Courier Prime", value: "'Courier New', Courier, monospace" },
                    { label: "Consolas", value: "Consolas, 'Courier New', monospace" },
                    { label: "Inter UI", value: "'Inter', sans-serif" },
                    { label: "System Default", value: "monospace" }
                  ].map((f) => (
                    <button
                      key={f.label}
                      onClick={() => updateSetting("editorFont", f.value)}
                      className={`p-2.5 rounded-lg border text-left transition-all ${
                        config.editorFont === f.value
                          ? "bg-orange-500/15 border-orange-500/40 text-orange-300"
                          : "bg-white/[0.02] border-white/5 text-white/50 hover:text-white hover:bg-white/5"
                      }`}
                    >
                      <div className="text-[10px] font-mono">{f.label}</div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Monaco Toggles */}
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => updateSetting("minimapEnabled", !config.minimapEnabled)}
                  className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                    config.minimapEnabled 
                      ? "bg-white/5 border-orange-500/30 text-white" 
                      : "bg-black/30 border-white/5 text-white/40"
                  }`}
                >
                  <span className="text-[10px] font-bold uppercase tracking-wider">Monaco Minimap</span>
                  <div className={`w-3.5 h-3.5 rounded flex items-center justify-center ${config.minimapEnabled ? 'bg-orange-500 text-black' : 'bg-white/10'}`}>
                    {config.minimapEnabled && <Check size={10} strokeWidth={3} />}
                  </div>
                </button>

                <button
                  onClick={() => updateSetting("ligaturesEnabled", !config.ligaturesEnabled)}
                  className={`p-3 rounded-xl border flex items-center justify-between transition-all ${
                    config.ligaturesEnabled 
                      ? "bg-white/5 border-orange-500/30 text-white" 
                      : "bg-black/30 border-white/5 text-white/40"
                  }`}
                >
                  <span className="text-[10px] font-bold uppercase tracking-wider">Font Ligatures</span>
                  <div className={`w-3.5 h-3.5 rounded flex items-center justify-center ${config.ligaturesEnabled ? 'bg-orange-500 text-black' : 'bg-white/10'}`}>
                    {config.ligaturesEnabled && <Check size={10} strokeWidth={3} />}
                  </div>
                </button>
              </div>

            </div>
          )}

          {/* TAB 3: AESTHETICS & GLOW */}
          {activeTab === "style" && (
            <div className="space-y-6">
              
              {/* Accent Color Palette */}
              <div className="bg-black/30 border border-white/5 rounded-xl p-4 space-y-3">
                <label className="text-[10px] font-black uppercase tracking-widest text-white/80 block">
                  Workspace Accent Theme
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {ACCENT_PALETTES.map((pal) => {
                    const isSelected = config.accentColor.toLowerCase() === pal.color.toLowerCase();
                    return (
                      <button
                        key={pal.name}
                        onClick={() => updateSetting("accentColor", pal.color)}
                        className={`p-2.5 rounded-xl border flex items-center gap-2.5 transition-all text-left ${
                          isSelected 
                            ? "bg-white/10 border-white/40 shadow-lg" 
                            : "bg-white/[0.02] border-white/5 hover:border-white/15"
                        }`}
                      >
                        <div 
                          className="w-4 h-4 rounded-full shadow-md shrink-0" 
                          style={{ backgroundColor: pal.color, boxShadow: `0 0 10px ${pal.glow}` }} 
                        />
                        <span className="text-[10px] font-bold text-white/80 truncate">{pal.name}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Panel Opacity Slider */}
              <div className="bg-black/30 border border-white/5 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-white/80 block">
                      Panel Glassmorphism Opacity
                    </label>
                    <span className="text-[9px] text-white/30">Background transparency for cards & sidebars</span>
                  </div>
                  <span className="font-mono text-orange-400 text-xs font-bold">{config.panelOpacity}%</span>
                </div>

                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min={30}
                    max={100}
                    step={5}
                    value={config.panelOpacity}
                    onChange={(e) => updateSetting("panelOpacity", parseInt(e.target.value))}
                    className="flex-1 accent-orange-500 cursor-pointer h-1.5 bg-white/10 rounded-lg"
                  />
                </div>
              </div>

              {/* Backdrop Blur Slider */}
              <div className="bg-black/30 border border-white/5 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-white/80 block">
                      Backdrop Blur Filter
                    </label>
                    <span className="text-[9px] text-white/30">Neural glassmorphism lens effect</span>
                  </div>
                  <span className="font-mono text-orange-400 text-xs font-bold">{config.backdropBlur}px</span>
                </div>

                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min={0}
                    max={32}
                    step={2}
                    value={config.backdropBlur}
                    onChange={(e) => updateSetting("backdropBlur", parseInt(e.target.value))}
                    className="flex-1 accent-orange-500 cursor-pointer h-1.5 bg-white/10 rounded-lg"
                  />
                </div>
              </div>

              {/* Corner Radius Slider */}
              <div className="bg-black/30 border border-white/5 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-white/80 block">
                      Container Corner Radius
                    </label>
                    <span className="text-[9px] text-white/30">0px (Sharp Brutalist) to 20px (Modern Curvature)</span>
                  </div>
                  <span className="font-mono text-orange-400 text-xs font-bold">{config.borderRadius}px</span>
                </div>

                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min={0}
                    max={20}
                    step={2}
                    value={config.borderRadius}
                    onChange={(e) => updateSetting("borderRadius", parseInt(e.target.value))}
                    className="flex-1 accent-orange-500 cursor-pointer h-1.5 bg-white/10 rounded-lg"
                  />
                </div>
              </div>

              {/* Glow Intensity Slider */}
              <div className="bg-black/30 border border-white/5 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-white/80 block">
                      Neon Glow & Border Aura
                    </label>
                    <span className="text-[9px] text-white/30">Energy pulse and lighting highlights</span>
                  </div>
                  <span className="font-mono text-orange-400 text-xs font-bold">{config.glowIntensity}%</span>
                </div>

                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min={0}
                    max={100}
                    step={5}
                    value={config.glowIntensity}
                    onChange={(e) => updateSetting("glowIntensity", parseInt(e.target.value))}
                    className="flex-1 accent-orange-500 cursor-pointer h-1.5 bg-white/10 rounded-lg"
                  />
                </div>
              </div>

            </div>
          )}

          {/* TAB 4: PRESETS & SAVED SLOTS */}
          {activeTab === "presets" && (
            <div className="space-y-6">
              
              {/* Built-in Presets */}
              <div className="space-y-3">
                <label className="text-[10px] font-black uppercase tracking-widest text-white/80 block">
                  Curated Studio Presets
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {WORKSPACE_PRESETS.map((preset) => {
                    const Icon = preset.icon;
                    return (
                      <button
                        key={preset.name}
                        onClick={() => {
                          onChangeConfig({ ...config, ...preset.config });
                        }}
                        className="p-3.5 rounded-xl bg-white/[0.02] border border-white/5 hover:border-orange-500/40 hover:bg-orange-500/5 text-left transition-all group cursor-pointer"
                      >
                        <div className="flex items-center gap-2 mb-1.5">
                          <Icon size={14} className="text-orange-400 group-hover:scale-110 transition-transform" />
                          <span className="font-bold text-[11px] text-white/90">{preset.name}</span>
                        </div>
                        <p className="text-[10px] text-white/40 leading-relaxed">{preset.desc}</p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Save Current Configuration as Custom Slot */}
              <div className="bg-black/40 border border-white/5 rounded-xl p-4 space-y-3">
                <label className="text-[10px] font-black uppercase tracking-widest text-white/80 block">
                  Save Current Workspace Layout
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="e.g., Ultra-Wide Dual Monitor"
                    value={slotNameInput}
                    onChange={(e) => setSlotNameInput(e.target.value)}
                    className="flex-1 bg-black/60 border border-white/10 rounded-lg px-3 py-2 text-xs text-white outline-none focus:border-orange-500"
                  />
                  <button
                    onClick={handleSaveSlot}
                    className="px-4 py-2 bg-orange-600 hover:bg-orange-500 text-white font-bold text-xs rounded-lg flex items-center gap-1.5 transition-all shadow-md active:scale-95"
                  >
                    <Save size={13} />
                    <span>Save Slot</span>
                  </button>
                </div>
              </div>

              {/* Custom Slots List */}
              {customSlots.length > 0 && (
                <div className="space-y-2">
                  <label className="text-[10px] font-black uppercase tracking-widest text-white/80 block">
                    Your Custom Saved Layouts ({customSlots.length})
                  </label>
                  <div className="space-y-2">
                    {customSlots.map((slot) => (
                      <div
                        key={slot.id}
                        className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02] border border-white/5"
                      >
                        <div className="flex items-center gap-2.5">
                          <Bookmark size={13} className="text-orange-400" />
                          <div>
                            <div className="font-bold text-[11px] text-white/90">{slot.name}</div>
                            <div className="text-[9px] text-white/30 font-mono">
                              Sidebar {slot.config.sidebarWidth}px · Chat {slot.config.chatWidth}px · Split {Math.round(slot.config.splitRatio * 100)}%
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => onChangeConfig({ ...slot.config })}
                            className="px-3 py-1 bg-white/10 hover:bg-white/20 text-white rounded-lg text-[10px] font-bold transition-colors"
                          >
                            Apply
                          </button>
                          <button
                            onClick={() => handleDeleteSlot(slot.id)}
                            className="p-1.5 text-white/30 hover:text-red-400 rounded-lg hover:bg-red-500/10 transition-colors"
                            title="Delete Slot"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="h-12 shrink-0 px-6 bg-black/60 border-t border-white/10 flex items-center justify-between text-[10px]">
          <div className="flex items-center gap-2 text-white/40">
            <Sparkles size={12} className="text-orange-400" />
            <span>Changes apply immediately with live reactive binding.</span>
          </div>

          <button
            onClick={onClose}
            className="px-5 py-1.5 bg-white text-black font-black uppercase tracking-widest text-[9px] rounded-lg hover:bg-white/90 transition-all shadow-md"
          >
            Done
          </button>
        </div>
      </motion.div>
    </div>
  );
};
