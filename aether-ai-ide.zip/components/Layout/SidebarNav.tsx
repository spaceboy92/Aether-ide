import React, { useState } from "react";
import { 
  Plus, 
  Folder, 
  Search, 
  Layers, 
  Settings, 
  HardDrive,
  Bot,
  Play,
  Cloud,
  BarChart3,
  Zap,
  Globe,
  ShieldCheck,
  Database,
  Wand2,
  Gauge,
  TrendingUp,
  Network,
  KeyRound,
  Sliders,
  MoreVertical,
  Share2,
  Trash2,
  Edit2
} from "lucide-react";
import AppLogo from "../UI/AppLogo";

interface SidebarNavProps {
  sessions: any[];
  activeSessionId: string | null;
  setActiveSessionId: (id: string | null) => void;
  setActiveTab: (tab: any) => void;
  createNewSession: () => void;
  sidebarMode: string | null;
  setSidebarMode: (mode: any) => void;
  googleDriveConnected: boolean;
  onDeleteSession?: (id: string) => void;
  onRenameSession?: (id: string, newTitle: string) => void;
}

const SidebarNav: React.FC<SidebarNavProps> = ({
  sessions,
  activeSessionId,
  setActiveSessionId,
  setActiveTab,
  createNewSession,
  sidebarMode,
  setSidebarMode,
  googleDriveConnected,
  onDeleteSession,
  onRenameSession
}) => {
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  return (
    <aside className="w-[280px] neural-glass border-r border-white/5 flex flex-col shrink-0 hidden md:flex z-20">
      <div className="h-16 flex items-center px-6 gap-3 shrink-0 border-b border-white/5 bg-white/[0.01]">
        <AppLogo size={24} />
        <div className="flex flex-col">
          <span className="text-white/80 font-black tracking-[0.15em] text-[10px] uppercase">
            AETHER
          </span>
          <span className="text-[7px] text-orange-500 font-black uppercase tracking-[0.3em] -mt-0.5">
            STUDIO
          </span>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-6 no-scrollbar">
        <button
          onClick={() => createNewSession()}
          className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-[11px] font-bold uppercase tracking-widest bg-white/[0.03] border border-white/5 hover:border-white/10 hover:bg-white/5 transition-all shadow-xl shadow-black/20 group"
          aria-label="Create New Project"
        >
          <Plus size={14} className="group-hover:rotate-90 transition-transform duration-300" /> 
          New Project
        </button>
        
        <div className="space-y-3">
          <div className="flex items-center justify-between px-2">
            <span className="text-[9px] font-black text-white/20 uppercase tracking-[0.2em]">
              Recent Projects
            </span>
            <button 
              onClick={() => {
                const subject = encodeURIComponent("Aether Feedback");
                window.location.href = `mailto:itzspaceboy92@gmail.com?subject=${subject}`;
              }}
              className="text-[8px] text-orange-500/40 hover:text-orange-500 font-bold uppercase tracking-widest transition-colors"
              aria-label="Send Feedback"
            >
              Feedback
            </button>
          </div>

          <div className="space-y-1 pb-20">
            {sessions.map((s) => {
              const isActive = activeSessionId === s.id;
              return (
                <div key={s.id} className="relative group">
                  <button
                    onClick={() => {
                      setActiveSessionId(s.id);
                      setActiveTab("chat");
                    }}
                    className={`
                      w-full text-left px-4 py-3 rounded-xl text-xs font-medium transition-all duration-300 relative group/btn
                      ${isActive 
                        ? "bg-white/[0.07] text-white shadow-[0_4px_12px_rgba(0,0,0,0.3)] ring-1 ring-white/10" 
                        : "text-white/40 hover:bg-white/[0.03] hover:text-white/70"}
                    `}
                    aria-pressed={isActive}
                  >
                    <div className="flex items-center gap-3 pr-6">
                      <div className={`w-1 h-1 rounded-full shrink-0 transition-all duration-500 ${isActive ? 'bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.6)] scale-125' : 'bg-white/10 group-hover/btn:bg-white/20'}`} />
                      <span className="truncate">{s.title || "Untitled Project"}</span>
                    </div>
                  </button>
                  
                  <div className={`absolute right-2 top-1/2 -translate-y-1/2 flex items-center transition-opacity ${isActive || activeDropdown === s.id ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setActiveDropdown(activeDropdown === s.id ? null : s.id);
                      }}
                      className="p-1.5 rounded-md hover:bg-white/10 text-white/50 hover:text-white transition-colors"
                    >
                      <MoreVertical size={14} />
                    </button>
                  </div>
                  
                  {activeDropdown === s.id && (
                    <>
                      <div 
                        className="fixed inset-0 z-40"
                        onClick={() => setActiveDropdown(null)}
                      />
                      <div className="absolute right-2 top-10 z-50 w-40 bg-[#0f1115] border border-white/10 rounded-xl shadow-2xl py-1 animate-in fade-in zoom-in-95 duration-100">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveDropdown(null);
                            window.dispatchEvent(new CustomEvent("aether_open_share"));
                          }}
                          className="w-full text-left px-3 py-2 text-xs text-white/70 hover:text-white hover:bg-white/5 flex items-center gap-2"
                        >
                          <Share2 size={12} className="text-sky-400" /> Share Project
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveDropdown(null);
                            const newTitle = prompt("Enter new title for session:", s.title);
                            if (newTitle && newTitle.trim() && onRenameSession) {
                              onRenameSession(s.id, newTitle.trim());
                            }
                          }}
                          className="w-full text-left px-3 py-2 text-xs text-white/70 hover:text-white hover:bg-white/5 flex items-center gap-2"
                        >
                          <Edit2 size={12} className="text-amber-400" /> Rename
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveDropdown(null);
                            if (confirm("Are you sure you want to delete this session? This action cannot be undone.") && onDeleteSession) {
                              onDeleteSession(s.id);
                            }
                          }}
                          className="w-full text-left px-3 py-2 text-xs text-rose-400 hover:bg-rose-500/10 flex items-center gap-2"
                        >
                          <Trash2 size={12} /> Delete Session
                        </button>
                      </div>
                    </>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="p-4 border-t border-white/5 space-y-3 bg-white/[0.01]">
        <div
          className="px-4 py-3 rounded-xl bg-white/[0.02] border border-white/5 flex items-center justify-between group cursor-help transition-all hover:bg-white/[0.04]"
          aria-label={`Storage: ${googleDriveConnected ? 'Cloud Active' : 'Local Only'}`}
        >
          <div className="flex items-center gap-2.5">
            <HardDrive
              size={13}
              className={googleDriveConnected ? "text-blue-400" : "text-white/20"}
            />
            <span className="text-[9px] font-black uppercase tracking-[0.2em] text-white/30">
              Storage
            </span>
          </div>
          <div className={`w-1.5 h-1.5 rounded-full transition-all duration-1000 ${googleDriveConnected ? "bg-blue-400 shadow-[0_0_10px_rgba(96,165,250,0.6)]" : "bg-white/5"}`} />
        </div>

        <div className="grid grid-cols-5 gap-1.5">
          {[
            { id: 'files', icon: Folder, label: 'FILES', active: sidebarMode === 'files' },
            { id: 'search', icon: Search, label: 'SEARCH', active: sidebarMode === 'search' },
            { id: 'jwt_decoder', icon: KeyRound, label: 'JWT', active: sidebarMode === 'jwt_decoder' },
            { id: 'env_manager', icon: Sliders, label: 'ENV', active: sidebarMode === 'env_manager' },
            { id: 'api_playground', icon: Globe, label: 'API', active: sidebarMode === 'api_playground' },
            { id: 'database', icon: Database, label: 'DB', active: sidebarMode === 'database' },
            { id: 'security', icon: ShieldCheck, label: 'SECURITY', active: sidebarMode === 'security' },
            { id: 'terminal', icon: HardDrive, label: 'TERMINAL', active: sidebarMode === 'terminal' },
            { id: 'deployment', icon: Cloud, label: 'DEPLOY', active: sidebarMode === 'deployment' },
            { id: 'settings', icon: Settings, label: 'SETTINGS', active: sidebarMode === 'settings' },
          ].map((tool) => (
            <button
              key={tool.id}
              onClick={() => {
                if (tool.id === 'files' || tool.id === 'search') {
                  if (!activeSessionId) return;
                }
                setSidebarMode(tool.active ? null : tool.id as any);
              }}
              disabled={(tool.id === 'files' || tool.id === 'search') && !activeSessionId}
              className={`
                p-2.5 rounded-lg flex flex-col items-center justify-center gap-1.5 transition-all duration-300 outline-none
                ${tool.active 
                  ? "bg-white text-black shadow-[0_0_20px_rgba(255,255,255,0.2)] scale-105" 
                  : "text-white/20 hover:bg-white/5 hover:text-white/60 disabled:opacity-5 disabled:hover:bg-transparent"}
              `}
              aria-label={tool.label}
              aria-pressed={tool.active}
            >
              <tool.icon size={15} />
              <span className="text-[6px] font-black tracking-[0.1em]">{tool.label}</span>
            </button>
          ))}
        </div>
      </div>
    </aside>
  );

  function createSessionAndFocus() {
    createNewSession();
  }
};

export default SidebarNav;
