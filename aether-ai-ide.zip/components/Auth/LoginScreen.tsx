import React, { useState, useEffect, useRef } from 'react';
import { Zap, User, ArrowRight, Check, HardDrive, Shield, Loader2, Mail, Lock, LogIn, UserPlus, Briefcase, Palette, Code, Building, RefreshCcw, Fingerprint } from 'lucide-react';
import { UserProfile } from '../../types';
import { googleSignIn } from '../../services/firebaseAuthService';

import { motion, AnimatePresence } from 'motion/react';
import { notificationEmitter } from '../UI/NotificationSystem';

interface LoginScreenProps {
  onLogin: () => void;
  onGuestLogin: (force?: boolean) => void;
  onCompleteProfile: (profile: UserProfile) => void;
  loading: boolean;
  bmwMode?: boolean;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin, onGuestLogin, onCompleteProfile, loading: parentLoading, bmwMode }) => {
  const [step, setStep] = useState<'login' | 'age' | 'account-type' | 'profile' | 'permissions'>('login');
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [localLoading, setLocalLoading] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [accountType, setAccountType] = useState<UserProfile['accountType']>('Developer');
  const [photoURL, setPhotoURL] = useState('');
  const [age, setAge] = useState<number | ''>('');
  const [driveAccess, setDriveAccess] = useState(true);
  const [prankMessage, setPrankMessage] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [showLogoutToast, setShowLogoutToast] = useState(false);
  const [showResetToast, setShowResetToast] = useState(false);
  const [showUpgradeToast, setShowUpgradeToast] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('loggedOut')) {
        setShowLogoutToast(true);
        setTimeout(() => setShowLogoutToast(false), 5000);
    }
    if (params.get('reset')) {
        setShowResetToast(true);
        setTimeout(() => setShowResetToast(false), 5000);
    }
    if (params.get('upgradeAuth')) {
        setShowUpgradeToast(true);
        setTimeout(() => setShowUpgradeToast(false), 8000);
    }
  }, []);

  const handlePasskeyAuth = async () => {
      try {
          if (!window.PublicKeyCredential) throw new Error("WebAuthn not supported");
          const credential = await navigator.credentials.get({
              publicKey: {
                  challenge: crypto.getRandomValues(new Uint8Array(32)),
                  timeout: 60000,
                  userVerification: "preferred"
              }
          });
          if (credential) {
              const passkeysStore = JSON.parse(localStorage.getItem('aether_passkeys') || '{}');
              const u = passkeysStore[credential.id];
              if (u) {
                  onCompleteProfile(u);
              } else {
                  throw new Error("No passkey associated with any local account.");
              }
          }
      } catch (e: any) {
          setErrorMsg(e.message || 'Passkey authentication failed.');
      }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLocalLoading(true);
    setErrorMsg(null);
    try {
      if (authMode === 'signup' && !name.trim()) {
         throw new Error("Name is required for signup");
      }
      
      // Simulation of auth
      if (authMode === 'login') {
          if (!name) setName('Developer');
          setStep('age');
      } else {
          setStep('account-type');
      }
    } catch (error: any) {
      setErrorMsg(error.message);
    }
    setLocalLoading(false);
  };

  const handleOAuthSuccess = async (googleEmail: string, googleName: string) => {
    setLocalLoading(true);
    setErrorMsg(null);
    try {
      setName(googleName);
      setEmail(googleEmail);
      setStep('age');
    } catch (error: any) {
      setErrorMsg(error.message);
    }
    setLocalLoading(false);
  };

  const handleGoogleLogin = async () => {
    setLocalLoading(true);
    setErrorMsg(null);
    try {
      const result = await googleSignIn();
      if (result) {
        localStorage.setItem('google_drive_access_token', result.accessToken);
        handleOAuthSuccess(result.user.email || 'developer@example.com', result.user.displayName || 'Developer');
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Google login failed');
      setLocalLoading(false);
    }
  };

  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === 'GOOGLE_DRIVE_AUTH_SUCCESS') {
        const tokens = event.data.tokens;
        const userInfo = event.data.user;
        localStorage.setItem('google_drive_access_token', tokens.access_token);
        
        notificationEmitter.emit({
          type: 'system',
          title: 'Account Synchronized',
          message: 'Google Drive access granted.'
        });

        handleOAuthSuccess(userInfo.email || 'developer@example.com', userInfo.name || 'Developer');
      }
    };
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  const handleGuestLogin = () => {
    setName('Guest User');
    onGuestLogin(true);
  };

  const handleAgeSubmit = () => {
    const ageNum = Number(age);
    if (!age) return;
    
    setPrankMessage(null);

    if (ageNum < 13) {
        setPrankMessage("You must be at least 13 to use this application.");
        return;
    }

    setStep('profile');
  };

  const handleProfileSubmit = () => {
    if (!name.trim()) return;
    setStep('permissions');
  };

  const handleFinalize = async () => {
    setLocalLoading(true);
    const newUser: UserProfile = {
      id: `u_${Date.now()}`,
      name: name,
      email: email,
      photoURL: photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=6366f1&color=fff`,
      isGuest: !email,
      syncEnabled: driveAccess,
      driveConnected: driveAccess,
      accountType: accountType,
      // @ts-ignore
      isMature: (Number(age) || 0) >= 18
    };
    
    try {
      await new Promise(resolve => setTimeout(resolve, 300));
      await onCompleteProfile(newUser);
      
      setTimeout(() => {
        setLocalLoading(false);
      }, 3000);
    } catch (error: any) {
      console.error("Failed to finalize profile:", error);
      let displayMsg = error.message || "Failed to create profile. Please try again.";
      try {
        const parsed = JSON.parse(displayMsg);
        if (parsed.error) displayMsg = parsed.error;
      } catch (e) {}
      setErrorMsg(displayMsg);
      setLocalLoading(false);
    }
  };

  const isLoading = localLoading || parentLoading;

  return (
    <div className="flex flex-col items-center justify-center min-h-[100dvh] py-8 w-full bg-transparent text-white relative overflow-y-auto custom-scrollbar font-sans">

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="z-10 bg-white/[0.02] backdrop-blur-3xl border border-white/5 p-6 sm:p-8 md:p-12 rounded-[2rem] max-w-[min(400px,95%)] w-full text-center relative shadow-2xl transition-all duration-500"
      >
        <AnimatePresence>
        {showLogoutToast && (
            <motion.div 
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="absolute top-4 left-1/2 -translate-x-1/2 z-[100] px-4 py-2 bg-emerald-500 text-black text-xs font-bold rounded-full shadow-lg flex items-center gap-2 whitespace-nowrap"
            >
                <Check size={14} />
                Signed out successfully
            </motion.div>
        )}
        </AnimatePresence>

        <div className="flex flex-col items-center justify-center mb-10 relative mt-4">
           <div className="w-16 h-16 bg-gradient-to-tr from-orange-500 to-amber-500 rounded-2xl flex items-center justify-center mb-6 shadow-[0_0_40px_rgba(249,115,22,0.3)]">
             <Zap className="text-white" size={32} />
           </div>
           <h1 className="text-3xl font-bold text-white mb-2 tracking-tight">
              Sign In
           </h1>
           <p className="text-white/50 text-sm">Welcome back to your workspace.</p>
        </div>

        <div className="flex bg-white/5 p-1 rounded-[1.2rem] mb-8 border border-white/5">
            <button 
                onClick={() => setAuthMode('login')}
                className={`flex-1 py-2.5 text-xs font-semibold rounded-xl transition-all ${authMode === 'login' ? 'bg-white/10 text-white shadow-lg' : 'text-white/40 hover:text-white'}`}
            >
                Start
            </button>
            <button 
                onClick={() => setAuthMode('signup')}
                className={`flex-1 py-2.5 text-xs font-semibold rounded-xl transition-all ${authMode === 'signup' ? 'bg-white/10 text-white shadow-lg' : 'text-white/40 hover:text-white'}`}
            >
                Create
            </button>
        </div>

        <AnimatePresence mode="wait">
        {isLoading ? (
          <motion.div 
            key="loading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center justify-center py-12 space-y-4"
          >
            <Loader2 className="w-8 h-8 text-orange-400 animate-spin" />
            <p className="text-xs text-white/50 font-medium">Authenticating...</p>
          </motion.div>
        ) : (
          <motion.div
            key={step}
            initial={{ opacity: 0, x: 10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.3 }}
          >
            {step === 'login' && (
                <div className="space-y-4 relative z-20">
                    <form onSubmit={handleEmailAuth} className="space-y-4">
                        <div className="relative group">
                            <User className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30 group-focus-within:text-orange-400 transition-colors" size={18} />
                            <input 
                                type="text"
                                value={name}
                                onChange={e => setName(e.target.value)}
                                placeholder="Username or Name"
                                className="w-full bg-black/40 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-sm text-white outline-none focus:border-orange-500/50 transition-all focus:bg-black/60 focus:ring-4 focus:ring-orange-500/10 hover:border-white/20"
                            />
                        </div>
                        {authMode === 'signup' ? (
                            <div className="relative group">
                                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30 group-focus-within:text-orange-400 transition-colors" size={18} />
                                <input 
                                    type="email"
                                    value={email}
                                    onChange={e => setEmail(e.target.value)}
                                    placeholder="Email Address"
                                    className="w-full bg-black/40 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-sm text-white outline-none focus:border-orange-500/50 transition-all focus:bg-black/60 focus:ring-4 focus:ring-orange-500/10 hover:border-white/20"
                                />
                            </div>
                        ) : (
                             <div className="relative group">
                                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30 group-focus-within:text-orange-400 transition-colors" size={18} />
                                <input 
                                    type="password"
                                    value={password}
                                    onChange={e => setPassword(e.target.value)}
                                    placeholder="Password"
                                    className="w-full bg-black/40 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-sm text-white outline-none focus:border-orange-500/50 transition-all focus:bg-black/60 focus:ring-4 focus:ring-orange-500/10 hover:border-white/20"
                                />
                            </div>
                        )}
                        <button 
                            type="submit"
                            className="bg-orange-500 hover:bg-orange-600 active:scale-95 text-white w-full px-6 py-4 rounded-2xl flex items-center justify-center gap-2 font-semibold text-sm group transition-all"
                        >
                            {authMode === 'login' ? 'Sign In' : 'Sign Up'}
                            <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform opacity-70" />
                        </button>
                    </form>

                    <div className="flex items-center gap-4 py-2 opacity-60">
                        <div className="flex-1 h-px bg-white/10"></div>
                        <span className="text-[10px] font-medium uppercase tracking-wider text-white/60">or continue with</span>
                        <div className="flex-1 h-px bg-white/10"></div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                        <button 
                            onClick={() => handlePasskeyAuth()}
                            className="w-full px-2 py-3 rounded-2xl flex items-center justify-center gap-2 bg-white/5 border border-white/10 text-white font-medium text-xs hover:bg-white/10 transition-all active:scale-95"
                        >
                            <Fingerprint size={16} className="text-orange-400" />
                            <span>Passkey</span>
                        </button>

                        <button 
                            onClick={() => handleGoogleLogin()}
                            className="w-full px-2 py-3 rounded-2xl flex items-center justify-center gap-2 bg-white/5 border border-white/10 text-white font-medium text-xs hover:bg-white/10 transition-all active:scale-95"
                        >
                            <svg className="w-4 h-4" viewBox="0 0 24 24">
                                <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                                <path fill="currentColor" className="opacity-70" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                                <path fill="currentColor" className="opacity-50" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" />
                                <path fill="currentColor" className="opacity-90" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                            </svg>
                            <span>Google</span>
                        </button>
                    </div>

                    <button 
                        onClick={() => handleGuestLogin()}
                        className="w-full py-4 text-white/40 hover:text-white transition-colors font-medium text-xs mt-2"
                    >
                        Sign in as Guest
                    </button>
                    
                    {errorMsg && <p className="text-red-400 text-xs font-medium text-center mt-4 bg-red-500/10 py-3 rounded-xl border border-red-500/20">{errorMsg}</p>}
                </div>
            )}

            {step === 'account-type' && (
                <div className="space-y-6 relative z-20 text-center">
                    <div className="space-y-2 mb-8">
                        <h3 className="text-xl font-bold text-white">How will you use this?</h3>
                        <p className="text-sm text-white/50">Select your primary focus</p>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                        {[
                            { id: 'Researcher', icon: Briefcase, label: 'Research', color: 'text-orange-400' },
                            { id: 'Creative', icon: Palette, label: 'Creative', color: 'text-amber-400' },
                            { id: 'Developer', icon: Code, label: 'Developer', color: 'text-orange-500' },
                            { id: 'Enterprise', icon: Building, label: 'Enterprise', color: 'text-amber-500' },
                        ].map(type => (
                            <button 
                                key={type.id}
                                onClick={() => setAccountType(type.id as any)}
                                className={`flex flex-col items-center gap-3 p-4 rounded-2xl border transition-all duration-200 active:scale-95 ${accountType === type.id ? 'bg-white/10 border-white/20 shadow-lg' : 'bg-black/20 border-white/5 hover:bg-white/5 hover:border-white/10'}`}
                            >
                                <type.icon size={24} className={accountType === type.id ? 'text-white' : type.color} />
                                <span className={`text-xs font-semibold ${accountType === type.id ? 'text-white' : 'text-white/60'}`}>{type.label}</span>
                            </button>
                        ))}
                    </div>

                    <button 
                        onClick={() => setStep('age')}
                        className="bg-orange-500 hover:bg-orange-600 active:scale-95 text-white w-full px-6 py-4 rounded-2xl font-semibold text-sm transition-all"
                    >
                        Continue
                    </button>
                </div>
            )}

            {step === 'age' && (
                <div className="space-y-6 relative z-20 text-center">
                    <div className="space-y-2 mb-8">
                        <h3 className="text-xl font-bold text-white">Verify Age</h3>
                        <p className="text-sm text-white/50">Please enter your age to continue.</p>
                    </div>
                    <input 
                        type="number" 
                        value={age}
                        onChange={(e) => {
                            setAge(parseInt(e.target.value) || '');
                            setPrankMessage(null);
                        }}
                        placeholder="Age"
                        autoFocus
                        className="bg-black/40 border border-white/10 w-full focus:bg-black/60 rounded-2xl p-5 text-white outline-none transition-all text-center text-xl font-medium focus:border-orange-500/50 focus:ring-4 focus:ring-orange-500/10"
                    />
                    
                    <AnimatePresence>
                    {prankMessage && (
                        <motion.div 
                            initial={{ opacity: 0, scale: 0.95 }}
                            animate={{ opacity: 1, scale: 1 }}
                            className="p-4 bg-red-500/10 border border-red-500/20 rounded-2xl backdrop-blur-md"
                        >
                             <p className="text-sm font-medium text-red-400 text-center">{prankMessage}</p>
                        </motion.div>
                    )}
                    </AnimatePresence>

                    <button
                        onClick={handleAgeSubmit}
                        disabled={age === ''}
                        className="bg-orange-500 hover:bg-orange-600 active:scale-95 text-white w-full px-6 py-4 rounded-2xl flex items-center justify-center gap-2 disabled:opacity-30 group font-semibold text-sm transition-all"
                    >
                        Continue
                    </button>
                </div>
            )}

            {step === 'profile' && (
                <div className="space-y-6 relative z-20 text-center">
                    <div className="space-y-2 mb-8">
                        <h3 className="text-xl font-bold text-white">Your Profile</h3>
                        <p className="text-sm text-white/50">How should we address you?</p>
                    </div>
                    <div className="relative mx-auto w-24 h-24 mb-6 shadow-2xl rounded-full bg-black/40 p-2 border border-white/10">
                        <img src={photoURL || `https://ui-avatars.com/api/?name=${encodeURIComponent(name || 'A')}&background=4f46e5&color=fff`} alt="Profile" className="w-full h-full rounded-full" />
                    </div>
                    <input 
                        type="text" 
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Your name"
                        className="bg-black/40 border border-white/10 w-full focus:bg-black/60 rounded-2xl p-5 text-white outline-none transition-all text-center font-medium text-lg focus:border-orange-500/50 focus:ring-4 focus:ring-orange-500/10"
                    />
                    <button
                        onClick={handleProfileSubmit}
                        disabled={!name.trim()}
                        className="bg-orange-500 hover:bg-orange-600 active:scale-95 text-white w-full px-6 py-4 rounded-2xl flex items-center justify-center gap-2 disabled:opacity-30 group font-semibold text-sm transition-all"
                    >
                        Continue
                    </button>
                </div>
            )}

            {step === 'permissions' && (
                 <div className="space-y-6 relative z-20 text-left">
                    <div className="space-y-2 text-center mb-8">
                        <h3 className="text-xl font-bold text-white">Cloud Sync</h3>
                        <p className="text-sm text-white/50">Connect to synchronize your ecosystem.</p>
                    </div>
                    
                    <div 
                        onClick={() => setDriveAccess(!driveAccess)}
                        className={`flex items-center gap-4 p-5 rounded-2xl cursor-pointer transition-all duration-300 ${driveAccess ? 'bg-orange-500/10 border-orange-500/30' : 'bg-black/40 border border-white/10'}`}
                    >
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 transition-colors ${driveAccess ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/20' : 'bg-white/10 text-white/40'}`}>
                            <HardDrive size={22} />
                        </div>
                        <div className="flex-1">
                            <h4 className="font-semibold text-sm text-white">Google Drive Setup</h4>
                            <p className="text-xs text-white/50">Back up your settings.</p>
                        </div>
                    </div>

                    <div className="p-4 rounded-xl flex items-center gap-3 text-xs text-white/40 justify-center">
                        <Shield size={14} className="shrink-0" />
                        <p>Fully secure integration.</p>
                    </div>

                    <button
                        onClick={handleFinalize}
                        className="bg-orange-500 hover:bg-orange-600 active:scale-95 text-white w-full px-6 py-4 rounded-2xl flex items-center justify-center gap-2 font-semibold text-sm transition-all"
                    >
                        Enter Application
                    </button>
                </div>
            )}
          </motion.div>
        )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};

export default LoginScreen;
