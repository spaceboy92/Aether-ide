import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface SystemLoaderProps {
  message?: string;
  fullScreen?: boolean;
}

const SystemLoader: React.FC<SystemLoaderProps> = ({ message = "Loading Workspace", fullScreen = false }) => {
  const [progress, setProgress] = useState(0);
  const [systemText, setSystemText] = useState("Initializing components");
  const [logs, setLogs] = useState<string[]>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        const increment = Math.random() * 8;
        return Math.min(prev + increment, 100);
      });
    }, 150);

    const texts = [
      "Initializing workspace...",
      "Loading project files...",
      "Setting up developer tools...",
      "Applying theme & layout...",
      "Workspace ready..."
    ];
    
    let textIdx = 0;
    const textInterval = setInterval(() => {
        if (textIdx < texts.length) {
            const nextText = texts[textIdx];
            setSystemText(nextText);
            setLogs(prev => [...prev.slice(-2), nextText]);
            textIdx++;
        }
    }, 800);

    return () => {
      clearInterval(interval);
      clearInterval(textInterval);
    };
  }, []);

  const containerClasses = fullScreen 
    ? "fixed inset-0 z-[100] bg-black/40 backdrop-blur-3xl flex flex-col items-center justify-center overflow-hidden" 
    : "flex-1 flex flex-col items-center justify-center h-full bg-black/50 backdrop-blur-md min-h-[400px]";

  return (
    <div className={containerClasses}>
      <div className="absolute inset-0 bg-gradient-to-tr from-orange-500/10 via-transparent to-amber-500/10 pointer-events-none" />
      <div className="w-80 space-y-10 relative flex flex-col items-center mt-32 z-10 transition-all duration-700">
        <div className="w-full text-center space-y-4">
            <div className="flex flex-col items-center justify-center mb-2">
              <div className="relative">
                <div className="w-20 h-20 rounded-full border-t-2 border-r-2 border-orange-500 animate-spin opacity-80" />
              </div>
            </div>
            <motion.h2 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-white text-3xl font-bold tracking-tight inline-flex items-center gap-3 drop-shadow-[0_0_15px_rgba(255,255,255,0.3)] font-sans"
            >
                Aether
            </motion.h2>
            <motion.p 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-orange-400 text-xs font-semibold tracking-widest font-mono uppercase mt-1 drop-shadow-[0_0_10px_rgba(249,115,22,0.5)]"
            >
                {systemText}
            </motion.p>
        </div>

        {/* Minimalist Progress Bar */}
        <div className="w-48 relative h-1 bg-white/5 rounded-full overflow-hidden shadow-inner">
            <motion.div 
                className="absolute top-0 left-0 h-full bg-gradient-to-r from-orange-400 to-amber-500 rounded-full shadow-[0_0_10px_rgba(249,115,22,0.5)]"
                initial={{ width: "0%" }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.2, ease: "easeOut" }}
            />
        </div>
      </div>
    </div>
  );
};

export default SystemLoader;
