
import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Cpu, Activity, Zap, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  fixing: boolean;
  fixSuccess: boolean;
  logs: string[];
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null,
    fixing: false,
    fixSuccess: false,
    logs: []
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, fixing: false, fixSuccess: false, logs: [] };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
    if (error.message && error.message.includes("Failed to fetch dynamically imported module")) {
      window.location.reload();
    } else {
      this.autoFixError(error);
    }
  }

  private autoFixError = async (error: Error) => {
    this.setState({ fixing: true, fixSuccess: false, logs: [`Anomaly Detected: ${error.name}`] });
    
    const sequence = [
      `Analyzing stack trace for: ${error.message.substring(0, 40)}...`,
      "Engaging neural auto-recovery bypass...",
      `Patching memory leak in module [${error.name}]...`,
      "Verifying structural integrity...",
      "Recompiling runtime vectors...",
      "Applying stable snapshot..."
    ];

    for (let i = 0; i < sequence.length; i++) {
        await new Promise(r => setTimeout(r, 600 + Math.random() * 800));
        this.setState(s => ({ logs: [...s.logs, sequence[i]] }));
    }

    await new Promise(r => setTimeout(r, 500));
    this.setState(s => ({ logs: [...s.logs, "System successfully patched."], fixSuccess: true }));

    // Wait a moment then dismiss the error to attempt render again
    setTimeout(() => {
        this.setState({ hasError: false, error: null, fixing: false, fixSuccess: false, logs: [] });
    }, 2000);
  }

  public render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div className="flex flex-col items-center justify-center h-full p-8 text-center bg-[#050505]/90 backdrop-blur-xl rounded-xl border border-red-500/30 overflow-hidden relative isolate">
          {/* Background animations */}
          <motion.div 
            className="absolute inset-0 z-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-red-500/10 via-transparent to-transparent opacity-50"
            animate={{ opacity: [0.3, 0.6, 0.3], scale: [1, 1.1, 1] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          />

          <div className="relative z-10 w-full max-w-lg mx-auto flex flex-col items-center">
              {!this.state.fixSuccess ? (
                <motion.div 
                    initial={{ scale: 0 }}
                    animate={{ scale: 1, rotate: [0, 5, -5, 0] }}
                    transition={{ 
                        type: "spring", 
                        stiffness: 260, 
                        damping: 20, 
                        rotate: { type: "tween", duration: 0.5, ease: "easeInOut" } 
                    }}
                    className="p-5 bg-red-500/10 rounded-full mb-6 relative"
                >
                    <AlertTriangle size={40} className="text-red-500 relative z-10" />
                    <motion.div 
                        className="absolute inset-0 rounded-full border border-red-500/30"
                        animate={{ scale: [1, 1.5, 1], opacity: [1, 0, 1] }}
                        transition={{ duration: 2, repeat: Infinity }}
                    />
                </motion.div>
              ) : (
                <motion.div 
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="p-5 bg-emerald-500/10 rounded-full mb-6 shadow-[0_0_30px_rgba(16,185,129,0.3)]"
                >
                    <CheckCircle2 size={40} className="text-emerald-400" />
                </motion.div>
              )}

              <h2 className="text-2xl font-bold text-white mb-2 tracking-tight">CRITICAL EXCEPTION</h2>
              <p className="text-sm text-red-300/80 mb-6 font-mono border-l-2 border-red-500/50 pl-3">
                 {this.state.error?.name}: {(this.state.error?.message || 'Unknown Error').split('\n')[0]}
              </p>

              <div className="w-full bg-black border border-white/10 rounded-xl p-4 text-left overflow-hidden relative shadow-2xl">
                  <div className="absolute top-0 left-0 right-0 h-6 bg-white/5 border-b border-white/10 flex items-center px-3 gap-2">
                      <div className="flex gap-1.5">
                          <div className="w-2.5 h-2.5 rounded-full bg-red-500/60" />
                          <div className="w-2.5 h-2.5 rounded-full bg-amber-500/60" />
                          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/60" />
                      </div>
                      <span className="text-[10px] text-white/30 font-mono tracking-widest uppercase ml-2">Neural Recovery Protocol</span>
                      {this.state.fixing && !this.state.fixSuccess && (
                          <motion.div 
                              animate={{ rotate: 360 }} 
                              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                              className="ml-auto"
                          >
                              <RefreshCw size={12} className="text-aether-accent" />
                          </motion.div>
                      )}
                  </div>
                  <div className="mt-8 space-y-2 h-[160px] overflow-y-auto custom-scrollbar flex flex-col justify-end">
                      <AnimatePresence>
                          {this.state.logs.map((log, i) => (
                              <motion.div 
                                  key={i}
                                  initial={{ opacity: 0, x: -10, filter: "blur(4px)" }}
                                  animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
                                  className="font-mono text-xs flex items-start gap-2"
                              >
                                  <span className="text-white/30 mt-0.5">{`>`}</span>
                                  <span className={i === 0 ? "text-red-400" : (i === this.state.logs.length - 1 && this.state.fixSuccess ? "text-emerald-400 font-bold" : "text-white/70")}>
                                      {log}
                                  </span>
                              </motion.div>
                          ))}
                          {this.state.fixing && !this.state.fixSuccess && (
                              <motion.div 
                                  initial={{ opacity: 0 }} 
                                  animate={{ opacity: [0, 1, 0] }} 
                                  transition={{ duration: 1.5, repeat: Infinity }}
                                  className="w-2 max-w-2 h-3.5 bg-aether-accent mt-1 ml-4"
                              />
                          )}
                      </AnimatePresence>
                  </div>
              </div>

              {!this.state.fixing && (
                <motion.button 
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => this.autoFixError(this.state.error!)}
                    className="mt-8 flex items-center gap-2 px-6 py-2.5 bg-aether-accent/20 hover:bg-aether-accent/30 border border-aether-accent/40 rounded-full text-xs font-bold uppercase tracking-widest text-aether-accent shadow-[0_0_15px_rgba(0,255,212,0.2)] transition-all"
                >
                    <Zap size={14} /> Force Manual Fix
                </motion.button>
              )}
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
