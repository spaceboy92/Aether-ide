
import React, { useEffect, useState } from 'react';
import { RuntimeStatus, RuntimeProcess, FileNode } from '../../types';
import { Cpu, Globe, Activity, HardDrive, Package, AlertCircle, RefreshCw, Terminal, ExternalLink, ShieldCheck, ShieldAlert, Cloud, UploadCloud } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getGoogleAuthUrl, syncProjectToDrive } from '../../services/googleDriveService';

interface SetupStatus {
  isInstalling: boolean;
  completed: boolean;
  details?: Record<string, string>;
}

interface EnvironmentPanelProps {
  files: FileNode[];
  projectName?: string;
}

export const EnvironmentPanel: React.FC<EnvironmentPanelProps> = ({ files, projectName = "Untitled Project" }) => {
  const [status, setStatus] = useState<RuntimeStatus>({
    type: 'browser-node',
    isReady: false,
    isBooting: false
  });
  const [setupStatus, setSetupStatus] = useState<SetupStatus | null>(null);
  const [isSupported, setIsSupported] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [driveConnected, setDriveConnected] = useState(!!localStorage.getItem("google_drive_access_token"));

  useEffect(() => {
    const interval = setInterval(async () => {
      try {
        const res = await fetch('/api/setup/status');
        if (res.ok) {
          const contentType = res.headers.get('content-type');
          if (contentType && contentType.includes('application/json')) {
            setSetupStatus(await res.json());
          }
        }
      } catch (e) {
        console.error("Failed to fetch setup status", e);
      }
    }, 5000);

    const handleMessage = (event: MessageEvent) => {
      if (event.data.type === 'GOOGLE_DRIVE_AUTH_SUCCESS') {
        localStorage.setItem("google_drive_access_token", JSON.stringify(event.data.tokens));
        setDriveConnected(true);
      }
    };

    window.addEventListener('message', handleMessage);

    return () => {
      clearInterval(interval);
      window.removeEventListener('message', handleMessage);
    };
  }, []);

  const handleBoot = () => {
    console.log("Local VM is disabled");
  };

  const handleConnectDrive = async () => {
    try {
      const url = await getGoogleAuthUrl();
      window.open(url, '_blank', 'width=600,height=600');
    } catch (e) {
      console.error("Failed to get auth URL", e);
    }
  };

  const handleSync = async () => {
    const tokenStr = localStorage.getItem("google_drive_access_token");
    if (!tokenStr) {
      handleConnectDrive();
      return;
    }

    setIsSyncing(true);
    try {
      const tokens = JSON.parse(tokenStr);
      await syncProjectToDrive(tokens, projectName, files);
      alert("Project successfully synced to Aether Projects folder in Google Drive!");
    } catch (e: any) {
      console.error("Sync failed", e);
      if (e.message.includes("expired")) {
        setDriveConnected(false);
      }
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0a0a0a] border-l border-white/5 w-80 shrink-0 overflow-y-auto custom-scrollbar">
      <div className="p-4 border-b border-white/5 flex items-center justify-between">
        <h2 className="text-[10px] font-black uppercase tracking-widest text-zinc-500">Local Runtime</h2>
        <div className={`w-2 h-2 rounded-full ${status.isReady ? 'bg-emerald-500 shadow-[0_0_8px_#10b981]' : status.isBooting ? 'bg-amber-500 animate-pulse' : 'bg-zinc-700'}`} />
      </div>

      <div className="p-6 space-y-8">
        {/* Google Drive Sync */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest">Storage Sync</h3>
            <div className={`w-1.5 h-1.5 rounded-full ${driveConnected ? 'bg-blue-500 shadow-[0_0_8px_#3b82f6]' : 'bg-zinc-700'}`} />
          </div>
          <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-4">
             <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-blue-500/10 rounded-xl">
                  <Cloud className="w-4 h-4 text-blue-500" />
                </div>
                <div>
                  <p className="text-xs font-bold text-white">Google Drive</p>
                  <p className="text-[10px] text-zinc-500">{driveConnected ? 'Cloud Linked' : 'Offline Storage'}</p>
                </div>
             </div>
             
             <button 
               onClick={handleSync}
               disabled={isSyncing}
               className="w-full py-2 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-all active:scale-95"
             >
               {isSyncing ? (
                 <RefreshCw className="w-3 h-3 animate-spin" />
               ) : (
                 <UploadCloud className="w-3 h-3" />
               )}
               {driveConnected ? 'Sync Project' : 'Connect & Sync'}
             </button>
          </div>
        </section>

        {/* Browser Capability */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs text-zinc-400 font-medium">Browser Capability</span>
            {isSupported ? (
              <div className="flex items-center gap-1.5 px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
                <ShieldCheck className="w-3 h-3 text-emerald-400" />
                <span className="text-[10px] text-emerald-400 font-bold">Compatible</span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 px-2 py-0.5 bg-red-500/10 border border-red-500/20 rounded-full">
                <ShieldAlert className="w-3 h-3 text-red-400" />
                <span className="text-[10px] text-red-400 font-bold">Isolated</span>
              </div>
            )}
          </div>
          {!isSupported && (
             <p className="text-[10px] text-zinc-500 leading-relaxed italic">
               Note: To enable full Browser-based Node.js (WebContainers), ensure you are on a modern desktop browser and the server is sending COOP/COEP headers.
             </p>
          )}
        </section>

        {/* Global Setup Status */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest">Aether Network Setup</h3>
            {setupStatus?.isInstalling && <RefreshCw className="w-2.5 h-2.5 text-blue-400 animate-spin" />}
          </div>
          <div className="space-y-2">
            {setupStatus?.details ? (
              Object.entries(setupStatus.details).map(([key, val]) => (
                <div key={key} className="flex items-center justify-between p-2.5 bg-white/[0.02] border border-white/5 rounded-xl group hover:border-white/10 transition-colors">
                  <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-tight">{key}</span>
                  <span className={`text-[10px] font-black ${(val.includes('Ready') || val.includes('Installed')) ? 'text-emerald-500' : val.includes('Checking') ? 'text-amber-500' : 'text-zinc-600'}`}>
                    {val}
                  </span>
                </div>
              ))
            ) : (
              <div className="p-4 bg-white/[0.01] border border-dashed border-white/5 rounded-xl text-center">
                <p className="text-[10px] text-zinc-600">No backend data available</p>
              </div>
            )}
          </div>
        </section>

        {/* Status Card */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs text-zinc-400 font-medium">Environment Status</span>
            {!status.isReady && !status.isBooting && (
              <button 
                onClick={handleBoot}
                className="text-[10px] bg-orange-500 hover:bg-orange-600 text-white px-3 py-1 rounded-full font-bold transition-all active:scale-95"
              >
                Initialize
              </button>
            )}
          </div>
          <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-4">
            <div className="flex items-center gap-3 mb-3">
               <div className="p-2 bg-blue-500/10 rounded-xl">
                 <Cpu className={`w-4 h-4 ${status.isBooting ? 'animate-spin text-blue-400' : 'text-blue-500'}`} />
               </div>
               <div>
                 <p className="text-xs font-bold text-white">{status.isReady ? 'System Operational' : status.isBooting ? 'Optimizing Core...' : 'Standby Mode'}</p>
                 <p className="text-[10px] text-zinc-500">{status.version || 'No active runtime'}</p>
               </div>
            </div>
            
            {status.error && (
              <div className="mt-3 p-2 bg-red-500/10 border border-red-500/20 rounded-lg flex items-start gap-2">
                <AlertCircle className="w-3 h-3 text-red-400 shrink-0 mt-0.5" />
                <p className="text-[10px] text-red-400 leading-relaxed">{status.error}</p>
              </div>
            )}
          </div>
        </section>

        {/* Resources */}
        <section>
          <h3 className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest mb-4">System Resources</h3>
          <div className="grid grid-cols-2 gap-3">
             <div className="p-3 bg-white/[0.02] border border-white/5 rounded-2xl">
                <Activity className="w-3 h-3 text-orange-400 mb-2" />
                <p className="text-[10px] text-zinc-500 uppercase">CPU Usage</p>
                <p className="text-sm font-bold text-white">0.02%</p>
             </div>
             <div className="p-3 bg-white/[0.02] border border-white/5 rounded-2xl">
                <HardDrive className="w-3 h-3 text-emerald-400 mb-2" />
                <p className="text-[10px] text-zinc-500 uppercase">Heap Used</p>
                <p className="text-sm font-bold text-white">{status.memoryUsage ? `${(status.memoryUsage / 1024 / 1024).toFixed(1)} MB` : '1.4 MB'}</p>
             </div>
          </div>
        </section>

        {/* Network / Ports */}
        <section>
          <h3 className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest mb-4">Network Ingress</h3>
          <div className="space-y-2">
            {status.openPorts && status.openPorts.length > 0 ? (
              status.openPorts.map(port => (
                <div key={port} className="flex items-center justify-between p-3 bg-white/[0.02] border border-white/5 rounded-2xl group hover:border-blue-500/30 transition-all cursor-pointer">
                  <div className="flex items-center gap-3">
                    <Globe className="w-3 h-3 text-blue-400" />
                    <span className="text-xs text-white font-medium">Port {port}</span>
                  </div>
                  <ExternalLink className="w-3 h-3 text-zinc-600 group-hover:text-blue-400 transition-colors" />
                </div>
              ))
            ) : (
              <div className="text-center py-6 bg-white/[0.01] border border-dashed border-white/5 rounded-2xl">
                <p className="text-[10px] text-zinc-600">No active network listeners</p>
              </div>
            )}
          </div>
        </section>

        {/* Deployment Metadata */}
        <section>
           <h3 className="text-[10px] font-bold text-zinc-600 uppercase tracking-widest mb-4">Package Context</h3>
           <div className="flex flex-wrap gap-1.5">
             <span className="flex items-center gap-1.5 px-2 py-1 bg-zinc-900 border border-white/5 rounded text-[10px] text-zinc-400 font-medium capitalize">
               <Package className="w-3 h-3" /> {status.packageManager || 'npm'}
             </span>
             <span className="flex items-center gap-1.5 px-2 py-1 bg-zinc-900 border border-white/5 rounded text-[10px] text-zinc-400 font-medium">
               <Terminal className="w-3 h-3" /> jsh
             </span>
           </div>
        </section>
      </div>

      <div className="mt-auto p-4 border-t border-white/5 bg-white/[0.01]">
        <div className="flex items-center justify-between text-[10px] text-zinc-600 font-bold uppercase tracking-tighter">
          <span>Aether Engine</span>
          <span>v1.0.4-LNX</span>
        </div>
      </div>
    </div>
  );
};
