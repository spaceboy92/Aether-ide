import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  X, 
  ChevronRight, 
  ChevronLeft, 
  Sparkles, 
  Code2, 
  Eye, 
  MessageSquare, 
  Settings, 
  CloudUpload,
  Terminal,
  Activity,
  ShoppingBag,
  Cpu,
  Rocket
} from "lucide-react";

interface Step {
  title: string;
  description: string;
  icon: React.ReactNode;
  color: string;
}

const steps: Step[] = [
  {
    title: "Welcome to Aether",
    description: "Your next-generation cinematic IDE powered by local-first principles and cloud-sync robustness. Let's get you acclimated.",
    icon: <Sparkles className="text-orange-400" size={32} />,
    color: "from-orange-500/20 to-transparent"
  },
  {
    title: "The Sidebar",
    description: "Manage your sessions, project files, and system tools. Use the icons on the left to switch between File Explorer, Search, Marketplace, and Settings.",
    icon: <Code2 className="text-emerald-400" size={32} />,
    color: "from-emerald-500/20 to-transparent"
  },
  {
    title: "AI Workspace",
    description: "The AI Assistant is your core partner. It can write code, fix bugs, and even generate entire applications from a single prompt.",
    icon: <MessageSquare className="text-blue-400" size={32} />,
    color: "from-blue-500/20 to-transparent"
  },
  {
    title: "Live Preview",
    description: "See your changes in real-time. Use the Preview tab to interact with your application as you build it.",
    icon: <Eye className="text-amber-400" size={32} />,
    color: "from-amber-500/20 to-transparent"
  },
  {
    title: "Project Studio",
    description: "Switch to the Studio tab for advanced AI experiments, including image generation and autonomous neural agent interactions.",
    icon: <Cpu className="text-amber-400" size={32} />,
    color: "from-amber-500/20 to-transparent"
  },
  {
    title: "Google Drive Sync",
    description: "All your data is automatically backed up to your Google Drive in the 'Aether IDE' folder. Never lose a line of code again.",
    icon: <CloudUpload className="text-sky-400" size={32} />,
    color: "from-sky-500/20 to-transparent"
  },
  {
    title: "System Terminal",
    description: "Monitor real-time logs and system health. Press Ctrl+J at any time to open the diagnostics terminal.",
    icon: <Terminal className="text-zinc-400" size={32} />,
    color: "from-zinc-500/20 to-transparent"
  },
  {
    title: "Marketplace",
    description: "Enhance your environment with professional add-ons, themes, and pre-built neural components from the Marketplace.",
    icon: <ShoppingBag className="text-pink-400" size={32} />,
    color: "from-pink-500/20 to-transparent"
  },
  {
    title: "Command Palette",
    description: "Press Ctrl+K (or Cmd+K) to open the Command Palette. It's the fastest way to run commands, create files, and navigate the IDE.",
    icon: <Activity className="text-orange-400" size={32} />,
    color: "from-orange-500/20 to-transparent"
  },
  {
    title: "Neural Deployment",
    description: "Ready to go live? Use the Publish button to deploy your project to the Aether Cloud and get a shareable public link instantly.",
    icon: <Rocket className="text-red-400" size={32} />,
    color: "from-red-500/20 to-transparent"
  }
];

interface TutorialModalProps {
  onClose: () => void;
}

const TutorialModal: React.FC<TutorialModalProps> = ({ onClose }) => {
  const [currentStep, setCurrentStep] = useState(0);

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  return (
    <div className="fixed bottom-8 right-8 z-[200] flex items-end justify-end pointer-events-none">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        className="bg-zinc-900/90 backdrop-blur-2xl border border-white/10 w-full max-w-[400px] rounded-[2rem] overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.5)] relative pointer-events-auto"
      >
        <div className={`absolute top-0 left-0 w-full h-32 bg-gradient-to-b ${steps[currentStep].color} pointer-events-none transition-all duration-700`} />
        
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-2 hover:bg-white/5 rounded-full text-white/40 hover:text-white transition-colors z-10"
        >
          <X size={16} />
        </button>

        <div className="p-8 space-y-6 relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-4"
            >
              <div className="w-12 h-12 rounded-2xl bg-white/[0.03] border border-white/5 flex items-center justify-center ring-1 ring-white/10 shadow-inner">
                {steps[currentStep].icon}
              </div>
              
              <div className="space-y-1.5 text-left">
                <h2 className="text-xl font-bold tracking-tight text-white">{steps[currentStep].title}</h2>
                <p className="text-white/50 text-sm leading-relaxed font-medium">
                  {steps[currentStep].description}
                </p>
              </div>
            </motion.div>
          </AnimatePresence>

          <div className="flex items-center justify-between pt-2">
            <div className="flex gap-1">
              {steps.map((_, i) => (
                <div 
                  key={i}
                  className={`h-1 rounded-full transition-all duration-300 ${i === currentStep ? 'w-4 bg-white' : 'w-1 bg-white/10'}`}
                />
              ))}
            </div>

            <div className="flex gap-2">
              {currentStep > 0 && (
                <button
                  onClick={handlePrev}
                  className="p-3 rounded-xl bg-white/5 hover:bg-white/10 text-white transition-all flex items-center gap-2 group"
                >
                  <ChevronLeft size={16} />
                </button>
              )}
              
              <button
                onClick={handleNext}
                className="px-6 py-3 bg-white text-black rounded-xl font-black text-[10px] uppercase tracking-[0.1em] hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2 shadow-xl"
              >
                {currentStep === steps.length - 1 ? "Finish" : "Next"}
                {currentStep < steps.length - 1 && <ChevronRight size={14} />}
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default TutorialModal;
