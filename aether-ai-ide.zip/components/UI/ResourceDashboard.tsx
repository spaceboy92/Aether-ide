import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  Cpu, HardDrive, Activity, Zap, Network, Thermometer, ShieldCheck, 
  Terminal, Download, RefreshCw, Layers, CheckCircle, AlertCircle, 
  Search, Play, Sliders, Server
} from 'lucide-react';

interface ResourceDashboardProps {
  stats: {
    cpu: string;
    mem: string;
    uptime: string;
    packetLoss: string;
  };
  onClose: () => void;
  activeSessionId?: string | null;
  onOptimizeMemory?: () => void;
  perfMode?: 'high' | 'low';
  onTogglePerfMode?: () => void;
  chatCompactMode?: boolean;
  onToggleChatCompact?: () => void;
}

interface ProcessItem {
  uid: string;
  pid: string;
  ppid: string;
  time: string;
  cmd: string;
}

const POPULAR_NPM = ['lodash', 'axios', 'canvas-confetti', 'lucide-react', 'recharts', 'framer-motion'];

const ResourceDashboard: React.FC<ResourceDashboardProps> = ({ 
  stats, 
  onClose, 
  activeSessionId, 
  onOptimizeMemory, 
  perfMode, 
  onTogglePerfMode,
  chatCompactMode,
  onToggleChatCompact
}) => {
  const [activeTab, setActiveTab] = useState<'status' | 'processes' | 'libraries'>('status');
  
  // Processes state
  const [processes, setProcesses] = useState<ProcessItem[]>([]);
  const [procLoading, setProcLoading] = useState(false);
  const [procError, setProcError] = useState<string | null>(null);
  const [procFilter, setProcFilter] = useState('');

  // Disk & Kernel details
  const [diskSpace, setDiskSpace] = useState<string>('Querying...');
  const [kernelInfo, setKernelInfo] = useState<string>('Querying...');

  // Library Installer state
  const [installType] = useState<'npm'>('npm');
  const [packageName, setPackageName] = useState('');
  const [installing, setInstalling] = useState(false);
  const [installLog, setInstallLog] = useState<string[]>([]);
  const [installStatus, setInstallStatus] = useState<'idle' | 'running' | 'success' | 'failed'>('idle');

  // Fetch disk space and kernel details on status tab load
  useEffect(() => {
    if (activeTab === 'status') {
      // Execute df -h
      fetch('/api/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: 'df -h /', sessionId: activeSessionId })
      })
      .then(res => res.json())
      .then(data => {
        if (data.stdout) {
          const lines = data.stdout.trim().split('\n');
          if (lines.length > 1) {
            setDiskSpace(lines[1]); // Show the root filesystem disk line
          } else {
            setDiskSpace(data.stdout);
          }
        } else {
          setDiskSpace('Disk status unavailable');
        }
      })
      .catch(() => setDiskSpace('Disk query failed'));

      // Execute uname -r
      fetch('/api/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: 'uname -srm', sessionId: activeSessionId })
      })
      .then(res => res.json())
      .then(data => {
        setKernelInfo(data.stdout?.trim() || 'Cloud Sandbox Kernel');
      })
      .catch(() => setKernelInfo('Kernel query failed'));
    }
  }, [activeTab, activeSessionId]);

  // Fetch processes list
  const fetchProcesses = async () => {
    setProcLoading(true);
    setProcError(null);
    try {
      const res = await fetch('/api/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: 'ps -ef', sessionId: activeSessionId })
      });
      const data = await res.json();
      if (data.stdout) {
        const lines = data.stdout.trim().split('\n');
        // UID        PID  PPID  C STIME TTY          TIME CMD
        const parsed: ProcessItem[] = [];
        for (let i = 1; i < lines.length; i++) {
          const line = lines[i].trim();
          if (!line) continue;
          const parts = line.split(/\s+/);
          if (parts.length >= 8) {
            parsed.push({
              uid: parts[0],
              pid: parts[1],
              ppid: parts[2],
              time: parts[6],
              cmd: parts.slice(7).join(' ')
            });
          }
        }
        setProcesses(parsed);
      } else if (data.error) {
        setProcError(data.error);
      }
    } catch (e: any) {
      setProcError(e.message || 'Failed to connect to the backend container');
    } finally {
      setProcLoading(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'processes') {
      fetchProcesses();
    }
  }, [activeTab]);

  // Handle Library Install execution
  const handleInstall = async (pkg: string = packageName) => {
    const targetPkg = pkg.trim();
    if (!targetPkg) return;

    setInstalling(true);
    setInstallStatus('running');
    setInstallLog(prev => [...prev, `[INIT] Spawning package installation worker for ${targetPkg}...`]);
    
    const cmd = installType === 'npm' 
      ? `npm install ${targetPkg} --no-audit --no-fund` 
      : installType === 'pip'
      ? `pip install ${targetPkg}`
      : `flutter pub add ${targetPkg}`;

    setInstallLog(prev => [...prev, `[EXEC] Running command: ${cmd}`]);

    try {
      const res = await fetch('/api/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: cmd, sessionId: activeSessionId })
      });
      const data = await res.json();
      
      if (data.stdout) {
        setInstallLog(prev => [...prev, ...data.stdout.split('\n')]);
      }
      if (data.stderr) {
        setInstallLog(prev => [...prev, `[WARN] ${data.stderr}`]);
      }

      if (res.ok && !data.error) {
        setInstallLog(prev => [...prev, `[SUCCESS] Package ${targetPkg} installed successfully in workspace.`]);
        setInstallStatus('success');
        setPackageName('');
      } else {
        const errMsg = data.error || 'Execution returned non-zero exit code';
        setInstallLog(prev => [...prev, `[ERROR] Installation failed: ${errMsg}`]);
        setInstallStatus('failed');
      }
    } catch (err: any) {
      setInstallLog(prev => [...prev, `[CRITICAL] Network error: ${err.message}`]);
      setInstallStatus('failed');
    } finally {
      setInstalling(false);
    }
  };

  const filteredProcesses = processes.filter(p => 
    p.cmd.toLowerCase().includes(procFilter.toLowerCase()) || 
    p.pid.includes(procFilter) ||
    p.uid.toLowerCase().includes(procFilter.toLowerCase())
  );

  return (
    <div className="flex-1 flex flex-col p-6 space-y-6 overflow-y-auto custom-scrollbar min-h-0 bg-neutral-950 text-white">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <Server className="text-orange-500 animate-pulse" size={24} />
          <div>
            <h2 className="text-base font-black tracking-tighter text-white uppercase">
              Cloud VM Control Panel
            </h2>
            <p className="text-[10px] font-medium text-white/40 font-mono leading-none mt-1">
              CONTAINER ID: 65d7647b • HOST: 0.0.0.0
            </p>
          </div>
        </div>
        <div className="px-3 py-1 bg-orange-500/10 border border-orange-500/20 rounded-full flex items-center gap-2">
          <div className="w-1.5 h-1.5 bg-orange-500 rounded-full animate-pulse" />
          <span className="text-[10px] font-bold text-orange-400 uppercase tracking-widest">
            {activeSessionId ? 'Project Loaded' : 'Standalone'}
          </span>
        </div>
      </div>

      {/* Control Panel Tabs */}
      <div className="flex border-b border-white/5 bg-white/[0.02] p-1 rounded-xl">
        {[
          { id: 'status', label: 'System status', icon: Sliders },
          { id: 'processes', label: 'Processes', icon: Activity },
          { id: 'libraries', label: 'Library Installer', icon: Download }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs font-bold tracking-wider transition-all uppercase ${
              activeTab === tab.id 
                ? 'bg-orange-600 text-white shadow-md shadow-orange-500/10' 
                : 'text-white/40 hover:text-white/90 hover:bg-white/5'
            }`}
          >
            <tab.icon size={14} />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div className="flex-1 min-h-0">
        {activeTab === 'status' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* CPU Usage */}
              <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-blue-500/10 rounded-lg">
                      <Cpu size={18} className="text-blue-400" />
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-white/40 uppercase tracking-widest">Processor Load</p>
                      <p className="text-lg font-bold text-white font-mono">{stats.cpu}%</p>
                    </div>
                  </div>
                </div>
                <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${parseFloat(stats.cpu) || 0}%` }}
                    className="h-full bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]"
                  />
                </div>
              </div>

              {/* Memory Usage */}
              <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-purple-500/10 rounded-lg">
                      <HardDrive size={18} className="text-purple-400" />
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-white/40 uppercase tracking-widest">Memory Allocation</p>
                      <p className="text-lg font-bold text-white font-mono">{stats.mem}</p>
                    </div>
                  </div>
                </div>
                <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${parseInt(stats.mem) || 0}%` }}
                    className="h-full bg-purple-500 shadow-[0_0_10px_rgba(168,85,247,0.5)]"
                  />
                </div>
              </div>

              {/* Disk usage from real system */}
              <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-pink-500/10 rounded-lg">
                      <HardDrive size={18} className="text-pink-400" />
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-white/40 uppercase tracking-widest">Storage Status</p>
                      <p className="text-sm font-bold text-white font-mono truncate max-w-xs">{diskSpace}</p>
                    </div>
                  </div>
                </div>
                <p className="text-[9px] font-mono text-white/40 leading-tight">
                  Queried live filesystem capacity from current sandbox instance.
                </p>
              </div>

              {/* Host / Kernel info */}
              <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-emerald-500/10 rounded-lg">
                      <Zap size={18} className="text-emerald-400" />
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-white/40 uppercase tracking-widest">Kernel / OS Info</p>
                      <p className="text-sm font-bold text-white font-mono truncate max-w-xs">{kernelInfo}</p>
                    </div>
                  </div>
                </div>
                <p className="text-[9px] font-mono text-white/40 leading-tight">
                  Running on a real isolated Cloud Sandbox virtualization layer.
                </p>
              </div>

              {/* Memory Optimization Controls */}
              <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-5 md:col-span-2">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-orange-500/10 rounded-lg">
                      <Zap size={18} className="text-orange-400" />
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-white/40 uppercase tracking-widest">Neural Performance Optimization</p>
                      <p className="text-sm font-bold text-white uppercase tracking-tight">Active Mode: {perfMode === 'low' ? 'Low Resource (Target 200MB)' : 'Standard (Target 500MB)'}</p>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <button 
                    onClick={onOptimizeMemory}
                    className="flex-1 py-2.5 bg-orange-500/20 hover:bg-orange-500/30 border border-orange-500/30 rounded-xl text-[10px] font-black text-orange-400 uppercase tracking-widest transition-all"
                  >
                    🚀 Trigger Memory Boost
                  </button>
                  <button 
                    onClick={onTogglePerfMode}
                    className={`flex-1 py-2.5 border rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${perfMode === 'low' ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' : 'bg-white/5 text-white/60 border-white/10 hover:text-white'}`}
                  >
                    {perfMode === 'low' ? '⚡ Disable Low-Resource Mode' : '🍃 Enable Low-Resource Mode'}
                  </button>
                </div>
                <div className="flex flex-col sm:flex-row gap-3 mt-3">
                  <button 
                    onClick={onToggleChatCompact}
                    className={`flex-1 py-2.5 border rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${chatCompactMode ? 'bg-orange-500/20 text-orange-400 border-orange-500/30' : 'bg-white/5 text-white/60 border-white/10 hover:text-white'}`}
                  >
                    {chatCompactMode ? '✨ Disable Neural Compaction' : '💎 Enable Neural Compaction'}
                  </button>
                </div>
                <p className="text-[9px] font-mono text-white/30 mt-3 italic">
                  Neural Compaction (Chat Compatibility) prunes non-essential AI reasoning and strictly limits response length to 1000 tokens for maximum efficiency.
                </p>
              </div>
            </div>

            {/* Static Security Rows */}
            <div className="space-y-3">
              <h3 className="text-[10px] font-black text-white/60 uppercase tracking-[0.2em]">Sandbox Environment Parameters</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { icon: ShieldCheck, label: 'Execution Sandbox', status: 'Isolated' },
                  { icon: Thermometer, label: 'Thermal Profile', status: 'Optimal' },
                  { icon: Network, label: 'Vite Reverse Proxy', status: 'Port 3000' },
                ].map((item, i) => (
                  <div key={i} className="flex items-center justify-between p-3.5 bg-white/[0.01] border border-white/5 rounded-xl">
                    <div className="flex items-center gap-3">
                      <item.icon size={14} className="text-orange-400" />
                      <span className="text-[11px] font-medium text-white/80">{item.label}</span>
                    </div>
                    <span className="text-[9px] font-black text-orange-400 uppercase">{item.status}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'processes' && (
          <div className="space-y-4 flex flex-col h-full max-h-[380px]">
            {/* Toolbar */}
            <div className="flex gap-3 items-center shrink-0">
              <div className="flex-1 bg-white/[0.03] border border-white/5 rounded-xl px-3 py-2 flex items-center gap-2">
                <Search size={14} className="text-white/30" />
                <input 
                  type="text" 
                  value={procFilter}
                  onChange={(e) => setProcFilter(e.target.value)}
                  placeholder="Filter processes by name or PID..." 
                  className="flex-1 bg-transparent border-none outline-none text-xs text-white placeholder:text-white/20"
                />
              </div>
              <button 
                onClick={fetchProcesses}
                disabled={procLoading}
                className="p-2.5 bg-white/5 hover:bg-white/10 rounded-xl border border-white/5 text-white/60 hover:text-white transition-all disabled:opacity-50"
                title="Refresh Process List"
              >
                <RefreshCw size={14} className={procLoading ? 'animate-spin' : ''} />
              </button>
            </div>

            {/* Process list table */}
            <div className="flex-1 min-h-0 bg-black/40 border border-white/5 rounded-2xl overflow-hidden flex flex-col">
              <div className="grid grid-cols-5 gap-4 px-4 py-2.5 bg-white/[0.02] border-b border-white/5 text-[9px] font-black text-white/40 uppercase tracking-wider font-sans shrink-0">
                <span>UID</span>
                <span>PID</span>
                <span>PPID</span>
                <span>TIME</span>
                <span className="col-span-2">COMMAND</span>
              </div>
              <div className="flex-1 overflow-y-auto p-2 space-y-1 custom-scrollbar text-[11px] font-mono">
                {procLoading ? (
                  <div className="flex flex-col items-center justify-center h-32 space-y-2">
                    <RefreshCw size={20} className="text-orange-500 animate-spin" />
                    <span className="text-white/40 text-xs italic">Reading container processes...</span>
                  </div>
                ) : procError ? (
                  <div className="p-4 text-center text-red-400 text-xs italic flex items-center justify-center gap-2">
                    <AlertCircle size={14} />
                    {procError}
                  </div>
                ) : filteredProcesses.length === 0 ? (
                  <div className="p-4 text-center text-white/20 text-xs italic">
                    No processes matching filters found
                  </div>
                ) : (
                  filteredProcesses.map((p, idx) => (
                    <div key={idx} className="grid grid-cols-5 gap-4 px-2 py-1.5 hover:bg-white/[0.02] rounded-lg transition-colors border-b border-white/[0.01]">
                      <span className="text-white/60 truncate">{p.uid}</span>
                      <span className="text-orange-400 font-bold">{p.pid}</span>
                      <span className="text-white/40">{p.ppid}</span>
                      <span className="text-white/60">{p.time}</span>
                      <span className="col-span-2 text-white truncate text-[10px]" title={p.cmd}>{p.cmd}</span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'libraries' && (
          <div className="space-y-4 flex flex-col h-full max-h-[380px]">
            {/* Selector and Input Row */}
            <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-4 space-y-3 shrink-0">
              {/* Popular list */}
              <div>
                <span className="text-[9px] font-black text-white/30 uppercase tracking-wider block mb-2 font-sans">Popular NPM Packages</span>
                <div className="flex flex-wrap gap-1.5">
                  {POPULAR_NPM.map(pkg => (
                    <button
                      key={pkg}
                      onClick={() => { setPackageName(pkg); }}
                      disabled={installing}
                      className="px-2.5 py-1 bg-white/[0.03] hover:bg-orange-500/10 hover:text-orange-400 border border-white/5 rounded-lg text-[10px] font-mono transition-all"
                    >
                      + {pkg}
                    </button>
                  ))}
                </div>
              </div>

              {/* Install execution bar */}
              <div className="flex gap-2 pt-2">
                <div className="flex-1 bg-black/40 border border-white/5 rounded-xl px-3 py-2.5 flex items-center gap-2">
                  <Terminal size={14} className="text-white/30" />
                  <input 
                    type="text" 
                    value={packageName}
                    onChange={(e) => setPackageName(e.target.value)}
                    placeholder="e.g., axios, lucide-react"
                    className="flex-1 bg-transparent border-none outline-none text-xs font-mono text-white placeholder:text-white/20"
                    disabled={installing}
                  />
                </div>
                <button
                  onClick={() => handleInstall()}
                  disabled={installing || !packageName.trim()}
                  className="px-5 py-2.5 bg-orange-600 hover:bg-orange-500 disabled:opacity-40 text-white font-bold rounded-xl text-xs transition-all flex items-center gap-2 cursor-pointer"
                >
                  {installing ? (
                    <RefreshCw size={14} className="animate-spin" />
                  ) : (
                    <Download size={14} />
                  )}
                  Install
                </button>
              </div>
            </div>

            {/* Logging terminal */}
            <div className="flex-1 min-h-0 bg-black/80 border border-white/10 rounded-2xl p-4 font-mono text-[10px] overflow-y-auto custom-scrollbar flex flex-col">
              <div className="flex items-center justify-between border-b border-white/5 pb-2 mb-2 shrink-0">
                <span className="text-[8px] text-white/30 font-bold uppercase tracking-widest">Install Logs</span>
                {installStatus === 'running' && <span className="text-orange-400 animate-pulse text-[9px]">Downloading...</span>}
                {installStatus === 'success' && <span className="text-emerald-400 flex items-center gap-1 text-[9px] font-bold"><CheckCircle size={10} /> Finished</span>}
                {installStatus === 'failed' && <span className="text-red-400 flex items-center gap-1 text-[9px] font-bold"><AlertCircle size={10} /> Failed</span>}
              </div>
              <div className="flex-1 overflow-y-auto space-y-1">
                {installLog.length === 0 ? (
                  <div className="text-white/20 italic">Terminal ready. Choose a package to install above...</div>
                ) : (
                  installLog.map((log, idx) => (
                    <div key={idx} className={`whitespace-pre-wrap leading-tight ${
                      log.startsWith('[ERROR]') ? 'text-red-400' :
                      log.startsWith('[SUCCESS]') ? 'text-emerald-400 font-bold' :
                      log.startsWith('[EXEC]') ? 'text-blue-400 font-bold' :
                      log.startsWith('[INIT]') ? 'text-orange-400' : 'text-white/70'
                    }`}>
                      {log}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Primary Action Button */}
      <div className="pt-2 shrink-0">
        <button 
          onClick={onClose}
          className="w-full py-3 bg-white text-black text-[10px] font-black uppercase tracking-[0.2em] rounded-xl hover:bg-neutral-200 transition-all active:scale-95"
        >
          Close Control Panel
        </button>
      </div>
    </div>
  );
};

export default ResourceDashboard;
