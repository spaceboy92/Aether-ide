
import React from 'react';
import { motion } from 'motion/react';

interface InteractiveCardProps {
  children: React.ReactNode;
  onClick?: () => void;
  className?: string;
  ariaLabel?: string;
  delay?: number;
}

const InteractiveCard: React.FC<InteractiveCardProps> = ({ 
  children, 
  onClick, 
  className = "", 
  ariaLabel = "Interactive element",
  delay = 0 
}) => {
  return (
    <motion.div
      onClick={onClick}
      aria-label={ariaLabel}
      role={onClick ? "button" : "region"}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={(e) => onClick && (e.key === 'Enter' || e.key === ' ') && onClick()}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: delay / 1000, ease: [0.23, 1, 0.32, 1] }}
      whileHover={{ y: -5, scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className={`
        group relative overflow-hidden rounded-3xl border border-white/5 bg-[#1A1A1A] p-6 
        cursor-pointer shadow-lg
        transition-colors duration-300
        hover:border-orange-500/30 hover:bg-[#222222]
        ${className}
      `}
    >
      {/* Glare Effect */}
      <div className="absolute inset-0 bg-gradient-to-tr from-orange-500/10 via-transparent to-amber-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
      
      {/* Inner Content */}
      <div className="relative z-10 h-full flex flex-col">
        {children}
      </div>
    </motion.div>
  );
};

export default InteractiveCard;
