import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sliders, 
  Activity, 
  Orbit, 
  Zap, 
  Sparkles, 
  RefreshCw, 
  Info, 
  Play, 
  Trash2, 
  ChevronDown, 
  ChevronUp, 
  Eye, 
  EyeOff, 
  VolumeX, 
  Cpu 
} from 'lucide-react';

interface BlackHoleBackgroundProps {
  isLowPerf?: boolean;
}

// Structs for simulation components
interface CosmicNebula {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
}

interface BackgroundStar {
  originalX: number;
  originalY: number;
  brightness: number;
  size: number;
  color: string;
}

interface AccretionParticle {
  r: number;
  phi: number;
  speed: number;
  size: number;
  color: string;
  type: 'inner' | 'mid' | 'outer';
  temp: number; // 0 to 1
  baseHue: number;
  x: number;
  y: number;
}

interface JetParticle {
  dist: number;
  offset: number;
  spiralAngle: number;
  speed: number;
  spiralSpeed: number;
  size: number;
  color: string;
  direction: 1 | -1; // 1 = north, -1 = south
  alpha: number;
}

interface HawkingParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  life: number;
  maxLife: number;
  type: 'positive' | 'negative';
}

interface Probe {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  dist: number;
  initialDist: number;
  trail: { x: number; y: number }[];
  status: 'orbiting' | 'devoured' | 'escaping';
  timeDilation: number;
  localTime: number;
  speed: number;
  color: string;
}

const GRAVITY = 0.55; // Core gravity constant

const BlackHoleBackground: React.FC<BlackHoleBackgroundProps> = ({ isLowPerf = false }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // HUD UI State
  const [isCollapsed, setIsCollapsed] = useState(true);
  const [mass, setMass] = useState(380); // Corresponds to event horizon size
  const [spin, setSpin] = useState(0.75); // Kerr parameter, affects speeds & Doppler warping
  const [jetIntensity, setJetIntensity] = useState(0.6); // Astrophysical jet strength
  const [beamingEnabled, setBeamingEnabled] = useState(true); // Doppler beaming
  const [lensingEnabled, setLensingEnabled] = useState(true); // Gravitational lensing
  const [hawkingEnabled, setHawkingEnabled] = useState(true); // Hawking radiation
  const [nebulaEnabled, setNebulaEnabled] = useState(true); // Drifting cosmic dust
  const [interactiveEnabled, setInteractiveEnabled] = useState(false); // Enable mouse gravity & probe launch
  const [colorTheme, setColorTheme] = useState<'amber' | 'cyan' | 'purple' | 'crimson'>('amber');
  
  // Real-time telemetry feed throttled to React
  const [probeTelemetry, setProbeTelemetry] = useState<Omit<Probe, 'trail' | 'x' | 'y' | 'vx' | 'vy'>[]>([]);
  const [hudStats, setHudStats] = useState({
    horizonRadiusKm: 0,
    hawkingTemp: '',
    entropy: '',
    spaceCurvature: '',
    elapsedTime: 0
  });

  // Keep latest parameters in a mutable ref for synchronous access in high-fps requestAnimationFrame loop
  const paramsRef = useRef({
    mass,
    spin,
    jetIntensity,
    beamingEnabled,
    lensingEnabled,
    hawkingEnabled,
    nebulaEnabled,
    interactiveEnabled,
    colorTheme,
    isLowPerf
  });

  // Synchronize refs on state updates
  useEffect(() => {
    paramsRef.current = {
      mass,
      spin,
      jetIntensity,
      beamingEnabled,
      lensingEnabled,
      hawkingEnabled,
      nebulaEnabled,
      interactiveEnabled,
      colorTheme,
      isLowPerf
    };
  }, [mass, spin, jetIntensity, beamingEnabled, lensingEnabled, hawkingEnabled, nebulaEnabled, interactiveEnabled, colorTheme, isLowPerf]);

  // Keep track of active probes in a ref to avoid recreating the rendering loop
  const probesRef = useRef<Probe[]>([]);

  // Function to launch a probe from React context (like slider or clicking)
  const launchProbe = (xCoord?: number, yCoord?: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const cx = canvas.width / 2;
    const cy = canvas.height / 2;
    
    // Set default coordinates if not clicked directly (orbiting at comfortable distance)
    let px = xCoord !== undefined ? xCoord : cx + 220 + Math.random() * 80;
    let py = yCoord !== undefined ? yCoord : cy - 50 + Math.random() * 100;
    
    const dx = px - cx;
    const dy = py - cy;
    const dist = Math.sqrt(dx * dx + dy * dy);
    
    const currentHorizon = paramsRef.current.mass * 0.3;
    if (dist < currentHorizon + 10) {
      // Too close to Horizon, spawn slightly further
      px = cx + (currentHorizon + 40) * (dx / dist);
      py = cy + (currentHorizon + 40) * (dy / dist);
    }
    
    const finalDx = px - cx;
    const finalDy = py - cy;
    const finalDist = Math.sqrt(finalDx * finalDx + finalDy * finalDy);
    
    // Perpendicular unit vector for tangent velocity (Orbit Launcher)
    const ux = -finalDy / finalDist;
    const uy = finalDx / finalDist;
    
    // Circular orbital speed: v = sqrt(GM / r)
    const vOrbit = Math.sqrt((GRAVITY * paramsRef.current.mass) / finalDist) * 1.05;
    
    const newProbe: Probe = {
      id: `PRB-${Math.floor(Math.random() * 900 + 100)}`,
      x: px,
      y: py,
      vx: ux * vOrbit,
      vy: uy * vOrbit,
      dist: finalDist,
      initialDist: finalDist,
      trail: [],
      status: 'orbiting',
      timeDilation: 1,
      localTime: 0,
      speed: vOrbit,
      color: colorTheme === 'amber' ? '#10b981' : colorTheme === 'cyan' ? '#eab308' : colorTheme === 'purple' ? '#22c55e' : '#06b6d4'
    };
    
    probesRef.current.push(newProbe);
  };

  const feedSingularity = () => {
    // Triggers a mass influx of 80 hot particle flares
    const canvas = canvasRef.current;
    if (!canvas) return;
    // Set a flag or let particles spawn directly at a high rate
    window.dispatchEvent(new CustomEvent('singularity-flare', { detail: { count: 80 } }));
    setMass(prev => Math.min(600, prev + 12));
  };

  const clearProbes = () => {
    probesRef.current = [];
    setProbeTelemetry([]);
  };

  // Main canvas rendering & simulation loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return;

    let animationFrameId: number;
    let w = canvas.width = window.innerWidth;
    let h = canvas.height = window.innerHeight;
    let cx = w / 2;
    let cy = h / 2;

    // Simulation components arrays
    const accretionParticles: AccretionParticle[] = [];
    const jetParticles: JetParticle[] = [];
    const backgroundStars: BackgroundStar[] = [];
    const hawkingParticles: HawkingParticle[] = [];
    const nebulaClouds: CosmicNebula[] = [];

    // Sparkle shockwave trigger
    let shockwaveRadius = 0;
    let shockwaveIntensity = 0;

    // Set up Nebula background clouds
    const initializeNebulae = () => {
      nebulaClouds.length = 0;
      const cloudColors = {
        amber: ['rgba(30, 10, 0, 0.04)', 'rgba(15, 5, 0, 0.02)'],
        cyan: ['rgba(0, 20, 25, 0.04)', 'rgba(0, 10, 15, 0.02)'],
        purple: ['rgba(20, 0, 30, 0.04)', 'rgba(10, 0, 15, 0.02)'],
        crimson: ['rgba(30, 0, 5, 0.04)', 'rgba(15, 0, 2, 0.02)'],
      };
      
      const themeColors = cloudColors[paramsRef.current.colorTheme] || cloudColors.amber;
      
      for (let i = 0; i < 3; i++) {
        nebulaClouds.push({
          x: Math.random() * w,
          y: Math.random() * h,
          vx: (Math.random() - 0.5) * 0.15,
          vy: (Math.random() - 0.5) * 0.15,
          radius: Math.random() * (Math.max(w, h) * 0.4) + Math.max(w, h) * 0.3,
          color: themeColors[i % themeColors.length]
        });
      }
    };

    // Set up Background Starfield
    const initializeStars = () => {
      backgroundStars.length = 0;
      const count = paramsRef.current.isLowPerf ? 150 : 400;
      for (let i = 0; i < count; i++) {
        const angle = Math.random() * Math.PI * 2;
        // Distribute stars outward, keeping some sparse density in center
        const r = Math.pow(Math.random(), 1.5) * Math.max(w, h) * 1.2;
        const x = cx + Math.cos(angle) * r;
        const y = cy + Math.sin(angle) * r;
        
        // Star colors with varying cosmic temperatures (warm amber, cool cyan, crisp white)
        const randColor = Math.random();
        let starColor = 'rgba(255, 255, 255, ';
        if (randColor < 0.2) starColor = 'rgba(191, 219, 254, '; // Soft blue-shifted
        else if (randColor < 0.35) starColor = 'rgba(254, 215, 170, '; // Warm red-shifted

        backgroundStars.push({
          originalX: x,
          originalY: y,
          brightness: Math.random() * 0.5 + 0.3,
          size: Math.random() * 1.3 + 0.3,
          color: starColor
        });
      }
    };

    // Initialize Accretion Disk particles
    const initializeAccretionDisk = () => {
      accretionParticles.length = 0;
      const count = paramsRef.current.isLowPerf ? 120 : 450;
      for (let i = 0; i < count; i++) {
        spawnAccretionParticle(true);
      }
    };

    const spawnAccretionParticle = (randomizeR = false) => {
      const currentHorizon = paramsRef.current.mass * 0.3;
      const maxR = Math.max(w, h) * 0.65;
      
      let r = 0;
      let type: 'inner' | 'mid' | 'outer' = 'mid';
      const randType = Math.random();
      
      if (randType < 0.22) {
        // Hot relativistic photon ring boundary
        type = 'inner';
        r = randomizeR ? Math.random() * (currentHorizon * 0.3) + currentHorizon * 1.05 : currentHorizon * 1.05;
      } else if (randType < 0.75) {
        // High density mid accretion disk
        type = 'mid';
        r = randomizeR ? Math.random() * (currentHorizon * 1.8) + currentHorizon * 1.35 : currentHorizon * 1.35;
      } else {
        // Sparse outer cloud
        type = 'outer';
        r = randomizeR ? Math.random() * (maxR - currentHorizon * 3.1) + currentHorizon * 3.1 : maxR;
      }

      const phi = Math.random() * Math.PI * 2;
      
      // Keplerian differential speed: v is proportional to 1 / sqrt(r)
      // Faster rotation at the center, slower at boundaries
      const baseSpeed = (Math.random() * 0.003 + 0.002) * (200 / r);
      
      // Map base color schemes
      let baseHue = 24; // Amber default
      if (paramsRef.current.colorTheme === 'cyan') baseHue = 185;
      else if (paramsRef.current.colorTheme === 'purple') baseHue = 275;
      else if (paramsRef.current.colorTheme === 'crimson') baseHue = 350;

      accretionParticles.push({
        r,
        phi,
        speed: baseSpeed,
        size: Math.random() * 1.8 + 0.4,
        color: '',
        type,
        temp: Math.max(0, 1 - (r - currentHorizon) / (maxR - currentHorizon)),
        baseHue,
        x: 0,
        y: 0
      });
    };

    const spawnJetParticle = () => {
      if (paramsRef.current.jetIntensity <= 0.05) return;
      const currentHorizon = paramsRef.current.mass * 0.3;
      
      // Spawn at event horizon, moving outwards along polar axis
      // Tilted slightly by -25 degrees for a gorgeous 3D perspective
      const direction: 1 | -1 = Math.random() < 0.5 ? 1 : -1;
      
      jetParticles.push({
        dist: Math.random() * currentHorizon * 0.4,
        offset: Math.random() * 2,
        spiralAngle: Math.random() * Math.PI * 2,
        speed: (Math.random() * 2.8 + 1.2) * (1 + paramsRef.current.jetIntensity * 0.4),
        spiralSpeed: Math.random() * 0.06 + 0.04,
        size: Math.random() * 2.2 + 0.6,
        color: '',
        direction,
        alpha: Math.random() * 0.6 + 0.4
      });
    };

    const spawnHawkingPair = () => {
      const currentHorizon = paramsRef.current.mass * 0.3;
      const phi = Math.random() * Math.PI * 2;
      
      // Virtual coordinates at event horizon boundary
      const hx = cx + Math.cos(phi) * currentHorizon;
      const hy = cy + Math.sin(phi) * currentHorizon;
      
      // Polar vectors
      const rx = Math.cos(phi);
      const ry = Math.sin(phi);
      
      // Negative energy particle (spirals inward into the singularity)
      hawkingParticles.push({
        x: hx,
        y: hy,
        vx: -rx * (Math.random() * 0.4 + 0.2),
        vy: -ry * (Math.random() * 0.4 + 0.2),
        size: Math.random() * 1.5 + 0.5,
        color: paramsRef.current.colorTheme === 'amber' ? 'rgba(56, 189, 248, ' : 'rgba(239, 68, 68, ', // Contrasting quantum colors
        alpha: 0.8,
        life: 0,
        maxLife: Math.random() * 40 + 30,
        type: 'negative'
      });

      // Positive energy particle (escapes radially outward, radiating Hawking radiation)
      hawkingParticles.push({
        x: hx + rx * 2,
        y: hy + ry * 2,
        vx: rx * (Math.random() * 1.8 + 0.8),
        vy: ry * (Math.random() * 1.8 + 0.8),
        size: Math.random() * 2.0 + 0.6,
        color: paramsRef.current.colorTheme === 'amber' ? 'rgba(251, 146, 60, ' : 'rgba(52, 211, 153, ',
        alpha: 0.9,
        life: 0,
        maxLife: Math.random() * 90 + 60,
        type: 'positive'
      });
    };

    // Listen to custom custom flare event
    const handleCustomFlare = (e: Event) => {
      const customEvent = e as CustomEvent;
      const count = customEvent.detail?.count || 40;
      
      // Start supernova wave
      shockwaveRadius = paramsRef.current.mass * 0.3;
      shockwaveIntensity = 1.0;

      // Spawn concentrated inward-spiraling flare particles
      const currentHorizon = paramsRef.current.mass * 0.3;
      for (let i = 0; i < count; i++) {
        const phi = Math.random() * Math.PI * 2;
        const r = currentHorizon * 3 + Math.random() * currentHorizon * 2;
        const baseSpeed = (Math.random() * 0.008 + 0.004) * (200 / r);
        let baseHue = 35; // Bright hyper golden flare
        if (paramsRef.current.colorTheme === 'cyan') baseHue = 160;
        else if (paramsRef.current.colorTheme === 'purple') baseHue = 300;
        else if (paramsRef.current.colorTheme === 'crimson') baseHue = 10;

        accretionParticles.push({
          r,
          phi,
          speed: baseSpeed * 1.8,
          size: Math.random() * 3.2 + 1.2,
          color: '',
          type: 'mid',
          temp: 0.9,
          baseHue,
          x: 0,
          y: 0
        });
      }
    };

    window.addEventListener('singularity-flare', handleCustomFlare);

    const resize = () => {
      w = canvas.width = window.innerWidth;
      h = canvas.height = window.innerHeight;
      cx = w / 2;
      cy = h / 2;
      initializeStars();
      initializeAccretionDisk();
      initializeNebulae();
    };

    window.addEventListener('resize', resize);
    resize();

    let mouseX = -1000;
    let mouseY = -1000;
    let currentMouseX = -1000;
    let currentMouseY = -1000;
    let mouseActive = false;

    const handleMouseMove = (e: MouseEvent) => {
      mouseX = e.clientX;
      mouseY = e.clientY;
      mouseActive = true;
    };

    const handleMouseLeave = () => {
      mouseActive = false;
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseleave', handleMouseLeave);

    let lastScrollTime = 0;
    const handleScroll = () => {
      lastScrollTime = Date.now();
    };
    window.addEventListener('scroll', handleScroll, { capture: true, passive: true });

    let frameCount = 0;

    // Core Animation loop running inside RAF
    const animate = () => {
      if (Date.now() - lastScrollTime < 150) {
        animationFrameId = requestAnimationFrame(animate);
        return;
      }
      frameCount++;
      const currentHorizon = paramsRef.current.mass * 0.3;

      // Smoothly interpolate mouse coordinates for beautiful inertia
      if (mouseActive) {
        if (currentMouseX === -1000) {
          currentMouseX = mouseX;
          currentMouseY = mouseY;
        } else {
          currentMouseX += (mouseX - currentMouseX) * 0.08;
          currentMouseY += (mouseY - currentMouseY) * 0.08;
        }
      } else {
        if (currentMouseX !== -1000) {
          currentMouseX += (-1000 - currentMouseX) * 0.08;
          currentMouseY += (-1000 - currentMouseY) * 0.08;
          if (Math.abs(currentMouseX + 1000) < 1) {
            currentMouseX = -1000;
            currentMouseY = -1000;
          }
        }
      }

      // 1. Dark Void Space Backdrop
      ctx.globalCompositeOperation = 'source-over';
      ctx.fillStyle = 'rgba(4, 4, 6, 0.20)'; // Smooth trails, high contrast with zero trailing artifacts
      ctx.fillRect(0, 0, w, h);

      // 2. Render Cosmic Nebula Gas Clouds
      if (paramsRef.current.nebulaEnabled && !paramsRef.current.isLowPerf) {
        ctx.globalCompositeOperation = 'screen';
        nebulaClouds.forEach(n => {
          n.x += n.vx;
          n.y += n.vy;
          
          // Mirror bounce at boundaries
          if (n.x < -200 || n.x > w + 200) n.vx *= -1;
          if (n.y < -200 || n.y > h + 200) n.vy *= -1;

          const grad = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, n.radius);
          grad.addColorStop(0, n.color);
          grad.addColorStop(0.5, n.color.replace('0.04', '0.01'));
          grad.addColorStop(1, 'transparent');

          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.arc(n.x, n.y, n.radius, 0, Math.PI * 2);
          ctx.fill();
        });
      }

      // 3. Draw Background Stars with Gravitational Lensing Distortion
      ctx.globalCompositeOperation = 'source-over';
      backgroundStars.forEach(s => {
        let sX = s.originalX;
        let sY = s.originalY;

        // Apply mouse lensing refraction locally
        if (currentMouseX !== -1000) {
          const mdx = sX - currentMouseX;
          const mdy = sY - currentMouseY;
          const md = Math.sqrt(mdx * mdx + mdy * mdy);
          const influenceRadius = 180;
          if (md < influenceRadius && md > 2) {
            // Calculate warp force (bell curve profile)
            const ratio = 1.0 - md / influenceRadius;
            const force = ratio * ratio * 28; // gentle magnification refraction
            sX -= (mdx / md) * force;
            sY -= (mdy / md) * force;
          }
        }

        const dx = sX - cx;
        const dy = sY - cy;
        const d = Math.sqrt(dx * dx + dy * dy);

        // Einstein Radius approximation: if inside event horizon, it's blacked out
        if (d < currentHorizon) return;

        let drawX = sX;
        let drawY = sY;
        let drawSize = s.size;
        let opacity = s.brightness;

        if (paramsRef.current.lensingEnabled) {
          // Gravitational lensing equation: apparent position shifted outward
          // Shifting light path: d_new = d_old + K * R_s^2 / d_old
          const lensingK = 1.35;
          const warpFactor = 1.0 + (lensingK * currentHorizon * currentHorizon) / (d * d);
          
          drawX = cx + dx * warpFactor;
          drawY = cy + dy * warpFactor;

          // Compute shear amplification (light stretching tangentially)
          // Stars passing extremely close to the photon sphere get stretched into beautiful Einstein Arcs
          const closeLimit = currentHorizon * 1.5;
          if (d < closeLimit) {
            const stretch = (closeLimit / d) * 1.5;
            drawSize = s.size * stretch;
            opacity = s.brightness * (d / closeLimit) * 1.4; // Magnification
            
            // Draw sheared star light streak along tangential orbital plane
            const tx = -dy / d;
            const ty = dx / d;
            
            ctx.strokeStyle = `${s.color}${opacity})`;
            ctx.lineWidth = drawSize * 0.4;
            ctx.beginPath();
            ctx.moveTo(drawX - tx * drawSize, drawY - ty * drawSize);
            ctx.lineTo(drawX + tx * drawSize, drawY + ty * drawSize);
            ctx.stroke();
            return;
          }
        }

        ctx.fillStyle = `${s.color}${opacity})`;
        ctx.beginPath();
        ctx.arc(drawX, drawY, drawSize, 0, Math.PI * 2);
        ctx.fill();
      });

      // 4. Update and Render Quantum Hawking Radiation
      if (paramsRef.current.hawkingEnabled && !paramsRef.current.isLowPerf) {
        ctx.globalCompositeOperation = 'screen';
        
        // Periodic pair creation
        if (frameCount % (paramsRef.current.isLowPerf ? 35 : 12) === 0) {
          spawnHawkingPair();
        }

        for (let i = hawkingParticles.length - 1; i >= 0; i--) {
          const hp = hawkingParticles[i];
          hp.life++;
          
          if (hp.life >= hp.maxLife) {
            hawkingParticles.splice(i, 1);
            continue;
          }

          // Update position
          hp.x += hp.vx;
          hp.y += hp.vy;

          if (hp.type === 'negative') {
            // Accelerate and spiral into singularity
            const dx = cx - hp.x;
            const dy = cy - hp.y;
            const r = Math.sqrt(dx * dx + dy * dy);
            
            if (r < currentHorizon * 0.2) {
              hawkingParticles.splice(i, 1);
              continue;
            }

            // Standard pull plus orbital curl
            const pull = 0.08 * (paramsRef.current.mass / r);
            hp.vx += (dx / r) * pull - (dy / r) * 0.02;
            hp.vy += (dy / r) * pull + (dx / r) * 0.02;
            hp.alpha = Math.max(0, 1 - hp.life / hp.maxLife);
          } else {
            // Escaping radiation: slow drag and fade
            hp.vx *= 0.985;
            hp.vy *= 0.985;
            hp.alpha = Math.max(0, 1 - hp.life / hp.maxLife);
          }

          ctx.fillStyle = `${hp.color}${hp.alpha})`;
          ctx.beginPath();
          ctx.arc(hp.x, hp.y, hp.size, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // 5. Update and Render Accretion Disk Particles with Additive Blending
      ctx.globalCompositeOperation = 'screen';
      
      // Slowly expand shockwave radius if active
      if (shockwaveRadius > 0) {
        shockwaveRadius += 6.5;
        shockwaveIntensity *= 0.982;
        if (shockwaveRadius > Math.max(w, h) * 0.95) {
          shockwaveRadius = 0;
          shockwaveIntensity = 0;
        }
      }

      accretionParticles.forEach((p, index) => {
        // Differential orbital rotation
        p.phi += p.speed * (1 + paramsRef.current.spin * 0.45);
        
        // Dynamic inward spiral (space-time dragging effect)
        // Rate is higher for closer particles due to intense drag
        const inwardPull = p.speed * 4.2 * (currentHorizon / p.r) * (1 - paramsRef.current.spin * 0.3);
        p.r -= inwardPull;

        // Interactive mouse kinetic transfer:
        // When particles drift past the mouse cursor, they heat up (glow) and experience a gentle gravitational tug
        if (currentMouseX !== -1000) {
          const pdx = p.x - currentMouseX;
          const pdy = p.y - currentMouseY;
          const pDist = Math.sqrt(pdx * pdx + pdy * pdy);
          if (pDist < 120) {
            const dragForce = (1.0 - pDist / 120);
            p.temp = Math.min(1.0, p.temp + dragForce * 0.08); // particle heats up (glows brighter)
            p.phi += p.speed * dragForce * 1.2; // accelerates the orbital spin locally
          }
        }

        // Supernova shockwave kinetic push
        if (shockwaveRadius > 0) {
          const distToWave = Math.abs(p.r - shockwaveRadius);
          if (distToWave < 35) {
            // Push particle outward slightly and heat it up
            p.r += (35 - distToWave) * 0.55 * shockwaveIntensity;
            p.temp = Math.min(1.0, p.temp + 0.3);
          }
        }

        // Singularity boundary check: recycle devoured particles to outer bounds
        if (p.r < currentHorizon + 4) {
          accretionParticles.splice(index, 1);
          spawnAccretionParticle(false);
          // Spawn outer radius offset
          accretionParticles[accretionParticles.length - 1].r = Math.max(w, h) * 0.45 + Math.random() * 80;
          return;
        }

        // Calculate 2D position
        p.x = cx + Math.cos(p.phi) * p.r;
        
        // Disk Inclination: tilt the accretion disk on y-axis by 25 degrees (cos of angle is height)
        // to create a cinematic 3D perspective
        const diskTiltAngle = -Math.PI / 8; // -22.5 degrees tilt
        p.y = cy + Math.sin(p.phi) * p.r * Math.cos(diskTiltAngle);

        // Relativistic Doppler Beaming / Aberration (matches EHT black hole images)
        // The side rotating towards the observer is significantly brighter and hotter (blue-shifted)
        // Let's assume counter-clockwise rotation, left side is approaching us (dx is negative)
        let beamingMultiplier = 1.0;
        let finalHue = p.baseHue;
        let finalSize = p.size;

        if (paramsRef.current.beamingEnabled) {
          const dx = (p.x - cx) / p.r; // -1 to +1
          // Approaches us on the left, recedes on the right
          const DopplerShift = -dx * paramsRef.current.spin * 0.55; 
          beamingMultiplier = Math.max(0.12, 1.0 + DopplerShift);
          
          // Color blue-shifting (approaching particles are white/blue, receding ones are dark red)
          if (dx < -0.2) {
            finalHue = Math.max(p.baseHue - 15, p.baseHue - Math.abs(dx) * paramsRef.current.spin * 25);
            finalSize = p.size * (1 + Math.abs(dx) * 0.3);
          } else if (dx > 0.2) {
            finalHue = p.baseHue + Math.abs(dx) * paramsRef.current.spin * 15;
            finalSize = p.size * Math.max(0.65, 1 - dx * 0.25);
          }
        }

        const alpha = Math.max(0.04, (p.temp * 0.3 + 0.08) * beamingMultiplier * (1 + shockwaveIntensity * 0.8));
        p.color = `hsla(${finalHue}, 92%, ${Math.min(95, 48 + p.temp * 30 + (shockwaveIntensity * 20))}%, ${alpha})`;

        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, finalSize, 0, Math.PI * 2);
        ctx.fill();
      });

      // 6. Astrophysical Polar Relativistic Jets (Collimated Plasma Helix)
      if (paramsRef.current.jetIntensity > 0.02 && !paramsRef.current.isLowPerf) {
        ctx.globalCompositeOperation = 'screen';
        
        // Control spawning density
        const jetSpawnChance = 0.5 * paramsRef.current.jetIntensity;
        if (Math.random() < jetSpawnChance) {
          spawnJetParticle();
        }

        const jetAngle = -Math.PI / 10 - Math.PI / 2; // Tilted axial angle perpendicular to accretion disk

        for (let i = jetParticles.length - 1; i >= 0; i--) {
          const jp = jetParticles[i];
          jp.dist += jp.speed;
          jp.spiralAngle += jp.spiralSpeed;
          
          // Collimation cone expands outward
          jp.offset = Math.sin(jp.spiralAngle) * (jp.dist * 0.065 + 3);

          if (jp.dist > Math.max(w, h) * 0.7) {
            jetParticles.splice(i, 1);
            continue;
          }

          // Compute 2D coordinate projecting along jet axis
          const jetDirectionX = Math.cos(jetAngle);
          const jetDirectionY = Math.sin(jetAngle);
          
          // Orthogonal radial spiral vector
          const spiralX = -jetDirectionY;
          const spiralY = jetDirectionX;

          const px = cx + (jetDirectionX * jp.dist * jp.direction) + (spiralX * jp.offset);
          const py = cy + (jetDirectionY * jp.dist * jp.direction) + (spiralY * jp.offset);

          // Hue mapping based on theme
          let hue = 180; // Blue/Cyan
          if (paramsRef.current.colorTheme === 'cyan') hue = 320; // Magenta
          else if (paramsRef.current.colorTheme === 'purple') hue = 50; // Neon Yellow/Gold
          else if (paramsRef.current.colorTheme === 'crimson') hue = 110; // Electric Green

          const alpha = jp.alpha * Math.max(0, 1 - (jp.dist / (Math.max(w, h) * 0.65))) * paramsRef.current.jetIntensity;
          ctx.fillStyle = `hsla(${hue}, 95%, 60%, ${alpha})`;
          ctx.beginPath();
          ctx.arc(px, py, jp.size * (1 + (jp.dist * 0.0015)), 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // 7. Interactive Physics Probes Telemetry & Mechanics
      ctx.globalCompositeOperation = 'screen';
      const probes = probesRef.current;

      for (let i = probes.length - 1; i >= 0; i--) {
        const p = probes[i];
        
        if (p.status === 'devoured') {
          // Render terminal explosion flare
          for (let f = 0; f < 6; f++) {
            ctx.fillStyle = `rgba(239, 68, 68, ${Math.random() * 0.7})`;
            ctx.beginPath();
            ctx.arc(p.x + (Math.random() - 0.5) * 15, p.y + (Math.random() - 0.5) * 15, Math.random() * 3 + 1, 0, Math.PI * 2);
            ctx.fill();
          }
          continue;
        }

        // Add coordinate to trail
        p.trail.push({ x: p.x, y: p.y });
        if (p.trail.length > 35) p.trail.shift();

        // Gravitational force formula: F = GM / r^2
        const pdx = cx - p.x;
        const pdy = cy - p.y;
        p.dist = Math.sqrt(pdx * pdx + pdy * pdy);

        // Check if crossed Event Horizon
        if (p.dist < currentHorizon + 4) {
          p.status = 'devoured';
          p.speed = 0;
          p.timeDilation = Infinity;
          
          // Flare blast shockwave
          shockwaveRadius = currentHorizon;
          shockwaveIntensity = 0.5;

          // Remove devoured probe after a delay
          setTimeout(() => {
            const idx = probesRef.current.findIndex(prb => prb.id === p.id);
            if (idx !== -1) probesRef.current.splice(idx, 1);
          }, 1500);
          continue;
        }

        const force = (GRAVITY * paramsRef.current.mass) / (p.dist * p.dist * p.dist);
        p.vx += pdx * force;
        p.vy += pdy * force;

        // Space-time dragging / friction (Accretion disk frame drag)
        // Causes subtle orbital decay
        p.vx *= 0.9985;
        p.vy *= 0.9985;

        // Update positions
        p.x += p.vx;
        p.y += p.vy;
        p.speed = Math.sqrt(p.vx * p.vx + p.vy * p.vy);

        // Schwarzschild Time Dilation: t_dilated = 1 / sqrt(1 - R_s/r)
        // As r -> R_s, time dilation goes to Infinity!
        const dilation = p.dist > currentHorizon ? 1.0 / Math.sqrt(1.0 - currentHorizon / p.dist) : Infinity;
        p.timeDilation = dilation;
        p.localTime += 1.0 / dilation; // Slower local clock

        // Draw orbital trail
        if (p.trail.length > 1) {
          ctx.beginPath();
          ctx.moveTo(p.trail[0].x, p.trail[0].y);
          for (let t = 1; t < p.trail.length; t++) {
            ctx.lineTo(p.trail[t].x, p.trail[t].y);
          }
          ctx.strokeStyle = p.color;
          ctx.lineWidth = 1.2;
          ctx.stroke();
        }

        // Draw Probe and target vector marker
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
        ctx.fill();

        // Pulsing radar marker HUD around probe
        const radarPulse = (frameCount * 0.08) % 1;
        ctx.strokeStyle = `rgba(16, 185, 129, ${1 - radarPulse})`;
        ctx.lineWidth = 0.8;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 10 + radarPulse * 15, 0, Math.PI * 2);
        ctx.stroke();

        // Draw HUD labeling on canvas for probes
        if (!paramsRef.current.isLowPerf) {
          ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
          ctx.font = '9px monospace';
          ctx.fillText(p.id, p.x + 8, p.y - 4);
          ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
          ctx.fillText(`r: ${(p.dist / currentHorizon).toFixed(1)} Rs`, p.x + 8, p.y + 6);
        }
      }

      // Throttled probe telemetry update back to React state to prevent heavy re-renders
      if (frameCount % 10 === 0) {
        setProbeTelemetry(
          probesRef.current.map(p => ({
            id: p.id,
            dist: p.dist / currentHorizon, // Normalized in Rs
            initialDist: p.initialDist,
            status: p.status,
            timeDilation: p.timeDilation,
            localTime: p.localTime,
            speed: p.speed,
            color: p.color
          }))
        );

        // Compute scientific physics numbers for the HUD diagnostics
        // Constants in SI units mapped to simulation scale
        const horizonRadiusKm = paramsRef.current.mass * 2.95; // Rs = 2GM/c^2 ~ 2.95km per solar mass
        const hawkingTemp = (1.227e23 / (paramsRef.current.mass * 1e5)).toExponential(3); // T \propto 1/M
        const entropy = (1.04e72 * Math.pow(paramsRef.current.mass, 2)).toExponential(3); // S \propto M^2
        const spaceCurvature = (GRAVITY * paramsRef.current.mass / Math.pow(currentHorizon, 3)).toFixed(5);

        setHudStats({
          horizonRadiusKm,
          hawkingTemp,
          entropy,
          spaceCurvature,
          elapsedTime: Math.floor(frameCount / 60)
        });
      }

      // 8. Draw Event Horizon (The Absolute Singularity Void Core)
      ctx.globalCompositeOperation = 'source-over';
      
      // Outer photon sphere bloom ring
      const photonGlow = ctx.createRadialGradient(cx, cy, currentHorizon * 0.95, cx, cy, currentHorizon * 1.35);
      let ringColor = 'rgba(249, 115, 22, '; // Orange
      if (paramsRef.current.colorTheme === 'cyan') ringColor = 'rgba(6, 182, 212, ';
      else if (paramsRef.current.colorTheme === 'purple') ringColor = 'rgba(168, 85, 247, ';
      else if (paramsRef.current.colorTheme === 'crimson') ringColor = 'rgba(239, 68, 68, ';

      photonGlow.addColorStop(0, '#000000');
      photonGlow.addColorStop(0.12, 'rgba(0,0,0, 0.9)');
      photonGlow.addColorStop(0.2, `${ringColor}0.30)`);
      photonGlow.addColorStop(0.35, `${ringColor}0.15)`);
      photonGlow.addColorStop(0.7, `${ringColor}0.04)`);
      photonGlow.addColorStop(1.0, 'transparent');

      ctx.fillStyle = photonGlow;
      ctx.beginPath();
      ctx.arc(cx, cy, currentHorizon * 1.35, 0, Math.PI * 2);
      ctx.fill();

      // Sharp Schwarzschild sphere core boundary (Null photon orbit)
      ctx.fillStyle = '#000000';
      ctx.beginPath();
      ctx.arc(cx, cy, currentHorizon, 0, Math.PI * 2);
      ctx.fill();

      // Delicate inner boundary shine
      const innerEdge = ctx.createRadialGradient(cx, cy, currentHorizon * 0.82, cx, cy, currentHorizon * 0.99);
      innerEdge.addColorStop(0, 'transparent');
      innerEdge.addColorStop(0.85, `${ringColor}0.04)`);
      innerEdge.addColorStop(1.0, `${ringColor}0.20)`);
      
      ctx.fillStyle = innerEdge;
      ctx.beginPath();
      ctx.arc(cx, cy, currentHorizon, 0, Math.PI * 2);
      ctx.fill();

      animationFrameId = requestAnimationFrame(animate);
    };

    // Initialize simulation loop
    animate();

    return () => {
      window.removeEventListener('resize', resize);
      window.removeEventListener('singularity-flare', handleCustomFlare);
      window.removeEventListener('scroll', handleScroll, { capture: true });
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseleave', handleMouseLeave);
      cancelAnimationFrame(animationFrameId);
    };
  }, [colorTheme]); // Reload setup only when core theme changes to prevent flickering

  // Canvas click handler to spawn probes when in interactive mode
  const handleCanvasClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!interactiveEnabled) return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    launchProbe(x, y);
  };

  return (
    <div
      className={`fixed inset-0 overflow-hidden ${
        interactiveEnabled ? 'pointer-events-auto z-[1]' : 'pointer-events-none z-[-1]'
      } bg-[#030305]`}
      onClick={handleCanvasClick}
    >
      {/* Underlying raw canvas */}
      <canvas
        ref={canvasRef}
        className={`w-full h-full block transition-all duration-300 ${
          interactiveEnabled ? 'cursor-crosshair filter brightness-110' : 'cursor-default'
        }`}
      />
      
      {/* Deep space radial cinematic vignette */}
      <div className="absolute inset-0 bg-radial-at-center from-transparent via-transparent to-[#020203]/92 opacity-85 pointer-events-none" />

      {/* DRAGGABLE / HOVER INTERACTIVE HOLOGRAPHIC DIAGNOSTIC CORE - Pointer-Events ALWAYS auto so it works */}
      <div 
        className="absolute bottom-6 right-6 z-50 pointer-events-auto max-w-sm md:max-w-md"
        onClick={(e) => e.stopPropagation()} // Stop propagation from launching a probe on click
      >
        <AnimatePresence mode="wait">
          {isCollapsed ? (
            // COMPACT GLOWING RADAR TRIGGER
            <motion.button
              key="collapsed-hud"
              initial={{ scale: 0.85, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.85, opacity: 0 }}
              onClick={() => setIsCollapsed(false)}
              className="group flex items-center gap-3 px-4 py-3 bg-zinc-950/85 backdrop-blur-xl border border-zinc-800/60 rounded-full shadow-2xl shadow-black/80 hover:border-amber-500/50 transition-all duration-300 active:scale-95"
            >
              <div className="relative flex items-center justify-center w-6 h-6 rounded-full bg-amber-500/10">
                <Orbit className="w-4 h-4 text-amber-400 group-hover:rotate-180 transition-transform duration-700" />
                <span className="absolute inset-0 rounded-full border border-amber-500/30 animate-ping opacity-60" />
              </div>
              <span className="font-mono text-xs font-semibold tracking-wider text-zinc-300 group-hover:text-amber-300 transition-colors">
                SINGULARITY DIAGNOSTICS
              </span>
            </motion.button>
          ) : (
            // COLLAPSIBLE SCI-FI OBSERVATORY CORE HUD
            <motion.div
              key="expanded-hud"
              initial={{ y: 20, opacity: 0, scale: 0.95 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              exit={{ y: 20, opacity: 0, scale: 0.95 }}
              className="bg-zinc-950/92 backdrop-blur-2xl border border-zinc-800/80 rounded-2xl shadow-3xl shadow-black/90 p-5 overflow-hidden w-[360px] md:w-[460px]"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-zinc-800/65 pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-amber-500 animate-pulse" />
                  <h3 className="font-mono text-xs font-bold tracking-widest text-zinc-100">
                    AETHER VOID OBSERVATORY
                  </h3>
                </div>
                <button
                  onClick={() => setIsCollapsed(true)}
                  className="p-1 hover:bg-zinc-800/50 rounded-lg text-zinc-400 hover:text-zinc-100 transition-colors"
                >
                  <ChevronDown className="w-4 h-4" />
                </button>
              </div>

              {/* Grid content */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* COLUMN 1: QUANTUM METRICS & PROBES */}
                <div className="space-y-4">
                  {/* Singularity stats */}
                  <div className="space-y-1.5">
                    <span className="font-mono text-[9px] text-zinc-500 tracking-wider block uppercase font-semibold">
                      // Astrophysics Matrix
                    </span>
                    <div className="bg-zinc-900/40 border border-zinc-800/35 rounded-lg p-2.5 space-y-1 font-mono text-[11px] text-zinc-400">
                      <div className="flex justify-between">
                        <span>Mass (M_☉):</span>
                        <span className="text-zinc-100 font-bold">{mass.toLocaleString()}M</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Schw. Radius:</span>
                        <span className="text-amber-400 font-semibold">{hudStats.horizonRadiusKm.toLocaleString()} km</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Hawking Temp:</span>
                        <span className="text-cyan-400 font-semibold">{hudStats.hawkingTemp} K</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Entropy (BH):</span>
                        <span className="text-purple-400">{hudStats.entropy} J/K</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Void Age:</span>
                        <span className="text-zinc-300 font-bold">{hudStats.elapsedTime} Epochs</span>
                      </div>
                    </div>
                  </div>

                  {/* Telemetry Probes */}
                  <div className="space-y-1.5 flex-1">
                    <div className="flex justify-between items-center">
                      <span className="font-mono text-[9px] text-zinc-500 tracking-wider block uppercase font-semibold">
                        // Probe Telemetry ({probeTelemetry.length})
                      </span>
                      {probeTelemetry.length > 0 && (
                        <button 
                          onClick={clearProbes}
                          className="text-[9px] font-mono text-rose-400/80 hover:text-rose-400 flex items-center gap-0.5"
                        >
                          <Trash2 className="w-2.5 h-2.5" /> Clear
                        </button>
                      )}
                    </div>

                    <div className="bg-zinc-900/40 border border-zinc-800/35 rounded-lg p-2.5 max-h-[140px] overflow-y-auto space-y-1.5">
                      {probeTelemetry.length === 0 ? (
                        <div className="text-center py-6 text-zinc-600 font-mono text-[10px]">
                          NO ACTIVE TELEMETRY<br />
                          {interactiveEnabled ? (
                            <span className="text-emerald-500/60 font-semibold">CLICK CANVAS TO DEPLOY</span>
                          ) : (
                            <span className="text-zinc-500/55">ENABLE VOID MODE TO LAUNCH</span>
                          )}
                        </div>
                      ) : (
                        probeTelemetry.map(probe => (
                          <div 
                            key={probe.id}
                            className="text-[10px] font-mono border-b border-zinc-800/30 pb-1.5 last:border-0 last:pb-0"
                          >
                            <div className="flex justify-between font-bold" style={{ color: probe.color }}>
                              <span>{probe.id}</span>
                              <span className="uppercase text-[9px]">
                                {probe.status === 'devoured' ? (
                                  <span className="text-rose-500 animate-pulse font-black">CRITICAL COLLAPSE</span>
                                ) : (
                                  'ORBIT ESTABLISHED'
                                )}
                              </span>
                            </div>
                            {probe.status !== 'devoured' && (
                              <div className="grid grid-cols-2 text-[9px] text-zinc-500 mt-0.5">
                                <span>Dist: <b className="text-zinc-300">{probe.dist.toFixed(2)} R_s</b></span>
                                <span>Vel: <b className="text-zinc-300">{(probe.speed * 100).toFixed(1)}K km/s</b></span>
                                <span className="col-span-2">Time Delay: <b className="text-amber-500">{(probe.timeDilation > 200 ? 'INF (Infinite)' : probe.timeDilation.toFixed(2) + 'x slower')}</b></span>
                              </div>
                            )}
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                </div>

                {/* COLUMN 2: CONTROLS & UTILITIES */}
                <div className="space-y-4">
                  {/* Preset & theme selector */}
                  <div className="space-y-1.5">
                    <span className="font-mono text-[9px] text-zinc-500 tracking-wider block uppercase font-semibold">
                      // Color Resonance Scheme
                    </span>
                    <div className="grid grid-cols-4 gap-1.5">
                      {(['amber', 'cyan', 'purple', 'crimson'] as const).map(theme => (
                        <button
                          key={theme}
                          onClick={() => setColorTheme(theme)}
                          className={`py-1 rounded font-mono text-[9px] font-bold uppercase border transition-all ${
                            colorTheme === theme
                              ? theme === 'amber' ? 'bg-amber-500/20 border-amber-500/70 text-amber-300'
                                : theme === 'cyan' ? 'bg-cyan-500/20 border-cyan-500/70 text-cyan-300'
                                : theme === 'purple' ? 'bg-purple-500/20 border-purple-500/70 text-purple-300'
                                : 'bg-rose-500/20 border-rose-500/70 text-rose-300'
                              : 'bg-zinc-900/40 border-zinc-800/40 text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800/20'
                          }`}
                        >
                          {theme}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Physics Sliders */}
                  <div className="space-y-2">
                    <span className="font-mono text-[9px] text-zinc-500 tracking-wider block uppercase font-semibold">
                      // Singularity Modulators
                    </span>
                    
                    {/* Mass slider */}
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between font-mono text-[10px] text-zinc-400">
                        <span>Horizon Mass:</span>
                        <span className="text-zinc-100 font-bold">{mass}k M_☉</span>
                      </div>
                      <input
                        type="range"
                        min="120"
                        max="580"
                        value={mass}
                        onChange={(e) => setMass(parseInt(e.target.value))}
                        className="w-full h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-500 focus:outline-none"
                      />
                    </div>

                    {/* Spin Slider */}
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between font-mono text-[10px] text-zinc-400">
                        <span>Ergosphere Spin (Kerr):</span>
                        <span className="text-zinc-100 font-bold">a = {spin.toFixed(2)}</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="0.99"
                        step="0.05"
                        value={spin}
                        onChange={(e) => setSpin(parseFloat(e.target.value))}
                        className="w-full h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-cyan-500 focus:outline-none"
                      />
                    </div>

                    {/* Jet Intensity Slider */}
                    <div className="space-y-1 text-xs">
                      <div className="flex justify-between font-mono text-[10px] text-zinc-400">
                        <span>Jet Plasma Flux:</span>
                        <span className="text-zinc-100 font-bold">{(jetIntensity * 100).toFixed(0)}%</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="1.0"
                        step="0.1"
                        value={jetIntensity}
                        onChange={(e) => setJetIntensity(parseFloat(e.target.value))}
                        className="w-full h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-purple-500 focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Scientific Toggles */}
                  <div className="grid grid-cols-2 gap-x-3 gap-y-2 font-mono text-[10px] text-zinc-400 border-t border-zinc-800/40 pt-3">
                    <button 
                      onClick={() => setBeamingEnabled(!beamingEnabled)}
                      className="flex items-center gap-1.5 hover:text-zinc-200 text-left transition-colors"
                    >
                      {beamingEnabled ? <Eye className="w-3.5 h-3.5 text-emerald-500" /> : <EyeOff className="w-3.5 h-3.5 text-zinc-600" />}
                      Doppler Beaming
                    </button>
                    <button 
                      onClick={() => setLensingEnabled(!lensingEnabled)}
                      className="flex items-center gap-1.5 hover:text-zinc-200 text-left transition-colors"
                    >
                      {lensingEnabled ? <Eye className="w-3.5 h-3.5 text-emerald-500" /> : <EyeOff className="w-3.5 h-3.5 text-zinc-600" />}
                      Einstein Lens
                    </button>
                    <button 
                      onClick={() => setHawkingEnabled(!hawkingEnabled)}
                      className="flex items-center gap-1.5 hover:text-zinc-200 text-left transition-colors"
                    >
                      {hawkingEnabled ? <Eye className="w-3.5 h-3.5 text-emerald-500" /> : <EyeOff className="w-3.5 h-3.5 text-zinc-600" />}
                      Hawking Radiation
                    </button>
                    <button 
                      onClick={() => setNebulaEnabled(!nebulaEnabled)}
                      className="flex items-center gap-1.5 hover:text-zinc-200 text-left transition-colors"
                    >
                      {nebulaEnabled ? <Eye className="w-3.5 h-3.5 text-emerald-500" /> : <EyeOff className="w-3.5 h-3.5 text-zinc-600" />}
                      Drifting Nebula
                    </button>
                  </div>

                  {/* INTERACTIVE MODE BUTTON */}
                  <button
                    onClick={() => setInteractiveEnabled(!interactiveEnabled)}
                    className={`w-full py-2.5 rounded-xl font-mono text-xs font-bold tracking-wider uppercase border transition-all duration-300 flex items-center justify-center gap-2 ${
                      interactiveEnabled 
                        ? 'bg-rose-500/15 border-rose-500/80 text-rose-300 shadow-lg shadow-rose-950/25 animate-pulse'
                        : 'bg-zinc-900 border-zinc-800 hover:border-zinc-700 text-zinc-300'
                    }`}
                  >
                    <Zap className={`w-3.5 h-3.5 ${interactiveEnabled ? 'text-rose-400 animate-bounce' : 'text-zinc-400'}`} />
                    {interactiveEnabled ? 'DEACTIVATE INTERACTIVE VOID' : 'ACTIVATE INTERACTIVE VOID'}
                  </button>

                  {/* Kinetic Utilities */}
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    <button
                      onClick={feedSingularity}
                      className="py-1.5 px-2 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 hover:border-amber-500/50 rounded-lg font-mono text-[10px] font-bold text-amber-300 transition-all flex items-center justify-center gap-1"
                    >
                      <Sparkles className="w-3 h-3" /> FEED SINGULARITY
                    </button>
                    <button
                      onClick={() => launchProbe()}
                      disabled={!interactiveEnabled}
                      className="py-1.5 px-2 disabled:opacity-50 disabled:cursor-not-allowed bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 hover:border-emerald-500/50 rounded-lg font-mono text-[10px] font-bold text-emerald-300 transition-all flex items-center justify-center gap-1"
                    >
                      <Play className="w-3 h-3" /> LAUNCH PROBE
                    </button>
                  </div>
                </div>
              </div>

              {/* Informative Footer */}
              <div className="mt-4 border-t border-zinc-800/40 pt-3 flex items-center justify-between text-[9px] font-mono text-zinc-600">
                <span className="flex items-center gap-1">
                  <Info className="w-3 h-3" />
                  {interactiveEnabled 
                    ? "Interactive Void Mode Active. Click background canvas to launch probes!"
                    : "Toggle Void Mode above to interact directly with the Singularity."}
                </span>
                <span className="font-bold flex items-center gap-0.5">
                  <Cpu className="w-3 h-3 text-emerald-500" />
                  60 FPS
                </span>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default BlackHoleBackground;
