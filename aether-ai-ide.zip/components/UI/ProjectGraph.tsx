
import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { FileNode } from '../../types';
import { X } from 'lucide-react';

interface ProjectGraphProps {
  files: FileNode[];
  onClose: () => void;
}

const ProjectGraph: React.FC<ProjectGraphProps> = ({ files, onClose }) => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current || files.length === 0) return;

    const width = window.innerWidth;
    const height = window.innerHeight;

    const svg = d3.select(svgRef.current)
      .attr('width', width)
      .attr('height', height);

    svg.selectAll('*').remove();

    const nodes = files.map(f => ({ id: f.id, name: f.name, type: 'file' }));
    nodes.push({ id: 'root', name: 'Project Root', type: 'root' });

    const links = files.map(f => ({ source: 'root', target: f.id }));

    const simulation = d3.forceSimulation(nodes as any)
      .force('link', d3.forceLink(links).id((d: any) => d.id).distance(150))
      .force('charge', d3.forceManyBody().strength(-500))
      .force('center', d3.forceCenter(width / 2, height / 2));

    const link = svg.append('g')
      .selectAll('line')
      .data(links)
      .enter().append('line')
      .attr('stroke', '#00d4ff')
      .attr('stroke-opacity', 0.3)
      .attr('stroke-width', 2);

    const node = svg.append('g')
      .selectAll('g')
      .data(nodes)
      .enter().append('g')
      .call(d3.drag<any, any>()
        .on('start', dragstarted)
        .on('drag', dragged)
        .on('end', dragended));

    node.append('circle')
      .attr('r', (d: any) => d.type === 'root' ? 20 : 10)
      .attr('fill', (d: any) => d.type === 'root' ? '#00d4ff' : '#fff')
      .attr('filter', 'url(#glow)');

    node.append('text')
      .text((d: any) => d.name)
      .attr('x', 15)
      .attr('y', 5)
      .attr('fill', '#fff')
      .style('font-size', '10px')
      .style('font-family', 'monospace')
      .style('pointer-events', 'none');

    // Glow filter
    const defs = svg.append('defs');
    const filter = defs.append('filter').attr('id', 'glow');
    filter.append('feGaussianBlur').attr('stdDeviation', '3.5').attr('result', 'coloredBlur');
    const feMerge = filter.append('feMerge');
    feMerge.append('feMergeNode').attr('in', 'coloredBlur');
    feMerge.append('feMergeNode').attr('in', 'SourceGraphic');

    simulation.on('tick', () => {
      link
        .attr('x1', (d: any) => d.source.x)
        .attr('y1', (d: any) => d.source.y)
        .attr('x2', (d: any) => d.target.x)
        .attr('y2', (d: any) => d.target.y);

      node
        .attr('transform', (d: any) => `translate(${d.x},${d.y})`);
    });

    function dragstarted(event: any) {
      if (!event.active) simulation.alphaTarget(0.3).restart();
      event.subject.fx = event.subject.x;
      event.subject.fy = event.subject.y;
    }

    function dragged(event: any) {
      event.subject.fx = event.x;
      event.subject.fy = event.y;
    }

    function dragended(event: any) {
      if (!event.active) simulation.alphaTarget(0);
      event.subject.fx = null;
      event.subject.fy = null;
    }

    return () => {
      simulation.stop();
    };
  }, [files]);

  return (
    <div className="fixed inset-0 z-[80] bg-black/90 backdrop-blur-xl flex flex-col">
      <div className="p-6 flex justify-between items-center border-b border-white/10">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <span className="w-2 h-2 bg-aether-accent rounded-full animate-pulse" />
            Neural Project Architecture
          </h2>
          <p className="text-[10px] text-aether-muted uppercase tracking-widest mt-1">Visualizing file relationships and dependencies</p>
        </div>
        <button 
          onClick={onClose}
          className="p-2 hover:bg-white/10 rounded-full text-white transition-colors"
        >
          <X size={24} />
        </button>
      </div>
      <div className="flex-1 relative overflow-hidden">
        <svg ref={svgRef} className="w-full h-full" />
        <div className="absolute bottom-6 left-6 p-4 bg-white/5 border border-white/10 rounded-xl backdrop-blur-md max-w-xs">
          <h4 className="text-xs font-bold text-aether-accent uppercase tracking-widest mb-2">Network Insights</h4>
          <p className="text-[10px] text-aether-muted leading-relaxed">
            This graph represents your current project structure. Drag nodes to explore the architecture. The central node is the project root.
          </p>
        </div>
      </div>
    </div>
  );
};

export default ProjectGraph;
