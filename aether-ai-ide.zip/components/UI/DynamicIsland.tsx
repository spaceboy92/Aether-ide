import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Sparkles, 
  Cpu, 
  Activity, 
  Volume2, 
  Maximize2, 
  Wind, 
  Rocket, 
  Zap, 
  ChevronDown, 
  CheckCircle2, 
  ShieldCheck,
  Code2,
  Terminal,
  X
} from "lucide-react";

interface DynamicIslandProps {
  activeSessionTitle?: string;
  systemStats: { cpu: string; memory: string; fps: number; disk: string };
  autoPilotMode?: boolean;
  setAutoPilotMode?: (val: boolean) => void;
  focusMode: boolean;
  setFocusMode: (val: boolean) => void;
  zenMode: boolean;
  setZenMode: (val: boolean) => void;
  onOpenDeploy?: () => void;
  onOpenHealth?: () => void;
}

export const DynamicIsland: React.FC<DynamicIslandProps> = ({
  activeSessionTitle,
  systemStats,
  autoPilotMode = true,
  setAutoPilotMode,
  focusMode,
  setFocusMode,
  zenMode,
  setZenMode,
  onOpenDeploy,
  onOpenHealth,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  // Audio click synthesizer for dynamic island interaction
  const playClickSound = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(800, ctx.currentTime);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.08);
    } catch (e) {
      // ignore
    }
  };

  return (
    <>
      {/* COLLAPSED PILL STATE IN HEADER */}
      <motion.div
        layoutId="dynamic-island-container"
        onClick={() => {
          playClickSound();
          setIsExpanded(true);
        }}
        className="h-7 px-2 sm:px-3 rounded-full flex items-center gap-1.5 sm:gap-2 bg-black/85 backdrop-blur-3xl border border-white/20 shadow-md cursor-pointer hover:scale-105 hover:bg-black/95 hover:border-white/30 transition-all max-w-[120px] xs:max-w-[180px] sm:max-w-[260px] md:max-w-none overflow-hidden shrink-0 select-none"
      >
        <div className="flex items-center justify-between w-full text-[10px] font-sans gap-1.5 min-w-0">
          <div className="flex items-center gap-1.5 min-w-0">
            {/* Glowing Dynamic Dot */}
            <div className="relative flex items-center justify-center w-2 h-2 shrink-0">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.9)]"></span>
            </div>

            <span className="font-bold text-white tracking-wide truncate text-[10px]">
              {activeSessionTitle || "Ready"}
            </span>
          </div>

          {/* Audio Waveform Micro-Visualizer */}
          <div className="hidden xs:flex items-center gap-1 shrink-0">
            <div className="hidden sm:flex items-center gap-0.5 h-3">
              <span className="w-0.5 h-2 bg-cyan-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
              <span className="w-0.5 h-3 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
              <span className="w-0.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              <span className="w-0.5 h-2.5 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '450ms' }} />
            </div>

            <span className="text-[8px] font-mono text-cyan-300 bg-cyan-500/20 px-1.5 py-0.2 rounded-full border border-cyan-500/30">
              STATUS
            </span>
          </div>
        </div>
      </motion.div>

      {/* EXPANDED DYNAMIC ISLAND FLOATING HUD OVERLAY */}
      <AnimatePresence>
        {isExpanded && (
          <div className="fixed inset-0 z-[200] flex justify-center items-start pt-12 sm:pt-14 p-3 sm:p-4 pointer-events-auto">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsExpanded(false)}
              className="fixed inset-0 bg-black/70 backdrop-blur-md z-[-1]"
            />

            {/* Expanded Modal Box */}
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: -12 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: -12 }}
              transition={{ type: "spring", stiffness: 400, damping: 30 }}
              className="w-[94vw] max-w-[420px] bg-zinc-950/95 backdrop-blur-3xl border border-cyan-500/40 rounded-3xl p-4 shadow-[0_25px_80px_rgba(0,0,0,0.95)] text-xs text-zinc-200 select-none space-y-3.5 relative"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-white/10 pb-2.5">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 text-black shadow-md">
                    <Sparkles size={14} className="animate-pulse" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white tracking-wide flex items-center gap-1.5">
                      System Monitor
                      <span className="text-[8px] font-mono px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                        ACTIVE
                      </span>
                    </h4>
                    <p className="text-[10px] text-zinc-400">Workspace status and performance</p>
                  </div>
                </div>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    playClickSound();
                    setIsExpanded(false);
                  }}
                  className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-zinc-300 transition-colors cursor-pointer"
                  title="Close Monitor"
                >
                  <X size={14} />
                </button>
              </div>

              {/* Status Card */}
              <div className="p-3 rounded-2xl bg-gradient-to-r from-blue-950/40 via-purple-950/30 to-black border border-blue-500/30 space-y-2">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    <CheckCircle2 size={13} className="text-emerald-400" />
                    AI Assistant & Diagnostics
                  </span>
                  <span className="text-[9px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30">
                    ONLINE
                  </span>
                </div>
                <p className="text-[10px] text-zinc-300 leading-relaxed">
                  Workspace syntax validator and diagnostics are active.
                </p>
              </div>

              {/* System Performance Gauges */}
              <div className="grid grid-cols-2 gap-2">
                <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 space-y-1">
                  <div className="flex items-center justify-between text-[10px] text-zinc-400 font-mono">
                    <span className="flex items-center gap-1"><Cpu size={12} className="text-cyan-400" /> CPU LOAD</span>
                    <span className="text-white font-bold">{systemStats.cpu}%</span>
                  </div>
                  <div className="w-full h-1.5 bg-black/60 rounded-full overflow-hidden">
                    <div className="h-full bg-cyan-400 transition-all duration-500" style={{ width: `${systemStats.cpu}%` }} />
                  </div>
                </div>

                <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 space-y-1">
                  <div className="flex items-center justify-between text-[10px] text-zinc-400 font-mono">
                    <span className="flex items-center gap-1"><Activity size={12} className="text-purple-400" /> MEMORY</span>
                    <span className="text-white font-bold">{systemStats.memory}</span>
                  </div>
                  <div className="w-full h-1.5 bg-black/60 rounded-full overflow-hidden">
                    <div className="h-full bg-purple-500 transition-all duration-500" style={{ width: '45%' }} />
                  </div>
                </div>
              </div>

              {/* Quick Actions Bar */}
              <div className="grid grid-cols-3 gap-2 pt-1">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (setAutoPilotMode) setAutoPilotMode(!autoPilotMode);
                  }}
                  className={`p-2 rounded-xl border text-[10px] font-bold flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                    autoPilotMode 
                      ? 'bg-amber-500/20 border-amber-500/40 text-amber-300' 
                      : 'bg-white/5 border-white/10 text-zinc-400 hover:text-white'
                  }`}
                >
                  <Zap size={14} />
                  <span>Auto-Pilot</span>
                </button>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setFocusMode(!focusMode);
                  }}
                  className={`p-2 rounded-xl border text-[10px] font-bold flex flex-col items-center justify-center gap-1 transition-all cursor-pointer ${
                    focusMode 
                      ? 'bg-blue-500/20 border-blue-500/40 text-blue-300' 
                      : 'bg-white/5 border-white/10 text-zinc-400 hover:text-white'
                  }`}
                >
                  <Maximize2 size={14} />
                  <span>Focus Mode</span>
                </button>

                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    if (onOpenDeploy) onOpenDeploy();
                  }}
                  className="p-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 border border-cyan-400 text-black font-bold text-[10px] flex flex-col items-center justify-center gap-1 shadow-md hover:brightness-110 transition-all cursor-pointer"
                >
                  <Rocket size={14} />
                  <span>Deploy App</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};

export default DynamicIsland;
