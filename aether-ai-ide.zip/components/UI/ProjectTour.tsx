import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  ChevronRight, 
  ChevronLeft, 
  X, 
  Sparkles,
  Info
} from "lucide-react";

interface Step {
  target: string;
  title: string;
  description: string;
  placement: "top" | "bottom" | "left" | "right" | "center";
}

const TOUR_STEPS: Step[] = [
  {
    target: "center",
    title: "Welcome to Aether IDE",
    description: "Your next-gen cinematic workspace. Let's take a quick tour of your new environment.",
    placement: "center"
  },
  {
    target: '[data-tour="sidebar-nav"]',
    title: "Neural Explorer",
    description: "Switch between your files, system settings, and global marketplace from this unified navigation rail.",
    placement: "right"
  },
  {
    target: '[data-tour="chat-interface"]',
    title: "AI Co-Developer",
    description: "The AI Assistant is integrated directly into your workflow. Ask it to build, debug, or optimize your code in real-time.",
    placement: "left"
  },
  {
    target: '[data-tour="preview-pane"]',
    title: "Live Neural Output",
    description: "See your code materialize instantly. Interacting with this pane is like working with a live production server.",
    placement: "left"
  },
  {
    target: '[data-tour="command-palette-trigger"]',
    title: "Universal Command Center",
    description: "Press Ctrl+K (or Cmd+K) to open the Command Palette. It's the fastest way to navigate the IDE.",
    placement: "top"
  },
  {
    target: '[data-tour="settings-entry"]',
    title: "Cloud Sync & Preferences",
    description: "Manage your Google Drive backups and customize your IDE theme here.",
    placement: "right"
  }
];

interface ProjectTourProps {
  onClose: () => void;
}

const ProjectTour: React.FC<ProjectTourProps> = ({ onClose }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [targetRect, setTargetRect] = useState<DOMRect | null>(null);

  const updateTargetRect = () => {
    const step = TOUR_STEPS[currentStep];
    if (step.placement === "center") {
      setTargetRect(null);
      return;
    }
    const element = document.querySelector(step.target);
    if (element) {
      setTargetRect(element.getBoundingClientRect());
      element.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } else {
      setTargetRect(null);
    }
  };

  useEffect(() => {
    updateTargetRect();
    const handleResize = () => updateTargetRect();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [currentStep]);

  const handleNext = () => {
    if (currentStep < TOUR_STEPS.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const currentSnapshot = TOUR_STEPS[currentStep];

  return (
    <div className="fixed inset-0 z-[1000] pointer-events-none overflow-hidden">
      {/* Darkened Overlay with cutout */}
      <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] transition-all duration-500" style={{
          clipPath: targetRect 
            ? `polygon(0% 0%, 0% 100%, ${targetRect.left}px 100%, ${targetRect.left}px ${targetRect.top}px, ${targetRect.right}px ${targetRect.top}px, ${targetRect.right}px ${targetRect.bottom}px, ${targetRect.left}px ${targetRect.bottom}px, ${targetRect.left}px 100%, 100% 100%, 100% 0%)`
            : 'none'
      }} />

      {/* Actual elements we want to interact with are NOT pointer-events-none, but the overlay is */}
      {/* We need to make the tour box interactable */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className={`
              absolute pointer-events-auto bg-zinc-900 border border-white/10 p-6 rounded-[2rem] shadow-2xl max-w-sm w-full
              ${!targetRect ? 'static' : ''}
            `}
            style={targetRect ? {
                top: currentSnapshot.placement === 'top' ? targetRect.top - 200 : currentSnapshot.placement === 'bottom' ? targetRect.bottom + 20 : 'auto',
                left: currentSnapshot.placement === 'left' ? targetRect.left - 420 : currentSnapshot.placement === 'right' ? targetRect.right + 20 : '50%',
                transform: !targetRect ? 'none' : currentSnapshot.placement === 'center' ? 'none' : (currentSnapshot.placement === 'left' || currentSnapshot.placement === 'right' ? 'translateY(-50%)' : 'translateX(-50%)'),
                marginTop: currentSnapshot.placement === 'center' ? 0 : 0
            } : {}}
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="p-2 bg-white/5 rounded-xl border border-white/5 text-white/40">
                  <Sparkles size={16} className="text-aether-accent" />
                </div>
                <button 
                  onClick={onClose}
                  className="p-1 hover:bg-white/5 rounded-full text-white/20 hover:text-white transition-colors"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="space-y-1">
                <h3 className="text-lg font-bold text-white tracking-tight">{currentSnapshot.title}</h3>
                <p className="text-white/50 text-xs leading-relaxed font-medium">
                  {currentSnapshot.description}
                </p>
              </div>

              <div className="flex items-center justify-between pt-2">
                <div className="text-[10px] font-bold text-white/20 uppercase tracking-widest">
                  Step {currentStep + 1} of {TOUR_STEPS.length}
                </div>
                <div className="flex gap-2">
                  {currentStep > 0 && (
                    <button
                      onClick={handlePrev}
                      className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-white transition-all"
                    >
                      <ChevronLeft size={16} />
                    </button>
                  )}
                  <button
                    onClick={handleNext}
                    className="px-4 py-2 bg-white text-black rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2"
                  >
                    {currentStep === TOUR_STEPS.length - 1 ? "Finish" : "Next"}
                    {currentStep < TOUR_STEPS.length - 1 && <ChevronRight size={14} />}
                  </button>
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};

export default ProjectTour;
