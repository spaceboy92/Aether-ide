import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bell, X, UserPlus, MessageSquare, Heart } from 'lucide-react';

export interface AppNotification {
  id: string;
  type: 'message' | 'friend_request' | 'like' | 'system';
  title: string;
  message: string;
  timestamp: number;
  read: boolean;
}

// Global event emitter for notifications
export const notificationEmitter = {
  listeners: [] as ((notif: AppNotification) => void)[],
  subscribe(fn: (notif: AppNotification) => void) {
    this.listeners.push(fn);
    return () => { this.listeners = this.listeners.filter(l => l !== fn); };
  },
  emit(notif: Omit<AppNotification, 'id' | 'timestamp' | 'read'>) {
    const fullNotif: AppNotification = {
      ...notif,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
      read: false
    };
    this.listeners.forEach(fn => fn(fullNotif));

    // Try browser push notification if permitted and document is not visible
    if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
      if (document.hidden) {
        new window.Notification(notif.title, {
          body: notif.message,
          icon: '/favicon.ico'
        });
      }
    }
  },
  requestPermission() {
    if (typeof Notification !== 'undefined' && Notification.permission !== 'granted' && Notification.permission !== 'denied') {
      Notification.requestPermission();
    }
  }
};

export const NotificationToast: React.FC = () => {
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    // Request permission on mount if viable
    if (typeof Notification !== 'undefined' && Notification.permission === 'default') {
      const timer = setTimeout(() => {
        notificationEmitter.requestPermission();
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, []);

  useEffect(() => {
    const unsubscribe = notificationEmitter.subscribe((notif) => {
      setNotifications(prev => [notif, ...prev].slice(0, 6)); // Keep up to 6 current notifications
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    if (isHovered || notifications.length === 0) return;
    const timer = setTimeout(() => {
      setNotifications(prev => prev.slice(0, -1));
    }, 7000);
    return () => clearTimeout(timer);
  }, [notifications, isHovered]);

  const removeNotif = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const clearAll = () => {
    setNotifications([]);
  };

  return (
    <div 
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="fixed top-16 sm:top-20 right-3 sm:right-6 z-[250] flex flex-col gap-2.5 pointer-events-none w-[calc(100vw-1.5rem)] sm:w-[380px] max-w-[420px]"
    >
      {notifications.length > 1 && (
        <div className="flex justify-end pointer-events-auto">
          <button
            onClick={clearAll}
            className="px-2.5 py-1 bg-black/80 hover:bg-black text-white/70 hover:text-white text-[10px] font-bold uppercase tracking-wider rounded-lg border border-white/10 backdrop-blur-xl shadow-lg transition-all flex items-center gap-1.5"
          >
            <span>Clear Notifications ({notifications.length})</span>
            <X size={12} />
          </button>
        </div>
      )}
      <AnimatePresence>
        {notifications.map(notif => (
          <motion.div
            key={notif.id}
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.2 } }}
            className="bg-[#0b1120]/95 backdrop-blur-2xl border border-white/15 p-3 sm:p-4 rounded-2xl shadow-[0_15px_40px_rgba(0,0,0,0.6)] w-full pointer-events-auto flex gap-3 sm:gap-3.5 items-start group relative overflow-hidden transition-all"
          >
            {/* Subtle glow effect behind icon */}
            <div className={`absolute top-0 left-0 w-24 h-24 rounded-full blur-2xl opacity-25 -translate-x-1/3 -translate-y-1/3 pointer-events-none ${
              notif.type === 'message' ? 'bg-blue-400' :
              notif.type === 'friend_request' ? 'bg-emerald-400' :
              notif.type === 'like' ? 'bg-rose-400' :
              'bg-orange-400'
            }`} />
            
            <div className={`p-2 sm:p-2.5 rounded-xl shrink-0 relative z-10 mt-0.5 ${
              notif.type === 'message' ? 'bg-blue-500/15 text-blue-400 ring-1 ring-blue-500/30' :
              notif.type === 'friend_request' ? 'bg-emerald-500/15 text-emerald-400 ring-1 ring-emerald-500/30' :
              notif.type === 'like' ? 'bg-rose-500/15 text-rose-400 ring-1 ring-rose-500/30' :
              'bg-orange-500/15 text-orange-400 ring-1 ring-orange-500/30'
            }`}>
              {notif.type === 'message' && <MessageSquare size={16} />}
              {notif.type === 'friend_request' && <UserPlus size={16} />}
              {notif.type === 'like' && <Heart size={16} />}
              {notif.type === 'system' && <Bell size={16} className="animate-pulse" />}
            </div>
            
            <div className="flex-1 min-w-0 py-0.5 relative z-10">
              <div className="flex items-center justify-between gap-2">
                <h4 className="text-xs sm:text-sm font-bold text-white tracking-tight truncate">{notif.title}</h4>
                <span className="text-[9px] font-mono text-white/40 shrink-0 uppercase tracking-wider">Live Feed</span>
              </div>
              <p className="text-[11px] sm:text-xs text-white/70 line-clamp-3 mt-1 leading-relaxed font-sans">{notif.message}</p>
            </div>
            
            <button 
              onClick={() => removeNotif(notif.id)} 
              className="p-1 sm:p-1.5 text-white/40 hover:text-white hover:bg-white/10 rounded-full shrink-0 transition-colors opacity-80 group-hover:opacity-100 focus:opacity-100 outline-none relative z-10"
            >
              <X size={14} />
            </button>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
};

