import React from 'react';
import { motion } from 'motion/react';

interface AppLogoProps {
  size?: number;
  className?: string;
  glow?: boolean;
}

const AppLogo: React.FC<AppLogoProps> = ({ size = 32, className = "", glow = true }) => {
  return (
    <div 
      className={`relative flex items-center justify-center select-none ${className}`} 
      style={{ width: size, height: size, transform: 'rotate(-12deg)' }}
    >
      <svg 
        viewBox="0 0 100 100" 
        className={`w-full h-full ${glow ? 'filter drop-shadow-[0_0_8px_rgba(249,115,22,0.65)]' : ''}`}
      >
        <defs>
          {/* Radial disk glow gradient */}
          <radialGradient id="logo-disk-grad" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="1" />
            <stop offset="25%" stopColor="#ffea9f" stopOpacity="0.95" />
            <stop offset="55%" stopColor="#ff7700" stopOpacity="0.8" />
            <stop offset="85%" stopColor="#ff2200" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#020205" stopOpacity="0" />
          </radialGradient>

          {/* Doppler Beaming Linear Gradient (Brighter on the left) */}
          <linearGradient id="logo-doppler-linear" x1="0%" y1="50%" x2="100%" y2="50%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="1" />
            <stop offset="20%" stopColor="#ffe699" stopOpacity="0.95" />
            <stop offset="45%" stopColor="#ff7300" stopOpacity="0.8" />
            <stop offset="75%" stopColor="#ff2200" stopOpacity="0.4" />
            <stop offset="100%" stopColor="#ff2200" stopOpacity="0" />
          </linearGradient>

          {/* Einstein Ring soft glow filter */}
          <filter id="logo-glow-orange" x="-30%" y="-30%" width="160%" height="160%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* 1. Upper Lensed Arch (Einstein lens warping behind) */}
        <path 
          d="M 12 50 A 38 31 0 0 1 88 50 A 35 22 0 0 0 12 50" 
          fill="url(#logo-disk-grad)" 
          opacity="0.9" 
        />
        <path 
          d="M 24 48 A 26 22 0 0 1 76 48" 
          fill="none" 
          stroke="#ffffff" 
          strokeWidth="1.25" 
          opacity="0.85" 
        />
        <path 
          d="M 18 50 A 32 26 0 0 1 82 50" 
          fill="none" 
          stroke="#ff9900" 
          strokeWidth="3.5" 
          filter="url(#logo-glow-orange)" 
          opacity="0.6" 
        />

        {/* 2. Lower Lensed Arch (Underneath background light) */}
        <path 
          d="M 16 50 A 34 26 0 0 0 84 50 A 30 17 0 0 1 16 50" 
          fill="url(#logo-disk-grad)" 
          opacity="0.75" 
        />
        <path 
          d="M 28 52 A 22 18 0 0 0 72 52" 
          fill="none" 
          stroke="#ff5500" 
          strokeWidth="1.0" 
          opacity="0.7" 
        />

        {/* 3. Einstein Ring / Photon Sphere */}
        <circle cx="50" cy="50" r="16" fill="none" stroke="#ffa366" strokeWidth="4.0" filter="url(#logo-glow-orange)" opacity="0.5" />
        <circle cx="50" cy="50" r="14.5" fill="none" stroke="#ffffff" strokeWidth="1.5" opacity="0.9" />

        {/* 4. Event Horizon Core (Solid absolute black trap) */}
        <circle cx="50" cy="50" r="13" fill="#010103" />

        {/* 5. Foreground Accretion Disk (Passing in front) */}
        <path 
          d="M 8 50 C 18 61, 82 61, 92 50 C 76 50.5, 24 50.5, 8 50" 
          fill="url(#logo-disk-grad)" 
          opacity="0.95" 
        />
        <path 
          d="M 8 50 C 20 57.5, 80 57.5, 92 50" 
          fill="none" 
          stroke="url(#logo-doppler-linear)" 
          strokeWidth="3.2" 
          strokeLinecap="round"
        />
        <path 
          d="M 14 50 C 25 54.5, 75 54.5, 86 50" 
          fill="none" 
          stroke="#ffffff" 
          strokeWidth="1.0" 
          strokeLinecap="round"
          opacity="0.9"
        />

        {/* Doppler beaming hot-spot highlight on left side */}
        <circle cx="26" cy="52" r="5" fill="#ffeeb0" filter="url(#logo-glow-orange)" opacity="0.35" />
      </svg>

      {size > 100 && (
        <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 whitespace-nowrap">
          <span className="text-xl font-bold tracking-[0.3em] text-white">AETHER</span>
          <div className="h-[1px] w-full bg-gradient-to-r from-transparent via-orange-500 to-transparent mt-2" />
        </div>
      )}
    </div>
  );
};

export default AppLogo;
