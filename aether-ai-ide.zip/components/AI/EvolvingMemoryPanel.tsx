import React, { useState, useEffect } from 'react';
import { Brain, Sparkles, RefreshCw, CheckCircle, Save, Trash2, X, Activity } from 'lucide-react';
import { getEvolvingProfile, updateEvolvingProfile, resetEvolvingProfile, EvolvingUserProfile } from '../../services/evolvingMemoryService';

interface EvolvingMemoryPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EvolvingMemoryPanel: React.FC<EvolvingMemoryPanelProps> = ({ isOpen, onClose }) => {
  const [profile, setProfile] = useState<EvolvingUserProfile>(getEvolvingProfile());
  const [newCorrection, setNewCorrection] = useState('');
  const [newInsight, setNewInsight] = useState('');

  useEffect(() => {
    if (isOpen) {
      setProfile(getEvolvingProfile());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleAddCorrection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCorrection.trim()) return;
    const updated = updateEvolvingProfile({
      frequentCorrections: [...profile.frequentCorrections, newCorrection.trim()]
    });
    setProfile(updated);
    setNewCorrection('');
  };

  const handleAddInsight = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newInsight.trim()) return;
    const updated = updateEvolvingProfile({
      learnedInsights: [...profile.learnedInsights, newInsight.trim()]
    });
    setProfile(updated);
    setNewInsight('');
  };

  const handleRemoveCorrection = (index: number) => {
    const list = [...profile.frequentCorrections];
    list.splice(index, 1);
    const updated = updateEvolvingProfile({ frequentCorrections: list });
    setProfile(updated);
  };

  const handleRemoveInsight = (index: number) => {
    const list = [...profile.learnedInsights];
    list.splice(index, 1);
    const updated = updateEvolvingProfile({ learnedInsights: list });
    setProfile(updated);
  };

  const handleReset = () => {
    if (window.confirm('Reset self-evolving AI memory profile back to default?')) {
      const reset = resetEvolvingProfile();
      setProfile(reset);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-zinc-950 border border-zinc-800 rounded-2xl w-full max-w-2xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="p-4 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/60">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-gradient-to-br from-amber-500/20 to-orange-500/20 border border-amber-500/30 text-amber-400">
              <Brain size={18} />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                Custom Instructions & Rules
                <span className="px-2 py-0.5 rounded-full text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono">
                  v{profile.version}.{profile.totalInteractions}
                </span>
              </h3>
              <p className="text-xs text-zinc-400">
                Set project conventions, code style, and rules that the assistant should follow.
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800">
            <X size={16} />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-y-auto space-y-5 custom-scrollbar text-xs">
          {/* Stats Bar */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-3 rounded-xl bg-zinc-900/80 border border-zinc-800">
              <div className="text-zinc-500 text-[10px] font-bold uppercase tracking-wider">Interactions</div>
              <div className="text-lg font-bold text-amber-400 font-mono mt-0.5">{profile.totalInteractions}</div>
            </div>
            <div className="p-3 rounded-xl bg-zinc-900/80 border border-zinc-800">
              <div className="text-zinc-500 text-[10px] font-bold uppercase tracking-wider">Learned Insights</div>
              <div className="text-lg font-bold text-emerald-400 font-mono mt-0.5">{profile.learnedInsights.length}</div>
            </div>
            <div className="p-3 rounded-xl bg-zinc-900/80 border border-zinc-800">
              <div className="text-zinc-500 text-[10px] font-bold uppercase tracking-wider">Active Rules</div>
              <div className="text-lg font-bold text-orange-400 font-mono mt-0.5">{profile.frequentCorrections.length}</div>
            </div>
          </div>

          {/* Preferences Grid */}
          <div className="space-y-3">
            <h4 className="font-bold text-zinc-300 text-xs flex items-center gap-1.5 uppercase tracking-wider">
              <Sparkles size={12} className="text-amber-400" /> Preferred Stack & Style
            </h4>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] text-zinc-400 font-medium">Preferred Tech Stack</label>
                <input
                  type="text"
                  value={profile.preferredFramework}
                  onChange={(e) => setProfile(updateEvolvingProfile({ preferredFramework: e.target.value }))}
                  className="w-full mt-1 bg-zinc-900 border border-zinc-800 rounded-lg p-2 text-xs text-white outline-none focus:border-amber-500/50"
                />
              </div>
              <div>
                <label className="text-[10px] text-zinc-400 font-medium">Styling & UI Theme</label>
                <input
                  type="text"
                  value={profile.preferredStyling}
                  onChange={(e) => setProfile(updateEvolvingProfile({ preferredStyling: e.target.value }))}
                  className="w-full mt-1 bg-zinc-900 border border-zinc-800 rounded-lg p-2 text-xs text-white outline-none focus:border-amber-500/50"
                />
              </div>
            </div>
          </div>

          {/* Learned Insights Section */}
          <div className="space-y-2">
            <h4 className="font-bold text-zinc-300 text-xs flex items-center gap-1.5 uppercase tracking-wider">
              <Activity size={12} className="text-emerald-400" /> Learned Project Insights
            </h4>
            <div className="space-y-1.5">
              {profile.learnedInsights.map((insight, idx) => (
                <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-zinc-900/80 border border-zinc-800/80">
                  <span className="text-zinc-300">{insight}</span>
                  <button onClick={() => handleRemoveInsight(idx)} className="p-1 text-zinc-500 hover:text-red-400">
                    <Trash2 size={12} />
                  </button>
                </div>
              ))}
            </div>
            <form onSubmit={handleAddInsight} className="flex gap-2 pt-1">
              <input
                type="text"
                placeholder="Add custom insight..."
                value={newInsight}
                onChange={(e) => setNewInsight(e.target.value)}
                className="flex-1 bg-zinc-900 border border-zinc-800 rounded-lg p-2 text-xs text-white outline-none focus:border-amber-500/50"
              />
              <button type="submit" className="px-3 py-1.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-lg font-medium hover:bg-emerald-500/30">
                Add
              </button>
            </form>
          </div>

          {/* Frequent Corrections / Custom Guidelines */}
          <div className="space-y-2">
            <h4 className="font-bold text-zinc-300 text-xs flex items-center gap-1.5 uppercase tracking-wider">
              <CheckCircle size={12} className="text-orange-400" /> Custom Rules & Guidelines
            </h4>
            <div className="space-y-1.5">
              {profile.frequentCorrections.map((corr, idx) => (
                <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-zinc-900/80 border border-zinc-800/80">
                  <span className="text-zinc-300">{corr}</span>
                  <button onClick={() => handleRemoveCorrection(idx)} className="p-1 text-zinc-500 hover:text-red-400">
                    <Trash2 size={12} />
                  </button>
                </div>
              ))}
            </div>
            <form onSubmit={handleAddCorrection} className="flex gap-2 pt-1">
              <input
                type="text"
                placeholder="Add custom rule (e.g., Always use Tailwind for styling)..."
                value={newCorrection}
                onChange={(e) => setNewCorrection(e.target.value)}
                className="flex-1 bg-zinc-900 border border-zinc-800 rounded-lg p-2 text-xs text-white outline-none focus:border-amber-500/50"
              />
              <button type="submit" className="px-3 py-1.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-lg font-medium hover:bg-amber-500/30">
                Add Rule
              </button>
            </form>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-zinc-800 bg-zinc-900/60 flex items-center justify-between">
          <button onClick={handleReset} className="flex items-center gap-1.5 text-zinc-400 hover:text-red-400 transition-colors">
            <RefreshCw size={12} /> Reset to Default
          </button>
          <button onClick={onClose} className="px-4 py-2 bg-amber-500 text-black font-bold rounded-xl hover:bg-amber-400 transition-colors">
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
