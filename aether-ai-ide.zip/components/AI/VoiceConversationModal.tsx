import React, { useState, useEffect, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Volume1,
  PhoneOff,
  Sparkles,
  Settings,
  Minimize2,
  Maximize2,
  RotateCcw,
  Square,
  Radio,
  Sliders,
  MessageSquare,
  Bot,
  User,
  Zap,
  Check,
  ChevronDown,
  Send,
  Copy,
  Search,
  Trash2,
  Download,
  FileText,
  Code2,
  Play,
  Pause,
  RefreshCw,
  Layers,
  LayoutGrid,
  Headphones,
  CheckCircle2,
  Flame,
  Activity,
  Gauge,
  Music,
  Palette
} from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { ChatSession, FileNode } from "../../types";

export interface VoiceConversationModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeSession: ChatSession | null;
  selectedModel: string;
  isProcessing: boolean;
  onSendMessage: (
    text: string,
    attachments?: any[],
    modelId?: string,
    isCompactMode?: boolean,
    sessionOverride?: any,
    activeAgentIds?: string[]
  ) => void;
  onStopProcessing?: () => void;
  files: FileNode[];
  activeFileName?: string;
}

const AVAILABLE_VOICES = [
  { id: "Kore", label: "Kore", desc: "Balanced & Natural", tone: "Warm Neutral" },
  { id: "Puck", label: "Puck", desc: "Dynamic & Upbeat", tone: "Energetic" },
  { id: "Fenrir", label: "Fenrir", desc: "Deep & Resonant", tone: "Authoritative" },
  { id: "Zephyr", label: "Zephyr", desc: "Calm & Smooth", tone: "Relaxed" },
  { id: "Charon", label: "Charon", desc: "Precise & Direct", tone: "Analytical" }
];

const VISUALIZER_THEMES = [
  { id: "flame", label: "Aether Flame", gradient: ["#f97316", "#f59e0b", "#ffffff"], aura: "from-amber-500 to-orange-500", glow: "rgba(249,115,22,0.4)" },
  { id: "cyan", label: "Cyber Cyan", gradient: ["#06b6d4", "#3b82f6", "#ffffff"], aura: "from-cyan-500 to-blue-600", glow: "rgba(6,182,212,0.4)" },
  { id: "matrix", label: "Matrix Emerald", gradient: ["#10b981", "#84cc16", "#ffffff"], aura: "from-emerald-500 to-lime-500", glow: "rgba(16,185,129,0.4)" },
  { id: "violet", label: "Quantum Violet", gradient: ["#a855f7", "#ec4899", "#ffffff"], aura: "from-purple-600 to-pink-500", glow: "rgba(168,85,247,0.4)" }
];

const SUGGESTED_VOICE_PROMPTS = [
  "Explain this project and key files",
  "Review active code and find bugs",
  "Refactor the current file for performance",
  "Generate unit tests for core logic",
  "Suggest modern UI improvements"
];

export const VoiceConversationModal: React.FC<VoiceConversationModalProps> = ({
  isOpen,
  onClose,
  activeSession,
  selectedModel,
  isProcessing,
  onSendMessage,
  onStopProcessing,
  files,
  activeFileName
}) => {
  // Navigation & View Mode
  const [viewMode, setViewMode] = useState<"split" | "visualizer" | "transcript">("split");
  const [isMinimized, setIsMinimized] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [selectedTheme, setSelectedTheme] = useState<string>(() => localStorage.getItem("aether_voice_theme") || "flame");

  // Voice conversation states
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeakerMuted, setIsSpeakerMuted] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [handsFreeMode, setHandsFreeMode] = useState(true);
  const [silenceDuration, setSilenceDuration] = useState<number>(1400); // ms
  const [audioCuesEnabled, setAudioCuesEnabled] = useState<boolean>(true);
  const [voiceStyle, setVoiceStyle] = useState<"concise" | "detailed">("concise");
  const [bargeInEnabled, setBargeInEnabled] = useState<boolean>(true);
  const [micSensitivity, setMicSensitivity] = useState<number>(50); // Noise gate filter

  const [selectedVoice, setSelectedVoice] = useState<string>(() => localStorage.getItem("aether_voice") || "Kore");
  const [ttsMode, setTtsMode] = useState<"premium" | "browser">(() => {
    return (localStorage.getItem("aether_tts_mode") as any) || "premium";
  });
  const [speechRate, setSpeechRate] = useState<number>(1.0);
  const [volume, setVolume] = useState<number>(1.0);

  // Hybrid Text Input inside Voice HUD
  const [textInput, setTextInput] = useState("");
  const [includeActiveFile, setIncludeActiveFile] = useState(true);

  // Live transcription & conversation log
  const [interimTranscript, setInterimTranscript] = useState("");
  const [lastUserSpoken, setLastUserSpoken] = useState("");
  const [lastAiSpoken, setLastAiSpoken] = useState("");
  const [statusMessage, setStatusMessage] = useState("Connected to Aether Voice Channel");
  const [transcriptSearch, setTranscriptSearch] = useState("");
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);

  // Telemetry stats
  const [wordsSpokenCount, setWordsSpokenCount] = useState(0);
  const [isHoldingSpace, setIsHoldingSpace] = useState(false);
  const [sessionStartTime] = useState<number>(() => Date.now());

  // Web Audio & Speech Recognition Refs
  const recognitionRef = useRef<any>(null);
  const isStoppingRef = useRef<boolean>(false);
  const isSpeakingRef = useRef<boolean>(false);
  const isMutedRef = useRef<boolean>(false);
  const lastStartTimeRef = useRef<number>(0);
  const consecutiveErrorsRef = useRef<number>(0);
  const restartTimerRef = useRef<NodeJS.Timeout | null>(null);
  const silenceTimerRef = useRef<NodeJS.Timeout | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const activeAudioSourceRef = useRef<{ source: AudioBufferSourceNode; ctx: AudioContext } | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const transcriptBottomRef = useRef<HTMLDivElement | null>(null);
  const textInputRef = useRef<HTMLInputElement | null>(null);
  const lastProcessedBotMsgIdRef = useRef<string | null>(null);
  const isComponentActiveRef = useRef(true);

  useEffect(() => {
    isSpeakingRef.current = isSpeaking;
  }, [isSpeaking]);

  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);

  useEffect(() => {
    localStorage.setItem("aether_voice", selectedVoice);
  }, [selectedVoice]);

  useEffect(() => {
    localStorage.setItem("aether_tts_mode", ttsMode);
  }, [ttsMode]);

  useEffect(() => {
    localStorage.setItem("aether_voice_theme", selectedTheme);
  }, [selectedTheme]);

  // Gentle Web Audio Sound Cue Synthesizer
  const playAudioCue = useCallback((type: "start" | "done" | "chime") => {
    if (!audioCuesEnabled) return;
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioContextClass();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = "sine";
      const now = ctx.currentTime;

      if (type === "start") {
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.exponentialRampToValueAtTime(880, now + 0.12);
        gain.gain.setValueAtTime(0.04, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.13);
      } else if (type === "done") {
        osc.frequency.setValueAtTime(659, now);
        osc.frequency.exponentialRampToValueAtTime(523, now + 0.15);
        gain.gain.setValueAtTime(0.04, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.16);
      } else {
        osc.frequency.setValueAtTime(587, now);
        gain.gain.setValueAtTime(0.03, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.11);
      }
    } catch (e) {
      // ignore
    }
  }, [audioCuesEnabled]);

  // Auto scroll transcript to bottom
  const scrollToTranscriptBottom = () => {
    if (transcriptBottomRef.current) {
      transcriptBottomRef.current.scrollIntoView({ behavior: "smooth" });
    }
  };

  useEffect(() => {
    if (isOpen) {
      scrollToTranscriptBottom();
    }
  }, [activeSession?.messages?.length, isOpen, interimTranscript]);

  // Clean stop of all audio output
  const stopAudioPlayback = useCallback(() => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    if (activeAudioSourceRef.current) {
      try {
        activeAudioSourceRef.current.source.stop();
        activeAudioSourceRef.current.ctx.close();
      } catch (e) {
        // ignore
      }
      activeAudioSourceRef.current = null;
    }
    setIsSpeaking(false);
    isSpeakingRef.current = false;
  }, []);

  // Safe stop speech recognition
  const stopListeningGracefully = useCallback(() => {
    isStoppingRef.current = true;
    if (restartTimerRef.current) {
      clearTimeout(restartTimerRef.current);
      restartTimerRef.current = null;
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {
        // ignore
      }
      recognitionRef.current = null;
    }
    setIsListening(false);
  }, []);

  // Speak AI text using Gemini TTS or Browser Web Speech API
  const speakText = useCallback(async (text: string) => {
    if (!text || !text.trim() || isSpeakerMuted) return;

    // Apply branding replacement dynamically to guarantee no lingering references are spoken
    const brandedText = text
      .replace(/Synapse Studio/g, "Aether IDE")
      .replace(/Synapse/g, "Aether");

    stopAudioPlayback();
    stopListeningGracefully();
    setIsSpeaking(true);
    isSpeakingRef.current = true;
    setStatusMessage("Aether is speaking...");
    setLastAiSpoken(brandedText);

    // Filter code blocks and markdown symbols for natural audio speech
    let cleanSpeech = brandedText
      .replace(/```[\s\S]*?```/g, " [I've updated the code in your workspace.] ")
      .replace(/`([^`]+)`/g, "$1")
      .replace(/[#*_~>]/g, "")
      .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
      .replace(/https?:\/\/[^\s]+/g, "link")
      .replace(/\s+/g, " ")
      .trim();

    // If concise mode, keep spoken summary succinct
    if (voiceStyle === "concise" && cleanSpeech.length > 280) {
      const firstSentences = cleanSpeech.match(/[^.!?]+[.!?]+/g);
      if (firstSentences && firstSentences.length > 0) {
        cleanSpeech = firstSentences.slice(0, 2).join(" ");
      }
    }

    if (!cleanSpeech) {
      setIsSpeaking(false);
      isSpeakingRef.current = false;
      return;
    }

    if (ttsMode === "premium") {
      try {
        const res = await fetch("/api/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: cleanSpeech, voice: selectedVoice })
        });

        const data = await res.json();
        if (data.success && data.audio) {
          const binaryString = atob(data.audio);
          const len = binaryString.length;
          const bytes = new Uint8Array(len);
          const view = new DataView(bytes.buffer);
          for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }

          const numSamples = len / 2;
          const float32Data = new Float32Array(numSamples);
          for (let i = 0; i < numSamples; i++) {
            const sample = view.getInt16(i * 2, true);
            float32Data[i] = sample / 32768.0;
          }

          const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
          const audioCtx = new AudioContextClass();
          const audioBuffer = audioCtx.createBuffer(1, numSamples, 24000);
          audioBuffer.getChannelData(0).set(float32Data);

          const source = audioCtx.createBufferSource();
          source.buffer = audioBuffer;
          source.playbackRate.value = speechRate;

          // Gain Node for volume control
          const gainNode = audioCtx.createGain();
          gainNode.gain.value = volume;
          source.connect(gainNode);
          gainNode.connect(audioCtx.destination);

          source.onended = () => {
            if (activeAudioSourceRef.current?.source === source) {
              setIsSpeaking(false);
              isSpeakingRef.current = false;
              setStatusMessage(handsFreeMode ? "Listening for your voice..." : "Ready for voice input");
              activeAudioSourceRef.current = null;
              playAudioCue("done");
              if (handsFreeMode && !isMutedRef.current && isComponentActiveRef.current) {
                startListening();
              }
            }
          };

          source.start(0);
          activeAudioSourceRef.current = { source, ctx: audioCtx };
          return;
        }
      } catch (err) {
        // Fallback gracefully
      }
    }

    // Fallback: Browser Web Speech API
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(cleanSpeech);
      utterance.rate = speechRate;
      utterance.volume = volume;
      utterance.pitch = 1.0;
      utterance.onend = () => {
        setIsSpeaking(false);
        isSpeakingRef.current = false;
        setStatusMessage(handsFreeMode ? "Listening for your voice..." : "Ready for voice input");
        playAudioCue("done");
        if (handsFreeMode && !isMutedRef.current && isComponentActiveRef.current) {
          startListening();
        }
      };
      utterance.onerror = () => {
        setIsSpeaking(false);
        isSpeakingRef.current = false;
      };
      window.speechSynthesis.speak(utterance);
    } else {
      setIsSpeaking(false);
      isSpeakingRef.current = false;
    }
  }, [selectedVoice, ttsMode, speechRate, volume, handsFreeMode, isSpeakerMuted, voiceStyle, stopAudioPlayback, stopListeningGracefully, playAudioCue]);

  // Setup Microphone & Audio Analyzer for dynamic visualizer waves
  const initMicrophoneAudio = useCallback(async () => {
    try {
      if (mediaStreamRef.current) return;
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      mediaStreamRef.current = stream;

      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioContextClass();
      audioContextRef.current = ctx;

      const analyser = ctx.createAnalyser();
      analyser.fftSize = 128;
      analyserRef.current = analyser;

      const source = ctx.createMediaStreamSource(stream);
      source.connect(analyser);

      // Draw real-time waveform on canvas
      const drawWaveform = () => {
        if (!isComponentActiveRef.current) return;
        const canvas = canvasRef.current;
        if (canvas && analyserRef.current) {
          const canvasCtx = canvas.getContext("2d");
          if (canvasCtx) {
            const bufferLength = analyserRef.current.frequencyBinCount;
            const dataArray = new Uint8Array(bufferLength);
            analyserRef.current.getByteFrequencyData(dataArray);

            canvasCtx.clearRect(0, 0, canvas.width, canvas.height);

            const barWidth = (canvas.width / bufferLength) * 1.5;
            let x = 0;

            const themeObj = VISUALIZER_THEMES.find(t => t.id === selectedTheme) || VISUALIZER_THEMES[0];

            for (let i = 0; i < bufferLength; i++) {
              const barHeight = (dataArray[i] / 255) * (canvas.height * 0.85);

              const gradient = canvasCtx.createLinearGradient(0, canvas.height, 0, 0);
              gradient.addColorStop(0, "rgba(255, 255, 255, 0.05)");
              gradient.addColorStop(0.5, themeObj.gradient[0]);
              gradient.addColorStop(1, themeObj.gradient[1]);

              canvasCtx.fillStyle = gradient;
              canvasCtx.fillRect(
                x,
                (canvas.height - barHeight) / 2,
                Math.max(barWidth - 1.5, 2),
                Math.max(barHeight, 3)
              );

              x += barWidth + 1.2;
            }
          }
        }
        animationFrameRef.current = requestAnimationFrame(drawWaveform);
      };

      drawWaveform();
    } catch (e) {
      // Audio stream optional for visualizer
    }
  }, [selectedTheme]);

  // Submit query to the assistant
  const handleSendQuery = useCallback((queryText: string) => {
    const text = queryText.trim();
    if (!text || isProcessing) return;

    playAudioCue("chime");
    setLastUserSpoken(text);
    setInterimTranscript("");
    setTextInput("");
    setStatusMessage("Aether is thinking & processing...");
    setWordsSpokenCount(prev => prev + text.split(/\s+/).length);

    stopListeningGracefully();

    // Context prepended if active file selected
    let promptWithContext = text;
    if (includeActiveFile && activeFileName) {
      const activeFile = files.find(f => f.name === activeFileName);
      if (activeFile?.content) {
        promptWithContext = `[Context File: ${activeFileName}]\n${text}`;
      }
    }

    onSendMessage(promptWithContext, [], selectedModel);
  }, [isProcessing, onSendMessage, selectedModel, includeActiveFile, activeFileName, files, playAudioCue, stopListeningGracefully]);

  // Start Speech Recognition cleanly without aborted error loops
  const startListening = useCallback(() => {
    if (isMutedRef.current || isSpeakingRef.current || isProcessing || !isComponentActiveRef.current) return;

    // Rate limit starting speech recognition to avoid double-triggers
    const nowTime = Date.now();
    if (nowTime - lastStartTimeRef.current < 1000) {
      return;
    }
    lastStartTimeRef.current = nowTime;

    const SpeechRecognition =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setStatusMessage("Speech recognition not supported in browser");
      return;
    }

    try {
      // Abort any existing instance safely
      if (recognitionRef.current) {
        isStoppingRef.current = true;
        try {
          recognitionRef.current.stop();
        } catch (e) {
          // ignore
        }
        recognitionRef.current = null;
      }

      isStoppingRef.current = false;
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = "en-US";

      recognition.onstart = () => {
        if (!isComponentActiveRef.current) return;
        setIsListening(true);
        setStatusMessage("Listening to you...");
        consecutiveErrorsRef.current = 0; // reset error counters on success
      };

      recognition.onresult = (event: any) => {
        let interim = "";
        let final = "";

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            final += transcript + " ";
          } else {
            interim += transcript;
          }
        }

        if (interim) {
          setInterimTranscript(interim);
          // High-fidelity Barge-in logic: stop audio playback if user interrupts
          if (bargeInEnabled && isSpeakingRef.current) {
            stopAudioPlayback();
          }
        }

        if (final.trim()) {
          setInterimTranscript("");
          setLastUserSpoken(final.trim());

          if (silenceTimerRef.current) {
            clearTimeout(silenceTimerRef.current);
          }

          if (handsFreeMode) {
            silenceTimerRef.current = setTimeout(() => {
              handleSendQuery(final.trim());
            }, silenceDuration);
          }
        }
      };

      recognition.onerror = (event: any) => {
        const error = event.error;
        consecutiveErrorsRef.current += 1;

        // Auto-pause loop if we encounter multiple consecutive failures
        if (consecutiveErrorsRef.current > 3) {
          isStoppingRef.current = true;
          setStatusMessage(`Microphone unavailable or blocked. Standby.`);
        }

        // Benign lifecycle events in browsers: ignore quietly
        if (error === "aborted" || error === "no-speech" || error === "audio-capture" || error === "network") {
          return;
        }
      };

      recognition.onend = () => {
        setIsListening(false);

        if (isStoppingRef.current) {
          isStoppingRef.current = false;
          return;
        }

        // Restart with debounce if still active, handsfree, and not speaking
        if (
          isComponentActiveRef.current &&
          handsFreeMode &&
          !isSpeakingRef.current &&
          !isProcessing &&
          !isMutedRef.current &&
          consecutiveErrorsRef.current < 3
        ) {
          if (restartTimerRef.current) clearTimeout(restartTimerRef.current);
          
          // Use a backoff delay to prevent infinite fast-crashing loop
          const backoffDelay = 350 + (consecutiveErrorsRef.current * 1000);
          
          restartTimerRef.current = setTimeout(() => {
            if (isComponentActiveRef.current && !isSpeakingRef.current && !isMutedRef.current && !isProcessing) {
              startListening();
            }
          }, backoffDelay);
        }
      };

      recognition.start();
      recognitionRef.current = recognition;
    } catch (err) {
      // Speech recognition start error handled safely
    }
  }, [isProcessing, handsFreeMode, silenceDuration, handleSendQuery, stopAudioPlayback, bargeInEnabled]);

  // Monitor latest bot message arrival and speak it
  const lastBotMessage = activeSession?.messages?.filter(m => m.role === "model").slice(-1)[0];

  useEffect(() => {
    if (!isOpen) return;

    if (lastBotMessage && lastBotMessage.id !== lastProcessedBotMsgIdRef.current) {
      lastProcessedBotMsgIdRef.current = lastBotMessage.id;
      if (!isProcessing && lastBotMessage.text) {
        speakText(lastBotMessage.text);
      }
    }
  }, [lastBotMessage, isProcessing, isOpen, speakText]);

  // Keyboard Spacebar Push-to-Talk listener
  useEffect(() => {
    if (!isOpen || handsFreeMode) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === "Space" && !isHoldingSpace && document.activeElement !== textInputRef.current) {
        e.preventDefault();
        setIsHoldingSpace(true);
        setIsMuted(false);
        startListening();
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === "Space" && isHoldingSpace) {
        e.preventDefault();
        setIsHoldingSpace(false);
        if (lastUserSpoken.trim()) {
          handleSendQuery(lastUserSpoken);
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, [isOpen, handsFreeMode, isHoldingSpace, lastUserSpoken, handleSendQuery, startListening]);

  // Lifecycle initialization on open
  useEffect(() => {
    isComponentActiveRef.current = isOpen;

    if (isOpen) {
      initMicrophoneAudio();
      setStatusMessage("Connected to Aether Voice Channel");

      // If this session has no messages, give a welcoming Aether IDE greeting
      if (!activeSession?.messages || activeSession.messages.length === 0) {
        speakText("Hello! I'm Aether, your AI coding co-pilot. How can I help you build, code, or debug today?");
      } else {
        startListening();
      }
    } else {
      stopAudioPlayback();
      stopListeningGracefully();
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      if (restartTimerRef.current) clearTimeout(restartTimerRef.current);
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
        mediaStreamRef.current = null;
      }
    }

    return () => {
      isComponentActiveRef.current = false;
      stopAudioPlayback();
      stopListeningGracefully();
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      if (restartTimerRef.current) clearTimeout(restartTimerRef.current);
      if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
        mediaStreamRef.current = null;
      }
    };
  }, [isOpen, initMicrophoneAudio, startListening, stopAudioPlayback, stopListeningGracefully, activeSession?.messages?.length]);

  // Filter messages for the transcript view
  const messagesList = activeSession?.messages || [];
  const filteredMessages = transcriptSearch.trim()
    ? messagesList.filter(m => m.text.toLowerCase().includes(transcriptSearch.toLowerCase()))
    : messagesList;

  const handleCopyMessage = (msgId: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMsgId(msgId);
    setTimeout(() => setCopiedMsgId(null), 2000);
  };

  const handleExportTranscript = () => {
    const text = messagesList
      .map(m => `### ${m.role === "user" ? "User" : "Aether AI"} (${new Date(m.timestamp).toLocaleTimeString()})\n${m.text}\n`)
      .join("\n---\n\n");
    const blob = new Blob([text], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `aether-voice-session-${new Date().toISOString().slice(0, 10)}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const currentTheme = VISUALIZER_THEMES.find(t => t.id === selectedTheme) || VISUALIZER_THEMES[0];

  if (!isOpen) return null;

  // Floating Minimized HUD
  if (isMinimized) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.8, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.8 }}
        className="fixed bottom-6 right-6 z-50 flex items-center gap-3 bg-[#0c0d14]/95 border border-orange-500/40 rounded-full px-4 py-2.5 shadow-2xl backdrop-blur-2xl text-white select-none"
      >
        <div className="flex items-center gap-2">
          <div className="relative flex items-center justify-center">
            <div className={`w-3 h-3 rounded-full ${isSpeaking ? "bg-amber-400 animate-ping" : isListening ? "bg-orange-500 animate-pulse" : "bg-zinc-600"}`} />
            <div className={`absolute w-3 h-3 rounded-full ${isSpeaking ? "bg-amber-400" : isListening ? "bg-orange-500" : "bg-zinc-600"}`} />
          </div>
          <span className="text-xs font-bold tracking-tight">
            {isSpeaking ? "Aether Speaking" : isListening ? "Listening..." : isProcessing ? "Thinking..." : "Voice Standby"}
          </span>
        </div>

        <div className="h-4 w-px bg-white/10" />

        <button
          onClick={() => {
            if (isSpeaking) {
              stopAudioPlayback();
            } else {
              setIsMuted(!isMuted);
              if (isMuted) startListening();
            }
          }}
          className={`p-1.5 rounded-full transition-all cursor-pointer ${isMuted ? "bg-red-500/20 text-red-400" : "hover:bg-white/10 text-zinc-300"}`}
          title={isMuted ? "Unmute Mic" : "Mute Mic"}
        >
          {isMuted ? <MicOff size={14} /> : <Mic size={14} />}
        </button>

        <button
          onClick={() => setIsMinimized(false)}
          className="p-1.5 rounded-full hover:bg-white/10 text-zinc-300 hover:text-white transition-all cursor-pointer"
          title="Expand Aether Voice Studio"
        >
          <Maximize2 size={14} />
        </button>

        <button
          onClick={onClose}
          className="p-1.5 rounded-full bg-red-500/20 hover:bg-red-500 text-red-400 hover:text-white transition-all cursor-pointer"
          title="End Voice Call"
        >
          <PhoneOff size={14} />
        </button>
      </motion.div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/85 backdrop-blur-xl animate-in fade-in duration-200">
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.96, y: 15 }}
        className="relative w-full max-w-5xl bg-[#090a10] border border-white/10 rounded-3xl shadow-2xl overflow-hidden flex flex-col h-[92vh] max-h-[860px] text-white"
      >
        {/* Top Header Bar */}
        <div className="px-5 py-3.5 border-b border-white/5 flex items-center justify-between bg-zinc-950/80 backdrop-blur-md shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-orange-500/20 to-amber-500/20 border border-orange-500/30 flex items-center justify-center text-orange-400 shadow-inner">
              <Radio size={17} className="animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-sm text-white tracking-wide">Aether Voice Studio</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono bg-orange-500/10 border border-orange-500/20 text-orange-400">
                  {selectedVoice} Persona
                </span>
                {activeFileName && (
                  <span className="hidden md:inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono bg-zinc-800/80 border border-white/5 text-zinc-300">
                    <FileText size={10} className="text-amber-400" />
                    {activeFileName}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-zinc-400 font-mono">
                {statusMessage}
              </p>
            </div>
          </div>

          {/* Center: View Switcher Tabs */}
          <div className="hidden sm:flex items-center bg-zinc-900/90 border border-white/10 rounded-xl p-1 gap-1">
            <button
              onClick={() => setViewMode("split")}
              className={`px-3 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                viewMode === "split"
                  ? "bg-orange-500 text-black shadow-md"
                  : "text-zinc-400 hover:text-white"
              }`}
            >
              <Layers size={13} />
              <span>Split View</span>
            </button>
            <button
              onClick={() => setViewMode("visualizer")}
              className={`px-3 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                viewMode === "visualizer"
                  ? "bg-orange-500 text-black shadow-md"
                  : "text-zinc-400 hover:text-white"
              }`}
            >
              <Activity size={13} />
              <span>Visualizer</span>
            </button>
            <button
              onClick={() => setViewMode("transcript")}
              className={`px-3 py-1 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                viewMode === "transcript"
                  ? "bg-orange-500 text-black shadow-md"
                  : "text-zinc-400 hover:text-white"
              }`}
            >
              <MessageSquare size={13} />
              <span>Full Transcript</span>
            </button>
          </div>

          {/* Right Header Actions */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setShowSettings(!showSettings)}
              className={`p-2 rounded-xl transition-all cursor-pointer ${
                showSettings
                  ? "bg-orange-500/20 text-orange-400 border border-orange-500/30"
                  : "text-zinc-400 hover:text-white hover:bg-white/5"
              }`}
              title="Voice Settings & Persona Controls"
            >
              <Sliders size={16} />
            </button>

            <button
              onClick={() => setIsMinimized(true)}
              className="p-2 rounded-xl text-zinc-400 hover:text-white hover:bg-white/5 transition-all cursor-pointer"
              title="Minimize to Floating Widget"
            >
              <Minimize2 size={16} />
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl text-zinc-400 hover:text-red-400 hover:bg-red-500/10 transition-all cursor-pointer"
              title="End Voice Call"
            >
              <PhoneOff size={16} />
            </button>
          </div>
        </div>

        {/* Settings Drawer Popover */}
        <AnimatePresence>
          {showSettings && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-zinc-900/95 border-b border-white/10 p-5 space-y-4 overflow-hidden z-20 shrink-0"
            >
              <div className="flex items-center justify-between border-b border-white/5 pb-2">
                <span className="text-xs font-bold uppercase tracking-wider text-zinc-300 flex items-center gap-1.5">
                  <Settings size={14} className="text-orange-400" /> Voice & Audio Persona Customization
                </span>
                <button
                  onClick={() => setShowSettings(false)}
                  className="text-xs font-semibold text-orange-400 hover:text-orange-300 cursor-pointer"
                >
                  Done
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {/* Voice Selection */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-medium text-zinc-400 flex items-center gap-1">
                    <Headphones size={12} className="text-orange-400" /> Neural Persona
                  </label>
                  <div className="grid grid-cols-2 gap-1.5">
                    {AVAILABLE_VOICES.map((v) => (
                      <button
                        key={v.id}
                        onClick={() => {
                          setSelectedVoice(v.id);
                          speakText(`Hello, I am ${v.label}, your Aether voice co-pilot.`);
                        }}
                        className={`p-2 rounded-xl text-left border transition-all cursor-pointer ${
                          selectedVoice === v.id
                            ? "bg-orange-500/15 border-orange-500/40 text-orange-300 font-bold"
                            : "bg-black/40 border-white/5 text-zinc-400 hover:border-white/20 hover:text-white"
                        }`}
                      >
                        <div className="text-xs">{v.label}</div>
                        <div className="text-[9px] text-zinc-500">{v.tone}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Turn-Taking & Response Style */}
                <div className="space-y-3">
                  <div>
                    <label className="text-[11px] font-medium text-zinc-400 block mb-1">Turn-Taking Mode</label>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setHandsFreeMode(true)}
                        className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-medium border transition-all cursor-pointer ${
                          handsFreeMode
                            ? "bg-orange-500/15 border-orange-500/40 text-orange-400"
                            : "bg-black/40 border-white/5 text-zinc-400 hover:text-white"
                        }`}
                      >
                        Hands-Free Auto
                      </button>
                      <button
                        onClick={() => setHandsFreeMode(false)}
                        className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-medium border transition-all cursor-pointer ${
                          !handsFreeMode
                            ? "bg-orange-500/15 border-orange-500/40 text-orange-400"
                            : "bg-black/40 border-white/5 text-zinc-400 hover:text-white"
                        }`}
                      >
                        Push to Talk
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-medium text-zinc-400 block mb-1">Spoken Response Style</label>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setVoiceStyle("concise")}
                        className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-medium border transition-all cursor-pointer ${
                          voiceStyle === "concise"
                            ? "bg-orange-500/15 border-orange-500/40 text-orange-400"
                            : "bg-black/40 border-white/5 text-zinc-400 hover:text-white"
                        }`}
                        title="Short spoken summary while code is written to editor"
                      >
                        Concise Audio
                      </button>
                      <button
                        onClick={() => setVoiceStyle("detailed")}
                        className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-medium border transition-all cursor-pointer ${
                          voiceStyle === "detailed"
                            ? "bg-orange-500/15 border-orange-500/40 text-orange-400"
                            : "bg-black/40 border-white/5 text-zinc-400 hover:text-white"
                        }`}
                        title="Full spoken explanation"
                      >
                        Detailed
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-medium text-zinc-400 block mb-1">Barge-In Interruption</label>
                    <button
                      onClick={() => setBargeInEnabled(!bargeInEnabled)}
                      className={`w-full py-1.5 px-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                        bargeInEnabled
                          ? "bg-orange-500/15 border-orange-500/40 text-orange-300 font-bold"
                          : "bg-black/40 border-white/5 text-zinc-500"
                      }`}
                      title="Let's you talk over Aether to interrupt immediately"
                    >
                      {bargeInEnabled ? "Active (Talk Over)" : "Inactive (No Interruption)"}
                    </button>
                  </div>
                </div>

                {/* VAD Sensitivity & Theme */}
                <div className="space-y-3">
                  <div>
                    <label className="text-[11px] font-medium text-zinc-400 block mb-1">Pause Detection Duration</label>
                    <div className="grid grid-cols-3 gap-1">
                      {[
                        { label: "800ms", val: 800 },
                        { label: "1.4s", val: 1400 },
                        { label: "2.2s", val: 2200 }
                      ].map((item) => (
                        <button
                          key={item.val}
                          onClick={() => setSilenceDuration(item.val)}
                          className={`py-1 rounded-lg text-xs font-mono border transition-all cursor-pointer ${
                            silenceDuration === item.val
                              ? "bg-orange-500/20 border-orange-500/50 text-orange-400 font-bold"
                              : "bg-black/40 border-white/5 text-zinc-400 hover:text-white"
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-medium text-zinc-400 block mb-1 flex items-center gap-1">
                      <Palette size={11} className="text-orange-400" /> Visualizer Aura Theme
                    </label>
                    <div className="grid grid-cols-2 gap-1.5">
                      {VISUALIZER_THEMES.map((theme) => (
                        <button
                          key={theme.id}
                          onClick={() => setSelectedTheme(theme.id)}
                          className={`px-2 py-1 rounded-lg text-[11px] border text-left truncate transition-all cursor-pointer ${
                            selectedTheme === theme.id
                              ? "bg-white/10 border-white/40 text-white font-bold"
                              : "bg-black/40 border-white/5 text-zinc-400 hover:text-white"
                          }`}
                        >
                          {theme.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Speed, Volume, Audio Cues */}
                <div className="space-y-3">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[11px] font-medium text-zinc-400">Speech Rate</label>
                      <span className="text-[11px] font-mono text-orange-400">{speechRate}x</span>
                    </div>
                    <div className="flex gap-1.5">
                      {[0.8, 1.0, 1.25, 1.5].map((rate) => (
                        <button
                          key={rate}
                          onClick={() => setSpeechRate(rate)}
                          className={`flex-1 py-1 rounded-lg text-xs font-mono border transition-all cursor-pointer ${
                            speechRate === rate
                              ? "bg-orange-500/20 border-orange-500/50 text-orange-400 font-bold"
                              : "bg-black/40 border-white/5 text-zinc-400 hover:text-white"
                          }`}
                        >
                          {rate}x
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[11px] font-medium text-zinc-400">Speaker Volume</label>
                      <span className="text-[11px] font-mono text-orange-400">{Math.round(volume * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0.1"
                      max="1"
                      step="0.05"
                      value={volume}
                      onChange={(e) => setVolume(parseFloat(e.target.value))}
                      className="w-full accent-orange-500 h-1.5 bg-zinc-800 rounded-lg cursor-pointer"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-[11px] font-medium text-zinc-400">Mic Sensitivity Gate</label>
                      <span className="text-[11px] font-mono text-orange-400">{micSensitivity}%</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max="100"
                      step="5"
                      value={micSensitivity}
                      onChange={(e) => setMicSensitivity(parseInt(e.target.value))}
                      className="w-full accent-orange-500 h-1.5 bg-zinc-800 rounded-lg cursor-pointer"
                      title="Adjust noise threshold filtering for voice capture"
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Main Content Area */}
        <div className="flex-1 overflow-hidden grid grid-cols-1 md:grid-cols-12 min-h-0">
          
          {/* Left Column: Visualizer Orb & Live Audio States */}
          {(viewMode === "split" || viewMode === "visualizer") && (
            <div className={`flex flex-col items-center justify-between p-6 border-r border-white/5 bg-gradient-to-b from-zinc-950/40 to-black/60 overflow-y-auto ${
              viewMode === "visualizer" ? "md:col-span-12" : "md:col-span-5"
            }`}>
              
              {/* Top Quick Voice Triggers */}
              <div className="w-full">
                <div className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Sparkles size={11} className="text-orange-400" /> Spoken Co-Pilot Triggers
                  </span>
                  <span className="text-[10px] font-mono text-zinc-500">
                    {wordsSpokenCount} words spoken
                  </span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {SUGGESTED_VOICE_PROMPTS.slice(0, 3).map((prompt, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleSendQuery(prompt)}
                      className="text-[11px] text-zinc-300 bg-white/5 hover:bg-orange-500/10 hover:border-orange-500/30 border border-white/5 rounded-xl px-2.5 py-1 transition-all text-left truncate max-w-full cursor-pointer active:scale-95"
                    >
                      "{prompt}"
                    </button>
                  ))}
                </div>
              </div>

              {/* Central Glowing Visualizer Orb */}
              <div className="flex flex-col items-center justify-center my-auto py-6 w-full">
                <div className="relative flex items-center justify-center">
                  {/* Outer Pulsing Aura */}
                  <motion.div
                    animate={{
                      scale: isSpeaking ? [1, 1.4, 1] : isListening ? [1, 1.25, 1] : isProcessing ? [1, 1.15, 1] : 1,
                      opacity: isSpeaking ? [0.35, 0.75, 0.35] : isListening ? [0.2, 0.5, 0.2] : isProcessing ? [0.25, 0.6, 0.25] : 0.08
                    }}
                    transition={{
                      duration: isSpeaking ? 1.4 : isProcessing ? 2.0 : 2.5,
                      repeat: Infinity,
                      ease: "easeInOut"
                    }}
                    className={`absolute w-48 h-48 rounded-full filter blur-3xl pointer-events-none ${
                      isSpeaking
                        ? `bg-gradient-to-tr ${currentTheme.aura}`
                        : isListening
                        ? "bg-gradient-to-tr from-orange-600 to-amber-600"
                        : isProcessing
                        ? "bg-gradient-to-tr from-purple-600 to-orange-500"
                        : "bg-zinc-700"
                    }`}
                  />

                  {/* Secondary Animated Ring */}
                  {isSpeaking && (
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
                      className="absolute w-36 h-36 rounded-full border border-dashed border-amber-400/40 pointer-events-none"
                    />
                  )}

                  {/* Central Core Orb */}
                  <div
                    className={`relative w-28 h-28 rounded-full flex items-center justify-center border shadow-2xl transition-all duration-300 ${
                      isSpeaking
                        ? "bg-gradient-to-br from-amber-400 to-orange-600 border-amber-300/60 shadow-[0_0_45px_rgba(245,158,11,0.5)] cursor-pointer"
                        : isListening
                        ? "bg-gradient-to-br from-orange-500 to-amber-600 border-orange-400/50 shadow-[0_0_35px_rgba(249,115,22,0.4)]"
                        : isProcessing
                        ? "bg-gradient-to-br from-zinc-800 to-zinc-900 border-orange-500/40 shadow-[0_0_25px_rgba(249,115,22,0.2)]"
                        : "bg-zinc-900 border-zinc-800"
                    }`}
                    onClick={() => {
                      if (isSpeaking) {
                        stopAudioPlayback();
                      } else if (!isProcessing) {
                        if (isMuted) {
                          setIsMuted(false);
                          startListening();
                        }
                      }
                    }}
                    title={isSpeaking ? "Click to interrupt Aether speech" : "Microphone active"}
                  >
                    {isSpeaking ? (
                      <Volume2 size={36} className="text-black animate-pulse" />
                    ) : isListening ? (
                      <Mic size={36} className="text-black animate-bounce" />
                    ) : isProcessing ? (
                      <Sparkles size={34} className="text-orange-400 animate-spin" />
                    ) : (
                      <Bot size={36} className="text-zinc-500" />
                    )}
                  </div>
                </div>

                {/* Waveform Frequency Equalizer Canvas */}
                <div className="w-full max-w-sm mt-5 h-12 flex items-center justify-center">
                  <canvas
                    ref={canvasRef}
                    width={320}
                    height={48}
                    className="w-full h-full opacity-85"
                  />
                </div>

                {/* State Label & Quick Action */}
                <div className="mt-3 text-center">
                  <div className="text-xs font-bold text-zinc-200">
                    {isSpeaking ? (
                      <span className="text-amber-400 flex items-center gap-1 justify-center">
                        <Volume2 size={13} /> Aether is speaking...
                      </span>
                    ) : isListening ? (
                      <span className="text-orange-400 flex items-center gap-1 justify-center">
                        <Mic size={13} /> Listening to your microphone...
                      </span>
                    ) : isProcessing ? (
                      <span className="text-orange-300 flex items-center gap-1 justify-center">
                        <Sparkles size={13} className="animate-spin" /> Synthesizing solution...
                      </span>
                    ) : (
                      <span className="text-zinc-400">Microphone standby</span>
                    )}
                  </div>
                  {lastAiSpoken && (
                    <button
                      onClick={() => speakText(lastAiSpoken)}
                      className="mt-1.5 text-[10px] text-zinc-400 hover:text-orange-400 flex items-center gap-1 mx-auto transition-colors cursor-pointer"
                    >
                      <RotateCcw size={10} /> Replay last response
                    </button>
                  )}
                </div>
              </div>

              {/* Spoken Preview Card */}
              <div className="w-full bg-zinc-950/80 border border-white/5 rounded-2xl p-3.5 space-y-2">
                {interimTranscript ? (
                  <div className="flex items-start gap-2.5">
                    <div className="p-1 rounded-md bg-orange-500/20 text-orange-400 shrink-0 mt-0.5">
                      <User size={12} />
                    </div>
                    <div className="flex-1 text-xs text-amber-200/90 font-medium italic animate-pulse">
                      "{interimTranscript}"
                    </div>
                  </div>
                ) : lastUserSpoken ? (
                  <div className="flex items-start gap-2.5">
                    <div className="p-1 rounded-md bg-white/10 text-zinc-300 shrink-0 mt-0.5">
                      <User size={12} />
                    </div>
                    <div className="flex-1 text-xs text-zinc-300 font-medium line-clamp-2">
                      "{lastUserSpoken}"
                    </div>
                  </div>
                ) : (
                  <div className="text-center text-[11px] text-zinc-500 font-mono py-1">
                    Speak naturally into your microphone or type below
                  </div>
                )}
              </div>

              {/* Live Session Telemetry Metrics */}
              <div className="w-full grid grid-cols-2 gap-2">
                <div className="bg-zinc-950/40 border border-white/5 rounded-xl p-2 text-center">
                  <div className="text-[9px] uppercase font-bold text-zinc-500 tracking-widest">Voice Latency</div>
                  <div className="text-xs font-mono font-bold text-orange-400 mt-1 flex items-center justify-center gap-1">
                    <Zap size={11} className="text-amber-400 animate-pulse" />
                    <span>Low-Latency</span>
                  </div>
                </div>
                <div className="bg-zinc-950/40 border border-white/5 rounded-xl p-2 text-center">
                  <div className="text-[9px] uppercase font-bold text-zinc-500 tracking-widest">VAD Connection</div>
                  <div className="text-xs font-mono font-bold text-orange-400 mt-1 flex items-center justify-center gap-1">
                    <Gauge size={11} className="text-orange-400" />
                    <span>Neural API</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Right Column: Full Interactive Transcript Log */}
          {(viewMode === "split" || viewMode === "transcript") && (
            <div className={`flex flex-col h-full bg-[#07080d] min-h-0 ${
              viewMode === "transcript" ? "md:col-span-12" : "md:col-span-7"
            }`}>
              
              {/* Transcript Toolbar */}
              <div className="p-3 px-4 border-b border-white/5 flex items-center justify-between gap-2 bg-zinc-950/60 shrink-0">
                <div className="flex items-center gap-2">
                  <MessageSquare size={14} className="text-orange-400" />
                  <span className="text-xs font-bold uppercase tracking-wider text-zinc-300">
                    Live Transcript
                  </span>
                  <span className="text-[10px] font-mono text-zinc-500 bg-zinc-900 px-1.5 py-0.5 rounded-md">
                    {messagesList.length} turns
                  </span>
                </div>

                <div className="flex items-center gap-1.5">
                  {/* Search Bar in Transcript */}
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Search transcript..."
                      value={transcriptSearch}
                      onChange={(e) => setTranscriptSearch(e.target.value)}
                      className="w-32 sm:w-44 bg-zinc-900/90 border border-white/5 rounded-lg pl-6 pr-2 py-1 text-[11px] text-zinc-200 placeholder-zinc-500 outline-none focus:border-orange-500/50"
                    />
                    <Search size={11} className="absolute left-2 top-2 text-zinc-500" />
                  </div>

                  {/* Export Transcript */}
                  <button
                    onClick={handleExportTranscript}
                    className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-white/5 transition-all cursor-pointer"
                    title="Export Transcript as Markdown"
                  >
                    <Download size={13} />
                  </button>
                </div>
              </div>

              {/* Transcript Messages Stream */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4 no-scrollbar">
                {filteredMessages.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-6 text-zinc-500">
                    <MessageSquare size={28} className="mb-2 text-zinc-600" />
                    <p className="text-xs font-medium">No spoken messages recorded yet.</p>
                    <p className="text-[11px] text-zinc-600 mt-1">Start speaking or type in the bar below.</p>
                  </div>
                ) : (
                  filteredMessages.map((msg, index) => {
                    const isUser = msg.role === "user";
                    const isCopied = copiedMsgId === msg.id;
                    const cleanMsgText = msg.text
                      .replace(/Synapse Studio/g, "Aether IDE")
                      .replace(/Synapse/g, "Aether");

                    return (
                      <div
                        key={msg.id || index}
                        className={`flex gap-3 group ${isUser ? "flex-row-reverse" : "flex-row"}`}
                      >
                        {/* Avatar Badge */}
                        <div
                          className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 mt-0.5 border ${
                            isUser
                              ? "bg-zinc-800 border-white/10 text-zinc-300"
                              : "bg-orange-500/20 border-orange-500/30 text-orange-400"
                          }`}
                        >
                          {isUser ? <User size={13} /> : <Bot size={13} />}
                        </div>

                        {/* Message Bubble */}
                        <div
                          className={`max-w-[85%] rounded-2xl p-3.5 space-y-1.5 relative border ${
                            isUser
                              ? "bg-zinc-900 border-white/10 text-zinc-100"
                              : "bg-zinc-950/80 border-orange-500/20 text-zinc-200"
                          }`}
                        >
                          {/* Top Author & Timestamp Header */}
                          <div className="flex items-center justify-between gap-4 text-[10px] text-zinc-400 pb-1 border-b border-white/5">
                            <span className="font-bold uppercase tracking-wider">
                              {isUser ? "You" : "Aether AI"}
                            </span>
                            <div className="flex items-center gap-2">
                              <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                              {!isUser && (
                                <button
                                  onClick={() => speakText(cleanMsgText)}
                                  className="text-zinc-400 hover:text-orange-400 transition-colors cursor-pointer"
                                  title="Read Aloud"
                                >
                                  <Volume2 size={12} />
                                </button>
                              )}
                              <button
                                  onClick={() => handleCopyMessage(msg.id || String(index), cleanMsgText)}
                                className="text-zinc-400 hover:text-white transition-colors cursor-pointer"
                                title="Copy Text"
                              >
                                {isCopied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                              </button>
                            </div>
                          </div>

                          {/* Message Content */}
                          <div className="text-xs leading-relaxed overflow-x-auto">
                            {isUser ? (
                              <p className="whitespace-pre-wrap">{cleanMsgText}</p>
                            ) : (
                              <div className="prose prose-invert prose-xs max-w-none">
                                <ReactMarkdown remarkPlugins={[remarkGfm]}>
                                  {cleanMsgText}
                                </ReactMarkdown>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}

                {/* Live Interim Bubble */}
                {interimTranscript && (
                  <div className="flex gap-3 flex-row-reverse animate-pulse">
                    <div className="w-7 h-7 rounded-xl flex items-center justify-center shrink-0 mt-0.5 bg-orange-500/20 border border-orange-500/40 text-orange-400">
                      <User size={13} />
                    </div>
                    <div className="max-w-[85%] rounded-2xl p-3 bg-zinc-900/90 border border-orange-500/40 text-amber-200 text-xs italic">
                      {interimTranscript} ...
                    </div>
                  </div>
                )}

                <div ref={transcriptBottomRef} />
              </div>
            </div>
          )}
        </div>

        {/* Integrated Bottom Controller & Text Input Bar */}
        <div className="p-3.5 sm:p-4 border-t border-white/5 bg-zinc-950/95 backdrop-blur-md flex flex-col gap-2.5 shrink-0">
          
          {/* Hybrid Quick Text Bar */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (textInput.trim()) {
                handleSendQuery(textInput);
              }
            }}
            className="flex items-center gap-2 bg-[#0d0e17] border border-white/10 focus-within:border-orange-500/50 rounded-2xl p-1.5 px-3 transition-all"
          >
            <input
              ref={textInputRef}
              type="text"
              placeholder="Type a message or speak naturally into your microphone..."
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
              className="flex-1 bg-transparent text-xs sm:text-sm text-white placeholder-zinc-500 outline-none"
            />

            {/* Quick Context Attachment Indicator */}
            {activeFileName && (
              <button
                type="button"
                onClick={() => setIncludeActiveFile(!includeActiveFile)}
                className={`hidden sm:flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-mono border transition-all cursor-pointer ${
                  includeActiveFile
                    ? "bg-amber-500/15 border-amber-500/40 text-amber-300 font-semibold"
                    : "bg-zinc-900 border-white/5 text-zinc-500 line-through"
                }`}
                title="Include active editor file context"
              >
                <Code2 size={11} />
                <span>{activeFileName}</span>
              </button>
            )}

            <button
              type="submit"
              disabled={!textInput.trim() || isProcessing}
              className="p-2 rounded-xl bg-orange-500 hover:bg-orange-400 disabled:opacity-40 disabled:hover:bg-orange-500 text-black font-bold transition-all cursor-pointer shadow-md active:scale-95"
              title="Send Message"
            >
              <Send size={14} />
            </button>
          </form>

          {/* Primary Action Button Controls */}
          <div className="flex items-center justify-between">
            {/* Left: Quick Actions */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  if (isSpeaking) {
                    stopAudioPlayback();
                  } else {
                    const next = !isMuted;
                    setIsMuted(next);
                    if (!next) startListening();
                  }
                }}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer active:scale-95 ${
                  isMuted
                    ? "bg-red-500/15 border-red-500/40 text-red-400 hover:bg-red-500/25"
                    : isListening
                    ? "bg-orange-500/15 border-orange-500/40 text-orange-400 shadow-[0_0_15px_rgba(249,115,22,0.2)]"
                    : "bg-zinc-900 border-white/10 text-zinc-300 hover:text-white"
                }`}
              >
                {isMuted ? <MicOff size={14} /> : <Mic size={14} />}
                <span>{isMuted ? "Unmute Mic" : isListening ? "Mute Mic" : "Mic Standby"}</span>
              </button>

              <button
                onClick={() => {
                  if (!isSpeakerMuted && isSpeaking) {
                    stopAudioPlayback();
                  }
                  setIsSpeakerMuted(!isSpeakerMuted);
                }}
                className={`p-2 rounded-xl border transition-all cursor-pointer ${
                  isSpeakerMuted
                    ? "bg-red-500/15 border-red-500/40 text-red-400"
                    : "bg-zinc-900 border-white/10 text-zinc-300 hover:text-white"
                }`}
                title={isSpeakerMuted ? "Unmute Speaker Audio" : "Mute Speaker Audio"}
              >
                {isSpeakerMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
              </button>

              {/* Sound Cues Toggle */}
              <button
                onClick={() => setAudioCuesEnabled(!audioCuesEnabled)}
                className={`p-2 rounded-xl border transition-all cursor-pointer ${
                  audioCuesEnabled
                    ? "bg-amber-500/15 border-amber-500/30 text-amber-400"
                    : "bg-zinc-900 border-white/10 text-zinc-500"
                }`}
                title={audioCuesEnabled ? "Audio Cues Enabled" : "Audio Cues Disabled"}
              >
                <Music size={14} />
              </button>
            </div>

            {/* Center: Push to Talk Hold Indicator (when not in hands-free) */}
            {!handsFreeMode && (
              <div className="hidden sm:flex items-center gap-2 text-xs text-zinc-400 font-mono">
                <span className="px-2 py-0.5 rounded bg-zinc-800 border border-white/10 text-orange-400">
                  Hold Spacebar
                </span>
                <span>to speak</span>
              </div>
            )}

            {/* Right: Stop / Interrupt & End Call */}
            <div className="flex items-center gap-2">
              {isSpeaking && (
                <button
                  onClick={stopAudioPlayback}
                  className="flex items-center gap-1 px-3 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-bold transition-all cursor-pointer active:scale-95"
                >
                  <Square size={12} className="fill-amber-300" />
                  <span>Interrupt</span>
                </button>
              )}

              {isProcessing && onStopProcessing && (
                <button
                  onClick={onStopProcessing}
                  className="flex items-center gap-1 px-3 py-2 rounded-xl bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-400 text-xs font-bold transition-all cursor-pointer active:scale-95"
                >
                  <Square size={12} className="fill-red-400" />
                  <span>Stop Thinking</span>
                </button>
              )}

              <button
                onClick={onClose}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold transition-all shadow-lg shadow-red-950/50 cursor-pointer active:scale-95"
              >
                <PhoneOff size={14} />
                <span>End Call</span>
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
