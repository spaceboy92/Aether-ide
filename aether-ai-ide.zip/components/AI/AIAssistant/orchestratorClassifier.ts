import { FileNode } from "../../../types";

export interface OrchestratorAgent {
  id: string;
  name: string;
  role: string;
  desc: string;
  divisionId: string;
  divisionName: string;
  divisionType: 'game' | 'frontend' | 'backend' | 'ai' | 'testing' | 'devops' | 'intelligence' | 'mobile_pwa' | 'data_cloud' | 'algorithms_perf';
  systemInstructionSnippet?: string;
}

export interface OrchestratorDivision {
  id: string;
  name: string;
  shortName: string;
  type: 'game' | 'frontend' | 'backend' | 'ai' | 'testing' | 'devops' | 'intelligence' | 'mobile_pwa' | 'data_cloud' | 'algorithms_perf';
  color: string;
  iconColor: string;
  badgeBg: string;
  agents: OrchestratorAgent[];
}

export const ORCHESTRATOR_DIVISIONS: OrchestratorDivision[] = [
  {
    id: "game_spec",
    name: "🎮 3D & 2D Game Division",
    shortName: "Game Dev",
    type: "game",
    color: "border-amber-500/20 text-amber-400 bg-amber-500/5",
    iconColor: "text-amber-400",
    badgeBg: "bg-amber-500/10 text-amber-400 border-amber-500/20",
    agents: [
      {
        id: "three_js",
        name: "Three.js / WebGL Agent",
        role: "Scene Graph & Lighting Conductor",
        desc: "Initializes WebGL scene, perspective camera, ACES tone mapping, shadow maps, and directional sun lights",
        divisionId: "game_spec",
        divisionName: "3D & 2D Game Division",
        divisionType: "game",
        systemInstructionSnippet: "Configure high-performance Three.js rendering loops, shadow map configurations (PCFSoftShadowMap), ACESFilmic tone mapping, and camera tracking with anti-aliasing."
      },
      {
        id: "game_modeler",
        name: "3D Modeler & Mesh Synthesizer",
        role: "Procedural Geometry & Asset Lofting",
        desc: "Procedural 3D geometries, vehicles, mechs, aircraft, procedural heightmap terrain, and parametric vertex matrices",
        divisionId: "game_spec",
        divisionName: "3D & 2D Game Division",
        divisionType: "game",
        systemInstructionSnippet: "Generate parametric 3D meshes, smooth vertex normal calculations, procedural cars, spaceships, mechs, and high-density heightmap terrains."
      },
      {
        id: "game_architect",
        name: "Physics & Level Architect",
        role: "Kinematics, Colliders & Controls",
        desc: "WASD / touch controls, delta-time normalized velocity vectors, raycast jump colliders, and bounding box collision checks",
        divisionId: "game_spec",
        divisionName: "3D & 2D Game Division",
        divisionType: "game",
        systemInstructionSnippet: "Implement rigid body collision matrices, WASD and mobile touch virtual joysticks, delta-time physics normalization, and gravity."
      },
      {
        id: "game_ui",
        name: "HUD & UI Master",
        role: "Game Canvas Overlay & State Screens",
        desc: "Overlay start screens, health & shield meters, score counters, minimap displays, pause menus, and game over screens",
        divisionId: "game_spec",
        divisionName: "3D & 2D Game Division",
        divisionType: "game",
        systemInstructionSnippet: "Build high-contrast responsive HUD overlays with Tailwind CSS and HTML Canvas, health bars, start overlays, minimaps, and game over modals."
      },
      {
        id: "game_audio",
        name: "Procedural Audio Synthesizer",
        role: "Web Audio API Oscillator Engine",
        desc: "100% client-side Web Audio API sound effects (lasers, explosions, engine revs, impact clangs, synthwave loops)",
        divisionId: "game_spec",
        divisionName: "3D & 2D Game Division",
        divisionType: "game",
        systemInstructionSnippet: "Synthesize dynamic sound effects using Web Audio API oscillator nodes, gain curves, bandpass filters, and noise burst generators."
      },
      {
        id: "game_director",
        name: "Game Director & Gameplay Loop",
        role: "Game State Engine & Universal Multi-Language Game Architect",
        desc: "Orchestrates game loops, wave spawners, scoring rules, and multi-language game engine generation (Python/Pygame '.py', Three.js/WebGL, HTML5 Canvas, C++, Rust)",
        divisionId: "game_spec",
        divisionName: "3D & 2D Game Division",
        divisionType: "game",
        systemInstructionSnippet: "Orchestrate complete game architectures in ANY requested programming language (Python '.py' with Pygame/numpy/math, WebGL/Three.js, Canvas 2D, Rust '.rs', C++ '.cpp', etc.). Write full, production-ready code matching the user's explicit language specification."
      },
      {
        id: "shader_vfx",
        name: "Shaders & Particle VFX",
        role: "GLSL & Particle Explosion Engine",
        desc: "High-performance particle systems, thruster trails, explosion blasts, camera trauma screenshakes, and custom GLSL effects",
        divisionId: "game_spec",
        divisionName: "3D & 2D Game Division",
        divisionType: "game",
        systemInstructionSnippet: "Build particle emitters, thruster trails, explosion shocks, bloom post-processing, and camera screenshake matrices."
      },
      {
        id: "multiplayer_netcode",
        name: "Netcode & Multiplayer Sync",
        role: "WebRTC & Socket.io Realtime State",
        desc: "Client-side prediction, entity interpolation, lockstep game state broadcasting, and lobby matchmaking",
        divisionId: "game_spec",
        divisionName: "3D & 2D Game Division",
        divisionType: "game",
        systemInstructionSnippet: "Architect low-latency multiplayer netcode with WebRTC/Socket.io, state reconciliation, and peer-to-peer synchronization."
      },
      {
        id: "vr_ar_spatial",
        name: "WebXR & Spatial Audio Agent",
        role: "VR/AR Immersive Controller",
        desc: "WebXR session initialization, hand tracking, 6DOF spatial audio panning, and pass-through AR mesh overlays",
        divisionId: "game_spec",
        divisionName: "3D & 2D Game Division",
        divisionType: "game",
        systemInstructionSnippet: "Implement WebXR controllers, spatial audio panners, and immersive VR/AR rendering layers."
      },
      {
        id: "webgl_gpu_fluid",
        name: "WebGL GPU Fluid & Particle Simulator",
        role: "GPGPU Velocity Fields & Particle Physics",
        desc: "High-density particle physics, Navier-Stokes fluid velocity fields, custom physics simulation shaders, and wind vector integrations",
        divisionId: "game_spec",
        divisionName: "3D & 2D Game Division",
        divisionType: "game",
        systemInstructionSnippet: "Develop WebGL2 state buffers, vector fields for fluid motion, high-density particle calculations, and complex gravity modifiers."
      },
      {
        id: "pbr_material_architect",
        name: "Procedural PBR Material Architect",
        role: "GLSL Normal Maps & Procedural Textures",
        desc: "Generates high-fidelity normal maps, metallic, roughness, and dynamic height occlusion parameters procedurally via GLSL and Simplex noise",
        divisionId: "game_spec",
        divisionName: "3D & 2D Game Division",
        divisionType: "game",
        systemInstructionSnippet: "Synthesize sophisticated WebGL fragment shaders that output high-performance procedural textures, micro-normal displacements, and lighting values."
      }
    ]
  },
  {
    id: "frontend",
    name: "🎨 Frontend Division",
    shortName: "Frontend",
    type: "frontend",
    color: "border-cyan-500/20 text-cyan-400 bg-cyan-500/5",
    iconColor: "text-cyan-400",
    badgeBg: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20",
    agents: [
      {
        id: "multipage_architect",
        name: "Multi-Page & Folder Architect",
        role: "Page Routes & Physical Directories",
        desc: "Architects multi-page web applications, route hierarchies, physical folder structures (pages/, components/, routes/, services/), and SPA/HTML transitions",
        divisionId: "frontend",
        divisionName: "Frontend Division",
        divisionType: "frontend",
        systemInstructionSnippet: "Decompose applications into physical directory hierarchies with pages/, components/, and shared layouts, providing clean multi-page routing and persistent state."
      },
      {
        id: "ui_ux",
        name: "UI/UX Architect",
        role: "Design Systems & User Experience",
        desc: "Design system tokens, responsive grid layouts, color harmony, typography hierarchy, and WCAG AA contrast rules",
        divisionId: "frontend",
        divisionName: "Frontend Division",
        divisionType: "frontend",
        systemInstructionSnippet: "Craft sophisticated WCAG AA compliant design systems, fluid spacing systems, harmonic typography pairs, and anti-slop visual elegance."
      },
      {
        id: "react_core",
        name: "React & State Engine",
        role: "Component Trees & Hook Lifecycle",
        desc: "Component architecture, hooks lifecycle, immutable state managers, and reactive subscriptions",
        divisionId: "frontend",
        divisionName: "Frontend Division",
        divisionType: "frontend",
        systemInstructionSnippet: "Structure clean functional React components with memoization, stable callbacks, Context API, and zero infinite render loops."
      },
      {
        id: "styling",
        name: "Styling & Motion Engine",
        role: "Tailwind CSS & Motion Transitions",
        desc: "Tailwind utility styling, layout transitions, CSS animations, and theme configurations",
        divisionId: "frontend",
        divisionName: "Frontend Division",
        divisionType: "frontend",
        systemInstructionSnippet: "Apply Tailwind CSS utilities, fluid responsive grid/flex layouts, motion layout transitions, and glassmorphic elevation layers."
      },
      {
        id: "components_core",
        name: "Component Builder",
        role: "Interactive UI Elements",
        desc: "Buttons, modals, dropdowns, forms, dashboard widgets, bento cards, and responsive navigation bars",
        divisionId: "frontend",
        divisionName: "Frontend Division",
        divisionType: "frontend",
        systemInstructionSnippet: "Build robust, reusable interactive components with complete event handlers, input validation, and keyboard interaction."
      },
      {
        id: "accessibility",
        name: "ARIA & Focus Manager",
        role: "Accessibility & Keyboard Navigation",
        desc: "ARIA attributes, keyboard navigation, focus trap management, and screen reader announcements",
        divisionId: "frontend",
        divisionName: "Frontend Division",
        divisionType: "frontend",
        systemInstructionSnippet: "Enforce full keyboard accessibility (Tab, Esc, Enter, Arrow keys), ARIA labels, role bindings, and screen reader compatibility."
      },
      {
        id: "fe_performance",
        name: "Frontend Optimizer",
        role: "Render Profiling & Asset Pruning",
        desc: "Lazy loading, render debounce profiling, bundle optimization, and image asset caching",
        divisionId: "frontend",
        divisionName: "Frontend Division",
        divisionType: "frontend",
        systemInstructionSnippet: "Optimize render trees with React.lazy, dynamic imports, debounced inputs, virtualized lists, and efficient memory usage."
      },
      {
        id: "micro_frontend",
        name: "Micro-Frontend Architect",
        role: "Component Federation & Modular Bundles",
        desc: "Isolated component modules, independent bundle mounting, and shared dependency injection",
        divisionId: "frontend",
        divisionName: "Frontend Division",
        divisionType: "frontend",
        systemInstructionSnippet: "Architect modular micro-frontends with clear boundaries, dynamic component loading, and event bus communication."
      },
      {
        id: "theme_design_tokens",
        name: "Theme & Design Token Engine",
        role: "Dynamic Palette & Dark/Light Mode",
        desc: "CSS variable token maps, dynamic theme swappers, contrast auditing, and accent color accentuation",
        divisionId: "frontend",
        divisionName: "Frontend Division",
        divisionType: "frontend",
        systemInstructionSnippet: "Manage fluid CSS custom properties, seamless dark/light mode toggling, and adaptive theme color tokens."
      },
      {
        id: "bento_grid_designer",
        name: "Bento Grid Layout Specialist",
        role: "High-Density Grid & Metric Balancer",
        desc: "Designs visually striking, responsive bento grids, layout weights, information hierarchies, and custom card aspect ratios",
        divisionId: "frontend",
        divisionName: "Frontend Division",
        divisionType: "frontend",
        systemInstructionSnippet: "Construct optically balanced bento structures with varying card span scales, sleek content distribution, and rich hover highlights."
      },
      {
        id: "d3_chart_visualizer",
        name: "Interactive Chart & D3.js Visualizer",
        role: "Vector SVG Charts & Live Graphs",
        desc: "Synthesizes advanced Recharts, D3.js, custom HTML Canvas, or interactive SVG diagrams for highly complex metrics visualization",
        divisionId: "frontend",
        divisionName: "Frontend Division",
        divisionType: "frontend",
        systemInstructionSnippet: "Generate dynamic, fully styled SVG charts, heatmaps, interactive node-link diagrams, and smooth canvas visualizers."
      }
    ]
  },
  {
    id: "mobile_pwa",
    name: "📱 Mobile, Touch & PWA Division",
    shortName: "Mobile & PWA",
    type: "mobile_pwa",
    color: "border-pink-500/20 text-pink-400 bg-pink-500/5",
    iconColor: "text-pink-400",
    badgeBg: "bg-pink-500/10 text-pink-400 border-pink-500/20",
    agents: [
      {
        id: "responsive_layout_master",
        name: "Adaptive Viewport & Grid Master",
        role: "Universal Screen Scaler (320px to 4K)",
        desc: "Ensures UI layouts scale flawlessly across small phones, notched displays, foldables, tablets, laptops, and ultra-wide 4K monitors",
        divisionId: "mobile_pwa",
        divisionName: "Mobile, Touch & PWA Division",
        divisionType: "mobile_pwa",
        systemInstructionSnippet: "Apply mobile-first responsive breakpoints (sm, md, lg, xl, 2xl, 3xl), fluid clamp typography, container queries, and zero horizontal scroll overflow."
      },
      {
        id: "mobile_touch_gesture",
        name: "Touch & Gesture Specialist",
        role: "Virtual Joysticks, Swipe & Haptics",
        desc: "Touch targets (min 44px), virtual touch joysticks, swipe cards, pinch-to-zoom, drag drawers, and navigator haptic vibration",
        divisionId: "mobile_pwa",
        divisionName: "Mobile, Touch & PWA Division",
        divisionType: "mobile_pwa",
        systemInstructionSnippet: "Implement touch event listeners (touchstart, touchmove, touchend), virtual joysticks, swipe drawers, and navigator.vibrate() haptic feedback."
      },
      {
        id: "pwa_offline_engine",
        name: "PWA & Offline Service Worker",
        role: "Manifest, Service Worker & Cache",
        desc: "Web App Manifest, service worker cache strategies, install prompts, offline fallback pages, and background sync",
        divisionId: "mobile_pwa",
        divisionName: "Mobile, Touch & PWA Division",
        divisionType: "mobile_pwa",
        systemInstructionSnippet: "Configure manifest.json, service worker caching rules, offline mode fallbacks, and PWA installation prompts."
      },
      {
        id: "cross_platform_architect",
        name: "Native Bridge & Hybrid Architect",
        role: "Capacitor / Mobile Native Interop",
        desc: "Native device API access (camera, accelerometer, GPS, push notifications, storage) and mobile web view optimization",
        divisionId: "mobile_pwa",
        divisionName: "Mobile, Touch & PWA Division",
        divisionType: "mobile_pwa",
        systemInstructionSnippet: "Integrate native device APIs, geolocation, orientation sensors, and camera capture with safe-area inset padding."
      },
      {
        id: "biometric_hardware_core",
        name: "Biometric & Hardware Core Bridge",
        role: "Biometrics & Sensor Stream Specialist",
        desc: "Engineers deep sensor streaming (accelerometer, gyroscope, device motion), camera capture pipelines, and fingerprint/face ID authentication wrappers",
        divisionId: "mobile_pwa",
        divisionName: "Mobile, Touch & PWA Division",
        divisionType: "mobile_pwa",
        systemInstructionSnippet: "Develop robust hardware triggers, gyroscope-driven perspective offsets, biometric verification, and permission guard status checks."
      }
    ]
  },
  {
    id: "backend",
    name: "⚙️ Backend Division",
    shortName: "Backend",
    type: "backend",
    color: "border-emerald-500/20 text-emerald-400 bg-emerald-500/5",
    iconColor: "text-emerald-400",
    badgeBg: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
    agents: [
      {
        id: "be_architect",
        name: "Backend Architect",
        role: "Server Topology & Microservices",
        desc: "Express server topology, proxy routing, middleware stacks, and service isolation",
        divisionId: "backend",
        divisionName: "Backend Division",
        divisionType: "backend",
        systemInstructionSnippet: "Design modular Express.js servers, clean middleware pipelines, error handlers, and route controllers."
      },
      {
        id: "api_agent",
        name: "API Agent",
        role: "REST & Endpoint Validation",
        desc: "REST APIs, payload validation, status codes, and JSON schema serialization",
        divisionId: "backend",
        divisionName: "Backend Division",
        divisionType: "backend",
        systemInstructionSnippet: "Build robust RESTful API endpoints with request validation, structured error JSON responses, and HTTP status code discipline."
      },
      {
        id: "auth_agent",
        name: "Auth Agent",
        role: "Identity, OAuth & Session Tokens",
        desc: "OAuth providers, JWT tokens, secure session cookies, and role-based access control",
        divisionId: "backend",
        divisionName: "Backend Division",
        divisionType: "backend",
        systemInstructionSnippet: "Implement secure authentication flows, JWT verification, OAuth integration, password hashing, and role-based access control."
      },
      {
        id: "db_agent",
        name: "Database Agent",
        role: "SQL Schemas & Query Tuning",
        desc: "PostgreSQL/Firestore schemas, index optimizations, migrations, and transactional integrity",
        divisionId: "backend",
        divisionName: "Backend Division",
        divisionType: "backend",
        systemInstructionSnippet: "Design relational database schemas, indexes, foreign keys, ORM models, and ACID transactional queries."
      },
      {
        id: "business_logic",
        name: "Business Logic Agent",
        role: "Core Application Algorithms",
        desc: "Domain business rules, data transformations, calculations, and transactional workflows",
        divisionId: "backend",
        divisionName: "Backend Division",
        divisionType: "backend",
        systemInstructionSnippet: "Encapsulate complex domain business logic, data validation pipelines, state machines, and calculations."
      },
      {
        id: "background_jobs",
        name: "Background Workers",
        role: "Job Queues & Schedulers",
        desc: "Task queues, cron timers, asynchronous batch workers, and retry handlers",
        divisionId: "backend",
        divisionName: "Backend Division",
        divisionType: "backend",
        systemInstructionSnippet: "Construct asynchronous task queues, cron schedulers, batch processors, and idempotent retry strategies."
      },
      {
        id: "realtime",
        name: "Realtime Agent",
        role: "WebSockets & Event Broadcasts",
        desc: "WebSockets, presence channels, real-time collaboration streams, and socket events",
        divisionId: "backend",
        divisionName: "Backend Division",
        divisionType: "backend",
        systemInstructionSnippet: "Implement WebSocket servers, pub/sub event broadcasting, user presence tracking, and real-time state synchronization."
      },
      {
        id: "graphql_grpc_agent",
        name: "GraphQL & gRPC Gateway",
        role: "Schema Federation & RPC",
        desc: "GraphQL queries/mutations, schema stitchers, gRPC proto buffers, and streaming response handlers",
        divisionId: "backend",
        divisionName: "Backend Division",
        divisionType: "backend",
        systemInstructionSnippet: "Construct GraphQL schemas, resolvers, and high-throughput gRPC service definitions."
      },
      {
        id: "edge_route_specialist",
        name: "Serverless Edge Route Specialist",
        role: "Edge Compute & Low-Latency API",
        desc: "Engineers edge functions (Vercel Edge, Cloudflare Workers) with ultra-low startup latencies, geographic routing, and edge cache control headers",
        divisionId: "backend",
        divisionName: "Backend Division",
        divisionType: "backend",
        systemInstructionSnippet: "Build runtime-agnostic lightweight serverless edge route handlers, leverage key-value edge memory, and fine-tune Cache-Control configurations."
      },
      {
        id: "api_gateway_security",
        name: "Rate-Limiter & API Gateway Hardener",
        role: "Request Filtering & Throttling",
        desc: "Protects backend APIs using token bucket rate limiters, CORS configuration controls, and DDoS mitigation proxies",
        divisionId: "backend",
        divisionName: "Backend Division",
        divisionType: "backend",
        systemInstructionSnippet: "Design resilient rate-limiting middleware, configure safe IP-filtering lists, and structure strict request headers."
      }
    ]
  },
  {
    id: "data_cloud",
    name: "🗄️ Full-Stack Database & Cloud Division",
    shortName: "Data & Cloud",
    type: "data_cloud",
    color: "border-teal-500/20 text-teal-400 bg-teal-500/5",
    iconColor: "text-teal-400",
    badgeBg: "bg-teal-500/10 text-teal-400 border-teal-500/20",
    agents: [
      {
        id: "firestore_realtime_sync",
        name: "Firestore & NoSQL Sync Master",
        role: "Real-time Document Storage & Auth",
        desc: "Firestore collection schemas, document CRUD, real-time onSnapshot listeners, security rules, and Firebase Auth",
        divisionId: "data_cloud",
        divisionName: "Full-Stack Database & Cloud Division",
        divisionType: "data_cloud",
        systemInstructionSnippet: "Configure Firestore collections, real-time document listeners (onSnapshot), offline caching, and security rules."
      },
      {
        id: "sql_schema_orm",
        name: "Relational SQL & ORM Engineer",
        role: "PostgreSQL, Drizzle & Prisma",
        desc: "Relational schemas, migrations, Drizzle ORM queries, foreign key constraints, and transactional consistency",
        divisionId: "data_cloud",
        divisionName: "Full-Stack Database & Cloud Division",
        divisionType: "data_cloud",
        systemInstructionSnippet: "Write type-safe Drizzle ORM schemas, migration scripts, join queries, and PostgreSQL transactions."
      },
      {
        id: "vector_db_architect",
        name: "Vector DB & Embeddings Search",
        role: "Semantic Search & Cosine Distance",
        desc: "pgvector, Pinecone, ChromaDB, vector embedding generation, cosine similarity indexing, and semantic search",
        divisionId: "data_cloud",
        divisionName: "Full-Stack Database & Cloud Division",
        divisionType: "data_cloud",
        systemInstructionSnippet: "Implement vector similarity search, embedding pipelines, HNSW index parameters, and semantic retrieval."
      },
      {
        id: "cloud_storage_media",
        name: "Cloud Media & Storage Pipeline",
        role: "Blob Uploads & Asset Streaming",
        desc: "File uploads, presigned URLs, image compression, chunked video streaming, and CDN cache headers",
        divisionId: "data_cloud",
        divisionName: "Full-Stack Database & Cloud Division",
        divisionType: "data_cloud",
        systemInstructionSnippet: "Build secure cloud media upload handlers, image optimization pipelines, and CDN distribution paths."
      },
      {
        id: "orm_migration_specialist",
        name: "Drizzle & Prisma ORM Schema Architect",
        role: "Database Migrations & Relational Indexes",
        desc: "Automates SQL schema migrations, indices mapping, complex SQL views, and table indexes with Prisma and Drizzle",
        divisionId: "data_cloud",
        divisionName: "Full-Stack Database & Cloud Division",
        divisionType: "data_cloud",
        systemInstructionSnippet: "Generate clean relational database models, index optimization trees, foreign keys mapping, and safe transaction rollbacks."
      },
      {
        id: "redis_cache_sync",
        name: "Redis Cache & Dynamic Lock Manager",
        role: "Memory Key-Value Stores & Mutex Locks",
        desc: "Configures high-speed cache caching, dynamic pub-sub message queues, and resource lock mechanisms to maintain strict backend consistency",
        divisionId: "data_cloud",
        divisionName: "Full-Stack Database & Cloud Division",
        divisionType: "data_cloud",
        systemInstructionSnippet: "Design efficient Redis key structures, cache invalidation schemes, and lock acquisitions to coordinate concurrent worker tasks."
      }
    ]
  },
  {
    id: "ai_div",
    name: "🤖 AI Division",
    shortName: "AI Core",
    type: "ai",
    color: "border-purple-500/20 text-purple-400 bg-purple-500/5",
    iconColor: "text-purple-400",
    badgeBg: "bg-purple-500/10 text-purple-400 border-purple-500/20",
    agents: [
      {
        id: "ai_architect",
        name: "AI Architect",
        role: "Model Topology & Token Stream",
        desc: "Orchestrates multi-model token flow, context windows, and model fallbacks",
        divisionId: "ai_div",
        divisionName: "AI Division",
        divisionType: "ai",
        systemInstructionSnippet: "Orchestrate multi-model AI workflows, context management, streaming responses, and structured output parsing."
      },
      {
        id: "model_agent",
        name: "Model Selector",
        role: "Dynamic Weights Routing",
        desc: "Routes prompts to optimal models (Gemini Flash, Gemini Pro, Anthropic, Qwen, Ollama)",
        divisionId: "ai_div",
        divisionName: "AI Division",
        divisionType: "ai",
        systemInstructionSnippet: "Dynamically select optimal models based on latency, reasoning depth, token context, and capability requirements."
      },
      {
        id: "prompt_engineer",
        name: "Prompt Engineer",
        role: "System Directives & Few-Shot Reasoning",
        desc: "System instruction refinement, few-shot examples, and structured JSON output schemas",
        divisionId: "ai_div",
        divisionName: "AI Division",
        divisionType: "ai",
        systemInstructionSnippet: "Craft high-precision system prompts, few-shot reasoning chains, structured output schemas, and zero-shot directives."
      },
      {
        id: "rag_agent",
        name: "RAG & Memory Agent",
        role: "Vector Embeddings & Context Retrieval",
        desc: "Vector embeddings, cosine similarity search, chunking, and semantic memory recall",
        divisionId: "ai_div",
        divisionName: "AI Division",
        divisionType: "ai",
        systemInstructionSnippet: "Implement Retrieval-Augmented Generation (RAG), chunking strategies, vector memory stores, and semantic recall."
      },
      {
        id: "ai_tool_agent",
        name: "AI Tool Smith",
        role: "Grounding & Execution Tools",
        desc: "Google Search grounding tools, image generation dispatch, and terminal tool execution",
        divisionId: "ai_div",
        divisionName: "AI Division",
        divisionType: "ai",
        systemInstructionSnippet: "Integrate real-time Google Search grounding, image generation tools, and code execution environments."
      },
      {
        id: "ai_cost",
        name: "Token Optimizer",
        role: "Compaction & Cache Pruning",
        desc: "Context compaction, semantic token pruning, and prompt cache hit rate optimization",
        divisionId: "ai_div",
        divisionName: "AI Division",
        divisionType: "ai",
        systemInstructionSnippet: "Optimize token consumption, prune redundant context, summarize history, and maximize cache efficiency."
      },
      {
        id: "deep_research_agent",
        name: "Deep Research & Web Crawler",
        role: "Multi-Source Knowledge Synthesis",
        desc: "Autonomous multi-step research, web scraping, documentation verification, and factual cross-referencing",
        divisionId: "ai_div",
        divisionName: "AI Division",
        divisionType: "ai",
        systemInstructionSnippet: "Conduct multi-step autonomous research, fetch live API documentation, verify technical specs, and synthesize knowledge."
      },
      {
        id: "multimodal_vision",
        name: "Multimodal Vision Agent",
        role: "Visual UI & Screen Understanding",
        desc: "Analyzes UI screenshots, visual mockups, wireframes, and design references into pixel-perfect layout code",
        divisionId: "ai_div",
        divisionName: "AI Division",
        divisionType: "ai",
        systemInstructionSnippet: "Deconstruct UI screenshots, mockups, and visual assets into precise HTML/Tailwind/React layout structures."
      },
      {
        id: "omni_interactions_agent",
        name: "Google Interactions API & Omni Flash Orchestrator",
        role: "Omni-Model Streams & Agent Orchestration",
        desc: "Orchestrates Gemini Omni models using high-performance server-side streaming and advanced system instruction mappings",
        divisionId: "ai_div",
        divisionName: "AI Division",
        divisionType: "ai",
        systemInstructionSnippet: "Execute specialized interactions via the Omni-channel API, injecting precise prompt parameters and structuring real-time response nodes."
      },
      {
        id: "speech_vocalizer_agent",
        name: "Web Audio TTS & Speech Vocalizer",
        role: "Speech Synthesis & Mouth Animation Mapping",
        desc: "Synthesizes real-time text-to-speech feedback using Web Audio API voice engines and maps mouth movement indices for animated avatar overlays",
        divisionId: "ai_div",
        divisionName: "AI Division",
        divisionType: "ai",
        systemInstructionSnippet: "Synthesize vocal patterns with client-side SpeechSynthesis or Web Audio API nodes, providing synchronous gesture timing maps."
      }
    ]
  },
  {
    id: "algorithms_perf",
    name: "⚡ Algorithms & Performance Division",
    shortName: "Algorithms & Perf",
    type: "algorithms_perf",
    color: "border-yellow-500/20 text-yellow-400 bg-yellow-500/5",
    iconColor: "text-yellow-400",
    badgeBg: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20",
    agents: [
      {
        id: "dsa_math_master",
        name: "DSA & Linear Algebra Master",
        role: "High-Order Math & Complex Algorithms",
        desc: "Matrix transformations, quaternion rotations, graph traversal, spatial partitioning (Octree/BVH), and sorting algorithms",
        divisionId: "algorithms_perf",
        divisionName: "Algorithms & Performance Division",
        divisionType: "algorithms_perf",
        systemInstructionSnippet: "Implement optimal O(N log N) / O(1) algorithms, linear algebra matrix operations, spatial hashing, and graph traversals."
      },
      {
        id: "memory_garbage_profiler",
        name: "Zero-GC Memory Profiler",
        role: "Object Pooling & Allocation Elimination",
        desc: "Eliminates garbage collection pauses via typed array buffers, object pooling, reusable vector instances, and memory profiling",
        divisionId: "algorithms_perf",
        divisionName: "Algorithms & Performance Division",
        divisionType: "algorithms_perf",
        systemInstructionSnippet: "Eliminate runtime garbage collection hitches by employing object pools, TypedArrays (Float32Array), and static memory allocation."
      },
      {
        id: "web_worker_multithread",
        name: "Web Worker Multi-Threader",
        role: "Background Thread Offloading",
        desc: "Offloads heavy physics computations, procedural generation, and data parsing to Web Workers and SharedArrayBuffer",
        divisionId: "algorithms_perf",
        divisionName: "Algorithms & Performance Division",
        divisionType: "algorithms_perf",
        systemInstructionSnippet: "Construct worker thread pools, postMessage transferrable objects, and OffscreenCanvas background rendering."
      },
      {
        id: "webgpu_compute_agent",
        name: "WebGPU Shader & GPGPU Parallel Compute Agent",
        role: "WGSL Pipelines & Parallel Compute",
        desc: "Engineers high-performance WebGPU execution contexts, WGSL compute shaders, render pipelines, and uniform/storage buffer structures",
        divisionId: "algorithms_perf",
        divisionName: "Algorithms & Performance Division",
        divisionType: "algorithms_perf",
        systemInstructionSnippet: "Initialize GPUDevices, construct pipeline states, write WGSL compute modules for matrix-matrix or particle simulations, and manage storage buffer bindings."
      },
      {
        id: "binary_serialization",
        name: "Bitwise Memory & Serialization Specialist",
        role: "ArrayBuffer Layouts & Custom Binary Protocols",
        desc: "Optimizes network payload footprints and file systems using custom ArrayBuffer schemas, bitwise flag masking, and direct Uint8Array packing",
        divisionId: "algorithms_perf",
        divisionName: "Algorithms & Performance Division",
        divisionType: "algorithms_perf",
        systemInstructionSnippet: "Pack and unpack primitive values inside custom dynamic ArrayBuffers using DataViews, optimize bit shifts, and minimize serialization overhead."
      }
    ]
  },
  {
    id: "testing",
    name: "🧪 Testing & Security",
    shortName: "QA & Security",
    type: "testing",
    color: "border-red-500/20 text-red-400 bg-red-500/5",
    iconColor: "text-red-400",
    badgeBg: "bg-red-500/10 text-red-400 border-red-500/20",
    agents: [
      {
        id: "unit_tester",
        name: "Unit Test Agent",
        role: "Unit & Function Validation",
        desc: "Writes isolated function test cases, edge condition checks, and mocking suites",
        divisionId: "testing",
        divisionName: "Testing & Security",
        divisionType: "testing",
        systemInstructionSnippet: "Write comprehensive unit tests, edge case assertions, mock fixtures, and boundary tests."
      },
      {
        id: "e2e_tester",
        name: "E2E Agent",
        role: "User Journey & Interaction Flow",
        desc: "Simulates user interactions, button clicks, form submissions, and error boundary states",
        divisionId: "testing",
        divisionName: "Testing & Security",
        divisionType: "testing",
        systemInstructionSnippet: "Design end-to-end user interaction test flows, form entry scenarios, and state transition assertions."
      },
      {
        id: "regression",
        name: "Regression Agent",
        role: "Baseline Integrity & Stability",
        desc: "Verifies existing core features and layout stability after modifications",
        divisionId: "testing",
        divisionName: "Testing & Security",
        divisionType: "testing",
        systemInstructionSnippet: "Ensure non-breaking code changes, verify functional backward compatibility, and protect existing features."
      },
      {
        id: "security_auditor",
        name: "Security Auditor",
        role: "Vulnerability & XSS Prevention",
        desc: "Audits input sanitization, XSS, CSRF, insecure endpoints, and auth headers",
        divisionId: "testing",
        divisionName: "Testing & Security",
        divisionType: "testing",
        systemInstructionSnippet: "Audit input sanitization, prevent XSS/SQL injection/CSRF vulnerabilities, and enforce secure HTTP headers."
      },
      {
        id: "secrets_finder",
        name: "Secrets Agent",
        role: "Credential Leak Prevention",
        desc: "Scans for leaked API keys, tokens, hardcoded passwords, and sensitive environment variables",
        divisionId: "testing",
        divisionName: "Testing & Security",
        divisionType: "testing",
        systemInstructionSnippet: "Detect and prevent hardcoded secret leaks, API keys, or unencrypted token credentials in client code."
      },
      {
        id: "chaos_load_tester",
        name: "Chaos & Stress Tester",
        role: "Resilience & Load Testing",
        desc: "Simulates network latency drops, corrupt payloads, high concurrency spikes, and memory leak degradation",
        divisionId: "testing",
        divisionName: "Testing & Security",
        divisionType: "testing",
        systemInstructionSnippet: "Test app resilience against simulated network failures, high data loads, offline transitions, and unexpected inputs."
      }
    ]
  },
  {
    id: "devops",
    name: "🚀 DevOps & Debugging",
    shortName: "DevOps",
    type: "devops",
    color: "border-orange-500/20 text-orange-400 bg-orange-500/5",
    iconColor: "text-orange-400",
    badgeBg: "bg-orange-500/10 text-orange-400 border-orange-500/20",
    agents: [
      {
        id: "build_agent",
        name: "Build Agent",
        role: "Vite & Bundle Compilation",
        desc: "Vite build configuration, esbuild bundling, source maps, and tree-shaking verification",
        divisionId: "devops",
        divisionName: "DevOps & Debugging",
        divisionType: "devops",
        systemInstructionSnippet: "Configure Vite build pipelines, bundling, module imports, and production asset optimization."
      },
      {
        id: "error_analyzer",
        name: "Error Analyzer",
        role: "Log & Stack Trace Parsing",
        desc: "Parses compiler diagnostics, runtime console exceptions, and stack traces",
        divisionId: "devops",
        divisionName: "DevOps & Debugging",
        divisionType: "devops",
        systemInstructionSnippet: "Parse compiler diagnostics, runtime stack traces, unhandled exceptions, and console warnings."
      },
      {
        id: "root_cause",
        name: "Root Cause Agent",
        role: "Diagnostic Localization",
        desc: "Traces runtime errors back to precise source file lines and erroneous state mutations",
        divisionId: "devops",
        divisionName: "DevOps & Debugging",
        divisionType: "devops",
        systemInstructionSnippet: "Trace bugs back to exact source file lines, unhandled async promises, or bad state mutations."
      },
      {
        id: "fix_agent",
        name: "Fix Agent",
        role: "Automated Code Repair",
        desc: "Applies targeted search/replace patches to resolve build errors and runtime crashes",
        divisionId: "devops",
        divisionName: "DevOps & Debugging",
        divisionType: "devops",
        systemInstructionSnippet: "Synthesize targeted, bug-free surgical code patches to resolve runtime crashes or compiler errors instantly."
      },
      {
        id: "ci_cd_pipeline",
        name: "Deployment & Container Specialist",
        role: "Cloud Run, Docker & GitHub Actions",
        desc: "Dockerfile optimizations, Cloud Run container setup, environment variable binding, and continuous integration",
        divisionId: "devops",
        divisionName: "DevOps & Debugging",
        divisionType: "devops",
        systemInstructionSnippet: "Optimize Dockerfiles, Cloud Run deployment manifests, container builds, and CI/CD pipelines."
      }
    ]
  },
  {
    id: "intelligence",
    name: "🗃️ Codebase Intel & Docs",
    shortName: "Code Intel",
    type: "intelligence",
    color: "border-blue-500/20 text-blue-400 bg-blue-500/5",
    iconColor: "text-blue-400",
    badgeBg: "bg-blue-500/10 text-blue-400 border-blue-500/20",
    agents: [
      {
        id: "repo_mapper",
        name: "Repository Mapper",
        role: "Workspace File Graph Indexer",
        desc: "Maintains real-time project file tree, import graphs, and exported symbols index",
        divisionId: "intelligence",
        divisionName: "Codebase Intel & Docs",
        divisionType: "intelligence",
        systemInstructionSnippet: "Map project file trees, module dependencies, export symbol graphs, and directory hierarchies."
      },
      {
        id: "code_search",
        name: "Code Search",
        role: "Semantic & Regex Symbol Search",
        desc: "Performs fast search across workspace files for symbols, function definitions, and hooks",
        divisionId: "intelligence",
        divisionName: "Codebase Intel & Docs",
        divisionType: "intelligence",
        systemInstructionSnippet: "Locate symbols, hook usages, type definitions, and variable references across the codebase."
      },
      {
        id: "refactoring",
        name: "Refactoring Agent",
        role: "Architecture Extraction & Cleanup",
        desc: "Extracts reusable hooks, decomposes large components, and cleans up dead imports",
        divisionId: "intelligence",
        divisionName: "Codebase Intel & Docs",
        divisionType: "intelligence",
        systemInstructionSnippet: "Decompose monolithic files into clean modular components, extract custom React hooks, and eliminate dead imports."
      },
      {
        id: "docs_agent",
        name: "Doc Generator",
        role: "JSDoc & Technical Markdown",
        desc: "Generates comprehensive documentation, component prop tables, and setup guides",
        divisionId: "intelligence",
        divisionName: "Codebase Intel & Docs",
        divisionType: "intelligence",
        systemInstructionSnippet: "Generate JSDoc type annotations, clear README guides, component API prop tables, and architecture diagrams."
      },
      {
        id: "ast_parser_agent",
        name: "AST & Syntax Structural Parser",
        role: "Abstract Syntax Tree Transformation",
        desc: "Transforms code via AST manipulations, codemods, and syntax tree verification",
        divisionId: "intelligence",
        divisionName: "Codebase Intel & Docs",
        divisionType: "intelligence",
        systemInstructionSnippet: "Analyze and manipulate Abstract Syntax Trees (AST) for precise codemod transformations and structural validation."
      },
      {
        id: "long_form_codebase_specialist",
        name: "Enterprise Long Coding Architect",
        role: "High-Capacity Multi-Module Synthesis (1k-10k+ Lines)",
        desc: "Architects long, enterprise-scale codebases (1,000 to 10,000+ lines) across clean modular files with zero truncation and zero stub comments",
        divisionId: "intelligence",
        divisionName: "Codebase Intel & Docs",
        divisionType: "intelligence",
        systemInstructionSnippet: "Decompose massive requests (1,000 to 10,000+ lines of code) into modular multi-file architectures (`src/components/`, `src/services/`, `src/engine/`, `src/types.ts`). MANDATE: Zero stub comments (`// ... rest of code`), 100% complete type-safe code, and surgical SEARCH/REPLACE diffs for large files."
      }
    ]
  }
];

// Expanded comprehensive keywords
const LONG_CODING_KEYWORDS_REGEX = /\b(1k|2k|3k|5k|10k|1000|2000|5000|10000|10k\s*lines|long\s*coding|large\s*codebase|long\s*code|massive\s*app|enterprise\s*app|enterprise\s*system|complete\s*architecture|multi-module|heavy\s*code)\b/i;

const GAME_KEYWORDS_REGEX = /\b(game|games|gaming|gameplay|gameloop|three\.?js|threejs|webgl|webgpu|mesh|meshes|geometry|geometries|material|materials|shader|shaders|glsl|skybox|fps|rpg|platformer|space shooter|racing|racer|car|cars|drift|steering|speedometer|wasd|joystick|jump|jumping|gravity|physics engine|rigid\s*body|collision|collider|colliders|hitbox|raycast|raycasting|spawner|respawn|enemy|enemies|boss|bosses|npc|health\s*bar|hp|ammo|gun|guns|weapon|weapons|sword|swords|laser|lasers|bullet|bullets|shield|scoreboard|high\s*score|stage|wave|waves|sfx|synth\s*sound|retro\s*sound|game\s*audio|arcade|arcade\s*game|voxel|voxels|terrain|procedural\s*terrain|heightmap|screenshake|particle\s*system|flight\s*sim|simulator|space\s*game|dungeon|roguelike|tower\s*defense|flappy|pong|snake\s*game|tetris|pacman|breakout|asteroids|pinball|endless\s*runner|stealth|battle\s*royale|arena|inventory|loot|game\s*over|gameover|play\s*screen|start\s*game|restart\s*game|pause\s*menu|orbitcontrols|camera\s*follow|render\s*loop|requestanimationframe|game\s*canvas|canvas\s*game|webxr|vr|ar|spatial\s*audio)\b/i;

const REALTIME_COLLAB_KEYWORDS_REGEX = /\b(collaborative|collaboration|real-time|realtime|live\s*editing|live\s*sync|multi-user|multiuser|pair\s*programming|code\s*editor|shared\s*canvas|yjs|socket\.io|webrtc|broadcast\s*channel|presence|cursor\s*sharing|cursor\s*sync)\b/i;

const MOBILE_TOUCH_KEYWORDS_REGEX = /\b(mobile|responsive|adaptive|phone|tablet|screen|viewport|breakpoint|touch|gesture|joystick|swipe|haptic|vibration|pwa|service\s*worker|manifest|offline|native|capacitor|foldable|orientation|portrait|landscape|touch\s*target|touch-action)\b/i;

const DATA_CLOUD_KEYWORDS_REGEX = /\b(firestore|firebase|nosql|document|collection|on snapshot|on-snapshot|sql|postgres|postgresql|drizzle|prisma|orm|migration|vector|vector\s*db|embeddings|pinecone|chroma|pgvector|cosine|blob|s3|cloud\s*storage|presigned|media\s*pipeline)\b/i;

const ALGO_PERF_KEYWORDS_REGEX = /\b(algorithm|dsa|matrix|quaternion|octree|bvh|spatial\s*partition|object\s*pool|garbage\s*collection|typedarray|float32array|worker|web\s*worker|multithread|thread|offscreen\s*canvas|performance|benchmark|profiler)\b/i;

const WEB_KEYWORDS_REGEX = /\b(react|tailwind|css|component|components|navbar|sidebar|dashboard|card|cards|modal|form|forms|login|signup|auth|oauth|jwt|database|sql|postgres|api|rest|graphql|backend|server|express|route|endpoint|page|layout|table|dropdown|button|input|seo|wcag|aria|saas|landing\s*page|checkout|stripe|ecommerce|blog|portfolio)\b/i;

export interface IntentClassificationResult {
  mode: 'game' | 'web' | 'backend_ai' | 'mobile_pwa' | 'data_cloud' | 'algorithms_perf';
  divisionName: string;
  divisionId: string;
  confidence: number;
  reason: string;
  spawnedAgents: string[];
  isGame: boolean;
  activeDivisions?: OrchestratorDivision[];
}

export const DIVISION_MENTION_MAP: Record<string, { divisionId: string; name: string; mode: 'game' | 'web' | 'backend_ai' | 'mobile_pwa' | 'data_cloud' | 'algorithms_perf'; isGame: boolean }> = {
  "all": { divisionId: "all", name: "⚡ Full Swarm Orchestration (All 10 Divisions)", mode: "web", isGame: false },
  "swarm": { divisionId: "all", name: "⚡ Full Swarm Orchestration (All 10 Divisions)", mode: "web", isGame: false },
  "full_swarm": { divisionId: "all", name: "⚡ Full Swarm Orchestration (All 10 Divisions)", mode: "web", isGame: false },
  "all_agents": { divisionId: "all", name: "⚡ Full Swarm Orchestration (All 10 Divisions)", mode: "web", isGame: false },

  "game": { divisionId: "game_spec", name: "🎮 3D & 2D Game Division", mode: "game", isGame: true },
  "game_spec": { divisionId: "game_spec", name: "🎮 3D & 2D Game Division", mode: "game", isGame: true },
  "games": { divisionId: "game_spec", name: "🎮 3D & 2D Game Division", mode: "game", isGame: true },
  "gamedev": { divisionId: "game_spec", name: "🎮 3D & 2D Game Division", mode: "game", isGame: true },
  "3d": { divisionId: "game_spec", name: "🎮 3D & 2D Game Division", mode: "game", isGame: true },

  "frontend": { divisionId: "frontend", name: "🎨 Frontend & UI/UX Division", mode: "web", isGame: false },
  "fe": { divisionId: "frontend", name: "🎨 Frontend & UI/UX Division", mode: "web", isGame: false },
  "ui": { divisionId: "frontend", name: "🎨 Frontend & UI/UX Division", mode: "web", isGame: false },
  "ui_ux": { divisionId: "frontend", name: "🎨 Frontend & UI/UX Division", mode: "web", isGame: false },
  "web": { divisionId: "frontend", name: "🎨 Frontend & UI/UX Division", mode: "web", isGame: false },

  "mobile": { divisionId: "mobile_pwa", name: "📱 Mobile, Touch & PWA Division", mode: "mobile_pwa", isGame: false },
  "mobile_pwa": { divisionId: "mobile_pwa", name: "📱 Mobile, Touch & PWA Division", mode: "mobile_pwa", isGame: false },
  "pwa": { divisionId: "mobile_pwa", name: "📱 Mobile, Touch & PWA Division", mode: "mobile_pwa", isGame: false },

  "backend": { divisionId: "backend", name: "⚙️ Backend & API Systems Division", mode: "backend_ai", isGame: false },
  "be": { divisionId: "backend", name: "⚙️ Backend & API Systems Division", mode: "backend_ai", isGame: false },
  "server": { divisionId: "backend", name: "⚙️ Backend & API Systems Division", mode: "backend_ai", isGame: false },
  "api": { divisionId: "backend", name: "⚙️ Backend & API Systems Division", mode: "backend_ai", isGame: false },

  "data_cloud": { divisionId: "data_cloud", name: "🗄️ Full-Stack Database & Cloud Sync Division", mode: "data_cloud", isGame: false },
  "data": { divisionId: "data_cloud", name: "🗄️ Full-Stack Database & Cloud Sync Division", mode: "data_cloud", isGame: false },
  "database": { divisionId: "data_cloud", name: "🗄️ Full-Stack Database & Cloud Sync Division", mode: "data_cloud", isGame: false },
  "db": { divisionId: "data_cloud", name: "🗄️ Full-Stack Database & Cloud Sync Division", mode: "data_cloud", isGame: false },
  "cloud": { divisionId: "data_cloud", name: "🗄️ Full-Stack Database & Cloud Sync Division", mode: "data_cloud", isGame: false },
  "firestore": { divisionId: "data_cloud", name: "🗄️ Full-Stack Database & Cloud Sync Division", mode: "data_cloud", isGame: false },

  "ai": { divisionId: "ai_div", name: "🤖 AI Core & Intelligence Division", mode: "backend_ai", isGame: false },
  "ai_div": { divisionId: "ai_div", name: "🤖 AI Core & Intelligence Division", mode: "backend_ai", isGame: false },
  "ml": { divisionId: "ai_div", name: "🤖 AI Core & Intelligence Division", mode: "backend_ai", isGame: false },
  "gemini": { divisionId: "ai_div", name: "🤖 AI Core & Intelligence Division", mode: "backend_ai", isGame: false },
  "llm": { divisionId: "ai_div", name: "🤖 AI Core & Intelligence Division", mode: "backend_ai", isGame: false },

  "algorithms_perf": { divisionId: "algorithms_perf", name: "⚡ High-Performance Algorithms & Memory Division", mode: "algorithms_perf", isGame: false },
  "perf": { divisionId: "algorithms_perf", name: "⚡ High-Performance Algorithms & Memory Division", mode: "algorithms_perf", isGame: false },
  "algo": { divisionId: "algorithms_perf", name: "⚡ High-Performance Algorithms & Memory Division", mode: "algorithms_perf", isGame: false },
  "performance": { divisionId: "algorithms_perf", name: "⚡ High-Performance Algorithms & Memory Division", mode: "algorithms_perf", isGame: false },

  "testing": { divisionId: "testing", name: "🛡️ Automated Testing & Security Division", mode: "web", isGame: false },
  "test": { divisionId: "testing", name: "🛡️ Automated Testing & Security Division", mode: "web", isGame: false },
  "qa": { divisionId: "testing", name: "🛡️ Automated Testing & Security Division", mode: "web", isGame: false },
  "security": { divisionId: "testing", name: "🛡️ Automated Testing & Security Division", mode: "web", isGame: false },

  "devops": { divisionId: "devops", name: "🚀 DevOps & Diagnostic Repair Division", mode: "web", isGame: false },
  "ci_cd": { divisionId: "devops", name: "🚀 DevOps & Diagnostic Repair Division", mode: "web", isGame: false },
  "repair": { divisionId: "devops", name: "🚀 DevOps & Diagnostic Repair Division", mode: "web", isGame: false },
  "fix": { divisionId: "devops", name: "🚀 DevOps & Diagnostic Repair Division", mode: "web", isGame: false },

  "intelligence": { divisionId: "intelligence", name: "🧠 Enterprise Long Coding & Codebase Architect Division", mode: "web", isGame: false },
  "codebase": { divisionId: "intelligence", name: "🧠 Enterprise Long Coding & Codebase Architect Division", mode: "web", isGame: false },
  "arch": { divisionId: "intelligence", name: "🧠 Enterprise Long Coding & Codebase Architect Division", mode: "web", isGame: false },
  "refactor": { divisionId: "intelligence", name: "🧠 Enterprise Long Coding & Codebase Architect Division", mode: "web", isGame: false },
};

export function resolveIntentsByGoal(fullMsg: string): string[] {
  const targets: string[] = [];
  const text = fullMsg.toLowerCase();

  // Support explicit @division, @all, or @agent_id notation
  const mentionMatches = text.match(/@([a-zA-Z0-9_\-]+)/g);
  if (mentionMatches) {
    const allAgentIds = [
      "three_js", "game_modeler", "game_architect", "game_ui", "game_audio", "game_director", "shader_vfx", "multiplayer_netcode", "vr_ar_spatial", "webgl_gpu_fluid", "pbr_material_architect",
      "multipage_architect", "ui_ux", "react_core", "styling", "components_core", "accessibility", "fe_performance", "micro_frontend", "theme_design_tokens", "bento_grid_designer", "d3_chart_visualizer",
      "responsive_layout_master", "mobile_touch_gesture", "pwa_offline_engine", "cross_platform_architect", "biometric_hardware_core",
      "be_architect", "api_agent", "auth_agent", "db_agent", "business_logic", "background_jobs", "realtime", "graphql_grpc_agent", "edge_route_specialist", "api_gateway_security",
      "firestore_realtime_sync", "sql_schema_orm", "vector_db_architect", "cloud_storage_media", "orm_migration_specialist", "redis_cache_sync",
      "ai_architect", "model_agent", "prompt_engineer", "rag_agent", "ai_tool_agent", "ai_cost", "deep_research_agent", "multimodal_vision", "omni_interactions_agent", "speech_vocalizer_agent",
      "dsa_math_master", "memory_garbage_profiler", "web_worker_multithread", "webgpu_compute_agent", "binary_serialization",
      "unit_tester", "e2e_tester", "regression", "security_auditor", "secrets_finder", "chaos_load_tester",
      "build_agent", "error_analyzer", "root_cause", "fix_agent", "ci_cd_pipeline",
      "repo_mapper", "code_search", "refactoring", "docs_agent", "ast_parser_agent", "long_form_codebase_specialist"
    ];

    for (const match of mentionMatches) {
      const parsedId = match.substring(1).replace(/-/g, '_').toLowerCase();
      
      // 1. Check if it's a whole division mention
      if (DIVISION_MENTION_MAP[parsedId]) {
        const divInfo = DIVISION_MENTION_MAP[parsedId];
        if (divInfo.divisionId === "all") {
          // Spawn all agents across all divisions!
          targets.push(...allAgentIds);
        } else {
          const div = ORCHESTRATOR_DIVISIONS.find(d => d.id === divInfo.divisionId);
          if (div) {
            targets.push(...div.agents.map(a => a.id));
          }
        }
      } else if (allAgentIds.includes(parsedId)) {
        // 2. Individual sub-agent mention
        targets.push(parsedId);
      }
    }
  }

  const matchesIntent = (patterns: { verbs?: string[], nouns: string[] }[]) => {
    return patterns.some(p => {
      const hasNoun = p.nouns.some(n => text.includes(n));
      if (!hasNoun) return false;
      if (p.verbs && p.verbs.length > 0) {
        return p.verbs.some(v => text.includes(v));
      }
      return true;
    });
  };

  if (matchesIntent([
    { verbs: ["arrange", "organize", "display", "layout", "grid", "bento", "dashboard"], nouns: ["widgets", "cards", "panels", "bento", "dashboard", "metric", "overview", "layout"] },
    { nouns: ["bento grid", "dashboard grid", "layout blocks", "visual widget group"] }
  ])) {
    targets.push("bento_grid_designer");
  }

  if (matchesIntent([
    { verbs: ["plot", "graph", "visualize", "draw", "chart", "analyze", "render"], nouns: ["data", "statistics", "metrics", "chart", "graph", "d3", "svg", "trends", "progress", "values"] },
    { nouns: ["d3 chart", "bar chart", "line graph", "svg plot", "scatter diagram", "pie chart"] }
  ])) {
    targets.push("d3_chart_visualizer");
  }

  if (matchesIntent([
    { verbs: ["access", "track", "read", "detect", "query", "scan", "authenticate"], nouns: ["gyro", "accelerometer", "biometric", "hardware", "fingerprint", "faceid", "sensor", "touchid"] },
    { nouns: ["device orientation", "hardware sensory", "motion tracker", "biometric secure scanning"] }
  ])) {
    targets.push("biometric_hardware_core");
  }

  if (matchesIntent([
    { verbs: ["deploy", "run", "route", "dispatch", "proxy"], nouns: ["serverless", "edge", "worker", "cloudflare", "microservice", "lambda", "functions"] },
    { nouns: ["edge routing", "cloudflare workers", "serverless api path", "low latency compute"] }
  ])) {
    targets.push("edge_route_specialist");
  }

  if (matchesIntent([
    { verbs: ["secure", "limit", "prevent", "control", "throttle", "protect", "filter"], nouns: ["rate limit", "ddos", "cors", "gatekeeper", "api gateway", "request flood", "endpoint attack", "throttling"] },
    { nouns: ["rate limiting", "cors policy", "ddos prevention", "api gateway security"] }
  ])) {
    targets.push("api_gateway_security");
  }

  if (matchesIntent([
    { verbs: ["map", "define", "sync", "generate", "seed", "migrate"], nouns: ["schema", "migration", "prisma", "drizzle", "database tables", "orm", "entity models"] },
    { nouns: ["db migration", "drizzle schema", "prisma model", "database seeding"] }
  ])) {
    targets.push("orm_migration_specialist");
  }

  if (matchesIntent([
    { verbs: ["cache", "store", "sync", "lock", "speed up"], nouns: ["redis", "mutex", "distributed state", "fast lookup", "caching", "in-memory session"] },
    { nouns: ["redis caching", "distributed lock", "mutex lock", "session cache"] }
  ])) {
    targets.push("redis_cache_sync");
  }

  if (matchesIntent([
    { verbs: ["chat", "stream", "talk", "interact"], nouns: ["omni", "multimodal", "realtime stream", "gemini-flash", "multi-channel"] },
    { nouns: ["omni interactions", "multimodal chatbot", "real-time stream interaction"] }
  ])) {
    targets.push("omni_interactions_agent");
  }

  if (matchesIntent([
    { verbs: ["speak", "vocalize", "synthesize", "pronounce", "narrate", "read aloud"], nouns: ["voice", "speech", "tts", "avatar", "text to speech", "vocal playback"] },
    { nouns: ["speech synthesizer", "tts voice rendering", "audio dialogue player"] }
  ])) {
    targets.push("speech_vocalizer_agent");
  }

  if (matchesIntent([
    { verbs: ["compute", "calculate", "process", "harness", "train"], nouns: ["webgpu", "wgsl", "gpgpu", "gpu matrix", "hardware acceleration", "tensor math"] },
    { nouns: ["webgpu compute shader", "hardware accelerated logic", "gpgpu computation pipeline"] }
  ])) {
    targets.push("webgpu_compute_agent");
  }

  if (matchesIntent([
    { verbs: ["pack", "unpack", "encode", "decode", "serialize", "parse"], nouns: ["binary", "buffer", "arraybuffer", "uint8array", "bitwise", "memory layout"] },
    { nouns: ["binary serialization", "uint8array arraybuffer", "bitwise buffer operations"] }
  ])) {
    targets.push("binary_serialization");
  }

  if (matchesIntent([
    { verbs: ["simulate", "render", "calculate", "display"], nouns: ["fluid", "particles", "liquid", "smoke", "velocity field", "density physics"] },
    { nouns: ["liquid fluid simulation", "smoke particle dynamics", "density field physics"] }
  ])) {
    targets.push("webgl_gpu_fluid");
  }

  if (matchesIntent([
    { verbs: ["render", "apply", "create", "load"], nouns: ["pbr", "material", "roughness", "metallic", "glsl", "normal texture", "3d shader"] },
    { nouns: ["physically based rendering", "metallic roughness material", "glsl shader textures"] }
  ])) {
    targets.push("pbr_material_architect");
  }

  // --- GAME DIVISION AGENT TRIGGERS ---
  if (matchesIntent([
    { verbs: ["render", "initialize", "setup", "create", "import", "build", "add"], nouns: ["three.js", "threejs", "webgl", "orbitcontrols", "perspectivecamera", "3d scene", "3d rendering"] },
    { nouns: ["three.js scene", "perspectivecamera", "orbitcontrols camera", "webgl canvas renderer"] }
  ])) {
    targets.push("three_js");
  }
  if (matchesIntent([
    { verbs: ["generate", "model", "build", "create", "loft", "synthesize"], nouns: ["3d mesh", "mesh geometry", "vertex buffer", "heightmap terrain", "procedural 3d"] },
    { nouns: ["procedural 3d assets", "heightmap terrain generation", "mesh vertices"] }
  ])) {
    targets.push("game_modeler");
  }
  if (matchesIntent([
    { verbs: ["implement", "calculate", "detect", "add", "setup", "simulate"], nouns: ["physics collision", "rigid body physics", "collider checks", "gravity simulation", "wasd keyboard controls"] },
    { nouns: ["wasd key controls", "bounding box collision", "gravity simulation logic"] }
  ])) {
    targets.push("game_architect");
  }
  if (matchesIntent([
    { verbs: ["design", "draw", "render", "create", "overlay"], nouns: ["hud dashboard", "game overlay HUD", "score counter dashboard", "game-over screen", "minimap canvas"] },
    { nouns: ["game head up display", "canvas HUD overlay", "minimap rendering", "game over screen overlay"] }
  ])) {
    targets.push("game_ui");
  }
  if (matchesIntent([
    { verbs: ["synthesize", "generate", "play", "hook up", "beep", "trigger"], nouns: ["sound effect", "sfx sound", "game audio music", "web audio synthesizer", "audio oscillator", "gain curve audio"] },
    { nouns: ["dynamic sfx synthesizer", "web audio oscillator engine", "sound effect synth"] }
  ])) {
    targets.push("game_audio");
  }
  if (matchesIntent([
    { verbs: ["orchestrate", "program", "design", "write", "setup"], nouns: ["pygame game loop", "gameplay logic engine", "enemy wave spawner", "scoring win condition", "game state transition"] },
    { nouns: ["pygame application file", "game loop requestanimationframe", "wave spawning system"] }
  ])) {
    targets.push("game_director");
  }
  if (matchesIntent([
    { verbs: ["render", "program", "write", "create", "add"], nouns: ["glsl shader vfx", "particle explosion blast", "camera screenshake trauma", "bloom post processing", "thruster visual trail"] },
    { nouns: ["custom glsl vertex shader", "particle emitter physics", "camera trauma shake matrix"] }
  ])) {
    targets.push("shader_vfx");
  }
  if (matchesIntent([
    { verbs: ["sync", "connect", "broadcast", "implement", "create"], nouns: ["multiplayer lobby", "socket.io netcode", "webrtc peer connection", "matchmaking queue", "client side prediction"] },
    { nouns: ["multiplayer socket syncer", "webrtc stream sync", "lobby matchmaking system"] }
  ])) {
    targets.push("multiplayer_netcode");
  }
  if (matchesIntent([
    { verbs: ["initialize", "setup", "enable", "track"], nouns: ["webxr vr session", "augmented reality overlay", "spatial audio 3d panning", "hand tracking controllers"] },
    { nouns: ["immersive vr experience", "spatial 3d audio system", "webxr controller trackers"] }
  ])) {
    targets.push("vr_ar_spatial");
  }

  // --- FRONTEND DIVISION AGENT TRIGGERS ---
  if (matchesIntent([
    { verbs: ["architect", "structure", "create", "set up", "design"], nouns: ["multi-page site", "route navigation links", "physical directory folders", "pages structure pages/", "router routes configuration"] },
    { nouns: ["multi page application framework", "react router paths layout", "physical folder structures"] }
  ])) {
    targets.push("multipage_architect");
  }
  if (matchesIntent([
    { verbs: ["design", "polish", "beautify", "craft", "harmonize"], nouns: ["ui/ux design principles", "color harmony theme", "typography scale scale", "wcag contrast compliance", "premium design system rules"] },
    { nouns: ["ui/ux design framework", "color palette harmony system", "contrast ratio accessibility checker"] }
  ])) {
    targets.push("ui_ux");
  }
  if (matchesIntent([
    { verbs: ["write", "refactor", "implement", "debug"], nouns: ["react hooks lifecycle", "useeffect dependency arrays", "usestate immutable state", "context api global state", "state manager reducer"] },
    { nouns: ["react functional component tree", "hook lifecycle management", "custom react hook system"] }
  ])) {
    targets.push("react_core");
  }
  if (matchesIntent([
    { verbs: ["style", "beautify", "animate", "configure"], nouns: ["tailwind utilities css", "framer motion transitions", "css layouts animations", "glassmorphic blur layers", "aesthetic gradients background"] },
    { nouns: ["tailwind class list", "framer motion transitions animation", "css transition layout classes"] }
  ])) {
    targets.push("styling");
  }
  if (matchesIntent([
    { verbs: ["build", "create", "implement", "add", "render"], nouns: ["interactive dropdown menu", "popup modal dialog", "form input collection", "responsive navbar layout", "bento card widget grid"] },
    { nouns: ["dropdown components ui", "form submit fields", "interactive navigation bar"] }
  ])) {
    targets.push("components_core");
  }
  if (matchesIntent([
    { verbs: ["ensure", "verify", "audit", "implement"], nouns: ["aria attributes", "accessibility wcag compliance", "keyboard navigation focus", "screen reader tag labels"] },
    { nouns: ["accessibility audit compliance", "screen reader labels standard"] }
  ])) {
    targets.push("accessibility");
  }
  if (matchesIntent([
    { verbs: ["optimize", "boost", "speed up", "profile"], nouns: ["render performance", "lazy loading bundles", "render debouncing optimization", "virtualized list virtualization"] },
    { nouns: ["frontend bundle optimization", "virtualized scrolling renderer"] }
  ])) {
    targets.push("fe_performance");
  }
  if (matchesIntent([
    { verbs: ["configure", "federate", "integrate"], nouns: ["micro-frontends module", "module federation framework", "federated bundles module"] },
    { nouns: ["micro frontend module federator", "federated architecture setup"] }
  ])) {
    targets.push("micro_frontend");
  }
  if (matchesIntent([
    { verbs: ["implement", "add", "switch", "support"], nouns: ["dark mode light theme", "design tokens swapper", "custom color palettes"] },
    { nouns: ["dark mode theme swapper", "design tokens css variables"] }
  ])) {
    targets.push("theme_design_tokens");
  }

  // --- MOBILE / PWA DIVISION AGENT TRIGGERS ---
  if (matchesIntent([
    { verbs: ["design", "adapt", "make", "fix", "arrange"], nouns: ["responsive viewport layout", "adaptive mobile breakpoint", "fluid screen grids", "fluid flexbox viewport layout"] },
    { nouns: ["mobile responsive layout grid", "viewport scaling breakpoints"] }
  ])) {
    targets.push("responsive_layout_master");
  }
  if (matchesIntent([
    { verbs: ["track", "listen", "detect", "add"], nouns: ["touch gestures swipe", "pinch zoom gesture", "virtual mobile joystick", "haptic tap feedback"] },
    { nouns: ["mobile pinch zoom gesture tracker", "virtual touch joystick control"] }
  ])) {
    targets.push("mobile_touch_gesture");
  }
  if (matchesIntent([
    { verbs: ["configure", "register", "install"], nouns: ["pwa service worker", "manifest caching manifest", "offline cache resource manager"] },
    { nouns: ["progressive web application service worker", "offline mode offline support"] }
  ])) {
    targets.push("pwa_offline_engine");
  }
  if (text.includes("capacitor") || text.includes("cordova") || text.includes("orientation sensor")) {
    targets.push("cross_platform_architect");
  }

  // --- BACKEND DIVISION AGENT TRIGGERS ---
  if (matchesIntent([
    { verbs: ["architect", "build", "launch", "mount", "create"], nouns: ["express server backend", "express middleware chain", "backend system pipeline", "express router routing paths"] },
    { nouns: ["express.js backend server api", "backend routes middleware pipeline"] }
  ])) {
    targets.push("be_architect");
  }
  if (matchesIntent([
    { verbs: ["define", "consume", "validate", "create", "mock"], nouns: ["rest api endpoints", "json api routing payload", "incoming request fields", "http status codes response"] },
    { nouns: ["restful api endpoints paths", "request schema payload validator"] }
  ])) {
    targets.push("api_agent");
  }
  if (matchesIntent([
    { verbs: ["configure", "secure", "implement", "set up", "setup"], nouns: ["jwt auth tokens", "login sign-in page", "signup user registration", "oauth credentials flow", "password hashing salts"] },
    { nouns: ["json web token authentication", "oauth login secure cookies"] }
  ])) {
    targets.push("auth_agent");
  }
  if (matchesIntent([
    { verbs: ["query", "connect", "store", "seed", "create"], nouns: ["relational sql database", "postgresql server tables", "firestore document collection", "database tables relations", "acid transaction queries"] },
    { nouns: ["postgresql database schema data", "firestore cloud collection database"] }
  ])) {
    targets.push("db_agent");
  }
  if (text.includes("business logic") || text.includes("state machine")) {
    targets.push("business_logic");
  }
  if (text.includes("background worker") || text.includes("cron job") || text.includes("batch processor")) {
    targets.push("background_jobs");
  }
  if (text.includes("websockets") || text.includes("socket.io") || text.includes("presence channel")) {
    targets.push("realtime");
  }

  // --- DATA CLOUD DIVISION AGENT TRIGGERS ---
  if (matchesIntent([
    { verbs: ["sync", "subscribe", "listen", "stream"], nouns: ["firestore onsnapshot realtime", "cloud firestore real-time synchronizer", "nosql reactive database sync"] },
    { nouns: ["realtime database onsnapshot listener", "firestore reactive state synchronization"] }
  ])) {
    targets.push("firestore_realtime_sync");
  }
  if (text.includes("drizzle") || text.includes("prisma") || text.includes("relational database")) {
    targets.push("sql_schema_orm");
  }
  if (text.includes("vector db") || text.includes("pinecone") || text.includes("embeddings")) {
    targets.push("vector_db_architect");
  }
  if (text.includes("cloud storage") || text.includes("presigned url")) {
    targets.push("cloud_storage_media");
  }

  // --- AI DIVISION AGENT TRIGGERS ---
  if (matchesIntent([
    { verbs: ["integrate", "connect", "architect", "invoke"], nouns: ["gemini multi-model flow", "ai prompt orchestration", "llm context windows tokens", "ai api request pipeline"] },
    { nouns: ["ai core engine architect", "gemini llm orchestration flow"] }
  ])) {
    targets.push("ai_architect");
  }
  if (text.includes("model selector") || text.includes("ollama")) {
    targets.push("model_agent");
  }
  if (text.includes("prompt engineering") || text.includes("json output schema")) {
    targets.push("prompt_engineer");
  }
  if (text.includes("rag") || text.includes("semantic memory")) {
    targets.push("rag_agent");
  }
  if (text.includes("grounding tool") || text.includes("search grounding")) {
    targets.push("ai_tool_agent");
  }
  if (text.includes("token optimizer") || text.includes("cache pruning")) {
    targets.push("ai_cost");
  }
  if (text.includes("deep research") || text.includes("crawler")) {
    targets.push("deep_research_agent");
  }
  if (text.includes("screen understanding") || text.includes("ui screenshots")) {
    targets.push("multimodal_vision");
  }

  // Return unique targets gathered from all matches
  return Array.from(new Set(targets));
}

export function classifyIntentAndDivision(
  currentPrompt: string = "",
  previousPrompt: string = "",
  allCombinedPrompts: string = "",
  files: FileNode[] = [],
  manualScope: 'AUTO' | 'FORCE_GAME' | 'FORCE_WEB' | 'FORCE_BACKEND_AI' | 'MANUAL' = 'AUTO',
  manualSelectedAgents: string[] = []
): IntentClassificationResult {
  const currentMsg = currentPrompt.trim().toLowerCase();
  const prevMsg = previousPrompt.trim().toLowerCase();
  const fullMsg = (currentPrompt + " " + previousPrompt + " " + allCombinedPrompts).toLowerCase();

  // 1. Manual Scope Overrides
  if (manualScope === 'MANUAL' && manualSelectedAgents.length > 0) {
    const hasGame = manualSelectedAgents.some(id => id.startsWith('game_') || id === 'three_js' || id === 'shader_vfx' || id === 'multiplayer_netcode' || id === 'vr_ar_spatial');
    return {
      mode: hasGame ? 'game' : 'web',
      divisionName: hasGame ? '🎮 3D & 2D Game Division' : '⚡ Web & App Division',
      divisionId: hasGame ? 'game_spec' : 'frontend',
      confidence: 1.0,
      reason: "Manual Override Active: Custom user-selected sub-agent pool applied.",
      spawnedAgents: manualSelectedAgents,
      isGame: hasGame
    };
  }

  let result: IntentClassificationResult;

  if (manualScope === 'FORCE_GAME') {
    result = {
      mode: 'game',
      divisionName: '🎮 3D & 2D Game Division',
      divisionId: 'game_spec',
      confidence: 1.0,
      reason: "User Lock: Orchestrator pinned strictly to 3D & 2D Game Development Division.",
      spawnedAgents: ["three_js", "game_modeler", "game_architect", "game_ui", "game_audio", "game_director", "shader_vfx", "multiplayer_netcode", "vr_ar_spatial"],
      isGame: true
    };
  } else if (manualScope === 'FORCE_WEB') {
    result = {
      mode: 'web',
      divisionName: '⚡ Web Application Division',
      divisionId: 'frontend',
      confidence: 1.0,
      reason: "User Lock: Orchestrator pinned strictly to Full-Stack Web Development Division.",
      spawnedAgents: ["ui_ux", "react_core", "styling", "components_core", "responsive_layout_master", "api_agent", "unit_tester", "refactoring"],
      isGame: false
    };
  } else if (manualScope === 'FORCE_BACKEND_AI') {
    result = {
      mode: 'backend_ai',
      divisionName: '⚙️ Backend Systems & AI Core Division',
      divisionId: 'backend',
      confidence: 1.0,
      reason: "User Lock: Orchestrator pinned strictly to Backend & AI Division.",
      spawnedAgents: ["be_architect", "api_agent", "db_agent", "auth_agent", "ai_architect", "ai_tool_agent", "security_auditor", "firestore_realtime_sync"],
      isGame: false
    };
  } else {
    // 2. Automated Smart Intent Classification (AUTO)
    // Direct @division or @all swarm invocation override
    const directMentions = (currentMsg.match(/@([a-zA-Z0-9_\-]+)/g) || []).map(m => m.substring(1).replace(/-/g, '_').toLowerCase());
    const explicitDivisions = directMentions.filter(m => !!DIVISION_MENTION_MAP[m]);

    if (explicitDivisions.length > 0) {
      const allMentionedAgents: string[] = [];
      let primaryDivInfo = DIVISION_MENTION_MAP[explicitDivisions[0]];
      let isAnyGame = false;
      const divisionNames: string[] = [];

      for (const divKey of explicitDivisions) {
        const divInfo = DIVISION_MENTION_MAP[divKey];
        if (divInfo.divisionId === "all") {
          allMentionedAgents.push(...ORCHESTRATOR_DIVISIONS.flatMap(d => d.agents.map(a => a.id)));
          divisionNames.push("⚡ Full Swarm (All 10 Divisions)");
        } else {
          const div = ORCHESTRATOR_DIVISIONS.find(d => d.id === divInfo.divisionId);
          if (div) {
            allMentionedAgents.push(...div.agents.map(a => a.id));
            divisionNames.push(div.name);
          }
          if (divInfo.isGame) isAnyGame = true;
        }
      }

      const uniqueMentionedAgents = Array.from(new Set(allMentionedAgents));

      result = {
        mode: isAnyGame ? 'game' : primaryDivInfo.mode,
        divisionName: divisionNames.join(" + "),
        divisionId: primaryDivInfo.divisionId,
        confidence: 1.0,
        reason: `🎯 Direct @mention override: Spawning entire division action [${divisionNames.join(", ")}] with ${uniqueMentionedAgents.length} specialized sub-agents.`,
        spawnedAgents: uniqueMentionedAgents,
        isGame: isAnyGame
      };
    } else {
      const isLongCodingMatch = LONG_CODING_KEYWORDS_REGEX.test(currentMsg) || LONG_CODING_KEYWORDS_REGEX.test(fullMsg);
    const isRealtimeCollabMatch = REALTIME_COLLAB_KEYWORDS_REGEX.test(currentMsg);
    const isCurrentGameMatch = GAME_KEYWORDS_REGEX.test(currentMsg) && !isRealtimeCollabMatch;
    const isPrevGameMatch = GAME_KEYWORDS_REGEX.test(prevMsg) && !isRealtimeCollabMatch;
    const isMobileTouchMatch = MOBILE_TOUCH_KEYWORDS_REGEX.test(currentMsg);
    const isDataCloudMatch = DATA_CLOUD_KEYWORDS_REGEX.test(currentMsg);
    const isAlgoPerfMatch = ALGO_PERF_KEYWORDS_REGEX.test(currentMsg);

    // Check workspace files for explicit 3D/2D game engine indicators
    const hasGameFilesInWorkspace = files.some(f => {
      const name = f.name.toLowerCase();
      const content = (f.content || "").toLowerCase();
      return (
        name.includes("three") ||
        name.includes("gamecanvas") ||
        content.includes("three.js") ||
        content.includes("three.perspectivecamera") ||
        content.includes("<canvas id=\"gamecanvas\"") ||
        content.includes("new three.scene")
      );
    });

    const isFollowUpTweak = (
      currentMsg.length < 75 ||
      currentMsg.includes("more") ||
      currentMsg.includes("add") ||
      currentMsg.includes("fix") ||
      currentMsg.includes("improve") ||
      currentMsg.includes("faster") ||
      currentMsg.includes("color") ||
      currentMsg.includes("styling") ||
      currentMsg.includes("controls") ||
      currentMsg.includes("sound") ||
      currentMsg.includes("play") ||
      currentMsg.includes("score") ||
      currentMsg.includes("run") ||
      currentMsg.includes("make it") ||
      currentMsg.includes("adaptive") ||
      currentMsg.includes("responsive")
    );

    let isGame = false;
    let confidence = 0.85;
    let reason = "";

    if (isCurrentGameMatch) {
      isGame = true;
      confidence = 0.98;
      reason = "Target prompt matched 3D/2D game development domain keywords (physics, WebGL, controls, audio, or game mechanics).";
    } else if (isPrevGameMatch && isFollowUpTweak) {
      isGame = true;
      confidence = 0.92;
      reason = "Context recall: Previous turn was Game Development and current prompt is a game feature extension / tweak.";
    } else if (hasGameFilesInWorkspace && isFollowUpTweak && !WEB_KEYWORDS_REGEX.test(currentMsg) && !isRealtimeCollabMatch) {
      isGame = true;
      confidence = 0.88;
      reason = "Workspace context: Active project structure contains 3D/2D Game Engine and canvas render loop.";
    } else {
      isGame = false;
      confidence = 0.90;
      reason = "Standard full-stack web, SaaS, mobile layout, and cloud application development scope.";
    }

    // Determine active agent pool based on classification
    let spawnedAgents: string[] = [];

    if (isLongCodingMatch) {
      spawnedAgents = ["long_form_codebase_specialist", "refactoring"];
      result = {
        mode: 'web',
        divisionName: '🧠 Enterprise Long Coding & Codebase Architect Division',
        divisionId: 'intelligence',
        confidence: 0.99,
        reason: "Prompt requests enterprise-scale multi-module synthesis (1,000 to 10,000+ lines of code) with modular file decomposition and zero truncation.",
        spawnedAgents,
        isGame: false
      };
    } else if (isGame) {
      spawnedAgents = ["game_director", "game_architect"];
      result = {
        mode: 'game',
        divisionName: '🎮 3D & 2D Game Division',
        divisionId: 'game_spec',
        confidence,
        reason,
        spawnedAgents,
        isGame: true
      };
    } else if (isRealtimeCollabMatch) {
      spawnedAgents = ["firestore_realtime_sync", "react_core"];
      result = {
        mode: 'data_cloud',
        divisionName: '🔄 Real-Time Collaboration & Shared State Division',
        divisionId: 'data_cloud',
        confidence: 0.98,
        reason: "Prompt requests real-time multi-user collaboration, live code editing, shared canvas/board state, or presence synchronization.",
        spawnedAgents,
        isGame: false
      };
    } else if (isMobileTouchMatch) {
      spawnedAgents = ["responsive_layout_master", "mobile_touch_gesture"];
      result = {
        mode: 'mobile_pwa',
        divisionName: '📱 Mobile, Touch & Adaptive Viewport Division',
        divisionId: 'mobile_pwa',
        confidence: 0.96,
        reason: "Prompt targets adaptive viewports, mobile touch gestures, responsive breakpoints, or PWA capabilities.",
        spawnedAgents,
        isGame: false
      };
    } else if (isDataCloudMatch) {
      spawnedAgents = ["firestore_realtime_sync", "sql_schema_orm"];
      result = {
        mode: 'data_cloud',
        divisionName: '🗄️ Full-Stack Database & Cloud Sync Division',
        divisionId: 'data_cloud',
        confidence: 0.97,
        reason: "Prompt requests cloud database persistence, Firestore/SQL schemas, real-time listeners, or vector storage.",
        spawnedAgents,
        isGame: false
      };
    } else if (isAlgoPerfMatch) {
      spawnedAgents = ["dsa_math_master", "fe_performance"];
      result = {
        mode: 'algorithms_perf',
        divisionName: '⚡ High-Performance Algorithms & Memory Division',
        divisionId: 'algorithms_perf',
        confidence: 0.95,
        reason: "Prompt targets mathematical algorithms, memory profiling, zero-GC loops, or multi-threading.",
        spawnedAgents,
        isGame: false
      };
    } else if (
      currentMsg.includes("multi-page") ||
      currentMsg.includes("multipage") ||
      currentMsg.includes("multiple page") ||
      currentMsg.includes("multi page") ||
      currentMsg.includes("folder") ||
      currentMsg.includes("directory") ||
      currentMsg.includes("directories") ||
      currentMsg.includes("router") ||
      currentMsg.includes("routing") ||
      currentMsg.includes("subpage") ||
      currentMsg.includes("pages") ||
      currentMsg.includes("navbar") ||
      currentMsg.includes("navigation bar") ||
      currentMsg.includes("hierarchy")
    ) {
      spawnedAgents = ["multipage_architect", "react_core"];
      result = {
        mode: 'web',
        divisionName: '🌐 Multi-Page Web & Directory Architect Division',
        divisionId: 'frontend',
        confidence: 0.98,
        reason: "Prompt targets modular multi-page architecture, routing hierarchies, and physical directory structures (pages/, components/, routes/).",
        spawnedAgents,
        isGame: false
      };
    } else if (
      currentMsg.includes("bug") ||
      currentMsg.includes("fix") ||
      currentMsg.includes("error") ||
      currentMsg.includes("broken") ||
      currentMsg.includes("fail") ||
      currentMsg.includes("crash") ||
      prevMsg.includes("error")
    ) {
      spawnedAgents = ["error_analyzer", "fix_agent"];
      result = {
        mode: 'web',
        divisionName: '🚀 DevOps & Diagnostic Repair Division',
        divisionId: 'devops',
        confidence: 0.94,
        reason: "Prompt requires diagnostic error analysis and surgical bug remediation.",
        spawnedAgents,
        isGame: false
      };
    } else if (
      currentMsg.includes("db") ||
      currentMsg.includes("database") ||
      currentMsg.includes("sql") ||
      currentMsg.includes("postgres") ||
      currentMsg.includes("auth") ||
      currentMsg.includes("login") ||
      currentMsg.includes("api") ||
      currentMsg.includes("endpoint") ||
      currentMsg.includes("backend")
    ) {
      spawnedAgents = ["be_architect", "db_agent"];
      result = {
        mode: 'backend_ai',
        divisionName: '⚙️ Backend Systems Division',
        divisionId: 'backend',
        confidence: 0.95,
        reason: "Prompt targets server-side API endpoints, databases, and authentication schemas.",
        spawnedAgents,
        isGame: false
      };
    } else if (
      currentMsg.includes("ai") ||
      currentMsg.includes("model") ||
      currentMsg.includes("gemini") ||
      currentMsg.includes("rag") ||
      currentMsg.includes("embeddings") ||
      currentMsg.includes("prompt") ||
      currentMsg.includes("token") ||
      currentMsg.includes("deep research")
    ) {
      spawnedAgents = ["ai_architect", "prompt_engineer"];
      result = {
        mode: 'backend_ai',
        divisionName: '🤖 AI Core & Intelligence Division',
        divisionId: 'ai_div',
        confidence: 0.96,
        reason: "Prompt requests AI reasoning models, RAG vector context, vision understanding, or tool smithing.",
        spawnedAgents,
        isGame: false
      };
    } else if (
      currentMsg.includes("style") ||
      currentMsg.includes("css") ||
      currentMsg.includes("tailwind") ||
      currentMsg.includes("design") ||
      currentMsg.includes("beautiful") ||
      currentMsg.includes("animation") ||
      currentMsg.includes("theme") ||
      currentMsg.includes("color") ||
      currentMsg.includes("adaptive") ||
      currentMsg.includes("screen")
    ) {
      spawnedAgents = ["ui_ux", "styling"];
      result = {
        mode: 'web',
        divisionName: '🎨 Frontend & Responsive UI/UX Styling Division',
        divisionId: 'frontend',
        confidence: 0.93,
        reason: "Prompt requires UI styling polish, motion transitions, adaptive layouts, and visual harmony.",
        spawnedAgents,
        isGame: false
      };
    } else {
      spawnedAgents = ["react_core", "styling"];
      result = {
        mode: 'web',
        divisionName: '⚡ Universal Full-Stack Web & App Division',
        divisionId: 'frontend',
        confidence,
        reason,
        spawnedAgents,
        isGame: false
      };
    }
    }

    // Dynamic Cross-Division Intelligent Activation (Cross-Pollenization)
    const extraAgents: string[] = [];
    const localContext = (currentMsg + " " + prevMsg).trim();

    // Check for 3D elements requested inside a web application using localContext
    if (result.mode !== 'game') {
      const hasThreeJsKeywords = /\b(three\.?js|threejs|webgl|perspectivecamera|scene|mesh|orbitcontrols|3d\s*model|3d\s*box|cube|geometry)\b/i.test(localContext);
      if (hasThreeJsKeywords) {
        extraAgents.push("three_js");
      }
    }

    // Check for mobile/responsive needs in any mode using localContext
    const hasResponsiveKeywords = /\b(mobile|responsive|adaptive|screen|viewport|touch|gesture|pwa|device)\b/i.test(localContext);
    if (hasResponsiveKeywords && !result.spawnedAgents.includes("responsive_layout_master")) {
      extraAgents.push("responsive_layout_master");
    }

    // Check for sound / sfx in any mode using localContext
    const hasAudioKeywords = /\b(sfx|audio|sound|music|synthesizer|synth|oscillator|soundtrack)\b/i.test(localContext);
    if (hasAudioKeywords) {
      extraAgents.push("game_audio");
    }

    // Check for shader/visual effects in any mode using localContext
    const hasShaderKeywords = /\b(shader|shaders|particle|particles|explosion|vfx|visual\s*effects|bloom|glow)\b/i.test(localContext);
    if (hasShaderKeywords) {
      extraAgents.push("shader_vfx");
    }

    // Check for database, backend, or auth needs in frontend/game modes using localContext
    if (result.mode !== 'backend_ai' && result.mode !== 'data_cloud') {
      const hasDbKeywords = /\b(db|database|firestore|sql|postgres|schema|datastore)\b/i.test(localContext);
      if (hasDbKeywords) {
        extraAgents.push("db_agent");
      }
      const hasBeKeywords = /\b(api|endpoint|server|express|route|backend)\b/i.test(localContext);
      if (hasBeKeywords) {
        extraAgents.push("api_agent");
      }
      const hasAuthKeywords = /\b(auth|login|signup|jwt|oauth|session|security)\b/i.test(localContext);
      if (hasAuthKeywords) {
        extraAgents.push("auth_agent");
      }
    }

    // Check for AI needs in general modes using localContext
    const hasAiKeywords = /\b(ai|model|gemini|rag|embeddings|chatgpt|openai|llama|intelligent|smart)\b/i.test(localContext);
    if (hasAiKeywords) {
      extraAgents.push("ai_architect");
    }

    // 12 Specialized Sub-Agents Intent-Driven Selection
    const intentAgents = resolveIntentsByGoal(localContext);
    extraAgents.push(...intentAgents);

    // If we have extra dynamic agents, merge them and update the reason
    if (extraAgents.length > 0) {
      const uniqueExtra = extraAgents.filter(id => !result.spawnedAgents.includes(id));
      if (uniqueExtra.length > 0) {
        result.spawnedAgents = [...result.spawnedAgents, ...uniqueExtra];
        result.reason += ` 🧠 Unified Cross-Domain Activation: Dynamically loaded specialized ${uniqueExtra.map(id => id.replace('_', ' ').toUpperCase()).join(', ')} sub-agent(s) to assist with hybrid requirements.`;
      }
    }
  }

  // Merge any manually selected / toggled overrides directly in any mode
  if (manualSelectedAgents.length > 0) {
    const originalCount = result.spawnedAgents.length;
    result.spawnedAgents = Array.from(new Set([...result.spawnedAgents, ...manualSelectedAgents]));
    if (result.spawnedAgents.length > originalCount) {
      result.reason += ` ⚡ Manual overrides merged: user-selected agents forced active in pool.`;
    }
  }

  // Dynamically resolve all unique divisions that own the spawned agents to support multi-division swarming
  const uniqueDivIds = new Set<string>();
  const activeDivisions: OrchestratorDivision[] = [];
  
  for (const agentId of result.spawnedAgents) {
    for (const div of ORCHESTRATOR_DIVISIONS) {
      if (div.agents.some(a => a.id === agentId)) {
        if (!uniqueDivIds.has(div.id)) {
          uniqueDivIds.add(div.id);
          activeDivisions.push(div);
        }
        break;
      }
    }
  }
  result.activeDivisions = activeDivisions;

  return result;
}
