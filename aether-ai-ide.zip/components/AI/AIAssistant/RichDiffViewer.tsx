import React, { useState, useMemo } from "react";
import {
  FileCode,
  Check,
  Copy,
  RotateCcw,
  Columns,
  AlignLeft,
  ChevronRight,
  FilePlus,
  FileEdit,
  FileX,
  Maximize2,
  Minimize2,
  ArrowRight,
  SplitSquareVertical,
  Layers,
  Scissors
} from "lucide-react";
import type { FileChange } from "../../../services/versionControlService";

interface RichDiffViewerProps {
  changes: FileChange[];
  onRestoreSingleFile?: (filePath: string) => Promise<void> | void;
  className?: string;
}

interface DiffLine {
  type: "added" | "deleted" | "unchanged" | "hunk";
  oldLineNumber?: number;
  newLineNumber?: number;
  text: string;
}

interface SplitDiffRow {
  left?: {
    lineNumber?: number;
    text: string;
    type: "deleted" | "unchanged";
  };
  right?: {
    lineNumber?: number;
    text: string;
    type: "added" | "unchanged";
  };
}

/**
 * Compute line-by-line diff using simple LCS algorithm
 */
function computeDiff(oldText: string = "", newText: string = ""): DiffLine[] {
  const oldLines = oldText ? oldText.split("\n") : [];
  const newLines = newText ? newText.split("\n") : [];

  if (oldLines.length === 0 && newLines.length === 0) {
    return [];
  }

  if (oldLines.length === 0) {
    return newLines.map((line, idx) => ({
      type: "added",
      newLineNumber: idx + 1,
      text: line,
    }));
  }

  if (newLines.length === 0) {
    return oldLines.map((line, idx) => ({
      type: "deleted",
      oldLineNumber: idx + 1,
      text: line,
    }));
  }

  // LCS Matrix for exact line matching
  const m = oldLines.length;
  const n = newLines.length;

  // Optimize for large files (if too many lines, fallback to fast prefix/suffix diff)
  if (m * n > 400000) {
    const lines: DiffLine[] = [];
    oldLines.forEach((l, i) => lines.push({ type: "deleted", oldLineNumber: i + 1, text: l }));
    newLines.forEach((l, i) => lines.push({ type: "added", newLineNumber: i + 1, text: l }));
    return lines;
  }

  const dp: number[][] = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (oldLines[i - 1] === newLines[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1] + 1;
      } else {
        dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
      }
    }
  }

  const diffResult: DiffLine[] = [];
  let i = m;
  let j = n;

  const stack: DiffLine[] = [];
  let oldNum = m;
  let newNum = n;

  while (i > 0 || j > 0) {
    if (i > 0 && j > 0 && oldLines[i - 1] === newLines[j - 1]) {
      stack.push({
        type: "unchanged",
        oldLineNumber: i,
        newLineNumber: j,
        text: oldLines[i - 1],
      });
      i--;
      j--;
    } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
      stack.push({
        type: "added",
        newLineNumber: j,
        text: newLines[j - 1],
      });
      j--;
    } else if (i > 0 && (j === 0 || dp[i][j - 1] < dp[i - 1][j])) {
      stack.push({
        type: "deleted",
        oldLineNumber: i,
        text: oldLines[i - 1],
      });
      i--;
    }
  }

  return stack.reverse();
}

/**
 * Build Side-by-side rows from unified diff lines
 */
function buildSplitRows(diffLines: DiffLine[]): SplitDiffRow[] {
  const rows: SplitDiffRow[] = [];
  let i = 0;

  while (i < diffLines.length) {
    const current = diffLines[i];

    if (current.type === "unchanged") {
      rows.push({
        left: {
          lineNumber: current.oldLineNumber,
          text: current.text,
          type: "unchanged",
        },
        right: {
          lineNumber: current.newLineNumber,
          text: current.text,
          type: "unchanged",
        },
      });
      i++;
    } else if (current.type === "deleted") {
      // Gather consecutive deletes and consecutive adds to align them
      const deletes: DiffLine[] = [];
      while (i < diffLines.length && diffLines[i].type === "deleted") {
        deletes.push(diffLines[i]);
        i++;
      }
      const adds: DiffLine[] = [];
      while (i < diffLines.length && diffLines[i].type === "added") {
        adds.push(diffLines[i]);
        i++;
      }

      const maxLen = Math.max(deletes.length, adds.length);
      for (let k = 0; k < maxLen; k++) {
        const d = deletes[k];
        const a = adds[k];
        rows.push({
          left: d
            ? {
                lineNumber: d.oldLineNumber,
                text: d.text,
                type: "deleted",
              }
            : undefined,
          right: a
            ? {
                lineNumber: a.newLineNumber,
                text: a.text,
                type: "added",
              }
            : undefined,
        });
      }
    } else if (current.type === "added") {
      rows.push({
        right: {
          lineNumber: current.newLineNumber,
          text: current.text,
          type: "added",
        },
      });
      i++;
    } else {
      i++;
    }
  }

  return rows;
}

export const RichDiffViewer: React.FC<RichDiffViewerProps> = ({
  changes,
  onRestoreSingleFile,
  className = "",
}) => {
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [viewMode, setViewMode] = useState<"unified" | "split">("unified");
  const [copiedDiff, setCopiedDiff] = useState(false);
  const [copiedNewCode, setCopiedNewCode] = useState(false);
  const [restoringFile, setRestoringFile] = useState<string | null>(null);

  const activeChange: FileChange | undefined = changes[selectedFileIndex] || changes[0];

  const diffLines = useMemo(() => {
    if (!activeChange) return [];
    return computeDiff(activeChange.oldContent || activeChange.previousContent || "", activeChange.newContent || "");
  }, [activeChange]);

  const splitRows = useMemo(() => {
    if (viewMode !== "split") return [];
    return buildSplitRows(diffLines);
  }, [diffLines, viewMode]);

  const handleCopyDiff = () => {
    if (!activeChange) return;
    const rawDiff = diffLines
      .map((l) => {
        const prefix = l.type === "added" ? "+" : l.type === "deleted" ? "-" : " ";
        return `${prefix} ${l.text}`;
      })
      .join("\n");
    navigator.clipboard.writeText(rawDiff);
    setCopiedDiff(true);
    setTimeout(() => setCopiedDiff(false), 2000);
  };

  const handleCopyNewCode = () => {
    if (!activeChange?.newContent) return;
    navigator.clipboard.writeText(activeChange.newContent);
    setCopiedNewCode(true);
    setTimeout(() => setCopiedNewCode(false), 2000);
  };

  const handleRestoreFile = async (path: string) => {
    if (!onRestoreSingleFile) return;
    setRestoringFile(path);
    try {
      await onRestoreSingleFile(path);
    } finally {
      setTimeout(() => setRestoringFile(null), 1500);
    }
  };

  if (!changes || changes.length === 0) {
    return (
      <div className="p-4 text-center text-xs font-mono text-white/40 bg-black/30 rounded-xl border border-white/5">
        No code diff changes available for this checkpoint.
      </div>
    );
  }

  return (
    <div className={`rounded-xl border border-white/10 bg-[#090a0f] overflow-hidden shadow-2xl flex flex-col ${className}`}>
      {/* Top File Selector Strip & Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-3 py-2 bg-white/[0.03] border-b border-white/10 text-xs font-mono select-none">
        {/* File Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto max-w-full pb-0.5">
          {changes.map((ch, idx) => {
            const isSelected = idx === selectedFileIndex;
            const statusIcon =
              ch.status === "added" ? (
                <FilePlus size={12} className="text-emerald-400" />
              ) : ch.status === "deleted" ? (
                <FileX size={12} className="text-rose-400" />
              ) : (
                <FileEdit size={12} className="text-amber-400" />
              );

            return (
              <button
                key={idx}
                onClick={() => setSelectedFileIndex(idx)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-mono transition-all cursor-pointer whitespace-nowrap ${
                  isSelected
                    ? "bg-white/15 text-white font-semibold border border-white/15 shadow-sm"
                    : "bg-white/5 text-white/60 hover:text-white hover:bg-white/10 border border-transparent"
                }`}
                title={ch.path}
              >
                {statusIcon}
                <span className="truncate max-w-[150px]">{ch.path.split("/").pop() || ch.path}</span>
                <span className="text-[9px] text-white/40 ml-0.5">
                  <span className="text-emerald-400">+{ch.additions}</span>
                  <span className="text-rose-400 ml-0.5">-{ch.deletions}</span>
                </span>
              </button>
            );
          })}
        </div>

        {/* Diff Display Controls */}
        <div className="flex items-center gap-1.5 ml-auto">
          {/* View Mode Toggle: Unified vs Split */}
          <div className="flex items-center bg-black/40 p-0.5 rounded-lg border border-white/5">
            <button
              onClick={() => setViewMode("unified")}
              className={`px-2 py-0.5 rounded text-[10px] font-mono flex items-center gap-1 transition-all ${
                viewMode === "unified"
                  ? "bg-white/20 text-white font-bold shadow-sm"
                  : "text-white/40 hover:text-white"
              }`}
              title="Unified Diff View"
            >
              <AlignLeft size={11} />
              <span>Unified</span>
            </button>
            <button
              onClick={() => setViewMode("split")}
              className={`px-2 py-0.5 rounded text-[10px] font-mono flex items-center gap-1 transition-all ${
                viewMode === "split"
                  ? "bg-white/20 text-white font-bold shadow-sm"
                  : "text-white/40 hover:text-white"
              }`}
              title="Side-by-side Split Diff View"
            >
              <Columns size={11} />
              <span>Split</span>
            </button>
          </div>

          {/* Copy Diff Button */}
          <button
            onClick={handleCopyDiff}
            className="px-2 py-1 rounded-lg text-[10px] font-mono bg-white/5 hover:bg-white/10 text-white/70 hover:text-white border border-white/5 flex items-center gap-1 transition-all cursor-pointer"
            title="Copy patch diff"
          >
            {copiedDiff ? <Check size={11} className="text-emerald-400" /> : <Copy size={11} />}
            <span className="hidden sm:inline">{copiedDiff ? "Copied" : "Copy Diff"}</span>
          </button>

          {/* Restore Single File Button */}
          {onRestoreSingleFile && activeChange && (
            <button
              onClick={() => handleRestoreFile(activeChange.path)}
              disabled={restoringFile === activeChange.path}
              className="px-2.5 py-1 rounded-lg text-[10px] font-mono font-semibold bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 flex items-center gap-1 transition-all cursor-pointer"
              title={`Restore only ${activeChange.path} to this state`}
            >
              <RotateCcw size={11} className={restoringFile === activeChange.path ? "animate-spin" : ""} />
              <span>{restoringFile === activeChange.path ? "Restoring..." : "Revert File"}</span>
            </button>
          )}
        </div>
      </div>

      {/* File Path & Diff Header Info */}
      {activeChange && (
        <div className="flex items-center justify-between px-3 py-1.5 bg-black/40 border-b border-white/5 text-[11px] font-mono text-white/50">
          <div className="flex items-center gap-2 truncate">
            <span className="text-white/80 font-semibold truncate">{activeChange.path}</span>
            <span
              className={`px-1.5 py-0.2 rounded text-[9px] font-bold uppercase ${
                activeChange.status === "added"
                  ? "bg-emerald-500/20 text-emerald-300"
                  : activeChange.status === "deleted"
                  ? "bg-rose-500/20 text-rose-300"
                  : "bg-amber-500/20 text-amber-300"
              }`}
            >
              {activeChange.status}
            </span>
            {activeChange.status === "modified" && (
              <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30 flex items-center gap-1">
                <Scissors size={9} />
                <span>Surgical Edit</span>
              </span>
            )}
          </div>

          <div className="flex items-center gap-2 text-[10px] text-white/40">
            <span className="text-emerald-400 font-bold">+{activeChange.additions} lines</span>
            <span>/</span>
            <span className="text-rose-400 font-bold">-{activeChange.deletions} lines</span>
          </div>
        </div>
      )}

      {/* Main Diff Code Display */}
      <div className="max-h-80 overflow-auto bg-[#07080b] font-mono text-[11px] leading-relaxed select-text">
        {viewMode === "unified" ? (
          <table className="w-full border-collapse">
            <tbody>
              {diffLines.map((line, idx) => {
                const isAdd = line.type === "added";
                const isDel = line.type === "deleted";

                return (
                  <tr
                    key={idx}
                    className={`transition-colors font-mono ${
                      isAdd
                        ? "bg-emerald-950/30 text-emerald-200 border-l-2 border-emerald-500"
                        : isDel
                        ? "bg-rose-950/30 text-rose-200 border-l-2 border-rose-500"
                        : "text-zinc-400 hover:bg-white/[0.02]"
                    }`}
                  >
                    {/* Old line number */}
                    <td className="w-9 py-0.5 px-1.5 text-right text-[10px] text-white/20 select-none border-r border-white/5 align-top">
                      {line.oldLineNumber || ""}
                    </td>

                    {/* New line number */}
                    <td className="w-9 py-0.5 px-1.5 text-right text-[10px] text-white/20 select-none border-r border-white/5 align-top">
                      {line.newLineNumber || ""}
                    </td>

                    {/* Marker +/- */}
                    <td className="w-5 py-0.5 px-1 text-center font-bold select-none text-[11px] align-top">
                      {isAdd ? (
                        <span className="text-emerald-400 font-bold">+</span>
                      ) : isDel ? (
                        <span className="text-rose-400 font-bold">-</span>
                      ) : (
                        <span className="text-white/10"> </span>
                      )}
                    </td>

                    {/* Code Content */}
                    <td className="py-0.5 px-2 whitespace-pre overflow-x-auto break-all">
                      {line.text || " "}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        ) : (
          /* Split / Side-by-side mode */
          <div className="grid grid-cols-2 divide-x divide-white/10 min-w-[500px]">
            {/* Left side (Original / Deleted) */}
            <div className="overflow-x-auto">
              <div className="px-2 py-1 bg-white/[0.02] border-b border-white/5 text-[9px] uppercase font-bold text-white/30 tracking-wider">
                Original / Before
              </div>
              <table className="w-full border-collapse">
                <tbody>
                  {splitRows.map((row, idx) => {
                    const left = row.left;
                    const isDel = left?.type === "deleted";

                    return (
                      <tr
                        key={idx}
                        className={`h-5 ${
                          isDel
                            ? "bg-rose-950/30 text-rose-200 border-l-2 border-rose-500"
                            : left
                            ? "text-zinc-400 hover:bg-white/[0.02]"
                            : "bg-black/20"
                        }`}
                      >
                        <td className="w-8 py-0.5 px-1 text-right text-[9px] text-white/20 select-none border-r border-white/5 align-top">
                          {left?.lineNumber || ""}
                        </td>
                        <td className="w-4 py-0.5 text-center text-[10px] font-bold text-rose-400 select-none align-top">
                          {isDel ? "-" : ""}
                        </td>
                        <td className="py-0.5 px-2 whitespace-pre text-[11px] overflow-hidden">
                          {left?.text || " "}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Right side (Modified / Added) */}
            <div className="overflow-x-auto">
              <div className="px-2 py-1 bg-white/[0.02] border-b border-white/5 text-[9px] uppercase font-bold text-white/30 tracking-wider">
                Modified / After
              </div>
              <table className="w-full border-collapse">
                <tbody>
                  {splitRows.map((row, idx) => {
                    const right = row.right;
                    const isAdd = right?.type === "added";

                    return (
                      <tr
                        key={idx}
                        className={`h-5 ${
                          isAdd
                            ? "bg-emerald-950/30 text-emerald-200 border-l-2 border-emerald-500"
                            : right
                            ? "text-zinc-400 hover:bg-white/[0.02]"
                            : "bg-black/20"
                        }`}
                      >
                        <td className="w-8 py-0.5 px-1 text-right text-[9px] text-white/20 select-none border-r border-white/5 align-top">
                          {right?.lineNumber || ""}
                        </td>
                        <td className="w-4 py-0.5 text-center text-[10px] font-bold text-emerald-400 select-none align-top">
                          {isAdd ? "+" : ""}
                        </td>
                        <td className="py-0.5 px-2 whitespace-pre text-[11px] overflow-hidden">
                          {right?.text || " "}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
