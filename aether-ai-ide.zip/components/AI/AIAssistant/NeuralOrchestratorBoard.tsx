import React, { useState, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Brain,
  Sparkles,
  Zap,
  Activity,
  Layers,
  Search,
  Filter,
  CheckCircle2,
  FileCode,
  SlidersHorizontal,
  ChevronRight,
  Copy,
  Trash2,
  Lock,
  Unlock,
  Maximize2,
  Eye,
  Terminal,
  Cpu,
  ShieldCheck,
  Flame,
  Gamepad2,
  Globe,
  Server,
  Wrench,
  HelpCircle,
  X,
  Check
} from "lucide-react";
import {
  ORCHESTRATOR_DIVISIONS,
  OrchestratorDivision,
  OrchestratorAgent,
  IntentClassificationResult
} from "./orchestratorClassifier";
import { FileNode } from "../../../types";

interface NeuralOrchestratorBoardProps {
  isProcessing: boolean;
  activeStep: 'INPUT' | 'UNDERSTAND' | 'INSPECT' | 'PLAN' | 'IMPLEMENT' | 'TEST' | 'REPORT';
  activeAgentId: string;
  activeLogs: Array<{ time: string; message: string; type: string }>;
  onClearLogs: () => void;
  spawnedAgents: string[];
  classification: IntentClassificationResult;
  selectedModel: string;
  lastUserMessages: { current: string; previous: string; allCombined: string };
  divisionScopeMode: 'AUTO' | 'FORCE_GAME' | 'FORCE_WEB' | 'FORCE_BACKEND_AI' | 'MANUAL';
  onSetDivisionScopeMode: (mode: 'AUTO' | 'FORCE_GAME' | 'FORCE_WEB' | 'FORCE_BACKEND_AI' | 'MANUAL') => void;
  manualSelectedAgents: string[];
  onToggleManualAgent: (agentId: string) => void;
  currentBotMessage: any;
  files: FileNode[];
}

export const NeuralOrchestratorBoard: React.FC<NeuralOrchestratorBoardProps> = ({
  isProcessing,
  activeStep,
  activeAgentId,
  activeLogs,
  onClearLogs,
  spawnedAgents,
  classification,
  selectedModel,
  lastUserMessages,
  divisionScopeMode,
  onSetDivisionScopeMode,
  manualSelectedAgents,
  onToggleManualAgent,
  currentBotMessage,
  files
}) => {
  const [selectedDivisionFilter, setSelectedDivisionFilter] = useState<string>("all");
  const [logCategoryFilter, setLogCategoryFilter] = useState<'ALL' | 'SPAWN' | 'FILE' | 'REASON' | 'SUCCESS'>('ALL');
  const [logSearchQuery, setLogSearchQuery] = useState("");
  const [inspectingAgent, setInspectingAgent] = useState<OrchestratorAgent | null>(null);
  const [copiedLogs, setCopiedLogs] = useState(false);

  // Flatten all agents for quick lookup
  const allAgentsMap = useMemo(() => {
    const map = new Map<string, OrchestratorAgent>();
    ORCHESTRATOR_DIVISIONS.forEach(div => {
      div.agents.forEach(agent => {
        map.set(agent.id, agent);
      });
    });
    return map;
  }, []);

  // Filtered logs
  const filteredLogs = useMemo(() => {
    return activeLogs.filter(log => {
      // Category filter
      if (logCategoryFilter === 'SPAWN' && log.type !== 'spawn') return false;
      if (logCategoryFilter === 'FILE' && !log.message.includes("Modifying code at path") && !log.message.includes("AST updates")) return false;
      if (logCategoryFilter === 'REASON' && !log.message.startsWith("🧠 [REASON]")) return false;
      if (logCategoryFilter === 'SUCCESS' && log.type !== 'success') return false;

      // Text query
      if (logSearchQuery.trim()) {
        const q = logSearchQuery.toLowerCase();
        return log.message.toLowerCase().includes(q) || log.time.toLowerCase().includes(q);
      }
      return true;
    });
  }, [activeLogs, logCategoryFilter, logSearchQuery]);

  // Filtered divisions
  const filteredDivisions = useMemo(() => {
    if (selectedDivisionFilter === "all") return ORCHESTRATOR_DIVISIONS;
    return ORCHESTRATOR_DIVISIONS.filter(div => div.id === selectedDivisionFilter);
  }, [selectedDivisionFilter]);

  // Extract files modified from bot message
  const touchedFiles = useMemo(() => {
    const text = currentBotMessage?.text || "";
    const matches = Array.from(text.matchAll(/```[a-zA-Z]*\s+path=([^\s`]+)/g));
    const paths = matches.map(m => (m as RegExpMatchArray)[1]).filter(Boolean);
    return Array.from(new Set(paths));
  }, [currentBotMessage?.text]);

  const handleCopyLogs = () => {
    const text = activeLogs.map(l => `[${l.time}] [${l.type.toUpperCase()}] ${l.message}`).join("\n");
    navigator.clipboard.writeText(text);
    setCopiedLogs(true);
    setTimeout(() => setCopiedLogs(false), 2000);
  };

  // Helper to get active task for an agent
  const getAgentLiveTask = (agentId: string) => {
    const isCurrentActive = activeAgentId === agentId;
    if (!isProcessing) {
      return spawnedAgents.includes(agentId) ? "Synthesized and released" : "Dormant (Ready)";
    }
    if (isCurrentActive) {
      switch (agentId) {
        case "three_js":
          return "Configuring Three.js WebGL scene graph, perspective camera & ACES tone mapping";
        case "game_modeler":
          return "Synthesizing procedural 3D meshes, vertex normals & vehicle geometries";
        case "game_architect":
          return "Calculating delta-time velocity vectors, WASD input & collision bounding boxes";
        case "game_ui":
          return "Injecting responsive HTML/Tailwind HUD layer, health bars & score displays";
        case "game_audio":
          return "Generating Web Audio API dynamic synth oscillators & sound effects";
        case "game_director":
          return "Orchestrating main game loop, wave spawning & game-over transitions";
        case "shader_vfx":
          return "Assembling particle emitter shaders & camera shake trauma matrices";
        case "ui_ux":
          return "Formulating responsive design system, typography & WCAG AA contrast";
        case "react_core":
          return "Constructing modular component hierarchy & reactive state hooks";
        case "styling":
          return "Applying Tailwind CSS utility classes & fluid layout animations";
        case "components_core":
          return "Building interactive buttons, cards, forms & navigation headers";
        case "api_agent":
          return "Structuring REST API endpoints & request/response payloads";
        case "db_agent":
          return "Defining schema models, relational tables & query indexes";
        case "error_analyzer":
          return "Diagnosing stack traces & isolating runtime exception sources";
        case "fix_agent":
          return "Applying surgical code repairs & search/replace diff patches";
        default:
          return "Active execution in progress...";
      }
    }
    if (spawnedAgents.includes(agentId)) {
      return "Sub-task completed. Standing by for verification.";
    }
    return "Standby";
  };

  return (
    <div className="flex-1 overflow-y-auto p-3 sm:p-5 space-y-4 min-h-0 custom-scrollbar bg-[#04060a]/95 backdrop-blur-md text-left select-none">
      
      {/* 1. MASTER TELEMETRY HUD BAR */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <div className="bg-zinc-900/60 border border-white/5 rounded-xl p-3 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[9px] font-black text-white/40 uppercase tracking-widest">Master Conductor</span>
            <Brain size={12} className={isProcessing ? "text-orange-400 animate-pulse" : "text-zinc-600"} />
          </div>
          <div className="mt-2 flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full ${isProcessing ? 'bg-orange-500 animate-ping' : 'bg-emerald-500'}`} />
            <span className={`text-xs font-bold font-mono ${isProcessing ? 'text-orange-400' : 'text-emerald-400'}`}>
              {isProcessing ? "ORCHESTRATING" : "READY / STANDBY"}
            </span>
          </div>
        </div>

        <div className="bg-zinc-900/60 border border-white/5 rounded-xl p-3 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[9px] font-black text-white/40 uppercase tracking-widest">Active Pool</span>
            <Layers size={12} className="text-cyan-400" />
          </div>
          <div className="mt-2 flex items-center justify-between">
            <span className="text-xs font-bold font-mono text-white">
              {spawnedAgents.length} Agents
            </span>
            <span className="text-[9px] text-zinc-500 font-mono">
              {isProcessing ? "Ephemeral Active" : "Pool Allocated"}
            </span>
          </div>
        </div>

        <div className="bg-zinc-900/60 border border-white/5 rounded-xl p-3 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[9px] font-black text-white/40 uppercase tracking-widest">Pipeline Step</span>
            <Activity size={12} className="text-orange-400" />
          </div>
          <div className="mt-2 flex items-center justify-between">
            <span className="text-xs font-bold font-mono text-orange-400 uppercase">
              {isProcessing ? activeStep : "IDLE"}
            </span>
            <span className="text-[9px] text-zinc-500 font-mono">
              Step {['INPUT', 'UNDERSTAND', 'INSPECT', 'PLAN', 'IMPLEMENT', 'TEST', 'REPORT'].indexOf(activeStep) + 1}/7
            </span>
          </div>
        </div>

        <div className="bg-zinc-900/60 border border-white/5 rounded-xl p-3 flex flex-col justify-between shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-[9px] font-black text-white/40 uppercase tracking-widest">Active Division</span>
            <Sparkles size={12} className={classification.isGame ? "text-amber-400" : "text-cyan-400"} />
          </div>
          <div className="mt-2 flex items-center justify-between">
            <span className={`text-xs font-bold truncate ${classification.isGame ? "text-amber-400" : "text-cyan-400"}`}>
              {classification.isGame ? "3D Game Dev" : "Web & App Dev"}
            </span>
            <span className="text-[8px] font-mono px-1.5 py-0.5 rounded bg-white/5 text-zinc-400 border border-white/5">
              {Math.round(classification.confidence * 100)}% Match
            </span>
          </div>
        </div>
      </div>

      {/* 2. COGNITIVE ROUTING & DIVISION SCOPE CONTROLS */}
      <div className="bg-zinc-950/80 border border-white/5 rounded-2xl p-4 space-y-3.5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-white/5">
          <div className="flex items-center gap-2">
            <div className="p-1 rounded-md bg-orange-500/10 text-orange-400 border border-orange-500/20">
              <Brain size={13} className="animate-pulse" />
            </div>
            <div>
              <span className="text-[10px] font-black uppercase text-orange-400 tracking-wider block">Cognitive Intent & Division Control</span>
              <span className="text-[8px] text-zinc-500 font-mono">Real-time prompt domain routing & division filtering</span>
            </div>
          </div>

          {/* Division Mode Switcher Pills */}
          <div className="flex flex-wrap items-center gap-1">
            <button
              onClick={() => onSetDivisionScopeMode('AUTO')}
              className={`px-2.5 py-1 rounded-lg text-[9px] font-bold font-mono transition-all flex items-center gap-1 ${
                divisionScopeMode === 'AUTO'
                  ? 'bg-orange-500 text-black shadow-sm font-black'
                  : 'bg-zinc-900 text-zinc-400 hover:text-white border border-white/5'
              }`}
            >
              <Sparkles size={10} /> Auto AI Route
            </button>
            <button
              onClick={() => onSetDivisionScopeMode('FORCE_GAME')}
              className={`px-2.5 py-1 rounded-lg text-[9px] font-bold font-mono transition-all flex items-center gap-1 ${
                divisionScopeMode === 'FORCE_GAME'
                  ? 'bg-amber-500 text-black shadow-sm font-black'
                  : 'bg-zinc-900 text-zinc-400 hover:text-amber-300 border border-white/5'
              }`}
            >
              <Gamepad2 size={10} /> Force Game Dev
            </button>
            <button
              onClick={() => onSetDivisionScopeMode('FORCE_WEB')}
              className={`px-2.5 py-1 rounded-lg text-[9px] font-bold font-mono transition-all flex items-center gap-1 ${
                divisionScopeMode === 'FORCE_WEB'
                  ? 'bg-cyan-500 text-black shadow-sm font-black'
                  : 'bg-zinc-900 text-zinc-400 hover:text-cyan-300 border border-white/5'
              }`}
            >
              <Globe size={10} /> Force Web Dev
            </button>
            <button
              onClick={() => onSetDivisionScopeMode('FORCE_BACKEND_AI')}
              className={`px-2.5 py-1 rounded-lg text-[9px] font-bold font-mono transition-all flex items-center gap-1 ${
                divisionScopeMode === 'FORCE_BACKEND_AI'
                  ? 'bg-purple-500 text-black shadow-sm font-black'
                  : 'bg-zinc-900 text-zinc-400 hover:text-purple-300 border border-white/5'
              }`}
            >
              <Server size={10} /> Force Backend/AI
            </button>
            <button
              onClick={() => onSetDivisionScopeMode('MANUAL')}
              className={`px-2.5 py-1 rounded-lg text-[9px] font-bold font-mono transition-all flex items-center gap-1 ${
                divisionScopeMode === 'MANUAL'
                  ? 'bg-emerald-500 text-black shadow-sm font-black'
                  : 'bg-zinc-900 text-zinc-400 hover:text-emerald-300 border border-white/5'
              }`}
            >
              <SlidersHorizontal size={10} /> Manual Pool
            </button>
          </div>
        </div>

        {/* Previous & Current Context Breakdown */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[10px]">
          <div className="bg-[#0b0c11] border border-white/[0.04] rounded-xl p-3 space-y-1.5">
            <span className="text-zinc-500 font-bold block uppercase tracking-widest text-[8px]">Previous Context</span>
            <p className="text-zinc-400 italic truncate max-w-full">
              {lastUserMessages.previous ? `"${lastUserMessages.previous}"` : "None (Initial Turn)"}
            </p>
            {lastUserMessages.previous && (
              <span className="inline-block text-[8px] font-mono px-1.5 py-0.5 rounded bg-white/5 text-zinc-400">
                Memory state retained
              </span>
            )}
          </div>

          <div className="bg-[#0b0c11] border border-white/[0.04] rounded-xl p-3 space-y-1.5">
            <span className="text-zinc-500 font-bold block uppercase tracking-widest text-[8px]">Active Intent</span>
            <p className="text-zinc-200 font-medium truncate max-w-full">
              {lastUserMessages.current ? `"${lastUserMessages.current}"` : "Awaiting user input..."}
            </p>
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              {(classification.activeDivisions || []).map(div => {
                const isGameDiv = div.type === 'game';
                return (
                  <span
                    key={div.id}
                    className={`inline-flex items-center gap-1 text-[8px] font-mono font-bold px-1.5 py-0.5 rounded border transition-all ${div.badgeBg || "bg-cyan-500/10 text-cyan-400 border-cyan-500/20"}`}
                  >
                    {isGameDiv ? <Gamepad2 size={9} /> : div.type === 'backend' ? <Server size={9} /> : div.type === 'ai' ? <Brain size={9} /> : <Globe size={9} />}
                    {div.name}
                  </span>
                );
              })}
              {(!classification.activeDivisions || classification.activeDivisions.length === 0) && (
                <span className={`inline-flex items-center gap-1 text-[8px] font-mono font-bold px-1.5 py-0.5 rounded border ${
                  classification.isGame 
                    ? "bg-amber-500/10 text-amber-400 border-amber-500/20" 
                    : "bg-cyan-500/10 text-cyan-400 border-cyan-500/20"
                }`}>
                  {classification.isGame ? <Gamepad2 size={9} /> : <Globe size={9} />}
                  {classification.divisionName}
                </span>
              )}
              <span className="text-[8px] font-mono text-zinc-500 ml-1">
                Mode: {classification.activeDivisions && classification.activeDivisions.length > 1 ? "Joint Division Swarm" : "Single Division"}
              </span>
            </div>
          </div>
        </div>

        {/* Detailed Routing Path & Reason */}
        <div className="pt-1 flex items-start gap-2 text-[9px] font-mono text-zinc-400">
          <span className="text-orange-400 font-bold shrink-0">Routing Explanation:</span>
          <span className="text-zinc-300 leading-relaxed">{classification.reason}</span>
        </div>
      </div>

      {/* 3. RUN-LOOP PROGRESS ENGINE & TOUCHED FILES */}
      <div className="bg-zinc-950/80 border border-white/5 rounded-2xl p-4 space-y-3 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity size={12} className={isProcessing ? "text-orange-400 animate-pulse" : "text-zinc-600"} />
            <span className="text-[10px] font-black uppercase text-zinc-300 tracking-wider">Neural Run-Loop Engine</span>
          </div>
          <span className="text-[8px] font-mono text-zinc-500">
            Model: {selectedModel}
          </span>
        </div>

        {/* 7-Step Pipeline Visualizer */}
        <div className="grid grid-cols-2 sm:grid-cols-7 gap-1.5">
          {(['INPUT', 'UNDERSTAND', 'INSPECT', 'PLAN', 'IMPLEMENT', 'TEST', 'REPORT'] as const).map((step, idx) => {
            const stepIndex = ['INPUT', 'UNDERSTAND', 'INSPECT', 'PLAN', 'IMPLEMENT', 'TEST', 'REPORT'].indexOf(activeStep);
            const isCurrent = step === activeStep && isProcessing;
            const isPast = stepIndex > idx;

            return (
              <div
                key={step}
                className={`py-1.5 px-2 rounded-lg text-[8px] font-mono font-bold text-center border transition-all flex flex-col items-center justify-center gap-0.5 ${
                  isCurrent
                    ? 'bg-orange-500 text-black border-orange-400 font-black shadow-[0_0_12px_rgba(249,115,22,0.4)] scale-[1.02]'
                    : isPast
                    ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                    : 'bg-zinc-900/40 text-zinc-600 border-white/5'
                }`}
              >
                <span className="text-[7px] opacity-75">{idx + 1}. STEP</span>
                <span className="truncate w-full">{step}</span>
              </div>
            );
          })}
        </div>

        {/* Files Modified in Real-Time */}
        {touchedFiles.length > 0 && (
          <div className="pt-2 border-t border-white/5 flex flex-wrap items-center gap-1.5">
            <span className="text-[8px] font-mono uppercase text-zinc-500 flex items-center gap-1">
              <FileCode size={10} className="text-cyan-400" /> Touched Files:
            </span>
            {touchedFiles.map((file, i) => (
              <span key={i} className="text-[8px] font-mono px-2 py-0.5 rounded-md bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 flex items-center gap-1">
                <FileCode size={9} /> {file}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* 4. ACTIVE SUB-AGENTS EXECUTION MATRIX */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Cpu size={13} className="text-orange-400" />
            <span className="text-[10px] font-black uppercase text-zinc-300 tracking-wider">Active Sub-Agents Swarm</span>
            <span className="text-[8px] bg-orange-500/10 text-orange-400 border border-orange-500/20 px-1.5 py-0.5 rounded font-mono font-bold">
              {spawnedAgents.length} Spawned
            </span>
          </div>
          <span className="text-[8px] text-zinc-500 font-mono">
            Click any agent to inspect live instructions
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
          {spawnedAgents.map((agentId) => {
            const agent = allAgentsMap.get(agentId);
            if (!agent) return null;

            const isCurrentActive = isProcessing && activeAgentId === agentId;
            const liveTask = getAgentLiveTask(agentId);

            return (
              <div
                key={agent.id}
                onClick={() => setInspectingAgent(agent)}
                className={`p-3 rounded-xl border transition-all cursor-pointer group flex flex-col justify-between ${
                  isCurrentActive
                    ? 'bg-orange-500/15 border-orange-500/50 shadow-[0_0_15px_rgba(249,115,22,0.15)] ring-1 ring-orange-500/30'
                    : 'bg-zinc-950/60 border-white/5 hover:border-white/20 hover:bg-zinc-900/40'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`p-1.5 rounded-lg border ${
                      isCurrentActive 
                        ? 'bg-orange-500 text-black border-orange-400 font-bold'
                        : 'bg-zinc-900 text-zinc-400 border-white/5'
                    }`}>
                      <Zap size={11} className={isCurrentActive ? "animate-spin" : ""} />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-white block group-hover:text-orange-400 transition-colors">
                        {agent.name}
                      </span>
                      <span className="text-[8px] font-mono text-zinc-500">
                        {agent.role}
                      </span>
                    </div>
                  </div>

                  {/* Status Badge */}
                  <div>
                    {isCurrentActive ? (
                      <span className="text-[8px] bg-orange-500 text-black font-black px-2 py-0.5 rounded-md uppercase animate-pulse flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-black animate-ping" />
                        EXECUTING
                      </span>
                    ) : isProcessing ? (
                      <span className="text-[8px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.5 rounded font-mono font-bold">
                        SYNTHESIZED
                      </span>
                    ) : (
                      <span className="text-[8px] bg-zinc-800 text-zinc-400 px-1.5 py-0.5 rounded font-mono">
                        STANDBY
                      </span>
                    )}
                  </div>
                </div>

                {/* Live Task Description */}
                <div className="mt-2.5 pt-2 border-t border-white/[0.04] flex items-center justify-between text-[9px]">
                  <p className={`font-mono text-[8px] truncate max-w-[85%] ${
                    isCurrentActive ? 'text-orange-300 font-medium' : 'text-zinc-500'
                  }`}>
                    {liveTask}
                  </p>
                  <Eye size={11} className="text-zinc-600 group-hover:text-zinc-300 transition-colors" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 5. DYNAMIC SYNAPTIC ACTIVITY LOGGER */}
      <div className="bg-black/90 border border-white/5 rounded-2xl p-4 shadow-2xl space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-white/5">
          <div className="flex items-center gap-2">
            <Terminal size={13} className="text-orange-400" />
            <span className="text-[10px] font-black uppercase text-zinc-300 tracking-wider">Dynamic Synaptic Activity Logger</span>
            {isProcessing && <span className="w-2 h-2 rounded-full bg-orange-500 animate-ping" />}
          </div>

          <div className="flex items-center gap-1.5">
            {/* Filter Pills */}
            <div className="flex items-center bg-zinc-900 rounded-lg p-0.5 border border-white/5 text-[8px] font-mono">
              {(['ALL', 'SPAWN', 'FILE', 'REASON', 'SUCCESS'] as const).map(cat => (
                <button
                  key={cat}
                  onClick={() => setLogCategoryFilter(cat)}
                  className={`px-2 py-0.5 rounded ${
                    logCategoryFilter === cat
                      ? 'bg-orange-500 text-black font-bold'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Copy Logs */}
            <button
              onClick={handleCopyLogs}
              title="Copy All Logs"
              className="p-1 rounded-md bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white border border-white/5"
            >
              {copiedLogs ? <Check size={11} className="text-emerald-400" /> : <Copy size={11} />}
            </button>

            {/* Clear Logs */}
            <button
              onClick={onClearLogs}
              title="Clear Activity Logs"
              className="p-1 rounded-md bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-red-400 border border-white/5"
            >
              <Trash2 size={11} />
            </button>
          </div>
        </div>

        {/* Search filter for logs */}
        <div className="relative">
          <Search size={11} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-500" />
          <input
            type="text"
            value={logSearchQuery}
            onChange={(e) => setLogSearchQuery(e.target.value)}
            placeholder="Search synaptic logs, AST traces, and agent actions..."
            className="w-full bg-[#0b0c11] border border-white/5 rounded-lg pl-7 pr-3 py-1 text-[9px] font-mono text-zinc-300 placeholder-zinc-600 focus:outline-none focus:border-orange-500/50"
          />
        </div>

        {/* Log Entries Container */}
        <div className="h-44 overflow-y-auto space-y-1.5 font-mono text-[9px] custom-scrollbar text-left pr-1">
          {filteredLogs.map((log, index) => (
            <div key={index} className="flex items-start gap-2 leading-relaxed hover:bg-white/[0.02] p-1 rounded transition-colors">
              <span className="text-zinc-600 shrink-0 select-none">[{log.time}]</span>
              <span className={
                log.type === 'spawn' ? 'text-cyan-400 font-semibold' :
                log.type === 'destroy' ? 'text-rose-400 font-semibold' :
                log.type === 'success' ? 'text-emerald-400 font-semibold' :
                log.message.startsWith('🧠 [REASON]') ? 'text-purple-400' :
                log.message.includes('Modifying code at path') ? 'text-amber-400' :
                'text-zinc-300'
              }>
                {log.message}
              </span>
            </div>
          ))}
          {filteredLogs.length === 0 && (
            <div className="text-center py-10 text-zinc-600 font-mono text-[10px]">
              No synaptic logs match active filter.<br />
              <span className="text-[8px] text-zinc-700">Logs will stream in real-time as the orchestrator executes tasks.</span>
            </div>
          )}
        </div>
      </div>

      {/* 6. STRICT DIVISION FILTERING & ALL DIVISIONS MAP */}
      <div className="space-y-3 pb-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Filter size={12} className="text-zinc-400" />
            <span className="text-[10px] font-black uppercase text-zinc-300 tracking-wider">Division Directory & Filtering</span>
          </div>

          {/* Division Filter Pills */}
          <div className="flex flex-wrap items-center gap-1">
            <button
              onClick={() => setSelectedDivisionFilter("all")}
              className={`px-2 py-0.5 rounded-lg text-[8px] font-mono font-bold transition-all ${
                selectedDivisionFilter === "all"
                  ? "bg-zinc-200 text-black"
                  : "bg-zinc-900 text-zinc-400 hover:text-white border border-white/5"
              }`}
            >
              All ({ORCHESTRATOR_DIVISIONS.length} Divisions)
            </button>
            {ORCHESTRATOR_DIVISIONS.map(div => (
              <button
                key={div.id}
                onClick={() => setSelectedDivisionFilter(div.id)}
                className={`px-2 py-0.5 rounded-lg text-[8px] font-mono font-bold transition-all ${
                  selectedDivisionFilter === div.id
                    ? "bg-orange-500 text-black"
                    : "bg-zinc-900 text-zinc-400 hover:text-white border border-white/5"
                }`}
              >
                {div.shortName}
              </button>
            ))}
          </div>
        </div>

        {/* Divisions Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {filteredDivisions.map((div) => {
            const hasSpawnedInDiv = div.agents.some(a => spawnedAgents.includes(a.id));
            const isGameDivision = div.type === 'game';
            const isCurrentlyFilteredOut = classification.isGame ? !isGameDivision : isGameDivision;

            return (
              <div
                key={div.id}
                className={`rounded-2xl border p-4 space-y-3 transition-all ${
                  hasSpawnedInDiv
                    ? 'border-orange-500/30 bg-orange-950/[0.04] shadow-xl'
                    : isCurrentlyFilteredOut
                    ? 'border-white/5 bg-zinc-950/40 opacity-40'
                    : 'border-white/5 bg-zinc-950/60'
                }`}
              >
                <div className="flex items-center justify-between pb-2 border-b border-white/5">
                  <span className={`text-[10px] font-bold ${div.iconColor}`}>{div.name}</span>
                  {hasSpawnedInDiv ? (
                    <span className="text-[7px] bg-orange-500/10 text-orange-400 border border-orange-500/20 px-2 py-0.5 rounded font-black uppercase tracking-wider">
                      ⚡ Active In Pool
                    </span>
                  ) : isCurrentlyFilteredOut ? (
                    <span className="text-[7px] bg-zinc-800 text-zinc-500 px-1.5 py-0.5 rounded font-mono">
                      Isolated (Non-Scope)
                    </span>
                  ) : (
                    <span className="text-[7px] text-zinc-600 font-mono">
                      Standby
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 gap-2">
                  {div.agents.map((agent) => {
                    const isSpawned = spawnedAgents.includes(agent.id);
                    const isActive = isProcessing && activeAgentId === agent.id;
                    const isSelectedInManual = manualSelectedAgents.includes(agent.id);

                    return (
                      <div
                        key={agent.id}
                        onClick={() => {
                          if (divisionScopeMode === 'MANUAL') {
                            onToggleManualAgent(agent.id);
                          } else {
                            setInspectingAgent(agent);
                          }
                        }}
                        className={`p-2.5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                          isActive
                            ? 'bg-orange-500/15 border-orange-400 text-orange-400 shadow-md'
                            : divisionScopeMode === 'MANUAL'
                            ? isSelectedInManual
                              ? 'bg-emerald-500/15 border-emerald-500 text-emerald-300'
                              : 'bg-zinc-900/40 border-white/5 text-zinc-500 hover:border-zinc-700'
                            : isSpawned
                            ? 'bg-zinc-900/80 border-orange-500/30 text-white'
                            : 'bg-zinc-900/30 border-white/[0.03] text-zinc-500 hover:border-white/10'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-[9px] font-black tracking-wide uppercase text-zinc-200">
                            {agent.name}
                          </span>

                          {isActive ? (
                            <span className="text-[7px] bg-orange-500 text-black font-black px-1.5 py-0.5 rounded animate-pulse uppercase">
                              ACTING: {activeStep}
                            </span>
                          ) : divisionScopeMode === 'MANUAL' ? (
                            isSelectedInManual ? (
                              <span className="text-[7px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.5 rounded uppercase font-bold">
                                MANUAL ON
                              </span>
                            ) : (
                              <span className="text-[7px] text-zinc-600 font-mono">OFFLINE</span>
                            )
                          ) : isSpawned ? (
                            <span className="text-[7px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.5 rounded uppercase font-bold">
                              SPAWNED
                            </span>
                          ) : (
                            <span className="text-[7px] text-zinc-600 font-mono">DORMANT</span>
                          )}
                        </div>
                        <p className="text-[8px] opacity-75 mt-1 leading-normal text-zinc-400">{agent.desc}</p>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 7. SUB-AGENT INSPECTOR MODAL */}
      <AnimatePresence>
        {inspectingAgent && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-zinc-950 border border-white/10 rounded-2xl w-full max-w-lg p-5 space-y-4 shadow-2xl text-left"
            >
              <div className="flex items-center justify-between pb-3 border-b border-white/5">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-xl bg-orange-500/10 text-orange-400 border border-orange-500/20">
                    <Cpu size={16} />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">{inspectingAgent.name}</h3>
                    <span className="text-[9px] font-mono text-zinc-400">{inspectingAgent.divisionName} • {inspectingAgent.role}</span>
                  </div>
                </div>
                <button
                  onClick={() => setInspectingAgent(null)}
                  className="p-1 rounded-lg hover:bg-zinc-800 text-zinc-400 hover:text-white"
                >
                  <X size={16} />
                </button>
              </div>

              <div className="space-y-3 text-[10px]">
                <div className="bg-[#0b0c11] border border-white/5 rounded-xl p-3 space-y-1">
                  <span className="text-[8px] font-mono uppercase text-zinc-500 block">Assigned Responsibilities</span>
                  <p className="text-zinc-300 leading-relaxed">{inspectingAgent.desc}</p>
                </div>

                {inspectingAgent.systemInstructionSnippet && (
                  <div className="bg-[#0b0c11] border border-white/5 rounded-xl p-3 space-y-1 font-mono">
                    <span className="text-[8px] uppercase text-orange-400/80 block">Specialized Prompt Directive</span>
                    <p className="text-zinc-400 text-[9px] leading-relaxed">{inspectingAgent.systemInstructionSnippet}</p>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-2 text-[9px] font-mono">
                  <div className="bg-zinc-900/60 p-2.5 rounded-xl border border-white/5">
                    <span className="text-zinc-500 block text-[8px]">Runtime Pool Status</span>
                    <span className="text-white font-bold">
                      {spawnedAgents.includes(inspectingAgent.id) ? "⚡ Active In Pool" : "Standby (Dormant)"}
                    </span>
                  </div>
                  <div className="bg-zinc-900/60 p-2.5 rounded-xl border border-white/5">
                    <span className="text-zinc-500 block text-[8px]">Division Domain</span>
                    <span className="text-orange-400 font-bold uppercase">
                      {inspectingAgent.divisionType}
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => setInspectingAgent(null)}
                  className="px-4 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-white font-mono text-xs border border-white/10"
                >
                  Close Inspector
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
};
