import { Globe, Box, SearchCode, ImageIcon, Wand2, Eye, Activity, Cpu, Sparkles, Zap, FileText } from "lucide-react";

export const AI_FEATURES = [
  {
    id: "vanilla",
    label: "Web Application",
    icon: Globe,
    prompt:
      "Generate a complete Web Application cleanly separated into modular files (index.html, style.css, script.js). CRITICAL: Decompose all styles into style.css and logic into script.js rather than embedding inline code in index.html.",
  },
  {
    id: "spa",
    label: "Modern SPA",
    icon: Box,
    prompt:
      "Generate a modern Single Page Application using pure JS. Implement a custom router, state management, and elegant UI transitions without any external frameworks.",
  },
  {
    id: "audit",
    label: "Code Audit",
    icon: SearchCode,
    prompt:
      "Perform a deep audit of the current codebase to identify security, performance, and stability issues.",
  },
  {
    id: "image",
    label: "Creative Asset",
    icon: ImageIcon,
    prompt:
      "Generate a high-quality visual asset or illustration for the current project context.",
  },
  {
    id: "polish",
    label: "Aether Polish",
    icon: Wand2,
    prompt:
      "Apply the Aether visual aesthetic to the current codebase—improving typography, spacing, and adding fluid motion effects.",
  },
];

export const NEURAL_SKILLS = [
  { id: 'vision', name: 'Visual Audit', icon: Eye, color: 'text-cyan-400', prompt: 'Analyze the current application interface and layout. I have provided context about the files and possibly a snapshot. Suggest UI improvements, accessibility fixes, and design refinements.' },
  { id: 'debugger', name: 'Auto Debug', icon: Activity, color: 'text-red-400', prompt: 'Analyze the current workspace for syntax errors, logical flaws, and performance bottlenecks. Suggest targeted fixes.' },
  { id: 'architect', name: 'App Logic', icon: Cpu, color: 'text-blue-400', prompt: 'Design a robust state management and routing architecture for the current project. Define core data types and services.' },
  { id: 'designer', name: 'UI Polish', icon: Sparkles, color: 'text-amber-400', prompt: 'Enhance the visual design of the current interface. Improve typography, spacing, and color harmony using Tailwind CSS best practices.' },
  { id: 'optimizer', name: 'Token Opt', icon: Zap, color: 'text-amber-500', prompt: 'Analyze the current codebase and refactor it for extreme efficiency. Remove dead code, optimize loops, and ensure the most compact implementation possible without sacrificing functionality.' },
  { id: 'writer', name: 'Doc Gen', icon: FileText, color: 'text-emerald-400', prompt: 'Generate comprehensive README and documentation for the current project. Include setup instructions and API references.' },
];
