import React, { useState, useMemo, useEffect, useRef } from "react";
import { 
  Sparkles, 
  Gamepad2, 
  Layers, 
  Server, 
  Database, 
  Brain, 
  Smartphone, 
  Zap, 
  ShieldCheck, 
  Wrench, 
  GitBranch, 
  FileText, 
  Bot, 
  ChevronRight, 
  Search, 
  CheckCircle2, 
  Flame,
  Globe
} from "lucide-react";
import { FileNode } from "../../../types";
import { ORCHESTRATOR_DIVISIONS, OrchestratorAgent, OrchestratorDivision } from "./orchestratorClassifier";

export interface DivisionActionItem {
  id: string;
  mentionTag: string;
  name: string;
  shortName: string;
  desc: string;
  agentCount: number;
  color: string;
  badgeBg: string;
  iconColor: string;
  divisionId: string;
  agents: OrchestratorAgent[];
}

export const ALL_DIVISION_ACTIONS: DivisionActionItem[] = [
  {
    id: "all_swarm",
    mentionTag: "@all",
    name: "⚡ Full Swarm Orchestration",
    shortName: "All Divisions",
    desc: "Activates all 61 specialized agents across all 10 engineering divisions simultaneously",
    agentCount: ORCHESTRATOR_DIVISIONS.reduce((acc, d) => acc + d.agents.length, 0),
    color: "border-orange-500/40 text-orange-400 bg-orange-500/10",
    badgeBg: "bg-orange-500/20 text-orange-300 border-orange-500/40",
    iconColor: "text-orange-400",
    divisionId: "all",
    agents: ORCHESTRATOR_DIVISIONS.flatMap(d => d.agents)
  },
  {
    id: "game_spec",
    mentionTag: "@game",
    name: "🎮 3D & 2D Game Division",
    shortName: "Game Dev",
    desc: "Spawns 11 specialized game agents (Three.js, 3D Modeler, Physics, HUD, Web Audio, Director, Shaders, Netcode, WebXR, GPU Fluid, PBR)",
    agentCount: ORCHESTRATOR_DIVISIONS.find(d => d.id === "game_spec")?.agents.length || 11,
    color: "border-amber-500/40 text-amber-400 bg-amber-500/10",
    badgeBg: "bg-amber-500/20 text-amber-300 border-amber-500/40",
    iconColor: "text-amber-400",
    divisionId: "game_spec",
    agents: ORCHESTRATOR_DIVISIONS.find(d => d.id === "game_spec")?.agents || []
  },
  {
    id: "frontend",
    mentionTag: "@frontend",
    name: "🎨 Frontend & UI/UX Division",
    shortName: "Frontend",
    desc: "Spawns 10 specialized frontend agents (Multi-page Routes, UI/UX, React Core, Styling & Motion, Components, ARIA, Perf, Bento Grid, D3 Charts)",
    agentCount: ORCHESTRATOR_DIVISIONS.find(d => d.id === "frontend")?.agents.length || 10,
    color: "border-cyan-500/40 text-cyan-400 bg-cyan-500/10",
    badgeBg: "bg-cyan-500/20 text-cyan-300 border-cyan-500/40",
    iconColor: "text-cyan-400",
    divisionId: "frontend",
    agents: ORCHESTRATOR_DIVISIONS.find(d => d.id === "frontend")?.agents || []
  },
  {
    id: "backend",
    mentionTag: "@backend",
    name: "⚙️ Backend & API Systems Division",
    shortName: "Backend",
    desc: "Spawns 10 specialized backend agents (Express Architect, REST API, JWT Auth, SQL/NoSQL DB, Background Jobs, Realtime Sockets, Edge Security)",
    agentCount: ORCHESTRATOR_DIVISIONS.find(d => d.id === "backend")?.agents.length || 10,
    color: "border-emerald-500/40 text-emerald-400 bg-emerald-500/10",
    badgeBg: "bg-emerald-500/20 text-emerald-300 border-emerald-500/40",
    iconColor: "text-emerald-400",
    divisionId: "backend",
    agents: ORCHESTRATOR_DIVISIONS.find(d => d.id === "backend")?.agents || []
  },
  {
    id: "data_cloud",
    mentionTag: "@data_cloud",
    name: "🗄️ Full-Stack Database & Cloud Sync Division",
    shortName: "Data & Cloud",
    desc: "Spawns 6 specialized data agents (Firestore Realtime Sync, SQL Schema ORM, Vector DB Embeddings, Cloud Storage Media, Redis Cache)",
    agentCount: ORCHESTRATOR_DIVISIONS.find(d => d.id === "data_cloud")?.agents.length || 6,
    color: "border-blue-500/40 text-blue-400 bg-blue-500/10",
    badgeBg: "bg-blue-500/20 text-blue-300 border-blue-500/40",
    iconColor: "text-blue-400",
    divisionId: "data_cloud",
    agents: ORCHESTRATOR_DIVISIONS.find(d => d.id === "data_cloud")?.agents || []
  },
  {
    id: "ai_div",
    mentionTag: "@ai",
    name: "🤖 AI Core & Intelligence Division",
    shortName: "AI Core",
    desc: "Spawns 10 specialized AI agents (AI Architect, Model Selector, Prompt Engineering, RAG Memory, Deep Research Crawler, Multimodal Vision, Omni, Speech)",
    agentCount: ORCHESTRATOR_DIVISIONS.find(d => d.id === "ai_div")?.agents.length || 10,
    color: "border-purple-500/40 text-purple-400 bg-purple-500/10",
    badgeBg: "bg-purple-500/20 text-purple-300 border-purple-500/40",
    iconColor: "text-purple-400",
    divisionId: "ai_div",
    agents: ORCHESTRATOR_DIVISIONS.find(d => d.id === "ai_div")?.agents || []
  },
  {
    id: "mobile_pwa",
    mentionTag: "@mobile",
    name: "📱 Mobile, Touch & PWA Division",
    shortName: "Mobile & PWA",
    desc: "Spawns 5 specialized mobile agents (Adaptive Viewport Scaler, Virtual Joysticks & Swipe Haptics, Service Worker Manifest, Biometrics & Sensors)",
    agentCount: ORCHESTRATOR_DIVISIONS.find(d => d.id === "mobile_pwa")?.agents.length || 5,
    color: "border-pink-500/40 text-pink-400 bg-pink-500/10",
    badgeBg: "bg-pink-500/20 text-pink-300 border-pink-500/40",
    iconColor: "text-pink-400",
    divisionId: "mobile_pwa",
    agents: ORCHESTRATOR_DIVISIONS.find(d => d.id === "mobile_pwa")?.agents || []
  },
  {
    id: "algorithms_perf",
    mentionTag: "@perf",
    name: "⚡ High-Performance Algorithms & Memory Division",
    shortName: "Algo & Perf",
    desc: "Spawns 5 performance agents (DSA Math Master, Memory Garbage Profiler, Web Workers Multithreading, WebGPU Compute, Binary Serialization)",
    agentCount: ORCHESTRATOR_DIVISIONS.find(d => d.id === "algorithms_perf")?.agents.length || 5,
    color: "border-yellow-500/40 text-yellow-400 bg-yellow-500/10",
    badgeBg: "bg-yellow-500/20 text-yellow-300 border-yellow-500/40",
    iconColor: "text-yellow-400",
    divisionId: "algorithms_perf",
    agents: ORCHESTRATOR_DIVISIONS.find(d => d.id === "algorithms_perf")?.agents || []
  },
  {
    id: "testing",
    mentionTag: "@testing",
    name: "🛡️ Automated Testing & Security Division",
    shortName: "Testing & QA",
    desc: "Spawns 5 testing agents (Unit Tester, Regression Sentinel, Security Vulnerability Auditor, Secrets Finder, Chaos Load Stress Tester)",
    agentCount: ORCHESTRATOR_DIVISIONS.find(d => d.id === "testing")?.agents.length || 5,
    color: "border-teal-500/40 text-teal-400 bg-teal-500/10",
    badgeBg: "bg-teal-500/20 text-teal-300 border-teal-500/40",
    iconColor: "text-teal-400",
    divisionId: "testing",
    agents: ORCHESTRATOR_DIVISIONS.find(d => d.id === "testing")?.agents || []
  },
  {
    id: "devops",
    mentionTag: "@devops",
    name: "🚀 DevOps & Diagnostic Repair Division",
    shortName: "DevOps & Fix",
    desc: "Spawns 5 diagnostic agents (Build Agent, Error Analyzer, Root Cause Detective, Auto-Fix Synthesizer, CI/CD Pipeline)",
    agentCount: ORCHESTRATOR_DIVISIONS.find(d => d.id === "devops")?.agents.length || 5,
    color: "border-rose-500/40 text-rose-400 bg-rose-500/10",
    badgeBg: "bg-rose-500/20 text-rose-300 border-rose-500/40",
    iconColor: "text-rose-400",
    divisionId: "devops",
    agents: ORCHESTRATOR_DIVISIONS.find(d => d.id === "devops")?.agents || []
  },
  {
    id: "intelligence",
    mentionTag: "@intelligence",
    name: "🧠 Enterprise Long Coding & Codebase Architect Division",
    shortName: "Intelligence",
    desc: "Spawns 6 architecture agents (Long-Form Codebase Specialist, AST Parser, Repo Topology Mapper, Refactoring Master, Semantic Code Search, Docs)",
    agentCount: ORCHESTRATOR_DIVISIONS.find(d => d.id === "intelligence")?.agents.length || 6,
    color: "border-indigo-500/40 text-indigo-400 bg-indigo-500/10",
    badgeBg: "bg-indigo-500/20 text-indigo-300 border-indigo-500/40",
    iconColor: "text-indigo-400",
    divisionId: "intelligence",
    agents: ORCHESTRATOR_DIVISIONS.find(d => d.id === "intelligence")?.agents || []
  }
];

export interface AtMentionPopoverProps {
  searchQuery: string;
  files: FileNode[];
  onSelectDivision: (action: DivisionActionItem) => void;
  onSelectAgent: (agent: OrchestratorAgent) => void;
  onSelectFile: (file: FileNode) => void;
  onClose: () => void;
}

export const AtMentionPopover: React.FC<AtMentionPopoverProps> = ({
  searchQuery,
  files,
  onSelectDivision,
  onSelectAgent,
  onSelectFile,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<"all" | "divisions" | "agents" | "files">("all");
  const [selectedIndex, setSelectedIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const cleanQuery = (searchQuery || "").trim().toLowerCase();

  // All individual agents
  const allAgents = useMemo(() => {
    return ORCHESTRATOR_DIVISIONS.flatMap(d => d.agents);
  }, []);

  // Filtered lists
  const filteredDivisions = useMemo(() => {
    if (!cleanQuery) return ALL_DIVISION_ACTIONS;
    return ALL_DIVISION_ACTIONS.filter(d => 
      d.mentionTag.toLowerCase().includes(cleanQuery) ||
      d.name.toLowerCase().includes(cleanQuery) ||
      d.shortName.toLowerCase().includes(cleanQuery) ||
      d.desc.toLowerCase().includes(cleanQuery)
    );
  }, [cleanQuery]);

  const filteredAgents = useMemo(() => {
    if (!cleanQuery) return allAgents;
    return allAgents.filter(a => 
      a.id.toLowerCase().includes(cleanQuery) ||
      a.name.toLowerCase().includes(cleanQuery) ||
      a.role.toLowerCase().includes(cleanQuery) ||
      a.desc.toLowerCase().includes(cleanQuery) ||
      a.divisionName.toLowerCase().includes(cleanQuery)
    );
  }, [allAgents, cleanQuery]);

  const filteredFiles = useMemo(() => {
    if (!cleanQuery) return files.slice(0, 12);
    return files.filter(f => 
      f.name.toLowerCase().includes(cleanQuery) ||
      (f.path && f.path.toLowerCase().includes(cleanQuery))
    ).slice(0, 12);
  }, [files, cleanQuery]);

  // Combined flat list for keyboard navigation
  const flatItems = useMemo(() => {
    const list: Array<{ type: "division" | "agent" | "file"; data: any }> = [];
    if (activeTab === "all" || activeTab === "divisions") {
      filteredDivisions.forEach(d => list.push({ type: "division", data: d }));
    }
    if (activeTab === "all" || activeTab === "agents") {
      filteredAgents.forEach(a => list.push({ type: "agent", data: a }));
    }
    if (activeTab === "all" || activeTab === "files") {
      filteredFiles.forEach(f => list.push({ type: "file", data: f }));
    }
    return list;
  }, [activeTab, filteredDivisions, filteredAgents, filteredFiles]);

  useEffect(() => {
    setSelectedIndex(0);
  }, [cleanQuery, activeTab]);

  // Handle keyboard events
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setSelectedIndex(prev => (prev + 1) % (flatItems.length || 1));
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setSelectedIndex(prev => (prev - 1 + (flatItems.length || 1)) % (flatItems.length || 1));
      } else if (e.key === "Enter" || e.key === "Tab") {
        if (flatItems.length > 0 && selectedIndex < flatItems.length) {
          e.preventDefault();
          const item = flatItems[selectedIndex];
          if (item.type === "division") onSelectDivision(item.data);
          else if (item.type === "agent") onSelectAgent(item.data);
          else if (item.type === "file") onSelectFile(item.data);
        }
      } else if (e.key === "Escape") {
        e.preventDefault();
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [flatItems, selectedIndex, onSelectDivision, onSelectAgent, onSelectFile, onClose]);

  const getDivisionIcon = (id: string) => {
    switch (id) {
      case "all":
      case "all_swarm":
        return <Flame size={13} className="text-orange-400 animate-pulse" />;
      case "game_spec":
        return <Gamepad2 size={13} className="text-amber-400" />;
      case "frontend":
        return <Layers size={13} className="text-cyan-400" />;
      case "backend":
        return <Server size={13} className="text-emerald-400" />;
      case "data_cloud":
        return <Database size={13} className="text-blue-400" />;
      case "ai_div":
        return <Brain size={13} className="text-purple-400" />;
      case "mobile_pwa":
        return <Smartphone size={13} className="text-pink-400" />;
      case "algorithms_perf":
        return <Zap size={13} className="text-yellow-400" />;
      case "testing":
        return <ShieldCheck size={13} className="text-teal-400" />;
      case "devops":
        return <Wrench size={13} className="text-rose-400" />;
      case "intelligence":
        return <GitBranch size={13} className="text-indigo-400" />;
      default:
        return <Bot size={13} className="text-orange-400" />;
    }
  };

  return (
    <div 
      ref={containerRef}
      className="absolute bottom-full left-0 mb-2 w-full max-h-[380px] flex flex-col bg-[#0a0b10] border border-zinc-750/80 rounded-xl shadow-2xl z-[200] overflow-hidden text-left backdrop-blur-xl animate-in fade-in slide-in-from-bottom-2 duration-150"
    >
      {/* Header Bar */}
      <div className="p-2.5 border-b border-zinc-800/80 bg-zinc-900/70 flex flex-col gap-2 shrink-0">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles size={12} className="text-orange-400" />
            <span>Direct @ Mention Swarm & Action Launcher</span>
          </span>
          <span className="text-[9px] font-mono text-zinc-500">
            {cleanQuery ? `Filtering: "@${cleanQuery}"` : "Type to filter agents & divisions"}
          </span>
        </div>

        {/* Filter Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
          <button
            type="button"
            onClick={() => setActiveTab("all")}
            className={`px-2.5 py-0.5 rounded-md text-[10px] font-medium transition-all cursor-pointer whitespace-nowrap ${
              activeTab === "all"
                ? "bg-orange-500 text-white shadow-sm font-semibold"
                : "bg-zinc-800/60 text-zinc-400 hover:text-white hover:bg-zinc-800"
            }`}
          >
            🌟 All ({filteredDivisions.length + filteredAgents.length + filteredFiles.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("divisions")}
            className={`px-2.5 py-0.5 rounded-md text-[10px] font-medium transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
              activeTab === "divisions"
                ? "bg-amber-500 text-black font-bold shadow-sm"
                : "bg-zinc-800/60 text-zinc-400 hover:text-white hover:bg-zinc-800"
            }`}
          >
            <Flame size={10} className="text-amber-400" />
            <span>Whole Divisions ({filteredDivisions.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("agents")}
            className={`px-2.5 py-0.5 rounded-md text-[10px] font-medium transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
              activeTab === "agents"
                ? "bg-cyan-500 text-black font-bold shadow-sm"
                : "bg-zinc-800/60 text-zinc-400 hover:text-white hover:bg-zinc-800"
            }`}
          >
            <Bot size={10} className="text-cyan-400" />
            <span>Sub-Agents ({filteredAgents.length})</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("files")}
            className={`px-2.5 py-0.5 rounded-md text-[10px] font-medium transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
              activeTab === "files"
                ? "bg-emerald-500 text-black font-bold shadow-sm"
                : "bg-zinc-800/60 text-zinc-400 hover:text-white hover:bg-zinc-800"
            }`}
          >
            <FileText size={10} className="text-emerald-400" />
            <span>Files ({filteredFiles.length})</span>
          </button>
        </div>
      </div>

      {/* Main Item List */}
      <div className="p-1.5 overflow-y-auto max-h-[290px] space-y-1 custom-scrollbar">
        {flatItems.length === 0 ? (
          <div className="p-6 text-center text-xs text-zinc-500 font-mono">
            No matching divisions, agents, or files found for "@{cleanQuery}"
          </div>
        ) : (
          flatItems.map((item, idx) => {
            const isSelected = idx === selectedIndex;

            if (item.type === "division") {
              const div = item.data as DivisionActionItem;
              return (
                <button
                  key={`div-${div.id}`}
                  type="button"
                  onClick={() => onSelectDivision(div)}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`w-full flex items-center justify-between p-2 rounded-lg text-left transition-all cursor-pointer border ${
                    isSelected 
                      ? "bg-zinc-800/90 border-amber-500/50 shadow-md translate-x-0.5" 
                      : "bg-zinc-900/30 border-white/5 hover:bg-zinc-850 hover:border-zinc-700"
                  }`}
                >
                  <div className="flex items-start gap-2.5 min-w-0 pr-2">
                    <div className="p-1.5 rounded-md bg-zinc-900 border border-white/10 shrink-0 mt-0.5">
                      {getDivisionIcon(div.divisionId)}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono font-bold text-xs text-amber-400 bg-amber-500/10 px-1.5 py-0.2 rounded border border-amber-500/30">
                          {div.mentionTag}
                        </span>
                        <span className="text-xs font-semibold text-zinc-100 truncate">
                          {div.name}
                        </span>
                        <span className="text-[9px] font-mono font-bold text-orange-300 bg-orange-500/20 px-1.5 py-0.2 rounded-full border border-orange-500/40">
                          SPAWN ENTIRE DIVISION ({div.agentCount} AGENTS)
                        </span>
                      </div>
                      <p className="text-[10px] text-zinc-400 line-clamp-1 mt-0.5">
                        {div.desc}
                      </p>
                    </div>
                  </div>
                  <ChevronRight size={13} className={`shrink-0 ${isSelected ? "text-amber-400" : "text-zinc-600"}`} />
                </button>
              );
            }

            if (item.type === "agent") {
              const agent = item.data as OrchestratorAgent;
              return (
                <button
                  key={`agent-${agent.id}`}
                  type="button"
                  onClick={() => onSelectAgent(agent)}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`w-full flex items-center justify-between p-2 rounded-lg text-left transition-all cursor-pointer border ${
                    isSelected 
                      ? "bg-zinc-800/90 border-cyan-500/50 shadow-md translate-x-0.5" 
                      : "bg-zinc-900/30 border-white/5 hover:bg-zinc-850 hover:border-zinc-700"
                  }`}
                >
                  <div className="flex items-start gap-2.5 min-w-0 pr-2">
                    <div className="p-1.5 rounded-md bg-zinc-900 border border-white/10 shrink-0 mt-0.5">
                      <Bot size={13} className="text-cyan-400" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono font-bold text-xs text-cyan-400 bg-cyan-500/10 px-1.5 py-0.2 rounded border border-cyan-500/30">
                          @{agent.id}
                        </span>
                        <span className="text-xs font-semibold text-zinc-200 truncate">
                          {agent.name}
                        </span>
                        <span className="text-[9px] font-mono text-zinc-400 bg-zinc-800 px-1.5 py-0.2 rounded border border-zinc-700">
                          {agent.divisionName}
                        </span>
                      </div>
                      <p className="text-[10px] text-zinc-400 line-clamp-1 mt-0.5">
                        <span className="text-zinc-300 font-medium">{agent.role}:</span> {agent.desc}
                      </p>
                    </div>
                  </div>
                  <ChevronRight size={13} className={`shrink-0 ${isSelected ? "text-cyan-400" : "text-zinc-600"}`} />
                </button>
              );
            }

            if (item.type === "file") {
              const file = item.data as FileNode;
              return (
                <button
                  key={`file-${file.id}`}
                  type="button"
                  onClick={() => onSelectFile(file)}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`w-full flex items-center justify-between p-2 rounded-lg text-left transition-all cursor-pointer border ${
                    isSelected 
                      ? "bg-zinc-800/90 border-emerald-500/50 shadow-md translate-x-0.5" 
                      : "bg-zinc-900/30 border-white/5 hover:bg-zinc-850 hover:border-zinc-700"
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0 pr-2">
                    <div className="p-1.5 rounded-md bg-zinc-900 border border-white/10 shrink-0">
                      <FileText size={13} className="text-emerald-400" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs text-zinc-200 truncate font-medium">
                          {file.name}
                        </span>
                        <span className="text-[8.5px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.2 rounded border border-emerald-500/30 uppercase">
                          {file.language || "FILE"}
                        </span>
                      </div>
                      <p className="text-[9.5px] font-mono text-zinc-500 truncate">
                        {file.path || file.name}
                      </p>
                    </div>
                  </div>
                  <ChevronRight size={13} className={`shrink-0 ${isSelected ? "text-emerald-400" : "text-zinc-600"}`} />
                </button>
              );
            }

            return null;
          })
        )}
      </div>

      {/* Footer Instructions */}
      <div className="p-1.5 px-3 border-t border-zinc-850 bg-black/60 flex items-center justify-between text-[9px] text-zinc-500 font-mono shrink-0">
        <span>↑↓ to navigate • ↵ or Tab to select • Esc to dismiss</span>
        <span className="text-orange-400/80">Direct @ Mention Engine</span>
      </div>
    </div>
  );
};
