import React, { useState, useMemo, useEffect, useRef } from "react";
import {
  Bot,
  User,
  Volume2,
  VolumeX,
  Pin,
  Eye,
  EyeOff,
  Network,
  Trash2,
  Globe,
  ExternalLink,
  FileText,
  ChevronDown,
  ChevronUp,
  Copy,
  Check,
  RotateCcw,
  GitBranch,
  GitCommit as GitCommitIcon,
  FileCode,
  Terminal,
  Play,
  Maximize2,
  Minimize2,
  Edit3,
  RefreshCw,
  ThumbsUp,
  ThumbsDown,
  Sparkles,
  Zap,
  CheckCircle2,
  Layers,
  Code2,
  Scissors,
  X,
  ShieldCheck,
  AlertTriangle,
  MoreVertical,
  History,
  FileDiff,
  Download,
  Share2,
  CornerDownLeft,
  ArrowRight
} from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { ChatMessage as ChatMessageType, FileNode, AgentAction } from "../../../types";
import { ThoughtStreamer } from "./ThoughtStreamer";
import { RichDiffViewer } from "./RichDiffViewer";
import { LiveCodeStreamCard } from "./LiveCodeStreamCard";
import { versionControlService } from "../../../services/versionControlService";
import type { GitCommit, FileChange } from "../../../services/versionControlService";

export interface ChatMessageProps {
  msg: ChatMessageType;
  isProcessing: boolean;
  isCompactMode?: boolean;
  activeSessionMessages?: ChatMessageType[];
  expandedReasoning?: Record<string, boolean>;
  setExpandedReasoning?: React.Dispatch<React.SetStateAction<Record<string, boolean>>>;
  isSpeaking?: string | null;
  handleSpeak?: (text: string, id: string) => void;
  toggleMessageExclusion?: (id: string) => void;
  toggleMessagePin?: (id: string) => void;
  deleteMessage?: (id: string) => void;
  forkSessionAtMessage?: (id: string) => void;
  files?: FileNode[];
  activeFileId?: string | null;
  activeSessionId?: string | null;
  onUpdateFiles?: (files: FileNode[]) => void;
  onAgentAction?: (actions: AgentAction[]) => Promise<void>;
  onEditAndResendMessage?: (id: string, newText: string) => void;
  onRetryMessage?: (id: string) => void;
  onApplyCodeToEditor?: (code: string, language?: string, filename?: string) => void;
  onRunTerminalCommand?: (command: string) => void;
  onFeedback?: (id: string, feedback: "like" | "dislike") => void;
}

/**
 * Interactive Code Block with Copy, Apply, Terminal Run, Line Numbers, and Fullscreen
 */
const EnhancedCodeBlock: React.FC<{
  language: string;
  code: string;
  onApply?: (code: string, language?: string, filename?: string) => void;
  onRunTerminal?: (cmd: string) => void;
}> = ({ language, code, onApply, onRunTerminal }) => {
  const [copied, setCopied] = useState(false);
  const [showLineNumbers, setShowLineNumbers] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [appliedFeedback, setAppliedFeedback] = useState(false);

  // Detect potential filename from first line (e.g. `// src/App.tsx` or `/* App.css */` or `# server.py`)
  const detectedFilename = useMemo(() => {
    const firstLine = code.trim().split("\n")[0] || "";
    const match = firstLine.match(/^(?:\/{2,}|\/\*+|#|<!--)\s*([a-zA-Z0-9_\-./]+\.[a-zA-Z0-9]+)/);
    return match ? match[1] : null;
  }, [code]);

  const isTerminalCommand = useMemo(() => {
    const lang = (language || "").toLowerCase();
    return (
      ["bash", "sh", "shell", "zsh", "terminal", "cmd"].includes(lang) ||
      code.startsWith("npm ") ||
      code.startsWith("git ") ||
      code.startsWith("npx ") ||
      code.startsWith("pnpm ")
    );
  }, [language, code]);

  // Surgical Hunk Detection
  const isSurgicalHunk = useMemo(() => {
    return /<{3,7}\s*(?:SEARCH|ORIGINAL|HEAD)[\s\S]*?={3,7}[\s\S]*?>{3,7}\s*(?:REPLACE|UPDATED|END)?/i.test(code) ||
           (code.includes('@@') && (code.includes('\n-') || code.includes('\n+')));
  }, [code]);

  const hunkCount = useMemo(() => {
    if (!isSurgicalHunk) return 0;
    const matches = code.match(/<{3,7}\s*(?:SEARCH|ORIGINAL|HEAD)/gi);
    return matches ? matches.length : (code.match(/@@\s*-\d+/g)?.length || 1);
  }, [code, isSurgicalHunk]);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleApply = () => {
    if (onApply) {
      onApply(code, language, detectedFilename || undefined);
      setAppliedFeedback(true);
      setTimeout(() => setAppliedFeedback(false), 2500);
    }
  };

  const handleRun = () => {
    if (onRunTerminal) {
      onRunTerminal(code.trim());
    }
  };

  const lines = useMemo(() => code.split("\n"), [code]);

  return (
    <>
      <div className={`my-3.5 rounded-xl overflow-hidden border shadow-xl group/code transition-all ${
        isSurgicalHunk 
          ? "border-purple-500/40 bg-[#080912] hover:border-purple-500/60" 
          : "border-white/10 bg-[#0a0b10] hover:border-white/20"
      }`}>
        {/* Code Block Header */}
        <div className="flex items-center justify-between px-3.5 py-2 bg-white/[0.03] border-b border-white/5 select-none">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-red-500/60" />
              <div className="w-2.5 h-2.5 rounded-full bg-amber-500/60" />
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/60" />
            </div>

            <div className="h-3 w-px bg-white/10 mx-1" />

            <div className="flex items-center gap-1.5">
              {isSurgicalHunk ? (
                <Scissors size={12} className="text-purple-400" />
              ) : (
                <Code2 size={12} className="text-orange-400" />
              )}
              <span className="text-[11px] font-mono font-bold text-white/80 uppercase">
                {language || "code"}
              </span>

              {isSurgicalHunk && (
                <span className="text-[10px] font-mono text-purple-300 bg-purple-500/20 px-2 py-0.5 rounded border border-purple-500/30 flex items-center gap-1 font-bold">
                  <span>Surgical Patch ({hunkCount} {hunkCount === 1 ? 'hunk' : 'hunks'})</span>
                </span>
              )}

              {detectedFilename && (
                <span className="text-[11px] font-mono text-white/50 bg-white/5 px-2 py-0.5 rounded border border-white/5 truncate max-w-[200px]">
                  {detectedFilename}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center gap-1">
            {/* Terminal Run Button (if script or shell) */}
            {isTerminalCommand && onRunTerminal && (
              <button
                onClick={handleRun}
                className="px-2 py-1 rounded-md text-[10px] font-mono bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/20 flex items-center gap-1 transition-all cursor-pointer"
                title="Execute command in terminal"
              >
                <Terminal size={11} />
                <span>Run</span>
              </button>
            )}

            {/* Apply Code to Workspace Editor */}
            {onApply && (
              <button
                onClick={handleApply}
                className={`px-2 py-1 rounded-md text-[10px] font-mono flex items-center gap-1 transition-all cursor-pointer ${
                  appliedFeedback
                    ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold"
                    : isSurgicalHunk
                    ? "bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 font-bold"
                    : "bg-orange-500/15 hover:bg-orange-500/25 text-orange-300 border border-orange-500/20"
                }`}
                title={isSurgicalHunk ? "Apply precision surgical edits without overwriting file" : "Apply code directly to active editor file"}
              >
                {appliedFeedback ? <Check size={11} /> : isSurgicalHunk ? <Scissors size={11} /> : <FileCode size={11} />}
                <span>{appliedFeedback ? "Applied!" : isSurgicalHunk ? `Apply Surgical Patch` : "Apply to Editor"}</span>
              </button>
            )}

            {/* Toggle Line Numbers */}
            <button
              onClick={() => setShowLineNumbers(!showLineNumbers)}
              className={`p-1 rounded-md text-[10px] font-mono transition-all ${
                showLineNumbers ? "text-white/70 bg-white/10" : "text-white/30 hover:text-white"
              }`}
              title="Toggle line numbers"
            >
              #
            </button>

            {/* Copy Button */}
            <button
              onClick={handleCopy}
              className="p-1 rounded-md text-white/40 hover:text-white hover:bg-white/10 transition-all"
              title="Copy code"
            >
              {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
            </button>

            {/* Fullscreen Expansion */}
            <button
              onClick={() => setIsFullscreen(true)}
              className="p-1 rounded-md text-white/40 hover:text-white hover:bg-white/10 transition-all"
              title="Expand full screen"
            >
              <Maximize2 size={12} />
            </button>
          </div>
        </div>

        {/* Code Content */}
        <div className="overflow-x-auto p-3 text-[12px] font-mono leading-relaxed bg-[#050608]">
          <pre className="m-0 p-0">
            <table className="border-collapse w-full">
              <tbody>
                {lines.map((line, idx) => {
                  const isSearchMarker = /^<{3,7}\s*(?:SEARCH|ORIGINAL|HEAD)/i.test(line);
                  const isSeparator = /^={3,7}/i.test(line);
                  const isReplaceMarker = /^>{3,7}\s*(?:REPLACE|UPDATED|END)?/i.test(line);
                  const isUnifiedDel = line.startsWith('-') && !line.startsWith('---');
                  const isUnifiedAdd = line.startsWith('+') && !line.startsWith('+++');

                  let rowStyle = "hover:bg-white/[0.02]";
                  let textStyle = "text-zinc-200";

                  if (isSearchMarker || isUnifiedDel) {
                    rowStyle = "bg-rose-950/20";
                    textStyle = "text-rose-300 font-semibold";
                  } else if (isSeparator) {
                    rowStyle = "bg-purple-950/20";
                    textStyle = "text-purple-300 font-bold";
                  } else if (isReplaceMarker || isUnifiedAdd) {
                    rowStyle = "bg-emerald-950/20";
                    textStyle = "text-emerald-300 font-semibold";
                  }

                  return (
                    <tr key={idx} className={rowStyle}>
                      {showLineNumbers && (
                        <td className="w-8 select-none text-right pr-3 text-[10px] text-white/20 font-mono align-top">
                          {idx + 1}
                        </td>
                      )}
                      <td className={`whitespace-pre overflow-x-auto ${textStyle}`}>{line || " "}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </pre>
        </div>
      </div>

      {/* Fullscreen Code Modal */}
      {isFullscreen && (
        <div className="fixed inset-0 z-[9999] bg-black/90 backdrop-blur-xl flex flex-col p-6 animate-in fade-in duration-150">
          <div className="flex items-center justify-between pb-4 border-b border-white/10 select-none">
            <div className="flex items-center gap-2">
              <Code2 size={16} className="text-orange-400" />
              <span className="text-sm font-mono font-bold text-white uppercase">
                {language || "code"} {detectedFilename ? `• ${detectedFilename}` : ""}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="px-3 py-1.5 rounded-lg text-xs font-mono bg-white/10 hover:bg-white/20 text-white flex items-center gap-1.5 transition-all"
              >
                {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                <span>{copied ? "Copied" : "Copy Code"}</span>
              </button>

              <button
                onClick={() => setIsFullscreen(false)}
                className="p-1.5 rounded-lg bg-white/10 text-white/60 hover:text-white hover:bg-white/20 transition-all"
              >
                <X size={16} />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-auto p-4 bg-[#08090d] rounded-xl border border-white/10 mt-4 font-mono text-sm leading-relaxed">
            <pre className="m-0">
              <table className="border-collapse w-full">
                <tbody>
                  {lines.map((line, idx) => (
                    <tr key={idx} className="hover:bg-white/[0.02]">
                      <td className="w-10 select-none text-right pr-4 text-xs text-white/25 font-mono">
                        {idx + 1}
                      </td>
                      <td className="whitespace-pre text-zinc-200">{line || " "}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </pre>
          </div>
        </div>
      )}
    </>
  );
};

export const renderMessageText = (
  text: string,
  onApply?: (code: string, language?: string, filename?: string) => void,
  onRunTerminal?: (cmd: string) => void
) => {
  return (
    <div className="markdown-body text-[13.5px] leading-[1.65] break-words overflow-x-hidden font-medium text-white/90 space-y-2.5">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          code({ node, inline, className, children, ...props }: any) {
            const match = /language-(\w+)/.exec(className || "");
            const content = String(children).replace(/\n$/, "");

            if (!inline && (match || content.includes("\n"))) {
              return (
                <EnhancedCodeBlock
                  language={match ? match[1] : ""}
                  code={content}
                  onApply={onApply}
                  onRunTerminal={onRunTerminal}
                />
              );
            }

            return (
              <code
                className={`${className} bg-white/10 px-1.5 py-0.5 rounded text-orange-300 font-mono text-[11.5px] border border-white/5 font-semibold`}
                {...props}
              >
                {children}
              </code>
            );
          },
          p: ({ children }) => <p className="mb-3 last:mb-0 leading-relaxed text-zinc-200">{children}</p>,
          h1: ({ children }) => (
            <h1 className="text-lg font-bold tracking-tight mb-3 mt-4 text-white border-b border-white/10 pb-1.5">
              {children}
            </h1>
          ),
          h2: ({ children }) => (
            <h2 className="text-base font-semibold tracking-tight mb-2.5 mt-3.5 text-white/95">
              {children}
            </h2>
          ),
          h3: ({ children }) => (
            <h3 className="text-sm font-semibold mb-2 mt-3 text-white/90">
              {children}
            </h3>
          ),
          ul: ({ children }) => (
            <ul className="list-disc ml-4 mb-3 space-y-1 marker:text-orange-400/60 text-zinc-300 text-[13px]">
              {children}
            </ul>
          ),
          ol: ({ children }) => (
            <ol className="list-decimal ml-4 mb-3 space-y-1 marker:text-orange-400 font-mono text-zinc-300 text-[13px]">
              {children}
            </ol>
          ),
          li: ({ children }) => <li className="pl-1 text-zinc-300">{children}</li>,
          blockquote: ({ children }) => (
            <blockquote className="border-l-2 border-orange-500/50 pl-3.5 py-1 my-3 bg-orange-500/5 rounded-r-lg text-zinc-300 italic text-[12.5px]">
              {children}
            </blockquote>
          ),
          table: ({ children }) => (
            <div className="overflow-x-auto my-3 rounded-lg border border-white/10">
              <table className="min-w-full divide-y divide-white/10 text-xs font-mono">
                {children}
              </table>
            </div>
          ),
          th: ({ children }) => (
            <th className="px-3 py-1.5 text-left bg-white/[0.05] text-white font-bold uppercase tracking-wider text-[10px]">
              {children}
            </th>
          ),
          img: ({ src, alt }: any) => {
            return (
              <div className="my-3 relative group rounded-2xl overflow-hidden border border-purple-500/30 shadow-2xl bg-black/80 max-w-lg transition-all hover:border-purple-500/60">
                <img
                  src={src}
                  alt={alt || "Generated AI Asset"}
                  referrerPolicy="no-referrer"
                  className="w-full h-auto object-cover max-h-[420px] transition-transform duration-300 group-hover:scale-[1.01]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-3 flex items-end justify-between">
                  <div className="truncate pr-2">
                    <span className="text-[11px] font-bold text-white block truncate">{alt || "Generated AI Asset"}</span>
                    <span className="text-[9px] font-mono text-purple-300 uppercase tracking-widest">AI Imagen / Visual Studio</span>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <a
                      href={src}
                      download={`aether_ai_asset_${Date.now()}.png`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-1.5 rounded-lg bg-zinc-900/90 hover:bg-zinc-800 text-white border border-white/20 text-xs font-mono flex items-center gap-1 cursor-pointer transition-colors"
                      title="Download Generated Asset"
                    >
                      <Download size={13} />
                    </a>
                    {onApply && (
                      <button
                        onClick={() => onApply(src, 'image', `public/images/asset_${Date.now()}.png`)}
                        className="p-1.5 rounded-lg bg-purple-600/90 hover:bg-purple-500 text-white border border-purple-400/40 text-xs font-mono flex items-center gap-1 cursor-pointer transition-colors"
                        title="Save Image to Workspace (/public/images/...)"
                      >
                        <FileCode size={13} />
                        <span className="text-[10px] font-bold">Save File</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          },
          td: ({ children }) => (
            <td className="px-3 py-1.5 text-zinc-300 border-t border-white/5">
              {children}
            </td>
          ),
        }}
      >
        {text}
      </ReactMarkdown>
    </div>
  );
};

const TypewriterMarkdown: React.FC<{
  text: string;
  isStreaming: boolean;
  onApplyCodeToEditor?: (code: string, language?: string, filename?: string) => void;
  onRunTerminalCommand?: (cmd: string) => void;
}> = ({ text, isStreaming, onApplyCodeToEditor, onRunTerminalCommand }) => {
  const [displayedLength, setDisplayedLength] = useState(() => (isStreaming ? 0 : text.length));
  const [isTyping, setIsTyping] = useState(false);
  const [isFastForward, setIsFastForward] = useState(false);
  const [soundMuted, setSoundMuted] = useState(true);
  const audioCtxRef = useRef<AudioContext | null>(null);

  const playTypewriterClick = () => {
    if (soundMuted) return;
    try {
      if (!audioCtxRef.current) {
        audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioCtxRef.current;
      if (ctx.state === "suspended") ctx.resume();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(700 + Math.random() * 500, ctx.currentTime);
      gain.gain.setValueAtTime(0.012, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.025);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.025);
    } catch {}
  };

  useEffect(() => {
    if (isFastForward) {
      setDisplayedLength(text.length);
      setIsTyping(false);
      return;
    }

    if (displayedLength < text.length) {
      setIsTyping(true);
      const timer = setTimeout(() => {
        const remaining = text.length - displayedLength;
        const step = remaining > 400 ? Math.ceil(remaining / 10) : remaining > 150 ? 6 : remaining > 40 ? 3 : 1;
        const nextLen = Math.min(text.length, displayedLength + step);
        setDisplayedLength(nextLen);
        if (Math.random() < 0.35) playTypewriterClick();
      }, 12);

      return () => clearTimeout(timer);
    } else {
      setIsTyping(false);
    }
  }, [text, displayedLength, isFastForward]);

  const displayedText = useMemo(() => {
    return text.slice(0, displayedLength);
  }, [text, displayedLength]);

  const handleSkipTypewriter = () => {
    setIsFastForward(true);
    setDisplayedLength(text.length);
  };

  return (
    <div className="relative group/typewriter">
      {(isTyping || isStreaming) && !isFastForward && (
        <div className="flex items-center gap-2 mb-2 px-2.5 py-1 rounded-lg bg-orange-500/10 border border-orange-500/20 text-[10.5px] font-mono text-orange-400 w-fit select-none animate-in fade-in duration-150 shadow-sm">
          <span className="flex items-center gap-1.5 font-bold tracking-wide">
            <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-ping" />
            TYPEWRITER STREAMING
          </span>
          <button
            onClick={() => setSoundMuted(!soundMuted)}
            className="p-0.5 rounded hover:bg-orange-500/20 text-orange-300 transition-colors cursor-pointer"
            title={soundMuted ? "Enable Typewriter Audio Tick" : "Mute Typewriter Audio Tick"}
          >
            {soundMuted ? <VolumeX size={11} /> : <Volume2 size={11} />}
          </button>
          <button
            onClick={handleSkipTypewriter}
            className="px-1.5 py-0.5 rounded bg-orange-500/20 hover:bg-orange-500/40 text-orange-200 border border-orange-500/30 text-[9px] font-bold transition-all cursor-pointer flex items-center gap-1"
            title="Fast forward typing to show full text immediately"
          >
            <span>Instant</span>
            <ArrowRight size={10} />
          </button>
        </div>
      )}

      {renderMessageText(displayedText, onApplyCodeToEditor, onRunTerminalCommand)}

      {(isTyping || isStreaming) && !isFastForward && (
        <span className="inline-block w-2.5 h-4 bg-orange-400/90 ml-1 translate-y-0.5 animate-pulse rounded-xs shadow-[0_0_10px_rgba(249,115,22,0.9)]" />
      )}
    </div>
  );
};

export const stripDeepReasoningTag = (text: string): string => {
  return (text || "")
    .replace(/^\[DEEP REASONING & ORCHESTRATION MODE\]:\s*\n?/i, "")
    .replace(/^\[DEEP REASONING & ORCHESTRATION MODE\]\s*/i, "");
};

export const ChatMessage: React.FC<ChatMessageProps> = ({
  msg,
  isProcessing,
  isCompactMode,
  activeSessionMessages = [],
  expandedReasoning = {},
  setExpandedReasoning,
  isSpeaking,
  handleSpeak,
  toggleMessageExclusion,
  toggleMessagePin,
  deleteMessage,
  forkSessionAtMessage,
  files = [],
  activeFileId,
  activeSessionId,
  onUpdateFiles,
  onAgentAction,
  onEditAndResendMessage,
  onRetryMessage,
  onApplyCodeToEditor,
  onRunTerminalCommand,
  onFeedback
}) => {
  const msgText = useMemo(() => stripDeepReasoningTag(msg.text), [msg.text]);

  // State for in-place prompt editing
  const [isEditingPrompt, setIsEditingPrompt] = useState(false);
  const [editedPromptText, setEditedPromptText] = useState(msgText);

  // State for 3-Dot Action Menu dropdown
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // State for Git Snapshot / Diff Inspector Drawer
  const [showDiffInspector, setShowDiffInspector] = useState(false);
  const [isRestoringCode, setIsRestoringCode] = useState(false);
  const [restoreFeedback, setRestoreFeedback] = useState<string | null>(null);
  const [confirmRestoreModal, setConfirmRestoreModal] = useState(false);

  // State for image lightbox preview
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);
  const [feedbackVote, setFeedbackVote] = useState<"like" | "dislike" | null>(msg.feedback || null);
  const [copiedMsg, setCopiedMsg] = useState(false);

  // Close 3-dot dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    if (isMenuOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isMenuOpen]);

  // Check if associated commit exists for this message
  const associatedCommit: GitCommit | undefined = useMemo(() => {
    try {
      return versionControlService.findCommitForMessage(msg, activeSessionId || undefined);
    } catch {
      return undefined;
    }
  }, [msg, activeSessionId]);

  // Check if this message proposes or has code modifications / snapshots
  const hasCodeChanges = useMemo(() => {
    if (associatedCommit && associatedCommit.changes.length > 0) return true;
    if (msg.commitSnapshot && msg.commitSnapshot.length > 0) return true;
    if (msg.commitHash) return true;
    if (msg.executionSteps && msg.executionSteps.some((s) => s.details?.includes("file") || s.label?.includes("file") || s.label?.includes("create") || s.label?.includes("update"))) {
      return true;
    }
    return false;
  }, [associatedCommit, msg]);

  // Diff changes array to pass to RichDiffViewer
  const fileChanges: FileChange[] = useMemo(() => {
    if (associatedCommit && associatedCommit.changes && associatedCommit.changes.length > 0) {
      return associatedCommit.changes;
    }
    // Synthesize fallback file changes if commitSnapshot is available
    if (msg.commitSnapshot && msg.commitSnapshot.length > 0) {
      return msg.commitSnapshot.map((f) => ({
        path: f.path || f.name,
        status: "modified",
        type: "modified",
        newContent: f.content || "",
        additions: (f.content || "").split("\n").length,
        deletions: 0,
        diffSummary: `Snapshot preserved (${(f.content || "").split("\n").length} lines)`
      }));
    }
    return [];
  }, [associatedCommit, msg.commitSnapshot]);

  // Check if message is currently streaming/generating
  const isCurrentlyStreaming = useMemo(() => {
    if (!isProcessing) return false;
    const lastMsg = activeSessionMessages[activeSessionMessages.length - 1];
    return lastMsg?.id === msg.id && msg.role === "model";
  }, [isProcessing, activeSessionMessages, msg]);

  // Reasoning accordion open/close state
  const isOpenReasoning = useMemo(() => {
    if (isCurrentlyStreaming) return true;
    if (expandedReasoning[msg.id] !== undefined) return expandedReasoning[msg.id];
    return false;
  }, [expandedReasoning, msg.id, isCurrentlyStreaming]);

  const handleToggleReasoning = () => {
    if (setExpandedReasoning) {
      setExpandedReasoning((prev) => ({
        ...prev,
        [msg.id]: !isOpenReasoning,
      }));
    }
  };

  // 1-Click Rollback / Restore to this exact state
  const handleRestoreAllCode = async () => {
    setIsRestoringCode(true);
    try {
      let restoredFiles: FileNode[] = [];
      let commitHashLabel = associatedCommit?.shortHash || msg.commitHash?.slice(0, 7) || "Snapshot";

      if (associatedCommit && associatedCommit.filesSnapshot) {
        const res = await versionControlService.revertToCommit(
          associatedCommit.hash,
          files,
          activeSessionId || undefined
        );
        restoredFiles = res.files;
      } else if (msg.commitSnapshot && msg.commitSnapshot.length > 0) {
        const res = await versionControlService.restoreFromMessageCheckpoint(
          msg,
          files,
          activeSessionId || undefined
        );
        restoredFiles = res.files;
      } else {
        throw new Error("No valid snapshot payload found for this checkpoint.");
      }

      if (onUpdateFiles) {
        onUpdateFiles(restoredFiles);
      }

      setRestoreFeedback(`Workspace successfully reverted to [${commitHashLabel}]!`);
      setConfirmRestoreModal(false);

      setTimeout(() => setRestoreFeedback(null), 4000);
    } catch (err: any) {
      setRestoreFeedback(`Restore failed: ${err.message}`);
      setTimeout(() => setRestoreFeedback(null), 4000);
    } finally {
      setIsRestoringCode(false);
    }
  };

  // Perform selective cherry-pick restore of a single file
  const handleRestoreSingleFile = async (filePath: string) => {
    try {
      const commitHashToUse = associatedCommit?.hash || msg.commitHash;
      if (!commitHashToUse) {
        throw new Error("Commit hash unavailable");
      }

      const res = await versionControlService.restoreSingleFile(
        commitHashToUse,
        filePath,
        files,
        activeSessionId || undefined
      );

      if (onUpdateFiles) {
        onUpdateFiles(res.files);
      }

      setRestoreFeedback(`Restored ${filePath} from snapshot!`);
      setTimeout(() => setRestoreFeedback(null), 3000);
    } catch (err: any) {
      setRestoreFeedback(`File restore error: ${err.message}`);
      setTimeout(() => setRestoreFeedback(null), 3000);
    }
  };

  const handleCopyMessage = () => {
    navigator.clipboard.writeText(msgText);
    setCopiedMsg(true);
    setIsMenuOpen(false);
    setTimeout(() => setCopiedMsg(false), 2000);
  };

  const handleFeedback = (type: "like" | "dislike") => {
    const nextVote = feedbackVote === type ? null : type;
    setFeedbackVote(nextVote);
    if (onFeedback && nextVote) {
      onFeedback(msg.id, nextVote);
    }
    setIsMenuOpen(false);
  };

  const handleSaveAndRegenerate = () => {
    if (editedPromptText.trim() && onEditAndResendMessage) {
      onEditAndResendMessage(msg.id, editedPromptText.trim());
      setIsEditingPrompt(false);
    }
  };

  const wordCount = useMemo(() => msgText.trim().split(/\s+/).length, [msgText]);
  const estimatedTokens = useMemo(() => Math.round(msgText.length / 3.8), [msgText]);

  return (
    <div
      className={`flex flex-col gap-1.5 w-full ${
        msg.role === "user" ? "items-end" : "items-start"
      }`}
    >
      {/* AI Model Header Minimalist Info Bar */}
      {msg.role === "model" && (
        <div className="flex items-center justify-between w-full px-1 mb-0.5 select-none">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-orange-500/15 border border-orange-500/30 flex items-center justify-center text-orange-400">
              <Bot size={11} />
            </div>

            <span className="text-[10px] font-bold text-white/70 uppercase tracking-widest font-mono">
              {msg.modelName || msg.modelId || "Assistant"}
            </span>

            {isCurrentlyStreaming && (
              <span className="text-[9px] text-orange-400 font-mono flex items-center gap-1 bg-orange-500/15 border border-orange-500/30 px-2 py-0.5 rounded-full animate-pulse shadow-[0_0_10px_rgba(249,115,22,0.3)]">
                <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-ping" />
                <span className="font-bold">LIVE STREAMING</span>
              </span>
            )}

            {!isCurrentlyStreaming && msg.latencyMs && (
              <span className="text-[9px] text-amber-400/80 font-mono flex items-center gap-0.5 bg-amber-500/10 px-1.5 py-0.2 rounded-full border border-amber-500/20">
                <Zap size={8} />
                {(msg.latencyMs / 1000).toFixed(1)}s
              </span>
            )}

            {associatedCommit && (
              <span className="text-[9px] font-mono bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-1.5 py-0.2 rounded-full flex items-center gap-1">
                <GitBranch size={8} />
                <span>{associatedCommit.shortHash}</span>
              </span>
            )}
          </div>

          <div className="flex items-center gap-1">
            {/* Minimalist 3-Dot Action Button */}
            <div className="relative" ref={menuRef}>
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="p-1 rounded-md text-white/40 hover:text-white hover:bg-white/10 transition-all cursor-pointer"
                title="Message actions"
              >
                <MoreVertical size={13} />
              </button>

              {/* Minimalist 3-Dot Dropdown Menu */}
              {isMenuOpen && (
                <div className="absolute right-0 top-full mt-1 w-48 rounded-xl bg-[#11131a] border border-white/10 shadow-2xl p-1.5 z-50 animate-in fade-in slide-in-from-top-1 duration-150 text-xs font-mono">
                  {/* Copy Response */}
                  <button
                    onClick={handleCopyMessage}
                    className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors text-left"
                  >
                    {copiedMsg ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                    <span>{copiedMsg ? "Copied" : "Copy Markdown"}</span>
                  </button>

                  {/* Read aloud / TTS */}
                  {handleSpeak && (
                    <button
                      onClick={() => {
                        handleSpeak(msgText, msg.id);
                        setIsMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors text-left"
                    >
                      {isSpeaking === msg.id ? <VolumeX size={12} /> : <Volume2 size={12} />}
                      <span>{isSpeaking === msg.id ? "Stop Reading" : "Read Aloud"}</span>
                    </button>
                  )}

                  {/* Restore / Revert action in menu */}
                  {hasCodeChanges && (
                    <button
                      onClick={() => {
                        setIsMenuOpen(false);
                        setConfirmRestoreModal(true);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10 transition-colors text-left font-semibold"
                    >
                      <RotateCcw size={12} />
                      <span>Revert to this State</span>
                    </button>
                  )}

                  {/* Toggle Diff Inspector */}
                  {fileChanges.length > 0 && (
                    <button
                      onClick={() => {
                        setIsMenuOpen(false);
                        setShowDiffInspector(!showDiffInspector);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors text-left"
                    >
                      <FileDiff size={12} />
                      <span>{showDiffInspector ? "Hide Code Diff" : "View Code Diff"}</span>
                    </button>
                  )}

                  <div className="h-px bg-white/10 my-1" />

                  {/* Like / Dislike Feedback */}
                  <div className="flex items-center justify-between px-2.5 py-1 text-white/50 text-[11px]">
                    <span>Rate response:</span>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleFeedback("like")}
                        className={`p-1 rounded hover:bg-white/10 ${feedbackVote === "like" ? "text-emerald-400" : "text-white/40"}`}
                      >
                        <ThumbsUp size={11} />
                      </button>
                      <button
                        onClick={() => handleFeedback("dislike")}
                        className={`p-1 rounded hover:bg-white/10 ${feedbackVote === "dislike" ? "text-rose-400" : "text-white/40"}`}
                      >
                        <ThumbsDown size={11} />
                      </button>
                    </div>
                  </div>

                  {/* Pin Focus */}
                  {toggleMessagePin && (
                    <button
                      onClick={() => {
                        toggleMessagePin(msg.id);
                        setIsMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-white/70 hover:text-orange-400 hover:bg-white/10 transition-colors text-left"
                    >
                      <Pin size={12} className={msg.isPinned ? "text-orange-400" : ""} />
                      <span>{msg.isPinned ? "Unpin Message" : "Pin Message"}</span>
                    </button>
                  )}

                  {/* Memory Exclusion */}
                  {toggleMessageExclusion && (
                    <button
                      onClick={() => {
                        toggleMessageExclusion(msg.id);
                        setIsMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors text-left"
                    >
                      {msg.isExcluded ? <Eye size={12} /> : <EyeOff size={12} />}
                      <span>{msg.isExcluded ? "Include in Context" : "Exclude from Context"}</span>
                    </button>
                  )}

                  {/* Fork Chat */}
                  {forkSessionAtMessage && (
                    <button
                      onClick={() => {
                        forkSessionAtMessage(msg.id);
                        setIsMenuOpen(false);
                      }}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-white/70 hover:text-emerald-400 hover:bg-white/10 transition-colors text-left"
                    >
                      <Network size={12} />
                      <span>Fork Chat</span>
                    </button>
                  )}

                  {/* Delete message */}
                  {deleteMessage && (
                    <>
                      <div className="h-px bg-white/10 my-1" />
                      <button
                        onClick={() => {
                          deleteMessage(msg.id);
                          setIsMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 transition-colors text-left"
                      >
                        <Trash2 size={12} />
                        <span>Delete Message</span>
                      </button>
                    </>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Main Message Bubble Container */}
      <div
        className={`relative max-w-[88%] sm:max-w-[82%] group transition-all duration-200 ${
          msg.isExcluded
            ? "opacity-40 text-white/50"
            : msg.isPinned
            ? "border border-orange-500/30 bg-orange-500/[0.02] rounded-xl p-2.5 sm:p-3 shadow"
            : msg.role === "user"
            ? `${
                isCompactMode
                  ? "bg-zinc-800/90 text-white border border-white/10 rounded-lg px-2.5 py-1.5 shadow"
                  : "bg-zinc-800/95 text-white border border-white/10 rounded-xl px-3 py-2 shadow-md ml-auto"
              }`
            : hasCodeChanges
            ? `${
                isCompactMode
                  ? "bg-[#0b0c12]/95 border border-emerald-500/20 text-white/95 rounded-lg p-2.5 shadow w-full"
                  : "bg-[#08090d]/95 border border-emerald-500/25 text-white/95 rounded-xl p-3 shadow-lg w-full"
              }`
            : `${
                isCompactMode
                  ? "bg-[#0d0e14]/90 border border-white/10 text-white/95 rounded-lg px-2.5 py-2 shadow backdrop-blur-xl w-full"
                  : "bg-[#090a0f]/90 border border-white/10 text-white/95 rounded-xl px-3 py-2.5 shadow-md backdrop-blur-xl w-full"
              }`
        }`}
      >
        {/* Status Badges */}
        <div className="flex flex-wrap items-center gap-1 mb-1 select-none">
          {msg.isExcluded && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[8px] font-bold bg-red-500/15 text-red-400 border border-red-500/30 uppercase font-mono">
              <EyeOff size={8} /> Excluded from Context
            </span>
          )}
          {msg.isPinned && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[8px] font-bold bg-orange-500/15 text-orange-400 border border-orange-500/30 uppercase font-mono">
              <Pin size={8} /> Pinned
            </span>
          )}
        </div>

        {/* User Identity Bar (minimalist header for user message) */}
        {msg.role === "user" && (
          <div className="flex items-center justify-between gap-2 pb-1.5 mb-2 border-b border-white/10 text-[10px] font-medium text-white/60 select-none">
            <div className="flex items-center gap-1.5">
              <div className="w-4 h-4 rounded-full bg-white/10 flex items-center justify-center">
                <User size={10} className="text-white/80" />
              </div>
              <span className="font-bold text-white/80">You</span>
            </div>

            <div className="flex items-center gap-2 text-[9px] font-mono text-white/40">
              <span>
                {new Date(msg.timestamp).toLocaleTimeString([], {
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </span>

              {/* 3-Dot Action Menu for User Bubble */}
              <div className="relative" ref={menuRef}>
                <button
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                  className="p-1 rounded hover:bg-white/10 text-white/40 hover:text-white transition-all cursor-pointer"
                  title="Prompt options"
                >
                  <MoreVertical size={11} />
                </button>

                {isMenuOpen && (
                  <div className="absolute right-0 top-full mt-1 w-44 rounded-xl bg-[#11131a] border border-white/10 shadow-2xl p-1.5 z-50 animate-in fade-in slide-in-from-top-1 duration-150 text-xs font-mono">
                    {/* Edit prompt in place */}
                    {onEditAndResendMessage && (
                      <button
                        onClick={() => {
                          setIsEditingPrompt(true);
                          setIsMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors text-left"
                      >
                        <Edit3 size={11} />
                        <span>Edit Prompt</span>
                      </button>
                    )}

                    {/* Re-run */}
                    {onRetryMessage && (
                      <button
                        onClick={() => {
                          onRetryMessage(msg.id);
                          setIsMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-white/70 hover:text-orange-400 hover:bg-white/10 transition-colors text-left"
                      >
                        <RefreshCw size={11} />
                        <span>Re-run Query</span>
                      </button>
                    )}

                    {/* Copy text */}
                    <button
                      onClick={handleCopyMessage}
                      className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors text-left"
                    >
                      {copiedMsg ? <Check size={11} className="text-emerald-400" /> : <Copy size={11} />}
                      <span>{copiedMsg ? "Copied" : "Copy Text"}</span>
                    </button>

                    {/* Pin Focus */}
                    {toggleMessagePin && (
                      <button
                        onClick={() => {
                          toggleMessagePin(msg.id);
                          setIsMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-white/70 hover:text-orange-400 hover:bg-white/10 transition-colors text-left"
                      >
                        <Pin size={11} />
                        <span>{msg.isPinned ? "Unpin Focus" : "Pin Focus"}</span>
                      </button>
                    )}

                    {/* Exclude Memory */}
                    {toggleMessageExclusion && (
                      <button
                        onClick={() => {
                          toggleMessageExclusion(msg.id);
                          setIsMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition-colors text-left"
                      >
                        {msg.isExcluded ? <Eye size={11} /> : <EyeOff size={11} />}
                        <span>{msg.isExcluded ? "Add to Memory" : "Mute Memory"}</span>
                      </button>
                    )}

                    {/* Fork branch */}
                    {forkSessionAtMessage && (
                      <button
                        onClick={() => {
                          forkSessionAtMessage(msg.id);
                          setIsMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-white/70 hover:text-emerald-400 hover:bg-white/10 transition-colors text-left"
                      >
                        <Network size={11} />
                        <span>Fork Branch</span>
                      </button>
                    )}

                    {/* Delete */}
                    {deleteMessage && (
                      <>
                        <div className="h-px bg-white/10 my-1" />
                        <button
                          onClick={() => {
                            deleteMessage(msg.id);
                            setIsMenuOpen(false);
                          }}
                          className="w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 transition-colors text-left"
                        >
                          <Trash2 size={11} />
                          <span>Delete</span>
                        </button>
                      </>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* 
          WRAPPER STRUCTURE: 
          When AI proposes or applies code modifications: 
          Sleek Banner with "Restore to this state" (One-Click Revert) + "View Code Diff" 
        */}
        {msg.role === "model" && hasCodeChanges && (
          <div className="mb-2 rounded-lg bg-emerald-950/20 border border-emerald-500/20 px-2.5 py-1.5 select-none">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 min-w-0">
                <GitCommitIcon size={12} className="text-emerald-400 shrink-0" />
                <span className="text-[10.5px] font-semibold text-emerald-300 font-mono shrink-0">
                  Code Changes
                </span>
                {associatedCommit && (
                  <span className="text-[9px] bg-emerald-500/20 text-emerald-300 px-1 py-0.2 rounded font-mono font-medium hidden sm:inline">
                    {associatedCommit.shortHash}
                  </span>
                )}
              </div>

              {/* Action Buttons: View Diff & 1-Click Revert */}
              <div className="flex items-center gap-1 ml-auto shrink-0">
                {fileChanges.length > 0 && (
                  <button
                    onClick={() => setShowDiffInspector(!showDiffInspector)}
                    className={`px-1.5 py-0.5 rounded text-[9.5px] font-mono flex items-center gap-1 transition-all cursor-pointer ${
                      showDiffInspector
                        ? "bg-white/15 text-white"
                        : "bg-white/5 hover:bg-white/10 text-zinc-300"
                    }`}
                    title="View code diff comparison"
                  >
                    <FileDiff size={10} className="text-emerald-400" />
                    <span>{showDiffInspector ? "Hide" : "Diff"}</span>
                  </button>
                )}

                {/* ONE-CLICK REVERT / RESTORE BUTTON */}
                <button
                  onClick={() => setConfirmRestoreModal(true)}
                  disabled={isRestoringCode}
                  className="px-2 py-0.5 rounded text-[9.5px] font-mono font-semibold bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 flex items-center gap-1 shadow-sm transition-all cursor-pointer"
                  title="Revert workspace files to this exact state"
                >
                  <RotateCcw size={10} className={isRestoringCode ? "animate-spin" : ""} />
                  <span>Restore</span>
                </button>
              </div>
            </div>

            {/* Restore Notification Toast */}
            {restoreFeedback && (
              <div className="mt-1.5 px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-[10px] font-mono flex items-center gap-1">
                <CheckCircle2 size={11} className="text-emerald-400" />
                <span>{restoreFeedback}</span>
              </div>
            )}

            {/* Rich Code Diff Viewer (Inline Expandable) */}
            {showDiffInspector && fileChanges.length > 0 && (
              <div className="mt-2 pt-1.5 border-t border-emerald-500/20 animate-in fade-in slide-in-from-top-1 duration-150">
                <RichDiffViewer
                  changes={fileChanges}
                  onRestoreSingleFile={handleRestoreSingleFile}
                />
              </div>
            )}
          </div>
        )}

        {/* Reasoning Dropdown Accordion */}
        {(() => {
          const hasThoughtsOrSteps = !!(
            msg.thoughts ||
            (msg.reasoningSteps && msg.reasoningSteps.length > 0)
          );
          const shouldDisplay = hasThoughtsOrSteps || (isCurrentlyStreaming && msg.role === "model");

          if (!shouldDisplay) return null;

          return (
            <div className="mb-3 border border-blue-500/15 rounded-xl bg-[#08090e] overflow-hidden shadow-sm transition-all">
              <button
                onClick={handleToggleReasoning}
                className="w-full flex items-center justify-between p-2.5 bg-blue-950/10 hover:bg-blue-950/20 border-b border-white/5 transition-colors group cursor-pointer text-left"
              >
                <div className="flex items-center gap-2">
                  <div className="relative flex items-center justify-center">
                    {isCurrentlyStreaming && (
                      <span className="absolute inline-flex h-2 w-2 rounded-full bg-blue-500/30 animate-ping" />
                    )}
                    <span
                      className={`relative inline-flex rounded-full h-1.5 w-1.5 ${
                        isCurrentlyStreaming ? "bg-blue-500 animate-pulse" : "bg-blue-500/40"
                      }`}
                    />
                  </div>
                  <span className="text-[10px] font-semibold text-blue-400 font-mono tracking-wide">
                    {isCurrentlyStreaming ? "Thinking..." : "Thought Process"}
                  </span>
                </div>
                <ChevronDown
                  size={12}
                  className={`text-white/40 group-hover:text-white/70 transition-transform duration-200 ${
                    isOpenReasoning ? "rotate-180" : ""
                  }`}
                />
              </button>

              {isOpenReasoning && (
                <div className="p-3 bg-transparent divide-y divide-white/5 text-[11px] font-mono leading-[1.6]">
                  {msg.thoughts && (
                    <div className="pb-2.5 text-zinc-400 whitespace-pre-wrap leading-relaxed font-sans text-[12px]">
                      {msg.thoughts}
                    </div>
                  )}
                  <ThoughtStreamer msg={msg} isCurrentlyStreaming={isCurrentlyStreaming} />
                </div>
              )}
            </div>
          );
        })()}

        {/* User In-Place Edit Mode vs Standard Text */}
        {isEditingPrompt ? (
          <div className="space-y-2.5 pt-1">
            <div className="text-[10.5px] font-bold text-orange-400 uppercase tracking-wider font-mono flex items-center gap-1.5">
              <Edit3 size={11} /> Edit Prompt & Re-send
            </div>
            <textarea
              value={editedPromptText}
              onChange={(e) => setEditedPromptText(e.target.value)}
              className="w-full h-24 p-2.5 rounded-xl bg-black/60 border border-white/20 text-xs font-sans text-white focus:outline-none focus:border-orange-500/60 leading-relaxed resize-y"
              placeholder="Edit your prompt..."
              autoFocus
            />
            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setIsEditingPrompt(false)}
                className="px-2.5 py-1 rounded-lg text-xs font-mono bg-white/5 hover:bg-white/10 text-white/60 hover:text-white transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveAndRegenerate}
                className="px-3.5 py-1 rounded-lg text-xs font-mono font-bold bg-orange-500 hover:bg-orange-600 text-white shadow-lg flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <RefreshCw size={11} />
                <span>Save & Run</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-2">
            {/* Live Streaming HUD Bar */}
            {isCurrentlyStreaming && msg.role === "model" && (
              <div className="flex items-center justify-between px-2.5 py-1 rounded-lg bg-orange-500/10 border border-orange-500/20 text-[11px] font-mono text-orange-300 mb-2">
                <div className="flex items-center gap-2">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-orange-500" />
                  </span>
                  <span className="font-semibold tracking-wide">
                    {msg.streamMetrics?.activeFile ? `Synthesizing ${msg.streamMetrics.activeFile}` : 'Streaming Response...'}
                  </span>
                </div>
                {msg.streamMetrics?.tokensPerSec ? (
                  <span className="text-[10px] text-orange-400/80 bg-orange-500/10 px-1.5 py-0.5 rounded border border-orange-500/15">
                    ⚡ {msg.streamMetrics.tokensPerSec} tok/s
                  </span>
                ) : null}
              </div>
            )}

            <div
              className={`${
                isCompactMode ? "text-[13px] leading-relaxed" : "text-[13.5px]"
              } ${msg.role === "user" ? "text-white/95" : "text-white/85"}`}
            >
              {msg.role === "user" ? (
                renderMessageText(msgText, onApplyCodeToEditor, onRunTerminalCommand)
              ) : (
                <TypewriterMarkdown
                  text={msgText}
                  isStreaming={isCurrentlyStreaming}
                  onApplyCodeToEditor={onApplyCodeToEditor}
                  onRunTerminalCommand={onRunTerminalCommand}
                />
              )}
            </div>
          </div>
        )}

        {/* Live Code Stream Card if code is streaming / present in fragment */}
        {msg.currentCodeFragment && (
          <LiveCodeStreamCard
            currentCodeFragment={msg.currentCodeFragment}
            isStreaming={isCurrentlyStreaming}
            onApplyCode={onApplyCodeToEditor}
            onRunTerminal={onRunTerminalCommand}
          />
        )}

        {/* Action History / Execution Steps Accordion (Minimalist) */}
        {msg.executionSteps && msg.executionSteps.length > 0 && (
          <details className="mt-3 group/actions bg-white/[0.02] border border-emerald-500/15 rounded-xl overflow-hidden [&_summary::-webkit-details-marker]:hidden">
            <summary className="text-[9.5px] font-semibold text-emerald-400 uppercase tracking-wider flex items-center justify-between p-2 cursor-pointer hover:bg-white/5 transition-colors select-none">
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                Actions ({msg.executionSteps.length})
              </div>
              <ChevronDown size={11} className="text-white/40 group-open/actions:rotate-180 transition-transform" />
            </summary>
            <div className="p-3 pt-1 border-t border-white/5 space-y-1.5">
              {msg.executionSteps.map((step) => (
                <div
                  key={step.id}
                  className="flex items-start gap-2 bg-black/40 px-2.5 py-1.5 rounded-lg border border-white/5 text-xs font-mono"
                >
                  <div className="mt-1 flex-shrink-0">
                    {step.status === "success" ? (
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    ) : step.status === "error" ? (
                      <div className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                    ) : (
                      <div className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" />
                    )}
                  </div>
                  <div className="flex flex-col flex-1 min-w-0">
                    <span className="text-[11px] text-white/80 break-all">{step.label}</span>
                    {step.details && (
                      <span className="text-[9.5px] text-white/40">{step.details}</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </details>
        )}

        {/* Attachments Display */}
        {msg.attachments && msg.attachments.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-3">
            {msg.attachments.map((att, i) => (
              <div key={i} className="group/att relative">
                {att.type === "image" && att.url ? (
                  <div
                    onClick={() => setLightboxImage(att.url)}
                    className="relative rounded-xl overflow-hidden border border-white/10 shadow-lg cursor-pointer hover:border-orange-500/40 transition-all"
                  >
                    <img
                      src={att.url}
                      alt={att.name}
                      className="h-20 w-20 object-cover hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 bg-white/5 px-3 py-1.5 rounded-lg border border-white/5 text-[11px] text-white/80 hover:bg-white/10 transition-colors">
                    <FileText size={12} className="text-white/40" />
                    <span className="font-semibold">{att.name}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Grounding & Web References */}
        {msg.groundingLinks && msg.groundingLinks.length > 0 && (
          <div className="mt-4 pt-3 border-t border-white/10 space-y-2">
            <div className="flex items-center gap-1.5 text-[9.5px] text-white/40 uppercase font-semibold tracking-wider">
              <Globe size={10} className="text-blue-400" />
              <span>Grounding Sources</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {msg.groundingLinks.map((link, idx) => (
                <a
                  key={idx}
                  href={link.uri}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 px-2.5 py-1 bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg text-[10.5px] text-white/80 truncate max-w-full transition-colors font-medium"
                >
                  <ExternalLink size={9} className="text-white/40" />
                  <span className="truncate max-w-[180px]">{link.title || "Reference"}</span>
                </a>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Confirmation Modal for One-Click Rollback / Restore */}
      {confirmRestoreModal && (
        <div className="fixed inset-0 z-[9999] bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-150">
          <div className="max-w-md w-full bg-[#10121a] border border-emerald-500/30 rounded-2xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <RotateCcw size={18} />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Restore Workspace to this State?</h3>
                <span className="text-xs text-emerald-400/80 font-mono">
                  Checkpoint: {associatedCommit?.shortHash || msg.commitHash?.slice(0, 7) || "Milestone"}
                </span>
              </div>
            </div>

            <p className="text-xs text-zinc-300 leading-relaxed">
              This will instantly restore all files in your workspace to the exact state at this AI checkpoint.
              An automatic rollback snapshot of your current files will be created in your version history.
            </p>

            {associatedCommit && (
              <div className="p-3 rounded-xl bg-black/50 border border-white/5 text-xs font-mono space-y-1">
                <div className="text-white/50 text-[10px] uppercase font-bold">Snapshot Details:</div>
                <div className="text-emerald-300">
                  {associatedCommit.changes.length} files modified (+{associatedCommit.stats.additions}/-{associatedCommit.stats.deletions} lines)
                </div>
              </div>
            )}

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                onClick={() => setConfirmRestoreModal(false)}
                className="px-3.5 py-1.5 rounded-xl text-xs font-mono bg-white/5 hover:bg-white/10 text-white/70 hover:text-white transition-all cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleRestoreAllCode}
                disabled={isRestoringCode}
                className="px-4 py-1.5 rounded-xl text-xs font-mono font-bold bg-emerald-500 hover:bg-emerald-600 text-white shadow-lg flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Check size={13} />
                <span>{isRestoringCode ? "Restoring..." : "Confirm & Restore"}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Image Lightbox Modal */}
      {lightboxImage && (
        <div
          onClick={() => setLightboxImage(null)}
          className="fixed inset-0 z-[9999] bg-black/90 backdrop-blur-xl flex items-center justify-center p-4 cursor-zoom-out"
        >
          <div className="relative max-w-4xl max-h-[90vh] overflow-hidden rounded-2xl border border-white/10 shadow-2xl">
            <img src={lightboxImage} alt="Preview" className="max-w-full max-h-[85vh] object-contain" />
            <button
              onClick={() => setLightboxImage(null)}
              className="absolute top-3 right-3 p-2 rounded-full bg-black/60 text-white hover:bg-black transition-all"
            >
              <X size={18} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
