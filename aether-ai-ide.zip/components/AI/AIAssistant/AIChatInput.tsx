import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { processUploadedFiles } from "../../../services/fileService";
import { 
  ArrowUp, 
  Paperclip, 
  Wand2, 
  Image as ImageIcon, 
  FileText, 
  MicOff, 
  Mic, 
  Camera, 
  X, 
  Loader2,
  ArrowUpRight,
  Radio,
  Link2,
  Globe,
  Upload,
  FolderOpen,
  FileCode,
  Check
} from "lucide-react";
import { AtMentionPopover, DivisionActionItem } from "./AtMentionDropdown";
import { OrchestratorAgent } from "./orchestratorClassifier";

interface AIChatInputProps {
  input: string;
  setInput: (val: string) => void;
  isProcessing: boolean;
  isEnhancing: boolean;
  isListening: boolean;
  isTyping: string | null;
  attachments: any[];
  setAttachments: React.Dispatch<React.SetStateAction<any[]>>;
  handleSend: () => void;
  handleEnhance: () => void;
  handleCapturePreview: () => void;
  toggleVoiceInput: () => void;
  onOpenVoiceModal?: () => void;
  onStopProcessing: () => void;
  textareaRef: React.RefObject<HTMLTextAreaElement>;
  fileInputRef: React.RefObject<HTMLInputElement>;
  folderInputRef: React.RefObject<HTMLInputElement>;
  imageInputRef: React.RefObject<HTMLInputElement>;
  handleFileUpload: (e: React.ChangeEvent<HTMLInputElement>, type: "image" | "file") => void;
  handleKeyDown: (e: React.KeyboardEvent) => void;
  dynamicShortcuts: any[];
  onSendMessage: (prompt: string, attachments: any[], model: string) => void;
  selectedModel: string;
  referencedFiles: any[];
  setReferencedFiles: React.Dispatch<React.SetStateAction<any[]>>;
  showFileDropdown: boolean;
  filteredFiles: any[];
  handleSelectFileRef: (file: any) => void;
  showAtMentionDropdown?: boolean;
  atMentionSearchQuery?: string;
  files?: any[];
  onSelectDivisionMention?: (division: DivisionActionItem) => void;
  onSelectAgentMention?: (agent: OrchestratorAgent) => void;
  onCloseAtMention?: () => void;
}

export const AIChatInput: React.FC<AIChatInputProps> = ({
  input,
  setInput,
  isProcessing,
  isEnhancing,
  isListening,
  isTyping,
  attachments,
  setAttachments,
  handleSend,
  handleEnhance,
  handleCapturePreview,
  toggleVoiceInput,
  onOpenVoiceModal,
  onStopProcessing,
  textareaRef,
  fileInputRef,
  folderInputRef,
  imageInputRef,
  handleFileUpload,
  handleKeyDown,
  dynamicShortcuts,
  onSendMessage,
  selectedModel,
  referencedFiles,
  setReferencedFiles,
  showFileDropdown,
  filteredFiles,
  handleSelectFileRef,
  showAtMentionDropdown,
  atMentionSearchQuery = "",
  files = [],
  onSelectDivisionMention,
  onSelectAgentMention,
  onCloseAtMention,
}) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [showLinkModal, setShowLinkModal] = useState(false);
  const [linkInputValue, setLinkInputValue] = useState("");
  const [isLoadingLink, setIsLoadingLink] = useState(false);

  // Direct Clipboard Paste Handler (Images, URLs, Files)
  const handlePaste = (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    const clipboardData = e.clipboardData;
    if (!clipboardData) return;

    // 1. Check for image files in clipboard
    const items = clipboardData.items;
    let foundImage = false;

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (item.type.startsWith("image/")) {
        const file = item.getAsFile();
        if (file) {
          foundImage = true;
          const reader = new FileReader();
          reader.onload = (ev) => {
            const result = ev.target?.result as string;
            const base64 = result.split(",")[1];
            setAttachments((prev) => [
              ...prev,
              {
                name: `pasted-image-${Date.now()}.${file.type.split("/")[1] || "png"}`,
                type: "image",
                mimeType: file.type || "image/png",
                data: base64,
              },
            ]);
          };
          reader.readAsDataURL(file);
        }
      }
    }

    // 2. Check for pasted direct image URL or web link
    const textData = clipboardData.getData("text");
    if (textData && !foundImage) {
      const trimmed = textData.trim();
      const isImgUrl = /^https?:\/\/.*\.(png|jpg|jpeg|webp|gif|svg)(\?.*)?$/i.test(trimmed);
      const isGeneralUrl = /^https?:\/\/[^\s]+$/i.test(trimmed);

      if (isImgUrl) {
        // Automatically add image URL reference chip
        setAttachments((prev) => [
          ...prev,
          {
            name: trimmed.split("/").pop()?.split("?")[0] || "image-link",
            type: "image-url",
            url: trimmed,
            mimeType: "image/url",
          },
        ]);
      } else if (isGeneralUrl && trimmed.length < 300) {
        // If it's a documentation, API, or web link, optionally add link badge
        setAttachments((prev) => [
          ...prev,
          {
            name: trimmed.replace(/^https?:\/\/(www\.)?/, "").slice(0, 30),
            type: "link",
            url: trimmed,
            mimeType: "text/url",
          },
        ]);
      }
    }
  };

  // Drag and Drop files / images directly onto Chat Input
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const droppedFiles = e.dataTransfer.files;
    if (droppedFiles && droppedFiles.length > 0) {
      const processed = await processUploadedFiles(droppedFiles);
      processed.forEach((file) => {
        const isImg = file.name.match(/\.(png|jpg|jpeg|webp|gif|svg)$/i);
        setAttachments((prev) => [
          ...prev,
          {
            name: file.name,
            type: isImg ? "image" : "file",
            mimeType: isImg ? `image/${file.name.split('.').pop() || 'png'}` : "text/plain",
            data: btoa(unescape(encodeURIComponent(file.content))),
          },
        ]);
      });
    }
  };

  // Add Link as Context (Image URL or Webpage URL)
  const handleAddLinkSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!linkInputValue.trim()) return;

    const url = linkInputValue.trim();
    setIsLoadingLink(true);

    try {
      const isImgUrl = /^https?:\/\/.*\.(png|jpg|jpeg|webp|gif|svg)(\?.*)?$/i.test(url);
      if (isImgUrl) {
        setAttachments((prev) => [
          ...prev,
          {
            name: url.split("/").pop()?.split("?")[0] || "image-link",
            type: "image-url",
            url,
            mimeType: "image/url",
          },
        ]);
      } else {
        setAttachments((prev) => [
          ...prev,
          {
            name: url.replace(/^https?:\/\/(www\.)?/, "").slice(0, 30),
            type: "link",
            url,
            mimeType: "text/url",
          },
        ]);
      }
      setLinkInputValue("");
      setShowLinkModal(false);
    } finally {
      setIsLoadingLink(false);
    }
  };

  return (
    <div className="p-2 pb-[calc(0.5rem+env(safe-area-inset-bottom))] bg-black/90 backdrop-blur-sm shrink-0 relative border-t border-white/5">
      {/* Input Bar */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`relative bg-[#0b0c10] border transition-all duration-200 rounded-xl shadow-lg backdrop-blur-xl ${
          isDragOver ? "border-orange-500 ring-2 ring-orange-500/30 bg-orange-500/5" : ""
        } ${isProcessing ? "border-zinc-800/50 opacity-60" : "border-zinc-800 focus-within:border-orange-500/40 focus-within:bg-[#0e1017]"}`}
      >
        {/* Drag Overlay Banner */}
        {isDragOver && (
          <div className="absolute inset-0 bg-orange-500/10 backdrop-blur-sm z-50 rounded-xl flex items-center justify-center gap-2 text-orange-400 font-bold text-xs pointer-events-none">
            <Upload size={16} className="animate-bounce" />
            <span>Drop images or files to attach to AI prompt</span>
          </div>
        )}

        {/* Link Input Modal / Popover */}
        {showLinkModal && (
          <div className="absolute bottom-full left-2 right-2 mb-2 bg-[#0c0e14] border border-zinc-700/80 rounded-xl p-3 shadow-2xl z-50 animate-in fade-in slide-in-from-bottom-2">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold text-white flex items-center gap-1.5">
                <Link2 size={13} className="text-orange-400" />
                Attach Image URL or Web Reference
              </span>
              <button
                type="button"
                onClick={() => setShowLinkModal(false)}
                className="text-zinc-500 hover:text-white p-0.5"
              >
                <X size={12} />
              </button>
            </div>
            <form onSubmit={handleAddLinkSubmit} className="flex gap-2">
              <input
                autoFocus
                type="url"
                value={linkInputValue}
                onChange={(e) => setLinkInputValue(e.target.value)}
                placeholder="https://example.com/mockup.png or API documentation URL..."
                className="flex-1 bg-black/70 border border-zinc-700 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder:text-zinc-500 outline-none focus:border-orange-500 font-mono"
              />
              <button
                type="submit"
                disabled={isLoadingLink || !linkInputValue.trim()}
                className="px-3 py-1.5 bg-orange-500 hover:bg-orange-600 text-black text-xs font-bold rounded-lg transition-colors cursor-pointer disabled:opacity-50"
              >
                {isLoadingLink ? <Loader2 size={12} className="animate-spin" /> : "Attach"}
              </button>
            </form>
          </div>
        )}

        {/* Unified @ Mention (Divisions, Agents, Files) Popover */}
        {showAtMentionDropdown && onSelectDivisionMention && onSelectAgentMention && (
          <AtMentionPopover
            searchQuery={atMentionSearchQuery}
            files={files}
            onSelectDivision={onSelectDivisionMention}
            onSelectAgent={onSelectAgentMention}
            onSelectFile={handleSelectFileRef}
            onClose={onCloseAtMention || (() => {})}
          />
        )}

        {/* Autocomplete file reference popover fallback */}
        {!showAtMentionDropdown && showFileDropdown && (
          <div className="absolute bottom-full left-0 mb-1.5 w-full max-h-48 overflow-y-auto bg-[#0a0b10] border border-zinc-800 rounded-xl shadow-2xl z-[150] no-scrollbar text-left">
            <div className="p-1.5 border-b border-zinc-850 bg-zinc-900/40 flex items-center justify-between">
              <span className="text-[9.5px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1">
                <FileText size={10} className="text-orange-500" /> Reference File Context
              </span>
              <span className="text-[8.5px] text-zinc-500">
                Type to filter...
              </span>
            </div>
            <div className="p-1">
              {filteredFiles.length > 0 ? (
                filteredFiles.map((file) => (
                  <button
                    key={file.id}
                    onClick={() => handleSelectFileRef(file)}
                    className="w-full flex items-center justify-between px-2.5 py-1.5 text-xs text-left text-zinc-300 hover:text-white hover:bg-zinc-900 rounded-md transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-1.5">
                      <FileText size={11} className="text-zinc-500 group-hover:text-orange-500" />
                      <span className="font-mono text-[11px]">{file.name}</span>
                    </div>
                    <span className="text-[8.5px] text-zinc-600 uppercase font-mono">{file.language}</span>
                  </button>
                ))
              ) : (
                <div className="p-2 text-center text-xs text-zinc-500 font-mono">
                  No matching workspace files found
                </div>
              )}
            </div>
          </div>
        )}

        {/* File Reference Chips */}
        {referencedFiles.length > 0 && (
          <div className="flex flex-wrap gap-1 p-2 border-b border-zinc-800/60 bg-white/[0.01]">
            {referencedFiles.map((file) => (
              <div
                key={file.id}
                className="flex items-center gap-1 bg-zinc-900 border border-zinc-800 rounded-md px-2 py-0.5 text-[10px] font-mono text-zinc-300 hover:text-white"
              >
                <FileText size={10} className="text-orange-500" />
                <span>{file.name}</span>
                <button
                  onClick={() => setReferencedFiles(prev => prev.filter(f => f.id !== file.id))}
                  className="text-zinc-500 hover:text-white transition-colors cursor-pointer ml-0.5"
                >
                  <X size={9} />
                </button>
              </div>
            ))}
          </div>
        )}

        {/* Attachment Preview (Images, Links, Files) */}
        {attachments.length > 0 && (
          <div className="flex gap-1.5 p-2 border-b border-white/10 overflow-x-auto bg-white/[0.01] items-center">
            {attachments.map((att, i) => (
              <div key={i} className="relative group shrink-0">
                {att.type === "image" && att.data ? (
                  <div className="relative">
                    <img
                      src={`data:${att.mimeType};base64,${att.data}`}
                      alt="Preview"
                      className="h-10 w-10 rounded-lg object-cover border border-white/20 shadow-sm"
                    />
                    <span className="absolute bottom-0 right-0 bg-black/80 text-[8px] text-zinc-300 px-1 rounded-tl font-mono">IMG</span>
                  </div>
                ) : att.type === "image-url" ? (
                  <div className="h-10 px-2 rounded-lg bg-pink-500/10 border border-pink-500/30 flex items-center gap-1.5 text-pink-300 text-[10px] font-mono max-w-[140px] truncate">
                    <ImageIcon size={14} className="shrink-0 text-pink-400" />
                    <span className="truncate">{att.name || att.url}</span>
                  </div>
                ) : att.type === "link" ? (
                  <div className="h-10 px-2 rounded-lg bg-blue-500/10 border border-blue-500/30 flex items-center gap-1.5 text-blue-300 text-[10px] font-mono max-w-[140px] truncate">
                    <Globe size={14} className="shrink-0 text-blue-400" />
                    <span className="truncate">{att.name || att.url}</span>
                  </div>
                ) : (
                  <div className="h-10 px-2 rounded-lg bg-white/10 flex items-center gap-1.5 border border-white/20 shadow-sm text-zinc-300 text-[10px] font-mono max-w-[140px] truncate">
                    <FileText size={14} className="shrink-0 text-orange-400" />
                    <span className="truncate">{att.name}</span>
                  </div>
                )}
                <button
                  type="button"
                  onClick={() =>
                    setAttachments((prev) =>
                      prev.filter((_, idx) => idx !== i),
                    )
                  }
                  className="absolute -top-1 -right-1 bg-red-500 text-white border border-white/30 rounded-full p-0.5 shadow transition-transform hover:scale-110 cursor-pointer"
                >
                  <X size={8} />
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="absolute -top-6 left-3">
          <AnimatePresence>
            {isTyping && (
              <motion.div
                initial={{ opacity: 0, y: 3 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 3 }}
                className="flex items-center gap-1.5 px-2.5 py-0.5 bg-black/90 border border-orange-500/30 rounded-full shadow backdrop-blur-md"
              >
                <div className="flex gap-1">
                  <div className="w-1 h-1 bg-orange-500 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                  <div className="w-1 h-1 bg-orange-500 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                  <div className="w-1 h-1 bg-orange-500 rounded-full animate-bounce"></div>
                </div>
                <span className="text-[8.5px] font-bold text-orange-300 uppercase tracking-wider">
                  {isTyping} generating...
                </span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Neural Quick Automation Shortcuts */}
        {dynamicShortcuts && dynamicShortcuts.length > 0 && (
          <div className="px-2.5 py-1 border-b border-white/5 flex gap-1 overflow-x-auto no-scrollbar scroll-smooth bg-black/30">
            {dynamicShortcuts.map((shortcut, idx) => (
              <button
                key={idx}
                onClick={() => {
                  if (isProcessing) return;
                  onSendMessage(shortcut.prompt, [], selectedModel);
                }}
                disabled={isProcessing}
                className={`flex items-center gap-1 px-2 py-0.5 bg-gradient-to-r ${shortcut.color} border border-white/10 rounded-md text-[9.5px] font-medium tracking-tight transition-all hover:opacity-90 active:scale-95 whitespace-nowrap cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed`}
              >
                <span>{shortcut.label}</span>
                <ArrowUpRight size={9} className="opacity-60" />
              </button>
            ))}
          </div>
        )}

        <textarea
          ref={textareaRef}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          onPaste={handlePaste}
          disabled={isProcessing}
          placeholder={isListening ? "Listening..." : "Ask AI, paste images/links, @reference files..."}
          className="w-full bg-transparent text-xs text-white px-3 py-2 outline-none resize-none min-h-[36px] max-h-[110px] overflow-y-auto no-scrollbar placeholder:text-zinc-500 font-sans leading-normal"
          rows={1}
        />

        {/* Hidden Inputs */}
        <input
          type="file"
          ref={fileInputRef}
          multiple
          className="hidden"
          onChange={(e) => handleFileUpload(e, "file")}
        />
        <input
          type="file"
          ref={folderInputRef}
          multiple
          {...({ webkitdirectory: "", directory: "" } as any)}
          className="hidden"
          onChange={(e) => handleFileUpload(e, "file")}
        />
        <input
          type="file"
          ref={imageInputRef}
          multiple
          className="hidden"
          accept="image/*,video/mp4,video/webm,video/mov,video/quicktime"
          onChange={(e) => handleFileUpload(e, "image")}
        />

        <div className="flex items-center justify-between px-2.5 pb-2 pt-0 gap-1">
          <div className="flex items-center gap-0.5 sm:gap-1 flex-1">
            <button
              onClick={handleEnhance}
              disabled={isEnhancing || !input.trim()}
              className={`p-1 rounded-md transition-all ${isEnhancing ? "text-orange-400 animate-pulse" : "text-zinc-400 hover:text-white hover:bg-white/10"}`}
              title="Enhance Prompt"
            >
              {isEnhancing ? (
                <Loader2 size={13} className="animate-spin" />
              ) : (
                <Wand2 size={13} />
              )}
            </button>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="p-1 text-zinc-400 hover:text-white hover:bg-white/10 rounded-md transition-all"
              title="Upload Files"
            >
              <Paperclip size={13} />
            </button>
            <button
              onClick={() => folderInputRef.current?.click()}
              className="p-1 text-zinc-400 hover:text-white hover:bg-white/10 rounded-md transition-all"
              title="Upload Folder"
            >
              <FolderOpen size={13} />
            </button>
            <button
              onClick={() => imageInputRef.current?.click()}
              className="p-1 text-zinc-400 hover:text-white hover:bg-white/10 rounded-md transition-all"
              title="Upload Image/Video"
            >
              <ImageIcon size={13} />
            </button>
            <button
              onClick={() => setShowLinkModal(!showLinkModal)}
              className={`p-1 rounded-md transition-all ${showLinkModal ? "text-orange-400 bg-orange-500/10" : "text-zinc-400 hover:text-white hover:bg-white/10"}`}
              title="Attach Image Link or Web URL"
            >
              <Link2 size={13} />
            </button>
            <button
              onClick={toggleVoiceInput}
              className={`p-1 rounded-md transition-all cursor-pointer ${isListening ? "text-red-500 animate-pulse bg-red-500/10" : "text-zinc-400 hover:text-white hover:bg-white/10"}`}
              title="Voice Dictation (Speech-to-Text)"
            >
              {isListening ? <MicOff size={13} /> : <Mic size={13} />}
            </button>
            {onOpenVoiceModal && (
              <button
                onClick={onOpenVoiceModal}
                className="flex items-center gap-1 px-1.5 py-1 rounded-md text-[10px] font-bold text-orange-400 bg-orange-500/10 hover:bg-orange-500/20 border border-orange-500/20 transition-all cursor-pointer shadow-sm active:scale-95"
                title="Start 2-Way Voice Conversation Call"
              >
                <Radio size={11} className="animate-pulse text-orange-400" />
                <span className="hidden xs:inline">Voice Convo</span>
              </button>
            )}
            <button
              onClick={handleCapturePreview}
              className="p-1 text-zinc-400 hover:text-white hover:bg-white/10 rounded-md transition-all"
              title="Snap Preview for AI Context"
            >
              <Camera size={13} />
            </button>
          </div>

          <div className="shrink-0">
            {isProcessing ? (
              <button
                onClick={onStopProcessing}
                className="p-1.5 rounded-lg bg-red-500 hover:bg-red-600 text-white shadow-md transition-all"
                title="Interrupt Generation"
              >
                <X size={13} strokeWidth={2.5} />
              </button>
            ) : (
              <button
                onClick={handleSend}
                disabled={!input.trim() && attachments.length === 0}
                className={`
                  p-1.5 rounded-lg transition-all
                  ${
                    input.trim() || attachments.length > 0
                      ? "bg-white text-black shadow hover:bg-zinc-200 cursor-pointer"
                      : "bg-white/10 text-white/20 cursor-not-allowed"
                  }
                `}
              >
                <ArrowUp size={13} strokeWidth={2.5} />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
export default AIChatInput;
