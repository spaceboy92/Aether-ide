import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Activity } from "lucide-react";

export const ThoughtStreamer: React.FC<{ msg: any; isCurrentlyStreaming: boolean }> = ({ msg, isCurrentlyStreaming }) => {
  const [streamedSteps, setStreamedSteps] = useState<{ step: string; status: 'completed' | 'active' | 'pending' }[]>([]);
  
  const presetSteps = [
    "Analyzing project files and structure...",
    "Planning component hierarchy and logic...",
    "Writing component code and markup...",
    "Adding state logic and event handlers...",
    "Applying Tailwind styling and layout...",
    "Polishing typography and spacing...",
    "Verifying workspace build..."
  ];

  const reasoningStepsStr = JSON.stringify(msg.reasoningSteps || []);

  useEffect(() => {
    if (!isCurrentlyStreaming) {
      if (!msg.reasoningSteps || msg.reasoningSteps.length === 0) {
        setStreamedSteps(prev => {
          if (prev.length > 0 && prev.every(s => s.status === 'completed')) return prev;
          return presetSteps.slice(0, 5).map(s => ({ step: s, status: 'completed' as const }));
        });
      }
      return;
    }

    let timerId: any;
    let stepIndex = 0;

    const initialSteps = [
      { step: presetSteps[0], status: 'active' as const }
    ];
    setStreamedSteps(initialSteps);

    const runStream = () => {
      timerId = setInterval(() => {
        stepIndex++;
        if (stepIndex >= presetSteps.length) {
          clearInterval(timerId);
          return;
        }

        setStreamedSteps(prev => {
          const updated = prev.map(s => ({ ...s, status: 'completed' as const }));
          return [...updated, { step: presetSteps[stepIndex], status: 'active' as const }];
        });
      }, 1800);
    };

    runStream();

    return () => {
      if (timerId) clearInterval(timerId);
    };
  }, [isCurrentlyStreaming, reasoningStepsStr]);

  const displaySteps = msg.reasoningSteps && msg.reasoningSteps.length > 0 
    ? msg.reasoningSteps 
    : streamedSteps;

  return (
    <div className={`${msg.thoughts ? "pt-3" : ""} space-y-2`}>
      <div className="text-[9px] font-bold uppercase tracking-widest text-zinc-500 mb-1.5 flex items-center gap-1">
        <Activity size={10} className="text-orange-500 animate-pulse" /> Reasoning
      </div>
      {displaySteps.map((s: { step: string; status: string }, i: number) => {
        const isStepCompleted = s.status === "completed";
        const isStepActive = s.status === "active";
        return (
          <motion.div 
            key={i} 
            initial={{ opacity: 0, x: -5 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-start gap-3 text-zinc-400"
          >
            <div className="mt-1.5 flex-shrink-0">
              {isStepCompleted ? (
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)]" />
              ) : isStepActive ? (
                <div className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" />
              ) : (
                <div className="w-1.5 h-1.5 rounded-full bg-zinc-700" />
              )}
            </div>
            <span className={`text-[10px] font-mono leading-relaxed ${isStepCompleted ? 'text-zinc-400' : isStepActive ? 'text-orange-400 font-medium' : 'text-zinc-600'}`}>
              {s.step}
              {isStepActive && <span className="animate-pulse">_</span>}
            </span>
          </motion.div>
        );
      })}
    </div>
  );
};
