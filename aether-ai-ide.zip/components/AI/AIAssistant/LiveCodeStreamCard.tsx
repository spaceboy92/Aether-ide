import React, { useMemo, useState, useRef, useEffect } from "react";
import { Code2, Sparkles, FileCode, Check, Copy, Maximize2, X, Zap } from "lucide-react";

export interface LiveCodeStreamCardProps {
  currentCodeFragment?: string;
  isStreaming: boolean;
  onApplyCode?: (code: string, language?: string, filename?: string) => void;
  onRunTerminal?: (cmd: string) => void;
}

export const LiveCodeStreamCard: React.FC<LiveCodeStreamCardProps> = ({
  currentCodeFragment,
  isStreaming,
  onApplyCode,
  onRunTerminal,
}) => {
  const [selectedFileIdx, setSelectedFileIdx] = useState(0);
  const [copied, setCopied] = useState(false);
  const [applied, setApplied] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const codeContainerRef = useRef<HTMLDivElement>(null);

  // Parse code fragments
  const parsedFragments: { path: string; code: string; language: string }[] = useMemo(() => {
    if (!currentCodeFragment) return [];
    try {
      if (currentCodeFragment.trim().startsWith('{')) {
        const obj = JSON.parse(currentCodeFragment);
        return Object.entries(obj).map(([filePath, code]) => {
          const cleanCode = String(code);
          const ext = filePath.split('.').pop()?.toLowerCase() || '';
          const langMap: Record<string, string> = {
            ts: 'typescript',
            tsx: 'typescript',
            js: 'javascript',
            jsx: 'javascript',
            py: 'python',
            rs: 'rust',
            html: 'html',
            css: 'css',
            json: 'json',
            sh: 'bash'
          };
          return {
            path: filePath,
            code: cleanCode,
            language: langMap[ext] || ext || 'text'
          };
        });
      }
    } catch {
      // Fallback plain string
    }

    return [{
      path: 'active_generation.ts',
      code: currentCodeFragment,
      language: 'typescript'
    }];
  }, [currentCodeFragment]);

  // Auto-scroll to bottom of code view during streaming
  useEffect(() => {
    if (isStreaming && codeContainerRef.current) {
      codeContainerRef.current.scrollTop = codeContainerRef.current.scrollHeight;
    }
  }, [currentCodeFragment, isStreaming]);

  // Adjust active tab if files length changes
  useEffect(() => {
    if (selectedFileIdx >= parsedFragments.length && parsedFragments.length > 0) {
      setSelectedFileIdx(parsedFragments.length - 1);
    }
  }, [parsedFragments.length, selectedFileIdx]);

  if (parsedFragments.length === 0) return null;

  const currentFile = parsedFragments[selectedFileIdx] || parsedFragments[0];
  const lines = currentFile.code.split("\n");
  const lineCount = lines.length;

  const handleCopy = () => {
    navigator.clipboard.writeText(currentFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleApply = () => {
    if (onApplyCode) {
      onApplyCode(currentFile.code, currentFile.language, currentFile.path);
      setApplied(true);
      setTimeout(() => setApplied(false), 2500);
    }
  };

  return (
    <div className="my-3 rounded-xl overflow-hidden border border-orange-500/30 bg-[#07080d] shadow-2xl transition-all">
      {/* Live Generation Header */}
      <div className="flex flex-wrap items-center justify-between px-3 py-2 bg-gradient-to-r from-orange-950/40 via-black/60 to-transparent border-b border-orange-500/20 select-none gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <div className="relative flex items-center justify-center">
            {isStreaming && (
              <span className="absolute inline-flex h-3 w-3 rounded-full bg-orange-500/40 animate-ping" />
            )}
            <span className={`relative inline-flex rounded-full h-2 w-2 ${isStreaming ? "bg-orange-500 animate-pulse" : "bg-emerald-500"}`} />
          </div>

          <div className="flex items-center gap-1.5 min-w-0">
            <Sparkles size={12} className="text-orange-400 shrink-0" />
            <span className="text-[11px] font-mono font-bold text-orange-300 uppercase tracking-wider shrink-0">
              {isStreaming ? "Live Code Stream" : "Generated Code"}
            </span>
          </div>

          {/* File Selector Tabs if multiple files */}
          {parsedFragments.length > 1 && (
            <div className="flex items-center gap-1 overflow-x-auto max-w-[280px] pl-2 border-l border-white/10 no-scrollbar">
              {parsedFragments.map((f, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedFileIdx(idx)}
                  className={`px-2 py-0.5 rounded text-[10px] font-mono whitespace-nowrap transition-all cursor-pointer ${
                    selectedFileIdx === idx
                      ? "bg-orange-500/20 text-orange-300 border border-orange-500/40 font-bold shadow-[0_0_8px_rgba(249,115,22,0.2)]"
                      : "bg-white/5 hover:bg-white/10 text-white/50 border border-transparent"
                  }`}
                >
                  {f.path.split('/').pop() || f.path}
                </button>
              ))}
            </div>
          )}

          {parsedFragments.length === 1 && (
            <span className="text-[10px] font-mono text-zinc-300 bg-white/5 px-2 py-0.5 rounded border border-white/10 truncate max-w-[200px]">
              {currentFile.path}
            </span>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 ml-auto shrink-0">
          <span className="text-[9.5px] font-mono text-orange-400/90 bg-orange-500/10 px-2 py-0.5 rounded border border-orange-500/20 flex items-center gap-1">
            <Zap size={9} className="text-orange-400" />
            {lineCount} {lineCount === 1 ? 'line' : 'lines'}
          </span>

          {onApplyCode && (
            <button
              onClick={handleApply}
              className={`px-2 py-1 rounded-md text-[10px] font-mono flex items-center gap-1 transition-all cursor-pointer ${
                applied
                  ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-semibold shadow-[0_0_8px_rgba(16,185,129,0.3)]"
                  : "bg-orange-500/20 hover:bg-orange-500/30 text-orange-300 border border-orange-500/30"
              }`}
              title="Apply streamed code directly into workspace editor"
            >
              {applied ? <Check size={11} /> : <FileCode size={11} />}
              <span>{applied ? "Applied!" : "Apply"}</span>
            </button>
          )}

          <button
            onClick={handleCopy}
            className="p-1 rounded-md text-white/50 hover:text-white hover:bg-white/10 transition-all cursor-pointer"
            title="Copy code"
          >
            {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
          </button>

          <button
            onClick={() => setIsFullscreen(true)}
            className="p-1 rounded-md text-white/50 hover:text-white hover:bg-white/10 transition-all cursor-pointer"
            title="Fullscreen code view"
          >
            <Maximize2 size={12} />
          </button>
        </div>
      </div>

      {/* Code Stream Body */}
      <div 
        ref={codeContainerRef}
        className="relative overflow-x-auto p-3 text-[12px] font-mono leading-relaxed bg-[#040508] max-h-[360px] overflow-y-auto scroll-smooth"
      >
        <pre className="m-0 p-0">
          <table className="border-collapse w-full">
            <tbody>
              {lines.map((line, idx) => (
                <tr key={idx} className="hover:bg-white/[0.03]">
                  <td className="w-8 select-none text-right pr-3 text-[10px] text-white/25 font-mono align-top">
                    {idx + 1}
                  </td>
                  <td className="whitespace-pre text-zinc-200">
                    {line || " "}
                    {isStreaming && idx === lines.length - 1 && (
                      <span className="inline-block w-1.5 h-3.5 bg-orange-400 ml-1 translate-y-0.5 animate-pulse rounded-xs shadow-[0_0_8px_rgba(249,115,22,0.9)]" />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </pre>
      </div>

      {/* Fullscreen Modal */}
      {isFullscreen && (
        <div className="fixed inset-0 z-[9999] bg-black/95 backdrop-blur-xl flex flex-col p-6 animate-in fade-in duration-150">
          <div className="flex items-center justify-between pb-4 border-b border-white/10 select-none">
            <div className="flex items-center gap-2">
              <Code2 size={16} className="text-orange-400" />
              <span className="text-sm font-mono font-bold text-white uppercase">
                {currentFile.path} • {currentFile.language}
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="px-3 py-1.5 rounded-lg text-xs font-mono bg-white/10 hover:bg-white/20 text-white flex items-center gap-1.5 transition-all cursor-pointer"
              >
                {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                <span>{copied ? "Copied" : "Copy Code"}</span>
              </button>

              <button
                onClick={() => setIsFullscreen(false)}
                className="p-1.5 rounded-lg bg-white/10 text-white/60 hover:text-white hover:bg-white/20 transition-all cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-auto p-4 bg-[#08090d] rounded-xl border border-white/10 mt-4 font-mono text-sm leading-relaxed">
            <pre className="m-0">
              <table className="border-collapse w-full">
                <tbody>
                  {lines.map((line, idx) => (
                    <tr key={idx} className="hover:bg-white/[0.02]">
                      <td className="w-10 select-none text-right pr-4 text-xs text-white/25 font-mono">
                        {idx + 1}
                      </td>
                      <td className="whitespace-pre text-zinc-200">{line || " "}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </pre>
          </div>
        </div>
      )}
    </div>
  );
};
