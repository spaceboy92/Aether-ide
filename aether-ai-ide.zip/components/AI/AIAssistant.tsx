import React, {
  useState,
  useEffect,
  useRef,
  useMemo,
  useCallback,
} from "react";
import html2canvas from "html2canvas";
import { motion, AnimatePresence } from "motion/react";
import { ChatSession, FileNode, AgentAction, UserProfile } from "../../types";
import {
  Bot, Plus,
  User,
  Sparkles,
  Loader2,
  Globe,
  ExternalLink,
  X,
  RotateCcw,
  Copy,
  Volume2,
  VolumeX,
  ArrowUp,
  Paperclip,
  Wand2,
  Image as ImageIcon,
  FileText,
  MicOff,
  Mic,
  Package,
  SearchCode,
  Minimize2,
  ChevronDown,
  SendHorizontal,
  Box,
  MessageSquare,
  Share2,
  Camera,
  Eye,
  EyeOff,
  Pin,
  Trash2,
  Network,
  Brain,
  DownloadCloud,
  Download,
  Server,
  Cpu,
  Layers,
  Wifi,
  Terminal,
  Activity,
  Zap,
  ArrowUpRight,
  CheckCircle,
  Play,
  SquarePlay,
  GitPullRequest,
  Gamepad2,
  Tv,
  ChevronLeft,
  MoreHorizontal,
  Radio,
  Headphones,
  PhoneOff,
  Sliders,
  RefreshCw,
  KeyRound,
  CloudUpload,
} from "lucide-react";
import { getAvailableModels, addCustomModel } from "../../services/aiService";
import { autoFetchAndSyncOllamaModels } from "../../services/ollamaService";
import { getOfflineModelStatus, saveOfflineModelStatus, getOfflineModelConfig } from "../../services/offlineAiService";
import { EvolvingMemoryPanel } from "./EvolvingMemoryPanel";
import { generateImageTool } from "../../services/imageGeneratorTool";
import { connectivityService } from "../../services/connectivityService";
import { generateId } from "../../utils/id";
import { embeddingService } from "../../services/embeddingService";
import { socketService } from "../../services/socketService";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

import { NeuralOrchestratorBoard } from "./AIAssistant/NeuralOrchestratorBoard";
import { ChatMessage } from "./AIAssistant/ChatMessage";
import { 
  ORCHESTRATOR_DIVISIONS, 
  classifyIntentAndDivision, 
  IntentClassificationResult,
  OrchestratorAgent
} from "./AIAssistant/orchestratorClassifier";
import { 
  AtMentionPopover, 
  DivisionActionItem, 
  ALL_DIVISION_ACTIONS 
} from "./AIAssistant/AtMentionDropdown";

const enhancePrompt = async (originalPrompt: string): Promise<string> => {
  try {
    const response = await fetch('/api/gemini/enhance', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: originalPrompt })
    });
    if (response.ok) {
      const data = await response.json();
      return data.result || originalPrompt;
    }
  } catch (e) {
    console.error("Client enhance failed, using original prompt:", e);
  }
  return originalPrompt;
};

const ThoughtStreamer: React.FC<{ msg: any; isCurrentlyStreaming: boolean }> = ({ msg, isCurrentlyStreaming }) => {
  const steps = msg.reasoningSteps && msg.reasoningSteps.length > 0 
    ? msg.reasoningSteps 
    : isCurrentlyStreaming 
      ? [{ step: "Analyzing intent and synthesizing reasoning...", status: "active" as const }]
      : [];

  if (steps.length === 0) return null;

  return (
    <div className={`${msg.thoughts ? "pt-3 border-t border-white/5 mt-3" : ""} space-y-2`}>
      <div className="text-[9px] font-bold uppercase tracking-widest text-zinc-500 mb-1.5 flex items-center gap-1">
        <Activity size={10} className="text-orange-500 animate-pulse" /> Thought Sequences
      </div>
      {steps.map((s: { step: string; status: string }, i: number) => {
        const isStepCompleted = s.status === "completed";
        const isStepActive = s.status === "active";
        return (
          <motion.div 
            key={i} 
            initial={{ opacity: 0, x: -5 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-start gap-3 text-zinc-400"
          >
            <div className="mt-1.5 flex-shrink-0">
              {isStepCompleted ? (
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)]" />
              ) : isStepActive ? (
                <div className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" />
              ) : (
                <div className="w-1.5 h-1.5 rounded-full bg-zinc-700" />
              )}
            </div>
            <span className={`text-[10px] font-mono leading-relaxed ${isStepCompleted ? 'text-zinc-400' : isStepActive ? 'text-orange-400 font-medium' : 'text-zinc-600'}`}>
              {s.step}
            </span>
          </motion.div>
        );
      })}
    </div>
  );
};

interface AIAssistantProps {
  user: UserProfile;
  files: FileNode[];
  activeFileId: string | null;
  onAgentAction: (actions: AgentAction[]) => Promise<void>;
  sessions: ChatSession[];
  activeSessionId: string | null;
  onCreateSession: () => void;
  onUpdateSession: (session: ChatSession) => void;
  onForkSession?: (session: ChatSession) => void;
  isProcessing: boolean;
  onSendMessage: (
    text: string,
    attachments?: { mimeType: string; data: string }[],
    modelId?: string,
    isCompactMode?: boolean,
    sessionOverride?: any,
    activeAgentIds?: string[]
  ) => void;
  isCompactMode?: boolean;
  onToggleCompactMode?: () => void;
  onStopProcessing?: () => void;
  onClose: () => void;
  onBackToHub?: () => void;
  onUploadFiles?: (
    files: {
      name: string;
      type: "image" | "file";
      mimeType: string;
      data: string;
    }[],
  ) => void;
  onRedirectToGameEngine?: (prompt: string) => void;
  activeRightTab?: string;
  splitSubTab?: string;
  initialTab?: 'chat' | 'agent';
  onCommandSelect?: (commandId: string, payload?: any) => void;
  setActiveFileId?: (id: string | null) => void;
}

const AI_FEATURES = [
  {
    id: "vanilla",
    label: "Web Application",
    icon: Globe,
    prompt:
      "Generate a complete Web Application cleanly separated into modular files (index.html, style.css, script.js). CRITICAL: Decompose all styles into style.css and logic into script.js rather than embedding inline code in index.html.",
  },
  {
    id: "spa",
    label: "Modern SPA",
    icon: Box,
    prompt:
      "Generate a modern Single Page Application using pure JS. Implement a custom router, state management, and elegant UI transitions without any external frameworks.",
  },
  {
    id: "audit",
    label: "Code Audit",
    icon: SearchCode,
    prompt:
      "Perform a deep audit of the current codebase to identify security, performance, and stability issues.",
  },
  {
    id: "image",
    label: "Creative Asset",
    icon: ImageIcon,
    prompt:
      "Generate a high-quality visual asset or illustration for the current project context.",
  },
  {
    id: "polish",
    label: "Aether Polish",
    icon: Wand2,
    prompt:
      "Apply the Aether visual aesthetic to the current codebase—improving typography, spacing, and adding fluid motion effects.",
  },
  {
    id: "auto_pr",
    label: "Create GitHub PR",
    icon: GitPullRequest,
    prompt:
      "Analyze the differences in the workspace and generate a highly detailed GitHub Pull Request description complete with commit logs, features, and impact details.",
  },
  {
    id: "test_suite",
    label: "Synthesize Tests",
    icon: CheckCircle,
    prompt:
      "Generate a comprehensive Jest / Vitest test suite for all active workspace components and state modules.",
  },
  {
    id: "dockerize",
    label: "Docker DevOps",
    icon: Server,
    prompt:
      "Formulate production-ready Dockerfile and docker-compose configurations mapped to our workspace structure.",
  },
  {
    id: "sound_effects",
    label: "WAV Sound Gen",
    icon: Play,
    prompt:
      "Construct a highly realistic Web Audio API synthesizer function to trigger retro game sound effects programmatically.",
  },
  {
    id: "color_picker",
    label: "Theme Picker",
    icon: Sparkles,
    prompt:
      "Propose 5 beautiful, accessible, cohesive Tailwind CSS color palettes tailored for our workspace application context.",
  }
];

const NEURAL_SKILLS = [
  { id: 'vision', name: 'Visual Audit', icon: Eye, color: 'text-cyan-400', prompt: 'Analyze the current application interface and layout. Suggest UI improvements, accessibility fixes, and design refinements.' },
  { id: 'debugger', name: 'Auto Debug', icon: Activity, color: 'text-red-400', prompt: 'Analyze the current workspace for syntax errors, logical flaws, and performance bottlenecks. Suggest targeted fixes.' },
  { id: 'architect', name: 'App Logic', icon: Cpu, color: 'text-blue-400', prompt: 'Design a robust state management and routing architecture for the current project. Define core data types and services.' },
  { id: 'designer', name: 'UI Polish', icon: Sparkles, color: 'text-amber-400', prompt: 'Enhance the visual design of the current interface. Improve typography, spacing, and color harmony using Tailwind CSS.' },
  { id: 'optimizer', name: 'Token Opt', icon: Zap, color: 'text-amber-500', prompt: 'Analyze the current codebase and refactor it for extreme efficiency. Remove dead code, optimize loops, and ensure the most compact implementation.' },
  { id: 'writer', name: 'Doc Gen', icon: FileText, color: 'text-emerald-400', prompt: 'Generate comprehensive README and documentation for the current project. Include setup instructions and API references.' },
  { id: 'copilot_sync', name: 'GitHub Sync', icon: GitPullRequest, color: 'text-indigo-400', prompt: 'Synchronize active modifications with the connected GitHub account. Formulate precise commit streams and branch definitions.' },
  { id: 'sec_scan', name: 'Security Audit', icon: SearchCode, color: 'text-rose-400', prompt: 'Scan all active files for leaked credentials, open ports, unsafe regex statements, and direct injection vulnerabilities.' },
  { id: 'd3_dep', name: 'D3 dependency', icon: Layers, color: 'text-violet-400', prompt: 'Render an interactive D3 code dependency tree detailing connections and module weights.' },
  { id: 'sql_mig', name: 'SQL Schema', icon: Terminal, color: 'text-sky-400', prompt: 'Evaluate schemas and generate optimized PostgreSQL/Cloud SQL schema definition code and migration files.' }
];

interface AgentDetails {
  name: string;
  icon: string;
  role: string;
}

const getAgentDetails = (agentId: string): AgentDetails => {
  const mapping: Record<string, AgentDetails> = {
    master: { name: "Co-pilot Master Orchestrator", icon: "🧠", role: "Routing tasks, coordinating dynamic sub-agents, and compiling neural outputs." },
    planner: { name: "Architectural Blueprint Planner", icon: "📋", role: "Analyzing workspace dependency graphs and plotting code edits." },
    ui_ux: { name: "UI/UX Design & Typography Specialist", icon: "🎨", role: "Crafting beautiful high-density interfaces, custom fonts, and colors." },
    react_core: { name: "React State & Lifecycle Engineer", icon: "⚛️", role: "Optimizing React components, memoization, hook performance, and rendering loops." },
    styling: { name: "Tailwind CSS & Styling Architect", icon: "💅", role: "Applying responsive, elegant styles, layouts, and pixel-perfect designs." },
    components_core: { name: "Reusable Component Architect", icon: "🧩", role: "Building modular, robust, and clean UI component collections." },
    responsive_layout_master: { name: "Multi-Screen Fluidity Expert", icon: "📱", role: "Perfecting layouts for smartphones, tablets, and high-DPI desktop screens." },
    api_agent: { name: "REST API & Network Integrator", icon: "🔌", role: "Linking frontends with endpoints, payload verification, and async query states." },
    unit_tester: { name: "Test Suite & Quality Guard", icon: "🧪", role: "Running linter audits, type validations, and syntax checking." },
    refactoring: { name: "Structural Refactoring Specialist", icon: "⚙️", role: "Streamlining large files, enhancing performance, and resolving modular complexity." },
    be_architect: { name: "Backend Systems Architect", icon: "🗄️", role: "Designing robust server-side controllers and Express route architectures." },
    db_agent: { name: "Database & Cloud Schema Engineer", icon: "💾", role: "Optimizing collection models, indexes, and complex queries." },
    auth_agent: { name: "Auth & Gatekeeper Security Specialist", icon: "🔒", role: "Managing secure routes, middleware, and user context validation." },
    ai_architect: { name: "Neural Model Integration Agent", icon: "🤖", role: "Embedding LLMs, smart context retrieval, and model scaling configurations." },
    ai_tool_agent: { name: "Function Calling Tool Specialist", icon: "🛠️", role: "Designing prompt-based parameters and tools interfaces." },
    security_auditor: { name: "Vulnerability & Privacy Auditor", icon: "🛡️", role: "Analyzing source code for security flaws and private data handling." },
    firestore_realtime_sync: { name: "Real-time Live Sync Agent", icon: "🔄", role: "Securing realtime Firestore sync events and collaborative streams." },
    three_js: { name: "3D WebGL Engine Developer", icon: "🎮", role: "Setting up Three.js scenes, camera rigs, shadow matrices, and lighting." },
    game_modeler: { name: "Procedural 3D Mesh Modeler", icon: "📐", role: "Lofting, subdividing, and procedural sculpting of 100k+ poly geometries." },
    game_architect: { name: "Game State & Loop Coordinator", icon: "🕹️", role: "Synchronizing frame delta-times, collision Box3 matrices, and scoring." },
    game_ui: { name: "HUD & Play UI Designer", icon: "🖥️", role: "Overlaying dashboards, health bars, tachometers, and start overlays." },
    game_audio: { name: "Web Audio Synth Engineer", icon: "🔊", role: "Synthesizing real-time procedural saw, square, and FM acoustics." },
    game_director: { name: "Interactive Mechanics Director", icon: "🎬", role: "Rigging mechs, walk/run spring animations, and physics multipliers." },
    shader_vfx: { name: "GLSL Custom Shader Developer", icon: "✨", role: "Writing custom vertex & fragment shaders for screen space bloom, noise, and vfx." },
    multiplayer_netcode: { name: "Multiplayer Network Sync Specialist", icon: "📡", role: "Handling state broadcasting and real-time multiplayer lobbies." },
    vr_ar_spatial: { name: "XR & Spatial Navigation Expert", icon: "🕶️", role: "Optimizing 3D vectors for stereoscopic projection and VR movement controls." },
    error_analyzer: { name: "Runtime Error Diagnostician", icon: "🔍", role: "Reviewing execution logs and tracking compile/runtime exceptions." },
    root_cause: { name: "Deep Root Cause Debugger", icon: "🕵️", role: "Tracing component tracebacks and logic state mismatches." },
    fix_agent: { name: "Self-Healing & AST Repair Agent", icon: "⚡", role: "Autocorrecting unclosed tags, imports, and syntax formatting errors." },
    regression: { name: "Backwards Compatibility Guard", icon: "🔄", role: "Validating existing features are kept safe during hotfixes." },
    build_agent: { name: "Compiler & Vite Builder Agent", icon: "📦", role: "Orchestrating production bundle tests and compilation trees." },
    ast_parser_agent: { name: "Abstract Syntax Tree Parser", icon: "🌳", role: "Validating TS/JS AST syntax validity and structural tree integrity." }
  };

  return mapping[agentId] || { name: "Neural Co-pilot Agent", icon: "🤖", role: "Working dynamically within the active Aether orchestration pool." };
};

interface AutoApplierCodeBlockProps {
  content: string;
  lang: string;
  snippetKey: string;
  files: FileNode[];
  activeFileId: string | null;
  onAgentAction: (actions: AgentAction[]) => Promise<void>;
  setActiveFileId?: (id: string | null) => void;
}

const AutoApplierCodeBlock: React.FC<AutoApplierCodeBlockProps> = ({
  content,
  lang,
  snippetKey,
  files,
  activeFileId,
  onAgentAction,
  setActiveFileId,
}) => {
  const [syncStatus, setSyncStatus] = useState<'syncing' | 'synced' | 'error'>('syncing');
  const [targetPath, setTargetPath] = useState('script.js');
  const [isCollapsed, setIsCollapsed] = useState(true);
  const appliedRef = useRef(false);

  useEffect(() => {
    let path = 'script.js';
    const headerMatch = content.match(/(?:\/\/\s*|\/\*\s*|<!--\s*|#\s*)(?:file|filename|path)?[:\s=]*([a-zA-Z0-9_\-./]+\.[a-zA-Z0-9]+)/i);
    if (headerMatch && headerMatch[1]) {
      path = headerMatch[1].trim();
    } else if (lang === 'html' || content.includes('<html') || content.includes('<!DOCTYPE')) {
      path = 'index.html';
    } else if (lang === 'css' || content.includes('@keyframes') || (content.includes('{') && content.includes(':') && (content.includes('margin') || content.includes('padding') || content.includes('color')))) {
      path = 'style.css';
    } else if (lang === 'tsx' || lang === 'jsx' || content.includes('export default function')) {
      path = 'src/App.tsx';
    } else if (activeFileId) {
      const activeFile = files.find(f => f.id === activeFileId);
      if (activeFile) path = activeFile.name;
    }
    setTargetPath(path);

    if (!appliedRef.current && content.trim().length > 10) {
      appliedRef.current = true;
      setSyncStatus('syncing');
      
      const performSync = async () => {
        try {
          await onAgentAction([{ action: 'update', path, content }]);
          setSyncStatus('synced');
          
          setTimeout(() => {
            const foundFile = files.find(f => f.name === path);
            if (foundFile && setActiveFileId) {
              setActiveFileId(foundFile.id);
            }
          }, 150);
        } catch (err) {
          console.error("Auto sync failed:", err);
          setSyncStatus('error');
        }
      };
      
      performSync();
    }
  }, [content, lang, activeFileId, onAgentAction, setActiveFileId, files]);

  return (
    <div className="my-4 rounded-xl overflow-hidden border border-emerald-500/15 bg-zinc-950/90 backdrop-blur-md shadow-2xl transition-all duration-300">
      <div className="flex items-center justify-between px-4 py-2.5 bg-emerald-500/[0.03] border-b border-white/5">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-lg bg-emerald-500/10">
            <FileText size={14} className="text-emerald-400" />
          </div>
          <div className="flex flex-col">
            <span className="text-[11px] font-semibold text-white/90 truncate max-w-[180px]">
              {targetPath}
            </span>
            <span className="text-[9px] text-zinc-500 uppercase font-mono tracking-wider">
              {lang || "source"}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {syncStatus === 'syncing' && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-orange-500/10 text-orange-400 text-[9px] font-semibold">
              <RefreshCw size={8} className="animate-spin" />
              Syncing changes...
            </span>
          )}
          {syncStatus === 'synced' && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 text-[9px] font-semibold">
              <CheckCircle size={8} />
              Applied to Editor
            </span>
          )}
          {syncStatus === 'error' && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-400 text-[9px] font-semibold">
              Sync failed
            </span>
          )}

          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="text-zinc-400 hover:text-white transition-all text-[10px] px-1.5 py-0.5 rounded hover:bg-white/5"
          >
            {isCollapsed ? "View Code" : "Hide"}
          </button>
        </div>
      </div>

      {!isCollapsed && (
        <div className="relative border-t border-white/5 max-h-[300px] overflow-y-auto custom-scrollbar">
          <pre className="p-4 overflow-x-auto text-xs font-mono leading-relaxed bg-black/40 text-white/75">
            <code>{content}</code>
          </pre>
          <button
            onClick={() => {
              navigator.clipboard.writeText(content);
            }}
            className="absolute top-2 right-2 p-1.5 rounded-md bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-all"
            title="Copy snippet"
          >
            <Copy size={12} />
          </button>
        </div>
      )}
    </div>
  );
};

const AIAssistant: React.FC<AIAssistantProps> = ({
  user,
  files,
  activeFileId,
  onAgentAction,
  sessions,
  activeSessionId,
  onCreateSession,
  onUpdateSession,
  onForkSession,
  isProcessing,
  onSendMessage,
  isCompactMode,
  onToggleCompactMode,
  onStopProcessing,
  onClose,
  onBackToHub,
  onUploadFiles,
  onRedirectToGameEngine,
  activeRightTab,
  splitSubTab,
  initialTab,
  onCommandSelect,
  setActiveFileId,
}) => {
  const [input, setInput] = useState("");
  const [selectedModel, setSelectedModel] = useState("gemini-3.1-pro-preview");
  const [isTyping, setIsTyping] = useState<string | null>(null);
  const [referencedFiles, setReferencedFiles] = useState<FileNode[]>([]);
  const [showFileDropdown, setShowFileDropdown] = useState(false);
  const [fileSearchQuery, setFileSearchQuery] = useState("");
  const [showAtMentionDropdown, setShowAtMentionDropdown] = useState(false);
  const [atMentionSearchQuery, setAtMentionSearchQuery] = useState("");
  const [isEvolvingPanelOpen, setIsEvolvingPanelOpen] = useState(false);

  const [aiTab, setAiTab] = useState<'chat' | 'agent'>(initialTab || 'chat');
  const [appliedSnippetIds, setAppliedSnippetIds] = useState<Record<string, boolean>>({});

  const [activeAgentId, setActiveAgentId] = useState<string>("master");
  const [activeStep, setActiveStep] = useState<'INPUT' | 'UNDERSTAND' | 'INSPECT' | 'PLAN' | 'IMPLEMENT' | 'TEST' | 'REPORT'>('INPUT');
  const [activeLogs, setActiveLogs] = useState<Array<{ time: string, message: string, type: string }>>([]);
  const [spawnedAgents, setSpawnedAgents] = useState<string[]>([]);

  // Orchestrator Modes & Division Scopes
  const [divisionScopeMode, setDivisionScopeMode] = useState<'AUTO' | 'FORCE_GAME' | 'FORCE_WEB' | 'FORCE_BACKEND_AI' | 'MANUAL'>('AUTO');
  const [manualSelectedAgents, setManualSelectedAgents] = useState<string[]>(["ui_ux", "react_core", "components_core"]);
  const [detectedMode, setDetectedMode] = useState<'game' | 'web' | null>(null);
  const [routingReason, setRoutingReason] = useState<string>("");

  // Listen for custom prompts dispatched by Component Inspector & Auto-Fix buttons
  useEffect(() => {
    const handleInsertPrompt = (e: CustomEvent) => {
      if (e.detail && e.detail.prompt) {
        if (!e.detail.autoSubmit) {
          setAiTab('chat');
          setInput((prev) => (prev ? `${prev}\n${e.detail.prompt}` : e.detail.prompt));
        }
      }
    };
    window.addEventListener('aether-insert-ai-prompt', handleInsertPrompt as EventListener);
    return () => window.removeEventListener('aether-insert-ai-prompt', handleInsertPrompt as EventListener);
  }, []);

  const lastUserMessages = useMemo(() => {
    const session = sessions.find(s => s.id === activeSessionId);
    if (!session || !session.messages) return { current: "", previous: "", allCombined: "" };
    const userMsgs = session.messages.filter(m => m.role === 'user');
    return {
      current: userMsgs.length > 0 ? userMsgs[userMsgs.length - 1].text : "",
      previous: userMsgs.length > 1 ? userMsgs[userMsgs.length - 2].text : "",
      allCombined: userMsgs.map(m => m.text).join(" | ")
    };
  }, [activeSessionId, sessions]);

  // Strict domain and division classification engine
  const classification = useMemo(() => {
    return classifyIntentAndDivision(
      lastUserMessages.current,
      lastUserMessages.previous,
      lastUserMessages.allCombined,
      files,
      divisionScopeMode,
      manualSelectedAgents
    );
  }, [lastUserMessages, files, divisionScopeMode, manualSelectedAgents]);

  const lastMessageText = useMemo(() => {
    return lastUserMessages.current;
  }, [lastUserMessages]);

  const currentBotMessage = useMemo(() => {
    const session = sessions.find(s => s.id === activeSessionId);
    if (!session || !session.messages) return null;
    const msgs = session.messages;
    if (msgs.length === 0) return null;
    const lastMsg = msgs[msgs.length - 1];
    return lastMsg.role === 'model' ? lastMsg : null;
  }, [activeSessionId, sessions]);

  const prevProcessingRef = useRef(isProcessing);

  useEffect(() => {
    const wasProcessing = prevProcessingRef.current;
    prevProcessingRef.current = isProcessing;

    if (!isProcessing) {
      if (wasProcessing) {
        setActiveLogs(prev => [
          ...prev,
          { time: new Date().toLocaleTimeString(), message: "Neural batch completed. Releasing ephemeral sub-agents.", type: "success" }
        ]);
        setActiveStep("REPORT");
        setActiveAgentId("master");
      }
      return;
    }

    const subAgents = classification.spawnedAgents;
    setSpawnedAgents(prev => (JSON.stringify(prev) !== JSON.stringify(subAgents) ? subAgents : prev));
    const newDetectedMode = classification.mode === 'game' ? 'game' : 'web';
    setDetectedMode(prev => (prev !== newDetectedMode ? newDetectedMode : prev));
    setRoutingReason(prev => (prev !== classification.reason ? classification.reason : prev));

    const timeStr = new Date().toLocaleTimeString();

    // Reset and initialize logs when starting a fresh pipeline
    if (!wasProcessing || activeLogs.length === 0 || activeLogs.some(l => l.message.includes("Neural batch completed"))) {
      const routingLog = classification.isGame 
        ? `🎯 Co-pilot Orchestrator: Routing task to [${classification.divisionName.toUpperCase()}] (Confidence: ${Math.round(classification.confidence * 100)}%)`
        : `⚡ Co-pilot Orchestrator: Routing task to [${classification.divisionName.toUpperCase()}] (Confidence: ${Math.round(classification.confidence * 100)}%)`;

      setActiveLogs([
        { time: timeStr, message: `🧠 Co-pilot Master Orchestrator initialized. Target Model: ${selectedModel}`, type: "info" },
        { time: timeStr, message: routingLog, type: "success" },
        { time: timeStr, message: `📋 Ephemeral Agent Pool spawned: [${subAgents.map(a => a.toUpperCase()).join(', ')}]`, type: "spawn" }
      ]);
      setActiveStep("INPUT");
      setActiveAgentId("master");
      return;
    }

    const botText = currentBotMessage?.text || "";
    const thoughts = currentBotMessage?.thoughts || "";
    const primaryAgentId = subAgents[0] || "master";
    const primaryAgentDetails = getAgentDetails(primaryAgentId);

    if (!botText || botText === "...") {
      setActiveStep("UNDERSTAND");
      setActiveAgentId(primaryAgentId);
      const understandMsg = `${primaryAgentDetails.icon} ${primaryAgentDetails.name} analyzing workspace & prompt intent...`;
      if (!activeLogs.some(l => l.message.includes("analyzing workspace & prompt intent"))) {
        setActiveLogs(prev => [
          ...prev,
          { time: timeStr, message: understandMsg, type: "info" }
        ]);
      }
    } else if (botText.length > 0 && !botText.includes("```")) {
      setActiveStep("PLAN");
      setActiveAgentId(primaryAgentId);
      const planMsg = `${primaryAgentDetails.icon} ${primaryAgentDetails.name} synthesizing solution structure...`;
      if (!activeLogs.some(l => l.message.includes("synthesizing solution structure"))) {
        setActiveLogs(prev => [
          ...prev,
          { time: timeStr, message: planMsg, type: "info" }
        ]);
      }
    } else if (botText.includes("```")) {
      setActiveStep("IMPLEMENT");
      
      const currentAgentIndex = Math.floor(botText.length / 280) % (subAgents.length || 1);
      const currentAgentId = subAgents[currentAgentIndex] || "master";
      setActiveAgentId(currentAgentId);

      // Detect files being edited in codeblocks
      const lastBlockMatch = botText.match(/```[a-zA-Z]*\s+path=([^\s`]+)/g);
      if (lastBlockMatch && lastBlockMatch.length > 0) {
        const lastFileWritten = lastBlockMatch[lastBlockMatch.length - 1].replace(/```[a-zA-Z]*\s+path=/, "");
        const fileLogMsg = `⚙️ [${currentAgentId.toUpperCase()}] Modifying code at path: ${lastFileWritten}`;
        if (!activeLogs.some(l => l.message === fileLogMsg)) {
          setActiveLogs(prev => [
            ...prev,
            { time: timeStr, message: fileLogMsg, type: "info" }
          ]);
        }
      } else {
        const genLogMsg = `⚙️ [${currentAgentId.toUpperCase()}] Compiling components and generating AST updates...`;
        if (activeLogs.filter(l => l.message.includes("AST updates")).length < 2) {
          if (!activeLogs.some(l => l.message === genLogMsg)) {
            setActiveLogs(prev => [
              ...prev,
              { time: timeStr, message: genLogMsg, type: "info" }
            ]);
          }
        }
      }
    }

    if (thoughts && thoughts.length > 10) {
      const latestThought = thoughts.split("\n").pop() || "";
      if (latestThought.trim().length > 15) {
        const thoughtLogMsg = `🧠 [REASON]: ${latestThought.trim().slice(0, 80)}...`;
        if (!activeLogs.some(l => l.message.startsWith(`🧠 [REASON]: ${latestThought.trim().slice(0, 15)}`))) {
          setActiveLogs(prev => [
            ...prev,
            { time: timeStr, message: thoughtLogMsg, type: "info" }
          ]);
        }
      }
    }
  }, [isProcessing, classification.divisionName, classification.mode, classification.reason, currentBotMessage?.text, currentBotMessage?.thoughts, selectedModel]);

  const handleApplySnippet = async (content: string, lang: string, snippetKey: string) => {
    let targetPath = 'script.js';
    const headerMatch = content.match(/(?:\/\/\s*|\/\*\s*|<!--\s*|#\s*)(?:file|filename|path)?[:\s=]*([a-zA-Z0-9_\-./]+\.[a-zA-Z0-9]+)/i);
    if (headerMatch && headerMatch[1]) {
      targetPath = headerMatch[1].trim();
    } else if (lang === 'html' || content.includes('<html') || content.includes('<!DOCTYPE')) {
      targetPath = 'index.html';
    } else if (lang === 'css' || content.includes('@keyframes') || (content.includes('{') && content.includes(':') && (content.includes('margin') || content.includes('padding') || content.includes('color')))) {
      targetPath = 'style.css';
    } else if (lang === 'tsx' || lang === 'jsx' || content.includes('export default function')) {
      targetPath = 'src/App.tsx';
    } else if (activeFileId) {
      const activeFile = files.find(f => f.id === activeFileId);
      if (activeFile) targetPath = activeFile.name;
    }

    try {
      await onAgentAction([{ action: 'update', path: targetPath, content }]);
      setAppliedSnippetIds(prev => ({ ...prev, [snippetKey]: true }));
      setTimeout(() => {
        setAppliedSnippetIds(prev => ({ ...prev, [snippetKey]: false }));
      }, 3000);
    } catch (e) {
      console.error("Failed to apply snippet:", e);
    }
  };

  const toggleMessageExclusion = (messageId: string) => {
    if (!activeSession) return;
    const updatedMessages = activeSession.messages.map(msg => {
      if (msg.id === messageId) {
        return { ...msg, isExcluded: !msg.isExcluded };
      }
      return msg;
    });
    onUpdateSession({
      ...activeSession,
      messages: updatedMessages,
      lastUpdated: Date.now()
    });
  };

  const toggleMessagePin = (messageId: string) => {
    if (!activeSession) return;
    const updatedMessages = activeSession.messages.map(msg => {
      if (msg.id === messageId) {
        return { ...msg, isPinned: !msg.isPinned };
      }
      return msg;
    });
    onUpdateSession({
      ...activeSession,
      messages: updatedMessages,
      lastUpdated: Date.now()
    });
  };

  const deleteMessage = (messageId: string) => {
    if (!activeSession) return;
    const updatedMessages = activeSession.messages.filter(msg => msg.id !== messageId);
    onUpdateSession({
      ...activeSession,
      messages: updatedMessages,
      lastUpdated: Date.now()
    });
  };

  const forkSessionAtMessage = (messageId: string) => {
    if (!activeSession || !onForkSession) return;
    const index = activeSession.messages.findIndex(m => m.id === messageId);
    if (index === -1) return;
    
    // Slice up to and including the selected message
    const slicedMessages = activeSession.messages.slice(0, index + 1);
    
    const forkedSession: ChatSession = {
      id: generateId('s'),
      title: `${activeSession.title} (Forked)`,
      messages: slicedMessages.map(m => ({ ...m, id: generateId(m.role === 'user' ? 'u' : 'b'), isExcluded: false, isPinned: false })),
      lastUpdated: Date.now()
    };
    
    onForkSession(forkedSession);
  };

  const handleEditAndResendMessage = (messageId: string, newText: string) => {
    if (!activeSession) return;
    const index = activeSession.messages.findIndex(m => m.id === messageId);
    if (index === -1) return;
    const sliced = activeSession.messages.slice(0, index);
    onUpdateSession({
      ...activeSession,
      messages: sliced,
      lastUpdated: Date.now()
    });
    onSendMessage(newText);
  };

  const handleRetryMessage = (messageId: string) => {
    if (!activeSession) return;
    const msg = activeSession.messages.find(m => m.id === messageId);
    if (!msg) return;
    onSendMessage(msg.text);
  };

  const handleApplyCodeToEditor = async (code: string, language?: string, filename?: string) => {
    if (activeFileId && files) {
      const activeFile = files.find(f => f.id === activeFileId);
      if (activeFile) {
        await onAgentAction([{
          action: 'update',
          path: activeFile.path || activeFile.name,
          content: code
        }]);
        return;
      }
    }
    if (filename) {
      await onAgentAction([{
        action: 'create',
        path: filename,
        content: code
      }]);
    }
  };

  const handleRunTerminalCommand = async (command: string) => {
    await onAgentAction([{
      action: 'terminal_command',
      command: command
    }]);
  };

  const handleUpdateFilesFromRestore = async (restoredFiles: FileNode[]) => {
    const actions: AgentAction[] = restoredFiles.map(f => ({
      action: 'update',
      path: f.path || f.name,
      content: f.content || ''
    }));
    if (actions.length > 0) {
      await onAgentAction(actions);
    }
  };

  const handleMessageFeedback = (messageId: string, feedback: 'like' | 'dislike') => {
    if (!activeSession) return;
    const updated = activeSession.messages.map(m => m.id === messageId ? { ...m, feedback } : m);
    onUpdateSession({
      ...activeSession,
      messages: updated,
      lastUpdated: Date.now()
    });
  };

  useEffect(() => {
    if (activeSessionId) {
      socketService.connect();
      socketService.joinSession(activeSessionId);

      const handleTyping = ({ user }: { user: string }) => {
        setIsTyping(user);
        setTimeout(() => setIsTyping(null), 3000);
      };
      
      socketService.onTyping(handleTyping);
      
      return () => {
        socketService.off('user-typing', handleTyping);
      };
    }
  }, [activeSessionId]);

  const [showSlashDropdown, setShowSlashDropdown] = useState(false);
  const [slashSearchQuery, setSlashSearchQuery] = useState("");
  const [slashSelectedIndex, setSlashSelectedIndex] = useState(0);

  const PROMPT_SLASH_COMMANDS = useMemo(() => [
    { cmd: '/jwt', title: 'JWT Token Inspector', desc: 'Decode & inspect JSON Web Tokens', icon: <KeyRound size={14} className="text-orange-400" />, category: 'TOOLS', systemCmd: 'jwt' },
    { cmd: '/env', title: 'Environment Variables Manager', desc: 'Manage secrets & workspace .env variables', icon: <Sliders size={14} className="text-cyan-400" />, category: 'TOOLS', systemCmd: 'env' },
    { cmd: '/build', title: 'Build Project', desc: 'Run npm run build production bundle', icon: <Play size={14} className="text-emerald-400" />, category: 'DEVOPS', systemCmd: 'build' },
    { cmd: '/lint', title: 'Lint Codebase', desc: 'Run npm run lint static type checking', icon: <CheckCircle size={14} className="text-yellow-400" />, category: 'DEVOPS', systemCmd: 'lint' },
    { cmd: '/commit', title: 'Git Commit', desc: 'Commit workspace file changes to Git', icon: <GitPullRequest size={14} className="text-purple-400" />, category: 'DEVOPS', systemCmd: 'commit' },
    { cmd: '/deploy', title: 'Deploy to Cloud Run', desc: 'Deploy app to Cloud Run container', icon: <CloudUpload size={14} className="text-emerald-400" />, category: 'DEVOPS', systemCmd: 'deploy' },
    { cmd: '/publish', title: 'Publish & Deploy App', desc: 'Compile & publish app live', icon: <CloudUpload size={14} className="text-blue-400" />, category: 'DEVOPS', systemCmd: 'publish' },
    { cmd: '/image', title: 'AI Image Generator', desc: 'Generate AI images, hero banners, visual assets & mockups', icon: <ImageIcon size={14} className="text-purple-400" />, category: 'PROMPT TOOLS', promptPrefix: '/image ' },
    { cmd: '/draw', title: 'Draw Vector SVG Asset', desc: 'Synthesize custom SVG icons & visual UI elements', icon: <Wand2 size={14} className="text-pink-400" />, category: 'PROMPT TOOLS', promptPrefix: '/draw ' },
    { cmd: '/ui', title: 'Prompt UI Component Builder', desc: 'Generate React components & Tailwind UI widgets', icon: <Box size={14} className="text-amber-400" />, category: 'PROMPT TOOLS', promptPrefix: '/ui ' },
    { cmd: '/refactor', title: 'Autonomous Code Refactorer', desc: 'Refactor code for performance, readability & types', icon: <Sparkles size={14} className="text-amber-400" />, category: 'PROMPT TOOLS', promptPrefix: '/refactor ' },
    { cmd: '/fix', title: 'AI Bug Repair & Error Fixer', desc: 'Detect and auto-correct syntax errors & bugs', icon: <Zap size={14} className="text-emerald-400" />, category: 'PROMPT TOOLS', promptPrefix: '/fix' },
    { cmd: '/test', title: 'Unit Test Generator', desc: 'Generate complete Vitest / Jest test suites', icon: <Cpu size={14} className="text-blue-400" />, category: 'PROMPT TOOLS', promptPrefix: '/test ' },
    { cmd: '/db', title: 'Database Schema Builder', desc: 'Generate Drizzle SQL / Firestore schemas from text', icon: <Server size={14} className="text-orange-400" />, category: 'PROMPT TOOLS', promptPrefix: '/db ' },
    { cmd: '/mock', title: 'API Mock Generator', desc: 'Generate REST API mock endpoints & JSON data', icon: <Globe size={14} className="text-sky-400" />, category: 'PROMPT TOOLS', promptPrefix: '/mock ' },
    { cmd: '/audio', title: 'Web Audio Sound Synthesizer', desc: 'Synthesize custom sound effects or retro 8-bit audio', icon: <Headphones size={14} className="text-indigo-400" />, category: 'PROMPT TOOLS', promptPrefix: '/audio ' },
    { cmd: '/create-tool', title: 'Dynamic Custom Tool Creator', desc: 'AI creates & builds a brand-new custom tool workspace module', icon: <Sliders size={14} className="text-rose-400" />, category: 'DYNAMIC CREATOR', promptPrefix: '/create-tool ' },
    { cmd: '/docs', title: 'Documentation Generator', desc: 'Generate comprehensive markdown project docs', icon: <FileText size={14} className="text-cyan-400" />, category: 'PROMPT TOOLS', promptPrefix: '/docs' },
    { cmd: '/enhance', title: 'Prompt Enhancer', desc: 'Transform simple prompt into engineering spec', icon: <Wand2 size={14} className="text-indigo-400" />, category: 'PROMPT TOOLS', promptPrefix: '/enhance ' },
    { cmd: '/terminal', title: 'Linux Terminal Shell', desc: 'Open interactive terminal console', icon: <Terminal size={14} className="text-emerald-400" />, category: 'SYSTEM', systemCmd: 'terminal' },
    { cmd: '/security', title: 'Security Scanner', desc: 'Run deep vulnerability and security audit', icon: <Activity size={14} className="text-emerald-400" />, category: 'SYSTEM', systemCmd: 'security' },
    { cmd: '/profiler', title: 'Performance Profiler', desc: 'Inspect CPU, memory & render performance', icon: <Activity size={14} className="text-green-400" />, category: 'SYSTEM', systemCmd: 'profiler' },
    { cmd: '/api', title: 'API Request Studio', desc: 'Open REST API testing playground', icon: <Globe size={14} className="text-sky-400" />, category: 'SYSTEM', systemCmd: 'api' },
    { cmd: '/database', title: 'Database Studio', desc: 'Inspect Firestore & SQL database tables', icon: <Server size={14} className="text-amber-400" />, category: 'SYSTEM', systemCmd: 'database' },
    { cmd: '/graph', title: 'Dependency Graph Studio', desc: 'Visualize module dependencies and imports graph', icon: <Network size={14} className="text-indigo-400" />, category: 'SYSTEM', systemCmd: 'graph' },
    { cmd: '/search', title: 'Spotlight Search', desc: 'Search workspace files & code symbols', icon: <SearchCode size={14} className="text-purple-400" />, category: 'SYSTEM', systemCmd: 'search' },
    { cmd: '/format', title: 'Format Active File', desc: 'Auto-format active code document', icon: <Box size={14} className="text-blue-400" />, category: 'SYSTEM', systemCmd: 'format' },
    { cmd: '/install', title: 'Install NPM Package', desc: 'Install npm package into dependencies', icon: <Package size={14} className="text-orange-400" />, category: 'SYSTEM', systemCmd: 'install' },
    { cmd: '/doctor', title: 'Run Health Doctor', desc: 'Run workspace health diagnostics', icon: <Activity size={14} className="text-teal-400" />, category: 'SYSTEM', systemCmd: 'doctor' },
    { cmd: '/clear', title: 'Clear Chat History', desc: 'Purge active chat session history', icon: <X size={14} className="text-rose-400" />, category: 'SYSTEM', systemCmd: 'clear' },
    { cmd: '/extensions', title: 'Extension Marketplace', desc: 'Browse and install workspace extensions', icon: <Package size={14} className="text-pink-400" />, category: 'WORKSPACE', systemCmd: 'extensions' },
    { cmd: '/customizer', title: 'Theme & Style Customizer', desc: 'Customize IDE UI theme, fonts & layout', icon: <Wand2 size={14} className="text-indigo-400" />, category: 'WORKSPACE', systemCmd: 'customizer' },
    { cmd: '/collab', title: 'Share & Collaborate', desc: 'Share session link or start live editing', icon: <Share2 size={14} className="text-sky-400" />, category: 'WORKSPACE', systemCmd: 'collab' },
    { cmd: '/help', title: 'Slash Commands Help', desc: 'Display all available slash commands & guide', icon: <Bot size={14} className="text-emerald-400" />, category: 'SYSTEM', systemCmd: 'help' },
  ], []);

  const filteredSlashCommands = useMemo(() => {
    if (!slashSearchQuery) return PROMPT_SLASH_COMMANDS;
    const query = slashSearchQuery.toLowerCase();
    return PROMPT_SLASH_COMMANDS.filter(item => 
      item.cmd.toLowerCase().includes(query) || 
      item.title.toLowerCase().includes(query) ||
      item.desc.toLowerCase().includes(query)
    );
  }, [PROMPT_SLASH_COMMANDS, slashSearchQuery]);

  useEffect(() => {
    setSlashSelectedIndex(0);
  }, [slashSearchQuery]);

  const executeSystemSlashCommand = (cmdName: string, extraArgs: string = "") => {
    const cleanCmd = cmdName.toLowerCase().trim();

    if (cleanCmd === 'clear') {
      if (activeSession) {
        onUpdateSession({ ...activeSession, messages: [], lastUpdated: Date.now() });
      }
      return;
    }

    if (cleanCmd === 'jwt') {
      window.dispatchEvent(new CustomEvent('aether-open-tool', { detail: { tool: 'jwt_decoder' } }));
      return;
    }

    if (cleanCmd === 'env') {
      window.dispatchEvent(new CustomEvent('aether-open-tool', { detail: { tool: 'env_manager' } }));
      return;
    }

    if (cleanCmd === 'build') {
      window.dispatchEvent(new CustomEvent('aether_run_terminal_cmd', { detail: 'npm run build' }));
      return;
    }

    if (cleanCmd === 'lint') {
      window.dispatchEvent(new CustomEvent('aether_run_terminal_cmd', { detail: 'npm run lint' }));
      return;
    }

    if (cleanCmd === 'commit') {
      const msg = extraArgs.trim() || 'feat: update workspace changes';
      window.dispatchEvent(new CustomEvent('aether_run_terminal_cmd', { detail: `git add . && git commit -m "${msg}"` }));
      return;
    }

    if (cleanCmd === 'doctor') {
      window.dispatchEvent(new CustomEvent('aether_run_terminal_cmd', { detail: 'aether doctor' }));
      return;
    }

    if (cleanCmd === 'terminal') {
      if (onCommandSelect) onCommandSelect('toggle-terminal');
      return;
    }

    if (cleanCmd === 'deploy' || cleanCmd === 'publish') {
      window.dispatchEvent(new CustomEvent("aether_open_deploy"));
      return;
    }

    if (cleanCmd === 'collab' || cleanCmd === 'share') {
      window.dispatchEvent(new CustomEvent("aether_open_share"));
      return;
    }

    if (cleanCmd === 'security') {
      if (onCommandSelect) onCommandSelect('open-security');
      return;
    }

    if (cleanCmd === 'profiler') {
      if (onCommandSelect) onCommandSelect('open-profiler');
      return;
    }

    if (cleanCmd === 'api') {
      if (onCommandSelect) onCommandSelect('open-api-playground');
      return;
    }

    if (cleanCmd === 'database') {
      if (onCommandSelect) onCommandSelect('open-database');
      return;
    }

    if (cleanCmd === 'graph') {
      if (onCommandSelect) onCommandSelect('open-dependencygraph');
      return;
    }

    if (cleanCmd === 'audiosynth') {
      if (onCommandSelect) onCommandSelect('open-audiosynth');
      return;
    }

    if (cleanCmd === 'uistudio') {
      if (onCommandSelect) onCommandSelect('open-uistudio');
      return;
    }

    if (cleanCmd === 'datatransformer') {
      if (onCommandSelect) onCommandSelect('open-datatransformer');
      return;
    }

    if (cleanCmd === 'search') {
      if (onCommandSelect) onCommandSelect('open-search');
      return;
    }

    if (cleanCmd === 'history') {
      if (onCommandSelect) onCommandSelect('open-history');
      return;
    }

    if (cleanCmd === 'tasks') {
      if (onCommandSelect) onCommandSelect('open-tasks');
      return;
    }

    if (cleanCmd === 'extensions' || cleanCmd === 'ext') {
      if (onCommandSelect) onCommandSelect('open-marketplace');
      return;
    }

    if (cleanCmd === 'customizer' || cleanCmd === 'theme') {
      if (onCommandSelect) onCommandSelect('open-customizer');
      return;
    }

    if (cleanCmd === 'format') {
      if (onCommandSelect) onCommandSelect('format-doc');
      return;
    }

    if (cleanCmd === 'install') {
      if (onCommandSelect) onCommandSelect('install-package');
      return;
    }

    if (cleanCmd === 'help') {
      const activeSession = sessions.find(s => s.id === activeSessionId);
      if (activeSession) {
        const helpMessage: ChatSession['messages'][0] = {
          id: generateId(),
          role: 'model',
          text: `### ⚡ Aether IDE Slash Commands Directory\n\nAll available slash commands accessible directly from the AI chat input bar:\n\n` +
            `**AI Prompt & Generation Tools**\n` +
            `- \`/image <prompt>\`: Generate AI images & visual assets\n` +
            `- \`/draw <prompt>\`: Synthesize custom vector SVG graphics\n` +
            `- \`/ui <prompt>\`: Build React components & Tailwind UI widgets\n` +
            `- \`/refactor <instruction>\`: Autonomous code refactorer\n` +
            `- \`/fix\`: Detect and auto-correct syntax bugs\n` +
            `- \`/test <scope>\`: Generate Vitest / Jest test suites\n` +
            `- \`/db <schema>\`: Build Drizzle ORM / Firestore models\n` +
            `- \`/mock <endpoint>\`: Generate REST API endpoints & mock JSON\n` +
            `- \`/audio <sound>\`: Synthesize web audio sound FX\n` +
            `- \`/docs\`: Generate Markdown project documentation\n` +
            `- \`/enhance\`: Enhance simple prompt into detailed spec\n\n` +
            `**ASI Tools & Inspectors**\n` +
            `- \`/jwt\`: Open JWT Token Decoder & Inspector\n` +
            `- \`/env\`: Open Environment Variable (.env) Manager\n` +
            `- \`/api\`: Open REST API Request Studio\n` +
            `- \`/database\`: Open Firestore & SQL Database Studio\n` +
            `- \`/graph\`: Visualize Code Architecture & Module Graph\n` +
            `- \`/audiosynth\`: Open Sound FX Synthesizer Studio\n` +
            `- \`/uistudio\`: Open UI Component & Theme Studio\n` +
            `- \`/datatransformer\`: Open JSON Engine & Data Transformer\n` +
            `- \`/search\`: Global Spotlight Workspace Search\n` +
            `- \`/history\`: File Revision History & Git Time Machine\n` +
            `- \`/security\`: Gatekeeper Security Scanner\n` +
            `- \`/profiler\`: Performance & Memory Profiler\n` +
            `- \`/tasks\`: Background Task Runner Agent\n\n` +
            `**System & DevOps**\n` +
            `- \`/terminal\`: Toggle Linux Terminal Console\n` +
            `- \`/build\`: Execute \`npm run build\` production compile\n` +
            `- \`/lint\`: Execute \`npm run lint\` static type check\n` +
            `- \`/commit <msg>\`: Git commit workspace changes\n` +
            `- \`/deploy\`: Deploy application to Cloud Run\n` +
            `- \`/doctor\`: Run Aether Health Diagnostics\n` +
            `- \`/install\`: Install NPM dependency\n` +
            `- \`/format\`: Auto-format active document\n` +
            `- \`/clear\`: Purge active session chat history\n` +
            `- \`/help\`: Display this slash command directory`,
          timestamp: Date.now()
        };
        onUpdateSession({
          ...activeSession,
          messages: [...activeSession.messages, helpMessage],
          lastUpdated: Date.now()
        });
      }
      return;
    }

    if (onCommandSelect) {
      onCommandSelect(cleanCmd);
    }
  };

  const handleSelectSlashCommand = (item: typeof PROMPT_SLASH_COMMANDS[0]) => {
    if (item.systemCmd) {
      setInput("");
      setShowSlashDropdown(false);
      executeSystemSlashCommand(item.systemCmd);
    } else if (item.promptPrefix) {
      setInput(item.promptPrefix);
      setShowSlashDropdown(false);
      if (textareaRef.current) {
        textareaRef.current.focus();
      }
    }
  };

  const handleGenerateAIImage = async (promptText: string) => {
    if (!activeSessionId) return;

    const userMsgText = `🎨 /image ${promptText}`;
    const userMsgId = generateId("u");
    const userMsg: ChatSession['messages'][0] = {
      id: userMsgId,
      role: "user",
      text: userMsgText,
      timestamp: Date.now()
    };

    const botMsgId = generateId("b");
    const botMsgLoading: ChatSession['messages'][0] = {
      id: botMsgId,
      role: "model",
      text: `🎨 *Synthesizing AI Visual Asset using Imagen 3 & Gemini engine for prompt:* **"${promptText}"**...\n\n⌛ *Connecting to neural rendering node...*`,
      timestamp: Date.now()
    };

    const currentSession = sessions.find(s => s.id === activeSessionId);
    if (currentSession) {
      onUpdateSession({
        ...currentSession,
        messages: [...currentSession.messages, userMsg, botMsgLoading],
        lastUpdated: Date.now()
      });
    }

    try {
      const res = await fetch("/api/ai/image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: promptText,
          aspectRatio: "16:9",
          highQuality: true
        })
      });

      const data = await res.json();
      const imageUrl = data.imageUrl || data.image || `https://image.pollinations.ai/prompt/${encodeURIComponent(promptText)}?width=1024&height=576&nologo=true`;

      const imageFileName = `public/images/gen_${Date.now()}.png`;
      if (onAgentAction) {
        await onAgentAction([{
          action: 'create',
          path: imageFileName,
          content: imageUrl
        }]);
      }

      const finalMarkdown = `### 🖼️ AI Visual Asset Generated

![${promptText}](${imageUrl})

**Prompt Spec:** \`${promptText}\`  
**Saved to Workspace:** \`${imageFileName}\`  
*Render Engine: Gemini Imagen 3 / Pollinations Neural Pipeline*
`;

      const sessionToUpdate = sessions.find(s => s.id === activeSessionId);
      if (sessionToUpdate) {
        const updatedMsgs = sessionToUpdate.messages.map(m => 
          m.id === botMsgId ? { ...m, text: finalMarkdown } : m
        );
        onUpdateSession({
          ...sessionToUpdate,
          messages: updatedMsgs,
          lastUpdated: Date.now()
        });
      }
    } catch (e: any) {
      const fallbackUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(promptText)}?width=1024&height=576&nologo=true`;
      const finalMarkdown = `### 🖼️ AI Visual Asset Generated

![${promptText}](${fallbackUrl})

**Prompt Spec:** \`${promptText}\`  
*Render Engine: Pollinations Neural Pipeline*
`;

      const sessionToUpdate = sessions.find(s => s.id === activeSessionId);
      if (sessionToUpdate) {
        const updatedMsgs = sessionToUpdate.messages.map(m => 
          m.id === botMsgId ? { ...m, text: finalMarkdown } : m
        );
        onUpdateSession({
          ...sessionToUpdate,
          messages: updatedMsgs,
          lastUpdated: Date.now()
        });
      }
    }
  };

  const handleInputChange = (val: string) => {
    setInput(val);
    
    // Auto-resize logic
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 140)}px`;
    }

    const lastWord = val.split(/\s+/).pop() || "";
    if (lastWord.startsWith("@")) {
      setShowAtMentionDropdown(true);
      setAtMentionSearchQuery(lastWord.slice(1));
      setShowFileDropdown(false);
      setShowSlashDropdown(false);
    } else if (val.startsWith("/") || lastWord.startsWith("/")) {
      setShowSlashDropdown(true);
      const search = val.startsWith("/") ? val.slice(1) : lastWord.slice(1);
      setSlashSearchQuery(search);
      setShowFileDropdown(false);
      setShowAtMentionDropdown(false);
    } else {
      setShowFileDropdown(false);
      setShowAtMentionDropdown(false);
      setShowSlashDropdown(false);
    }
    if (activeSessionId && user && val.length > 0) {
      socketService.emitTyping(activeSessionId, user.name || "Anonymous");
    }
  };

  const handleSelectDivisionMention = (division: DivisionActionItem) => {
    const words = input.split(/\s+/);
    words.pop(); // remove "@" token
    const base = words.join(" ");
    const nextInput = (base ? base + " " : "") + division.mentionTag + " ";
    setInput(nextInput);
    setShowAtMentionDropdown(false);
    setAtMentionSearchQuery("");

    // Activate the division's agents in manualSelectedAgents / spawnedAgents
    const agentIds = division.agents.map(a => a.id);
    setManualSelectedAgents(prev => Array.from(new Set([...prev, ...agentIds])));
    setSpawnedAgents(prev => Array.from(new Set([...prev, ...agentIds])));

    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  const handleSelectAgentMention = (agent: OrchestratorAgent) => {
    const words = input.split(/\s+/);
    words.pop(); // remove "@" token
    const base = words.join(" ");
    const nextInput = (base ? base + " " : "") + `@${agent.id} `;
    setInput(nextInput);
    setShowAtMentionDropdown(false);
    setAtMentionSearchQuery("");

    setManualSelectedAgents(prev => Array.from(new Set([...prev, agent.id])));
    setSpawnedAgents(prev => Array.from(new Set([...prev, agent.id])));

    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  const handleSelectFileRef = (file: FileNode) => {
    if (!referencedFiles.some(f => f.id === file.id)) {
      setReferencedFiles(prev => [...prev, file]);
    }
    const words = input.split(/\s+/);
    words.pop(); // remove "@" token
    const base = words.join(" ");
    setInput(base + (base ? " " : ""));
    setShowFileDropdown(false);
    setShowAtMentionDropdown(false);
    setFileSearchQuery("");
    setAtMentionSearchQuery("");
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  const filteredFiles = useMemo(() => {
    if (!fileSearchQuery) return files.slice(0, 8);
    return files.filter(f => f.name.toLowerCase().includes(fileSearchQuery.toLowerCase())).slice(0, 8);
  }, [files, fileSearchQuery]);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [expandedReasoning, setExpandedReasoning] = useState<Record<string, boolean>>({});
  const [modelsList, setModelsList] = useState(() => getAvailableModels());

  const [showCustomModelModal, setShowCustomModelModal] = useState(false);
  const [customModelInput, setCustomModelInput] = useState("");
  const [customModelProvider, setCustomModelProvider] = useState<"nvidia" | "anthropic" | "offline" | "ollama">("ollama");

  const handleRunCustomModel = () => {
    const raw = customModelInput.trim();
    if (!raw) return;

    let provider = customModelProvider;
    const lower = raw.toLowerCase();
    if (lower.startsWith("claude") || lower.includes("anthropic")) {
      provider = "anthropic";
    } else if (lower.includes("nemotron") || lower.includes("ollama") || lower.includes("llama") || lower.includes("mistral") || lower.includes("deepseek")) {
      provider = "ollama";
    }

    const modelId = raw;

    const added = addCustomModel({
      id: modelId,
      name: `⚡ ${raw}`,
      description: `User-specified custom model (${provider})`,
      type: provider
    });

    setSelectedModel(added.id);
    setShowCustomModelModal(false);
    setCustomModelInput("");
  };

  // Set default model from project or user settings
  const currentSession = sessions.find(s => s.id === activeSessionId);
  useEffect(() => {
    let newModel = user.aiSettings?.defaultModel || "gemini-3.1-pro-preview";
    if (currentSession?.settings?.defaultModel && currentSession.settings.defaultModel !== "default") {
        newModel = currentSession.settings.defaultModel;
    }
    setSelectedModel(newModel);
  }, [activeSessionId, user.aiSettings?.defaultModel, currentSession?.settings?.defaultModel]);

  // Offline model download states
  const [downloadState, setDownloadState] = useState(() => getOfflineModelStatus("qwen-2.5-0.5b-offline"));

  useEffect(() => {
    if (selectedModel.includes('offline')) {
      setDownloadState(getOfflineModelStatus(selectedModel));
    }
  }, [selectedModel]);

  const handleDownloadOfflineModel = () => {
    if (downloadState.status === 'downloading' || downloadState.status === 'ready') return;
    
    const initialStatus = getOfflineModelStatus(selectedModel);
    const shards: { name: string; size: string; progress: number; status: 'pending' | 'downloading' | 'completed' }[] = initialStatus.shards.map(s => ({ ...s, progress: 0, status: 'pending' }));
    const modelConfig = getOfflineModelConfig(selectedModel);

    let activeIndex = 0;
    
    const updateProgress = () => {
      if (activeIndex >= shards.length) {
        const finalStatus = {
          status: 'ready' as const,
          progress: 100,
          activeShard: '',
          shards: shards.map(s => ({ ...s, progress: 100, status: 'completed' as const }))
        };
        setDownloadState(finalStatus);
        saveOfflineModelStatus(selectedModel, finalStatus);
        console.log(`Successfully downloaded and cached local ${modelConfig.name} weights in IndexedDB!`);
        return;
      }

      const activeShard = shards[activeIndex];
      activeShard.status = 'downloading';
      activeShard.progress += 25;

      if (activeShard.progress >= 100) {
        activeShard.progress = 100;
        activeShard.status = 'completed';
        activeIndex++;
      }

      const overallProgress = Math.round((shards.reduce((acc, s) => acc + s.progress, 0) / (shards.length * 100)) * 100);

      const updatedStatus = {
        status: 'downloading' as const,
        progress: overallProgress,
        activeShard: activeShard.name,
        shards: [...shards]
      };

      setDownloadState(updatedStatus);
      saveOfflineModelStatus(selectedModel, updatedStatus);

      setTimeout(updateProgress, 180);
    };

    updateProgress();
  };

  const handleToggleAgent = (agentId: string) => {
    setManualSelectedAgents(prev => {
      if (prev.includes(agentId)) {
        if (prev.length <= 1) return prev;
        return prev.filter(id => id !== agentId);
      } else {
        return [...prev, agentId];
      }
    });
  };

  useEffect(() => {
    setModelsList(getAvailableModels());
    autoFetchAndSyncOllamaModels();
    const handleUpdate = () => {
      setModelsList(getAvailableModels());
    };
    window.addEventListener("aether_custom_models_updated", handleUpdate);
    return () => {
      window.removeEventListener("aether_custom_models_updated", handleUpdate);
    };
  }, []);
  const [isThinkingMode, setIsThinkingMode] = useState(true);
  const [showCognitiveTuning, setShowCognitiveTuning] = useState(false);
  const [thinkLimitBudget, setThinkLimitBudget] = useState(() => Number(localStorage.getItem('think_token_budget')) || 32768);
  const [tokenCompaction, setTokenCompaction] = useState(() => localStorage.getItem('token_compaction_enabled') === 'true');
  const [githubUser, setGithubUser] = useState(() => localStorage.getItem('github_connector_user') || '');

  useEffect(() => {
    const handleSync = () => {
      setThinkLimitBudget(Number(localStorage.getItem('think_token_budget')) || 32768);
      setGithubUser(localStorage.getItem('github_connector_user') || '');
    };
    window.addEventListener('think_budget_updated', handleSync);
    window.addEventListener('aether_extensions_updated', handleSync);
    return () => {
      window.removeEventListener('think_budget_updated', handleSync);
      window.removeEventListener('aether_extensions_updated', handleSync);
    };
  }, []);

  const compactContext = (text: string, limit: number = 8000) => {
    // Stage 1: Normalize whitespace while preserving essential formatting
    let processed = text.replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();

    if (processed.length <= limit) return processed;
    
    // Stage 2: If code is longer than limit, provide the complete beginning and clean truncation at function boundary
    const lines = processed.split('\n');
    let accumulated = '';
    for (const line of lines) {
      if ((accumulated.length + line.length) > limit) {
        accumulated += `\n\n// ... [Context truncated for length - total lines: ${lines.length}]`;
        break;
      }
      accumulated += (accumulated ? '\n' : '') + line;
    }
    return accumulated;
  };

  const dynamicShortcuts = useMemo(() => {
    const shortcuts = [];
    
    // Check if React files exist
    const hasReact = files.some(f => f.name.endsWith('.tsx') || f.name.endsWith('.jsx'));
    // Check if three.js or canvas is used (scene.json, etc.)
    const has3D = files.some(f => f.name.includes('scene') || f.name.includes('three') || f.content?.includes('THREE'));
    // Check if audio is used
    const hasAudio = files.some(f => f.name.includes('audio') || f.name.includes('sound') || f.content?.includes('AudioContext'));
    const hasNode = files.some(f => f.name === 'server.ts' || f.name === 'server.js');
    const hasCSS = files.some(f => f.name.endsWith('.css'));
    const hasHTML = files.some(f => f.name.endsWith('.html'));
    const hasGameEngine = files.some(f => f.name.includes('Game') || f.name.includes('Arena') || f.name.includes('Engine'));

    shortcuts.push({
      label: "🌐 Multi-Page App",
      color: "from-amber-500/10 to-orange-500/10 text-amber-400 border-amber-500/20",
      prompt: "Create a complete multi-page application with physical folder architecture (pages/, components/, routes/), modular subpages (Home, Dashboard, Analytics, Settings), and responsive navigation."
    });
    shortcuts.push({
      label: "📁 Physical Folders",
      color: "from-cyan-500/10 to-blue-500/10 text-cyan-400 border-cyan-500/20",
      prompt: "Reorganize the project into a clean physical folder hierarchy (src/pages/, src/components/, src/services/, src/hooks/) with modular imports."
    });

    if (hasReact) {
      shortcuts.push({ label: "🎨 Polished UI", color: "from-blue-500/10 to-indigo-500/10 text-blue-400 border-blue-500/20", prompt: "Improve the UI design and layout in the React components with modern styling." });
    }
    
    if (has3D || hasGameEngine) {
      shortcuts.push({ label: "👾 World Scene", color: "from-indigo-500/10 to-blue-500/10 text-indigo-400 border-indigo-500/20", prompt: "Create a rich 3D environment in scene.json with interactive models and lighting." });
    }

    if (hasAudio) {
      shortcuts.push({ label: "🔊 Audio Engine", color: "from-emerald-500/10 to-teal-500/10 text-emerald-400 border-emerald-500/20", prompt: "Implement professional audio systems using Web Audio API." });
    }

    if (hasNode) {
      shortcuts.push({ label: "🔌 Add API Endpoint", color: "from-green-500/10 to-emerald-500/10 text-green-400 border-green-500/20", prompt: "Add a new API endpoint to the backend server." });
    }

    if (hasCSS && !hasReact) {
      shortcuts.push({ label: "💅 Modernize CSS", color: "from-pink-500/10 to-rose-500/10 text-pink-400 border-pink-500/20", prompt: "Update the CSS to use modern styling with flexbox/grid and better color schemes." });
    }

    if (hasHTML && !hasReact) {
      shortcuts.push({ label: "📝 Add HTML Section", color: "from-orange-500/10 to-amber-500/10 text-orange-400 border-orange-500/20", prompt: "Add a new interactive section to the HTML structure." });
    }

    // Default fallbacks if we don't have enough
    if (shortcuts.length < 5) {
      if (!shortcuts.find(s => s.label === "🐛 Fix Bugs")) shortcuts.push({ label: "🐛 Fix Bugs", color: "from-red-500/10 to-orange-500/10 text-red-400 border-red-500/20", prompt: "Analyze the code for potential bugs and fix them." });
      if (!shortcuts.find(s => s.label === "📝 Document Code")) shortcuts.push({ label: "📝 Document Code", color: "from-gray-500/10 to-slate-500/10 text-gray-400 border-gray-500/20", prompt: "Add comments and documentation to the main functions." });
      if (!shortcuts.find(s => s.label === "🚀 Optimize")) shortcuts.push({ label: "🚀 Optimize", color: "from-purple-500/10 to-violet-500/10 text-purple-400 border-purple-500/20", prompt: "Optimize the current codebase for speed and efficiency." });
      if (!shortcuts.find(s => s.label === "✨ Code Audit")) shortcuts.push({ label: "✨ Code Audit", color: "from-cyan-500/10 to-blue-500/10 text-cyan-400 border-cyan-500/20", prompt: "Perform a deep security and stability audit on the current code." });
    }

    return shortcuts.slice(0, 5);
  }, [files]);


  const [attachments, setAttachments] = useState<
    { name: string; type: string; mimeType: string; data?: string; url?: string }[]
  >([]);
  const [isSpeaking, setIsSpeaking] = useState<string | null>(null);
  const [isCopying, setIsCopying] = useState<string | null>(null);
  const [editingMsgId, setEditingMsgId] = useState<string | null>(null);
  const [editInput, setEditInput] = useState("");
  const [isReasoningExpanded, setIsReasoningExpanded] = useState(true);

  // Application Audio State Variables & Persistent Setup
  const [aetherAudioMode, setApplicationAudioMode] = useState<"muted" | "browser" | "premium">(() => {
    return (localStorage.getItem("aether_audio_mode") as any) || "muted";
  });
  const [aetherVoice, setApplicationVoice] = useState<"Kore" | "Puck" | "Fenrir" | "Zephyr" | "Charon">(() => {
    return (localStorage.getItem("aether_voice") as any) || "Kore";
  });
  const [showVoiceMenu, setShowVoiceMenu] = useState(false);
  const [showMoreTools, setShowMoreTools] = useState(false);
  const activeAudioRef = useRef<{ source: AudioBufferSourceNode; ctx: AudioContext } | null>(null);
  const prevIsProcessing = useRef(isProcessing);

  useEffect(() => {
    localStorage.setItem("aether_audio_mode", aetherAudioMode);
  }, [aetherAudioMode]);

  useEffect(() => {
    localStorage.setItem("aether_voice", aetherVoice);
  }, [aetherVoice]);

  useEffect(() => {
    return () => {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
      if (activeAudioRef.current) {
        try {
          activeAudioRef.current.source.stop();
          activeAudioRef.current.ctx.close();
        } catch (e) {
          // ignore
        }
      }
    };
  }, []);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  // Ref for AbortController to support Stop Generation
  const stopControllerRef = useRef<AbortController | null>(null);

  const activeSession = sessions.find((s) => s.id === activeSessionId) || null;

  // Use simple reference or memoized messages
  const lastBotMessage = useMemo(() => {
    return activeSession?.messages
      ?.filter((m) => m.role === "model")
      ?.slice(-1)[0];
  }, [activeSession?.messages]);

  const [isOffline, setIsOffline] = useState(
    connectivityService.getStatus() === "offline",
  );

  useEffect(() => {
    return connectivityService.subscribe((status) => {
      setIsOffline(status === "offline");
    });
  }, []);

  useEffect(() => {
    if (prevIsProcessing.current && !isProcessing && aetherAudioMode !== "muted") {
      const lastMsg = lastBotMessage;
      if (lastMsg && lastMsg.role === "model") {
        handleSpeak(lastMsg.text, lastMsg.id);
      }
    }
    prevIsProcessing.current = isProcessing;
  }, [isProcessing, aetherAudioMode, lastBotMessage?.id]);

  const handleSend = () => {
    if (
      (!input.trim() && attachments.length === 0) ||
      !activeSessionId ||
      isProcessing
    )
      return;

    const lowerInput = input.trim().toLowerCase();
    const isCurrentlyViewingGame = activeRightTab === "game" || (activeRightTab === "split" && splitSubTab === "game");
    const forcesGeneralWeb = lowerInput.startsWith("/web") || lowerInput.startsWith("/code");

    // 1. Fully Automatic Game Prompt Detector & Router
    const isGamePrompt = !forcesGeneralWeb && (
      isCurrentlyViewingGame ||
      ((lowerInput.includes("game") || 
        lowerInput.includes("three.js") || 
        lowerInput.includes("physics") || 
        lowerInput.includes("wasd") || 
        lowerInput.includes("collision") || 
        lowerInput.includes("space shooter") || 
        lowerInput.includes("rpg") || 
        lowerInput.includes("orbitcontrols") || 
        lowerInput.includes("canvas game") || 
        lowerInput.includes("retro sound") || 
        lowerInput.includes("synth sound") || 
        lowerInput.includes("laser sound") || 
        lowerInput.includes("play screen") || 
        lowerInput.includes("scoreboard")) &&
       !lowerInput.includes("audit") && 
       !lowerInput.includes("github") &&
       !lowerInput.includes("sql") &&
       !lowerInput.includes("database"))
    );

    // Game prompts fall through directly to standard neural co-pilot session with no redirects

    if (onUploadFiles && attachments.length > 0) {
      const fileAttachments = attachments
        .filter((a) => a.data)
        .map((a) => ({
          name: a.name,
          type: (a.type === "image" ? "image" : "file") as "image" | "file",
          mimeType: a.mimeType,
          data: a.data || "",
        }));
      if (fileAttachments.length > 0) {
        onUploadFiles(fileAttachments);
      }
    }

    // Collect link / web reference attachments to include in AI prompt context
    const linkAttachments = attachments.filter((a) => a.url);
    let promptUrlContext = "";
    if (linkAttachments.length > 0) {
      promptUrlContext = linkAttachments
        .map((l) => `[ATTACHED WEB/IMAGE URL CONTEXT (${l.type})]: ${l.url}`)
        .join("\n") + "\n\n";
    }

    const payloadAttachments = attachments
      .filter((a) => a.data)
      .map((a) => ({
        mimeType: a.mimeType,
        data: a.data,
      }));
    
    // Preserve the user's selected model
    const resolvedModel = selectedModel || "aether-pro";
    
    // Slash Command Check & Direct Routing
    const trimmedInput = input.trim();
    const imageCmdMatch = trimmedInput.match(/^\/(image|generate-image|draw)\s*(.*)/i);
    if (imageCmdMatch) {
      const promptText = imageCmdMatch[2].trim() || "A futuristic AI engineering dashboard with glowing cybernetic accents in 3D WebGL render";
      setInput("");
      setShowSlashDropdown(false);
      handleGenerateAIImage(promptText);
      return;
    }

    const sysCmdMatch = trimmedInput.match(/^\/(terminal|deploy|publish|security|profiler|api|database|search|format|install|doctor|clear|jwt|env|build|lint|commit|ext|extensions|theme|customizer|graph|audiosynth|uistudio|datatransformer|collab|share|history|tasks|help)\b(.*)/i);
    if (sysCmdMatch) {
      const cmdName = sysCmdMatch[1].toLowerCase();
      const extraArgs = (sysCmdMatch[2] || "").trim();
      setInput("");
      setShowSlashDropdown(false);
      executeSystemSlashCommand(cmdName, extraArgs);
      return;
    }

    // Prompt-based tools enrichment
    const uiMatch = trimmedInput.match(/^\/ui\s*(.*)/i);
    const refactorMatch = trimmedInput.match(/^\/refactor\s*(.*)/i);
    const fixMatch = trimmedInput.match(/^\/fix\b/i);
    const testMatch = trimmedInput.match(/^\/test\s*(.*)/i);
    const dbMatch = trimmedInput.match(/^\/db\s*(.*)/i);
    const mockMatch = trimmedInput.match(/^\/mock\s*(.*)/i);
    const docsMatch = trimmedInput.match(/^\/docs\b/i);

    let finalPrompt = input;
    if (forcesGeneralWeb) {
      finalPrompt = input.replace(/^\/(web|code)\s*/i, "");
    } else if (uiMatch) {
      const promptText = uiMatch[1].trim() || "A modern glassmorphic UI component card";
      finalPrompt = `[PROMPT-BASED UI COMPONENT TOOL]: Build a complete, interactive React component with TypeScript and Tailwind CSS based on: "${promptText}". Export default the main component.`;
    } else if (refactorMatch) {
      const promptText = refactorMatch[1].trim() || "Clean up code structure and type safety";
      const activeFile = files.find(f => f.id === activeFileId);
      finalPrompt = `[PROMPT-BASED REFACTOR TOOL]: Refactor active workspace file (${activeFile?.name || "App.tsx"}) according to: "${promptText}". Provide clean code updates.`;
    } else if (fixMatch) {
      finalPrompt = `[PROMPT-BASED BUG FIXER TOOL]: Scan all workspace files for syntax errors, missing imports, unhandled exceptions or type issues and apply fix updates.`;
    } else if (testMatch) {
      const promptText = testMatch[1].trim() || "Unit test suite for active components";
      const activeFile = files.find(f => f.id === activeFileId);
      finalPrompt = `[PROMPT-BASED UNIT TEST GENERATOR]: Generate a full Vitest/Jest unit test file in TypeScript for (${activeFile?.name || "App.tsx"}) matching: "${promptText}".`;
    } else if (dbMatch) {
      const promptText = dbMatch[1].trim() || "User accounts, posts, and comments schema";
      finalPrompt = `[PROMPT-BASED DATABASE SCHEMA BUILDER]: Create a complete Drizzle ORM TypeScript schema or Firestore model for: "${promptText}".`;
    } else if (mockMatch) {
      const promptText = mockMatch[1].trim() || "Users and products REST API dataset";
      finalPrompt = `[PROMPT-BASED MOCK API GENERATOR]: Generate Express route handlers and sample JSON mock datasets for: "${promptText}".`;
    } else if (docsMatch) {
      finalPrompt = `[PROMPT-BASED DOCUMENTATION GENERATOR]: Write clean Markdown documentation for this project in README.md including features, installation, and API guide.`;
    }

    // 2. Intelligent Auto-Enrichment for General Coder (styling vs bug fixing)
    const isStylingQuery = (
      lowerInput.includes("style") || 
      lowerInput.includes("css") || 
      lowerInput.includes("tailwind") || 
      lowerInput.includes("design") || 
      lowerInput.includes("layout") || 
      lowerInput.includes("padding") || 
      lowerInput.includes("margin") || 
      lowerInput.includes("aesthetic") || 
      lowerInput.includes("border") || 
      lowerInput.includes("color scheme") ||
      lowerInput.includes("theme") ||
      lowerInput.includes("beautiful") ||
      lowerInput.includes("modernize")
    );

    const isDebuggerQuery = (
      lowerInput.includes("bug") || 
      lowerInput.includes("fix") || 
      lowerInput.includes("error") || 
      lowerInput.includes("broken") || 
      lowerInput.includes("syntax") || 
      lowerInput.includes("compile") || 
      lowerInput.includes("failed") || 
      lowerInput.includes("crash") || 
      lowerInput.includes("exception") || 
      lowerInput.includes("audit") ||
      lowerInput.includes("infinite loop") ||
      lowerInput.includes("not working") ||
      lowerInput.includes("doesn't work")
    );

    if (isStylingQuery) {
      finalPrompt = "[VISUAL DESIGNER Core Agent Engaged: Prioritize elegant visual layout, mathematical typography scales, warm/cool cohesive color schemes, generous white space, and proper nesting radiuses. Use Tailwind CSS.]\n\n" + finalPrompt;
    } else if (isDebuggerQuery) {
      finalPrompt = "[CODE AUDITOR & DEBUGGER Core Agent Engaged: Carefully inspect the current project state, active files, and syntax for any compile errors, unclosed HTML/React tags, unclosed brackets, or run-time exceptions. Fix them with targeted updates.]\n\n" + finalPrompt;
    }

    // Append custom instructions if they exist
    const globalInstructions = user.aiSettings?.customInstructions;
    const projectInstructions = currentSession?.settings?.customInstructions;
    
    if (globalInstructions || projectInstructions) {
        finalPrompt += "\n\n--- CUSTOM INSTRUCTIONS ---\n";
        if (globalInstructions) {
            finalPrompt += `Global Instructions:\n${globalInstructions}\n\n`;
        }
        if (projectInstructions) {
            finalPrompt += `Project Instructions:\n${projectInstructions}\n\n`;
        }
    }

    if (referencedFiles.length > 0) {
      finalPrompt += "\n\n--- MANUALLY REFERENCED WORKSPACE FILES ---\n" + 
        referencedFiles.map(f => {
          let content = f.content || '';
          if (tokenCompaction) {
            content = compactContext(content, 2500); // Save tokens via semantic pruning!
          }
          return `Path: ${f.name}\n\`\`\`${f.language || 'typescript'}\n${content}\n\`\`\``;
        }).join('\n\n');
    }

    onSendMessage(promptUrlContext + finalPrompt, payloadAttachments, resolvedModel, isCompactMode, undefined, classification.spawnedAgents);

    setInput("");
    setAttachments([]);
    setReferencedFiles([]);
    setShowFileDropdown(false);
    if (textareaRef.current) textareaRef.current.style.height = "auto";
  };

  const handleCapturePreview = async () => {
    try {
      const iframe = document.getElementById("main-preview-iframe") as HTMLIFrameElement;
      const container = document.getElementById("aether-preview-container");
      
      let targetElement: HTMLElement | null = null;
      
      // Try to get iframe body if available
      if (iframe) {
        const doc = iframe.contentDocument || iframe.contentWindow?.document;
        if (doc && doc.body) {
          targetElement = doc.body;
        }
      }
      
      // Fallback to the whole preview container if iframe body is not accessible
      if (!targetElement && container) {
        targetElement = container;
      }
      
      if (!targetElement || !targetElement.clientWidth) {
        console.warn("Snapshot target not found or has no width.");
        return;
      }

      // Use html2canvas to capture the target
      const canvas = await html2canvas(targetElement, {
        useCORS: true,
        allowTaint: true,
        backgroundColor: "#ffffff",
        scale: 1, // Use 1 for better performance on snapshots
        logging: false,
        width: targetElement.clientWidth,
        height: targetElement.clientHeight
      });

      const dataUrl = canvas.toDataURL("image/jpeg", 0.8);
      const base64Data = dataUrl.split(",")[1];
      
      setAttachments((prev) => [
        ...prev,
        {
          name: `Preview_Snapshot_${new Date().toLocaleTimeString().replace(/:/g, "-")}.jpg`,
          type: "image",
          mimeType: "image/jpeg",
          data: base64Data,
        },
      ]);
      
      if (textareaRef.current) {
        textareaRef.current.focus();
      }
    } catch (e) {
      console.error("Preview snapshot failed", e);
    }
  };

  const handleStop = () => {
    // Logic for stopping generation if implemented in parent
    onSendMessage("STOP_GENERATION_COMMAND", [], selectedModel);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (showSlashDropdown && filteredSlashCommands.length > 0) {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setSlashSelectedIndex(prev => (prev + 1) % filteredSlashCommands.length);
        return;
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        setSlashSelectedIndex(prev => (prev - 1 + filteredSlashCommands.length) % filteredSlashCommands.length);
        return;
      }
      if (e.key === "Enter" || e.key === "Tab") {
        e.preventDefault();
        const selected = filteredSlashCommands[slashSelectedIndex];
        if (selected) {
          handleSelectSlashCommand(selected);
        }
        return;
      }
      if (e.key === "Escape") {
        e.preventDefault();
        setShowSlashDropdown(false);
        return;
      }
    }

    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleEnhance = async () => {
    if (!input.trim()) return;
    setIsEnhancing(true);
    const enhanced = await enhancePrompt(input);
    setInput(enhanced);
    setIsEnhancing(false);
  };

  const handleFileUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    type: "image" | "file",
  ) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const result = ev.target?.result as string;
        const base64 = result.split(",")[1];
        setAttachments((prev) => [
          ...prev,
          {
            name: file.name,
            type,
            mimeType: file.type || "text/plain",
            data: base64,
          },
        ]);
      };
      reader.readAsDataURL(file);
    });
    e.target.value = "";
  };

  const toggleVoiceInput = () => {
    if (isListening) {
      setIsListening(false);
      return;
    }
    const SpeechRecognition =
      (window as any).SpeechRecognition ||
      (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Voice input not supported in this browser.");
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = "en-US";
    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInput((prev) => (prev ? prev + " " : "") + transcript);
    };
    recognition.start();
  };

  const stopAllSpeech = () => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    if (activeAudioRef.current) {
      try {
        activeAudioRef.current.source.stop();
        activeAudioRef.current.ctx.close();
      } catch (e) {
        // ignore
      }
      activeAudioRef.current = null;
    }
    setIsSpeaking(null);
  };

  const handleSpeak = async (text: string, msgId: string, forceMode?: "browser" | "premium") => {
    if (isSpeaking === msgId) {
      stopAllSpeech();
      return;
    }

    stopAllSpeech();
    setIsSpeaking(msgId);

    const mode = forceMode || (aetherAudioMode === "muted" ? "premium" : aetherAudioMode);

    if (mode === "premium") {
      try {
        // Clean text to avoid reading markdown structure
        const cleanText = text
          .replace(/[#*`_~]/g, "")
          .replace(/\[.*?\]\(.*?\)/g, "")
          .replace(/```[\s\S]*?```/g, "[Generated code omitted from voice]")
          .trim();

        const response = await fetch("/api/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: cleanText, voice: aetherVoice }),
        });

        if (!response.ok) {
          throw new Error("TTS endpoint failed");
        }

        const data = await response.json();
        if (data.success && data.audio) {
          const binaryString = atob(data.audio);
          const len = binaryString.length;
          const bytes = new Uint8Array(len);
          const view = new DataView(bytes.buffer);
          for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }

          const numSamples = len / 2;
          const float32Data = new Float32Array(numSamples);
          for (let i = 0; i < numSamples; i++) {
            const sample = view.getInt16(i * 2, true);
            float32Data[i] = sample / 32768.0;
          }

          const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
          if (!AudioContextClass) {
            throw new Error("AudioContext unsupported");
          }

          const audioCtx = new AudioContextClass();
          const audioBuffer = audioCtx.createBuffer(1, numSamples, 24000);
          audioBuffer.getChannelData(0).set(float32Data);

          const source = audioCtx.createBufferSource();
          source.buffer = audioBuffer;
          source.connect(audioCtx.destination);

          source.onended = () => {
            if (activeAudioRef.current?.source === source) {
              setIsSpeaking(null);
            }
          };

          source.start(0);
          activeAudioRef.current = { source, ctx: audioCtx };
        } else {
          throw new Error("Invalid speech payload");
        }
      } catch (err) {
        console.warn("Application premium transcription failed, falling back to browser speak...", err);
        const utterance = new SpeechSynthesisUtterance(text.replace(/[#*`_~]/g, ""));
        utterance.onend = () => setIsSpeaking(null);
        window.speechSynthesis.speak(utterance);
      }
    } else {
      const utterance = new SpeechSynthesisUtterance(text.replace(/[#*`_~]/g, ""));
      utterance.onend = () => setIsSpeaking(null);
      window.speechSynthesis.speak(utterance);
    }
  };

  const addFeature = (prompt: string) => {
    setInput(
      (prev) => (prev ? prev + "\n" : "") + `[FEATURE REQUEST]: ${prompt}`,
    );
    if (textareaRef.current) textareaRef.current.focus();
  };

  const renderMessageText = (text: string) => {
    let sanitizedText = text || "";
    // Clean any lingering raw JSON brackets or thought fragments from chat bubble display
    if (sanitizedText.includes('{"thoughts"') || sanitizedText.includes('{ "thoughts"') || sanitizedText.includes('"reasoningSteps":')) {
      const idx = sanitizedText.indexOf('{');
      if (idx !== -1) {
        const cleanPrefix = sanitizedText.slice(0, idx).trim();
        if (cleanPrefix.length > 5) {
          sanitizedText = cleanPrefix;
        } else {
          sanitizedText = "I have processed your request and updated your workspace files.";
        }
      }
    }

    return (
      <div className="markdown-body text-[14px] leading-[1.6] break-words overflow-x-hidden font-medium text-white/90">
        <ReactMarkdown
          remarkPlugins={[remarkGfm]}
          components={{
            code({ node, inline, className, children, ...props }: any) {
              const match = /language-(\w+)/.exec(className || "");
              const content = String(children).replace(/\n$/, "");

              if (!inline && match) {
                const snippetKey = `${match[1]}-${content.slice(0, 32)}`;
                return (
                  <AutoApplierCodeBlock
                    content={content}
                    lang={match[1]}
                    snippetKey={snippetKey}
                    files={files}
                    activeFileId={activeFileId}
                    onAgentAction={onAgentAction}
                    setActiveFileId={setActiveFileId}
                  />
                );
              }

              return (
                <code
                  className={`${className} bg-white/10 px-1.5 py-0.5 rounded-md text-white font-mono text-[11px] border border-white/5`}
                  {...props}
                >
                  {children}
                </code>
              );
            },
            p: ({ children }) => <p className="mb-4 last:mb-0">{children}</p>,
            h1: ({ children }) => (
              <h1 className="text-2xl font-semibold tracking-tight mb-6 mt-8 text-white">
                {children}
              </h1>
            ),
            h2: ({ children }) => (
              <h2 className="text-xl font-semibold tracking-tight mb-4 mt-6 text-white/90">
                {children}
              </h2>
            ),
            h3: ({ children }) => (
              <h3 className="text-lg font-medium mb-3 mt-5 text-white/80">
                {children}
              </h3>
            ),
            ul: ({ children }) => (
              <ul className="list-disc ml-5 mb-4 space-y-1.5 marker:text-white/40">
                {children}
              </ul>
            ),
            ol: ({ children }) => (
              <ol className="list-decimal ml-5 mb-4 space-y-1.5 marker:text-white/40">
                {children}
              </ol>
            ),
            li: ({ children }) => (
              <li className="text-white/80 pl-1">{children}</li>
            ),
            blockquote: ({ children }) => (
              <blockquote className="border-l-[3px] border-white/20 bg-white/5 px-6 py-4 my-6 rounded-r-xl text-white/70 italic text-[13px]">
                <div className="relative z-10">{children}</div>
              </blockquote>
            ),
            a: ({ children, href }) => (
              <a
                href={href}
                target="_blank"
                rel="noopener noreferrer"
                className="text-white font-semibold hover:text-white/70 transition-colors underline underline-offset-2"
              >
                {children}
              </a>
            ),
            hr: () => <hr className="my-6 border-white/10" />,
            table: ({ children }) => (
              <div className="overflow-x-auto my-6 border border-white/10 rounded-xl bg-white/[0.02]">
                <table className="w-full text-left border-collapse">
                  {children}
                </table>
              </div>
            ),
            th: ({ children }) => (
              <th className="px-4 py-3 bg-white/5 font-semibold text-[11px] border-b border-white/10 text-white/60">
                {children}
              </th>
            ),
            td: ({ children }) => (
              <td className="px-4 py-3 border-b border-white/5 text-[13px]">
                {children}
              </td>
            ),
          }}
        >
          {sanitizedText}
        </ReactMarkdown>
      </div>
    );
  };

  return (
    <div className="flex flex-col flex-1 h-full w-full min-h-0 bg-[#07080c] text-white overflow-hidden relative font-sans">
      {/* Streamlined Responsive Header */}
      <div className="px-2.5 sm:px-4 py-2 sm:py-2.5 border-b border-white/[0.08] flex items-center justify-between bg-zinc-950/95 backdrop-blur-xl shrink-0 z-20 gap-2">
        {/* Left: Brand & Model Selection */}
        <div className="flex items-center gap-1.5 sm:gap-2.5 min-w-0 flex-1">
          {onBackToHub && (
            <button
              onClick={onBackToHub}
              className="lg:hidden w-7 h-7 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-white/70 hover:text-white hover:bg-white/10 transition-all shrink-0 active:scale-95"
              aria-label="Back to Hub"
            >
              <ChevronLeft size={16} />
            </button>
          )}

          <div className="hidden xs:flex items-center gap-1.5 shrink-0">
            <div className="w-7 h-7 rounded-lg bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-400">
              <Sparkles size={14} />
            </div>
            <div className="hidden sm:flex flex-col">
              <span className="text-xs font-bold text-white tracking-wide leading-tight">
                Aether AI
              </span>
              <span className={`text-[8px] font-mono leading-none ${isOffline ? "text-amber-500" : "text-zinc-500"}`}>
                {isOffline ? "Offline" : "Ready"}
              </span>
            </div>
          </div>

          <div className="h-4 w-px bg-white/10 hidden md:block shrink-0" />

          {/* Model Selector Dropdown */}
          <div className="flex items-center gap-1 bg-white/[0.04] border border-white/10 hover:border-white/20 rounded-lg px-2 py-1 transition-all select-none min-w-0 max-w-[150px] sm:max-w-[180px]">
            <Sparkles size={11} className="text-orange-400 shrink-0" />
            <select
              value={selectedModel}
              onChange={(e) => setSelectedModel(e.target.value)}
              className="bg-transparent border-none text-[11px] sm:text-xs font-bold text-white focus:outline-none focus:ring-0 cursor-pointer w-full truncate pr-1"
            >
              {modelsList.map((model) => (
                <option key={model.id} value={model.id} className="bg-[#0b0c11] text-white text-xs">
                  {model.name}
                </option>
              ))}
            </select>
          </div>

          {/* Automated Mode Status Indicator (Desktop only) */}
          <div
            className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-orange-500/30 bg-orange-500/10 text-orange-400 text-[9px] font-bold uppercase tracking-wider shrink-0 select-none shadow-[0_0_8px_rgba(249,115,22,0.1)]"
            title="Auto Model Routing: Automatically selects the best model for code and chat"
          >
            <Cpu size={11} className={isProcessing ? "animate-pulse text-orange-400" : "text-cyan-400"} />
            <span>AUTO ROUTING</span>
          </div>

          {/* Think Toggle */}
          <button
            onClick={() => setIsThinkingMode(!isThinkingMode)}
            className={`flex items-center gap-1 px-2 py-1 rounded-lg border text-[11px] font-medium transition-all shrink-0 active:scale-95 ${
              isThinkingMode
                ? "bg-orange-500/15 text-orange-400 border-orange-500/30 shadow-[0_0_10px_rgba(249,115,22,0.15)]"
                : "bg-white/[0.03] border-white/5 text-zinc-400 hover:text-white"
            }`}
            title="Toggle Reasoning"
          >
            <Brain size={12} className={isThinkingMode ? "animate-pulse text-orange-400" : "text-zinc-400"} />
            <span className="hidden sm:inline">Think</span>
          </button>


        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-1 shrink-0">
          {/* Share Session Link */}
          <button
            onClick={() => {
              window.dispatchEvent(new CustomEvent("aether_open_share"));
            }}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-sky-400 hover:bg-sky-500/10 transition-all active:scale-95"
            title="Share Chat & Workspace Session"
          >
            <Share2 size={14} />
          </button>

          {/* Clear Chat */}
          <button
            onClick={() => {
              if (activeSession) {
                onUpdateSession({ ...activeSession, messages: [] });
              }
            }}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-rose-400 hover:bg-rose-500/10 transition-all active:scale-95"
            title="Clear Chat"
          >
            <Trash2 size={14} />
          </button>

          {/* Reset / New Session */}
          <button
            onClick={() => onCreateSession()}
            className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-white/5 transition-all active:scale-95"
            title="New Chat Session"
          >
            <Plus size={15} />
          </button>

          {/* Close Panel Button */}
          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-rose-300 hover:bg-rose-500/20 transition-all cursor-pointer font-bold"
              title="Close Chat Panel"
            >
              <X size={16} />
            </button>
          )}
        </div>
      </div>

      {/* Sub-Agent Indicator & Memory Profile (Desktop only to save vertical mobile space) */}
      <div className="hidden sm:flex px-4 py-1.5 border-b border-white/[0.04] bg-zinc-950/40 items-center justify-between shrink-0 z-10 select-none">
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-orange-500/10 border border-orange-500/30 text-orange-400 text-[9px] font-bold uppercase tracking-wider">
            <Brain size={11} className={isProcessing ? "animate-spin text-orange-400" : "text-amber-400"} style={{ animationDuration: '3s' }} />
            <span>SMART MODEL ROUTING</span>
            {isProcessing && (
              <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-ping" />
            )}
          </div>
        </div>

        <button
          onClick={() => setIsEvolvingPanelOpen(true)}
          className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer bg-amber-500/10 border border-amber-500/30 text-amber-400 hover:bg-amber-500/20"
          title="Assistant Memory & Project Guidelines"
        >
          <Brain size={11} className="text-amber-400 animate-pulse" />
          <span>Memory & Rules</span>
        </button>
      </div>

      <React.Suspense fallback={null}>
        <EvolvingMemoryPanel isOpen={isEvolvingPanelOpen} onClose={() => setIsEvolvingPanelOpen(false)} />
      </React.Suspense>

      {aiTab === 'chat' ? (
        <div className="flex-1 overflow-y-auto p-3 md:p-6 space-y-4 min-h-0 custom-scrollbar bg-transparent/10 backdrop-blur-md">

            {/* Offline Qwen Model Cache Downloader View */}
            {selectedModel.includes('offline') && downloadState.status !== 'ready' && (
              <div className="mx-auto max-w-3xl w-full bg-gradient-to-b from-[#0a0d14] to-[#04060a] border border-cyan-500/20 rounded-2xl p-5 shadow-2xl animate-in zoom-in-95 duration-300 text-left relative overflow-hidden">
                <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(6,182,212,0.1),transparent)] pointer-events-none" />

                <div className="flex items-start justify-between gap-4 mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center animate-pulse">
                      <DownloadCloud size={20} className="text-cyan-400" />
                    </div>
                    <div>
                      <h3 className="text-xs font-black uppercase tracking-widest text-white flex items-center gap-1.5">
                        Local weights missing <span className="text-[9px] bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 px-1.5 py-0.5 rounded font-bold uppercase">WebGPU / WASM</span>
                      </h3>
                      <p className="text-[10px] text-zinc-400 mt-1">
                        Download the {getOfflineModelConfig(selectedModel).name} ({getOfflineModelConfig(selectedModel).params}) model to enable private, browser-native AI coding completely offline.
                      </p>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 bg-zinc-800 text-[9px] font-mono text-cyan-400 rounded-full border border-white/5 uppercase">
                    Local Cache
                  </span>
                </div>

                {downloadState.status === 'downloading' ? (
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between items-center text-[10px] font-bold text-zinc-400 mb-1.5">
                        <span className="flex items-center gap-2">
                          <Loader2 size={10} className="animate-spin text-cyan-400" />
                          Caching: {downloadState.activeShard}
                        </span>
                        <span className="font-mono text-cyan-400">{downloadState.progress}%</span>
                      </div>
                      <div className="w-full bg-zinc-950/80 h-2.5 rounded-full overflow-hidden border border-white/5">
                        <div 
                          className="bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-500 h-full transition-all duration-300 shadow-[0_0_10px_rgba(6,182,212,0.5)]" 
                          style={{ width: `${downloadState.progress}%` }}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5 pt-2">
                      {downloadState.shards.map((s, idx) => (
                        <div 
                          key={idx} 
                          className={`p-2 rounded-xl border flex items-center justify-between gap-2 text-[9px] ${
                            s.status === 'completed'
                              ? 'bg-emerald-500/5 border-emerald-500/20 text-emerald-400'
                              : s.status === 'downloading'
                              ? 'bg-cyan-500/10 border-cyan-500/30 text-cyan-400'
                              : 'bg-white/[0.01] border-white/5 text-zinc-600'
                          }`}
                        >
                          <span className="font-medium truncate">{s.name}</span>
                          <span className="text-[8px] font-mono opacity-60 shrink-0">{s.size}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col sm:flex-row items-center gap-3">
                    <button
                      onClick={handleDownloadOfflineModel}
                      className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-cyan-500 to-teal-400 hover:from-cyan-400 hover:to-teal-300 text-black font-black uppercase tracking-widest text-[10px] rounded-xl shadow-lg shadow-cyan-500/10 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 shrink-0"
                    >
                      <DownloadCloud size={14} /> Initialize Local Cache ({getOfflineModelConfig(selectedModel).totalSize})
                    </button>
                    <span className="text-[9px] text-zinc-500 font-semibold text-center sm:text-left">
                      Weights will be stored directly inside your browser's persistent IndexedDB local cache.
                    </span>
                  </div>
                )}
              </div>
            )}

            {!activeSessionId ? (
          <div className="h-full flex flex-col items-center justify-center text-white/40 text-center p-8">
            <Sparkles size={32} className="mb-4 opacity-30 text-white" />
            <p className="text-xs font-medium mb-1">
               No Active Chat
            </p>
            <p className="text-[10px] uppercase tracking-widest opacity-40">Start a new conversation to begin</p>
            <button
              onClick={() => onCreateSession()}
              className="mt-6 genz-button-secondary px-6 py-2 rounded-xl text-[10px] font-bold transition-all"
            >
              New Chat
            </button>
          </div>
        ) : (
          <div className="max-w-2xl mx-auto w-full space-y-6 pb-4">


            {activeSession.messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-10 px-4 text-center animate-in fade-in duration-500 space-y-6">
                <div className="flex flex-col items-center">
                  <div className="w-14 h-14 rounded-2xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center shadow-lg mb-4 text-orange-400">
                    <Sparkles size={28} />
                  </div>
                  
                  <h2 className="text-xl font-bold tracking-tight text-white mb-2 font-mono">
                    Aether AI Assistant
                  </h2>
                  <p className="text-xs text-zinc-400 max-w-sm leading-relaxed">
                    Unleash multi-agent reasoning, auto-fixes, and high-fidelity code generation.
                  </p>
                </div>

                {/* AI Preset Co-Pilots Swarm Presets */}
                <div className="w-full max-w-md mt-6 space-y-3 text-left">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 block pl-1 font-mono">
                    ⚡ Neural Swarm Presets
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    {NEURAL_SKILLS.slice(0, 6).map((skill) => {
                      const IconComponent = skill.icon;
                      return (
                        <button
                          key={skill.id}
                          onClick={() => {
                            setInput(skill.prompt);
                            textareaRef.current?.focus();
                          }}
                          className="flex flex-col items-start p-3 bg-zinc-900/40 hover:bg-zinc-900 border border-white/5 hover:border-orange-500/30 rounded-xl transition-all cursor-pointer text-left group"
                        >
                          <div className="flex items-center gap-2 mb-1">
                            <span className={`${skill.color} p-1 rounded-md bg-white/5`}>
                              <IconComponent size={12} />
                            </span>
                            <span className="text-xs font-bold text-zinc-200 group-hover:text-orange-400 transition-colors">
                              {skill.name}
                            </span>
                          </div>
                          <span className="text-[9px] text-zinc-500 leading-snug line-clamp-2">
                            {skill.prompt}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            ) : (
              activeSession.messages.map((msg) => (
                <ChatMessage
                  key={msg.id}
                  msg={msg}
                  isProcessing={isProcessing}
                  isCompactMode={isCompactMode}
                  activeSessionMessages={activeSession.messages}
                  expandedReasoning={expandedReasoning}
                  setExpandedReasoning={setExpandedReasoning}
                  isSpeaking={isSpeaking}
                  handleSpeak={handleSpeak}
                  toggleMessageExclusion={toggleMessageExclusion}
                  toggleMessagePin={toggleMessagePin}
                  deleteMessage={deleteMessage}
                  forkSessionAtMessage={onForkSession ? forkSessionAtMessage : undefined}
                  files={files}
                  activeFileId={activeFileId}
                  activeSessionId={activeSessionId}
                  onUpdateFiles={handleUpdateFilesFromRestore}
                  onAgentAction={onAgentAction}
                  onEditAndResendMessage={handleEditAndResendMessage}
                  onRetryMessage={handleRetryMessage}
                  onApplyCodeToEditor={handleApplyCodeToEditor}
                  onRunTerminalCommand={handleRunTerminalCommand}
                  onFeedback={handleMessageFeedback}
                />
              ))
            )}
          </div>
        )}

        {isProcessing && (
          <div className="pt-2 pb-1 animate-in fade-in slide-in-from-bottom-2 px-3 sm:px-6">
            <div className="flex flex-col gap-2.5 bg-[#0e1017] border border-orange-500/25 rounded-xl p-3.5 shadow-xl shadow-orange-500/5 backdrop-blur-xl">
              <div className="flex items-center gap-3">
                <div className="relative flex items-center justify-center w-7 h-7 shrink-0 rounded-lg bg-orange-500/10 border border-orange-500/20">
                  <span className="text-sm">{getAgentDetails(activeAgentId).icon}</span>
                  <span className="absolute -top-0.5 -right-0.5 flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-orange-500"></span>
                  </span>
                </div>
                <div className="flex flex-col min-w-0 flex-1">
                  <div className="flex items-center gap-2 justify-between">
                    <span className="text-xs font-black text-white uppercase tracking-wider">
                      {getAgentDetails(activeAgentId).name}
                    </span>
                    <span className="px-1.5 py-0.5 text-[8.5px] font-mono font-bold bg-orange-500/15 text-orange-400 border border-orange-500/25 rounded uppercase tracking-wider">
                      {activeStep}
                    </span>
                  </div>
                  <span className="text-[10px] text-orange-300/85 font-medium mt-0.5">
                    {getAgentDetails(activeAgentId).role}
                  </span>
                </div>
              </div>
              
              <div className="border-t border-white/[0.04] pt-2 flex items-center gap-2 text-[10px] text-zinc-400 font-mono">
                <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse shrink-0" />
                <span className="truncate flex-1">
                  {activeLogs[activeLogs.length - 1]?.message || "Writing code and suggestions..."}
                </span>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} className="h-4" />
      </div>
      ) : (
        /* Neural Orchestrator Board UI Component */
        <React.Suspense fallback={<div className="p-8 text-center text-xs font-mono text-zinc-500 animate-pulse">Initializing Neural Board...</div>}>
          <NeuralOrchestratorBoard
            isProcessing={isProcessing}
            activeStep={activeStep}
            activeAgentId={activeAgentId}
            activeLogs={activeLogs}
            onClearLogs={() => setActiveLogs([])}
            spawnedAgents={spawnedAgents}
            classification={classification}
            selectedModel={selectedModel}
            lastUserMessages={lastUserMessages}
            divisionScopeMode={divisionScopeMode}
            onSetDivisionScopeMode={setDivisionScopeMode}
            manualSelectedAgents={manualSelectedAgents}
            onToggleManualAgent={handleToggleAgent}
            currentBotMessage={currentBotMessage}
            files={files}
          />
        </React.Suspense>
      )}

      {/* Streamlined Footer Input Area */}
      <div className="p-2 pb-[calc(0.5rem+env(safe-area-inset-bottom))] bg-black/90 backdrop-blur-sm shrink-0 relative border-t border-white/5">
        
        {/* Context-Aware Dynamic AI Prompt Shortcuts */}
        {!isProcessing && dynamicShortcuts.length > 0 && (
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 pt-0.5 px-1 scrollbar-none scroll-smooth">
            {dynamicShortcuts.map((shortcut, i) => (
              <button
                key={i}
                onClick={() => {
                  setInput(shortcut.prompt);
                  textareaRef.current?.focus();
                }}
                className={`shrink-0 flex items-center gap-1 px-2.5 py-1 rounded-full border bg-gradient-to-r ${shortcut.color} text-[9px] font-bold tracking-wide cursor-pointer transition-all duration-200 hover:scale-[1.02] hover:brightness-110 active:scale-95`}
                title="Populate input with this prompt preset"
              >
                <span>{shortcut.label}</span>
              </button>
            ))}
          </div>
        )}

        {/* Input Bar */}
        <div
          className={`relative bg-[#0b0c10] border transition-all duration-200 rounded-xl shadow-lg backdrop-blur-xl ${isProcessing ? "border-zinc-800/50 opacity-60" : "border-zinc-800 focus-within:border-orange-500/40 focus-within:bg-[#0e1017]"}`}
        >
          {/* Autocomplete Slash Commands popover */}
          {showSlashDropdown && (
            <div className="absolute bottom-full left-0 mb-2 w-full max-h-72 overflow-y-auto bg-[#0a0b10] border border-orange-500/30 rounded-xl shadow-2xl z-[150] custom-scrollbar text-left">
              <div className="p-2 border-b border-zinc-800 bg-zinc-900/60 flex items-center justify-between">
                <span className="text-[10px] font-bold text-orange-400 uppercase tracking-widest flex items-center gap-1.5">
                  <Sparkles size={11} className="text-orange-500 animate-pulse" /> AI Tools & Slash Commands
                </span>
                <span className="text-[9px] text-zinc-500 font-mono">
                  {filteredSlashCommands.length} available
                </span>
              </div>
              <div className="p-1 space-y-0.5">
                {filteredSlashCommands.length > 0 ? (
                  filteredSlashCommands.map((item, idx) => {
                    const isSelected = idx === slashSelectedIndex;
                    return (
                      <button
                        key={idx}
                        onClick={() => handleSelectSlashCommand(item)}
                        className={`w-full flex items-center justify-between px-3 py-2 text-xs text-left rounded-lg transition-all cursor-pointer group ${
                          isSelected 
                            ? "text-white bg-orange-500/20 border border-orange-500/40 shadow-sm" 
                            : "text-zinc-300 hover:text-white hover:bg-zinc-900/90 border border-transparent"
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <div className={`p-1.5 rounded-md border shrink-0 transition-colors ${
                            isSelected 
                              ? "bg-orange-500/20 border-orange-500/50 text-orange-300" 
                              : "bg-zinc-900 border-zinc-800 group-hover:border-orange-500/40 group-hover:bg-orange-500/10"
                          }`}>
                            {item.icon}
                          </div>
                          <div className="truncate">
                            <div className="flex items-center gap-1.5">
                              <span className="font-mono font-bold text-orange-400 group-hover:text-orange-300 text-xs">{item.cmd}</span>
                              <span className="text-zinc-200 font-medium text-[11px] truncate">{item.title}</span>
                            </div>
                            <div className="text-[10px] text-zinc-500 truncate">{item.desc}</div>
                          </div>
                        </div>
                        <span className="text-[9px] font-mono px-2 py-0.5 rounded bg-zinc-850 text-zinc-400 uppercase border border-zinc-800 shrink-0 ml-2">
                          {item.category}
                        </span>
                      </button>
                    );
                  })
                ) : (
                  <div className="p-4 text-center text-xs text-zinc-500 font-mono">
                    No matching slash commands found
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Autocomplete @ Mention (Divisions, Agents, Files) popover */}
          {showAtMentionDropdown && (
            <AtMentionPopover
              searchQuery={atMentionSearchQuery}
              files={files}
              onSelectDivision={handleSelectDivisionMention}
              onSelectAgent={handleSelectAgentMention}
              onSelectFile={handleSelectFileRef}
              onClose={() => setShowAtMentionDropdown(false)}
            />
          )}

          {/* File Reference Chips */}
          {referencedFiles.length > 0 && (
            <div className="flex flex-wrap gap-1.5 p-3 border-b border-zinc-800/60 bg-white/[0.01]">
              {referencedFiles.map((file) => (
                <div
                  key={file.id}
                  className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-800 rounded-lg px-2.5 py-1 text-[11px] font-mono text-zinc-300 hover:text-white"
                >
                  <FileText size={11} className="text-orange-500" />
                  <span>{file.name}</span>
                  <button
                    onClick={() => setReferencedFiles(prev => prev.filter(f => f.id !== file.id))}
                    className="text-zinc-500 hover:text-white transition-colors cursor-pointer"
                  >
                    <X size={10} />
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Attachment Preview */}
          {attachments.length > 0 && (
            <div className="flex gap-2 p-3 border-b border-white/10 overflow-x-auto bg-white/[0.01]">
              {attachments.map((att, i) => (
                <div key={i} className="relative group shrink-0">
                  {att.type === "image" && att.data ? (
                    <img
                      src={`data:${att.mimeType};base64,${att.data}`}
                      alt="Preview"
                      className="h-14 w-14 rounded-xl object-cover border border-white/20 shadow-md"
                    />
                  ) : (
                    <div className="h-14 w-14 rounded-xl bg-white/10 flex items-center justify-center border border-white/20 shadow-md">
                      {att.type === "image" ? (
                        <ImageIcon size={20} className="text-white/60" />
                      ) : (
                        <FileText size={20} className="text-white/60" />
                      )}
                    </div>
                  )}
                  <button
                    onClick={() =>
                      setAttachments((prev) =>
                        prev.filter((_, idx) => idx !== i),
                      )
                    }
                    className="absolute -top-1.5 -right-1.5 bg-red-500 text-white border border-white/30 rounded-full p-1 shadow-lg transition-transform hover:scale-110"
                  >
                    <X size={10} />
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="absolute -top-7 left-5">
            <AnimatePresence>
              {isTyping && (
                <motion.div
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 5 }}
                  className="flex items-center gap-2 px-3 py-1 bg-black/90 border border-orange-500/30 rounded-full shadow-lg backdrop-blur-md"
                >
                  <div className="flex gap-1">
                    <div className="w-1.5 h-1.5 bg-orange-500 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                    <div className="w-1.5 h-1.5 bg-orange-500 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                    <div className="w-1.5 h-1.5 bg-orange-500 rounded-full animate-bounce"></div>
                  </div>
                  <span className="text-[9px] font-bold text-orange-300 uppercase tracking-widest">
                    {isTyping} synthesizing response...
                  </span>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => handleInputChange(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={isProcessing}
            placeholder={isListening ? "Listening..." : "Ask AI or describe changes..."}
            className="w-full bg-transparent text-xs text-white px-3 py-2 outline-none resize-none min-h-[36px] max-h-[110px] overflow-y-auto custom-scrollbar placeholder:text-zinc-500 font-sans leading-normal"
            rows={1}
          />

          {/* Hidden Inputs */}
          <input
            type="file"
            ref={fileInputRef}
            className="hidden"
            onChange={(e) => handleFileUpload(e, "file")}
          />
          <input
            type="file"
            ref={folderInputRef}
            className="hidden"
            {...({ webkitdirectory: "", directory: "" } as any)}
            onChange={(e) => handleFileUpload(e, "file")}
          />
          <input
            type="file"
            ref={imageInputRef}
            className="hidden"
            accept="image/*,video/mp4,video/webm,video/mov,video/quicktime"
            onChange={(e) => handleFileUpload(e, "image")}
          />

          <div className="flex items-center justify-between px-2.5 pb-2 pt-0 gap-1">
            <div className="flex items-center gap-0.5 sm:gap-1 flex-1">
              <button
                onClick={() => {
                  setShowSlashDropdown(prev => !prev);
                  if (!input.startsWith("/")) {
                    setInput("/");
                    setSlashSearchQuery("");
                  }
                  textareaRef.current?.focus();
                }}
                className={`p-1 px-1.5 rounded-md text-[11px] font-mono font-bold transition-all cursor-pointer ${
                  showSlashDropdown ? "text-orange-400 bg-orange-500/20 border border-orange-500/40" : "text-zinc-400 hover:text-white hover:bg-white/10"
                }`}
                title="Browse Slash Commands (/)"
              >
                /
              </button>

              <button
                onClick={handleEnhance}
                disabled={isEnhancing || !input.trim()}
                className={`p-1 rounded-md transition-all cursor-pointer ${isEnhancing ? "text-orange-400 animate-pulse" : "text-zinc-400 hover:text-white hover:bg-white/10"}`}
                title="Enhance Prompt"
              >
                {isEnhancing ? (
                  <Loader2 size={13} className="animate-spin" />
                ) : (
                  <Wand2 size={13} />
                )}
              </button>
              <button
                onClick={toggleVoiceInput}
                className={`p-1 rounded-md transition-all cursor-pointer ${isListening ? "text-red-500 animate-pulse bg-red-500/10" : "text-zinc-400 hover:text-white hover:bg-white/10"}`}
                title="Voice Dictation (Speech-to-Text)"
              >
                {isListening ? <MicOff size={13} /> : <Mic size={13} />}
              </button>



              <button
                onClick={() => fileInputRef.current?.click()}
                className="p-1 text-zinc-400 hover:text-white hover:bg-white/10 rounded-md transition-all cursor-pointer"
                title="Attach Context File"
              >
                <Paperclip size={13} />
              </button>

              <button
                onClick={() => imageInputRef.current?.click()}
                className="p-1 text-zinc-400 hover:text-white hover:bg-white/10 rounded-md transition-all cursor-pointer"
                title="Attach Image"
              >
                <ImageIcon size={13} />
              </button>
            </div>

            <div className="shrink-0">
              {isProcessing ? (
                <button
                  onClick={onStopProcessing}
                  className="p-1.5 rounded-lg bg-red-500 hover:bg-red-600 text-white shadow-md transition-all cursor-pointer"
                  title="Interrupt Generation"
                >
                  <X size={13} strokeWidth={2.5} />
                </button>
              ) : (
                <button
                  onClick={handleSend}
                  disabled={!input.trim() && attachments.length === 0}
                  className={`
                    p-1.5 rounded-lg transition-all
                    ${
                      input.trim() || attachments.length > 0
                        ? "bg-white text-black shadow hover:bg-zinc-200 cursor-pointer"
                        : "bg-white/10 text-white/20 cursor-not-allowed"
                    }
                  `}
                >
                  <ArrowUp size={13} strokeWidth={2.5} />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Custom Model Modal Runner */}
      <AnimatePresence>
        {showCustomModelModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-[#121319] border border-white/10 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-5 text-white"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl">
                    <Sparkles size={18} />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm">Run Any AI Model</h3>
                    <p className="text-xs text-white/50">Specify any cloud or local model name to run queries</p>
                  </div>
                </div>
                <button onClick={() => setShowCustomModelModal(false)} className="text-white/40 hover:text-white">
                  <X size={18} />
                </button>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="text-xs font-medium text-white/70 block mb-1">Model Name / ID</label>
                  <input
                    type="text"
                    value={customModelInput}
                    onChange={(e) => setCustomModelInput(e.target.value)}
                    onKeyDown={(e) => { if (e.key === 'Enter') handleRunCustomModel(); }}
                    placeholder="e.g. gpt-4o, claude-3-7-sonnet, deepseek-r1:14b, qwen2.5-coder, gemini-2.5-pro"
                    className="w-full bg-black/60 border border-white/10 rounded-xl px-3.5 py-2.5 text-xs text-white font-mono focus:outline-none focus:border-emerald-500 transition-colors"
                    autoFocus
                  />
                </div>

                <div>
                  <label className="text-xs font-medium text-white/70 block mb-1">Provider Engine Type</label>
                  <select
                    value={customModelProvider}
                    onChange={(e: any) => setCustomModelProvider(e.target.value)}
                    className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="ollama">Ollama Server (Local / Remote)</option>
                    <option value="nvidia">Google Gemini & Cloud APIs</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  onClick={() => setShowCustomModelModal(false)}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-white/60 hover:text-white bg-white/5 hover:bg-white/10"
                >
                  Cancel
                </button>
                <button
                  onClick={handleRunCustomModel}
                  disabled={!customModelInput.trim()}
                  className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-black transition-all disabled:opacity-40"
                >
                  Activate & Run Model
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Voice Conversation is now completely integrated into the unified chat layout */}
    </div>
  );
};

export default AIAssistant;
