import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, FileText, ChevronRight, X } from 'lucide-react';
import { FileNode } from '../../types';

interface SearchViewProps {
  files: FileNode[];
  onSelectFile: (fileId: string) => void;
}

const SearchView: React.FC<SearchViewProps> = ({ files, onSelectFile }) => {
  const [query, setQuery] = useState('');

  const results = query.length > 2 ? files.filter(f => 
    f.name.toLowerCase().includes(query.toLowerCase()) || 
    f.content.toLowerCase().includes(query.toLowerCase())
  ) : [];

  return (
    <div className="flex flex-col h-full bg-[#080808]">
      <div className="p-4 border-b border-white/5 space-y-4">
        <div className="relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/20" />
          <input 
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search all files..."
            className="w-full bg-white/5 border border-white/10 rounded-xl py-2 pl-9 pr-4 text-xs text-white outline-none focus:border-aether-accent/50 transition-all font-medium"
          />
        </div>
        <div className="flex items-center justify-between px-1">
            <span className="text-[10px] font-bold text-white/20 uppercase tracking-widest">{results.length} Matches</span>
            <div className="text-[9px] text-aether-accent font-bold uppercase tracking-widest italic animate-pulse">Semantic Search Active</div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-2">
        <AnimatePresence mode="popLayout">
          {results.length > 0 ? (
            results.map((f, i) => (
              <motion.div 
                key={f.id}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                onClick={() => onSelectFile(f.id)}
                className="group flex flex-col gap-2 p-3 rounded-xl hover:bg-white/5 cursor-pointer transition-all border border-transparent hover:border-white/5 mb-2"
              >
                <div className="flex items-center gap-2">
                    <div className="p-1.5 bg-white/5 rounded-lg text-white/40 group-hover:text-aether-accent transition-colors">
                        <FileText size={12} />
                    </div>
                    <span className="text-xs font-bold text-white/60 group-hover:text-white transition-colors">
                        {f.name.split(new RegExp(`(${query})`, 'gi')).map((part, i) => 
                            part.toLowerCase() === query.toLowerCase() 
                                ? <span key={i} className="text-aether-accent bg-aether-accent/20 px-0.5 rounded">{part}</span> 
                                : part
                        )}
                    </span>
                </div>
                {query.length > 0 && (
                    <div className="text-[10px] font-mono text-white/20 line-clamp-2 overflow-hidden bg-white/[0.02] p-2 rounded-lg">
                        {(() => {
                           const line = f.content.split('\n').find(l => l.toLowerCase().includes(query.toLowerCase())) || f.content.slice(0, 50);
                           return line.split(new RegExp(`(${query})`, 'gi')).map((part, i) => 
                               part.toLowerCase() === query.toLowerCase() 
                                   ? <span key={i} className="text-aether-accent bg-aether-accent/20 px-0.5 rounded">{part}</span> 
                                   : part
                           );
                        })()}
                    </div>
                )}
              </motion.div>
            ))
          ) : query.length > 2 ? (
            <div className="p-12 text-center space-y-3">
                <Search size={24} className="mx-auto text-white/10" />
                <p className="text-[10px] uppercase font-bold text-white/20 tracking-widest italic leading-relaxed">No direct matches found. Application is scanning alternate logic branches...</p>
            </div>
          ) : (
            <div className="p-12 text-center text-[10px] uppercase font-bold text-white/10 tracking-[0.2em]">Start typing to scan clusters...</div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default SearchView;
