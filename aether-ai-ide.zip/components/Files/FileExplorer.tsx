import React, { useState, useMemo, useRef } from 'react';
import { FileNode } from '../../types';
import {
  Folder, FolderOpen, FileCode, Plus, Trash2, FileJson, FileType,
  Download, Search, Image as ImageIcon, Zap, ChevronRight, ChevronDown,
  Package, Flame, FolderPlus, Layers, Sparkles, Wand2, Terminal, Code, Cpu,
  Upload, FileArchive
} from 'lucide-react';
import { processDroppedFiles, processUploadedFiles } from '../../services/fileService';
import { AIImageModal } from './AIImageModal';
import { NEXT_GEN_TEMPLATES } from '../../services/projectTemplates';

interface FileExplorerProps {
  files: FileNode[];
  activeFileId: string | null;
  onSelectFile: (file: FileNode) => void;
  onCreateFile: (name: string, lang: string) => void;
  onDeleteFile: (id: string) => void;
  onRenameFile: (id: string, newName: string) => void;
  onExport: () => void;
  onApplyTemplate: (type: string) => void;
  projectId: string | null;
  onFilesUpdated?: (files: FileNode[]) => void;
  onSnapshot?: () => void;
}

interface TreeNode {
  id: string;
  name: string;
  fullPath: string;
  isFolder: boolean;
  children?: TreeNode[];
  file?: FileNode;
}

export const FileExplorer: React.FC<FileExplorerProps> = ({
  files,
  activeFileId,
  onSelectFile,
  onCreateFile,
  onDeleteFile,
  onRenameFile,
  onExport,
  onApplyTemplate,
  projectId,
  onFilesUpdated,
  onSnapshot
}) => {
  const [isCreatingFile, setIsCreatingFile] = useState(false);
  const [isCreatingFolder, setIsCreatingFolder] = useState(false);
  const [targetFolderPath, setTargetFolderPath] = useState<string>('');
  const [newItemName, setNewItemName] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [collapsedFolders, setCollapsedFolders] = useState<Set<string>>(new Set());
  const [showPackages, setShowPackages] = useState(true);
  const [isDragging, setIsDragging] = useState(false);
  const [showImageModal, setShowImageModal] = useState(false);
  const [showUploadMenu, setShowUploadMenu] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);

  const handleManualUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0 || !projectId) return;
    const updated = await processUploadedFiles(projectId, e.target.files);
    if (onFilesUpdated) onFilesUpdated(updated);
    e.target.value = '';
    setShowUploadMenu(false);
  };

  // Toggle Folder Collapse State
  const toggleFolder = (folderPath: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setCollapsedFolders(prev => {
      const next = new Set(prev);
      if (next.has(folderPath)) {
        next.delete(folderPath);
      } else {
        next.add(folderPath);
      }
      return next;
    });
  };

  // Build Real Physical Folder Hierarchy Tree
  const fileTree = useMemo(() => {
    const root: TreeNode = {
      id: 'root',
      name: 'root',
      fullPath: '',
      isFolder: true,
      children: []
    };

    const filtered = files.filter(f => f.name.toLowerCase().includes(searchQuery.toLowerCase()));

    filtered.forEach(file => {
      const cleanPath = file.name.replace(/^\//, '');
      const parts = cleanPath.split('/');
      let current = root;

      parts.forEach((part, index) => {
        const isLast = index === parts.length - 1;
        const currentPath = parts.slice(0, index + 1).join('/');

        if (isLast) {
          // File node
          current.children?.push({
            id: file.id,
            name: part,
            fullPath: currentPath,
            isFolder: false,
            file
          });
        } else {
          // Folder node
          let existingFolder = current.children?.find(c => c.isFolder && c.name === part);
          if (!existingFolder) {
            existingFolder = {
              id: 'folder_' + currentPath,
              name: part,
              fullPath: currentPath,
              isFolder: true,
              children: []
            };
            current.children?.push(existingFolder);
          }
          current = existingFolder;
        }
      });
    });

    // Sort folders first, then files alphabetically
    const sortNodes = (node: TreeNode) => {
      if (node.children) {
        node.children.sort((a, b) => {
          if (a.isFolder && !b.isFolder) return -1;
          if (!a.isFolder && b.isFolder) return 1;
          return a.name.localeCompare(b.name);
        });
        node.children.forEach(sortNodes);
      }
    };

    sortNodes(root);
    return root.children || [];
  }, [files, searchQuery]);

  const isImageNode = (file: FileNode) => {
    if (file.isBinary || file.language === 'image') return true;
    const name = file.name.toLowerCase();
    return name.endsWith('.png') || name.endsWith('.jpg') || name.endsWith('.jpeg') || name.endsWith('.gif') || name.endsWith('.webp') || name.endsWith('.svg');
  };

  const getFileIcon = (file: FileNode) => {
    if (isImageNode(file)) return <ImageIcon size={14} className="text-pink-400 shrink-0" />;
    if (file.name.endsWith('.rs')) return <Flame size={14} className="text-orange-500 shrink-0" />;
    if (file.name.endsWith('.toml')) return <FileType size={14} className="text-amber-400 shrink-0" />;
    if (file.name.endsWith('.html')) return <FileCode size={14} className="text-orange-400 shrink-0" />;
    if (file.name.endsWith('.css')) return <FileType size={14} className="text-blue-400 shrink-0" />;
    if (file.name.endsWith('.js') || file.name.endsWith('.ts') || file.name.endsWith('.tsx') || file.name.endsWith('.jsx')) {
      return <FileCode size={14} className="text-yellow-400 shrink-0" />;
    }
    if (file.name.endsWith('.json')) return <FileJson size={14} className="text-emerald-400 shrink-0" />;
    if (file.name.endsWith('.py')) return <FileCode size={14} className="text-yellow-300 shrink-0" />;
    return <FileCode size={14} className="text-zinc-400 shrink-0" />;
  };

  const handleCreateFileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName) return;
    const finalPath = targetFolderPath ? `${targetFolderPath}/${newItemName}` : newItemName;
    const ext = newItemName.split('.').pop() || '';
    const langMap: Record<string, string> = {
      js: 'javascript', ts: 'typescript', tsx: 'typescript', jsx: 'javascript',
      html: 'html', css: 'css', json: 'json', rs: 'rust', toml: 'toml', py: 'python', md: 'markdown'
    };
    onCreateFile(finalPath, langMap[ext] || 'plaintext');
    setNewItemName('');
    setIsCreatingFile(false);
    setTargetFolderPath('');
  };

  const handleCreateFolderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName) return;
    const folderPath = targetFolderPath ? `${targetFolderPath}/${newItemName}` : newItemName;
    onCreateFile(`${folderPath}/.keep`, 'plaintext');
    setNewItemName('');
    setIsCreatingFolder(false);
    setTargetFolderPath('');
  };

  const handleDeleteFolder = (folderPath: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm(`Delete folder '${folderPath}' and all files inside?`)) {
      const filesToDelete = files.filter(f => f.name === folderPath || f.name.startsWith(folderPath + '/'));
      filesToDelete.forEach(f => onDeleteFile(f.id));
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (!projectId) return;
    const updatedFiles = await processDroppedFiles(projectId, e.dataTransfer.items);
    if (onFilesUpdated) onFilesUpdated(updatedFiles);
  };

  // Recursive Tree Node Renderer
  const renderTreeNode = (node: TreeNode, depth: number = 0) => {
    const isCollapsed = collapsedFolders.has(node.fullPath);
    const indentStyle = { paddingLeft: `${depth * 14 + 8}px` };

    if (node.isFolder) {
      return (
        <div key={node.id} className="select-none">
          <div
            onClick={(e) => toggleFolder(node.fullPath, e)}
            style={indentStyle}
            className="group flex items-center justify-between py-1.5 pr-2 rounded-lg cursor-pointer text-zinc-300 hover:bg-white/5 hover:text-white transition-colors"
          >
            <div className="flex items-center gap-1.5 overflow-hidden flex-1 min-w-0">
              {isCollapsed ? (
                <ChevronRight size={13} className="text-zinc-500 shrink-0" />
              ) : (
                <ChevronDown size={13} className="text-zinc-500 shrink-0" />
              )}
              {isCollapsed ? (
                <Folder size={14} className="text-amber-400 shrink-0" />
              ) : (
                <FolderOpen size={14} className="text-amber-300 shrink-0" />
              )}
              <span className="text-xs font-semibold tracking-wide truncate">{node.name}</span>
            </div>

            <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setTargetFolderPath(node.fullPath);
                  setIsCreatingFile(true);
                  setIsCreatingFolder(false);
                }}
                className="hover:text-amber-300 p-0.5 text-zinc-400"
                title="New File in Folder"
              >
                <Plus size={12} />
              </button>
              <button
                onClick={(e) => handleDeleteFolder(node.fullPath, e)}
                className="hover:text-red-400 p-0.5 text-zinc-400"
                title="Delete Folder"
              >
                <Trash2 size={12} />
              </button>
            </div>
          </div>

          {!isCollapsed && node.children && (
            <div className="space-y-0.5">
              {node.children.map(child => renderTreeNode(child, depth + 1))}
            </div>
          )}
        </div>
      );
    }

    // File Node
    const file = node.file!;
    const isSelected = activeFileId === file.id;
    const isImg = isImageNode(file);

    return (
      <div
        key={node.id}
        style={indentStyle}
        onClick={() => onSelectFile(file)}
        className={`group flex items-center justify-between py-1.5 pr-2 rounded-lg cursor-pointer text-xs transition-colors ${
          isSelected
            ? 'bg-amber-500/15 text-amber-300 font-bold border border-amber-500/20'
            : 'text-zinc-400 hover:bg-white/5 hover:text-zinc-200 border border-transparent'
        }`}
      >
        <div className="flex items-center gap-2 overflow-hidden flex-1 min-w-0">
          {getFileIcon(file)}
          {editingId === file.id ? (
            <input
              autoFocus
              type="text"
              value={editingName}
              onChange={(e) => setEditingName(e.target.value)}
              onBlur={() => {
                if (editingName.trim() && editingName !== node.name) {
                  const pathParts = file.name.split('/');
                  pathParts[pathParts.length - 1] = editingName.trim();
                  onRenameFile(file.id, pathParts.join('/'));
                }
                setEditingId(null);
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  if (editingName.trim() && editingName !== node.name) {
                    const pathParts = file.name.split('/');
                    pathParts[pathParts.length - 1] = editingName.trim();
                    onRenameFile(file.id, pathParts.join('/'));
                  }
                  setEditingId(null);
                } else if (e.key === 'Escape') {
                  setEditingId(null);
                }
              }}
              onClick={(e) => e.stopPropagation()}
              className="bg-black text-white px-1 py-0.5 rounded text-xs outline-none border border-amber-500/50 w-full"
            />
          ) : (
            <span
              onDoubleClick={(e) => {
                e.stopPropagation();
                setEditingId(file.id);
                setEditingName(node.name);
              }}
              className="truncate tracking-wide"
              title={file.name}
            >
              {node.name}
            </span>
          )}
          {isImg && (
            <span className="text-[9px] font-mono px-1 py-0.2 rounded bg-pink-500/10 text-pink-400 shrink-0 uppercase">
              IMG
            </span>
          )}
        </div>

        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onDeleteFile(file.id);
            }}
            title="Delete File"
            className="text-zinc-500 hover:text-red-400 p-0.5 transition-colors"
          >
            <Trash2 size={11} />
          </button>
        </div>
      </div>
    );
  };

  return (
    <div
      className={`flex flex-col h-full bg-zinc-950/90 border-r border-zinc-800/80 relative transition-all ${isDragging ? 'ring-2 ring-amber-500 ring-inset' : ''}`}
      onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={handleDrop}
    >
      {/* Workspace Header */}
      <div className="p-3 border-b border-zinc-800/80 shrink-0">
        <div className="flex justify-between items-center mb-2.5">
          <div className="flex items-center gap-1.5">
            <Layers size={13} className="text-amber-400" />
            <h2 className="font-bold text-[11px] tracking-widest text-zinc-400 uppercase">Physical Workspace</h2>
          </div>
          <div className="flex items-center gap-1">
            {/* AI Image Studio Button */}
            <button
              onClick={() => setShowImageModal(true)}
              title="Generate AI Visual Asset"
              className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-gradient-to-r from-pink-500/20 to-orange-500/20 hover:from-pink-500/30 hover:to-orange-500/30 border border-pink-500/30 text-pink-400 hover:text-pink-300 text-[10px] font-bold transition-all shadow-sm cursor-pointer"
            >
              <Wand2 size={11} />
              <span className="hidden sm:inline">AI Image</span>
            </button>

            {/* Unified Upload Button */}
            <div className="relative">
              <button
                onClick={() => setShowUploadMenu(!showUploadMenu)}
                title="Upload Files, Folders or ZIP Archive"
                className="p-1 text-zinc-400 hover:text-amber-400 transition-colors cursor-pointer flex items-center"
              >
                <Upload size={13} />
              </button>

              {showUploadMenu && (
                <div className="absolute right-0 top-full mt-1 w-44 bg-zinc-900 border border-zinc-700 rounded-xl shadow-2xl z-50 p-1 text-[11px] text-zinc-200">
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-zinc-800 hover:text-amber-300 flex items-center gap-2 cursor-pointer"
                  >
                    <FileCode size={12} className="text-amber-400" />
                    <span>Upload Files...</span>
                  </button>
                  <button
                    onClick={() => folderInputRef.current?.click()}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-zinc-800 hover:text-amber-300 flex items-center gap-2 cursor-pointer"
                  >
                    <FolderOpen size={12} className="text-amber-400" />
                    <span>Upload Folder...</span>
                  </button>
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-zinc-800 hover:text-amber-300 flex items-center gap-2 cursor-pointer"
                  >
                    <FileArchive size={12} className="text-amber-400" />
                    <span>Import ZIP Archive</span>
                  </button>
                </div>
              )}
            </div>

            {onSnapshot && (
              <button onClick={onSnapshot} title="Take Snapshot" className="p-1 text-zinc-400 hover:text-amber-400 transition-colors">
                <Zap size={13} />
              </button>
            )}
            <button onClick={onExport} title="Download ZIP" className="p-1 text-zinc-400 hover:text-amber-400 transition-colors">
              <Download size={13} />
            </button>
            <button
              onClick={() => { setTargetFolderPath(''); setIsCreatingFolder(true); setIsCreatingFile(false); }}
              title="New Folder"
              className="p-1 text-zinc-400 hover:text-amber-400 transition-colors"
            >
              <FolderPlus size={13} />
            </button>
            <button
              onClick={() => { setTargetFolderPath(''); setIsCreatingFile(true); setIsCreatingFolder(false); }}
              title="New File"
              className="p-1 text-zinc-400 hover:text-amber-400 transition-colors"
            >
              <Plus size={13} />
            </button>
          </div>
        </div>

        {/* Hidden File and Folder Upload Inputs */}
        <input
          type="file"
          ref={fileInputRef}
          multiple
          className="hidden"
          onChange={handleManualUpload}
        />
        <input
          type="file"
          ref={folderInputRef}
          multiple
          {...({ webkitdirectory: "", directory: "" } as any)}
          className="hidden"
          onChange={handleManualUpload}
        />

        {/* Search */}
        <div className="relative">
          <Search size={12} className="absolute left-2.5 top-2.5 text-zinc-500" />
          <input
            type="text"
            placeholder="Search physical tree..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-zinc-900 border border-zinc-800 rounded-lg pl-8 pr-2 py-1.5 text-xs text-zinc-200 placeholder-zinc-500 focus:border-amber-500/50 outline-none transition-colors"
          />
        </div>
      </div>

      {/* Creation Forms */}
      {isCreatingFolder && (
        <form onSubmit={handleCreateFolderSubmit} className="p-2 border-b border-zinc-800 bg-amber-500/5">
          <div className="text-[10px] text-amber-400 font-bold mb-1 uppercase tracking-wider">
            {targetFolderPath ? `New folder in /${targetFolderPath}` : 'New Root Folder'}
          </div>
          <div className="flex gap-1">
            <input
              autoFocus
              type="text"
              value={newItemName}
              onChange={(e) => setNewItemName(e.target.value)}
              placeholder="pages, components or assets"
              className="flex-1 bg-black border border-amber-500/50 rounded px-2 py-1 text-xs text-white outline-none"
            />
            <button type="submit" className="bg-amber-500 text-black px-2 py-1 rounded text-xs font-bold">Create</button>
            <button type="button" onClick={() => setIsCreatingFolder(false)} className="px-2 py-1 text-xs text-zinc-400">Cancel</button>
          </div>
        </form>
      )}

      {isCreatingFile && (
        <form onSubmit={handleCreateFileSubmit} className="p-2 border-b border-zinc-800 bg-amber-500/5">
          <div className="text-[10px] text-amber-400 font-bold mb-1 uppercase tracking-wider">
            {targetFolderPath ? `New file in /${targetFolderPath}` : 'New Root File'}
          </div>
          <div className="flex gap-1">
            <input
              autoFocus
              type="text"
              value={newItemName}
              onChange={(e) => setNewItemName(e.target.value)}
              placeholder="index.html, App.tsx or main.py"
              className="flex-1 bg-black border border-amber-500/50 rounded px-2 py-1 text-xs text-white outline-none"
            />
            <button type="submit" className="bg-amber-500 text-black px-2 py-1 rounded text-xs font-bold">Create</button>
            <button type="button" onClick={() => setIsCreatingFile(false)} className="px-2 py-1 text-xs text-zinc-400">Cancel</button>
          </div>
        </form>
      )}

      {/* Physical Folder Tree Body */}
      <div className="flex-1 overflow-y-auto p-2 space-y-0.5 custom-scrollbar">
        {fileTree.length === 0 ? (
          <div className="text-center py-8 text-zinc-600 text-xs">
            No files in workspace
          </div>
        ) : (
          fileTree.map(node => renderTreeNode(node, 0))
        )}
      </div>

      {/* Next-Gen Web & App Architect Presets */}
      <div className="p-3 border-t border-zinc-800/80 bg-zinc-950/80 shrink-0">
        <button
          onClick={() => setShowPackages(!showPackages)}
          className="w-full flex items-center justify-between text-[10px] font-bold text-zinc-400 uppercase tracking-widest hover:text-amber-300 transition-colors"
        >
          <div className="flex items-center gap-1.5">
            <Package size={12} className="text-amber-400" />
            <span>Project Architect</span>
          </div>
          <ChevronDown size={12} className={`transition-transform ${showPackages ? '' : '-rotate-90'}`} />
        </button>

        {showPackages && (
          <div className="mt-2.5 space-y-1.5 max-h-48 overflow-y-auto custom-scrollbar pr-1">
            {NEXT_GEN_TEMPLATES.map(tmpl => (
              <button
                key={tmpl.id}
                onClick={() => onApplyTemplate(tmpl.id)}
                className="w-full text-left px-2.5 py-1.5 rounded-lg bg-zinc-900/80 border border-zinc-800 hover:border-amber-500/40 text-[11px] text-zinc-300 hover:text-amber-300 transition-all flex items-center justify-between group cursor-pointer"
                title={tmpl.description}
              >
                <div className="flex items-center gap-2 min-w-0">
                  <span>{tmpl.icon}</span>
                  <span className="truncate">{tmpl.name}</span>
                </div>
                <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400 group-hover:text-amber-300 group-hover:bg-amber-500/10 shrink-0">
                  {tmpl.badge}
                </span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* AI Image Generation Modal */}
      <AIImageModal
        isOpen={showImageModal}
        onClose={() => setShowImageModal(false)}
        currentFiles={files}
        onImageCreated={(fileNode) => {
          if (onFilesUpdated) {
            onFilesUpdated([...files, fileNode]);
          } else {
            onCreateFile(fileNode.name, 'image');
          }
          onSelectFile(fileNode);
        }}
      />
    </div>
  );
};

export default FileExplorer;
