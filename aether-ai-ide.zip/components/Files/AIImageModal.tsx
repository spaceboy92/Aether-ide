import React, { useState } from 'react';
import { 
  Sparkles, 
  Image as ImageIcon, 
  X, 
  Layers, 
  Wand2, 
  FolderPlus, 
  Check, 
  Loader2, 
  Sliders, 
  Compass 
} from 'lucide-react';
import { generateImageTool, ImageGenOptions } from '../../services/imageGeneratorTool';
import { FileNode } from '../../types';

interface AIImageModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImageCreated: (file: FileNode) => void;
  currentFiles: FileNode[];
  targetFolder?: string;
}

const STYLE_PRESETS = [
  { id: 'general', label: 'General / Digital Art', icon: '🎨', promptSuffix: ', highly detailed digital art, vibrant colors, clean composition' },
  { id: 'cyberpunk', label: 'Cyberpunk & Neon', icon: '🌆', promptSuffix: ', cyberpunk aesthetic, neon lights, dark moody atmosphere, ultra high definition 8k' },
  { id: '3d-render', label: '3D Isometric / Blender', icon: '🧊', promptSuffix: ', 3D isometric render, blender cycles style, soft ambient lighting, smooth surfaces' },
  { id: 'vector', label: 'Flat Vector SVG', icon: '📐', promptSuffix: ', clean flat vector illustration, minimalist style, bold colors, white background' },
  { id: 'pixel-art', label: 'Retro Pixel Art', icon: '👾', promptSuffix: ', 16-bit pixel art style, retro game aesthetic, vibrant pixel palette' },
  { id: 'photorealistic', label: 'Photorealistic', icon: '📷', promptSuffix: ', realistic photography, 35mm lens, sharp focus, cinematic lighting, photorealism' },
  { id: 'minimalist-logo', label: 'Minimalist Icon / Logo', icon: '✨', promptSuffix: ', minimalist logo emblem, clean geometry, modern UI design, vector app icon' },
  { id: 'ui-texture', label: 'Game Texture / Background', icon: '🌌', promptSuffix: ', seamless background texture, game UI asset, fantasy sci-fi landscape' }
];

const RESOLUTIONS = [
  { id: 'square', label: '1024 × 1024 (Square / Icon)', width: 1024, height: 1024 },
  { id: 'landscape', label: '1280 × 720 (16:9 Banner)', width: 1280, height: 720 },
  { id: 'portrait', label: '720 × 1280 (9:16 Mobile)', width: 720, height: 1280 },
  { id: 'compact', label: '512 × 512 (Game Sprite)', width: 512, height: 512 }
];

export const AIImageModal: React.FC<AIImageModalProps> = ({
  isOpen,
  onClose,
  onImageCreated,
  currentFiles,
  targetFolder = 'public/images'
}) => {
  const [prompt, setPrompt] = useState('');
  const [fileName, setFileName] = useState('');
  const [selectedFolder, setSelectedFolder] = useState(targetFolder);
  const [selectedStyle, setSelectedStyle] = useState('general');
  const [selectedResolution, setSelectedResolution] = useState('square');
  const [isGenerating, setIsGenerating] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  // Auto-generate a file name based on prompt
  const handlePromptChange = (val: string) => {
    setPrompt(val);
    if (!fileName || fileName.startsWith('asset-') || fileName.startsWith('image-')) {
      const slug = val
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)+/g, '')
        .slice(0, 24);
      if (slug) {
        setFileName(`${slug}.png`);
      }
    }
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      setErrorMsg('Please enter a description for the image asset.');
      return;
    }

    setErrorMsg(null);
    setIsGenerating(true);

    try {
      const stylePreset = STYLE_PRESETS.find(s => s.id === selectedStyle);
      const resConfig = RESOLUTIONS.find(r => r.id === selectedResolution);
      
      const fullPrompt = `${prompt.trim()}${stylePreset ? stylePreset.promptSuffix : ''}`;
      const finalFileName = fileName.trim() ? (fileName.endsWith('.png') ? fileName : `${fileName}.png`) : `asset-${Date.now()}.png`;
      const cleanFolder = selectedFolder.replace(/^\/+|\/+$/g, '');
      const fullPath = cleanFolder ? `${cleanFolder}/${finalFileName}` : finalFileName;

      const generatedFileNode = await generateImageTool({
        prompt: fullPrompt,
        fileName: fullPath,
        width: resConfig?.width || 1024,
        height: resConfig?.height || 1024,
        style: selectedStyle
      });

      setPreviewImage(generatedFileNode.content);
      onImageCreated(generatedFileNode);
      setIsGenerating(false);
      onClose();
    } catch (err: any) {
      console.error('Image generation error:', err);
      setErrorMsg(err.message || 'Image generation service timed out. Please try again.');
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-150">
      <div 
        className="w-full max-w-xl bg-zinc-950 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-zinc-800/80 flex items-center justify-between bg-zinc-900/40">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-pink-500 to-orange-500 flex items-center justify-center text-white shadow-lg shadow-orange-500/20">
              <Sparkles size={16} />
            </div>
            <div>
              <h2 className="font-extrabold text-sm text-white tracking-wide flex items-center gap-2">
                AI Image Asset Studio
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-orange-500/10 text-orange-400 border border-orange-500/20">
                  Next-Gen
                </span>
              </h2>
              <p className="text-[11px] text-zinc-400">Generate visual game assets, UI textures, icons & photos directly into File Explorer</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-5 custom-scrollbar">
          {/* Prompt input */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-zinc-300 flex items-center justify-between">
              <span>Prompt Description</span>
              <span className="text-[10px] text-zinc-500">Natural language or keywords</span>
            </label>
            <textarea
              rows={3}
              value={prompt}
              onChange={(e) => handlePromptChange(e.target.value)}
              placeholder="e.g. Glowing neon cyberpunk hovercar flying over futuristic megacity at night..."
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-xs text-white placeholder-zinc-500 outline-none focus:border-orange-500/60 focus:ring-1 focus:ring-orange-500/30 transition-all resize-none"
            />
          </div>

          {/* Quick Suggestions */}
          <div className="flex flex-wrap gap-1.5">
            {[
              'Cyberpunk hacker avatar',
              'Isometric floating island 3D',
              'Minimalist modern app logo',
              'Sci-fi game weapon icon',
              'Dark futuristic grid background'
            ].map(sug => (
              <button
                key={sug}
                type="button"
                onClick={() => handlePromptChange(sug)}
                className="px-2.5 py-1 rounded-lg bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-[11px] text-zinc-400 hover:text-orange-400 transition-colors"
              >
                + {sug}
              </button>
            ))}
          </div>

          {/* Style Presets Grid */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-zinc-300 flex items-center gap-1.5">
              <Compass size={13} className="text-orange-400" />
              <span>Style Archetype</span>
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {STYLE_PRESETS.map(style => (
                <button
                  key={style.id}
                  type="button"
                  onClick={() => setSelectedStyle(style.id)}
                  className={`p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                    selectedStyle === style.id 
                      ? 'bg-orange-500/10 border-orange-500 text-white shadow-md shadow-orange-500/10' 
                      : 'bg-zinc-900/60 border-zinc-800/80 text-zinc-400 hover:border-zinc-700 hover:text-zinc-200'
                  }`}
                >
                  <span className="text-lg mb-1">{style.icon}</span>
                  <span className="text-[11px] font-bold leading-tight">{style.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Resolution & Dimensions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-zinc-300 flex items-center gap-1.5">
                <Sliders size={13} className="text-amber-400" />
                <span>Aspect & Resolution</span>
              </label>
              <select
                value={selectedResolution}
                onChange={(e) => setSelectedResolution(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 text-xs text-zinc-200 outline-none focus:border-amber-500"
              >
                {RESOLUTIONS.map(res => (
                  <option key={res.id} value={res.id}>{res.label}</option>
                ))}
              </select>
            </div>

            {/* Target Path in File Explorer */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-zinc-300 flex items-center gap-1.5">
                <FolderPlus size={13} className="text-emerald-400" />
                <span>Target File Path</span>
              </label>
              <div className="flex gap-1">
                <input
                  type="text"
                  value={selectedFolder}
                  onChange={(e) => setSelectedFolder(e.target.value)}
                  placeholder="public/images"
                  className="w-1/2 bg-zinc-900 border border-zinc-800 rounded-xl px-2.5 py-2 text-xs text-zinc-300 outline-none font-mono"
                  title="Folder path"
                />
                <span className="text-zinc-600 flex items-center">/</span>
                <input
                  type="text"
                  value={fileName}
                  onChange={(e) => setFileName(e.target.value)}
                  placeholder="hero-bg.png"
                  className="w-1/2 bg-zinc-900 border border-zinc-800 rounded-xl px-2.5 py-2 text-xs text-zinc-200 outline-none font-mono focus:border-emerald-500"
                  title="File name"
                />
              </div>
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-xs text-red-400">
              {errorMsg}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-zinc-900/60 border-t border-zinc-800/80 flex items-center justify-between">
          <div className="text-[11px] text-zinc-500">
            Generates high-res image & integrates into File Explorer
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={isGenerating}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-zinc-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleGenerate}
              disabled={isGenerating || !prompt.trim()}
              className={`px-5 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all cursor-pointer ${
                isGenerating || !prompt.trim()
                  ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-orange-500 to-pink-500 text-white shadow-lg shadow-orange-500/20 hover:scale-[1.02] active:scale-[0.98]'
              }`}
            >
              {isGenerating ? (
                <>
                  <Loader2 size={14} className="animate-spin" />
                  <span>Synthesizing Asset...</span>
                </>
              ) : (
                <>
                  <Wand2 size={14} />
                  <span>Generate Asset</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
