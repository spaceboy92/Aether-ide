import React, { useState, useEffect, useMemo } from 'react';
import { 
  GitBranch, 
  GitCommit as GitCommitIcon, 
  Clock, 
  Calendar, 
  RotateCcw, 
  Check, 
  Copy, 
  Search, 
  Plus, 
  Sparkles, 
  User, 
  FileCode, 
  PlusCircle, 
  MinusCircle, 
  Eye, 
  Trash2,
  ChevronRight,
  ChevronDown,
  ArrowRight,
  ShieldAlert,
  ShieldCheck,
  AlertTriangle,
  Layers,
  Edit3,
  Save,
  Download,
  Upload,
  RefreshCw,
  Zap,
  FileCheck,
  Wrench,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { FileNode } from '../../types';
import { 
  versionControlService, 
  GitCommit, 
  FileChange, 
  PersistenceHealth 
} from '../../services/versionControlService';

interface FileHistoryViewProps {
  activeFileId?: string | null;
  files?: FileNode[];
  onFilesUpdated?: (files: FileNode[]) => void;
  sessionId?: string | null;
  addLog?: (type: any, message: string, source?: string) => void;
}

const FileHistoryView: React.FC<FileHistoryViewProps> = ({
  activeFileId,
  files = [],
  onFilesUpdated,
  sessionId,
  addLog
}) => {
  const [commits, setCommits] = useState<GitCommit[]>([]);
  const [activeBranch, setActiveBranch] = useState<string>('main');
  const [branches, setBranches] = useState<string[]>(['main']);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCommit, setSelectedCommit] = useState<GitCommit | null>(null);
  const [diffViewCommit, setDiffViewCommit] = useState<GitCommit | null>(null);
  const [selectedFileForDiff, setSelectedFileForDiff] = useState<FileChange | null>(null);
  const [manualPrompt, setManualPrompt] = useState('');
  const [isCreatingCommit, setIsCreatingCommit] = useState(false);
  const [copiedHash, setCopiedHash] = useState<string | null>(null);
  const [confirmRollbackHash, setConfirmRollbackHash] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // In-place code editing state for diff / repair mode
  const [isEditingFile, setIsEditingFile] = useState(false);
  const [editingContent, setEditingContent] = useState('');
  const [editCommitMessage, setEditCommitMessage] = useState('');
  const [isSavingEdit, setIsSavingEdit] = useState(false);

  // Persistence Diagnostics & Emergency Recovery
  const [showDiagnostics, setShowDiagnostics] = useState(false);
  const [health, setHealth] = useState<PersistenceHealth | null>(null);
  const [showNewBranchModal, setShowNewBranchModal] = useState(false);
  const [newBranchName, setNewBranchName] = useState('');

  const refreshHistory = () => {
    const list = versionControlService.getCommits(sessionId || undefined, activeBranch);
    setCommits(list);
    setBranches(versionControlService.getAllBranches());
    setActiveBranch(versionControlService.getActiveBranch());
    setHealth(versionControlService.diagnosePersistence(files));
  };

  useEffect(() => {
    refreshHistory();

    const handleCommitCreated = () => refreshHistory();
    const handleHistoryCleared = () => refreshHistory();
    const handleBranchChanged = () => refreshHistory();

    window.addEventListener('aether_git_commit_created', handleCommitCreated);
    window.addEventListener('aether_git_history_cleared', handleHistoryCleared);
    window.addEventListener('aether_git_branch_changed', handleBranchChanged);

    return () => {
      window.removeEventListener('aether_git_commit_created', handleCommitCreated);
      window.removeEventListener('aether_git_history_cleared', handleHistoryCleared);
      window.removeEventListener('aether_git_branch_changed', handleBranchChanged);
    };
  }, [sessionId, activeBranch, files]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Create manual snapshot / commit
  const handleCreateManualCommit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualPrompt.trim() || files.length === 0) return;

    setIsCreatingCommit(true);
    try {
      const commit = await versionControlService.createCommit({
        prompt: manualPrompt.trim(),
        files: files,
        author: 'user',
        branch: activeBranch,
        sessionId: sessionId || undefined
      });
      setManualPrompt('');
      refreshHistory();
      setSelectedCommit(commit);
      showToast(`Snapshot committed: [${commit.hash.slice(0, 7)}]`);
      addLog?.('success', `Created Git commit [${commit.hash.slice(0, 7)}]: "${commit.prompt}"`, 'GIT_VCS');
    } catch (err: any) {
      addLog?.('error', `Commit failed: ${err.message}`, 'GIT_VCS');
    } finally {
      setIsCreatingCommit(false);
    }
  };

  // Rollback entire workspace to commit
  const handleRollback = async (commit: GitCommit) => {
    if (!onFilesUpdated) {
      showToast('Cannot rollback: file updater not connected');
      return;
    }

    try {
      const result = await versionControlService.revertToCommit(commit.hash, files, sessionId || undefined);
      onFilesUpdated(result.files);
      setConfirmRollbackHash(null);
      refreshHistory();
      showToast(`Restored workspace to commit [${commit.hash.slice(0, 7)}]!`);
      addLog?.('success', `Restored workspace to commit [${commit.hash.slice(0, 7)}] ("${commit.prompt.slice(0, 35)}...")`, 'GIT_VCS');
    } catch (err: any) {
      addLog?.('error', `Rollback error: ${err.message}`, 'GIT_VCS');
    }
  };

  // Restore single file from commit
  const handleRestoreSingleFile = async (commit: GitCommit, filePath: string) => {
    if (!onFilesUpdated) {
      showToast('File updater not connected');
      return;
    }

    try {
      const result = await versionControlService.restoreSingleFile(commit.hash, filePath, files, sessionId || undefined);
      onFilesUpdated(result.files);
      refreshHistory();
      showToast(`Restored ${filePath} from [${commit.hash.slice(0, 7)}]`);
      addLog?.('success', `Restored single file ${filePath} from [${commit.hash.slice(0, 7)}]`, 'GIT_VCS');
    } catch (err: any) {
      showToast(`Failed to restore file: ${err.message}`);
    }
  };

  // Edit and commit code directly
  const handleSaveEditedFile = async () => {
    if (!selectedFileForDiff || !onFilesUpdated) return;
    setIsSavingEdit(true);

    try {
      const msg = editCommitMessage.trim() || `Hotfix & repair ${selectedFileForDiff.path}`;
      const result = await versionControlService.updateAndCommitFile(
        selectedFileForDiff.path,
        editingContent,
        files,
        msg,
        sessionId || undefined
      );

      onFilesUpdated(result.files);
      setIsEditingFile(false);
      refreshHistory();
      showToast(`Applied & committed fix to ${selectedFileForDiff.path}`);
      addLog?.('success', `Updated & committed ${selectedFileForDiff.path}: "${msg}"`, 'GIT_VCS');

      // Update current selected change preview
      setSelectedFileForDiff({
        ...selectedFileForDiff,
        newContent: editingContent,
        diffSummary: 'Edited in VCS Inspector'
      });
    } catch (err: any) {
      showToast(`Save error: ${err.message}`);
    } finally {
      setIsSavingEdit(false);
    }
  };

  // Emergency Restore from Latest Snapshot
  const handleEmergencyRestore = () => {
    if (!onFilesUpdated) return;
    const recovery = versionControlService.emergencyRecoverLatest(sessionId || undefined);
    if (!recovery) {
      showToast('No snapshot found to recover from.');
      return;
    }

    onFilesUpdated(recovery.files);
    refreshHistory();
    showToast(`Emergency recovered ${recovery.files.length} files from [${recovery.commit.shortHash}]!`);
    addLog?.('success', `Emergency restored ${recovery.files.length} files from commit [${recovery.commit.shortHash}]`, 'GIT_VCS');
  };

  // Export JSON Git bundle
  const handleExportBundle = () => {
    try {
      const bundle = versionControlService.exportBundle();
      const blob = new Blob([bundle], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `aether-git-backup-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      showToast('Exported Git Version Control backup bundle!');
    } catch (err: any) {
      showToast(`Export failed: ${err.message}`);
    }
  };

  // Import JSON Git bundle
  const handleImportBundle = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const result = versionControlService.importBundle(text);
        if (result.files && onFilesUpdated) {
          onFilesUpdated(result.files);
        }
        refreshHistory();
        showToast(`Imported ${result.importedCount} Git commits!`);
        addLog?.('success', `Imported ${result.importedCount} Git commits from backup file.`, 'GIT_VCS');
      } catch (err: any) {
        showToast(`Import failed: ${err.message}`);
      }
    };
    reader.readAsText(file);
  };

  // Create branch
  const handleCreateBranch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBranchName.trim()) return;

    const success = versionControlService.createBranch(newBranchName);
    if (success) {
      setActiveBranch(newBranchName.trim().replace(/\s+/g, '-').toLowerCase());
      setNewBranchName('');
      setShowNewBranchModal(false);
      refreshHistory();
      showToast(`Created & switched to branch "${newBranchName}"`);
    } else {
      showToast('Branch already exists or invalid name');
    }
  };

  const handleCopyHash = (hash: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(hash);
    setCopiedHash(hash);
    setTimeout(() => setCopiedHash(null), 2000);
  };

  // Filter commits
  const filteredCommits = useMemo(() => {
    return commits.filter(c => {
      const q = searchQuery.toLowerCase();
      const matchesSearch = 
        c.prompt.toLowerCase().includes(q) ||
        c.hash.toLowerCase().includes(q) ||
        c.shortHash.toLowerCase().includes(q) ||
        c.formattedDate.toLowerCase().includes(q) ||
        c.formattedTime.toLowerCase().includes(q) ||
        c.author.toLowerCase().includes(q) ||
        c.changes.some(ch => ch.path.toLowerCase().includes(q));
      return matchesSearch;
    });
  }, [commits, searchQuery]);

  return (
    <div className="flex flex-col h-full bg-[#0a0c10] text-zinc-200 select-none overflow-hidden font-sans">
      {/* Header Bar */}
      <div className="p-3.5 border-b border-white/10 bg-zinc-950/90 flex flex-col gap-2.5 shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-orange-500/10 border border-orange-500/30 text-orange-400">
              <GitBranch size={16} />
            </div>
            <div>
              <h2 className="text-xs font-black uppercase tracking-wider text-white flex items-center gap-1.5">
                Git Version Control
                <span className="px-1.5 py-0.5 rounded-full text-[9px] bg-orange-500/20 text-orange-300 font-mono">
                  {commits.length} commits
                </span>
              </h2>
              <p className="text-[10px] text-zinc-400">File Snapshots, Diff Inspector & Persistence Recovery</p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Persistence Health Badge */}
            <button
              onClick={() => setShowDiagnostics(!showDiagnostics)}
              className={`flex items-center gap-1 text-[10px] font-mono px-2 py-1 rounded-lg border transition-colors cursor-pointer ${
                health?.status === 'critical'
                  ? 'bg-red-500/20 border-red-500/40 text-red-300'
                  : health?.status === 'warning'
                  ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                  : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20'
              }`}
              title="Click to view persistence diagnostics & recovery options"
            >
              {health?.status === 'critical' ? (
                <AlertTriangle size={11} className="text-red-400" />
              ) : health?.status === 'warning' ? (
                <AlertTriangle size={11} className="text-amber-400" />
              ) : (
                <ShieldCheck size={11} className="text-emerald-400" />
              )}
              <span>{health?.status.toUpperCase() || 'HEALTH'}</span>
            </button>

            {/* Branch Selector */}
            <div className="flex items-center gap-1 bg-zinc-900 border border-white/10 rounded-lg px-2 py-1">
              <GitBranch size={11} className="text-zinc-400" />
              <select
                value={activeBranch}
                onChange={(e) => {
                  const b = e.target.value;
                  versionControlService.setActiveBranch(b);
                  setActiveBranch(b);
                  refreshHistory();
                }}
                className="bg-transparent text-[11px] font-mono text-zinc-200 focus:outline-none cursor-pointer"
              >
                {branches.map(b => (
                  <option key={b} value={b} className="bg-zinc-900 text-white">{b}</option>
                ))}
              </select>
              <button
                onClick={() => setShowNewBranchModal(true)}
                className="text-zinc-400 hover:text-orange-400 ml-0.5 p-0.5 rounded cursor-pointer"
                title="Create New Branch"
              >
                <Plus size={12} />
              </button>
            </div>
          </div>
        </div>

        {/* Persistence Recovery & Diagnostic Drawer */}
        <AnimatePresence>
          {showDiagnostics && health && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="bg-black/80 border border-orange-500/30 rounded-xl p-3 text-xs space-y-2.5 overflow-hidden"
            >
              <div className="flex items-center justify-between border-b border-white/10 pb-1.5">
                <div className="flex items-center gap-1.5 font-bold text-orange-400 text-[11px]">
                  <Wrench size={13} />
                  <span>PERSISTENCE DIAGNOSTICS & EMERGENCY RECOVERY</span>
                </div>
                <button
                  onClick={() => setShowDiagnostics(false)}
                  className="text-zinc-400 hover:text-white"
                >
                  <X size={13} />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2 font-mono text-[10px]">
                <div className="p-1.5 bg-zinc-900/80 rounded border border-white/5">
                  <div className="text-zinc-400">Storage Used:</div>
                  <div className="font-bold text-white">{health.formattedStorageUsed}</div>
                </div>
                <div className="p-1.5 bg-zinc-900/80 rounded border border-white/5">
                  <div className="text-zinc-400">Workspace Files:</div>
                  <div className="font-bold text-white">{health.filesInWorkspace} active</div>
                </div>
              </div>

              {health.recommendations.length > 0 && (
                <div className="space-y-1">
                  {health.recommendations.map((rec, ri) => (
                    <div key={ri} className="text-[10px] text-amber-300/90 flex items-start gap-1">
                      <span>•</span>
                      <span>{rec}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Emergency Action Buttons */}
              <div className="flex items-center gap-2 pt-1 flex-wrap">
                <button
                  onClick={handleEmergencyRestore}
                  className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 font-bold text-[10px] rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                  title="Restore workspace from most recent valid snapshot"
                >
                  <Zap size={12} className="text-amber-400" />
                  Emergency Restore Latest
                </button>

                <button
                  onClick={handleExportBundle}
                  className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[10px] rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                  title="Export offline JSON backup"
                >
                  <Download size={11} />
                  Export Bundle
                </button>

                <label className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[10px] rounded-lg transition-colors flex items-center gap-1 cursor-pointer">
                  <Upload size={11} />
                  Import Backup
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleImportBundle}
                    className="hidden"
                  />
                </label>

                <button
                  onClick={() => {
                    const pruned = versionControlService.repairCorruptSnapshots();
                    refreshHistory();
                    showToast(`Cleaned ${pruned} corrupt items.`);
                  }}
                  className="px-2 py-1 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 text-[10px] rounded-lg transition-colors"
                >
                  Repair
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Manual Commit Input Form */}
        <form onSubmit={handleCreateManualCommit} className="flex items-center gap-1.5">
          <input
            type="text"
            placeholder="Commit message / prompt milestone..."
            value={manualPrompt}
            onChange={(e) => setManualPrompt(e.target.value)}
            className="flex-1 bg-zinc-900/90 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-orange-500/50"
          />
          <button
            type="submit"
            disabled={!manualPrompt.trim() || isCreatingCommit}
            className="px-3 py-1.5 bg-orange-500 hover:bg-orange-600 disabled:opacity-40 text-black font-black text-xs rounded-lg transition-colors flex items-center gap-1 shrink-0 cursor-pointer"
            title="Create snapshot commit with date, time, and files"
          >
            <Plus size={13} />
            Commit
          </button>
        </form>

        {/* Search / Filter Input */}
        <div className="relative">
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-500" />
          <input
            type="text"
            placeholder="Filter commits by prompt, file, date, hash..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-zinc-900/60 border border-white/5 rounded-lg pl-8 pr-3 py-1 text-[11px] text-zinc-300 placeholder-zinc-500 focus:outline-none focus:border-white/20"
          />
        </div>
      </div>

      {/* Toast Notification */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="bg-emerald-500/90 text-black text-xs font-black px-3 py-1.5 text-center shadow-lg shrink-0 flex items-center justify-center gap-1.5"
          >
            <Check size={13} />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Timeline Commit List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3 custom-scrollbar">
        {filteredCommits.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 px-4 text-center text-zinc-500">
            <GitCommitIcon size={32} className="mb-2 text-zinc-600 animate-pulse" />
            <p className="text-xs font-bold text-zinc-400">No Git Commits Found</p>
            <p className="text-[11px] text-zinc-500 mt-1 max-w-[220px]">
              AI prompts, file edits, and manual commits will automatically appear here with timestamps, dates, and diffs.
            </p>
          </div>
        ) : (
          filteredCommits.map((commit) => {
            const isSelected = selectedCommit?.hash === commit.hash;
            const isConfirmingRollback = confirmRollbackHash === commit.hash;

            return (
              <div
                key={commit.hash}
                onClick={() => setSelectedCommit(isSelected ? null : commit)}
                className={`relative rounded-xl border transition-all duration-200 cursor-pointer overflow-hidden ${
                  isSelected 
                    ? 'bg-zinc-900/90 border-orange-500/50 shadow-lg shadow-orange-950/30' 
                    : 'bg-zinc-950/60 hover:bg-zinc-900/60 border-white/5 hover:border-white/15'
                }`}
              >
                {/* Branch Line Visual */}
                <div className="absolute left-3.5 top-0 bottom-0 w-0.5 bg-orange-500/20" />

                <div className="p-3 pl-8 relative">
                  {/* Timeline Dot */}
                  <div className={`absolute left-2.5 top-4 w-2.5 h-2.5 rounded-full border-2 ${
                    commit.author === 'ai'
                      ? 'bg-cyan-400 border-cyan-300 shadow-[0_0_8px_rgba(6,182,212,0.8)]'
                      : commit.author === 'system'
                      ? 'bg-amber-400 border-amber-300'
                      : 'bg-orange-500 border-orange-400'
                  }`} />

                  {/* Top Metadata Row: Date, Time, Hash, Author */}
                  <div className="flex items-center justify-between gap-2 mb-1.5 flex-wrap">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="flex items-center gap-1 text-[10px] font-mono text-zinc-400 bg-white/5 px-1.5 py-0.5 rounded">
                        <Calendar size={10} className="text-zinc-400" />
                        {commit.formattedDate}
                      </span>
                      <span className="flex items-center gap-1 text-[10px] font-mono text-orange-300 bg-orange-500/10 px-1.5 py-0.5 rounded">
                        <Clock size={10} className="text-orange-400" />
                        {commit.formattedTime}
                      </span>
                      <span className="text-[10px] text-zinc-500 font-sans">
                        ({commit.relativeTime})
                      </span>
                    </div>

                    {/* Commit Hash Pill */}
                    <button
                      onClick={(e) => handleCopyHash(commit.hash, e)}
                      className="flex items-center gap-1 text-[10px] font-mono text-zinc-400 hover:text-white bg-zinc-800 hover:bg-zinc-700 px-1.5 py-0.5 rounded transition-colors"
                      title="Copy Commit Hash"
                    >
                      {copiedHash === commit.hash ? <Check size={10} className="text-emerald-400" /> : <Copy size={10} />}
                      {commit.hash.slice(0, 7)}
                    </button>
                  </div>

                  {/* Primary Prompt / Commit Message */}
                  <div className="mb-2">
                    <div className="text-xs font-bold text-white line-clamp-2 leading-relaxed">
                      {commit.prompt}
                    </div>
                  </div>

                  {/* Badges Row: Author & File Stats */}
                  <div className="flex items-center justify-between gap-2 text-[10px] flex-wrap">
                    <div className="flex items-center gap-1.5">
                      {commit.author === 'ai' ? (
                        <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-medium">
                          <Sparkles size={10} /> AI Synthesis
                        </span>
                      ) : commit.author === 'system' ? (
                        <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-medium">
                          <RotateCcw size={10} /> System Revert
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-300 font-medium">
                          <User size={10} /> Developer
                        </span>
                      )}

                      {commit.tag && (
                        <span className="px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono">
                          🏷️ {commit.tag}
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 font-mono">
                      <span className="text-emerald-400 font-bold">+{commit.stats.additions}</span>
                      <span className="text-red-400 font-bold">-{commit.stats.deletions}</span>
                      <span className="text-zinc-400">{commit.stats.totalFiles} files</span>
                    </div>
                  </div>

                  {/* Expanded Action Panel */}
                  {isSelected && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-3 pt-3 border-t border-white/10 flex flex-col gap-2.5"
                    >
                      {/* Changed Files Summary */}
                      <div className="space-y-1">
                        <span className="text-[10px] font-black uppercase tracking-wider text-zinc-400">
                          Modified Files ({commit.changes.length})
                        </span>
                        <div className="max-h-36 overflow-y-auto space-y-1 pr-1 custom-scrollbar">
                          {commit.changes.map((change, ci) => (
                            <div
                              key={ci}
                              className="flex items-center justify-between text-[11px] p-1.5 rounded bg-black/40 hover:bg-zinc-800/80 border border-white/5 transition-colors group"
                            >
                              <div 
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setDiffViewCommit(commit);
                                  setSelectedFileForDiff(change);
                                  setIsEditingFile(false);
                                }}
                                className="flex items-center gap-1.5 truncate flex-1 cursor-pointer"
                              >
                                <FileCode size={12} className="text-orange-400 shrink-0" />
                                <span className="truncate text-zinc-200">{change.path}</span>
                              </div>
                              
                              <div className="flex items-center gap-1.5 shrink-0 font-mono text-[10px]">
                                {change.status === 'added' && (
                                  <span className="text-emerald-400 bg-emerald-500/10 px-1 rounded">added</span>
                                )}
                                {change.status === 'modified' && (
                                  <span className="text-amber-400 bg-amber-500/10 px-1 rounded">mod</span>
                                )}
                                {change.status === 'deleted' && (
                                  <span className="text-red-400 bg-red-500/10 px-1 rounded">del</span>
                                )}
                                
                                {/* Quick Cherry-Pick / Restore Single File */}
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleRestoreSingleFile(commit, change.path);
                                  }}
                                  className="opacity-0 group-hover:opacity-100 px-1.5 py-0.5 bg-orange-500/20 hover:bg-orange-500/40 text-orange-300 rounded text-[9px] font-bold transition-opacity cursor-pointer flex items-center gap-0.5"
                                  title={`Restore only ${change.path} to workspace`}
                                >
                                  <FileCheck size={10} />
                                  Restore File
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Action Buttons */}
                      <div className="flex items-center justify-between gap-2 pt-1 flex-wrap">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setDiffViewCommit(commit);
                            setSelectedFileForDiff(commit.changes[0] || null);
                            setIsEditingFile(false);
                          }}
                          className="px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-bold rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          <Eye size={12} /> Inspect / Edit Diffs
                        </button>

                        {isConfirmingRollback ? (
                          <div className="flex items-center gap-1.5 bg-red-950/80 border border-red-500/50 p-1 rounded-lg">
                            <span className="text-[10px] text-red-300 font-bold px-1">Restore entire workspace?</span>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleRollback(commit);
                              }}
                              className="px-2 py-0.5 bg-red-600 hover:bg-red-700 text-white font-black text-[10px] rounded transition-colors"
                            >
                              Yes, Restore
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setConfirmRollbackHash(null);
                              }}
                              className="px-1.5 py-0.5 text-zinc-400 hover:text-white text-[10px]"
                            >
                              Cancel
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setConfirmRollbackHash(commit.hash);
                            }}
                            className="px-2.5 py-1 bg-orange-500/20 hover:bg-orange-500/30 border border-orange-500/40 text-orange-300 text-xs font-black rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                          >
                            <RotateCcw size={12} /> Rollback Workspace
                          </button>
                        )}
                      </div>
                    </motion.div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Diff Inspector & In-Place Code Editor Modal */}
      <AnimatePresence>
        {diffViewCommit && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="bg-zinc-950 border border-white/15 rounded-2xl w-full max-w-5xl max-h-[90vh] flex flex-col overflow-hidden shadow-2xl"
            >
              {/* Modal Header */}
              <div className="p-4 border-b border-white/10 bg-zinc-900/80 flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 rounded-lg bg-orange-500/20 text-orange-400">
                    <GitCommitIcon size={18} />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      Commit [{diffViewCommit.hash.slice(0, 7)}]
                      <span className="text-xs font-mono text-zinc-400">
                        {diffViewCommit.formattedDate} {diffViewCommit.formattedTime}
                      </span>
                    </h3>
                    <p className="text-xs text-zinc-400 font-sans line-clamp-1">
                      Prompt: "{diffViewCommit.prompt}"
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {selectedFileForDiff && (
                    <button
                      onClick={() => {
                        if (!isEditingFile) {
                          setEditingContent(selectedFileForDiff.newContent || selectedFileForDiff.oldContent || '');
                          setEditCommitMessage(`Fix & edit ${selectedFileForDiff.path}`);
                        }
                        setIsEditingFile(!isEditingFile);
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                        isEditingFile
                          ? 'bg-amber-500 text-black'
                          : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-white/10'
                      }`}
                    >
                      <Edit3 size={13} />
                      {isEditingFile ? 'Exit Code Editor' : 'Edit & Fix Code'}
                    </button>
                  )}

                  <button
                    onClick={() => {
                      setDiffViewCommit(null);
                      setSelectedFileForDiff(null);
                      setIsEditingFile(false);
                    }}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-colors cursor-pointer"
                  >
                    ✕
                  </button>
                </div>
              </div>

              {/* Modal Content: File List on left, Code Diff / Editor on right */}
              <div className="flex-1 flex overflow-hidden min-h-[400px]">
                {/* File selection sidebar */}
                <div className="w-64 border-r border-white/10 p-3 overflow-y-auto space-y-1 bg-black/40 shrink-0">
                  <div className="text-[10px] font-black uppercase tracking-wider text-zinc-500 mb-2 flex items-center justify-between">
                    <span>Changed Files ({diffViewCommit.changes.length})</span>
                  </div>
                  {diffViewCommit.changes.map((ch, i) => (
                    <button
                      key={i}
                      onClick={() => {
                        setSelectedFileForDiff(ch);
                        setIsEditingFile(false);
                      }}
                      className={`w-full text-left p-2 rounded-lg text-xs flex items-center justify-between transition-colors cursor-pointer ${
                        selectedFileForDiff?.path === ch.path
                          ? 'bg-orange-500/20 text-orange-200 border border-orange-500/40'
                          : 'hover:bg-zinc-900 text-zinc-300'
                      }`}
                    >
                      <span className="truncate font-mono">{ch.path}</span>
                      <span className="text-[10px] font-mono shrink-0 ml-1 text-zinc-400">
                        +{ch.additions}/-{ch.deletions}
                      </span>
                    </button>
                  ))}
                </div>

                {/* Diff Viewer / In-Place Editor Pane */}
                <div className="flex-1 p-4 overflow-y-auto font-mono text-xs custom-scrollbar bg-[#050608] flex flex-col">
                  {selectedFileForDiff ? (
                    <div className="flex-1 flex flex-col space-y-3">
                      <div className="flex items-center justify-between border-b border-white/10 pb-2 flex-wrap gap-2">
                        <div className="flex items-center gap-2">
                          <FileCode size={14} className="text-orange-400" />
                          <span className="text-sm font-bold text-white">{selectedFileForDiff.path}</span>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleRestoreSingleFile(diffViewCommit, selectedFileForDiff.path)}
                            className="px-2.5 py-1 bg-orange-500/20 hover:bg-orange-500/30 text-orange-300 border border-orange-500/40 rounded-lg text-[11px] font-bold flex items-center gap-1 cursor-pointer transition-colors"
                            title="Restore only this file into the current workspace"
                          >
                            <FileCheck size={12} />
                            Restore This File Only
                          </button>
                        </div>
                      </div>
                      
                      {isEditingFile ? (
                        /* Direct in-place file editor for hotfixes */
                        <div className="flex-1 flex flex-col space-y-2">
                          <div className="flex items-center gap-2">
                            <input
                              type="text"
                              placeholder="Commit message for this repair..."
                              value={editCommitMessage}
                              onChange={(e) => setEditCommitMessage(e.target.value)}
                              className="flex-1 bg-zinc-900 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-amber-400"
                            />
                            <button
                              onClick={handleSaveEditedFile}
                              disabled={isSavingEdit}
                              className="px-4 py-1.5 bg-amber-400 hover:bg-amber-300 text-black font-black text-xs rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                            >
                              <Save size={13} />
                              Apply & Commit Fix
                            </button>
                          </div>
                          <textarea
                            value={editingContent}
                            onChange={(e) => setEditingContent(e.target.value)}
                            className="flex-1 w-full bg-black/90 border border-amber-500/30 rounded-xl p-3 text-zinc-100 text-xs font-mono leading-relaxed outline-none focus:border-amber-400 resize-none min-h-[300px]"
                            spellCheck={false}
                          />
                        </div>
                      ) : (
                        /* Code Diff View */
                        <div className="bg-black/60 rounded-xl p-3 border border-white/5 overflow-x-auto flex-1">
                          <pre className="text-zinc-300 text-xs whitespace-pre-wrap leading-relaxed">
                            {selectedFileForDiff.newContent || selectedFileForDiff.oldContent || '// No text content in this version'}
                          </pre>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-center text-zinc-500 py-16 flex flex-col items-center justify-center">
                      <FileCode size={32} className="mb-2 text-zinc-600" />
                      <span>Select a file on the left to inspect its version diff or edit its code.</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Modal Footer */}
              <div className="p-3.5 border-t border-white/10 bg-zinc-900/80 flex items-center justify-between flex-wrap gap-2">
                <span className="text-xs text-zinc-400 font-mono">
                  Changes: +{diffViewCommit.stats.additions} / -{diffViewCommit.stats.deletions} lines across {diffViewCommit.stats.totalFiles} files
                </span>
                <button
                  onClick={() => {
                    handleRollback(diffViewCommit);
                    setDiffViewCommit(null);
                  }}
                  className="px-4 py-2 bg-orange-500 hover:bg-orange-600 text-black font-black text-xs rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <RotateCcw size={14} /> Revert Entire Workspace to this Snapshot
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* New Branch Modal */}
      <AnimatePresence>
        {showNewBranchModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="bg-zinc-950 border border-white/15 rounded-2xl w-full max-w-sm p-4 space-y-3 shadow-2xl"
            >
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-black uppercase text-white flex items-center gap-1.5">
                  <GitBranch size={14} className="text-orange-400" />
                  Create New Branch
                </h3>
                <button onClick={() => setShowNewBranchModal(false)} className="text-zinc-400 hover:text-white">✕</button>
              </div>

              <form onSubmit={handleCreateBranch} className="space-y-3">
                <input
                  type="text"
                  placeholder="e.g. feature-game-mechanics, hotfix-physics"
                  value={newBranchName}
                  onChange={(e) => setNewBranchName(e.target.value)}
                  className="w-full bg-zinc-900 border border-white/10 rounded-lg px-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-orange-400 font-mono"
                  autoFocus
                />
                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowNewBranchModal(false)}
                    className="px-3 py-1.5 text-xs text-zinc-400 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={!newBranchName.trim()}
                    className="px-4 py-1.5 bg-orange-500 hover:bg-orange-600 disabled:opacity-40 text-black font-black text-xs rounded-lg transition-colors cursor-pointer"
                  >
                    Create & Switch
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default FileHistoryView;
