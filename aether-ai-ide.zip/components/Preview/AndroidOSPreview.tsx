import React, { useState, useEffect, useRef } from 'react';
import { 
  Smartphone, Battery, Wifi, Signal, Search, Home, ArrowLeft, 
  MoreVertical, Heart, Share2, MessageCircle, Plus, RefreshCw, 
  Cloud, Shield, Play, Folder, Settings, Camera, Compass, 
  FolderOpen, FileCode, User, Info, Sliders, Sun, Moon, 
  Flame, Activity, HardDrive, Terminal, Lock, Unlock, 
  WifiOff, Volume2, VolumeX, AlertCircle, ShoppingBag, 
  CheckCircle, ChevronRight, Power, Sparkles, Loader2, Send
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const ParticleCanvas: React.FC<{ theme: string; speed: number; count: number; maxDist: number }> = ({ theme, speed, count, maxDist }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef<{ x: number; y: number; active: boolean }>({ x: 0, y: 0, active: false });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = canvas.width = canvas.offsetWidth || 300;
    let height = canvas.height = canvas.offsetHeight || 180;

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.offsetWidth || 300;
      height = canvas.height = canvas.offsetHeight || 180;
    };
    window.addEventListener('resize', handleResize);

    // Color theme matching
    const colors = {
      sunset: ['#f97316', '#fdba74', '#ea580c', '#ffffff'],
      quantum: ['#06b6d4', '#67e8f9', '#0891b2', '#ffffff'],
      matrix: ['#22c55e', '#86efac', '#16a34a', '#ffffff'],
      coral: ['#f43f5e', '#fda4af', '#e11d48', '#ffffff']
    }[theme as 'sunset' | 'quantum' | 'matrix' | 'coral'] || ['#f97316', '#ffffff'];

    interface Particle {
      x: number;
      y: number;
      vx: number;
      vy: number;
      radius: number;
      color: string;
    }

    const particles: Particle[] = [];
    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * speed * 0.5,
        vy: (Math.random() - 0.5) * speed * 0.5,
        radius: 1.5 + Math.random() * 2,
        color: colors[Math.floor(Math.random() * colors.length)]
      });
    }

    const onMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current = {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
        active: true
      };
    };

    const onMouseLeave = () => {
      mouseRef.current.active = false;
    };

    const onTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        const rect = canvas.getBoundingClientRect();
        mouseRef.current = {
          x: e.touches[0].clientX - rect.left,
          y: e.touches[0].clientY - rect.top,
          active: true
        };
      }
    };

    canvas.addEventListener('mousemove', onMouseMove);
    canvas.addEventListener('mouseleave', onMouseLeave);
    canvas.addEventListener('touchmove', onTouchMove);
    canvas.addEventListener('touchend', onMouseLeave);

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      // Draw constellation links
      ctx.lineWidth = 0.5;
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < maxDist) {
            const alpha = (1 - dist / maxDist) * 0.15;
            ctx.strokeStyle = `rgba(100, 116, 139, ${alpha})`;
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }

      // Update and draw particles
      particles.forEach((p) => {
        // Gravitational force model on hover
        if (mouseRef.current.active) {
          const dx = mouseRef.current.x - p.x;
          const dy = mouseRef.current.y - p.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 100) {
            const force = (100 - dist) / 1000;
            p.vx += dx * force * 0.1;
            p.vy += dy * force * 0.1;
          }
        }

        p.x += p.vx;
        p.y += p.vy;

        // Friction limits
        p.vx *= 0.98;
        p.vy *= 0.98;

        // Bounce borders
        if (p.x < 0 || p.x > width) p.vx *= -1;
        if (p.y < 0 || p.y > height) p.vy *= -1;

        // Constraint boundaries
        p.x = Math.max(0, Math.min(width, p.x));
        p.y = Math.max(0, Math.min(height, p.y));

        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      if (canvas) {
        canvas.removeEventListener('mousemove', onMouseMove);
        canvas.removeEventListener('mouseleave', onMouseLeave);
        canvas.removeEventListener('touchmove', onTouchMove);
        canvas.removeEventListener('touchend', onMouseLeave);
      }
    };
  }, [theme, speed, count, maxDist]);

  return <canvas ref={canvasRef} className="w-full h-full block bg-black/40 rounded-2xl border border-zinc-900" />;
};

import { generateId } from '../../utils/id';

const ComposeRenderer: React.FC<{
  nodes: any[];
  states: Record<string, any>;
  onStateChange: (name: string, value: any) => void;
  onExecuteAction: (action: string) => void;
}> = ({ nodes, states, onStateChange, onExecuteAction }) => {
  const resolveVal = (valStr: string) => {
    if (!valStr) return "";
    let clean = valStr.trim();
    if (clean.startsWith('"') && clean.endsWith('"')) {
      clean = clean.slice(1, -1);
    }
    return clean.replace(/\$?\{?(\w+)\}?/g, (match, name) => {
      return states[name] !== undefined ? String(states[name]) : match;
    });
  };

  return (
    <>
      {nodes.map((node, index) => {
        let className = "";
        let inlineStyle: React.CSSProperties = {};
        
        if (node.modifiers) {
          if (node.modifiers.fillMaxSize) {
            className += " w-full h-full";
          }
          if (node.modifiers.fillMaxWidth) {
            className += " w-full";
          }
          if (node.modifiers.fillMaxHeight) {
            className += " h-full";
          }
          if (node.modifiers.padding) {
            const pVal = node.modifiers.padding;
            if (pVal === true || String(pVal).includes("16.dp")) className += " p-4";
            else if (String(pVal).includes("12.dp")) className += " p-3";
            else if (String(pVal).includes("8.dp")) className += " p-2";
            else if (String(pVal).includes("bottom = 16.dp")) className += " pb-4";
            else if (String(pVal).includes("bottom = 12.dp")) className += " pb-3";
            else if (String(pVal).includes("bottom = 8.dp")) className += " pb-2";
            else className += " p-3";
          }
          if (node.modifiers.height) {
            const hVal = parseFloat(node.modifiers.height);
            if (!isNaN(hVal)) inlineStyle.height = hVal;
          }
          if (node.modifiers.width) {
            const wVal = parseFloat(node.modifiers.width);
            if (!isNaN(wVal)) inlineStyle.width = wVal;
          }
          if (node.modifiers.background) {
            className += " bg-zinc-900";
          }
        }

        switch (node.type) {
          case 'ConditionIf': {
            const cond = node.args.condition;
            if (!cond) return null;
            const isNegated = cond.startsWith('!');
            const varName = isNegated ? cond.slice(1).trim() : cond.trim();
            const val = states[varName] === true;
            const shouldRender = isNegated ? !val : val;
            if (!shouldRender) return null;
            return (
              <ComposeRenderer
                key={index}
                nodes={node.children}
                states={states}
                onStateChange={onStateChange}
                onExecuteAction={onExecuteAction}
              />
            );
          }
          
          case 'Column': {
            let alignClass = "items-start";
            if (node.args.horizontalAlignment && node.args.horizontalAlignment.includes("CenterHorizontally")) {
              alignClass = "items-center";
            }
            return (
              <div key={index} className={`flex flex-col gap-3.5 ${alignClass} ${className}`} style={inlineStyle}>
                <ComposeRenderer
                  nodes={node.children}
                  states={states}
                  onStateChange={onStateChange}
                  onExecuteAction={onExecuteAction}
                />
              </div>
            );
          }
          
          case 'Row': {
            let justifyClass = "justify-start";
            if (node.args.horizontalArrangement && node.args.horizontalArrangement.includes("SpaceBetween")) {
              justifyClass = "justify-between";
            }
            return (
              <div key={index} className={`flex flex-row items-center gap-3.5 ${justifyClass} ${className}`} style={inlineStyle}>
                <ComposeRenderer
                  nodes={node.children}
                  states={states}
                  onStateChange={onStateChange}
                  onExecuteAction={onExecuteAction}
                />
              </div>
            );
          }
          
          case 'Box':
            return (
              <div key={index} className={`relative ${className}`} style={inlineStyle}>
                <ComposeRenderer
                  nodes={node.children}
                  states={states}
                  onStateChange={onStateChange}
                  onExecuteAction={onExecuteAction}
                />
              </div>
            );
            
          case 'Card':
            return (
              <div key={index} className={`rounded-2xl bg-zinc-900 border border-zinc-800 p-4 shadow-xl w-full ${className}`} style={inlineStyle}>
                <ComposeRenderer
                  nodes={node.children}
                  states={states}
                  onStateChange={onStateChange}
                  onExecuteAction={onExecuteAction}
                />
              </div>
            );
            
          case 'Text': {
            const txtStyle = node.args.style || "";
            let textClass = "text-[11px] text-zinc-300";
            if (txtStyle.includes("headlineMedium") || txtStyle.includes("h4") || txtStyle.includes("h5")) {
              textClass = "text-sm font-black uppercase tracking-wider text-white";
            } else if (txtStyle.includes("titleMedium") || txtStyle.includes("titleLarge")) {
              textClass = "text-[12px] font-bold text-white";
            } else if (txtStyle.includes("bodySmall")) {
              textClass = "text-[9px] text-zinc-500 font-mono";
            }
            return (
              <p key={index} className={`${textClass} leading-snug text-left ${className}`} style={inlineStyle}>
                {resolveVal(node.args.text || node.args.value || "")}
              </p>
            );
          }
          
          case 'Button': {
            const clickAction = node.args.onClick;
            return (
              <button
                key={index}
                onClick={() => {
                  if (clickAction) {
                    onExecuteAction(clickAction);
                  }
                }}
                className={`w-full py-2.5 bg-orange-500 hover:bg-orange-400 active:scale-98 text-black text-[9px] font-black uppercase tracking-widest rounded-xl transition-all shadow-md shadow-orange-500/10 cursor-pointer ${className}`}
                style={inlineStyle}
              >
                <ComposeRenderer
                  nodes={node.children}
                  states={states}
                  onStateChange={onStateChange}
                  onExecuteAction={onExecuteAction}
                />
              </button>
            );
          }
          
          case 'IconButton': {
            const clickAction = node.args.onClick;
            return (
              <button
                key={index}
                onClick={() => {
                  if (clickAction) {
                    onExecuteAction(clickAction);
                  }
                }}
                className={`p-2 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-orange-500/20 rounded-xl transition-all active:scale-95 text-orange-500 cursor-pointer ${className}`}
                style={inlineStyle}
              >
                <ComposeRenderer
                  nodes={node.children}
                  states={states}
                  onStateChange={onStateChange}
                  onExecuteAction={onExecuteAction}
                />
              </button>
            );
          }
          
          case 'Spacer': {
            let spaceHeight = 8;
            if (node.modifiers && node.modifiers.height) {
              const hFloat = parseFloat(node.modifiers.height);
              if (!isNaN(hFloat)) spaceHeight = hFloat;
            }
            return <div key={index} style={{ height: `${spaceHeight}px`, width: '100%' }} />;
          }
          
          case 'TextField': {
            const varName = node.args.value;
            const placeholder = resolveVal(node.args.placeholder || '""');
            return (
              <div key={index} className={`flex flex-col gap-1 w-full text-left ${className}`} style={inlineStyle}>
                <input
                  type="text"
                  value={states[varName] !== undefined ? states[varName] : ""}
                  onChange={(e) => {
                    if (varName) {
                      onStateChange(varName, e.target.value);
                    }
                  }}
                  placeholder={placeholder}
                  className="w-full bg-zinc-950 border border-zinc-800/80 rounded-xl px-3 py-2 text-[10px] text-white font-mono placeholder:text-zinc-700 focus:outline-none focus:border-orange-500/30"
                />
              </div>
            );
          }
          
          case 'Slider': {
            const varName = node.args.value;
            const val = states[varName] !== undefined ? parseFloat(states[varName]) : 0;
            return (
              <div key={index} className="w-full px-1">
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={val}
                  onChange={(e) => {
                    if (varName) {
                      onStateChange(varName, parseFloat(e.target.value));
                    }
                  }}
                  className="w-full accent-orange-500 cursor-pointer"
                />
              </div>
            );
          }
          
          case 'Switch': {
            const varName = node.args.checked;
            const isChecked = states[varName] === true;
            return (
              <button
                key={index}
                type="button"
                onClick={() => {
                  if (varName) {
                    onStateChange(varName, !isChecked);
                  }
                }}
                className={`w-9 h-5 flex items-center rounded-full p-0.5 cursor-pointer transition-colors ${isChecked ? 'bg-orange-500' : 'bg-zinc-800'}`}
              >
                <div className={`bg-black w-4 h-4 rounded-full shadow-md transform transition-transform duration-200 ${isChecked ? 'translate-x-4' : 'translate-x-0'}`} />
              </button>
            );
          }
          
          case 'CircularProgressIndicator':
            return (
              <div key={index} className="py-2 flex justify-center w-full">
                <Loader2 size={18} className="text-orange-500 animate-spin" />
              </div>
            );
            
          case 'LinearProgressIndicator':
            return (
              <div key={index} className="w-full h-1 bg-zinc-900 rounded-full overflow-hidden my-2">
                <div className="w-1/3 h-full bg-orange-500 rounded-full animate-pulse" style={{ animationDuration: '1.2s' }} />
              </div>
            );
            
          case 'Divider':
          case 'HorizontalDivider':
            return <div key={index} className="w-full h-[1px] bg-zinc-800/80 my-1" />;
            
          default:
            return null;
        }
      })}
    </>
  );
};

interface AndroidOSPreviewProps {
  files: any[];
  setFiles?: React.Dispatch<React.SetStateAction<any[]>>;
  onLog?: (type: 'info' | 'warn' | 'error', message: string, source: string) => void;
  activeSessionId?: string | null;
}

export const AndroidOSPreview: React.FC<AndroidOSPreviewProps> = ({ files, setFiles, onLog, activeSessionId }) => {
  // Device Core States
  const [isBooted, setIsBooted] = useState(false);
  const [bootProgress, setBootProgress] = useState(0);
  const [isLocked, setIsLocked] = useState(true);
  const [isPowerOff, setIsPowerOff] = useState(false);
  const [currentTime, setCurrentTime] = useState('');
  const [currentDate, setCurrentDate] = useState('');
  
  // OS Shell State
  const [activeApp, setActiveApp] = useState<'home' | 'settings' | 'files' | 'browser' | 'camera' | 'play' | 'playstore' | 'terminal' | 'compose' | 'd3chart' | 'localdb' | 'threejs'>('home');
  const [openAppsHistory, setOpenAppsHistory] = useState<string[]>(['home']);
  const [showRecents, setShowRecents] = useState(false);
  const [showNotificationShade, setShowNotificationShade] = useState(false);
  
  // Real Working Installed Apps States
  const [installedApps, setInstalledApps] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('aether_installed_apps');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // State sync for installed apps
  useEffect(() => {
    localStorage.setItem('aether_installed_apps', JSON.stringify(installedApps));
  }, [installedApps]);

  // Installing progress states
  const [installingApp, setInstallingApp] = useState<string | null>(null);
  const [installProgress, setInstallProgress] = useState(0);

  // App 1: Compose Designer States
  const [composeElements, setComposeElements] = useState<string[]>(['TopBar', 'Card', 'Button']);
  
  // App 2: D3 Vector Chart States
  const [d3ActiveTab, setD3ActiveTab] = useState<'bandwidth' | 'cpu' | 'memory'>('bandwidth');
  const [d3Frequency, setD3Frequency] = useState(1);
  const [d3Thickness, setD3Thickness] = useState(2);
  const [chartData, setChartData] = useState<number[]>(Array.from({ length: 15 }, () => 30 + Math.random() * 40));

  useEffect(() => {
    const timer = setInterval(() => {
      setChartData((prev) => {
        const next = [...prev.slice(1)];
        const multiplier = d3ActiveTab === 'bandwidth' ? 50 : d3ActiveTab === 'cpu' ? 70 : 40;
        const add = Math.sin(Date.now() / (2000 / d3Frequency)) * (multiplier / 2) + multiplier;
        next.push(Math.max(10, Math.min(100, Math.floor(add))));
        return next;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [d3ActiveTab, d3Frequency]);

  // App 3: LocalDB Storage States
  const [localDbEntries, setLocalDbEntries] = useState<{ key: string; val: string }[]>(() => {
    try {
      const saved = localStorage.getItem('aether_simulated_db');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      { key: "sys_version", val: "16.0.4-LTS" },
      { key: "compiler_node", val: "Active (AOSP)" },
      { key: "theme_preference", val: "Aether Orange" },
      { key: "active_vram", val: "6.42 GiB" }
    ];
  });

  useEffect(() => {
    localStorage.setItem('aether_simulated_db', JSON.stringify(localDbEntries));
  }, [localDbEntries]);

  const [dbKeyInput, setDbKeyInput] = useState('');
  const [dbValInput, setDbValInput] = useState('');
  const [dbEditingIndex, setDbEditingIndex] = useState<number | null>(null);

  // App 4: ThreeJS Particle States
  const [particleTheme, setParticleTheme] = useState<'sunset' | 'quantum' | 'matrix' | 'coral'>('sunset');
  const [particleSpeed, setParticleSpeed] = useState(3);
  const [particleCount, setParticleCount] = useState(40);
  const [particleDistance, setParticleDistance] = useState(60);

  // Quick Settings States
  const [wifiOn, setWifiOn] = useState(true);
  const [bluetoothOn, setBluetoothOn] = useState(true);
  const [flashlightOn, setFlashlightOn] = useState(false);
  const [airplaneMode, setAirplaneMode] = useState(false);
  const [brightness, setBrightness] = useState(85);
  const [isSilentMode, setIsSilentMode] = useState(false);
  
  // Hardware States
  const [volume, setVolume] = useState(70);
  const [showVolumeSlider, setShowVolumeSlider] = useState(false);
  let volumeTimer = useRef<any>(null);

  // App Specific States
  const [selectedFile, setSelectedFile] = useState<any>(null);
  const [browserUrl, setBrowserUrl] = useState('https://google.com');
  const [browserInput, setBrowserInput] = useState('https://google.com');
  const [cameraFilter, setCameraFilter] = useState<'none' | 'monochrome' | 'cyberpunk' | 'thermal'>('none');
  const [cameraFlash, setCameraFlash] = useState(false);
  
  // Developer Options (Easter Egg)
  const [buildClicks, setBuildClicks] = useState(0);
  const [isDevUnlocked, setIsDevUnlocked] = useState(false);
  const [showLayoutBounds, setShowLayoutBounds] = useState(false);
  const [animationSpeed, setAnimationSpeed] = useState(1); // multiplier
  const [forceGPURendering, setForceGPURendering] = useState(false);

  // Active Variable / Simulation state inside "Aether Play" Compile App
  const [appCounter, setAppCounter] = useState(0);
  const [compiling, setCompiling] = useState(false);
  const [compileStep, setCompileStep] = useState(0);
  const [runLogs, setRunLogs] = useState<string[]>([]);
  const [themeMode, setThemeMode] = useState<'orange' | 'material'>('orange');
  
  // Real Kotlin Jetpack Compose Compiler States
  const [composeStates, setComposeStates] = useState<Record<string, any>>({});
  const [composeNodes, setComposeNodes] = useState<any[]>([]);
  const [compileError, setCompileError] = useState<string | null>(null);

  // Terminal Emulator States
  const [terminalLogs, setTerminalLogs] = useState<{ text: string, type: 'input' | 'output' | 'error' | 'success' | 'ascii' }[]>([
    { text: "Aether OS Terminal Simulator v1.0.0", type: 'success' },
    { text: "Type 'help' or select a preset command below to begin.", type: 'output' },
  ]);
  const [terminalInput, setTerminalInput] = useState('');
  const terminalEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll terminal to bottom
  useEffect(() => {
    if (terminalEndRef.current) {
      terminalEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [terminalLogs]);

  // Toasts
  const [toast, setToast] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  };

  // Real time updates
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }));
      setCurrentDate(now.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Simulated Boot Sequence
  useEffect(() => {
    if (isBooted) return;
    const timer = setInterval(() => {
      setBootProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setIsBooted(true);
          if (onLog) onLog('info', 'Android Kernel AOSP-Aether booted successfully.', 'SYSTEM');
          return 100;
        }
        return prev + 8;
      });
    }, 150);
    return () => clearInterval(timer);
  }, [isBooted]);

  const handleVolumeChange = (increase: boolean) => {
    setVolume((prev) => {
      const next = increase ? Math.min(prev + 10, 100) : Math.max(prev - 10, 0);
      if (onLog) onLog('info', `Volume adjusted to ${next}%`, 'DEVICE');
      return next;
    });
    setShowVolumeSlider(true);
    if (volumeTimer.current) clearTimeout(volumeTimer.current);
    volumeTimer.current = setTimeout(() => setShowVolumeSlider(false), 2000);
  };

  const navigateToApp = (appName: any) => {
    if (appName !== activeApp) {
      setActiveApp(appName);
      setOpenAppsHistory((prev) => [...prev.filter(a => a !== appName), appName]);
    }
    setShowRecents(false);
    setShowNotificationShade(false);
  };

  const handleBack = () => {
    if (showRecents) {
      setShowRecents(false);
      return;
    }
    if (showNotificationShade) {
      setShowNotificationShade(false);
      return;
    }
    if (openAppsHistory.length > 1) {
      const history = [...openAppsHistory];
      history.pop(); // remove current app
      const prevApp = history[history.length - 1];
      setActiveApp(prevApp as any);
      setOpenAppsHistory(history);
    } else {
      setActiveApp('home');
    }
  };

  const handleHomeButton = () => {
    setActiveApp('home');
    setShowRecents(false);
    setShowNotificationShade(false);
  };

  const handleRecentsButton = () => {
    setShowRecents(!showRecents);
    setShowNotificationShade(false);
  };

  const closeAppFromRecents = (appName: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const nextHistory = openAppsHistory.filter(a => a !== appName);
    setOpenAppsHistory(nextHistory);
    if (activeApp === appName) {
      setActiveApp(nextHistory.length > 0 ? (nextHistory[nextHistory.length - 1] as any) : 'home');
    }
  };

  const handleBuildClick = () => {
    if (isDevUnlocked) {
      triggerToast("Already in Developer Mode!");
      return;
    }
    const nextClicks = buildClicks + 1;
    setBuildClicks(nextClicks);
    if (nextClicks >= 7) {
      setIsDevUnlocked(true);
      triggerToast("Developer Options Unlocked!");
      if (onLog) onLog('info', 'User unlocked Android Developer Options.', 'SYSTEM');
    } else if (nextClicks > 2) {
      triggerToast(`You are ${7 - nextClicks} steps away from being a developer.`);
    }
  };

  const handleInstallApp = (appId: string) => {
    if (installedApps.includes(appId)) {
      navigateToApp(appId as any);
      return;
    }
    if (installingApp) return;

    setInstallingApp(appId);
    setInstallProgress(0);
    
    let currentProgress = 0;
    const interval = setInterval(() => {
      currentProgress += 20;
      setInstallProgress(currentProgress);
      if (currentProgress >= 100) {
        clearInterval(interval);
        setInstalledApps(prev => [...prev, appId]);
        setInstallingApp(null);
        triggerToast(`Installed to Launcher!`);
        if (onLog) onLog('info', `Installed extension app: ${appId}`, 'PLAYSTORE');
      }
    }, 150);
  };

  const handleTerminalCommand = (commandStr: string) => {
    const trimmed = commandStr.trim();
    if (!trimmed) return;

    // Add input to history
    const nextLogs = [...terminalLogs, { text: `aether@aosp-emul:~$ ${trimmed}`, type: 'input' as const }];

    const args = trimmed.split(' ');
    const command = args[0].toLowerCase();

    let outputLogs: typeof terminalLogs = [];

    switch (command) {
      case 'help':
        outputLogs = [
          { text: "Available System Commands:", type: 'success' },
          { text: "  help        - Displays this assistance menu", type: 'output' },
          { text: "  ls          - Lists compiled program file structures", type: 'output' },
          { text: "  cat [file]  - Outputs the content of a file", type: 'output' },
          { text: "  neofetch    - Renders the beautiful system hardware banner", type: 'output' },
          { text: "  deviceinfo  - Prints hardware status properties", type: 'output' },
          { text: "  logcat      - Pipes the active device execution log", type: 'output' },
          { text: "  theme [opt] - Toggle theme color (orange / material)", type: 'output' },
          { text: "  ping [host] - Measure virtual round-trip latency", type: 'output' },
          { text: "  reboot      - Performs a full system software reset", type: 'output' },
          { text: "  clear       - Flushes the shell window history", type: 'output' },
        ];
        break;

      case 'ls':
        if (files.length === 0) {
          outputLogs = [{ text: "No files available in the active workspace repository.", type: 'error' }];
        } else {
          outputLogs = [
            { text: `Directory listing for /workspace/src:`, type: 'success' },
            ...files.map(f => ({
              text: `  -rw-r--r--   1 root  root   ${f.content ? f.content.length : 124} B  ${f.name}`,
              type: 'output' as const
            }))
          ];
        }
        break;

      case 'cat':
        if (args.length < 2) {
          outputLogs = [{ text: "Error: Missing filename parameter. Usage: cat [filename]", type: 'error' }];
        } else {
          const targetName = args[1].toLowerCase();
          const found = files.find(f => f.name.toLowerCase() === targetName || f.name.toLowerCase().endsWith(targetName));
          if (found) {
            outputLogs = [
              { text: `--- Reading file: ${found.name} ---`, type: 'success' },
              { text: found.content || "// File content is empty", type: 'output' },
            ];
          } else {
            outputLogs = [{ text: `Error: File '${args[1]}' not found in workspace directory.`, type: 'error' }];
          }
        }
        break;

      case 'neofetch':
        outputLogs = [
          { text: `      .---.       Aether OS v16.0.4-LTS`, type: 'ascii' },
          { text: `     /     \\      Kernel: Linux 6.1.18-AOSP-Aether`, type: 'ascii' },
          { text: `     \\_.._./      Uptime: ${Math.floor(performance.now() / 60000) + 1} mins`, type: 'ascii' },
          { text: `      |  |        Packages: 1 (AetherApp.apk)`, type: 'ascii' },
          { text: `    .-'  '-.      Shell: bash (Aether Terminal v1.0)`, type: 'ascii' },
          { text: `   /   __   \\     Theme: ${themeMode === 'orange' ? 'Aether Orange' : 'Material You'}`, type: 'ascii' },
          { text: `  |   (  )   |    CPU: Octa-core Google Tensor G4 (simulated)`, type: 'ascii' },
          { text: `   \\   ""   /     Memory: 6.42 GiB / 8.00 GiB (80%)`, type: 'ascii' },
          { text: `    '-....-'      Active Files: ${files.length} mounted nodes`, type: 'ascii' },
        ];
        break;

      case 'deviceinfo':
        outputLogs = [
          { text: `--- HARDWARE METRICS REPORT ---`, type: 'success' },
          { text: `Device Model: Aether Simulator Pixel Pro (v16)`, type: 'output' },
          { text: `Power Source: Lithium-Polymer, 85% charging`, type: 'output' },
          { text: `Network: Wi-Fi: ${wifiOn ? "ENABLED (120 Mbps)" : "DISABLED"} • Bluetooth: ${bluetoothOn ? "ENABLED" : "DISABLED"}`, type: 'output' },
          { text: `Storage: /dev/block/dm-0 (64 GB total, 12 GB free)`, type: 'output' },
          { text: `Developer Mode: ${isDevUnlocked ? "UNLOCKED (ADMIN)" : "LOCKED (Tap build version in Settings 7x)"}`, type: 'output' },
          { text: `Volume: System Level: ${volume}% • Audio State: ${isSilentMode ? "MUTED" : "UNMUTED"}`, type: 'output' },
          { text: `Display: 1440 x 3120, GPU Acceleration: ${forceGPURendering ? "FORCE ACTIVE" : "STANDARD"}`, type: 'output' },
        ];
        break;

      case 'logcat':
        outputLogs = [
          { text: `--- PIPING SYSTEM EVENTS (LOGCAT) ---`, type: 'success' },
          { text: `[00:01:04] [SYSTEM] Initializing Aether Android OS Kernel...`, type: 'output' },
          { text: `[00:01:05] [SYSTEM] Android OS booted successfully.`, type: 'output' },
          { text: `[00:01:05] [SYSTEM] Wi-Fi network registered with SSID "AetherGuest".`, type: 'output' },
          { text: `[00:02:11] [DEVICE] Volume synchronized to default level: ${volume}%`, type: 'output' },
          ...(isDevUnlocked ? [{ text: `[00:03:14] [SYSTEM] Developer Authorization verified and granted.`, type: 'success' as const }] : []),
          ...(compiling ? [{ text: `[00:04:12] [COMPILER] Active Gradle compilation cycle triggered by developer.`, type: 'output' as const }] : []),
          { text: `[LIVE EVENT PIPE TERMINATED SUCCESSFUL]`, type: 'success' }
        ];
        break;

      case 'theme':
        if (args.length < 2) {
          outputLogs = [{ text: "Error: Missing parameter. Usage: theme [orange | material]", type: 'error' }];
        } else {
          const opt = args[1].toLowerCase();
          if (opt === 'orange' || opt === 'material') {
            setThemeMode(opt);
            triggerToast(`Theme set to ${opt === 'orange' ? 'Aether Orange' : 'Material You'}`);
            outputLogs = [{ text: `System Theme Mode changed to [${opt}] successfully.`, type: 'success' }];
          } else {
            outputLogs = [{ text: "Invalid theme option. Use 'orange' or 'material'.", type: 'error' }];
          }
        }
        break;

      case 'ping':
        const host = args[1] || 'google.com';
        outputLogs = [
          { text: `PING ${host} (142.250.190.46) 56(84) bytes of data.`, type: 'output' },
          { text: `64 bytes from ${host}: icmp_seq=1 ttl=116 time=${(10 + Math.random() * 15).toFixed(1)} ms`, type: 'output' },
          { text: `64 bytes from ${host}: icmp_seq=2 ttl=116 time=${(10 + Math.random() * 15).toFixed(1)} ms`, type: 'output' },
          { text: `--- ${host} ping statistics ---`, type: 'success' },
          { text: `2 packets transmitted, 2 received, 0% packet loss, rtt min/avg/max = 10.4/12.8/15.2 ms`, type: 'output' }
        ];
        break;

      case 'reboot':
        setIsBooted(false);
        setBootProgress(0);
        setActiveApp('home');
        triggerToast("Rebooting device...");
        return;

      case 'clear':
        setTerminalLogs([]);
        setTerminalInput('');
        return;

      default:
        outputLogs = [{ text: `bash: ${command}: command not found. Type 'help' for available commands.`, type: 'error' }];
    }

    setTerminalLogs([...nextLogs, ...outputLogs]);
    setTerminalInput('');
  };

  // Scaffold default Kotlin files in workspace
  const handleScaffoldKotlinProject = async () => {
    if (!setFiles) return;
    
    const projectFiles = [
      {
        id: generateId('f'),
        name: 'MainActivity.kt',
        content: `package com.aether.sandbox\n\nimport android.os.Bundle\nimport androidx.activity.ComponentActivity\nimport androidx.activity.compose.setContent\nimport androidx.compose.foundation.layout.*\nimport androidx.compose.material3.*\nimport androidx.compose.runtime.*\nimport androidx.compose.ui.Modifier\nimport androidx.compose.ui.unit.dp\n\nclass MainActivity : ComponentActivity() {\n    override fun onCreate(savedInstanceState: Bundle?) {\n        super.onCreate(savedInstanceState)\n        setContent {\n            MainScreen()\n        }\n    }\n}\n\n@Composable\nfun MainScreen() {\n    var count by remember { mutableStateOf(0) }\n    var text by remember { mutableStateOf("Jetpack Compose!") }\n    var showProgress by remember { mutableStateOf(false) }\n\n    Column(\n        modifier = Modifier.fillMaxSize().padding(16.dp),\n        horizontalAlignment = Alignment.CenterHorizontally\n    ) {\n        // App Header\n        Card(\n            modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp)\n        ) {\n            Column(modifier = Modifier.padding(12.dp)) {\n                Text(\n                    text = "Aether Android Simulator",\n                    style = MaterialTheme.typography.titleMedium\n                )\n                Text(\n                    text = "Live compiled with Jetpack Compose",\n                    style = MaterialTheme.typography.bodySmall\n                )\n            }\n        }\n\n        // Dynamic Greeting\n        Text(\n            text = "Welcome to $text",\n            style = MaterialTheme.typography.headlineMedium\n        )\n        \n        Spacer(modifier = Modifier.height(16.dp))\n\n        // Input field mapping to 'text'\n        TextField(\n            value = text,\n            onValueChange = { text = it },\n            placeholder = "Type to update greeting..."\n        )\n\n        Spacer(modifier = Modifier.height(16.dp))\n\n        // Counter Action\n        Button(\n            onClick = {\n                count++\n                showProgress = true\n            },\n            modifier = Modifier.fillMaxWidth()\n        ) {\n            Text("Clicks: $count")\n        }\n\n        Spacer(modifier = Modifier.height(16.dp))\n\n        // Switch Action\n        Row(\n            modifier = Modifier.fillMaxWidth(),\n            horizontalArrangement = Arrangement.SpaceBetween\n        ) {\n            Text("Show Activity Loader")\n            Switch(\n                checked = showProgress,\n                onCheckedChange = { showProgress = it }\n            )\n        }\n\n        if (showProgress) {\n            Spacer(modifier = Modifier.height(24.dp))\n            CircularProgressIndicator()\n        }\n    }\n}`,
        language: 'kotlin',
        lastModified: Date.now()
      },
      {
        id: generateId('f'),
        name: 'AndroidManifest.xml',
        content: `<?xml version="1.0" encoding="utf-8"?>\n<manifest xmlns:android="http://schemas.android.com/apk/res/android"\n    package="com.aether.sandbox">\n\n    <application\n        android:allowBackup="true"\n        android:icon="@mipmap/ic_launcher"\n        android:label="AetherApp"\n        android:theme="@style/Theme.AetherSandbox">\n        <activity\n            android:name=".MainActivity"\n            android:exported="true"\n            android:theme="@style/Theme.AetherSandbox.NoActionBar">\n            <intent-filter>\n                <action android:name="android.intent.action.MAIN" />\n                <category android:name="android.intent.category.LAUNCHER" />\n            </intent-filter>\n        </activity>\n    </application>\n</manifest>`,
        language: 'xml',
        lastModified: Date.now()
      },
      {
        id: generateId('f'),
        name: 'build.gradle',
        content: `plugins {\n    id 'com.android.application'\n    id 'org.jetbrains.kotlin.android'\n}\n\nandroid {\n    namespace 'com.aether.sandbox'\n    compileSdk 34\n\n    defaultConfig {\n        applicationId "com.aether.sandbox"\n        minSdk 24\n        targetSdk 34\n        versionCode 1\n        versionName "1.0"\n    }\n\n    buildFeatures {\n        compose true\n    }\n\n    composeOptions {\n        kotlinCompilerExtensionVersion '1.5.1'\n    }\n}\n\ndependencies {\n    implementation 'androidx.core:core-ktx:1.12.0'\n    implementation 'androidx.lifecycle:lifecycle-runtime-ktx:2.7.0'\n    implementation 'androidx.activity:activity-compose:1.8.2'\n    implementation platform('androidx.compose:compose-bom:2023.08.0')\n    implementation 'androidx.compose.ui:ui'\n    implementation 'androidx.compose.ui:ui-graphics'\n    implementation 'androidx.compose.ui:ui-tooling-preview'\n    implementation 'androidx.compose.material3:material3'\n}`,
        language: 'groovy',
        lastModified: Date.now()
      }
    ];

    setFiles(projectFiles);

    if (activeSessionId) {
      try {
        const { saveFiles } = await import('../../services/fileService');
        await saveFiles(activeSessionId, projectFiles);
      } catch (err) {
        console.error("Failed to save files:", err);
      }
    }

    triggerToast("Android Compose Project scaffolded!");
    if (onLog) onLog('info', 'Scaffolded complete Kotlin + Jetpack Compose project files.', 'SYSTEM');
  };

  // Safe evaluation and state parsing for Jetpack Compose DSL compiler
  const extractComposableBody = (code: string) => {
    const states: { name: string; value: any }[] = [];
    // Extract var variables
    const stateRegex = /(?:val|var)\s+(\w+)\s+(?:by|=)\s+remember\s*\{\s*mutableStateOf\s*\(([^)]*)\)\s*\}/g;
    let match;
    while ((match = stateRegex.exec(code)) !== null) {
      const name = match[1];
      let valRaw = match[2].trim();
      let value: any = valRaw;
      if (valRaw === 'true') value = true;
      else if (valRaw === 'false') value = false;
      else if (!isNaN(Number(valRaw))) value = Number(valRaw);
      else if (valRaw.startsWith('"') && valRaw.endsWith('"')) value = valRaw.slice(1, -1);
      states.push({ name, value });
    }

    // Find first non-theme @Composable fun
    const funcRegex = /@Composable\s+fun\s+(\w+)\s*\([^)]*\)\s*\{/g;
    let funcMatch;
    let bodyText = "";
    while ((funcMatch = funcRegex.exec(code)) !== null) {
      const funcName = funcMatch[1];
      if (funcName.toLowerCase().includes('theme')) continue;
      
      let index = funcMatch.index + funcMatch[0].length;
      let braceCount = 1;
      let startIdx = index;
      while (braceCount > 0 && index < code.length) {
        const char = code[index];
        if (char === '{') braceCount++;
        else if (char === '}') braceCount--;
        index++;
      }
      bodyText = code.substring(startIdx, index - 1);
      break;
    }

    return { body: bodyText, states };
  };

  const parseModifiers = (argsStr: string) => {
    const modifiers: Record<string, any> = {};
    if (!argsStr) return modifiers;
    
    const match = /modifier\s*=\s*Modifier\s*([^{)]+)/.exec(argsStr);
    if (match) {
      const modifierChain = match[1];
      const segments = modifierChain.split('.');
      segments.forEach(seg => {
        const trimmed = seg.trim();
        if (!trimmed) return;
        
        const parenIdx = trimmed.indexOf('(');
        const name = parenIdx >= 0 ? trimmed.substring(0, parenIdx).trim() : trimmed;
        const params = parenIdx >= 0 ? trimmed.substring(parenIdx + 1, trimmed.length - 1).trim() : "";
        modifiers[name] = params || true;
      });
    }
    return modifiers;
  };

  const parseArgs = (argsStr: string) => {
    const args: Record<string, any> = {};
    if (!argsStr) return args;
    
    const parts: string[] = [];
    let current = "";
    let parenLevel = 0;
    let braceLevel = 0;
    for (let i = 0; i < argsStr.length; i++) {
      const char = argsStr[i];
      if (char === '(') parenLevel++;
      else if (char === ')') parenLevel--;
      else if (char === '{') braceLevel++;
      else if (char === '}') braceLevel--;
      
      if (char === ',' && parenLevel === 0 && braceLevel === 0) {
        parts.push(current);
        current = "";
      } else {
        current += char;
      }
    }
    if (current) parts.push(current);
    
    parts.forEach((part, idx) => {
      const trimmed = part.trim();
      if (!trimmed) return;
      
      if (trimmed.includes('=')) {
        const eqIdx = trimmed.indexOf('=');
        const key = trimmed.substring(0, eqIdx).trim();
        const val = trimmed.substring(eqIdx + 1).trim();
        if (key !== 'modifier') {
          args[key] = val;
        }
      } else if (idx === 0) {
        args['value'] = trimmed;
        args['text'] = trimmed;
      }
    });
    return args;
  };

  const parseComposeBodyToNodes = (code: string): any[] => {
    const nodes: any[] = [];
    let pos = 0;
    
    const skipWhitespace = () => {
      while (pos < code.length && /\s/.test(code[pos])) {
        pos++;
      }
      if (pos < code.length - 1 && code[pos] === '/' && code[pos + 1] === '/') {
        while (pos < code.length && code[pos] !== '\n') {
          pos++;
        }
        skipWhitespace();
      }
    };
    
    const parseIdentifier = () => {
      let start = pos;
      while (pos < code.length && /[a-zA-Z0-9_.]/.test(code[pos])) {
        pos++;
      }
      return code.substring(start, pos);
    };
    
    const parseBalanced = (openChar: string, closeChar: string) => {
      let start = pos;
      let count = 0;
      while (pos < code.length) {
        const char = code[pos];
        if (char === openChar) count++;
        else if (char === closeChar) {
          count--;
          if (count === 0) {
            pos++;
            return code.substring(start + 1, pos - 1);
          }
        }
        pos++;
      }
      return code.substring(start);
    };

    while (pos < code.length) {
      skipWhitespace();
      if (pos >= code.length) break;
      
      const id = parseIdentifier();
      if (!id) {
        pos++;
        continue;
      }
      
      const knownComponents = [
        'Column', 'Row', 'Box', 'Card', 'Button', 'IconButton', 
        'Text', 'Spacer', 'TextField', 'Slider', 'Switch', 
        'CircularProgressIndicator', 'LinearProgressIndicator', 
        'Image', 'Icon', 'Divider', 'HorizontalDivider'
      ];
      
      if (knownComponents.includes(id)) {
        skipWhitespace();
        let argsStr = "";
        if (pos < code.length && code[pos] === '(') {
          argsStr = parseBalanced('(', ')');
        }
        
        skipWhitespace();
        let lambdaBody = "";
        if (pos < code.length && code[pos] === '{') {
          lambdaBody = parseBalanced('{', '}');
        }
        
        nodes.push({
          type: id,
          modifiers: parseModifiers(argsStr),
          args: parseArgs(argsStr),
          children: lambdaBody ? parseComposeBodyToNodes(lambdaBody) : []
        });
      } else if (id === 'if') {
        skipWhitespace();
        let condStr = "";
        if (pos < code.length && code[pos] === '(') {
          condStr = parseBalanced('(', ')');
        }
        skipWhitespace();
        let ifBody = "";
        if (pos < code.length && code[pos] === '{') {
          ifBody = parseBalanced('{', '}');
        }
        
        nodes.push({
          type: 'ConditionIf',
          modifiers: {},
          args: { condition: condStr.trim() },
          children: parseComposeBodyToNodes(ifBody)
        });
      }
    }
    return nodes;
  };

  const handleCompileSequence = () => {
    if (compiling) return;
    setCompiling(true);
    setCompileStep(0);
    setRunLogs([]);
    setCompileError(null);
    
    const steps = [
      "Initializing Aether Android OS SDK v16.0...",
      "Analyzing package definition (AndroidManifest.xml)...",
      "Resolving Kotlin Gradle DSL script constraints...",
      "Compiling Abstract Syntax Trees (AST) for MainActivity.kt...",
      "Injecting Material You & Jetpack Compose dynamic components...",
      "Assembling Dalvik Executable (classes.dex)...",
      "Signing debug application package (app-debug.apk)...",
      "Deploying application binary to target device virtual sandbox...",
      "Application Process Launched [PID: " + Math.floor(Math.random() * 9000 + 1000) + "]"
    ];

    // Read the user's active MainActivity.kt file
    const ktFile = files.find(f => f.name === 'MainActivity.kt' || f.name.endsWith('.kt'));
    
    if (!ktFile) {
      setCompiling(false);
      setCompileError("MainActivity.kt not found in workspace. Press 'Scaffold Project' to initialize a Compose blueprint.");
      if (onLog) onLog('error', 'Compilation failed: MainActivity.kt is missing.', 'COMPILER');
      return;
    }

    const code = ktFile.content || "";

    // Realistic verification validation
    let braceCount = 0;
    let parenCount = 0;
    let errorDetected = false;
    let errorMessage = "";
    
    for (let i = 0; i < code.length; i++) {
      if (code[i] === '{') braceCount++;
      else if (code[i] === '}') braceCount--;
      else if (code[i] === '(') parenCount++;
      else if (code[i] === ')') parenCount--;
      
      if (braceCount < 0 && !errorDetected) {
        errorDetected = true;
        errorMessage = "MainActivity.kt: Compilation Error: Unmatched closing brace '}' detected. Check bracket pairing.";
      }
      if (parenCount < 0 && !errorDetected) {
        errorDetected = true;
        errorMessage = "MainActivity.kt: Compilation Error: Unmatched closing parenthesis ')' detected. Check bracket pairing.";
      }
    }

    if (!errorDetected && braceCount > 0) {
      errorDetected = true;
      errorMessage = `MainActivity.kt: Compilation Error: Mismatched curly braces. ${braceCount} opening brace(s) never closed.`;
    }
    if (!errorDetected && parenCount > 0) {
      errorDetected = true;
      errorMessage = `MainActivity.kt: Compilation Error: Mismatched parentheses. ${parenCount} opening parenthesis never closed.`;
    }

    let current = 0;
    const interval = setInterval(() => {
      if (current < steps.length) {
        // Halt and error out at compile stage if code is syntactically broken!
        if (current === 3 && errorDetected) {
          clearInterval(interval);
          setCompiling(false);
          setCompileError(errorMessage);
          setRunLogs(prev => [
            ...prev,
            `[BUILD] Compiling Abstract Syntax Trees (AST) for MainActivity.kt...`,
            `[BUILD] FAILED: Kotlin compiler aborted with fatal error:`,
            `[BUILD] ${errorMessage}`
          ]);
          if (onLog) onLog('error', errorMessage, 'COMPILER');
          triggerToast("Kotlin Compiler Aborted!");
          return;
        }

        setRunLogs(prev => [...prev, `[BUILD] ${steps[current]}`]);
        setCompileStep(current + 1);
        current++;
      } else {
        clearInterval(interval);
        
        // Transpile successfully
        try {
          const { body, states } = extractComposableBody(code);
          const nodes = parseComposeBodyToNodes(body);
          
          // Set states
          const initialStates: Record<string, any> = {};
          states.forEach(s => {
            initialStates[s.name] = s.value;
          });
          
          setComposeStates(initialStates);
          setComposeNodes(nodes);
          
          setCompiling(false);
          triggerToast("Android App Loaded Successfully!");
          if (onLog) onLog('info', 'Active Android Compose workspace built and running.', 'COMPILER');
        } catch (err: any) {
          clearInterval(interval);
          setCompiling(false);
          setCompileError(`Failed to parse Compose layout tree: ${err.message}`);
          setRunLogs(prev => [...prev, `[BUILD] FAILED: Transpilation engine failed: ${err.message}`]);
          if (onLog) onLog('error', `Compose parser failed: ${err.message}`, 'COMPILER');
        }
      }
    }, 450 * animationSpeed);
  };

  const handleExecuteAction = (actionStr: string) => {
    setComposeStates(prev => {
      const next = { ...prev };
      const cleanAction = actionStr.replace(/[{}]/g, '').trim();
      const statements = cleanAction.split(';').map(s => s.trim()).filter(Boolean);
      
      for (const stmt of statements) {
        if (stmt.endsWith('++')) {
          const v = stmt.slice(0, -2).trim();
          if (v in next) next[v] = Number(next[v]) + 1;
        } else if (stmt.endsWith('--')) {
          const v = stmt.slice(0, -2).trim();
          if (v in next) next[v] = Number(next[v]) - 1;
        } else if (stmt.includes('=')) {
          const eqIdx = stmt.indexOf('=');
          const v = stmt.substring(0, eqIdx).trim();
          const expr = stmt.substring(eqIdx + 1).trim();
          
          if (v in next) {
            if (expr === `!${v}`) {
              next[v] = !next[v];
            } else if (expr === 'true') {
              next[v] = true;
            } else if (expr === 'false') {
              next[v] = false;
            } else if (!isNaN(Number(expr))) {
              next[v] = Number(expr);
            } else if (expr.startsWith('"') && expr.endsWith('"')) {
              next[v] = expr.slice(1, -1);
            }
          }
        }
      }
      return next;
    });
  };

  // Find App details or code structures
  const mainActivityFile = files.find(f => f.name.toLowerCase().includes('activity') || f.name.endsWith('.kt') || f.name.endsWith('.java'));
  const parsedAppName = mainActivityFile ? mainActivityFile.name.split('.')[0].replace('Activity', '') : "AetherApp";

  return (
    <div className={`relative flex items-center justify-center p-2 w-full h-full select-none ${showLayoutBounds ? 'debug-bounds-active' : ''}`}>
      
      {/* Visual Global CSS inject for Layout Bounds */}
      {showLayoutBounds && (
        <style dangerouslySetInnerHTML={{__html: `
          .debug-bounds-active button, 
          .debug-bounds-active span, 
          .debug-bounds-active div, 
          .debug-bounds-active input, 
          .debug-bounds-active p {
            outline: 1px solid #00ffff55 !important;
            outline-offset: -1px;
          }
        `}} />
      )}

      {/* Hardware Device Container */}
      <div className="relative w-[340px] h-[680px] bg-zinc-950 rounded-[42px] border-[14px] border-zinc-900 shadow-[0_30px_100px_rgba(0,0,0,0.9)] flex flex-col overflow-hidden ring-1 ring-white/10 shrink-0">
        
        {/* Sleek Dynamic Island */}
        <motion.div 
          animate={{
            width: compiling ? 240 : toast ? 220 : flashlightOn ? 140 : 110,
            height: (compiling || toast) ? 30 : 24,
            borderRadius: 999
          }}
          transition={{ type: "spring", stiffness: 300, damping: 25 }}
          className="absolute top-2.5 left-1/2 -translate-x-1/2 bg-black z-50 flex items-center justify-between px-3 overflow-hidden shadow-lg border border-white/5"
        >
          {/* Left-side Lens */}
          <div className="w-3.5 h-3.5 rounded-full bg-zinc-900/80 border border-zinc-800/50 flex items-center justify-center shrink-0">
            <div className="w-1.5 h-1.5 rounded-full bg-blue-900/40" />
          </div>
          
          {/* Dynamic Content */}
          <div className="flex-1 px-2 flex items-center justify-center min-w-0">
            <AnimatePresence mode="wait">
              {compiling ? (
                <motion.div 
                  key="compiling"
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="flex items-center gap-1.5 min-w-0"
                >
                  <Loader2 size={10} className="text-orange-500 animate-spin shrink-0" />
                  <span className="text-[8px] font-black tracking-wider text-orange-500 uppercase truncate">
                    Compiling APK...
                  </span>
                </motion.div>
              ) : toast ? (
                <motion.div 
                  key="toast"
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="flex items-center gap-1 min-w-0"
                >
                  <AlertCircle size={9} className="text-orange-500 shrink-0" />
                  <span className="text-[8px] font-bold text-zinc-300 truncate tracking-wide uppercase">
                    {toast}
                  </span>
                </motion.div>
              ) : flashlightOn ? (
                <motion.div 
                  key="torch"
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="flex items-center gap-1 shrink-0"
                >
                  <Flame size={10} className="text-amber-400 fill-amber-400 animate-pulse" />
                  <span className="text-[8px] font-bold text-amber-400 tracking-wider">TORCH ON</span>
                </motion.div>
              ) : (
                <motion.div 
                  key="default"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="w-10 h-1 bg-zinc-900 rounded-full shrink-0"
                />
              )}
            </AnimatePresence>
          </div>

          {/* Right-side status light */}
          <div className="w-1.5 h-1.5 rounded-full bg-zinc-900 shrink-0 flex items-center justify-center">
            {compiling && <div className="w-1 h-1 rounded-full bg-orange-500 animate-ping" />}
            {flashlightOn && !compiling && <div className="w-1 h-1 rounded-full bg-amber-400" />}
          </div>
        </motion.div>

        {/* Dynamic Bezel Glow for Flashlight */}
        <AnimatePresence>
          {flashlightOn && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-50 pointer-events-none border-[12px] border-orange-500/30 blur-[4px]"
            />
          )}
        </AnimatePresence>

        {/* Dynamic Screen Off/Lock/Power Slider Overlay */}
        <AnimatePresence>
          {isPowerOff && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black z-[1000] flex flex-col items-center justify-center gap-4 text-center p-6"
            >
              <div className="w-12 h-12 rounded-full bg-red-500/10 border border-red-500/30 text-red-500 flex items-center justify-center animate-pulse">
                <Power size={22} />
              </div>
              <h4 className="text-sm font-bold tracking-widest text-zinc-300 uppercase">Power Options</h4>
              <button 
                onClick={() => {
                  setIsPowerOff(false);
                  setIsBooted(false);
                  setBootProgress(0);
                }}
                className="px-4 py-2 bg-orange-500 text-black text-[10px] uppercase tracking-widest font-black rounded-xl hover:bg-orange-400 active:scale-95 transition-all mt-6"
              >
                Reboot System
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Simulated System Loader (Android Booting Screen) */}
        {!isBooted && (
          <div className="absolute inset-0 bg-zinc-950 z-[900] flex flex-col items-center justify-center text-white">
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 1 }}
              className="flex flex-col items-center"
            >
              <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-orange-500 to-amber-600 flex items-center justify-center shadow-lg shadow-orange-500/10 mb-8 relative">
                <Sparkles size={32} className="text-black" />
                <span className="absolute -inset-1.5 rounded-[28px] border border-orange-500/30 animate-pulse" />
              </div>
              <h2 className="text-lg font-black tracking-widest text-orange-500 uppercase">AETHER OS</h2>
              <span className="text-[9px] text-zinc-500 tracking-[0.25em] font-mono mt-1">POWERED BY ANDROID</span>
              
              <div className="w-32 h-1 bg-zinc-900 rounded-full overflow-hidden mt-12">
                <motion.div 
                  className="h-full bg-orange-500"
                  style={{ width: `${bootProgress}%` }}
                />
              </div>
              <span className="text-[9px] text-zinc-500 font-mono mt-2">{bootProgress}%</span>
            </motion.div>
          </div>
        )}

        {/* Screen Interface Core */}
        {isBooted && (
          <div className="flex-1 flex flex-col relative bg-zinc-950 text-zinc-200 overflow-hidden">
            
            {/* Always-On Display Mode (AOD) / Lockscreen */}
            <AnimatePresence>
              {isLocked && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 bg-black/95 z-[400] flex flex-col justify-between p-8 pt-20"
                >
                  <div className="text-center space-y-2 mt-4">
                    <h1 className="text-5xl font-light tracking-tight text-orange-500">{currentTime.slice(0, 5)}</h1>
                    <p className="text-xs text-zinc-400 font-medium">{currentDate}</p>
                    
                    <div className="pt-8 flex justify-center">
                      <div className="px-3 py-1 rounded-full bg-zinc-900/80 border border-zinc-800/40 flex items-center gap-1.5 text-zinc-500 text-[9px] font-semibold">
                        <Battery size={10} className="text-orange-500" />
                        <span>85% • Charging</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-col items-center gap-4 mb-10">
                    <motion.button 
                      whileTap={{ scale: 0.9 }}
                      onClick={() => {
                        setIsLocked(false);
                        triggerToast("Device Unlocked");
                      }}
                      className="w-16 h-16 rounded-full bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-500 hover:bg-orange-500/20 active:scale-95 transition-all shadow-xl shadow-orange-500/5 cursor-pointer relative group"
                    >
                      <Unlock size={22} className="group-hover:scale-110 transition-transform" />
                      <span className="absolute -inset-2 rounded-full border border-orange-500/20 animate-ping opacity-40" />
                    </motion.button>
                    <span className="text-[10px] text-zinc-500 tracking-wider font-semibold uppercase">Tap lock to enter</span>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Standard System Status Bar */}
            <div 
              onClick={() => setShowNotificationShade(true)}
              className="h-11 bg-transparent px-6 flex justify-between items-center text-[10px] font-bold tracking-wider select-none shrink-0 z-[250] cursor-pointer"
            >
              <span>{currentTime.slice(0, 5)}</span>
              <div className="flex items-center gap-1.5">
                {airplaneMode ? (
                  <span className="text-[8px] bg-zinc-900 px-1 py-0.5 rounded text-orange-500">AIRPLANE</span>
                ) : (
                  <>
                    <Signal size={11} className={wifiOn ? "text-orange-500" : "text-zinc-600"} />
                    <Wifi size={11} className={wifiOn ? "text-orange-500" : "text-zinc-600"} />
                  </>
                )}
                <Battery size={11} className="text-orange-500" />
              </div>
            </div>

            {/* Simulated Notification Shade (Drawer Panel) */}
            <AnimatePresence>
              {showNotificationShade && (
                <motion.div 
                  initial={{ y: "-100%" }}
                  animate={{ y: 0 }}
                  exit={{ y: "-100%" }}
                  transition={{ type: "spring", damping: 25, stiffness: 220 }}
                  className="absolute inset-x-0 top-0 h-[88%] bg-zinc-950/95 border-b border-zinc-800/80 backdrop-blur-2xl z-[300] flex flex-col p-6 pt-12 text-zinc-200"
                >
                  {/* Pull down handle at bottom */}
                  <div 
                    onClick={() => setShowNotificationShade(false)}
                    className="absolute bottom-2 left-1/2 -translate-x-1/2 w-14 h-1.5 bg-zinc-800 rounded-full cursor-pointer hover:bg-zinc-700 transition-colors"
                  />

                  {/* Header / Date Info */}
                  <div className="flex justify-between items-center mb-6">
                    <div>
                      <h4 className="text-lg font-black tracking-tight text-white">{currentTime.slice(0, 5)}</h4>
                      <p className="text-[10px] text-zinc-500 font-bold uppercase">{currentDate}</p>
                    </div>
                    <button 
                      onClick={() => {
                        setShowNotificationShade(false);
                        navigateToApp('settings');
                      }}
                      className="p-2.5 bg-zinc-900 border border-zinc-800 rounded-xl hover:bg-zinc-800 text-zinc-400 hover:text-white transition-colors"
                    >
                      <Settings size={14} />
                    </button>
                  </div>

                  {/* Quick Settings Grid */}
                  <div className="grid grid-cols-3 gap-3 mb-6">
                    {/* WiFi */}
                    <button 
                      onClick={() => {
                        setWifiOn(!wifiOn);
                        triggerToast(wifiOn ? "Wi-Fi Disconnected" : "Wi-Fi Connected");
                      }}
                      className={`p-3.5 rounded-2xl flex flex-col gap-1.5 text-left border transition-all ${wifiOn ? 'bg-orange-500 border-orange-400 text-black shadow-lg shadow-orange-500/10' : 'bg-zinc-900 border-zinc-800 text-zinc-400'}`}
                    >
                      {wifiOn ? <Wifi size={16} /> : <WifiOff size={16} />}
                      <span className="text-[10px] font-bold">Wi-Fi</span>
                    </button>

                    {/* Flashlight */}
                    <button 
                      onClick={() => setFlashlightOn(!flashlightOn)}
                      className={`p-3.5 rounded-2xl flex flex-col gap-1.5 text-left border transition-all ${flashlightOn ? 'bg-orange-500 border-orange-400 text-black shadow-lg shadow-orange-500/10' : 'bg-zinc-900 border-zinc-800 text-zinc-400'}`}
                    >
                      <Sliders size={16} className={flashlightOn ? "rotate-90 transition-transform" : ""} />
                      <span className="text-[10px] font-bold">Torch</span>
                    </button>

                    {/* Airplane Mode */}
                    <button 
                      onClick={() => {
                        setAirplaneMode(!airplaneMode);
                        triggerToast(airplaneMode ? "Network active" : "Airplane mode on");
                      }}
                      className={`p-3.5 rounded-2xl flex flex-col gap-1.5 text-left border transition-all ${airplaneMode ? 'bg-orange-500 border-orange-400 text-black shadow-lg shadow-orange-500/10' : 'bg-zinc-900 border-zinc-800 text-zinc-400'}`}
                    >
                      <Compass size={16} />
                      <span className="text-[10px] font-bold">Airplane</span>
                    </button>

                    {/* Dark Mode */}
                    <button 
                      onClick={() => {
                        setThemeMode(themeMode === 'orange' ? 'material' : 'orange');
                        triggerToast(`System: ${themeMode === 'orange' ? 'Material You' : 'Aether Core'} Theme`);
                      }}
                      className="p-3.5 rounded-2xl bg-zinc-900 border border-zinc-800 text-zinc-300 flex flex-col gap-1.5 text-left hover:border-zinc-700 transition-all"
                    >
                      {themeMode === 'orange' ? <Sun size={16} className="text-orange-500" /> : <Moon size={16} className="text-zinc-400" />}
                      <span className="text-[10px] font-bold">Theme</span>
                    </button>

                    {/* Silent Mode */}
                    <button 
                      onClick={() => {
                        setIsSilentMode(!isSilentMode);
                        triggerToast(isSilentMode ? "Sound Mode Active" : "Silent Mode Active");
                      }}
                      className={`p-3.5 rounded-2xl flex flex-col gap-1.5 text-left border transition-all ${isSilentMode ? 'bg-orange-500 border-orange-400 text-black shadow-lg shadow-orange-500/10' : 'bg-zinc-900 border-zinc-800 text-zinc-400'}`}
                    >
                      {isSilentMode ? <VolumeX size={16} /> : <Volume2 size={16} />}
                      <span className="text-[10px] font-bold">Silent</span>
                    </button>

                    {/* Force GPU Toggle */}
                    <button 
                      onClick={() => {
                        setForceGPURendering(!forceGPURendering);
                        triggerToast(forceGPURendering ? "GPU layout disabled" : "Forced GPU layout enabled");
                      }}
                      className={`p-3.5 rounded-2xl flex flex-col gap-1.5 text-left border transition-all ${forceGPURendering ? 'bg-orange-500 border-orange-400 text-black shadow-lg shadow-orange-500/10' : 'bg-zinc-900 border-zinc-800 text-zinc-400'}`}
                    >
                      <Activity size={16} />
                      <span className="text-[10px] font-bold">High GPU</span>
                    </button>
                  </div>

                  {/* Brightness slider */}
                  <div className="bg-zinc-900 border border-zinc-800/50 rounded-2xl p-4 mb-6">
                    <div className="flex justify-between items-center text-[9px] font-black uppercase text-zinc-500 tracking-wider mb-2">
                      <span>Brightness</span>
                      <span className="text-orange-500">{brightness}%</span>
                    </div>
                    <input 
                      type="range" 
                      min="10" 
                      max="100" 
                      value={brightness}
                      onChange={(e) => setBrightness(parseInt(e.target.value))}
                      className="w-full accent-orange-500 bg-zinc-800 h-1 rounded-full appearance-none outline-none cursor-pointer"
                    />
                  </div>

                  {/* Notifications feed */}
                  <h5 className="text-[9px] font-black uppercase text-zinc-500 tracking-wider mb-2">System Notifications</h5>
                  <div className="flex-1 overflow-y-auto space-y-2 custom-scrollbar">
                    <div className="p-3 bg-zinc-900/80 border border-zinc-800/40 rounded-xl flex items-start gap-3">
                      <div className="p-1.5 bg-orange-500/10 border border-orange-500/20 text-orange-500 rounded-lg shrink-0">
                        <CheckCircle size={14} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h6 className="text-[11px] font-bold text-white leading-none mb-1">Compiler Node Online</h6>
                        <p className="text-[10px] text-zinc-500 leading-tight">AOSP compilation layer successfully registered with current project directory.</p>
                      </div>
                    </div>

                    <div className="p-3 bg-zinc-900/80 border border-zinc-800/40 rounded-xl flex items-start gap-3">
                      <div className="p-1.5 bg-zinc-800 text-zinc-400 rounded-lg shrink-0">
                        <HardDrive size={14} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h6 className="text-[11px] font-bold text-zinc-300 leading-none mb-1">Android Workspace Loaded</h6>
                        <p className="text-[10px] text-zinc-500 leading-tight">{files.length} active workspace files parsed and cached in device partition.</p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Core Application Stage */}
            <div className="flex-1 px-4 overflow-hidden relative flex flex-col bg-zinc-950">
              <AnimatePresence mode="wait">
                {activeApp === 'home' && (
                  <motion.div 
                    key="home"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="flex-1 flex flex-col justify-between py-6 pb-20 relative"
                  >
                    {/* Aesthetic Clock Display */}
                    <div className="text-center mt-6 space-y-1">
                      <h2 className="text-4xl font-light tracking-tight text-white font-display">{currentTime.slice(0, 5)}</h2>
                      <p className="text-[10px] text-orange-500 tracking-wider uppercase font-bold">{currentDate}</p>
                    </div>

                    {/* Active Variables Info / Live Quick Stat */}
                    <div 
                      onClick={() => navigateToApp('play')}
                      className="mx-2 p-3.5 bg-zinc-900/80 border border-orange-500/10 hover:border-orange-500/30 rounded-2xl cursor-pointer flex justify-between items-center gap-3 transition-all duration-300 hover:bg-zinc-900 hover:scale-[1.02] shadow-xl group"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-500 group-hover:scale-110 transition-transform">
                          <Play size={16} />
                        </div>
                        <div>
                          <span className="text-[9px] font-black uppercase text-orange-500 tracking-widest block mb-0.5">ACTIVE PROJECT RUN</span>
                          <span className="text-xs font-bold text-white truncate">{parsedAppName || "AetherApp"}</span>
                        </div>
                      </div>
                      <ChevronRight size={16} className="text-zinc-500 group-hover:text-white transition-colors" />
                    </div>

                    {/* Launcher App Grid (2x4) */}
                    <div className="grid grid-cols-4 gap-x-2 gap-y-6 px-1 my-6">
                      
                      {/* Play Aether (Real project runner) */}
                      <div onClick={() => navigateToApp('play')} className="flex flex-col items-center gap-2 cursor-pointer group">
                        <div className="w-13 h-13 rounded-2xl bg-orange-500 text-black flex items-center justify-center shadow-lg shadow-orange-500/20 border border-orange-400 group-hover:scale-110 transition-transform duration-300">
                          <Play size={22} fill="currentColor" />
                        </div>
                        <span className="text-[9px] font-bold text-zinc-300 group-hover:text-white tracking-wide truncate max-w-full">Aether Play</span>
                      </div>

                      {/* Files Manager */}
                      <div onClick={() => navigateToApp('files')} className="flex flex-col items-center gap-2 cursor-pointer group">
                        <div className="w-13 h-13 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 group-hover:border-orange-500/30 flex items-center justify-center text-orange-500 group-hover:scale-110 transition-transform duration-300 shadow-xl">
                          <Folder size={22} fill="currentColor" className="opacity-90" />
                        </div>
                        <span className="text-[9px] font-bold text-zinc-300 group-hover:text-white tracking-wide truncate max-w-full">Files</span>
                      </div>

                      {/* Web Browser */}
                      <div onClick={() => navigateToApp('browser')} className="flex flex-col items-center gap-2 cursor-pointer group">
                        <div className="w-13 h-13 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 group-hover:border-orange-500/30 flex items-center justify-center text-orange-500 group-hover:scale-110 transition-transform duration-300 shadow-xl">
                          <Compass size={22} />
                        </div>
                        <span className="text-[9px] font-bold text-zinc-300 group-hover:text-white tracking-wide truncate max-w-full">Chrome</span>
                      </div>

                      {/* Camera */}
                      <div onClick={() => navigateToApp('camera')} className="flex flex-col items-center gap-2 cursor-pointer group">
                        <div className="w-13 h-13 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 group-hover:border-orange-500/30 flex items-center justify-center text-orange-500 group-hover:scale-110 transition-transform duration-300 shadow-xl">
                          <Camera size={22} />
                        </div>
                        <span className="text-[9px] font-bold text-zinc-300 group-hover:text-white tracking-wide truncate max-w-full">Camera</span>
                      </div>

                      {/* Play Store */}
                      <div onClick={() => navigateToApp('playstore')} className="flex flex-col items-center gap-2 cursor-pointer group">
                        <div className="w-13 h-13 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 group-hover:border-orange-500/30 flex items-center justify-center text-orange-500 group-hover:scale-110 transition-transform duration-300 shadow-xl">
                          <ShoppingBag size={22} />
                        </div>
                        <span className="text-[9px] font-bold text-zinc-300 group-hover:text-white tracking-wide truncate max-w-full">Play Store</span>
                      </div>

                      {/* Settings */}
                      <div onClick={() => navigateToApp('settings')} className="flex flex-col items-center gap-2 cursor-pointer group">
                        <div className="w-13 h-13 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 group-hover:border-orange-500/30 flex items-center justify-center text-orange-500 group-hover:scale-110 transition-transform duration-300 shadow-xl">
                          <Settings size={22} />
                        </div>
                        <span className="text-[9px] font-bold text-zinc-300 group-hover:text-white tracking-wide truncate max-w-full">Settings</span>
                      </div>

                      {/* Aether Shell/Terminal */}
                      <div onClick={() => navigateToApp('terminal')} className="flex flex-col items-center gap-2 cursor-pointer group">
                        <div className="w-13 h-13 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 group-hover:border-orange-500/30 flex items-center justify-center text-orange-500 group-hover:scale-110 transition-transform duration-300 shadow-xl">
                          <Terminal size={22} />
                        </div>
                        <span className="text-[9px] font-bold text-zinc-300 group-hover:text-white tracking-wide truncate max-w-full">Shell</span>
                      </div>

                      {/* Dynamic Installed Apps */}
                      {installedApps.includes('compose') && (
                        <div onClick={() => navigateToApp('compose')} className="flex flex-col items-center gap-2 cursor-pointer group">
                          <div className="w-13 h-13 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 group-hover:border-orange-500/30 flex items-center justify-center text-orange-500 group-hover:scale-110 transition-transform duration-300 shadow-xl">
                            <Sliders size={22} />
                          </div>
                          <span className="text-[9px] font-bold text-zinc-300 group-hover:text-white tracking-wide truncate max-w-full">Compose</span>
                        </div>
                      )}

                      {installedApps.includes('d3chart') && (
                        <div onClick={() => navigateToApp('d3chart')} className="flex flex-col items-center gap-2 cursor-pointer group">
                          <div className="w-13 h-13 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 group-hover:border-orange-500/30 flex items-center justify-center text-orange-500 group-hover:scale-110 transition-transform duration-300 shadow-xl">
                            <Activity size={22} />
                          </div>
                          <span className="text-[9px] font-bold text-zinc-300 group-hover:text-white tracking-wide truncate max-w-full">Telemetry</span>
                        </div>
                      )}

                      {installedApps.includes('localdb') && (
                        <div onClick={() => navigateToApp('localdb')} className="flex flex-col items-center gap-2 cursor-pointer group">
                          <div className="w-13 h-13 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 group-hover:border-orange-500/30 flex items-center justify-center text-orange-500 group-hover:scale-110 transition-transform duration-300 shadow-xl">
                            <HardDrive size={22} />
                          </div>
                          <span className="text-[9px] font-bold text-zinc-300 group-hover:text-white tracking-wide truncate max-w-full">LocalDB</span>
                        </div>
                      )}

                      {installedApps.includes('threejs') && (
                        <div onClick={() => navigateToApp('threejs')} className="flex flex-col items-center gap-2 cursor-pointer group">
                          <div className="w-13 h-13 rounded-2xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 group-hover:border-orange-500/30 flex items-center justify-center text-orange-500 group-hover:scale-110 transition-transform duration-300 shadow-xl">
                            <Sparkles size={22} />
                          </div>
                          <span className="text-[9px] font-bold text-zinc-300 group-hover:text-white tracking-wide truncate max-w-full">Physics FX</span>
                        </div>
                      )}

                    </div>
                  </motion.div>
                )}

                {/* APP: SETTINGS */}
                {activeApp === 'settings' && (
                  <motion.div 
                    key="settings"
                    initial={{ x: "100%" }}
                    animate={{ x: 0 }}
                    exit={{ x: "100%" }}
                    className="flex-1 flex flex-col bg-zinc-950 absolute inset-0 py-4 pb-20 overflow-y-auto custom-scrollbar text-zinc-200"
                  >
                    <div className="flex items-center gap-3 mb-6">
                      <button onClick={handleBack} className="p-1.5 hover:bg-zinc-900 rounded-xl text-zinc-400 hover:text-white transition-colors">
                        <ArrowLeft size={18} />
                      </button>
                      <h3 className="text-sm font-black tracking-widest uppercase">Android Settings</h3>
                    </div>

                    <div className="space-y-4">
                      {/* Section: Display */}
                      <div className="bg-zinc-900/60 border border-zinc-800/40 rounded-2xl p-4">
                        <h4 className="text-[9px] font-black uppercase text-zinc-500 tracking-wider mb-3">Display & Aesthetic</h4>
                        
                        <div className="flex justify-between items-center py-2.5 border-b border-zinc-800/60">
                          <span className="text-xs font-bold">Theme</span>
                          <button 
                            onClick={() => setThemeMode(themeMode === 'orange' ? 'material' : 'orange')}
                            className="text-[10px] font-black uppercase px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 hover:text-white border border-zinc-700/60 text-orange-400 rounded-lg transition-colors"
                          >
                            {themeMode === 'orange' ? 'Orange & Black' : 'Material You'}
                          </button>
                        </div>

                        <div className="flex justify-between items-center py-2.5">
                          <span className="text-xs font-bold">Screen Lock</span>
                          <button 
                            onClick={() => {
                              setIsLocked(true);
                              triggerToast("Device Locked");
                            }}
                            className="p-1.5 bg-zinc-800 hover:bg-zinc-700 rounded-lg text-zinc-400 hover:text-white transition-all flex items-center gap-1 text-[9px] font-bold uppercase tracking-wider"
                          >
                            <Lock size={11} /> Lock Screen
                          </button>
                        </div>
                      </div>

                      {/* Section: System info */}
                      <div className="bg-zinc-900/60 border border-zinc-800/40 rounded-2xl p-4">
                        <h4 className="text-[9px] font-black uppercase text-zinc-500 tracking-wider mb-3">System & Device</h4>
                        
                        <div className="flex justify-between items-center py-2.5 border-b border-zinc-800/60">
                          <span className="text-xs font-bold">OS Version</span>
                          <span className="text-xs font-mono text-zinc-500">Aether-AOSP v16.0</span>
                        </div>

                        <div className="flex justify-between items-center py-2.5 border-b border-zinc-800/60">
                          <span className="text-xs font-bold">Files Cached</span>
                          <span className="text-xs font-mono text-zinc-500">{files.length} instances</span>
                        </div>

                        {/* EASTER EGG Build number */}
                        <div 
                          onClick={handleBuildClick}
                          className="flex justify-between items-center py-2.5 cursor-pointer hover:bg-zinc-800/30 rounded-lg px-1 transition-all"
                        >
                          <span className="text-xs font-bold">Build Number</span>
                          <span className="text-[10px] font-mono text-zinc-500 bg-zinc-800 px-2 py-0.5 rounded border border-zinc-700/50">AETHER-AOSP-BLACKHOLE</span>
                        </div>
                      </div>

                      {/* Section: Developer Options (unlocked after clicks) */}
                      {isDevUnlocked && (
                        <div className="bg-zinc-900/60 border border-orange-500/20 rounded-2xl p-4 animate-in slide-in-from-bottom duration-300">
                          <h4 className="text-[9px] font-black uppercase text-orange-500 tracking-wider mb-3 flex items-center gap-1.5">
                            <Sliders size={11} /> Developer Options
                          </h4>

                          <div className="flex justify-between items-center py-2.5 border-b border-zinc-800/60">
                            <span className="text-xs font-bold">Show Layout Bounds</span>
                            <button 
                              onClick={() => {
                                setShowLayoutBounds(!showLayoutBounds);
                                triggerToast(showLayoutBounds ? "Layout bounds hidden" : "Layout bounds active");
                              }}
                              className={`text-[9px] font-black uppercase px-2.5 py-1.5 rounded-lg transition-colors border ${showLayoutBounds ? 'bg-orange-500 text-black border-orange-400' : 'bg-zinc-800 text-zinc-400 border-zinc-700'}`}
                            >
                              {showLayoutBounds ? 'Enabled' : 'Disabled'}
                            </button>
                          </div>

                          <div className="flex justify-between items-center py-2.5 border-b border-zinc-800/60">
                            <span className="text-xs font-bold">Force GPU Overlay</span>
                            <button 
                              onClick={() => {
                                setForceGPURendering(!forceGPURendering);
                                triggerToast(forceGPURendering ? "GPU layout overlay disabled" : "Forced GPU layout enabled");
                              }}
                              className={`text-[9px] font-black uppercase px-2.5 py-1.5 rounded-lg transition-colors border ${forceGPURendering ? 'bg-orange-500 text-black border-orange-400' : 'bg-zinc-800 text-zinc-400 border-zinc-700'}`}
                            >
                              {forceGPURendering ? 'Force' : 'Default'}
                            </button>
                          </div>

                          <div className="flex justify-between items-center py-2.5">
                            <div className="flex flex-col">
                              <span className="text-xs font-bold">Animation Scale</span>
                              <span className="text-[9px] text-zinc-500">Framer Motion speed</span>
                            </div>
                            <select 
                              value={animationSpeed} 
                              onChange={(e) => {
                                setAnimationSpeed(parseFloat(e.target.value));
                                triggerToast(`Scale set to ${e.target.value}x`);
                              }}
                              className="bg-zinc-800 border border-zinc-700 rounded-lg text-xs font-bold px-2 py-1 outline-none text-orange-500 cursor-pointer"
                            >
                              <option value="0.5">0.5x (Fast)</option>
                              <option value="1">1.0x (Normal)</option>
                              <option value="2">2.0x (Slow)</option>
                            </select>
                          </div>
                        </div>
                      )}

                      <button 
                        onClick={() => {
                          setIsBooted(false);
                          setBootProgress(0);
                        }}
                        className="w-full py-3 border border-dashed border-red-500/20 hover:border-red-500/40 hover:bg-red-500/5 text-red-400 font-bold uppercase tracking-widest text-[9px] rounded-xl transition-all"
                      >
                        Perform Soft Reset
                      </button>
                    </div>
                  </motion.div>
                )}

                {/* APP: FILES (Workspace manager) */}
                {activeApp === 'files' && (
                  <motion.div 
                    key="files"
                    initial={{ x: "100%" }}
                    animate={{ x: 0 }}
                    exit={{ x: "100%" }}
                    className="flex-1 flex flex-col bg-zinc-950 absolute inset-0 py-4 pb-20 overflow-hidden text-zinc-200"
                  >
                    <div className="flex items-center gap-3 mb-4 shrink-0">
                      <button onClick={handleBack} className="p-1.5 hover:bg-zinc-900 rounded-xl text-zinc-400 hover:text-white transition-colors">
                        <ArrowLeft size={18} />
                      </button>
                      <h3 className="text-sm font-black tracking-widest uppercase">Files Explorer</h3>
                    </div>

                    {selectedFile ? (
                      // File Content View
                      <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
                        <div className="flex items-center gap-2 pb-2.5 mb-2 border-b border-zinc-800/60 shrink-0">
                          <button onClick={() => setSelectedFile(null)} className="p-1 hover:bg-zinc-900 rounded text-zinc-500 hover:text-white">
                            <ArrowLeft size={14} />
                          </button>
                          <FileCode size={14} className="text-orange-500" />
                          <span className="text-[10px] font-bold font-mono text-white truncate max-w-[180px]">{selectedFile.name}</span>
                        </div>
                        <div className="flex-1 overflow-auto bg-black/50 p-3 rounded-xl border border-zinc-900 text-[9px] font-mono leading-relaxed text-zinc-400">
                          <pre className="whitespace-pre-wrap select-text">{selectedFile.content}</pre>
                        </div>
                      </div>
                    ) : (
                      // Files list
                      <div className="flex-1 overflow-y-auto space-y-2 custom-scrollbar pr-1">
                        <div className="px-1 py-1.5 text-[9px] font-black uppercase text-zinc-500 tracking-wider">Workspace Repository</div>
                        {files.length === 0 ? (
                          <div className="text-center py-12 text-zinc-600 text-xs italic">No workspace files found.</div>
                        ) : (
                          files.map((file) => (
                            <div 
                              key={file.id}
                              onClick={() => setSelectedFile(file)}
                              className="p-3 bg-zinc-900/60 border border-zinc-800/40 hover:border-orange-500/30 rounded-xl flex items-center justify-between cursor-pointer group transition-all"
                            >
                              <div className="flex items-center gap-2.5 min-w-0">
                                <FileCode size={16} className="text-orange-500 group-hover:scale-110 transition-transform" />
                                <span className="text-xs font-bold text-zinc-300 group-hover:text-white font-mono truncate">{file.name}</span>
                              </div>
                              <span className="text-[8px] font-mono bg-zinc-800 text-zinc-500 px-1.5 py-0.5 rounded border border-zinc-700/40 uppercase font-bold shrink-0">{file.language}</span>
                            </div>
                          ))
                        )}
                      </div>
                    )}
                  </motion.div>
                )}

                {/* APP: WEB BROWSER (Chrome Simulator) */}
                {activeApp === 'browser' && (
                  <motion.div 
                    key="browser"
                    initial={{ x: "100%" }}
                    animate={{ x: 0 }}
                    exit={{ x: "100%" }}
                    className="flex-1 flex flex-col bg-zinc-950 absolute inset-0 py-4 pb-20 overflow-hidden text-zinc-200"
                  >
                    {/* URL Bar Search Bar */}
                    <div className="flex items-center gap-2 mb-3 shrink-0">
                      <button onClick={handleBack} className="p-1 hover:bg-zinc-900 rounded">
                        <ArrowLeft size={16} />
                      </button>
                      <form 
                        onSubmit={(e) => {
                          e.preventDefault();
                          setBrowserUrl(browserInput);
                        }}
                        className="flex-1 flex bg-zinc-900 border border-zinc-800 rounded-xl px-2.5 py-1.5 items-center gap-2 focus-within:border-orange-500/50"
                      >
                        <Compass size={12} className="text-zinc-500" />
                        <input 
                          type="text" 
                          value={browserInput}
                          onChange={(e) => setBrowserInput(e.target.value)}
                          className="w-full bg-transparent border-none outline-none text-xs text-white"
                        />
                      </form>
                    </div>

                    {/* Browser Viewport Frame */}
                    <div className="flex-1 bg-zinc-900 rounded-2xl border border-zinc-800 flex flex-col items-center justify-center p-6 text-center">
                      <div className="w-12 h-12 rounded-full bg-orange-500/10 border border-orange-500/20 text-orange-500 flex items-center justify-center mb-4">
                        <Compass size={24} className="animate-spin" style={{ animationDuration: '6s' }} />
                      </div>
                      <h4 className="text-xs font-black uppercase text-zinc-300 tracking-wider">Simulated Chrome</h4>
                      <p className="text-[10px] text-zinc-500 mt-2 leading-relaxed max-w-[200px]">Web container browser environment ready. Viewing {browserUrl}</p>
                      
                      <div className="w-full bg-zinc-950 rounded-xl border border-zinc-800/80 p-4 mt-6 text-left">
                        <span className="text-[8px] font-black uppercase text-orange-500 tracking-widest block mb-2">Workspace Quicklinks</span>
                        <div className="space-y-2">
                          <button onClick={() => { setBrowserUrl('https://google.com'); setBrowserInput('https://google.com'); }} className="w-full py-1.5 bg-zinc-900 hover:bg-zinc-800 text-[10px] text-zinc-300 rounded border border-zinc-800 text-left px-2">Google</button>
                          <button onClick={() => { setBrowserUrl('https://github.com/aether'); setBrowserInput('https://github.com/aether'); }} className="w-full py-1.5 bg-zinc-900 hover:bg-zinc-800 text-[10px] text-zinc-300 rounded border border-zinc-800 text-left px-2">Aether GitHub</button>
                          <button onClick={() => { setBrowserUrl('https://stackoverflow.com'); setBrowserInput('https://stackoverflow.com'); }} className="w-full py-1.5 bg-zinc-900 hover:bg-zinc-800 text-[10px] text-zinc-300 rounded border border-zinc-800 text-left px-2">Stack Overflow</button>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* APP: CAMERA */}
                {activeApp === 'camera' && (
                  <motion.div 
                    key="camera"
                    initial={{ x: "100%" }}
                    animate={{ x: 0 }}
                    exit={{ x: "100%" }}
                    className="flex-1 flex flex-col bg-black absolute inset-0 py-4 pb-20 overflow-hidden text-zinc-200 justify-between"
                  >
                    <div className="flex items-center justify-between px-2 shrink-0">
                      <button onClick={handleBack} className="p-1.5 hover:bg-zinc-900 rounded-xl text-zinc-400 hover:text-white">
                        <ArrowLeft size={18} />
                      </button>
                      <button 
                        onClick={() => {
                          setCameraFlash(!cameraFlash);
                          triggerToast(cameraFlash ? "Flash Off" : "Flash Auto");
                        }}
                        className={`p-1.5 rounded-lg border ${cameraFlash ? 'border-orange-500 text-orange-500' : 'border-transparent text-zinc-400'}`}
                      >
                        <Flame size={16} />
                      </button>
                    </div>

                    {/* Camera view screen */}
                    <div className="flex-1 bg-zinc-950 my-3 rounded-2xl border border-zinc-800 overflow-hidden relative flex flex-col items-center justify-center">
                      {/* Active Grid Lines */}
                      <div className="absolute inset-0 grid grid-cols-3 grid-rows-3 pointer-events-none">
                        <div className="border-r border-b border-white/5" />
                        <div className="border-r border-b border-white/5" />
                        <div className="border-b border-white/5" />
                        <div className="border-r border-b border-white/5" />
                        <div className="border-r border-b border-white/5" />
                        <div className="border-b border-white/5" />
                        <div className="border-r border-white/5" />
                        <div className="border-r border-white/5" />
                        <div />
                      </div>

                      {/* Moving Scan-lines */}
                      <div className="absolute inset-x-0 h-0.5 bg-orange-500/25 top-1/4 animate-bounce z-10" style={{ animationDuration: '4s' }} />

                      {/* Center Focus Box */}
                      <div className="w-14 h-14 border border-dashed border-orange-500/40 rounded-lg animate-pulse flex items-center justify-center relative z-10">
                        <div className="w-1 h-1 bg-orange-500 rounded-full" />
                      </div>

                      {/* Video feed mock background */}
                      <img 
                        src={`https://picsum.photos/seed/aethercamera/300/400`} 
                        alt="Camera Viewport"
                        referrerPolicy="no-referrer"
                        className={`absolute inset-0 w-full h-full object-cover transition-all ${
                          cameraFilter === 'monochrome' ? 'grayscale' : 
                          cameraFilter === 'cyberpunk' ? 'hue-rotate-180 saturate-150 border-orange-500/20' : 
                          cameraFilter === 'thermal' ? 'invert hue-rotate-90 saturate-200' : ''
                        }`}
                      />

                      <div className="absolute bottom-3 left-3 bg-black/60 border border-zinc-800/80 px-2 py-1 rounded-md text-[8px] text-white/60 font-mono tracking-widest uppercase z-10">
                        ISO {100 + Math.floor(Math.random() * 200)} • 60 FPS
                      </div>
                    </div>

                    {/* Footer Controls */}
                    <div className="flex flex-col gap-4 items-center shrink-0">
                      {/* Filter Slider */}
                      <div className="flex gap-2 p-1 bg-zinc-900 border border-zinc-800 rounded-xl text-[8px] font-black uppercase">
                        {['none', 'monochrome', 'cyberpunk', 'thermal'].map((f) => (
                          <button 
                            key={f}
                            onClick={() => setCameraFilter(f as any)}
                            className={`px-2.5 py-1 rounded-md transition-all ${cameraFilter === f ? 'bg-orange-500 text-black font-black' : 'text-zinc-500'}`}
                          >
                            {f}
                          </button>
                        ))}
                      </div>

                      {/* Capture Trigger */}
                      <div className="flex items-center gap-8 pb-3">
                        <div className="w-8 h-8 rounded-full border border-zinc-800 bg-zinc-900/60" />
                        <button 
                          onClick={() => {
                            triggerToast("Photo captured!");
                            if (onLog) onLog('info', 'Photo captured by virtual camera sandbox.', 'SYSTEM');
                          }}
                          className="w-14 h-14 bg-white hover:bg-zinc-200 rounded-full border-4 border-zinc-800 active:scale-90 transition-transform cursor-pointer"
                        />
                        <div className="w-8 h-8 rounded-full border border-zinc-800 bg-zinc-900/60" />
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* APP: PLAY STORE */}
                {activeApp === 'playstore' && (
                  <motion.div 
                    key="playstore"
                    initial={{ x: "100%" }}
                    animate={{ x: 0 }}
                    exit={{ x: "100%" }}
                    className="flex-1 flex flex-col bg-zinc-950 absolute inset-0 py-4 pb-20 overflow-y-auto custom-scrollbar text-zinc-200"
                  >
                    <div className="flex items-center gap-3 mb-4 shrink-0">
                      <button onClick={handleBack} className="p-1.5 hover:bg-zinc-900 rounded-xl text-zinc-400 hover:text-white transition-colors">
                        <ArrowLeft size={18} />
                      </button>
                      <h3 className="text-sm font-black tracking-widest uppercase">Aether Play Store</h3>
                    </div>

                    <div className="space-y-4">
                      {/* Banner */}
                      <div className="p-4 bg-gradient-to-tr from-orange-500 to-amber-600 text-black rounded-2xl shadow-xl shadow-orange-500/10 flex flex-col justify-end min-h-[90px]">
                        <span className="text-[8px] font-black uppercase tracking-widest opacity-80">Featured Extension</span>
                        <h4 className="text-base font-black leading-tight uppercase">Quantum Compiler v2.0</h4>
                      </div>

                      {/* Developer utilities list */}
                      <h5 className="text-[9px] font-black uppercase tracking-wider text-zinc-500">Essential Developer Toolkits</h5>
                      
                      {['Aether Compose Designer', 'D3 Vector Chart Library', 'LocalDB Storage Engine', 'ThreeJS Particle FX'].map((app, idx) => {
                        const appId = idx === 0 ? 'compose' : idx === 1 ? 'd3chart' : idx === 2 ? 'localdb' : 'threejs';
                        const isInstalled = installedApps.includes(appId);
                        const isInstalling = installingApp === appId;

                        return (
                          <div key={app} className="p-3 bg-zinc-900/60 border border-zinc-800/40 rounded-2xl flex items-center justify-between">
                            <div className="flex items-center gap-3 min-w-0">
                              <div className="w-9 h-9 rounded-xl bg-orange-500/10 border border-orange-500/20 text-orange-500 flex items-center justify-center shrink-0">
                                {idx === 0 && <Sliders size={16} />}
                                {idx === 1 && <Activity size={16} />}
                                {idx === 2 && <HardDrive size={16} />}
                                {idx === 3 && <Sparkles size={16} />}
                              </div>
                              <div className="min-w-0">
                                <h6 className="text-[11px] font-bold text-white truncate leading-none mb-1">{app}</h6>
                                <p className="text-[9px] text-zinc-500">
                                  {isInstalled ? "Extension is fully active." : isInstalling ? `Installing... ${installProgress}%` : "Tap to download & install."}
                                </p>
                              </div>
                            </div>
                            <button 
                              onClick={() => handleInstallApp(appId)}
                              disabled={installingApp !== null && !isInstalling}
                              className={`px-2.5 py-1.5 rounded-lg text-[8px] font-black uppercase tracking-widest transition-all shrink-0 border ${
                                isInstalled 
                                  ? 'bg-zinc-900 border-zinc-800 text-orange-500 hover:bg-orange-500 hover:text-black hover:border-orange-400' 
                                  : isInstalling 
                                    ? 'bg-zinc-900 border-orange-500/30 text-orange-400 animate-pulse' 
                                    : 'bg-zinc-800 hover:bg-orange-500 hover:text-black border-zinc-700/60 text-zinc-200'
                              } disabled:opacity-30`}
                            >
                              {isInstalled ? "Open" : isInstalling ? `${installProgress}%` : "Get"}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </motion.div>
                )}

                {/* APP: PLAY (Aether compile project runner) */}
                {activeApp === 'play' && (
                  <motion.div 
                    key="play"
                    initial={{ x: "100%" }}
                    animate={{ x: 0 }}
                    exit={{ x: "100%" }}
                    className="flex-1 flex flex-col bg-zinc-950 absolute inset-0 py-4 pb-20 overflow-hidden text-zinc-200"
                  >
                    <div className="flex items-center justify-between mb-4 pr-3 shrink-0">
                      <div className="flex items-center gap-3">
                        <button onClick={handleBack} className="p-1.5 hover:bg-zinc-900 rounded-xl text-zinc-400 hover:text-white transition-colors">
                          <ArrowLeft size={18} />
                        </button>
                        <h3 className="text-sm font-black tracking-widest uppercase">Aether Play</h3>
                      </div>
                      <span className="text-[7.5px] font-black uppercase bg-orange-500/10 text-orange-500 border border-orange-500/25 px-2 py-0.5 rounded-full tracking-wider animate-pulse">Jetpack Compose SDK</span>
                    </div>

                    {!files.some(f => f.name.endsWith('.kt')) ? (
                      // Onboarding Scaffolder
                      <div className="flex-1 flex flex-col justify-center items-center text-center p-4">
                        <div className="w-16 h-16 rounded-3xl bg-orange-500/10 border border-orange-500/25 flex items-center justify-center text-orange-500 mb-6 relative shadow-2xl">
                          <Sparkles size={24} className="animate-pulse" />
                        </div>
                        <h4 className="text-xs font-black tracking-widest uppercase text-zinc-200">Scaffold Android Project</h4>
                        <p className="text-[10px] text-zinc-500 leading-relaxed mt-2.5 max-w-[210px]">
                          Create a real Kotlin Jetpack Compose workspace, complete with build configurations, manifest declarations, and states.
                        </p>

                        <button 
                          onClick={handleScaffoldKotlinProject}
                          className="w-full py-3.5 bg-orange-500 text-black font-black uppercase tracking-widest text-[9px] rounded-xl hover:bg-orange-400 active:scale-95 transition-all mt-8 flex items-center justify-center gap-1.5 shadow-lg shadow-orange-500/10 cursor-pointer"
                        >
                          <Plus size={12} /> INITIALIZE COMPOSE PROJECT
                        </button>
                      </div>
                    ) : compileStep < 9 ? (
                      // Compiler Build Screen
                      <div className="flex-1 flex flex-col justify-center items-center text-center p-4 min-h-0">
                        <div className="w-16 h-16 rounded-3xl bg-zinc-900 border border-orange-500/20 flex items-center justify-center text-orange-500 mb-5 relative shadow-2xl">
                          <Activity size={24} className={compiling ? "animate-pulse" : ""} />
                        </div>
                        <h4 className="text-xs font-black tracking-widest uppercase text-zinc-200">Android Compiler</h4>
                        <p className="text-[10px] text-zinc-500 leading-relaxed mt-2 max-w-[210px]">
                          Compile files in the workspace into Dalvik executables and manifest composition nodes.
                        </p>

                        {compileError && (
                          <div className="w-full mt-4 p-3 bg-red-950/25 border border-red-900/40 rounded-xl text-left text-[9px] text-red-400 leading-relaxed font-mono">
                            <span className="font-bold block text-[10px] mb-1">Compilation Aborted:</span>
                            {compileError}
                          </div>
                        )}

                        <button 
                          onClick={handleCompileSequence}
                          disabled={compiling}
                          className="w-full py-3.5 bg-orange-500 text-black font-black uppercase tracking-widest text-[9px] rounded-xl hover:bg-orange-400 active:scale-95 transition-all mt-6 disabled:opacity-50 flex items-center justify-center gap-1.5 shadow-lg shadow-orange-500/10 cursor-pointer"
                        >
                          <Terminal size={12} /> {compiling ? "COMPILING WORKSPACE..." : "COMPILE & RUN COMPOSE"}
                        </button>

                        <div className="w-full mt-4 bg-black/50 border border-zinc-900 rounded-xl p-3 h-32 overflow-y-auto text-left text-[8px] font-mono leading-relaxed text-zinc-500 custom-scrollbar">
                          {runLogs.length === 0 && <span className="italic text-zinc-700">Waiting for compiler instructions...</span>}
                          {runLogs.map((log, idx) => (
                            <div key={idx} className="border-b border-zinc-900/60 pb-0.5 mb-0.5">{log}</div>
                          ))}
                        </div>
                      </div>
                    ) : (
                      // Live Application Sandbox Screen representing the compiled user program!
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="flex-1 flex flex-col min-h-0 bg-zinc-900 rounded-2xl border border-orange-500/20 overflow-hidden relative"
                      >
                        {/* Simulated Application Title Bar */}
                        <div className="px-4 py-3 bg-zinc-950 border-b border-zinc-800/80 flex justify-between items-center shrink-0">
                          <div className="flex items-center gap-2">
                            <div className="w-2.5 h-2.5 rounded-full bg-orange-500 animate-pulse" />
                            <span className="text-[10px] font-bold font-mono tracking-wide text-white">{parsedAppName || "AetherApp"}</span>
                          </div>
                          <button 
                            onClick={() => {
                              setCompileStep(0);
                              setRunLogs([]);
                            }}
                            className="p-1 hover:bg-zinc-800 rounded-md text-zinc-400 hover:text-white transition-colors"
                            title="Recompile Program"
                          >
                            <RefreshCw size={11} />
                          </button>
                        </div>

                        {/* Interactive App content - RENDERED FROM COMPOSE NODES */}
                        <div className="flex-1 overflow-y-auto p-4 custom-scrollbar bg-zinc-950 text-white">
                          <div className="w-full h-full flex flex-col">
                            {composeNodes.length === 0 ? (
                              <div className="flex-1 flex flex-col items-center justify-center opacity-30 text-center gap-2">
                                <Sliders size={20} className="text-zinc-600 animate-pulse" />
                                <span className="text-[8px] font-black uppercase tracking-widest">MainScreen empty</span>
                              </div>
                            ) : (
                              <ComposeRenderer
                                nodes={composeNodes}
                                states={composeStates}
                                onStateChange={(name, value) => {
                                  setComposeStates(prev => ({ ...prev, [name]: value }));
                                }}
                                onExecuteAction={handleExecuteAction}
                              />
                            )}
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </motion.div>
                )}

                {/* APP: TERMINAL (Aether Shell Emulator) */}
                {activeApp === 'terminal' && (
                  <motion.div 
                    key="terminal"
                    initial={{ x: "100%" }}
                    animate={{ x: 0 }}
                    exit={{ x: "100%" }}
                    className="flex-1 flex flex-col bg-zinc-950 absolute inset-0 py-4 pb-20 overflow-hidden text-zinc-200"
                  >
                    {/* Header */}
                    <div className="flex items-center gap-3 mb-2 shrink-0">
                      <button onClick={handleBack} className="p-1.5 hover:bg-zinc-900 rounded-xl text-zinc-400 hover:text-white transition-colors">
                        <ArrowLeft size={18} />
                      </button>
                      <div className="flex items-center gap-2">
                        <Terminal size={14} className="text-orange-500" />
                        <h3 className="text-xs font-black tracking-widest uppercase font-mono">Aether Shell v1.0</h3>
                      </div>
                    </div>

                    {/* Console Output Area */}
                    <div className="flex-1 overflow-y-auto bg-black/70 rounded-2xl border border-zinc-900 p-3.5 font-mono text-[8px] leading-relaxed select-text mb-3 custom-scrollbar flex flex-col gap-1.5">
                      {terminalLogs.map((log, idx) => (
                        <div 
                          key={idx} 
                          className={`whitespace-pre-wrap ${
                            log.type === 'input' ? 'text-zinc-300 font-bold' :
                            log.type === 'success' ? 'text-orange-400 font-bold' :
                            log.type === 'error' ? 'text-red-500 font-semibold' :
                            log.type === 'ascii' ? 'text-zinc-500 leading-none font-bold' :
                            'text-zinc-400'
                          }`}
                        >
                          {log.text}
                        </div>
                      ))}
                      <div ref={terminalEndRef} />
                    </div>

                    {/* Quick Preset Buttons */}
                    <div className="shrink-0 mb-3">
                      <div className="text-[7px] font-black uppercase text-zinc-600 tracking-wider mb-1.5 px-1">Quick Actions</div>
                      <div className="flex gap-1.5 overflow-x-auto pb-1.5 no-scrollbar">
                        {[
                          { label: 'neofetch', cmd: 'neofetch' },
                          { label: 'deviceinfo', cmd: 'deviceinfo' },
                          { label: 'logcat', cmd: 'logcat' },
                          { label: 'ls workspace', cmd: 'ls' },
                          { label: 'reboot system', cmd: 'reboot' },
                          { label: 'clear logs', cmd: 'clear' },
                        ].map((btn) => (
                          <button
                            type="button"
                            key={btn.label}
                            onClick={() => handleTerminalCommand(btn.cmd)}
                            className="px-2 py-1 bg-zinc-900 hover:bg-zinc-800 hover:border-orange-500/20 active:scale-95 text-[7px] text-zinc-400 hover:text-orange-400 font-mono font-bold uppercase tracking-wider rounded-lg border border-zinc-800 shrink-0 transition-all cursor-pointer"
                          >
                            {btn.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Form Input Bar */}
                    <form 
                      onSubmit={(e) => {
                        e.preventDefault();
                        handleTerminalCommand(terminalInput);
                      }}
                      className="flex items-center gap-2 bg-zinc-900 border border-zinc-800 rounded-xl px-3 py-2 shrink-0 focus-within:border-orange-500/30"
                    >
                      <span className="text-[8px] font-bold text-orange-500 font-mono select-none shrink-0">$</span>
                      <input 
                        type="text"
                        value={terminalInput}
                        onChange={(e) => setTerminalInput(e.target.value)}
                        placeholder="Type 'help' or enter commands..."
                        className="flex-1 bg-transparent border-none outline-none text-[9px] font-mono text-zinc-200 placeholder:text-zinc-600 focus:ring-0 p-0"
                      />
                      <button 
                        type="submit" 
                        className="p-1 hover:bg-zinc-800 rounded-md text-zinc-500 hover:text-orange-500 transition-all"
                      >
                        <Send size={11} />
                      </button>
                    </form>
                  </motion.div>
                )}

                {/* APP: COMPOSE (Jetpack Compose Visual Editor) */}
                {activeApp === 'compose' && (
                  <motion.div 
                    key="compose"
                    initial={{ x: "100%" }}
                    animate={{ x: 0 }}
                    exit={{ x: "100%" }}
                    className="flex-1 flex flex-col bg-zinc-950 absolute inset-0 py-4 pb-20 overflow-y-auto custom-scrollbar text-zinc-200"
                  >
                    <div className="flex items-center gap-3 mb-4 shrink-0">
                      <button onClick={handleBack} className="p-1.5 hover:bg-zinc-900 rounded-xl text-zinc-400 hover:text-white transition-colors">
                        <ArrowLeft size={18} />
                      </button>
                      <h3 className="text-sm font-black tracking-widest uppercase">Compose Designer</h3>
                    </div>

                    <div className="space-y-4 pr-1">
                      {/* Control board */}
                      <div className="p-3 bg-zinc-900 border border-zinc-800/80 rounded-2xl">
                        <span className="text-[7px] font-black uppercase tracking-widest text-zinc-500 block mb-2">Palette Toolbox</span>
                        <div className="grid grid-cols-2 gap-2">
                          {[
                            { name: 'TopBar', label: '+ Top App Bar' },
                            { name: 'Card', label: '+ Standard Card' },
                            { name: 'Button', label: '+ Action Button' },
                            { name: 'Text', label: '+ Headline Text' },
                            { name: 'Progress', label: '+ Loader Ring' },
                            { name: 'TextField', label: '+ Input Field' }
                          ].map((item) => (
                            <button
                              key={item.name}
                              type="button"
                              onClick={() => {
                                setComposeElements(prev => [...prev, item.name]);
                                triggerToast(`Added Compose element: ${item.name}`);
                              }}
                              className="px-2 py-1.5 bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 hover:border-orange-500/20 rounded-lg text-[8px] font-bold text-zinc-300 hover:text-white transition-all text-left cursor-pointer"
                            >
                              {item.label}
                            </button>
                          ))}
                        </div>
                        <div className="flex gap-2 mt-3 pt-3 border-t border-zinc-800/60">
                          <button
                            type="button"
                            onClick={() => {
                              setComposeElements([]);
                              triggerToast("Cleared composition layout");
                            }}
                            className="flex-1 py-1 bg-zinc-950 hover:bg-red-950 hover:text-red-400 border border-zinc-800 hover:border-red-900/40 rounded-lg text-[8px] font-black uppercase tracking-wider transition-all cursor-pointer"
                          >
                            Reset Canvas
                          </button>
                        </div>
                      </div>

                      {/* Visual rendering screen */}
                      <div>
                        <span className="text-[7px] font-black uppercase tracking-widest text-zinc-500 block mb-1.5 px-1">Interactive Layout Workspace</span>
                        <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4 min-h-[160px] flex flex-col gap-3 relative overflow-hidden">
                          {composeElements.length === 0 ? (
                            <div className="flex-1 flex flex-col items-center justify-center text-center opacity-35 min-h-[120px] gap-2">
                              <Sliders size={20} className="text-zinc-600 animate-pulse" />
                              <p className="text-[8px] uppercase tracking-wider font-semibold">Canvas Empty. Add layouts above.</p>
                            </div>
                          ) : (
                            composeElements.map((el, i) => (
                              <div key={i} className="group relative">
                                {/* Hover remove button */}
                                <button
                                  type="button"
                                  onClick={() => {
                                    setComposeElements(prev => prev.filter((_, idx) => idx !== i));
                                    triggerToast(`Removed index: ${i}`);
                                  }}
                                  className="absolute -right-1.5 -top-1.5 w-4 h-4 rounded-full bg-red-600 border border-zinc-950 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-20 cursor-pointer"
                                  style={{ fontSize: '7px' }}
                                >
                                  ×
                                </button>

                                {el === 'TopBar' && (
                                  <div className="p-2.5 bg-orange-500/10 border border-orange-500/20 text-orange-500 rounded-xl flex justify-between items-center text-[10px] font-bold shadow-sm shadow-orange-500/5">
                                    <span>Aether Custom Layout</span>
                                    <div className="w-2.5 h-2.5 rounded-full bg-orange-500 animate-pulse" />
                                  </div>
                                )}

                                {el === 'Card' && (
                                  <div className="p-3.5 bg-zinc-950 border border-zinc-850 rounded-xl shadow-lg">
                                    <h4 className="text-[10px] font-bold text-white leading-none mb-1">AOSP System Model</h4>
                                    <p className="text-[8px] text-zinc-500 leading-tight">Interactive compilation module successfully initialized.</p>
                                  </div>
                                )}

                                {el === 'Button' && (
                                  <button type="button" className="w-full py-2 bg-orange-500 hover:bg-orange-400 text-black text-[9px] font-black uppercase tracking-widest rounded-xl transition-all shadow-md shadow-orange-500/10 cursor-pointer">
                                    Confirm Blueprint Action
                                  </button>
                                )}

                                {el === 'Text' && (
                                  <span className="text-xs font-black tracking-tight text-white block my-1">
                                    Compose Neural Sandbox
                                  </span>
                                )}

                                {el === 'Progress' && (
                                  <div className="flex justify-center p-2">
                                    <Loader2 size={20} className="text-orange-500 animate-spin" />
                                  </div>
                                )}

                                {el === 'TextField' && (
                                  <div className="w-full p-2.5 bg-zinc-950 border border-zinc-850 rounded-xl text-[9px] font-semibold text-zinc-500 flex justify-between items-center">
                                    <span>Enter developer metadata...</span>
                                    <Sliders size={10} className="text-zinc-600" />
                                  </div>
                                )}
                              </div>
                            ))
                          )}
                        </div>
                      </div>

                      {/* Code Generator block */}
                      <div>
                        <div className="flex justify-between items-center mb-1.5 px-1">
                          <span className="text-[7px] font-black uppercase tracking-widest text-zinc-500">Auto-Generated Kotlin Source</span>
                          <button
                            type="button"
                            onClick={() => {
                              const kotlinCode = `@Composable\nfun AetherCustomLayout() {\n    Column(\n        modifier = Modifier.fillMaxSize().padding(16.dp),\n        verticalArrangement = Arrangement.spacedBy(12.dp)\n    ) {\n` + composeElements.map(el => {
                                if (el === 'TopBar') return `        TopAppBar(title = { Text("Aether Custom Layout") })`;
                                if (el === 'Card') return `        Card { Column { Text("AOSP System Model") } }`;
                                if (el === 'Button') return `        Button(onClick = {}) { Text("Confirm Blueprint Action") }`;
                                if (el === 'Text') return `        Text("Compose Neural Sandbox", style = MaterialTheme.typography.h6)`;
                                if (el === 'Progress') return `        CircularProgressIndicator()`;
                                if (el === 'TextField') return `        OutlinedTextField(value = "", onValueChange = {})`;
                                return '';
                              }).filter(Boolean).join('\n') + `\n    }\n}`;
                              navigator.clipboard.writeText(kotlinCode);
                              triggerToast("Source code copied!");
                            }}
                            className="text-[7px] font-black uppercase text-orange-500 hover:text-white transition-all cursor-pointer"
                          >
                            Copy Code
                          </button>
                        </div>
                        <div className="p-3 bg-zinc-950 border border-zinc-900 rounded-2xl font-mono text-[7px] text-zinc-400 overflow-x-auto leading-relaxed max-h-48 custom-scrollbar whitespace-pre">
                          <span className="text-zinc-600">@Composable</span>{"\n"}
                          <span className="text-orange-500">fun</span> AetherCustomLayout() {"{\n"}
                          {"    Column(\n        modifier = Modifier.fillMaxSize().padding(16.dp),\n        verticalArrangement = Arrangement.spacedBy(12.dp)\n    ) {\n"}
                          {composeElements.map((el, i) => {
                            if (el === 'TopBar') return `        TopAppBar(title = { Text("Aether Custom Layout") })`;
                            if (el === 'Card') return `        Card { Column { Text("AOSP System Model") } }`;
                            if (el === 'Button') return `        Button(onClick = {}) { Text("Confirm Blueprint Action") }`;
                            if (el === 'Text') return `        Text("Compose Neural Sandbox")`;
                            if (el === 'Progress') return `        CircularProgressIndicator()`;
                            if (el === 'TextField') return `        OutlinedTextField(value = "", onValueChange = {})`;
                            return '';
                          }).filter(Boolean).map((line, idx) => <div key={idx} className="text-zinc-300">{line}</div>)}
                          {"    }\n}"}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* APP: D3CHART (Interactive Telemetry Dashboard) */}
                {activeApp === 'd3chart' && (
                  <motion.div 
                    key="d3chart"
                    initial={{ x: "100%" }}
                    animate={{ x: 0 }}
                    exit={{ x: "100%" }}
                    className="flex-1 flex flex-col bg-zinc-950 absolute inset-0 py-4 pb-20 overflow-y-auto custom-scrollbar text-zinc-200"
                  >
                    <div className="flex items-center gap-3 mb-4 shrink-0">
                      <button onClick={handleBack} className="p-1.5 hover:bg-zinc-900 rounded-xl text-zinc-400 hover:text-white transition-colors">
                        <ArrowLeft size={18} />
                      </button>
                      <h3 className="text-sm font-black tracking-widest uppercase font-mono">System Telemetry</h3>
                    </div>

                    <div className="space-y-4 pr-1">
                      {/* Telemetry Selectors */}
                      <div className="flex gap-1.5 bg-zinc-900 border border-zinc-800 p-1 rounded-xl shrink-0">
                        {[
                          { id: 'bandwidth', label: 'Bandwidth' },
                          { id: 'cpu', label: 'CPU Load' },
                          { id: 'memory', label: 'Memory' }
                        ].map((tab) => (
                          <button
                            key={tab.id}
                            type="button"
                            onClick={() => {
                              setD3ActiveTab(tab.id as any);
                              triggerToast(`Viewing ${tab.label} Stream`);
                            }}
                            className={`flex-1 py-1.5 text-[8px] font-black uppercase rounded-lg transition-all cursor-pointer ${
                              d3ActiveTab === tab.id 
                                ? 'bg-orange-500 text-black font-black shadow-md' 
                                : 'text-zinc-400 hover:bg-zinc-800'
                            }`}
                          >
                            {tab.label}
                          </button>
                        ))}
                      </div>

                      {/* Custom Interactive SVG Line Chart */}
                      <div className="bg-zinc-900/60 border border-zinc-800 rounded-2xl p-4">
                        <div className="flex justify-between items-center text-[8px] font-black uppercase text-zinc-500 tracking-wider mb-3">
                          <span>Live Waveform Monitor</span>
                          <span className="text-orange-500 animate-pulse">● Real-time</span>
                        </div>

                        {/* Interactive Graph Drawing */}
                        <div className="w-full h-40 bg-zinc-950 rounded-xl relative border border-zinc-900 overflow-hidden flex items-end">
                          <svg className="w-full h-full absolute inset-0">
                            {/* Grid Lines */}
                            {[0.25, 0.5, 0.75].map((ratio, idx) => (
                              <line
                                key={idx}
                                x1="0"
                                y1={160 * ratio}
                                x2="100%"
                                y2={160 * ratio}
                                stroke="#1e293b"
                                strokeWidth="0.5"
                                strokeDasharray="4 4"
                              />
                            ))}

                            {/* Render Custom Wave Path */}
                            {chartData.length > 1 && (() => {
                              const points = chartData.map((val, idx) => {
                                const x = (idx / (chartData.length - 1)) * 280; // approximate width
                                const y = 160 - (val / 100) * 130 - 15;
                                return { x, y };
                              });

                              // Construct path strings
                              const pathD = points.reduce((acc, p, i) => 
                                i === 0 ? `M ${p.x} ${p.y}` : `${acc} L ${p.x} ${p.y}`, ""
                              );

                              const areaD = `${pathD} L ${points[points.length - 1].x} 160 L 0 160 Z`;

                              return (
                                <>
                                  {/* Area Gradient under curve */}
                                  <path d={areaD} fill="url(#areaGrad)" />
                                  {/* High-fidelity stroke curve line */}
                                  <path
                                    d={pathD}
                                    fill="none"
                                    stroke="#f97316"
                                    strokeWidth={d3Thickness}
                                    strokeLinecap="round"
                                    strokeLinejoin="round"
                                  />
                                  {/* Interactive dots at nodes */}
                                  {points.map((p, i) => (
                                    <circle
                                      key={i}
                                      cx={p.x}
                                      cy={p.y}
                                      r={3}
                                      fill="#ffffff"
                                      stroke="#ea580c"
                                      strokeWidth="1.5"
                                      className="hover:scale-150 transition-transform cursor-pointer"
                                      onClick={() => triggerToast(`Node ${i + 1}: ${chartData[i]}%`)}
                                    />
                                  ))}
                                  {/* Gradient Definition */}
                                  <defs>
                                    <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                                      <stop offset="0%" stopColor="#ea580c" stopOpacity="0.25" />
                                      <stop offset="100%" stopColor="#ea580c" stopOpacity="0.0" />
                                    </linearGradient>
                                  </defs>
                                </>
                              );
                            })()}
                          </svg>

                          <div className="absolute bottom-2 left-2 text-[7px] font-mono text-zinc-500">
                            Y: Usage Range [0 - 100%]
                          </div>
                          <div className="absolute bottom-2 right-2 text-[7px] font-mono text-zinc-500">
                            X: 15s Window (1Hz)
                          </div>
                        </div>
                      </div>

                      {/* Interactive Controls Board */}
                      <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-2xl space-y-3.5">
                        <span className="text-[7px] font-black uppercase tracking-widest text-zinc-500 block">Signal Modulator Controls</span>
                        
                        <div>
                          <div className="flex justify-between items-center text-[8px] font-black uppercase text-zinc-400 mb-1">
                            <span>Modulation Frequency</span>
                            <span className="text-orange-500">{d3Frequency} Hz</span>
                          </div>
                          <input 
                            type="range" 
                            min="1" 
                            max="5" 
                            value={d3Frequency}
                            onChange={(e) => setD3Frequency(parseInt(e.target.value))}
                            className="w-full accent-orange-500 bg-zinc-800 h-1 rounded-full appearance-none outline-none cursor-pointer"
                          />
                        </div>

                        <div>
                          <div className="flex justify-between items-center text-[8px] font-black uppercase text-zinc-400 mb-1">
                            <span>Path Stroke Thickness</span>
                            <span className="text-orange-500">{d3Thickness} px</span>
                          </div>
                          <input 
                            type="range" 
                            min="1" 
                            max="4" 
                            value={d3Thickness}
                            onChange={(e) => setD3Thickness(parseInt(e.target.value))}
                            className="w-full accent-orange-500 bg-zinc-800 h-1 rounded-full appearance-none outline-none cursor-pointer"
                          />
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* APP: LOCALDB (Stateful Key-Value database explorer) */}
                {activeApp === 'localdb' && (
                  <motion.div 
                    key="localdb"
                    initial={{ x: "100%" }}
                    animate={{ x: 0 }}
                    exit={{ x: "100%" }}
                    className="flex-1 flex flex-col bg-zinc-950 absolute inset-0 py-4 pb-20 overflow-y-auto custom-scrollbar text-zinc-200"
                  >
                    <div className="flex items-center gap-3 mb-4 shrink-0">
                      <button onClick={handleBack} className="p-1.5 hover:bg-zinc-900 rounded-xl text-zinc-400 hover:text-white transition-colors">
                        <ArrowLeft size={18} />
                      </button>
                      <h3 className="text-sm font-black tracking-widest uppercase font-mono font-bold text-orange-500">LocalDB Client</h3>
                    </div>

                    <div className="space-y-4 pr-1">
                      {/* Entry Form */}
                      <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-2xl">
                        <span className="text-[7px] font-black uppercase tracking-widest text-zinc-500 block mb-2">
                          {dbEditingIndex !== null ? "Edit Key-Value Record" : "Insert Key-Value Record"}
                        </span>
                        
                        <div className="space-y-2">
                          <div>
                            <input 
                              type="text" 
                              placeholder="Key Name..." 
                              value={dbKeyInput}
                              onChange={(e) => setDbKeyInput(e.target.value)}
                              disabled={dbEditingIndex !== null}
                              className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded-xl text-[9px] font-mono text-zinc-200 focus:outline-none focus:border-orange-500/30 disabled:opacity-55"
                            />
                          </div>
                          <div>
                            <input 
                              type="text" 
                              placeholder="Value Data..." 
                              value={dbValInput}
                              onChange={(e) => setDbValInput(e.target.value)}
                              className="w-full p-2 bg-zinc-950 border border-zinc-800 rounded-xl text-[9px] font-mono text-zinc-200 focus:outline-none focus:border-orange-500/30"
                            />
                          </div>
                        </div>

                        <div className="flex gap-2 mt-3">
                          <button
                            type="button"
                            onClick={() => {
                              if (!dbKeyInput.trim() || !dbValInput.trim()) {
                                triggerToast("Error: Missing fields");
                                return;
                              }
                              
                              if (dbEditingIndex !== null) {
                                // Update existing
                                setLocalDbEntries(prev => {
                                  const next = [...prev];
                                  next[dbEditingIndex].val = dbValInput;
                                  return next;
                                });
                                triggerToast("Database entry updated!");
                                setDbEditingIndex(null);
                              } else {
                                // Add new
                                const keyExists = localDbEntries.some(e => e.key === dbKeyInput.trim());
                                if (keyExists) {
                                  triggerToast("Error: Key already exists");
                                  return;
                                }
                                setLocalDbEntries(prev => [...prev, { key: dbKeyInput.trim(), val: dbValInput.trim() }]);
                                triggerToast("Database entry inserted!");
                              }

                              setDbKeyInput('');
                              setDbValInput('');
                            }}
                            className="flex-1 py-2 bg-orange-500 hover:bg-orange-400 text-black font-black uppercase tracking-wider text-[8px] rounded-lg shadow transition-all cursor-pointer"
                          >
                            {dbEditingIndex !== null ? "Save Update" : "Insert Record"}
                          </button>

                          {dbEditingIndex !== null && (
                            <button
                              type="button"
                              onClick={() => {
                                setDbKeyInput('');
                                setDbValInput('');
                                setDbEditingIndex(null);
                              }}
                              className="px-3 py-2 bg-zinc-950 hover:bg-zinc-800 border border-zinc-800 rounded-lg text-[8px] font-black uppercase tracking-wider text-zinc-400 hover:text-white cursor-pointer"
                            >
                              Cancel
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Entries Table */}
                      <div>
                        <div className="flex justify-between items-center mb-1.5 px-1">
                          <span className="text-[7px] font-black uppercase tracking-widest text-zinc-500">Active Storage Namespace</span>
                          <button
                            type="button"
                            onClick={() => {
                              setLocalDbEntries([
                                { key: "sys_version", val: "16.0.4-LTS" },
                                { key: "compiler_node", val: "Active (AOSP)" },
                                { key: "theme_preference", val: "Aether Orange" },
                                { key: "active_vram", val: "6.42 GiB" }
                              ]);
                              setDbKeyInput('');
                              setDbValInput('');
                              setDbEditingIndex(null);
                              triggerToast("Database table reset!");
                            }}
                            className="text-[7px] font-black uppercase text-orange-500 hover:text-white transition-all cursor-pointer"
                          >
                            Reset Table
                          </button>
                        </div>

                        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden divide-y divide-zinc-800/60 max-h-56 overflow-y-auto custom-scrollbar">
                          {localDbEntries.length === 0 ? (
                            <div className="p-8 text-center text-[9px] text-zinc-600 font-bold uppercase tracking-wider">
                              No Database records found
                            </div>
                          ) : (
                            localDbEntries.map((entry, idx) => (
                              <div key={entry.key} className="p-3 flex items-center justify-between text-[9px] font-mono">
                                <div className="min-w-0 flex-1 pr-1 pr-1">
                                  <span className="text-orange-500 font-bold block truncate">{entry.key}</span>
                                  <span className="text-zinc-400 block truncate mt-0.5">{entry.val}</span>
                                </div>

                                <div className="flex gap-1.5 shrink-0">
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setDbKeyInput(entry.key);
                                      setDbValInput(entry.val);
                                      setDbEditingIndex(idx);
                                      triggerToast(`Loading Key: ${entry.key}`);
                                    }}
                                    className="px-2 py-1 bg-zinc-950 hover:bg-zinc-800 border border-zinc-850 rounded text-[7px] font-black uppercase tracking-widest text-zinc-400 hover:text-white cursor-pointer"
                                  >
                                    Edit
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setLocalDbEntries(prev => prev.filter(e => e.key !== entry.key));
                                      triggerToast(`Deleted entry: ${entry.key}`);
                                      if (dbEditingIndex === idx) {
                                        setDbKeyInput('');
                                        setDbValInput('');
                                        setDbEditingIndex(null);
                                      }
                                    }}
                                    className="px-2 py-1 bg-zinc-950 hover:bg-red-950 border border-zinc-850 rounded text-[7px] font-black uppercase tracking-widest text-zinc-500 hover:text-red-400 hover:border-red-900/30 cursor-pointer"
                                  >
                                    Delete
                                  </button>
                                </div>
                              </div>
                            ))
                          )}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* APP: THREEJS (Physics Particles Sandbox) */}
                {activeApp === 'threejs' && (
                  <motion.div 
                    key="threejs"
                    initial={{ x: "100%" }}
                    animate={{ x: 0 }}
                    exit={{ x: "100%" }}
                    className="flex-1 flex flex-col bg-zinc-950 absolute inset-0 py-4 pb-20 overflow-y-auto custom-scrollbar text-zinc-200"
                  >
                    <div className="flex items-center gap-3 mb-4 shrink-0">
                      <button onClick={handleBack} className="p-1.5 hover:bg-zinc-900 rounded-xl text-zinc-400 hover:text-white transition-colors">
                        <ArrowLeft size={18} />
                      </button>
                      <h3 className="text-sm font-black tracking-widest uppercase font-mono">Physics Node Arena</h3>
                    </div>

                    <div className="space-y-4 pr-1">
                      {/* Live Canvas Area */}
                      <div>
                        <span className="text-[7px] font-black uppercase tracking-widest text-zinc-500 block mb-1.5 px-1">Constellation Spring Grid</span>
                        <div className="w-full h-44 relative bg-zinc-950 rounded-2xl shadow-inner border border-zinc-900 overflow-hidden shrink-0">
                          <ParticleCanvas 
                            theme={particleTheme}
                            speed={particleSpeed}
                            count={particleCount}
                            maxDist={particleDistance}
                          />
                          <div className="absolute top-2.5 right-2.5 bg-black/60 border border-zinc-800 px-2 py-1 rounded text-[7px] text-zinc-500 uppercase tracking-widest font-bold">
                            Interactive Hover Active
                          </div>
                        </div>
                      </div>

                      {/* Theme Palettes Selector */}
                      <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-2xl">
                        <span className="text-[7px] font-black uppercase tracking-widest text-zinc-500 block mb-2">Color Matrix Mode</span>
                        <div className="grid grid-cols-4 gap-1.5">
                          {[
                            { id: 'sunset', label: 'Sunset' },
                            { id: 'quantum', label: 'Quantum' },
                            { id: 'matrix', label: 'Matrix' },
                            { id: 'coral', label: 'Coral' }
                          ].map((t) => (
                            <button
                              key={t.id}
                              type="button"
                              onClick={() => {
                                setParticleTheme(t.id as any);
                                triggerToast(`Theme loaded: ${t.label}`);
                              }}
                              className={`py-1 rounded text-[8px] font-black uppercase border transition-all cursor-pointer ${
                                particleTheme === t.id 
                                  ? 'bg-orange-500 border-orange-400 text-black' 
                                  : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:text-white'
                              }`}
                            >
                              {t.id}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Arena Modulators Board */}
                      <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-2xl space-y-3.5">
                        <span className="text-[7px] font-black uppercase tracking-widest text-zinc-500 block">Arena Parameter Modulators</span>

                        <div>
                          <div className="flex justify-between items-center text-[8px] font-black uppercase text-zinc-400 mb-1">
                            <span>Kinetic Velocity Multiplier</span>
                            <span className="text-orange-500">{particleSpeed}x</span>
                          </div>
                          <input 
                            type="range" 
                            min="1" 
                            max="6" 
                            value={particleSpeed}
                            onChange={(e) => setParticleSpeed(parseInt(e.target.value))}
                            className="w-full accent-orange-500 bg-zinc-800 h-1 rounded-full appearance-none outline-none cursor-pointer"
                          />
                        </div>

                        <div>
                          <div className="flex justify-between items-center text-[8px] font-black uppercase text-zinc-400 mb-1">
                            <span>Node Count (Density)</span>
                            <span className="text-orange-500">{particleCount} nodes</span>
                          </div>
                          <input 
                            type="range" 
                            min="15" 
                            max="75" 
                            value={particleCount}
                            onChange={(e) => setParticleCount(parseInt(e.target.value))}
                            className="w-full accent-orange-500 bg-zinc-800 h-1 rounded-full appearance-none outline-none cursor-pointer"
                          />
                        </div>

                        <div>
                          <div className="flex justify-between items-center text-[8px] font-black uppercase text-zinc-400 mb-1">
                            <span>Link Spring Reach Distance</span>
                            <span className="text-orange-500">{particleDistance} px</span>
                          </div>
                          <input 
                            type="range" 
                            min="30" 
                            max="100" 
                            value={particleDistance}
                            onChange={(e) => setParticleDistance(parseInt(e.target.value))}
                            className="w-full accent-orange-500 bg-zinc-800 h-1 rounded-full appearance-none outline-none cursor-pointer"
                          />
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Bottom Simulated Toast Banner */}
            <AnimatePresence>
              {toast && (
                <motion.div 
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  exit={{ y: 20, opacity: 0 }}
                  className="absolute bottom-16 left-1/2 -translate-x-1/2 px-4 py-2 bg-zinc-900/90 border border-orange-500/20 text-white rounded-full text-[9px] font-bold tracking-wider uppercase backdrop-blur-md z-[500] shadow-2xl flex items-center gap-1.5"
                >
                  <AlertCircle size={10} className="text-orange-500 animate-pulse" />
                  <span>{toast}</span>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Hardware Side Volume Slider Indicator */}
            <AnimatePresence>
              {showVolumeSlider && (
                <motion.div 
                  initial={{ x: 20, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  exit={{ x: 20, opacity: 0 }}
                  className="absolute right-2.5 top-1/3 w-8 h-28 bg-zinc-900/90 border border-zinc-800/80 backdrop-blur-md rounded-full py-3 flex flex-col items-center justify-between z-[450] shadow-2xl"
                >
                  <span className="text-[8px] font-mono font-bold text-orange-500">{volume}</span>
                  <div className="w-1.5 h-14 bg-zinc-800 rounded-full relative overflow-hidden">
                    <div 
                      className="absolute bottom-0 inset-x-0 bg-orange-500" 
                      style={{ height: `${volume}%` }}
                    />
                  </div>
                  {volume === 0 ? <VolumeX size={10} className="text-zinc-500" /> : <Volume2 size={10} className="text-orange-500" />}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Standard Bottom Android System Navigation Bar */}
            <div className="absolute bottom-0 inset-x-0 h-14 bg-zinc-950/90 border-t border-zinc-900/80 flex items-center justify-around px-8 pb-3 z-[250] backdrop-blur-md">
              <button 
                onClick={handleBack}
                className="p-3 text-zinc-400 hover:text-orange-500 hover:scale-110 active:scale-95 transition-all cursor-pointer"
                title="System Back"
              >
                <ArrowLeft size={16} />
              </button>
              <button 
                onClick={handleHomeButton}
                className="p-3 text-zinc-400 hover:text-orange-500 hover:scale-110 active:scale-95 transition-all cursor-pointer"
                title="System Home"
              >
                <Home size={16} />
              </button>
              <button 
                onClick={handleRecentsButton}
                className="p-3 text-zinc-400 hover:text-orange-500 hover:scale-110 active:scale-95 transition-all cursor-pointer"
                title="System Recents"
              >
                <Sliders size={16} />
              </button>
            </div>

            {/* Simulated Recents Screen (Task deck slider) */}
            <AnimatePresence>
              {showRecents && (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-x-0 top-0 h-[88%] bg-zinc-950/95 backdrop-blur-2xl z-[350] flex flex-col p-6 pt-12 text-zinc-200"
                >
                  <div className="flex justify-between items-center mb-6">
                    <h4 className="text-[10px] font-black uppercase text-zinc-500 tracking-wider">Recent Applications</h4>
                    <button 
                      onClick={() => {
                        setOpenAppsHistory(['home']);
                        setActiveApp('home');
                        setShowRecents(false);
                        triggerToast("All apps closed");
                      }}
                      className="text-[9px] font-black uppercase px-2 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 rounded text-orange-400 hover:text-white transition-all"
                    >
                      Clear All
                    </button>
                  </div>

                  {openAppsHistory.filter(a => a !== 'home').length === 0 ? (
                    <div className="flex-1 flex flex-col items-center justify-center text-center opacity-40 gap-3">
                      <Sliders size={28} className="text-zinc-600 animate-pulse" />
                      <p className="text-[10px] uppercase tracking-wider font-semibold">No recent applications active</p>
                    </div>
                  ) : (
                    <div className="flex-1 overflow-x-auto flex gap-4 items-center px-4 py-8 custom-scrollbar-horizontal">
                      {openAppsHistory.filter(a => a !== 'home').map((app, idx) => (
                        <motion.div 
                          key={app}
                          initial={{ scale: 0.85, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          transition={{ delay: idx * 0.1 }}
                          onClick={() => {
                            setActiveApp(app as any);
                            setShowRecents(false);
                          }}
                          className="w-44 h-72 bg-zinc-900 rounded-3xl border border-zinc-800 hover:border-orange-500/40 p-4 shrink-0 flex flex-col justify-between shadow-2xl relative cursor-pointer group"
                        >
                          <div className="flex justify-between items-center">
                            <span className="text-[10px] font-black uppercase tracking-wider text-zinc-400 group-hover:text-orange-500 transition-colors">{app}</span>
                            <button 
                              onClick={(e) => closeAppFromRecents(app, e)}
                              className="p-1 bg-zinc-800 hover:bg-red-500/10 hover:text-red-400 rounded-lg text-zinc-500 transition-colors"
                            >
                              <Plus className="rotate-45" size={12} />
                            </button>
                          </div>
                          
                          <div className="flex-1 flex items-center justify-center opacity-25">
                            {app === 'settings' && <Settings size={44} />}
                            {app === 'files' && <Folder size={44} />}
                            {app === 'browser' && <Compass size={44} />}
                            {app === 'camera' && <Camera size={44} />}
                            {app === 'play' && <Play size={44} />}
                            {app === 'playstore' && <ShoppingBag size={44} />}
                            {app === 'terminal' && <Terminal size={44} />}
                            {app === 'compose' && <Sliders size={44} />}
                            {app === 'd3chart' && <Activity size={44} />}
                            {app === 'localdb' && <HardDrive size={44} />}
                            {app === 'threejs' && <Sparkles size={44} />}
                          </div>

                          <span className="text-[8px] text-zinc-600 font-mono text-center block">Swipe Up to Close</span>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

          </div>
        )}

      </div>

      {/* Hardware Buttons Side-panel */}
      <div className="flex flex-col gap-3 ml-2 shrink-0">
        <button 
          onClick={() => handleVolumeChange(true)}
          className="w-2.5 h-10 bg-zinc-800 hover:bg-zinc-700 active:bg-orange-500 border border-zinc-700 rounded-full cursor-pointer transition-colors"
          title="Volume Up"
        />
        <button 
          onClick={() => handleVolumeChange(false)}
          className="w-2.5 h-10 bg-zinc-800 hover:bg-zinc-700 active:bg-orange-500 border border-zinc-700 rounded-full cursor-pointer transition-colors"
          title="Volume Down"
        />
        <button 
          onClick={() => {
            if (isLocked) {
              setIsLocked(false);
              triggerToast("Unlocked");
            } else {
              setIsLocked(true);
              triggerToast("Locked");
            }
          }}
          className="w-2.5 h-14 bg-zinc-800 hover:bg-zinc-700 active:bg-orange-500 border border-zinc-700 rounded-full cursor-pointer transition-colors mt-4"
          title="Lock Screen"
        />
        <button 
          onClick={() => setIsPowerOff(!isPowerOff)}
          className="w-2.5 h-6 bg-red-600 hover:bg-red-500 border border-red-800 rounded-full cursor-pointer transition-colors"
          title="Power System"
        />
      </div>

    </div>
  );
};
