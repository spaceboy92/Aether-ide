import React, { useEffect, useState, useRef } from 'react';
import { 
  Loader2, Play, Terminal, AlertCircle, CheckCircle2, 
  Server, RefreshCw, Send, Plus, Trash2, Database, Code, 
  HelpCircle, Sparkles, Smartphone, Power, ShieldCheck, Box,
  Download, Package, Monitor, Maximize2, Focus, Layers, Cpu, Copy
} from 'lucide-react';

interface PythonPreviewProps {
  code: string;
}

interface ConsoleLine {
  type: 'input' | 'output' | 'error' | 'system';
  text: string;
}

interface MockRoute {
  path: string;
  method: string;
  response: string;
}

interface ServerRequestLog {
  timestamp: string;
  method: string;
  url: string;
  status: number;
  response: string;
}

const POPULAR_PYTHON_PACKAGES = [
  { name: 'pygame-ce', category: 'Game Engine', desc: 'Pygame Community Edition 2D game engine with SDL audio & canvas graphics', icon: '🎮' },
  { name: 'numpy', category: 'Data Science', desc: 'Fast multidimensional arrays and matrix mathematics', icon: '🔢' },
  { name: 'pandas', category: 'Data Science', desc: 'High-performance data structures and dataframe analytics', icon: '📊' },
  { name: 'matplotlib', category: 'Visualization', desc: 'Publication-quality plotting and interactive graphs', icon: '📈' },
  { name: 'scipy', category: 'Scientific', desc: 'Scientific algorithms, signal processing, and numerical optimization', icon: '🔬' },
  { name: 'scikit-learn', category: 'Machine Learning', desc: 'Machine learning models, classification, and regression', icon: '🧠' },
  { name: 'pillow', category: 'Image Processing', desc: 'Python Imaging Library for image manipulation', icon: '🖼️' },
  { name: 'requests', category: 'Networking', desc: 'HTTP requests library for REST APIs and web fetching', icon: '🌐' },
  { name: 'sympy', category: 'Mathematics', desc: 'Symbolic mathematics and computer algebra system', icon: '🧮' },
  { name: 'beautifulsoup4', category: 'Web Scraping', desc: 'Parsing HTML and XML documents', icon: '📝' },
];

const INTERACTIVE_INPUT_PYTHON_PATCH = `
import builtins
import sys
import js
import asyncio

async def _aether_async_input(prompt=""):
    p_str = str(prompt) if prompt is not None else ""
    if p_str:
        sys.stdout.write(p_str)
        sys.stdout.flush()
    fut = asyncio.get_event_loop().create_future()
    def _cb(val):
        if not fut.done():
            fut.set_result(str(val))
    js.window.__AETHER_INPUT_CB__ = _cb
    user_val = await fut
    sys.stdout.write(str(user_val) + "\n")
    sys.stdout.flush()
    return str(user_val)

builtins.input = _aether_async_input
`;

const AETHER_AST_TRANSFORMER = `
import ast
import js
import sys
import asyncio

class _AetherLoopTransformer(ast.NodeTransformer):
    def __init__(self):
        self.async_funcs = set()

    def visit_While(self, node):
        self.generic_visit(node)
        cancel_if = ast.If(
            test=ast.Call(
                func=ast.Name(id='getattr', ctx=ast.Load()),
                args=[
                    ast.Attribute(value=ast.Name(id='js', ctx=ast.Load()), attr='window', ctx=ast.Load()),
                    ast.Constant(value='__AETHER_CANCEL__'),
                    ast.Constant(value=False)
                ],
                keywords=[]
            ),
            body=[ast.Break()],
            orelse=[]
        )
        yield_stmt = ast.Expr(
            value=ast.Await(
                value=ast.Call(
                    func=ast.Attribute(value=ast.Name(id='asyncio', ctx=ast.Load()), attr='sleep', ctx=ast.Load()),
                    args=[ast.Constant(value=0.016)],
                    keywords=[]
                )
            )
        )
        node.body.extend([cancel_if, yield_stmt])
        return node

    def visit_FunctionDef(self, node):
        self.generic_visit(node)
        has_await = any(isinstance(n, ast.Await) for n in ast.walk(node))
        if has_await:
            self.async_funcs.add(node.name)
            new_node = ast.AsyncFunctionDef(
                name=node.name,
                args=node.args,
                body=node.body,
                decorator_list=node.decorator_list,
                returns=node.returns,
                type_comment=getattr(node, 'type_comment', None)
            )
            return ast.copy_location(new_node, node)
        return node

    def visit_Call(self, node):
        self.generic_visit(node)
        if isinstance(node.func, ast.Name):
            if node.func.id == 'input':
                return ast.Await(value=node)
            elif node.func.id in self.async_funcs:
                return ast.Await(value=node)
        return node

def _aether_transform_code(user_code_str):
    try:
        parsed = ast.parse(user_code_str)
        transformer = _AetherLoopTransformer()
        transformed = transformer.visit(parsed)
        ast.fix_missing_locations(transformed)
        unparsed = ast.unparse(transformed)
        return unparsed
    except Exception as e:
        return user_code_str
`;

const PYGAME_EMULATOR_PYTHON_CODE = `
import sys
import js
import types

if 'pygame' not in sys.modules or not hasattr(sys.modules['pygame'], 'display'):
    pg = types.ModuleType('pygame')

    pg.QUIT = 256
    pg.KEYDOWN = 768
    pg.KEYUP = 769
    pg.MOUSEBUTTONDOWN = 1025
    pg.MOUSEBUTTONUP = 1026
    pg.MOUSEMOTION = 1024

    pg.K_LEFT = 276
    pg.K_RIGHT = 275
    pg.K_UP = 273
    pg.K_DOWN = 274
    pg.K_SPACE = 32
    pg.K_space = 32
    pg.K_RETURN = 13
    pg.K_ESCAPE = 27
    pg.K_TAB = 9
    pg.K_w = 119
    pg.K_a = 97
    pg.K_s = 115
    pg.K_d = 100

    for c in range(97, 123):
        setattr(pg, "K_" + chr(c), c)
        setattr(pg, "K_" + chr(c).upper(), c)
    for d in range(0, 10):
        setattr(pg, "K_" + str(d), 48 + d)

    def parse_color(c):
        if isinstance(c, (list, tuple)):
            r = int(c[0]) if len(c) > 0 else 0
            g = int(c[1]) if len(c) > 1 else 0
            b = int(c[2]) if len(c) > 2 else 0
            a = float(c[3]/255.0) if len(c) > 3 else 1.0
            return "rgba(" + str(r) + "," + str(g) + "," + str(b) + "," + str(a) + ")"
        elif isinstance(c, str):
            return c
        return "rgb(255,255,255)"

    class Color:
        def __init__(self, *args):
            if len(args) == 1:
                a = args[0]
                self.r, self.g, self.b = int(a[0]), int(a[1]), int(a[2])
                self.a = int(a[3]) if len(a) > 3 else 255
            elif len(args) >= 3:
                self.r, self.g, self.b = int(args[0]), int(args[1]), int(args[2])
                self.a = int(args[3]) if len(args) > 3 else 255
            else:
                self.r, self.g, self.b, self.a = 255, 255, 255, 255

    pg.Color = Color

    class Rect:
        def __init__(self, *args):
            if len(args) == 1 and isinstance(args[0], (list, tuple, Rect)):
                a = args[0]
                if isinstance(a, Rect):
                    self.x, self.y, self.width, self.height = a.x, a.y, a.width, a.height
                elif len(a) == 4:
                    self.x, self.y, self.width, self.height = a[0], a[1], a[2], a[3]
                elif len(a) == 2:
                    self.x, self.y, self.width, self.height = a[0][0], a[0][1], a[1][0], a[1][1]
            elif len(args) == 2:
                self.x, self.y = args[0][0], args[0][1]
                self.width, self.height = args[1][0], args[1][1]
            elif len(args) == 4:
                self.x, self.y, self.width, self.height = args[0], args[1], args[2], args[3]
            else:
                self.x, self.y, self.width, self.height = 0, 0, 0, 0
            self.w = self.width
            self.h = self.height

        @property
        def center(self): return (self.x + self.width // 2, self.y + self.height // 2)
        @center.setter
        def center(self, val): self.x, self.y = val[0] - self.width // 2, val[1] - self.height // 2

        @property
        def centerx(self): return self.x + self.width // 2
        @centerx.setter
        def centerx(self, v): self.x = v - self.width // 2

        @property
        def centery(self): return self.y + self.height // 2
        @centery.setter
        def centery(self, v): self.y = v - self.height // 2

        @property
        def top(self): return self.y
        @top.setter
        def top(self, v): self.y = v

        @property
        def left(self): return self.x
        @left.setter
        def left(self, v): self.x = v

        @property
        def right(self): return self.x + self.width
        @right.setter
        def right(self, v): self.x = v - self.width

        @property
        def bottom(self): return self.y + self.height
        @bottom.setter
        def bottom(self, v): self.y = v - self.height

        def colliderect(self, other):
            if isinstance(other, (list, tuple)): other = Rect(other)
            return not (self.right <= other.left or self.left >= other.right or self.bottom <= other.top or self.top >= other.bottom)

        def collidepoint(self, *args):
            if len(args) == 1: x, y = args[0][0], args[0][1]
            else: x, y = args[0], args[1]
            return self.left <= x <= self.right and self.top <= y <= self.bottom

        def copy(self):
            return Rect(self.x, self.y, self.width, self.height)

    pg.Rect = Rect

    class Surface:
        def __init__(self, size, flags=0):
            self.width = int(size[0])
            self.height = int(size[1])
            self.js_canvas = js.document.createElement('canvas')
            self.js_canvas.width = self.width
            self.js_canvas.height = self.height
            self.ctx = self.js_canvas.getContext('2d')
            self._alpha = 255
            self._colorkey = None
            self.fill((0, 0, 0))

        def get_width(self): return self.width
        def get_height(self): return self.height
        def get_size(self): return (self.width, self.height)
        def get_rect(self, **kwargs):
            r = Rect(0, 0, self.width, self.height)
            for k, v in kwargs.items(): setattr(r, k, v)
            return r

        def set_alpha(self, alpha, flags=0):
            if alpha is None:
                self._alpha = 255
            else:
                try:
                    self._alpha = max(0, min(255, int(alpha)))
                except Exception:
                    self._alpha = 255
            self.ctx.globalAlpha = self._alpha / 255.0
            return self._alpha

        def get_alpha(self):
            return getattr(self, '_alpha', 255)

        def set_colorkey(self, color, flags=0):
            self._colorkey = color

        def get_colorkey(self):
            return getattr(self, '_colorkey', None)

        def convert(self, *args):
            return self

        def convert_alpha(self, *args):
            return self

        def copy(self):
            s = Surface((self.width, self.height))
            s.ctx.drawImage(self.js_canvas, 0, 0)
            return s

        def subsurface(self, rect):
            r = Rect(rect)
            s = Surface((r.width, r.height))
            s.ctx.drawImage(self.js_canvas, r.x, r.y, r.width, r.height, 0, 0, r.width, r.height)
            return s

        def fill(self, color):
            self.ctx.fillStyle = parse_color(color)
            self.ctx.fillRect(0, 0, self.width, self.height)

        def blit(self, source, dest, area=None):
            if isinstance(dest, Rect): dx, dy = dest.x, dest.y
            elif isinstance(dest, (list, tuple)): dx, dy = dest[0], dest[1]
            else: dx, dy = 0, 0
            if hasattr(source, 'js_canvas'):
                old_alpha = self.ctx.globalAlpha
                if hasattr(source, '_alpha') and source._alpha < 255:
                    self.ctx.globalAlpha = source._alpha / 255.0
                if area:
                    ar = Rect(area)
                    self.ctx.drawImage(source.js_canvas, ar.x, ar.y, ar.width, ar.height, dx, dy, ar.width, ar.height)
                else:
                    self.ctx.drawImage(source.js_canvas, dx, dy)
                self.ctx.globalAlpha = old_alpha

    pg.Surface = Surface

    display = types.ModuleType('pygame.display')
    _screen_surface = None

    def set_mode(size=(800, 600), flags=0, depth=0):
        global _screen_surface
        canvas = js.document.getElementById('canvas')
        if not canvas:
            canvas = js.document.createElement('canvas')
            canvas.id = 'canvas'
            js.document.body.appendChild(canvas)
        canvas.width = int(size[0])
        canvas.height = int(size[1])
        surf = Surface(size)
        surf.js_canvas = canvas
        surf.ctx = canvas.getContext('2d')
        _screen_surface = surf
        return surf

    display.set_mode = set_mode
    display.set_caption = lambda t, i=None: None
    display.flip = lambda: None
    display.update = lambda *a: None
    display.get_surface = lambda: _screen_surface
    pg.display = display

    draw = types.ModuleType('pygame.draw')
    def rect(surface, color, rect_obj, width=0, border_radius=0):
        ctx = surface.ctx
        if isinstance(rect_obj, Rect): rx, ry, rw, rh = rect_obj.x, rect_obj.y, rect_obj.width, rect_obj.height
        elif isinstance(rect_obj, (list, tuple)): rx, ry, rw, rh = rect_obj[0], rect_obj[1], rect_obj[2], rect_obj[3]
        else: return
        ctx.fillStyle = parse_color(color)
        ctx.strokeStyle = parse_color(color)
        if width == 0: ctx.fillRect(rx, ry, rw, rh)
        else: ctx.lineWidth = width; ctx.strokeRect(rx, ry, rw, rh)

    def circle(surface, color, center, radius, width=0):
        ctx = surface.ctx
        ctx.beginPath()
        ctx.arc(center[0], center[1], radius, 0, 2 * js.Math.PI)
        if width == 0: ctx.fillStyle = parse_color(color); ctx.fill()
        else: ctx.lineWidth = width; ctx.strokeStyle = parse_color(color); ctx.stroke()

    def line(surface, color, start_pos, end_pos, width=1):
        ctx = surface.ctx
        ctx.beginPath()
        ctx.moveTo(start_pos[0], start_pos[1])
        ctx.lineTo(end_pos[0], end_pos[1])
        ctx.strokeStyle = parse_color(color)
        ctx.lineWidth = width
        ctx.stroke()

    def polygon(surface, color, points, width=0):
        if not points: return
        ctx = surface.ctx
        ctx.beginPath()
        ctx.moveTo(points[0][0], points[0][1])
        for p in points[1:]: ctx.lineTo(p[0], p[1])
        ctx.closePath()
        if width == 0: ctx.fillStyle = parse_color(color); ctx.fill()
        else: ctx.lineWidth = width; ctx.strokeStyle = parse_color(color); ctx.stroke()

    draw.rect = rect
    draw.circle = circle
    draw.line = line
    draw.polygon = polygon
    pg.draw = draw

    event = types.ModuleType('pygame.event')
    def get():
        raw_events = getattr(js.window, '__AETHER_PYGAME_EVENTS__', None)
        res = []
        if raw_events is not None:
            try:
                length = int(getattr(raw_events, 'length', 0))
                for i in range(length):
                    e = raw_events[i]
                    ev_obj = types.SimpleNamespace()
                    ev_obj.type = int(getattr(e, 'type', 0))
                    ev_obj.key = int(getattr(e, 'key', 0))
                    res.append(ev_obj)
            except Exception:
                pass
            try:
                js.window.__AETHER_PYGAME_EVENTS__ = []
            except Exception:
                pass
        return res

    event.get = get
    pg.event = event

    key = types.ModuleType('pygame.key')
    def get_pressed():
        keys_obj = getattr(js.window, '__AETHER_PYGAME_KEYS_PRESSED__', None)
        class PressedState:
            def __getitem__(self, k):
                if keys_obj is None:
                    return False
                try:
                    val = getattr(keys_obj, str(k), None)
                    if val is None:
                        val = getattr(keys_obj, str(int(k)), False)
                    return bool(val)
                except Exception:
                    return False
            def __len__(self):
                return 512
            def __iter__(self):
                return iter([self[i] for i in range(512)])
            def __bool__(self):
                return True
        return PressedState()

    key.get_pressed = get_pressed
    pg.key = key

    mouse_mod = types.ModuleType('pygame.mouse')
    mouse_mod.get_pos = lambda: (int(getattr(js.window, '__AETHER_PYGAME_MOUSE_X__', 0)), int(getattr(js.window, '__AETHER_PYGAME_MOUSE_Y__', 0)))
    mouse_mod.get_pressed = lambda: (bool(getattr(js.window, '__AETHER_PYGAME_MOUSE_DOWN__', False)), False, False)
    mouse_mod.set_visible = lambda v: None
    pg.mouse = mouse_mod

    time_mod = types.ModuleType('pygame.time')
    class Clock:
        def __init__(self): self.last_time = js.performance.now()
        def tick(self, fps=60):
            now = js.performance.now()
            dt = now - self.last_time
            self.last_time = now
            return int(dt)
        def get_fps(self): return 60.0

    time_mod.Clock = Clock
    time_mod.get_ticks = lambda: int(js.performance.now())
    time_mod.wait = lambda ms: None
    time_mod.delay = lambda ms: None
    pg.time = time_mod

    font_mod = types.ModuleType('pygame.font')
    class Font:
        def __init__(self, name=None, size=20):
            self.size = size
            self.name = name or 'sans-serif'
        def render(self, text, antialias, color, background=None):
            ctx_dummy = js.document.createElement('canvas').getContext('2d')
            ctx_dummy.font = str(self.size) + "px " + str(self.name)
            w = max(int(ctx_dummy.measureText(str(text)).width), 10)
            h = int(self.size * 1.3)
            surf = Surface((w, h))
            if background: surf.fill(background)
            surf.ctx.font = str(self.size) + "px " + str(self.name)
            surf.ctx.fillStyle = parse_color(color)
            surf.ctx.textBaseline = "top"
            surf.ctx.fillText(str(text), 0, 0)
            return surf

    font_mod.init = lambda: None
    font_mod.Font = Font
    font_mod.SysFont = lambda name, size, bold=False, italic=False: Font(name, size)
    pg.font = font_mod

    image_mod = types.ModuleType('pygame.image')
    def load(filename):
        s = Surface((100, 100))
        s.fill((100, 150, 200))
        return s
    image_mod.load = load
    pg.image = image_mod

    transform_mod = types.ModuleType('pygame.transform')
    def scale(surface, size):
        ns = Surface(size)
        ns.ctx.drawImage(surface.js_canvas, 0, 0, size[0], size[1])
        return ns
    transform_mod.scale = scale
    pg.transform = transform_mod

    mixer_mod = types.ModuleType('pygame.mixer')
    class Sound:
        def __init__(self, file): pass
        def play(self): pass
        def stop(self): pass
        def set_volume(self, v): pass
    mixer_mod.init = lambda: None
    mixer_mod.Sound = Sound
    pg.mixer = mixer_mod

    pg.init = lambda: (6, 0)
    pg.quit = lambda: None

    sys.modules['pygame'] = pg
    sys.modules['pygame.display'] = display
    sys.modules['pygame.draw'] = draw
    sys.modules['pygame.event'] = event
    sys.modules['pygame.key'] = key
    sys.modules['pygame.mouse'] = mouse_mod
    sys.modules['pygame.time'] = time_mod
    sys.modules['pygame.font'] = font_mod
    sys.modules['pygame.image'] = image_mod
    sys.modules['pygame.transform'] = transform_mod
    sys.modules['pygame.mixer'] = mixer_mod
`;

const PythonPreview: React.FC<PythonPreviewProps> = ({ code }) => {
  // Main Tabs: 'script' | 'packages' | 'idle' | 'server'
  const [activeTab, setActiveTab] = useState<'script' | 'packages' | 'idle' | 'server'>('script');
  
  // Standard Execution States
  const [output, setOutput] = useState<string[]>([]);
  const [generatedFiles, setGeneratedFiles] = useState<{ name: string; type: string; dataUrl: string }[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [statusText, setStatusText] = useState<string>('');
  const pyodideRef = useRef<any>(null);

  // Pygame Canvas & Screen States
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [hasPygame, setHasPygame] = useState(false);
  const [canvasFocused, setCanvasFocused] = useState(false);

  // Package Manager States
  const [installedPackages, setInstalledPackages] = useState<string[]>(['python 3.11', 'micropip']);
  const [customPkgInput, setCustomPkgInput] = useState('');
  const [isInstallingPkg, setIsInstallingPkg] = useState(false);
  const [pkgInstallStatus, setPkgInstallStatus] = useState<string | null>(null);

  // REPL (IDLE) States
  const [idleInput, setIdleInput] = useState('');
  const [idleLogs, setIdleLogs] = useState<ConsoleLine[]>([
    { type: 'system', text: 'Aether Native Linux Python 3.10 Kernel Active (/workspace persistent storage)' },
    { type: 'system', text: 'Direct system-level access to Linux kernel, subprocesses, sockets, files, and pip packages.' }
  ]);
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const idleEndRef = useRef<HTMLDivElement>(null);

  // Simulated Server States
  const [serverRunning, setServerRunning] = useState(false);
  const [serverLogs, setServerLogs] = useState<ServerRequestLog[]>([]);
  const [routes, setRoutes] = useState<MockRoute[]>([
    { path: '/api/tasks', method: 'GET', response: '[\n  {"id": 1, "title": "Build Multi-Agent Workspace", "status": "completed"},\n  {"id": 2, "title": "Run Pygame Canvas Game", "status": "running"},\n  {"id": 3, "title": "Execute Python Script", "status": "pending"}\n]' },
    { path: '/api/profile', method: 'GET', response: '{\n  "operator": "Aether Architect",\n  "access": "neural_link",\n  "status": "online",\n  "server": "Python 3.11 Engine"\n}' },
    { path: '/api/analytics', method: 'GET', response: '{\n  "cpu_load": "8.4%",\n  "memory": "Pyodide WebAssembly 512MB",\n  "uptime_seconds": 3600,\n  "packages_loaded": 12\n}' }
  ]);
  const [newPath, setNewPath] = useState('');
  const [newResponse, setNewResponse] = useState('{\n  "status": "ok"\n}');
  const [newMethod, setNewMethod] = useState('GET');
  const [showAddRoute, setShowAddRoute] = useState(false);
  const serverLogsEndRef = useRef<HTMLDivElement>(null);

  // Interactive Terminal CMD Prompt States
  const [termInput, setTermInput] = useState('');
  const [termHistory, setTermHistory] = useState<string[]>([]);
  const [termHistIdx, setTermHistIdx] = useState(-1);
  const consoleEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll console logs
  useEffect(() => {
    if (consoleEndRef.current) {
      consoleEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [output, error]);

  const handleTerminalSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = termInput.trim();
    if (!cmd) return;

    setTermInput('');
    setTermHistory(prev => [...prev, cmd]);
    setTermHistIdx(-1);

    // Check if Python input() is currently waiting for a callback
    // @ts-ignore
    if (window.__AETHER_INPUT_CB__) {
      // @ts-ignore
      const cb = window.__AETHER_INPUT_CB__;
      // @ts-ignore
      window.__AETHER_INPUT_CB__ = null;
      setOutput(prev => [...prev, cmd]);
      cb(cmd);
      return;
    }

    setOutput(prev => [...prev, `$ ${cmd}`]);

    if (cmd === 'clear' || cmd === 'cls') {
      setOutput([]);
      return;
    }

    if (cmd.startsWith('pip ')) {
      const pkg = cmd.replace(/^pip\s+install\s+/, '').trim();
      if (pkg) {
        handleInstallPackage(pkg);
      }
      return;
    }

    try {
      const response = await fetch('/api/python/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          script: cmd.startsWith('python3 ') || cmd.startsWith('python ') ? cmd.replace(/^python3?\s+/, '') : cmd,
          filename: 'interactive.py'
        })
      });

      const data = await response.json();
      if (data.stdout) {
        setOutput(prev => [...prev, ...data.stdout.split('\n')]);
      }
      if (data.stderr) {
        setOutput(prev => [...prev, ...data.stderr.split('\n').map((l: string) => `[STDERR] ${l}`)]);
      }
      if (data.generatedFiles && data.generatedFiles.length > 0) {
        setGeneratedFiles(data.generatedFiles);
      }
    } catch (err: any) {
      setOutput(prev => [...prev, `[STDERR] ${err.message || String(err)}`]);
    }
  };

  const handleTermKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (termHistory.length === 0) return;
      const nextIdx = termHistIdx === -1 ? termHistory.length - 1 : Math.max(0, termHistIdx - 1);
      setTermHistIdx(nextIdx);
      setTermInput(termHistory[nextIdx]);
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (termHistIdx === -1) return;
      if (termHistIdx === termHistory.length - 1) {
        setTermHistIdx(-1);
        setTermInput('');
      } else {
        const nextIdx = termHistIdx + 1;
        setTermHistIdx(nextIdx);
        setTermInput(termHistory[nextIdx]);
      }
    }
  };

  // Detect Pygame in code
  useEffect(() => {
    if (code && (code.includes('import pygame') || code.includes('from pygame'))) {
      setHasPygame(true);
    }
  }, [code]);

  // Initialize Native Linux Python Server Environment
  useEffect(() => {
    let mounted = true;

    const loadServerPythonRuntime = async () => {
      try {
        const res = await fetch('/api/python/version');
        const data = await res.json();
        if (mounted) {
          setInstalledPackages(['python 3.10', 'pip', 'system-packages']);
          setIsLoading(false);
        }
      } catch (err: any) {
        if (mounted) {
          setIsLoading(false);
        }
      }
    };

    loadServerPythonRuntime();

    return () => {
      mounted = false;
    };
  }, []);

  // Sync Server Mock Routes
  useEffect(() => {
    // @ts-ignore
    window.__AETHER_MOCK_SERVER_ACTIVE__ = serverRunning;
    
    if (serverRunning) {
      const routesMap: Record<string, (body: any, method: string) => string> = {};
      routes.forEach(r => {
        routesMap[r.path] = (body, method) => r.response;
      });
      // @ts-ignore
      window.__AETHER_MOCK_SERVER_ROUTES__ = routesMap;
      // @ts-ignore
      window.__AETHER_LOG_SERVER_REQUEST__ = (method: string, url: string, status: number, responseText: string) => {
        const newLog: ServerRequestLog = {
          timestamp: new Date().toLocaleTimeString(),
          method,
          url,
          status,
          response: responseText
        };
        setServerLogs(prev => [...prev, newLog].slice(-100));
      };
    } else {
      // @ts-ignore
      window.__AETHER_MOCK_SERVER_ROUTES__ = {};
      // @ts-ignore
      window.__AETHER_LOG_SERVER_REQUEST__ = undefined;
    }
  }, [serverRunning, routes]);

  // Setup Window Event Listeners for Pygame Keyboard & Mouse Input
  useEffect(() => {
    // @ts-ignore
    window.__AETHER_PYGAME_EVENTS__ = window.__AETHER_PYGAME_EVENTS__ || [];
    // @ts-ignore
    window.__AETHER_PYGAME_KEYS_PRESSED__ = window.__AETHER_PYGAME_KEYS_PRESSED__ || {};

    const keyMap: Record<string, number> = {
      'ArrowLeft': 276, 'ArrowRight': 275, 'ArrowUp': 273, 'ArrowDown': 274,
      'Space': 32, ' ': 32, 'Enter': 13, 'Escape': 27, 'Tab': 9,
      'KeyW': 119, 'KeyA': 97, 'KeyS': 115, 'KeyD': 100,
      'w': 119, 'a': 97, 's': 115, 'd': 100
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      const code = keyMap[e.code] || keyMap[e.key] || (e.key ? e.key.charCodeAt(0) : 0);
      // @ts-ignore
      window.__AETHER_PYGAME_KEYS_PRESSED__[code] = true;
      // @ts-ignore
      window.__AETHER_PYGAME_EVENTS__.push({ type: 768, key: code });
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const code = keyMap[e.code] || keyMap[e.key] || (e.key ? e.key.charCodeAt(0) : 0);
      // @ts-ignore
      window.__AETHER_PYGAME_KEYS_PRESSED__[code] = false;
      // @ts-ignore
      window.__AETHER_PYGAME_EVENTS__.push({ type: 769, key: code });
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (canvasRef.current) {
        const rect = canvasRef.current.getBoundingClientRect();
        // @ts-ignore
        window.__AETHER_PYGAME_MOUSE_X__ = e.clientX - rect.left;
        // @ts-ignore
        window.__AETHER_PYGAME_MOUSE_Y__ = e.clientY - rect.top;
      }
    };

    const handleMouseDown = () => {
      // @ts-ignore
      window.__AETHER_PYGAME_MOUSE_DOWN__ = true;
      // @ts-ignore
      window.__AETHER_PYGAME_EVENTS__.push({ type: 1025, button: 1 });
    };

    const handleMouseUp = () => {
      // @ts-ignore
      window.__AETHER_PYGAME_MOUSE_DOWN__ = false;
      // @ts-ignore
      window.__AETHER_PYGAME_EVENTS__.push({ type: 1026, button: 1 });
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, []);

  // Scroll helpers
  useEffect(() => {
    idleEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [idleLogs]);

  useEffect(() => {
    serverLogsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [serverLogs]);

  const handleStop = () => {
    // @ts-ignore
    window.__AETHER_CANCEL__ = true;
    // @ts-ignore
    if (window.__AETHER_INPUT_CB__) {
      // @ts-ignore
      window.__AETHER_INPUT_CB__('');
      // @ts-ignore
      window.__AETHER_INPUT_CB__ = null;
    }
    setIsRunning(false);
    setStatusText('Process stopped by user');
    setOutput(prev => [...prev, '[SYSTEM] Execution terminated by user.']);
  };

  // Run Main Script on Native Linux Container VM with Real Storage Access
  const runCode = async () => {
    setIsRunning(true);
    setError(null);
    setOutput([]);
    setStatusText('Executing on Native Linux Container VM...');

    try {
      const response = await fetch('/api/python/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          script: code,
          filename: 'main.py'
        })
      });

      const data = await response.json();

      if (data.stdout) {
        const stdoutLines = data.stdout.split('\n');
        setOutput(prev => [...prev, ...stdoutLines]);
      }
      if (data.stderr) {
        const stderrLines = data.stderr.split('\n').map((l: string) => `[STDERR] ${l}`);
        setOutput(prev => [...prev, ...stderrLines]);
      }
      if (data.generatedFiles && data.generatedFiles.length > 0) {
        setGeneratedFiles(data.generatedFiles);
      }

      if (data.exitCode !== 0 && !data.stdout && !data.stderr) {
        setError(`Linux VM process exited with code ${data.exitCode}`);
      }

      setStatusText('');
    } catch (err: any) {
      setError(err.message || String(err));
    } finally {
      setIsRunning(false);
      setStatusText('');
    }
  };

  // Custom Package Installer via Native Linux Pip Package Manager into Persistent Workspace Storage
  const handleInstallPackage = async (packageName: string) => {
    const target = packageName.trim();
    if (!target) return;

    setIsInstallingPkg(true);
    setPkgInstallStatus(`Installing ${target} into persistent Linux environment...`);

    try {
      const response = await fetch('/api/python/pip/install', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ packageName: target })
      });
      const data = await response.json();

      setInstalledPackages(prev => Array.from(new Set([...prev, target])));
      setPkgInstallStatus(data.success ? `Successfully installed ${target} into Linux environment!` : `Notice: ${data.stderr || data.error || 'Package updated'}`);
      setTimeout(() => setPkgInstallStatus(null), 5000);
    } catch (err: any) {
      setPkgInstallStatus(`Failed to install ${target}: ${err.message || String(err)}`);
    } finally {
      setIsInstallingPkg(false);
    }
  };

  // Run REPL Command on Native Linux VM
  const runRepl = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!idleInput.trim()) return;

    const cmd = idleInput;
    setIdleInput('');
    setCommandHistory(prev => [...prev, cmd]);
    setHistoryIndex(-1);
    
    setIdleLogs(prev => [...prev, { type: 'input', text: cmd }]);

    try {
      const response = await fetch('/api/python/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ script: cmd, filename: 'repl.py' })
      });
      const data = await response.json();

      if (data.stdout) {
        setIdleLogs(prev => [...prev, { type: 'output', text: data.stdout.trim() }]);
      }
      if (data.stderr) {
        setIdleLogs(prev => [...prev, { type: 'error', text: data.stderr.trim() }]);
      }
      if (!data.stdout && !data.stderr) {
        setIdleLogs(prev => [...prev, { type: 'system', text: '>>> Success' }]);
      }
    } catch (err: any) {
      setIdleLogs(prev => [...prev, { type: 'error', text: err.message || String(err) }]);
    }
  };

  // REPL History Navigation
  const handleReplKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (commandHistory.length === 0) return;
      const nextIdx = historyIndex === -1 ? commandHistory.length - 1 : Math.max(0, historyIndex - 1);
      setHistoryIndex(nextIdx);
      setIdleInput(commandHistory[nextIdx]);
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex === -1) return;
      if (historyIndex === commandHistory.length - 1) {
        setHistoryIndex(-1);
        setIdleInput('');
      } else {
        const nextIdx = historyIndex + 1;
        setHistoryIndex(nextIdx);
        setIdleInput(commandHistory[nextIdx]);
      }
    }
  };

  // Server Route Handlers
  const handleAddRoute = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPath.trim()) return;
    const formattedPath = newPath.startsWith('/') ? newPath : '/' + newPath;
    setRoutes(prev => [...prev, { path: formattedPath, method: newMethod, response: newResponse }]);
    setNewPath('');
    setNewResponse('{\n  "status": "ok"\n}');
    setShowAddRoute(false);
  };

  const handleDeleteRoute = (pathToDelete: string) => {
    setRoutes(prev => prev.filter(r => r.path !== pathToDelete));
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center h-full bg-[#07080c] text-white gap-4 p-6">
        <div className="relative">
          <Loader2 className="w-10 h-10 animate-spin text-yellow-500" />
          <Cpu className="w-4 h-4 text-amber-400 absolute inset-0 m-auto" />
        </div>
        <div className="text-center space-y-1">
          <p className="text-xs font-mono uppercase tracking-widest text-amber-400 font-bold">Initializing Full Python 3.11 Runtime...</p>
          <p className="text-[10px] text-zinc-500 font-mono">Loading WebAssembly interpreter, Pygame graphics & Micropip engine</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-[#07080c] text-white font-mono overflow-hidden">
      {/* Top Header & Tab Navigation Bar */}
      <div className="flex items-center justify-between p-2 border-b border-white/10 bg-white/5 select-none shrink-0 gap-2">
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          <button 
            onClick={() => setActiveTab('script')}
            className={`px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all border flex items-center gap-1.5 ${
              activeTab === 'script'
                ? 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30 shadow-[0_0_12px_rgba(234,179,8,0.15)]'
                : 'text-zinc-500 border-transparent hover:text-white hover:bg-white/5'
            }`}
          >
            <Code size={12} />
            Script & Canvas Runner
            {hasPygame && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" title="Pygame Canvas Active" />}
          </button>

          <button 
            onClick={() => setActiveTab('packages')}
            className={`px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all border flex items-center gap-1.5 ${
              activeTab === 'packages'
                ? 'bg-purple-500/10 text-purple-400 border-purple-500/30'
                : 'text-zinc-500 border-transparent hover:text-white hover:bg-white/5'
            }`}
          >
            <Package size={12} />
            Pip Packages ({installedPackages.length})
          </button>

          <button 
            onClick={() => setActiveTab('idle')}
            className={`px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all border flex items-center gap-1.5 ${
              activeTab === 'idle'
                ? 'bg-amber-600/10 text-amber-400 border-amber-500/30'
                : 'text-zinc-500 border-transparent hover:text-white hover:bg-white/5'
            }`}
          >
            <Terminal size={12} />
            Python IDLE REPL
          </button>

          <button 
            onClick={() => setActiveTab('server')}
            className={`px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all border flex items-center gap-1.5 ${
              activeTab === 'server'
                ? 'bg-emerald-600/10 text-emerald-400 border-emerald-500/30'
                : 'text-zinc-500 border-transparent hover:text-white hover:bg-white/5'
            }`}
          >
            <Server size={12} />
            Server Simulator
          </button>
        </div>

        {/* Action Button */}
        {activeTab === 'script' && (
          <div className="flex items-center gap-2 shrink-0">
            {hasPygame && (
              <button
                onClick={() => {
                  if (canvasRef.current) {
                    canvasRef.current.focus();
                    setCanvasFocused(true);
                  }
                }}
                className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase border transition-all flex items-center gap-1 ${
                  canvasFocused 
                    ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 shadow-[0_0_10px_rgba(16,185,129,0.3)]' 
                    : 'bg-white/5 text-zinc-400 border-white/10 hover:text-white'
                }`}
                title="Focus Pygame Canvas for Keyboard & Gamepad Inputs"
              >
                <Focus size={11} />
                {canvasFocused ? 'Controls Focused' : 'Focus Controls'}
              </button>
            )}

            {isRunning && (
              <button
                onClick={handleStop}
                className="flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold transition-all bg-red-600/30 text-red-400 border border-red-500/40 hover:bg-red-600/50"
                title="Stop Execution"
              >
                <Power size={11} />
                STOP
              </button>
            )}

            <button 
              onClick={runCode}
              disabled={isRunning}
              className={`flex items-center gap-1.5 px-4 py-1 rounded-full text-[10px] font-bold transition-all shadow-lg ${
                isRunning 
                  ? 'bg-white/10 text-white/40 cursor-not-allowed' 
                  : 'bg-yellow-500 hover:bg-yellow-400 text-black shadow-[0_0_15px_rgba(234,179,8,0.4)]'
              }`}
            >
              {isRunning ? <Loader2 size={11} className="animate-spin" /> : <Play size={11} fill="currentColor" />}
              {isRunning ? 'RUNNING' : 'RUN PYTHON'}
            </button>
          </div>
        )}

        {activeTab === 'server' && (
          <button 
            onClick={() => setServerRunning(!serverRunning)}
            className={`flex items-center gap-1.5 px-3.5 py-1 rounded-full text-[10px] font-bold transition-all border ${
              serverRunning 
                ? 'bg-emerald-600/20 text-emerald-400 border-emerald-500/30 shadow-[0_0_15px_rgba(16,185,129,0.2)]' 
                : 'bg-red-600/20 text-red-400 border-red-500/30 hover:bg-red-600/30'
            }`}
          >
            <Power size={11} />
            {serverRunning ? 'SERVER: ONLINE' : 'SERVER: OFFLINE'}
          </button>
        )}
      </div>

      {/* Main Viewport Content */}
      <div className="flex-1 overflow-hidden relative flex flex-col">
        {/* Status bar notification */}
        {statusText && (
          <div className="px-3 py-1.5 bg-yellow-500/10 border-b border-yellow-500/20 text-yellow-300 text-[10px] flex items-center gap-2 shrink-0 animate-pulse">
            <Loader2 size={12} className="animate-spin text-yellow-400" />
            <span>{statusText}</span>
          </div>
        )}

        {/* TAB 1: SCRIPT & PYGAME CANVAS RUNNER */}
        {activeTab === 'script' && (
          <div className="flex-1 flex flex-col md:flex-row h-full overflow-hidden bg-[#050608]">
            {/* Left/Top Panel: Pygame & Graphic Canvas Display */}
            <div className="flex-1 flex flex-col items-center justify-center p-3 bg-black/60 border-b md:border-b-0 md:border-r border-white/10 relative min-h-[250px] overflow-hidden">
              <div className="absolute top-2 left-3 flex items-center gap-2 z-10 text-[10px] font-bold text-zinc-400 uppercase tracking-wider">
                <Monitor size={12} className="text-yellow-400" />
                <span>Pygame Graphics Canvas</span>
                {hasPygame && <span className="px-1.5 py-0.5 bg-emerald-500/20 text-emerald-400 rounded border border-emerald-500/30 text-[9px]">SDL2 Ready</span>}
              </div>

              {/* Canvas Element or Generated File Images */}
              {generatedFiles.length > 0 ? (
                <div className="w-full h-full flex flex-col items-center justify-center gap-3 overflow-y-auto p-2 custom-scrollbar">
                  {generatedFiles.map((gf, idx) => (
                    <div key={idx} className="flex flex-col items-center gap-1.5 max-w-full bg-white/5 p-2 rounded-xl border border-white/10">
                      <img src={gf.dataUrl} alt={gf.name} className="max-w-full max-h-[350px] object-contain rounded-lg shadow-xl" />
                      <span className="text-[10px] text-yellow-400 font-mono flex items-center gap-1">
                        <Box size={10} /> {gf.name} (Linux Storage Output)
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <canvas 
                  ref={canvasRef}
                  id="canvas"
                  tabIndex={0}
                  onFocus={() => setCanvasFocused(true)}
                  onBlur={() => setCanvasFocused(false)}
                  className={`bg-black rounded-xl border transition-all max-w-full max-h-full aspect-video outline-none shadow-2xl ${
                    canvasFocused 
                      ? 'border-emerald-500/60 shadow-[0_0_20px_rgba(16,185,129,0.25)]' 
                      : 'border-white/20 hover:border-white/40'
                  }`}
                  style={{ width: '100%', maxWidth: '800px', height: 'auto', minHeight: '300px' }}
                />
              )}

              {!isRunning && output.length === 0 && !error && (
                <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center pointer-events-none bg-black/40 backdrop-blur-xs">
                  <Box size={40} className="text-yellow-400/40 mb-3 animate-bounce" />
                  <p className="text-xs font-bold text-zinc-300">Pygame & Canvas Engine Ready</p>
                  <p className="text-[10px] text-zinc-500 max-w-sm mt-1">Press "RUN PYTHON" to execute your script. Pygame games, NumPy arrays, Matplotlib graphs, and full Python scripts will render here.</p>
                </div>
              )}
            </div>

            {/* Right/Bottom Panel: Live Interactive Execution Terminal */}
            <div className="w-full md:w-96 flex flex-col h-full bg-[#08090d] border-t md:border-t-0 border-white/10">
              <div className="px-3 py-2 bg-white/5 border-b border-white/10 flex items-center justify-between text-[10px] font-bold text-zinc-400 uppercase tracking-wider shrink-0">
                <span className="flex items-center gap-1.5">
                  <Terminal size={12} className="text-yellow-400" />
                  Interactive Output Terminal
                </span>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => {
                      if (output.length > 0) {
                        navigator.clipboard.writeText(output.join('\n'));
                      }
                    }}
                    className="hover:text-white text-zinc-400 transition-colors"
                    title="Copy Terminal Logs"
                  >
                    <Copy size={12} />
                  </button>
                  <button 
                    onClick={() => setOutput([])}
                    className="hover:text-white text-zinc-400 transition-colors"
                    title="Clear Console"
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              </div>

              <div className="flex-1 p-3 overflow-y-auto space-y-1.5 custom-scrollbar font-mono text-xs">
                {output.length === 0 && !error && !isRunning && (
                  <p className="text-zinc-600 text-[11px] italic">Terminal ready. Press "RUN PYTHON" or type interactive commands below...</p>
                )}

                {output.map((line, i) => (
                  <div key={i} className={`py-0.5 break-all ${
                    line.startsWith('$') 
                      ? 'text-yellow-400 font-bold' 
                      : line.startsWith('[STDERR]') 
                      ? 'text-red-400 bg-red-500/5 px-2 rounded border border-red-500/10' 
                      : 'text-zinc-200'
                  }`}>
                    {line}
                  </div>
                ))}

                {error && (
                  <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl space-y-1 mt-2">
                    <div className="flex items-center gap-1.5 text-red-400 text-[10px] font-bold uppercase">
                      <AlertCircle size={13} />
                      <span>Python Runtime Error</span>
                    </div>
                    <p className="text-xs text-red-200 whitespace-pre-wrap leading-relaxed">{error}</p>
                  </div>
                )}

                {!isRunning && output.length > 0 && !error && (
                  <div className="flex items-center gap-1.5 text-[10px] text-emerald-400 font-bold uppercase mt-3 pt-2 border-t border-white/5">
                    <CheckCircle2 size={12} />
                    <span>Process Completed</span>
                  </div>
                )}

                <div ref={consoleEndRef} />
              </div>

              {/* Interactive Command Prompt Bar */}
              <form onSubmit={handleTerminalSubmit} className="flex items-center border-t border-white/10 bg-black/60 p-2 shrink-0">
                <span className="text-emerald-400 font-bold text-xs px-1.5 select-none font-mono">$</span>
                <input
                  type="text"
                  value={termInput}
                  onChange={e => setTermInput(e.target.value)}
                  onKeyDown={handleTermKeyDown}
                  placeholder="enter cmd or python statement... (e.g. print(10+20), ls, pip install scipy)"
                  className="flex-1 bg-transparent text-white outline-none border-none py-1 px-1 font-mono text-xs placeholder:text-zinc-600"
                />
                <button 
                  type="submit" 
                  disabled={!termInput.trim()}
                  className="p-1.5 text-zinc-400 hover:text-yellow-400 disabled:opacity-30 transition-colors"
                  title="Execute Terminal Command"
                >
                  <Send size={13} />
                </button>
              </form>
            </div>
          </div>
        )}

        {/* TAB 2: PIP PACKAGES HUB */}
        {activeTab === 'packages' && (
          <div className="flex-1 overflow-y-auto p-4 space-y-6 custom-scrollbar bg-[#050608]">
            {/* Top Search & Pip Install Bar */}
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 space-y-3">
              <div className="flex items-center gap-2">
                <Package className="text-purple-400" size={18} />
                <div>
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider">PyPI Package Installer (Micropip)</h3>
                  <p className="text-[10px] text-zinc-400">Install any Python package directly from PyPI into your browser WebAssembly environment</p>
                </div>
              </div>

              <form 
                onSubmit={(e) => {
                  e.preventDefault();
                  handleInstallPackage(customPkgInput);
                  setCustomPkgInput('');
                }}
                className="flex gap-2"
              >
                <div className="flex-1 bg-black/60 border border-white/10 rounded-xl flex items-center px-3 py-1.5">
                  <span className="text-purple-400 font-bold text-xs mr-2 select-none">pip install</span>
                  <input 
                    type="text" 
                    value={customPkgInput}
                    onChange={(e) => setCustomPkgInput(e.target.value)}
                    placeholder="package name (e.g. scikit-learn, requests, sympy, pandas)..."
                    className="w-full bg-transparent outline-none text-xs text-white placeholder:text-zinc-600"
                  />
                </div>
                <button 
                  type="submit"
                  disabled={isInstallingPkg || !customPkgInput.trim()}
                  className="px-4 py-1.5 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white font-bold text-xs rounded-xl transition-all shadow-lg flex items-center gap-1.5"
                >
                  {isInstallingPkg ? <Loader2 size={13} className="animate-spin" /> : <Download size={13} />}
                  Install
                </button>
              </form>

              {pkgInstallStatus && (
                <div className="text-[11px] text-purple-300 font-mono bg-purple-500/10 border border-purple-500/20 p-2 rounded-lg flex items-center gap-2">
                  <Sparkles size={13} className="text-purple-400 shrink-0" />
                  <span>{pkgInstallStatus}</span>
                </div>
              )}
            </div>

            {/* Installed Packages Badges */}
            <div className="space-y-2">
              <h4 className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
                <ShieldCheck size={12} className="text-emerald-400" />
                Active Installed Packages
              </h4>
              <div className="flex flex-wrap gap-2">
                {installedPackages.map((pkg, i) => (
                  <span key={i} className="px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-[11px] font-bold rounded-lg flex items-center gap-1">
                    <CheckCircle2 size={11} className="text-emerald-400" />
                    {pkg}
                  </span>
                ))}
              </div>
            </div>

            {/* Popular Featured Packages Grid */}
            <div className="space-y-3">
              <h4 className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">Popular Python Engines & Libraries</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {POPULAR_PYTHON_PACKAGES.map((pkg) => {
                  const isInstalled = installedPackages.includes(pkg.name);
                  return (
                    <div key={pkg.name} className="p-3 bg-white/5 border border-white/10 rounded-xl hover:border-purple-500/40 transition-all flex justify-between items-start gap-3">
                      <div className="space-y-1 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-lg select-none">{pkg.icon}</span>
                          <span className="text-xs font-bold text-white">{pkg.name}</span>
                          <span className="text-[9px] px-1.5 py-0.5 bg-white/10 text-zinc-400 rounded">{pkg.category}</span>
                        </div>
                        <p className="text-[10px] text-zinc-400 leading-relaxed">{pkg.desc}</p>
                      </div>

                      <button
                        onClick={() => handleInstallPackage(pkg.name)}
                        disabled={isInstallingPkg || isInstalled}
                        className={`px-3 py-1 rounded-lg text-[10px] font-bold uppercase transition-all shrink-0 ${
                          isInstalled 
                            ? 'bg-emerald-500/20 text-emerald-400 cursor-default'
                            : 'bg-white/10 hover:bg-purple-600 text-white'
                        }`}
                      >
                        {isInstalled ? 'Loaded' : 'Get Package'}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: PYTHON IDLE REPL */}
        {activeTab === 'idle' && (
          <div className="flex flex-col h-full bg-[#050608]">
            <div className="flex-1 overflow-y-auto p-4 space-y-2.5 custom-scrollbar text-xs">
              {idleLogs.map((log, i) => (
                <div key={i} className="break-all leading-relaxed">
                  {log.type === 'input' && (
                    <div className="flex items-start gap-1.5 text-zinc-300">
                      <span className="text-amber-500 font-bold font-mono shrink-0 select-none">&gt;&gt;&gt;</span>
                      <span className="font-mono whitespace-pre-wrap">{log.text}</span>
                    </div>
                  )}
                  {log.type === 'output' && (
                    <div className="text-yellow-200 pl-5 font-mono whitespace-pre-wrap bg-white/5 p-2 rounded-lg border border-white/5 my-1">
                      {log.text}
                    </div>
                  )}
                  {log.type === 'error' && (
                    <div className="text-red-400 pl-5 font-mono whitespace-pre-wrap flex items-start gap-1.5 bg-red-500/5 p-2 rounded-lg border border-red-500/10 my-1">
                      <AlertCircle size={12} className="shrink-0 mt-0.5" />
                      <span>{log.text}</span>
                    </div>
                  )}
                  {log.type === 'system' && (
                    <p className="text-zinc-500 pl-5 italic text-[10px] select-none font-sans">
                      {log.text}
                    </p>
                  )}
                </div>
              ))}
              <div ref={idleEndRef} />
            </div>

            <form onSubmit={runRepl} className="flex items-center border-t border-white/10 bg-black/40 p-2 shrink-0">
              <span className="text-amber-500 font-bold px-2 select-none">&gt;&gt;&gt;</span>
              <input
                type="text"
                value={idleInput}
                onChange={e => setIdleInput(e.target.value)}
                onKeyDown={handleReplKeyDown}
                placeholder="type custom Python statement... (e.g. import numpy as np; print(np.random.rand(3,3)))"
                className="flex-1 bg-transparent text-white outline-none border-none py-1.5 px-1 font-mono text-xs placeholder:text-zinc-700"
              />
              <button 
                type="submit" 
                className="p-1.5 text-zinc-400 hover:text-amber-400 transition-colors"
                title="Execute Command"
              >
                <Send size={14} />
              </button>
            </form>
          </div>
        )}

        {/* TAB 4: LOCAL SIMULATED SERVER LOGS */}
        {activeTab === 'server' && (
          <div className="flex flex-col h-full bg-[#050608]">
            <div className="p-3 bg-white/5 border-b border-white/10 text-[10px] space-y-3 shrink-0">
              <div className="flex justify-between items-center">
                <span className="font-bold text-zinc-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Database size={12} className="text-emerald-400" />
                  Active API Endpoints
                </span>
                <button 
                  onClick={() => setShowAddRoute(!showAddRoute)}
                  className="px-2 py-0.5 bg-white/10 hover:bg-white/20 rounded text-[9px] font-bold text-white uppercase transition-all flex items-center gap-1"
                >
                  <Plus size={10} />
                  Add route
                </button>
              </div>

              {showAddRoute && (
                <form onSubmit={handleAddRoute} className="bg-black/50 p-3 rounded-lg border border-white/10 space-y-2">
                  <div className="flex gap-2">
                    <select 
                      value={newMethod} 
                      onChange={e => setNewMethod(e.target.value)}
                      className="bg-zinc-900 border border-white/10 text-[9px] text-zinc-300 rounded px-2 outline-none"
                    >
                      <option value="GET">GET</option>
                      <option value="POST">POST</option>
                      <option value="PUT">PUT</option>
                      <option value="DELETE">DELETE</option>
                    </select>
                    <input 
                      type="text" 
                      placeholder="/api/my-endpoint" 
                      value={newPath} 
                      onChange={e => setNewPath(e.target.value)}
                      className="flex-1 bg-zinc-900 border border-white/10 text-[9px] text-white rounded px-2 py-1 outline-none font-mono"
                    />
                  </div>
                  <textarea 
                    rows={2} 
                    value={newResponse} 
                    onChange={e => setNewResponse(e.target.value)}
                    className="w-full bg-zinc-900 border border-white/10 text-[9px] text-emerald-400 rounded p-2 outline-none font-mono"
                  />
                  <button type="submit" className="w-full py-1 bg-emerald-600 hover:bg-emerald-500 text-black font-bold text-[9px] uppercase rounded">
                    Save Endpoint
                  </button>
                </form>
              )}

              <div className="flex flex-wrap gap-1.5">
                {routes.map(r => (
                  <div key={r.path} className="px-2 py-1 bg-black/40 border border-white/10 rounded flex items-center gap-1.5">
                    <span className="text-emerald-400 font-bold">{r.method}</span>
                    <span className="text-zinc-300">{r.path}</span>
                    <button onClick={() => handleDeleteRoute(r.path)} className="text-zinc-500 hover:text-red-400 ml-1">
                      <Trash2 size={10} />
                    </button>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-3 space-y-1.5 font-mono text-[11px]">
              {serverLogs.length === 0 && (
                <p className="text-zinc-600 italic">No incoming server logs yet. Enable "SERVER: ONLINE" above to log requests.</p>
              )}
              {serverLogs.map((log, i) => (
                <div key={i} className="p-2 bg-white/5 rounded border border-white/5 flex items-start gap-2">
                  <span className="text-zinc-500 text-[9px]">{log.timestamp}</span>
                  <span className="text-emerald-400 font-bold">{log.method}</span>
                  <span className="text-zinc-200">{log.url}</span>
                  <span className="text-blue-400 font-bold ml-auto">{log.status}</span>
                </div>
              ))}
              <div ref={serverLogsEndRef} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PythonPreview;
