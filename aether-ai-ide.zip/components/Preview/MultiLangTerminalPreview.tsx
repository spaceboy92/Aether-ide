import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  Terminal, Play, Loader2, Cpu, AlertCircle, RefreshCw, CheckCircle2, 
  Flame, Wrench, PlayCircle, Bug, Sparkles, Send, Trash2, Copy, Check,
  FileCode, Layers, ShieldCheck, ChevronRight, X, HelpCircle, Code2,
  FileSearch, AlertTriangle, ArrowRight, CornerDownLeft
} from 'lucide-react';
import { FileNode } from '../../types';
import universalCompilerService, { CompilerDiagnostic, LanguageDefinition } from '../../services/universalCompilerService';

interface MultiLangTerminalPreviewProps {
  files: FileNode[];
  selectedFilename?: string;
  onSelectFile?: (filename: string) => void;
  onCodeFixed?: (filename: string, fixedContent: string) => void;
  onEmitPreviewLog?: (level: 'info' | 'warn' | 'error', message: string, source?: string) => void;
}

interface ExecutionLog {
  id: string;
  type: 'stdout' | 'stderr' | 'system' | 'prompt' | 'diag';
  content: string;
  timestamp: number;
}

export const MultiLangTerminalPreview: React.FC<MultiLangTerminalPreviewProps> = ({
  files,
  selectedFilename,
  onSelectFile,
  onCodeFixed,
  onEmitPreviewLog
}) => {
  // Find all runnable code files across all languages
  const runnableFiles = useMemo(() => {
    return files.filter(f => universalCompilerService.isCompilableFile(f.name));
  }, [files]);

  // Determine active file
  const [activeFileName, setActiveFileName] = useState<string>(() => {
    if (selectedFilename && files.some(f => f.name === selectedFilename)) {
      return selectedFilename;
    }
    return runnableFiles[0]?.name || (files[0]?.name ?? 'main.py');
  });

  // Keep synced if runnable files change
  useEffect(() => {
    if (selectedFilename && files.some(f => f.name === selectedFilename)) {
      setActiveFileName(selectedFilename);
    } else if (!files.some(f => f.name === activeFileName) && runnableFiles.length > 0) {
      setActiveFileName(runnableFiles[0].name);
    }
  }, [runnableFiles, selectedFilename, files]);

  const activeFile = useMemo(() => {
    return files.find(f => f.name === activeFileName) || runnableFiles[0] || files[0];
  }, [files, activeFileName, runnableFiles]);

  // Language metadata
  const languageInfo: LanguageDefinition = useMemo(() => {
    if (!activeFile) {
      return universalCompilerService.getLanguageMeta('generic.txt');
    }
    return universalCompilerService.getLanguageMeta(activeFile.name);
  }, [activeFile]);

  // States
  const [logs, setLogs] = useState<ExecutionLog[]>([]);
  const [isCompiling, setIsCompiling] = useState(false);
  const [isCheckingErrors, setIsCheckingErrors] = useState(false);
  const [isScanningWorkspace, setIsScanningWorkspace] = useState(false);
  const [isFixingErrors, setIsFixingErrors] = useState(false);
  const [diagnostics, setDiagnostics] = useState<CompilerDiagnostic[]>([]);
  const [executionStats, setExecutionStats] = useState<{ durationMs?: number; runtime?: string; exitCode?: number } | null>(null);
  const [cliInput, setCliInput] = useState('');
  const [copied, setCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'terminal' | 'diagnostics'>('terminal');

  // Rust specific configurations
  const [rustEdition, setRustEdition] = useState<'2021' | '2018'>('2021');
  const [rustMode, setRustMode] = useState<'debug' | 'release'>('debug');

  const terminalEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs, isCompiling, diagnostics]);

  // Helper to log to both local terminal and global preview log
  const logEvent = (level: 'info' | 'warn' | 'error', msg: string) => {
    if (onEmitPreviewLog) {
      onEmitPreviewLog(level, msg, `[${languageInfo.name}] ${activeFile?.name || ''}`);
    }
    // Also dispatch preview log event for parent PreviewPane iframe listener
    if (typeof window !== 'undefined') {
      window.postMessage({
        type: 'AETHER_PREVIEW_LOG',
        level: level,
        message: `[${languageInfo.name} • ${activeFile?.name}] ${msg}`
      }, '*');
    }
  };

  // Compile and execute the active code file in ANY language
  const runCode = async () => {
    if (!activeFile || !activeFile.content.trim()) return;

    setIsCompiling(true);
    setDiagnostics([]);
    setExecutionStats(null);

    const startTime = Date.now();
    const cmdPrompt = `$ ${languageInfo.cmd} ${activeFile.name}`;

    setLogs(prev => [
      ...prev,
      {
        id: `sys-${Date.now()}`,
        type: 'prompt',
        content: cmdPrompt,
        timestamp: Date.now()
      }
    ]);

    logEvent('info', `Compiling and launching ${activeFile.name} via ${languageInfo.compiler}...`);

    try {
      const result = await universalCompilerService.compileAndExecute(activeFile, files);
      const duration = result.durationMs || (Date.now() - startTime);

      const newEntries: ExecutionLog[] = [];

      if (result.stderr && result.stderr.trim()) {
        newEntries.push({
          id: `err-${Date.now()}`,
          type: 'stderr',
          content: result.stderr.trim(),
          timestamp: Date.now()
        });
        logEvent('error', `Compilation/Runtime issue in ${activeFile.name}: ${result.stderr.slice(0, 180)}`);
      }

      if (result.stdout && result.stdout.trim()) {
        newEntries.push({
          id: `out-${Date.now()}`,
          type: 'stdout',
          content: result.stdout.trim(),
          timestamp: Date.now()
        });
        logEvent('info', result.stdout.slice(0, 150));
      }

      if (!result.stdout && !result.stderr) {
        newEntries.push({
          id: `sys-${Date.now()}`,
          type: 'system',
          content: `[Process completed in ${duration}ms with exit code 0 (No stdout output)]`,
          timestamp: Date.now()
        });
      } else {
        newEntries.push({
          id: `end-${Date.now()}`,
          type: 'system',
          content: `[Process exited with code ${result.exitCode} (${result.runtime}) in ${duration}ms]`,
          timestamp: Date.now()
        });
      }

      setLogs(prev => [...prev, ...newEntries]);
      setDiagnostics(result.diagnostics || []);
      setExecutionStats({
        durationMs: duration,
        runtime: result.runtime,
        exitCode: result.exitCode
      });

      if (result.diagnostics && result.diagnostics.length > 0) {
        setActiveTab('diagnostics');
      }
    } catch (err: any) {
      const errorMsg = `Compiler Engine Error: ${err.message || 'Execution fault'}`;
      setLogs(prev => [
        ...prev,
        {
          id: `fault-${Date.now()}`,
          type: 'stderr',
          content: errorMsg,
          timestamp: Date.now()
        }
      ]);
      logEvent('error', errorMsg);
    } finally {
      setIsCompiling(false);
    }
  };

  // Check file specifically for syntax and compiler errors across any language
  const checkForErrors = async () => {
    if (!activeFile) return;
    setIsCheckingErrors(true);

    logEvent('info', `Running static compiler diagnostics and syntax check on ${activeFile.name}...`);

    try {
      const res = await universalCompilerService.checkFileErrors(activeFile, files);
      setDiagnostics(res.diagnostics);

      if (res.diagnostics.length > 0) {
        setActiveTab('diagnostics');
        const diagSummary = `[DIAGNOSTICS]: Found ${res.diagnostics.length} issue(s) in ${activeFile.name}:\n` +
          res.diagnostics.map((d, i) => `  #${i + 1} [Line ${d.line}] ${d.code ? `(${d.code}) ` : ''}${d.message}\n     ↳ Fix: ${d.fixSuggestion}`).join('\n');

        setLogs(prev => [
          ...prev,
          {
            id: `diag-${Date.now()}`,
            type: 'diag',
            content: diagSummary,
            timestamp: Date.now()
          }
        ]);

        res.diagnostics.forEach(d => {
          logEvent(d.severity === 'error' ? 'error' : 'warn', `[Line ${d.line}] ${d.message} (Fix: ${d.fixSuggestion})`);
        });
      } else {
        const cleanMsg = `[DIAGNOSTICS]: Zero syntax or compiler errors detected in ${activeFile.name}! Code is valid.`;
        setLogs(prev => [
          ...prev,
          {
            id: `clean-${Date.now()}`,
            type: 'stdout',
            content: cleanMsg,
            timestamp: Date.now()
          }
        ]);
        logEvent('info', cleanMsg);
      }
    } catch (err: any) {
      console.error('Error check failed:', err);
      logEvent('error', `Failed to check errors: ${err.message}`);
    } finally {
      setIsCheckingErrors(false);
    }
  };

  // Scan all workspace files across all coding languages
  const handleScanEntireWorkspace = async () => {
    setIsScanningWorkspace(true);
    logEvent('info', 'Scanning entire workspace across all languages for errors...');

    try {
      const report = await universalCompilerService.scanWorkspace(files);
      setDiagnostics(report.diagnostics);

      const summary = `[WORKSPACE AUDIT]: Scanned ${report.totalFiles} compilable files. Detected ${report.totalErrors} error(s) and ${report.totalWarnings} warning(s) across ${report.filesWithErrors} file(s).`;

      setLogs(prev => [
        ...prev,
        {
          id: `ws-${Date.now()}`,
          type: report.totalErrors > 0 ? 'stderr' : 'stdout',
          content: summary + (report.diagnostics.length > 0 ? '\n' + report.diagnostics.map(d => ` • [${d.file}:${d.line}] ${d.message}`).join('\n') : ''),
          timestamp: Date.now()
        }
      ]);

      if (report.diagnostics.length > 0) {
        setActiveTab('diagnostics');
      }

      logEvent(report.totalErrors > 0 ? 'error' : 'info', summary);
    } catch (err: any) {
      console.error('Workspace scan failed:', err);
    } finally {
      setIsScanningWorkspace(false);
    }
  };

  // AI Auto-Fix code errors for the active file
  const handleAutoFixCode = async () => {
    if (!activeFile || !onCodeFixed) return;
    setIsFixingErrors(true);
    logEvent('info', `AI Assistant auto-patching errors in ${activeFile.name}...`);

    try {
      const fixResult = await universalCompilerService.autoFixCode(activeFile, diagnostics);

      if (fixResult.success && fixResult.fixedContent) {
        onCodeFixed(activeFile.name, fixResult.fixedContent);
        setDiagnostics([]);

        setLogs(prev => [
          ...prev,
          {
            id: `fix-${Date.now()}`,
            type: 'system',
            content: `[AI AUTO-FIX]: Successfully patched ${activeFile.name}.\nChangelog: ${fixResult.changelog}\nRe-compiling...`,
            timestamp: Date.now()
          }
        ]);

        logEvent('info', `Successfully repaired ${activeFile.name}: ${fixResult.changelog}`);

        // Re-execute to verify
        setTimeout(() => runCode(), 300);
      }
    } catch (err: any) {
      console.error('Auto fix error:', err);
      logEvent('error', `AI Auto-Fix failed: ${err.message}`);
    } finally {
      setIsFixingErrors(false);
    }
  };

  // Fix a single diagnostic line with AI
  const handleFixSingleDiagnostic = (diag: CompilerDiagnostic) => {
    const prompt = `Fix error in ${diag.file} at line ${diag.line}: "${diag.message}". Suggestion: "${diag.fixSuggestion}"`;
    window.dispatchEvent(new CustomEvent('aether-insert-ai-prompt', { detail: { prompt, autoSubmit: true } }));
    logEvent('info', `Generated AI repair prompt for ${diag.file}:${diag.line}`);
  };

  // Interactive CLI commands inside preview terminal
  const handleCliSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!cliInput.trim()) return;

    const cmd = cliInput.trim();
    setCliInput('');

    setLogs(prev => [
      ...prev,
      {
        id: `cli-${Date.now()}`,
        type: 'prompt',
        content: `$ ${cmd}`,
        timestamp: Date.now()
      }
    ]);

    if (cmd === 'clear' || cmd === 'cls') {
      setLogs([]);
      setDiagnostics([]);
      return;
    }

    if (cmd === 'run' || cmd === languageInfo.cmd) {
      runCode();
      return;
    }

    if (cmd === 'check' || cmd === 'errors') {
      checkForErrors();
      return;
    }

    if (cmd === 'scan' || cmd === 'all') {
      handleScanEntireWorkspace();
      return;
    }

    if (cmd === 'fix') {
      handleAutoFixCode();
      return;
    }

    if (cmd === 'help') {
      setLogs(prev => [
        ...prev,
        {
          id: `h-${Date.now()}`,
          type: 'system',
          content: `Universal Compiler Terminal Commands:
  - run               : Compile and execute active file (${activeFile?.name})
  - check             : Check active file for syntax & compiler errors
  - scan              : Scan all workspace files across all languages
  - fix               : AI Auto-patch detected syntax/runtime errors
  - ls                : List compilable files in workspace
  - clear             : Clear terminal output`,
          timestamp: Date.now()
        }
      ]);
      return;
    }

    if (cmd === 'ls') {
      setLogs(prev => [
        ...prev,
        {
          id: `ls-${Date.now()}`,
          type: 'stdout',
          content: runnableFiles.map(f => `  * ${f.name} (${universalCompilerService.getLanguageMeta(f.name).name})`).join('\n'),
          timestamp: Date.now()
        }
      ]);
      return;
    }

    // Default simulation
    setLogs(prev => [
      ...prev,
      {
        id: `cmdout-${Date.now()}`,
        type: 'stdout',
        content: `Executed "${cmd}" on ${languageInfo.name} environment.`,
        timestamp: Date.now()
      }
    ]);
  };

  const copyLogs = () => {
    const text = logs.map(l => l.content).join('\n');
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const errorCount = diagnostics.filter(d => d.severity === 'error').length;
  const warningCount = diagnostics.filter(d => d.severity === 'warning').length;

  return (
    <div className="flex flex-col h-full bg-[#05070c] text-[#00ff99] font-mono select-text overflow-hidden">
      {/* Top Toolbar */}
      <div className="h-11 bg-zinc-950/95 border-b border-zinc-800/80 px-2 sm:px-3 flex items-center justify-between gap-2 shrink-0 select-none">
        {/* Left: Active File & Runner Selector */}
        <div className="flex items-center gap-2 overflow-hidden min-w-0">
          <div className={`p-1.5 rounded-lg bg-zinc-900 border border-zinc-800 shrink-0 ${languageInfo.color}`}>
            <Terminal size={14} className={isCompiling ? "animate-pulse" : ""} />
          </div>
          
          <div className="flex items-center gap-1.5 min-w-0">
            {runnableFiles.length > 1 ? (
              <select
                value={activeFileName}
                onChange={(e) => {
                  setActiveFileName(e.target.value);
                  if (onSelectFile) onSelectFile(e.target.value);
                }}
                className="bg-zinc-900 border border-zinc-800 text-zinc-100 text-xs font-bold rounded-lg px-2 py-1 outline-none cursor-pointer hover:border-cyan-500/50 transition-colors truncate max-w-[130px] sm:max-w-[200px]"
                title="Select source file to compile/run"
              >
                {runnableFiles.map(f => (
                  <option key={f.name} value={f.name}>
                    {f.name} ({universalCompilerService.getLanguageMeta(f.name).id})
                  </option>
                ))}
              </select>
            ) : (
              <span className="text-xs font-black text-white tracking-wide truncate">
                {activeFile?.name || 'Code Runner'}
              </span>
            )}
            
            <span className="hidden md:inline-block text-[9px] px-2 py-0.5 rounded-full bg-cyan-950/60 border border-cyan-500/30 text-cyan-300 uppercase font-black tracking-wider">
              {languageInfo.name}
            </span>
          </div>
        </div>

        {/* Center / Right: Actions & Tools */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          {/* Scan Workspace Button */}
          <button
            onClick={handleScanEntireWorkspace}
            disabled={isScanningWorkspace || isCompiling}
            className="flex items-center gap-1 px-2 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 text-zinc-300 rounded-lg text-[11px] font-bold transition-all disabled:opacity-40 cursor-pointer"
            title="Scan entire workspace across all languages for compiler errors"
          >
            {isScanningWorkspace ? <Loader2 size={12} className="animate-spin text-purple-400" /> : <FileSearch size={12} className="text-purple-400" />}
            <span className="hidden xl:inline">Scan All Files</span>
          </button>

          {/* Check Errors Button */}
          <button
            onClick={checkForErrors}
            disabled={isCheckingErrors || isCompiling}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 text-zinc-200 rounded-lg text-[11px] font-bold transition-all disabled:opacity-40 cursor-pointer"
            title="Perform strict compiler type and syntax verification"
          >
            {isCheckingErrors ? <Loader2 size={12} className="animate-spin text-amber-400" /> : <Bug size={12} className="text-amber-400" />}
            <span className="hidden sm:inline">Check Errors</span>
          </button>

          {/* Primary RUN & COMPILE Button */}
          <button
            onClick={runCode}
            disabled={isCompiling}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-lg text-[11px] font-black uppercase tracking-wider transition-all shadow-md active:scale-95 cursor-pointer ${
              languageInfo.id === 'rust'
                ? 'bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-400 text-black'
                : languageInfo.id === 'python'
                ? 'bg-gradient-to-r from-yellow-400 to-amber-400 hover:from-yellow-300 text-black'
                : languageInfo.id === 'cpp' || languageInfo.id === 'c'
                ? 'bg-gradient-to-r from-sky-400 to-blue-500 hover:from-sky-300 text-black'
                : 'bg-gradient-to-r from-cyan-400 to-teal-400 hover:from-cyan-300 text-black'
            }`}
            title={`Compile and execute ${activeFile?.name}`}
          >
            {isCompiling ? (
              <Loader2 size={12} className="animate-spin text-black" />
            ) : (
              <Play size={12} fill="currentColor" />
            )}
            <span>{isCompiling ? 'COMPILING' : `RUN ${languageInfo.id.toUpperCase()}`}</span>
          </button>

          {/* View Tab Toggle (Terminal vs Diagnostics) */}
          <div className="flex items-center bg-zinc-900 border border-zinc-800 rounded-lg p-0.5">
            <button
              onClick={() => setActiveTab('terminal')}
              className={`px-2 py-0.5 text-[10px] font-bold rounded transition-colors ${
                activeTab === 'terminal' ? 'bg-zinc-800 text-cyan-300 shadow-sm' : 'text-zinc-500 hover:text-zinc-300'
              }`}
              title="Terminal Output"
            >
              Output
            </button>
            <button
              onClick={() => setActiveTab('diagnostics')}
              className={`px-2 py-0.5 text-[10px] font-bold rounded transition-colors relative flex items-center gap-1 ${
                activeTab === 'diagnostics' ? 'bg-zinc-800 text-amber-300 shadow-sm' : 'text-zinc-500 hover:text-zinc-300'
              }`}
              title="Compiler Diagnostics & Errors"
            >
              <span>Errors</span>
              {errorCount > 0 && (
                <span className="w-3.5 h-3.5 bg-red-500 text-white text-[8px] font-black rounded-full flex items-center justify-center">
                  {errorCount}
                </span>
              )}
            </button>
          </div>

          {/* Copy Logs */}
          <button
            onClick={copyLogs}
            className="p-1.5 text-zinc-500 hover:text-zinc-200 hover:bg-zinc-900 rounded-lg transition-colors"
            title="Copy Terminal Logs"
          >
            {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
          </button>

          {/* Clear Logs */}
          <button
            onClick={() => {
              setLogs([]);
              setDiagnostics([]);
            }}
            className="p-1.5 text-zinc-500 hover:text-red-400 hover:bg-zinc-900 rounded-lg transition-colors"
            title="Clear Terminal Output"
          >
            <Trash2 size={13} />
          </button>
        </div>
      </div>

      {/* Diagnostics / Error Warning Summary Bar */}
      {diagnostics.length > 0 && (
        <div className="bg-zinc-950/90 border-b border-zinc-800 p-2 sm:px-3 flex items-center justify-between gap-3 text-xs shrink-0 select-none">
          <div className="flex items-center gap-2 overflow-hidden">
            {errorCount > 0 ? (
              <div className="flex items-center gap-1.5 text-red-400 font-bold text-[11px]">
                <AlertCircle size={14} className="shrink-0 text-red-400 animate-pulse" />
                <span>{errorCount} compiler error(s) & {warningCount} warning(s) detected</span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 text-emerald-400 font-bold text-[11px]">
                <CheckCircle2 size={14} className="shrink-0" />
                <span>Code compiled cleanly with 0 fatal errors!</span>
              </div>
            )}
          </div>

          {errorCount > 0 && onCodeFixed && (
            <button
              onClick={handleAutoFixCode}
              disabled={isFixingErrors}
              className="px-2.5 py-1 bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-400 text-white rounded-lg text-[10px] font-black uppercase tracking-wider transition-all flex items-center gap-1 shrink-0 shadow-md cursor-pointer active:scale-95"
              title="AI automatically fixes all compiler errors in this file"
            >
              {isFixingErrors ? <Loader2 size={11} className="animate-spin" /> : <Sparkles size={11} />}
              <span>{isFixingErrors ? 'Patching Code...' : 'AI Auto-Fix File'}</span>
            </button>
          )}
        </div>
      )}

      {/* Main View Area (Terminal View vs Diagnostics Breakdown) */}
      {activeTab === 'diagnostics' && diagnostics.length > 0 ? (
        <div className="flex-1 p-4 overflow-y-auto custom-scrollbar-vertical space-y-3 bg-[#07090e]">
          <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
            <h3 className="text-xs font-black uppercase tracking-wider text-zinc-300 flex items-center gap-2">
              <Bug size={14} className="text-amber-400" />
              <span>Compiler Error Diagnostic Breakdown ({diagnostics.length} Issues)</span>
            </h3>
            <button
              onClick={() => setActiveTab('terminal')}
              className="text-[10px] text-cyan-400 hover:underline font-mono"
            >
              Switch to Terminal View →
            </button>
          </div>

          <div className="space-y-2.5">
            {diagnostics.map((diag, idx) => (
              <div
                key={idx}
                className={`p-3 rounded-xl border transition-all ${
                  diag.severity === 'error'
                    ? 'bg-red-950/20 border-red-500/30 hover:border-red-500/50'
                    : 'bg-amber-950/20 border-amber-500/30 hover:border-amber-500/50'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <span className={`px-1.5 py-0.5 rounded text-[9px] font-black uppercase tracking-wider ${
                      diag.severity === 'error' ? 'bg-red-500/20 text-red-400 border border-red-500/40' : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                    }`}>
                      {diag.severity}
                    </span>
                    <span className="font-mono text-xs font-bold text-white">
                      {diag.file}:{diag.line}{diag.column ? `:${diag.column}` : ''}
                    </span>
                    {diag.code && (
                      <span className="text-[10px] font-mono text-zinc-400 bg-zinc-900 px-1.5 py-0.2 rounded border border-zinc-800">
                        {diag.code}
                      </span>
                    )}
                  </div>

                  <button
                    onClick={() => handleFixSingleDiagnostic(diag)}
                    className="px-2 py-0.5 bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 rounded text-[10px] font-bold flex items-center gap-1 transition-colors cursor-pointer shrink-0"
                    title="Send repair prompt to AI Assistant"
                  >
                    <Wrench size={10} /> Fix with AI
                  </button>
                </div>

                <p className="text-xs text-zinc-200 mt-2 font-mono">{diag.message}</p>

                {diag.sourceSnippet && (
                  <div className="mt-2 p-2 bg-black/50 rounded-lg border border-zinc-800 text-[11px] font-mono text-red-300">
                    <code>{diag.sourceSnippet}</code>
                  </div>
                )}

                {diag.fixSuggestion && (
                  <div className="mt-2 text-[11px] text-emerald-400/90 font-mono flex items-start gap-1.5">
                    <span className="text-emerald-500 font-bold shrink-0">↳ Recommendation:</span>
                    <span>{diag.fixSuggestion}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Main Terminal Output Display */
        <div className="flex-1 p-4 overflow-y-auto custom-scrollbar-vertical text-xs leading-relaxed whitespace-pre-wrap bg-[#04060a]">
          {logs.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-zinc-600 gap-3 select-none">
              <div className="w-12 h-12 rounded-2xl bg-zinc-900/80 border border-zinc-800 flex items-center justify-center text-zinc-500">
                <Terminal size={24} className={languageInfo.color} />
              </div>
              <div className="text-center max-w-sm">
                <p className="text-xs font-bold text-zinc-300">{languageInfo.name} Universal Compiler Ready</p>
                <p className="text-[11px] text-zinc-500 mt-1">
                  Click <strong>RUN {languageInfo.id.toUpperCase()}</strong> or <strong>Check Errors</strong> to compile, execute, and inspect diagnostics for {activeFile?.name}.
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-1">
              {logs.map((entry) => (
                <div key={entry.id} className="leading-relaxed">
                  {entry.type === 'prompt' && (
                    <div className="text-cyan-400 font-bold font-mono py-1 flex items-center gap-1.5">
                      <ChevronRight size={12} className="text-cyan-500" />
                      <span>{entry.content}</span>
                    </div>
                  )}
                  {entry.type === 'stdout' && (
                    <div className="text-zinc-200 pl-4 font-mono whitespace-pre-wrap">
                      {entry.content}
                    </div>
                  )}
                  {entry.type === 'stderr' && (
                    <div className="text-red-400 bg-red-950/20 border border-red-500/30 p-2.5 rounded-lg my-1 font-mono whitespace-pre-wrap flex items-start gap-2">
                      <AlertCircle size={13} className="shrink-0 mt-0.5 text-red-400" />
                      <div className="flex-1 min-w-0">{entry.content}</div>
                    </div>
                  )}
                  {entry.type === 'system' && (
                    <div className="text-zinc-500 italic pl-4 font-mono text-[11px] py-0.5">
                      {entry.content}
                    </div>
                  )}
                  {entry.type === 'diag' && (
                    <div className="text-amber-300 bg-amber-950/20 border border-amber-500/30 p-2.5 rounded-lg my-1 font-mono whitespace-pre-wrap">
                      {entry.content}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
          <div ref={terminalEndRef} />
        </div>
      )}

      {/* Terminal Footer with Execution Statistics */}
      {executionStats && (
        <div className="px-3 py-1.5 bg-zinc-950/90 border-t border-zinc-800/80 text-[10px] text-zinc-400 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <CheckCircle2 size={11} className={executionStats.exitCode === 0 ? "text-emerald-400" : "text-amber-400"} />
            <span>Runtime: <strong className="text-zinc-200">{executionStats.runtime}</strong></span>
          </div>
          <div className="flex items-center gap-3">
            <span>Duration: <strong className="text-cyan-400">{executionStats.durationMs}ms</strong></span>
            <span>Exit Code: <strong className={executionStats.exitCode === 0 ? "text-emerald-400" : "text-red-400"}>{executionStats.exitCode}</strong></span>
          </div>
        </div>
      )}

      {/* Interactive Command Input Form */}
      <form onSubmit={handleCliSubmit} className="p-2.5 bg-zinc-950 border-t border-zinc-800 flex items-center gap-2 shrink-0">
        <div className="flex items-center gap-1.5 text-zinc-500 shrink-0 select-none">
          <ChevronRight size={13} className="text-cyan-400" />
          <span className="text-[9px] font-black bg-zinc-900 border border-zinc-800 px-1.5 py-0.5 rounded text-zinc-300">
            {languageInfo.id}
          </span>
        </div>
        <input
          ref={inputRef}
          type="text"
          value={cliInput}
          onChange={(e) => setCliInput(e.target.value)}
          placeholder={`Enter command (e.g. 'run', 'check', 'scan', 'fix', 'help')...`}
          className="flex-1 bg-transparent border-none outline-none text-zinc-100 text-xs placeholder:text-zinc-700 font-mono"
        />
        <button
          type="submit"
          disabled={!cliInput.trim() || isCompiling}
          className="p-1 text-zinc-500 hover:text-cyan-400 transition-all disabled:opacity-20 cursor-pointer"
        >
          <Send size={13} />
        </button>
      </form>
    </div>
  );
};

export default MultiLangTerminalPreview;
