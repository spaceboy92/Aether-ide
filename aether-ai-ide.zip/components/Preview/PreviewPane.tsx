import React, { useEffect, useState, useRef, useMemo } from "react";
import { FileNode } from "../../types";
import {
  RefreshCw,
  Monitor,
  Smartphone,
  Tablet,
  Grid2X2,
  MousePointerClick,
  ExternalLink,
  Loader2,
  Maximize2,
  X,
  Globe,
  Zap,
  Terminal,
  SearchCode,
  Shield,
  Cpu,
  Activity,
  Play,
  Settings,
  Wand2,
  ChevronDown,
  CheckCircle2,
  Code2,
  Rocket,
  ArrowLeft,
  ArrowRight,
  SlidersHorizontal,
  Lock,
  Wifi,
  FileCode,
  Check,
  Copy,
  AlertTriangle,
  FileText,
  Pin,
  MessageSquare,
  Trash2,
  Users,
  Sparkles,
  Share2,
  Bug,
  FileSearch,
  Filter,
  Flame,
  Layers,
  Compass,
  Search,
  Bookmark,
  Home,
  ShieldCheck
} from "lucide-react";
import { generateStandaloneHTML } from "../../services/fileService";
import { generateContent } from "../../services/aiService";
import { multiplayerService, MultiplayerRoom, FeedbackPin } from "../../services/multiplayerService";
import MultiLangTerminalPreview from "./MultiLangTerminalPreview";
import universalCompilerService, { CompilerDiagnostic } from "../../services/universalCompilerService";
import { NetworkHubModal } from "../Tools/NetworkHubModal";
import { Network } from "lucide-react";

interface PreviewPaneProps {
  files: FileNode[];
  setFiles?: React.Dispatch<React.SetStateAction<FileNode[]>>;
  autoPilotMode?: boolean;
  onLog?: (
    type: "info" | "warn" | "error",
    message: string,
    source: string,
  ) => void;
  activeSessionId?: string | null;
  onWorkspaceModified?: () => Promise<void>;
  onTerminalCommand?: (command: string) => Promise<void>;
  terminalLogs?: any[];
  onOpenDeploy?: () => void;
}

const VIEWPORTS: Record<string, { w: string; h: string; label: string; icon: any }> = {
  desktop: { w: "100%", h: "100%", label: "Desktop (Fluid)", icon: Monitor },
  tablet: { w: "768px", h: "100%", label: "Tablet (768px)", icon: Tablet },
  mobile: { w: "375px", h: "100%", label: "Mobile (375px)", icon: Smartphone },
  matrix: { w: "100%", h: "100%", label: "Multi-Device Matrix", icon: Grid2X2 },
};

type RuntimeMode = "web" | "compiler" | "url" | "audit";

interface UnifiedPreviewLog {
  id: string;
  type: "info" | "warn" | "error" | "diag";
  message: string;
  source?: string;
  file?: string;
  line?: number;
  code?: string;
  timestamp: number;
}

export const PreviewPane: React.FC<PreviewPaneProps> = ({
  files,
  setFiles,
  autoPilotMode = true,
  onLog,
  activeSessionId,
  onWorkspaceModified,
  onTerminalCommand,
  terminalLogs,
  onOpenDeploy,
}) => {
  const [srcDoc, setSrcDoc] = useState("");
  const [liveBlobUrl, setLiveBlobUrl] = useState<string>("");
  const [isLoading, setIsLoading] = useState(true);
  const [viewport, setViewport] = useState<string>("desktop");
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [key, setKey] = useState(0);
  const [runtimeMode, setRuntimeMode] = useState<RuntimeMode>("web");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isScanningAllErrors, setIsScanningAllErrors] = useState(false);
  const [auditResults, setAuditResults] = useState<{
    scores: { label: string; score: number; color: string; icon: any }[];
    vulnerabilities: { title: string; severity: string; desc: string }[];
  } | null>(null);

  // Unified Preview Logs (captures web errors, runtime errors, and compiler diagnostics across all languages)
  const [showLogs, setShowLogs] = useState(false);
  const [logFilter, setLogFilter] = useState<"all" | "error" | "warn" | "info">("all");
  const [previewLogs, setPreviewLogs] = useState<UnifiedPreviewLog[]>([]);

  // Active files tracking
  const [activeHtmlFileName, setActiveHtmlFileName] = useState<string>("index.html");
  const [activeSourceFileName, setActiveSourceFileName] = useState<string>("");

  // Top Address Bar State
  const [urlInput, setUrlInput] = useState("workspace://index.html");
  const [customWebUrl, setCustomWebUrl] = useState("");
  const [urlHistory, setUrlHistory] = useState<string[]>(["workspace://index.html"]);
  const [historyIndex, setHistoryIndex] = useState(0);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [isInspectorActive, setIsInspectorActive] = useState(false);
  const [inspectorNotification, setInspectorNotification] = useState<string | null>(null);
  const [isCorsBypassActive, setIsCorsBypassActive] = useState(true);
  const [showNetworkHub, setShowNetworkHub] = useState(false);

  // Deploy / Publish Modal State
  const [showPublishModal, setShowPublishModal] = useState(false);
  const [publishDomain, setPublishDomain] = useState("");
  const [isPublishing, setIsPublishing] = useState(false);
  const [publishedUrl, setPublishedUrl] = useState("");

  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [windowWidth, setWindowWidth] = useState(typeof window !== "undefined" ? window.innerWidth : 1200);

  // Compilable code files (Python, Rust, C++, C, Go, Java, TypeScript, etc.)
  const compilableFiles = useMemo(() => {
    return files.filter(f => universalCompilerService.isCompilableFile(f.name));
  }, [files]);

  // HTML and UI files
  const htmlFiles = useMemo(() => {
    return files.filter((f) => f.name.endsWith(".html") || f.name.endsWith(".htm"));
  }, [files]);

  // Set default active source file
  useEffect(() => {
    if (!activeSourceFileName && compilableFiles.length > 0) {
      // Prioritize non-client companion files if web UI exists
      const isClientScript = (name: string) => /^(script|app|main|index)\.(js|jsx|ts|tsx)$/i.test(name);
      if (htmlFiles.length > 0) {
        const backendOnly = compilableFiles.filter(f => !isClientScript(f.name));
        if (backendOnly.length > 0) {
          setActiveSourceFileName(backendOnly[0].name);
          return;
        }
      }
      setActiveSourceFileName(compilableFiles[0].name);
    }
  }, [compilableFiles, activeSourceFileName, htmlFiles]);

  useEffect(() => {
    const handleResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // Append a structured log into unified preview logs
  const appendPreviewLog = (
    type: "info" | "warn" | "error" | "diag",
    message: string,
    source: string = "Preview",
    file?: string,
    line?: number,
    code?: string
  ) => {
    const newLog: UnifiedPreviewLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      type,
      message,
      source,
      file,
      line,
      code,
      timestamp: Date.now()
    };

    setPreviewLogs((prev) => [newLog, ...prev.slice(0, 199)]);

    if (onLog && (type === "info" || type === "warn" || type === "error")) {
      onLog(type, message, source);
    }
  };

  // Listen for iframe debug messages and navigation events
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      if (event.data?.type === "AETHER_PREVIEW_LOG") {
        const { level, message } = event.data;
        appendPreviewLog(level || "info", message, "Web App Console");
      } else if (event.data?.type === "AETHER_INSPECT_ELEMENT") {
        const { tagName, id, className, textContent } = event.data;
        const promptText = `Modify the <${tagName.toLowerCase()}${id ? ' id="' + id + '"' : ''}${className ? ' class="' + className + '"' : ''}> component containing text "${textContent.trim().slice(0, 40)}": `;
        
        window.dispatchEvent(new CustomEvent('aether-insert-ai-prompt', { detail: { prompt: promptText } }));
        setInspectorNotification(`Selected <${tagName.toLowerCase()}> component! Prompt attached to AI Assistant.`);
        setTimeout(() => setInspectorNotification(null), 3500);
      } else if (event.data?.type === "AETHER_NAVIGATE_WORKSPACE") {
        const target = event.data.target;
        if (target) {
          handleSelectFile(target);
        }
      }
    };
    window.addEventListener("message", handleMessage);
    return () => window.removeEventListener("message", handleMessage);
  }, [historyIndex]);

  // Generate Virtual Bundle for Web Preview
  useEffect(() => {
    if (runtimeMode !== "web") {
      setIsLoading(false);
      return;
    }

    setIsLoading(true);

    const timeoutId = setTimeout(async () => {
      let finalContent = generateStandaloneHTML(files, activeHtmlFileName);

      // Add log hijacker script for Preview console tab
      const logHijacker = `
        <script>
          (function() {
            const originalLog = console.log;
            const originalError = console.error;
            const originalWarn = console.warn;

            function sendLog(level, args) {
              const message = Array.from(args).map(arg => {
                try {
                  if (arg instanceof Error) return arg.message + (arg.stack ? '\\n' + arg.stack : '');
                  return typeof arg === 'object' ? JSON.stringify(arg) : String(arg);
                } catch(e) {
                  return String(arg);
                }
              }).join(' ');
              
              if (message.includes('WebSocket') || 
                  message.includes('A component is changing an uncontrolled input') ||
                  message.includes('Warning: React does not recognize') ||
                  message.includes('vite:dep')) {
                 return;
              }
              
              window.parent.postMessage({ type: 'AETHER_PREVIEW_LOG', level, message }, '*');
            }

            console.log = (...args) => { originalLog(...args); sendLog('info', args); };
            console.error = (...args) => { originalError(...args); sendLog('error', args); };
            console.warn = (...args) => { originalWarn(...args); sendLog('warn', args); };

            window.onerror = function(message, source, lineno, colno, error) {
              if (message.includes('ResizeObserver') || message.includes('WebSocket')) return false;
              sendLog('error', [message + ' (Line ' + lineno + ':' + colno + ')']);
              return false;
            };

            window.addEventListener('unhandledrejection', function(event) {
              let msg = '';
              if (event.reason instanceof Error) {
                 msg = event.reason.message;
              } else if (event.reason && typeof event.reason === 'object') {
                 try { msg = JSON.stringify(event.reason); } catch(e) { msg = String(event.reason); }
              } else {
                 msg = String(event.reason || '');
              }
              if (msg.includes('WebSocket')) return;
              sendLog('error', ['Unhandled Promise Rejection: ' + msg]);
            });

            // Visual Component Inspector Script
            let activeOutlineEl = null;
            window.addEventListener('mouseover', function(e) {
              if (!window.__aether_inspector_enabled) return;
              e.stopPropagation();
              if (activeOutlineEl && activeOutlineEl !== e.target) {
                activeOutlineEl.style.outline = activeOutlineEl.__origOutline || '';
              }
              activeOutlineEl = e.target;
              activeOutlineEl.__origOutline = activeOutlineEl.style.outline;
              activeOutlineEl.style.outline = '2px solid #00d4ff';
            });

            window.addEventListener('click', function(e) {
              if (!window.__aether_inspector_enabled) return;
              e.preventDefault();
              e.stopPropagation();
              const el = e.target;
              window.parent.postMessage({
                type: 'AETHER_INSPECT_ELEMENT',
                tagName: el.tagName,
                id: el.id || '',
                className: el.className || '',
                textContent: (el.textContent || '').slice(0, 100)
              }, '*');
            }, true);
          })();
        </script>
      `;

      if (finalContent.includes("</head>")) {
        finalContent = finalContent.replace("</head>", `${logHijacker}</head>`);
      } else {
        finalContent = `${logHijacker}${finalContent}`;
      }

      setSrcDoc((prev) => (prev !== finalContent ? finalContent : prev));

      try {
        const blob = new Blob([finalContent], { type: "text/html" });
        const url = URL.createObjectURL(blob);
        setLiveBlobUrl((prevUrl) => {
          if (prevUrl) {
            try { URL.revokeObjectURL(prevUrl); } catch (e) {}
          }
          return url;
        });
      } catch (err) {
        console.warn("Could not create standalone blob url:", err);
      }

      setIsLoading(false);
    }, 200);

    return () => clearTimeout(timeoutId);
  }, [files, key, activeHtmlFileName, runtimeMode]);

  // Navigate Address Bar
  const handleNavigate = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const target = urlInput.trim();
    if (!target) return;

    if (target.startsWith("workspace://")) {
      const fileName = target.replace("workspace://", "").trim();
      handleSelectFile(fileName);
      return;
    }

    let finalUrl = target;
    if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
      if (finalUrl.startsWith("localhost") || finalUrl.startsWith("127.0.0.1")) {
        finalUrl = "http://" + finalUrl;
      } else if (/^[a-zA-Z0-9-]+\.[a-zA-Z]{2,}/.test(finalUrl)) {
        finalUrl = "https://" + finalUrl;
      } else {
        // Direct Search Query in Chrome / Google
        finalUrl = `https://www.google.com/search?q=${encodeURIComponent(finalUrl)}`;
      }
    }

    setCustomWebUrl(finalUrl);
    setRuntimeMode("url");
    setUrlHistory((prev) => [...prev.slice(0, historyIndex + 1), finalUrl]);
    setHistoryIndex((prev) => prev + 1);
  };

  const handleOpenDirectUrl = (url: string) => {
    let finalUrl = url.trim();
    if (!finalUrl.startsWith("http://") && !finalUrl.startsWith("https://")) {
      finalUrl = "https://" + finalUrl;
    }
    setUrlInput(finalUrl);
    setCustomWebUrl(finalUrl);
    setRuntimeMode("url");
    setUrlHistory((prev) => [...prev.slice(0, historyIndex + 1), finalUrl]);
    setHistoryIndex((prev) => prev + 1);
  };

  // Select any file and route intelligently to Web Preview vs Universal Compiler
  const handleSelectFile = (filename: string) => {
    const isHtml = filename.endsWith(".html") || filename.endsWith(".htm");
    const isCompilable = universalCompilerService.isCompilableFile(filename);

    if (isHtml) {
      setActiveHtmlFileName(filename);
      setRuntimeMode("web");
    } else {
      setActiveSourceFileName(filename);
      if (runtimeMode === "compiler") {
        setRuntimeMode("web");
      }
      // Automatically show the unified console log/terminal drawer when a backend file is loaded
      setShowLogs(true);
    }

    const route = `workspace://${filename}`;
    setUrlInput(route);
    setUrlHistory((prev) => [...prev.slice(0, historyIndex + 1), route]);
    setHistoryIndex((prev) => prev + 1);
  };

  const handleHistoryBack = () => {
    if (historyIndex > 0) {
      const newIdx = historyIndex - 1;
      setHistoryIndex(newIdx);
      const prevUrl = urlHistory[newIdx];
      setUrlInput(prevUrl);
      if (prevUrl.startsWith("workspace://")) {
        const fn = prevUrl.replace("workspace://", "");
        handleSelectFile(fn);
      } else {
        setRuntimeMode("url");
        setCustomWebUrl(prevUrl);
      }
    }
  };

  const handleHistoryForward = () => {
    if (historyIndex < urlHistory.length - 1) {
      const newIdx = historyIndex + 1;
      setHistoryIndex(newIdx);
      const nextUrl = urlHistory[newIdx];
      setUrlInput(nextUrl);
      if (nextUrl.startsWith("workspace://")) {
        const fn = nextUrl.replace("workspace://", "");
        handleSelectFile(fn);
      } else {
        setRuntimeMode("url");
        setCustomWebUrl(nextUrl);
      }
    }
  };

  // Popout Preview in Real Browser Window
  const handlePopoutNewTab = () => {
    if (runtimeMode === "url" && customWebUrl) {
      window.open(customWebUrl, "_blank", "noopener,noreferrer");
      return;
    }

    if (liveBlobUrl) {
      window.open(liveBlobUrl, "_blank");
    } else {
      const standalone = generateStandaloneHTML(files, activeHtmlFileName);
      const blob = new Blob([standalone], { type: "text/html" });
      const url = URL.createObjectURL(blob);
      window.open(url, "_blank");
    }
  };

  const handleCopyUrl = () => {
    const urlToCopy = runtimeMode === "url" ? customWebUrl : (liveBlobUrl || window.location.href);
    navigator.clipboard.writeText(urlToCopy);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  // Trigger universal workspace error check across ALL files and dump into preview log
  const handleGlobalErrorScan = async () => {
    setIsScanningAllErrors(true);
    setShowLogs(true);
    appendPreviewLog("info", "Starting Universal Workspace Compilation & Error Scan across all languages...", "Compiler Engine");

    try {
      const report = await universalCompilerService.scanWorkspace(files);

      if (report.totalErrors > 0 || report.totalWarnings > 0) {
        appendPreviewLog(
          "error",
          `Scan Complete: Found ${report.totalErrors} error(s) and ${report.totalWarnings} warning(s) in ${report.filesWithErrors} file(s).`,
          "Universal Compiler"
        );

        report.diagnostics.forEach((diag) => {
          appendPreviewLog(
            diag.severity === "error" ? "error" : "warn",
            `[${diag.file}:${diag.line}] ${diag.code ? `(${diag.code}) ` : ''}${diag.message} -> Fix: ${diag.fixSuggestion || 'Check syntax'}`,
            `[${diag.file}]`,
            diag.file,
            diag.line,
            diag.code
          );
        });
      } else {
        appendPreviewLog(
          "info",
          `✅ 100% Clean! Scanned ${report.totalFiles} code files across all languages with 0 compiler errors.`,
          "Universal Compiler"
        );
      }
    } catch (err: any) {
      appendPreviewLog("error", `Workspace error scan failed: ${err.message}`, "System");
    } finally {
      setIsScanningAllErrors(false);
    }
  };

  // Run AI Code Audit
  const runAudit = async () => {
    setIsAnalyzing(true);
    try {
      const codeContext = files.map((f) => `File: ${f.name}\n${f.content}`).join("\n\n");
      const prompt = `You are a master code auditor. Analyze the following project files across all languages and output a JSON response.
      
Respond ONLY with raw JSON matching this format exactly:
{
  "scores": [
    { "label": "Security", "score": number },
    { "label": "Performance", "score": number },
    { "label": "Stability", "score": number }
  ],
  "vulnerabilities": [
    { "title": "string", "severity": "Critical|Medium|Low", "desc": "string" }
  ]
}

Code:
${codeContext.substring(0, 15000)}
`;
      const response = await generateContent("gemini-3.7-flash", prompt, { responseMimeType: "application/json" });
      if (!response) throw new Error("Empty AI response received.");
      const parsed = JSON.parse(response);

      const mappedScores = parsed.scores.map((s: any) => ({
        label: s.label,
        score: s.score,
        icon: s.label === "Security" ? Shield : s.label === "Performance" ? Cpu : Activity,
        color: s.label === "Security" ? "text-emerald-400" : s.label === "Performance" ? "text-cyan-400" : "text-amber-400",
      }));

      setAuditResults({ scores: mappedScores, vulnerabilities: parsed.vulnerabilities || [] });
    } catch (err) {
      console.error(err);
      appendPreviewLog("error", "AI Code Audit failed to parse or execute.", "Neural Audit");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const [isCompiling, setIsCompiling] = useState(false);
  const lastFileContentsRef = useRef<Record<string, string>>({});
  const autoRunTimeoutRef = useRef<any>(null);

  const executeSourceFile = async (filename: string) => {
    if (!filename) return;

    const activeFile = files.find((f) => f.name === filename);
    if (!activeFile) return;

    setIsCompiling(true);
    setShowLogs(true);
    const langInfo = universalCompilerService.getLanguageMeta(activeFile.name);

    appendPreviewLog("info", `Auto-Executing ${activeFile.name} (${langInfo.compiler})`, "Compiler");

    try {
      const result = await universalCompilerService.compileAndExecute(activeFile, files);

      if (result.stdout && result.stdout.trim()) {
        appendPreviewLog("info", result.stdout.trim(), "Stdout");
      }

      if (result.stderr && result.stderr.trim()) {
        appendPreviewLog("error", result.stderr.trim(), "Stderr");
      }

      if (result.diagnostics && result.diagnostics.length > 0) {
        result.diagnostics.forEach((diag) => {
          appendPreviewLog(
            "diag",
            `${diag.message} (Line ${diag.line})`,
            "Diagnostic",
            activeFile.name,
            diag.line,
            diag.code
          );
        });
      }

      const statusMsg = `Process finished with exit code ${result.exitCode ?? 0} (took ${result.durationMs || 0}ms)`;
      appendPreviewLog(result.exitCode === 0 ? "info" : "error", statusMsg, "System");
    } catch (err: any) {
      appendPreviewLog("error", `Failed to compile and execute: ${err.message}`, "Compiler Engine");
    } finally {
      setIsCompiling(false);
    }
  };

  const executeSelectedSourceFile = async () => {
    const filename = activeSourceFileName || (compilableFiles[0]?.name);
    if (!filename) {
      appendPreviewLog("warn", "No compilable code file loaded in the workspace.", "System");
      return;
    }
    await executeSourceFile(filename);
  };

  // Completely Hands-Free Automatic Compiler Watcher for Backend & Standalone Source Files
  useEffect(() => {
    // If in web mode with an active HTML entry file, the live iframe preview handles web scripts natively
    const isClientCompanion = (name: string) => /^(script|app|main|index)\.(js|jsx|ts|tsx)$/i.test(name);
    const hasWebEntry = htmlFiles.length > 0 && runtimeMode === "web";

    let fileToAutoRun: string | null = null;

    for (const file of files) {
      if (universalCompilerService.isCompilableFile(file.name)) {
        // Skip auto-running client web companion scripts into Node runner if web preview is live
        if (hasWebEntry && isClientCompanion(file.name)) {
          lastFileContentsRef.current[file.name] = file.content;
          continue;
        }

        const prevContent = lastFileContentsRef.current[file.name];
        if (prevContent !== undefined && prevContent !== file.content) {
          fileToAutoRun = file.name;
        }
        // Sync cache
        lastFileContentsRef.current[file.name] = file.content;
      }
    }

    // Also run if a standalone backend compilable file is newly activated and has not been run yet
    if (!fileToAutoRun && activeSourceFileName) {
      if (!hasWebEntry || !isClientCompanion(activeSourceFileName)) {
        const activeFile = files.find((f) => f.name === activeSourceFileName);
        if (activeFile && lastFileContentsRef.current[activeSourceFileName] === undefined) {
          lastFileContentsRef.current[activeSourceFileName] = activeFile.content;
          fileToAutoRun = activeSourceFileName;
        }
      }
    }

    if (fileToAutoRun) {
      const runTarget = fileToAutoRun;

      if (autoRunTimeoutRef.current) {
        clearTimeout(autoRunTimeoutRef.current);
      }

      autoRunTimeoutRef.current = setTimeout(() => {
        executeSourceFile(runTarget);
      }, 800);
    }

    return () => {
      if (autoRunTimeoutRef.current) {
        clearTimeout(autoRunTimeoutRef.current);
      }
    };
  }, [files, activeSourceFileName, htmlFiles, runtimeMode]);

  // Filtered Preview Logs
  const filteredLogs = useMemo(() => {
    if (logFilter === "all") return previewLogs;
    return previewLogs.filter((l) => l.type === logFilter);
  }, [previewLogs, logFilter]);

  const errorCount = previewLogs.filter((l) => l.type === "error").length;
  const warnCount = previewLogs.filter((l) => l.type === "warn").length;

  // Render Main Viewport Content
  const renderPreviewContent = () => {
    if (runtimeMode === "audit") {
      return (
        <div className="w-full h-full bg-[#090b10] text-white p-6 font-mono overflow-y-auto custom-scrollbar-vertical">
          <div className="flex items-center justify-between mb-8 pb-4 border-b border-zinc-800">
            <div className="flex items-center gap-3">
              <SearchCode size={28} className="text-cyan-400" />
              <div>
                <h2 className="text-base font-black uppercase tracking-widest text-white">Neural Code Audit</h2>
                <p className="text-xs text-zinc-400">Deep structural security, compiler safety & performance analysis</p>
              </div>
            </div>
            <button
              onClick={() => setRuntimeMode("web")}
              className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg text-xs font-bold transition-colors cursor-pointer"
            >
              Back to Preview
            </button>
          </div>

          {!auditResults ? (
            <div className="flex flex-col items-center justify-center p-12 bg-zinc-900/60 border border-zinc-800 rounded-2xl">
              <Wand2 size={40} className="text-cyan-400 mb-4 opacity-80 animate-pulse" />
              <h3 className="text-sm font-bold text-white mb-2 uppercase tracking-widest">Ready to Inspect Codebase</h3>
              <p className="text-xs text-zinc-400 mb-6 text-center max-w-sm">
                Launch a deep security, performance, and multi-language compiler safety audit across all workspace files.
              </p>
              <button
                onClick={runAudit}
                disabled={isAnalyzing}
                className="px-6 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-black font-black uppercase tracking-wider text-xs rounded-xl transition-all shadow-lg shadow-cyan-500/10 flex items-center gap-2 cursor-pointer"
              >
                {isAnalyzing ? <Loader2 size={16} className="animate-spin" /> : <Play size={16} />}
                {isAnalyzing ? "Analyzing Codebase..." : "Start Neural Audit"}
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {auditResults.scores.map((stat, i) => {
                  const Icon = stat.icon || Activity;
                  return (
                    <div key={i} className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-4">
                      <div className="flex justify-between items-center mb-2">
                        <Icon size={18} className={stat.color} />
                        <span className="text-xl font-bold text-white">{stat.score}%</span>
                      </div>
                      <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">{stat.label}</p>
                    </div>
                  );
                })}
              </div>

              <div className="space-y-3">
                <h3 className="text-xs font-black uppercase tracking-widest text-cyan-400">Findings & Vulnerabilities</h3>
                {auditResults.vulnerabilities.length === 0 ? (
                  <div className="p-4 bg-emerald-500/10 text-emerald-400 text-xs font-bold border border-emerald-500/20 rounded-xl flex items-center gap-2">
                    <CheckCircle2 size={18} />
                    Clean codebase! No critical vulnerabilities detected.
                  </div>
                ) : (
                  auditResults.vulnerabilities.map((v, i) => (
                    <div key={i} className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-4 flex justify-between items-center gap-4">
                      <div>
                        <p className="text-xs font-bold text-white mb-1">{v.title}</p>
                        <p className="text-[11px] text-zinc-400">{v.desc}</p>
                      </div>
                      <span className={`text-[9px] font-black px-2.5 py-1 rounded-full uppercase shrink-0 ${
                        v.severity === "Critical" || v.severity === "High"
                          ? "bg-red-500/20 text-red-400 border border-red-500/30"
                          : "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                      }`}>
                        {v.severity}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>
      );
    }

    if (runtimeMode === "url") {
      const getRenderUrl = (url: string) => {
        if (!url) return "/api/proxy?url=https%3A%2F%2Fwww.google.com";
        if (url.startsWith("http://localhost") || url.startsWith("http://127.0.0.1")) {
          return url;
        }
        return `/api/proxy?url=${encodeURIComponent(url)}`;
      };

      const currentActiveUrl = customWebUrl || "https://www.google.com";

      const bookmarks = [
        { name: "Google", url: "https://www.google.com", icon: "🔍" },
        { name: "GitHub", url: "https://github.com", icon: "🐙" },
        { name: "MDN Docs", url: "https://developer.mozilla.org", icon: "📖" },
        { name: "Stack Overflow", url: "https://stackoverflow.com", icon: "💬" },
        { name: "NPM", url: "https://www.npmjs.com", icon: "📦" },
        { name: "Tailwind CSS", url: "https://tailwindcss.com", icon: "🎨" },
        { name: "Google AI", url: "https://aistudio.google.com", icon: "🤖" },
        { name: "Wikipedia", url: "https://www.wikipedia.org", icon: "🌐" },
      ];

      return (
        <div className="w-full h-full flex flex-col bg-[#0b0d14] text-white select-none">
          {/* Chrome Browser Controls & Sub-Header */}
          <div className="bg-[#12151f] border-b border-zinc-800/80 px-3 py-1.5 flex flex-col gap-1.5 shrink-0 z-10">
            {/* Top Bar: URL + Security + Quick Actions */}
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 text-zinc-400">
                <button
                  onClick={() => handleOpenDirectUrl("https://www.google.com")}
                  className="p-1 hover:text-cyan-400 hover:bg-zinc-800 rounded transition-colors cursor-pointer"
                  title="Google Home"
                >
                  <Home size={13} />
                </button>
              </div>

              <div className="flex-1 flex items-center bg-zinc-950 border border-zinc-800 rounded-lg px-2.5 py-1 text-xs gap-2 font-mono">
                <div className="flex items-center gap-1 text-emerald-400 shrink-0" title="Secure Proxy Connection">
                  <ShieldCheck size={12} />
                  <span className="text-[9px] font-bold uppercase hidden md:inline">HTTPS</span>
                </div>
                <input
                  type="text"
                  value={urlInput.startsWith("workspace://") ? currentActiveUrl : urlInput}
                  onChange={(e) => setUrlInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      handleNavigate();
                    }
                  }}
                  placeholder="Enter any open link (e.g. google.com, github.com) or search query..."
                  className="w-full bg-transparent focus:outline-none text-zinc-200 text-[11px] placeholder:text-zinc-600 font-mono"
                />
                <button
                  onClick={() => handleNavigate()}
                  className="px-2 py-0.5 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 rounded text-[10px] font-bold cursor-pointer transition-colors shrink-0 flex items-center gap-1"
                >
                  <Search size={10} />
                  <span className="hidden sm:inline">Go</span>
                </button>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => handlePopoutNewTab()}
                  className="p-1.5 bg-zinc-800/80 hover:bg-zinc-700 text-zinc-300 hover:text-white rounded-lg transition-colors cursor-pointer flex items-center gap-1 text-[10px] font-bold"
                  title="Open in Real Chrome Browser Window"
                >
                  <ExternalLink size={12} />
                  <span className="hidden lg:inline">Chrome Tab</span>
                </button>
              </div>
            </div>

            {/* Bookmarks Bar */}
            <div className="flex items-center gap-1.5 overflow-x-auto custom-scrollbar-horizontal py-0.5">
              <span className="text-[9px] font-bold uppercase tracking-wider text-zinc-500 flex items-center gap-1 shrink-0 mr-1">
                <Bookmark size={10} className="text-zinc-500" /> Quick Links:
              </span>
              {bookmarks.map((bm, i) => (
                <button
                  key={i}
                  onClick={() => handleOpenDirectUrl(bm.url)}
                  className={`px-2 py-0.5 text-[10px] font-medium rounded-md border flex items-center gap-1 shrink-0 transition-all cursor-pointer ${
                    currentActiveUrl.includes(bm.name.toLowerCase().replace(" ", ""))
                      ? "bg-cyan-500/20 text-cyan-300 border-cyan-500/40"
                      : "bg-zinc-900/90 text-zinc-400 hover:text-zinc-200 border-zinc-800 hover:border-zinc-700"
                  }`}
                >
                  <span>{bm.icon}</span>
                  <span>{bm.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Browser Iframe Engine */}
          <div className="w-full flex-1 relative bg-white overflow-hidden">
            <iframe
              key={`url_${currentActiveUrl}_${key}`}
              src={getRenderUrl(currentActiveUrl)}
              className="w-full h-full border-none bg-white block"
              sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-modals allow-downloads allow-top-navigation-by-user-activation"
              allow="accelerometer; camera; encrypted-media; geolocation; gyroscope; microphone; midi; payment; usb; clipboard-read; clipboard-write"
            />
          </div>
        </div>
      );
    }

    // Default Workspace Web Preview
    return (
      <div className="w-full h-full min-h-full flex-1 flex flex-col relative bg-transparent" style={{ width: "100%", height: "100%", minHeight: "100%" }}>
        <iframe
          id="main-preview-iframe"
          key={`doc_${key}_${activeHtmlFileName}`}
          ref={iframeRef}
          srcDoc={srcDoc}
          onLoad={() => setIsLoading(false)}
          className="w-full h-full min-h-full flex-1 border-none bg-transparent block"
          style={{ width: "100%", height: "100%", minHeight: "100%", border: "none" }}
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox allow-modals allow-downloads allow-top-navigation-by-user-activation"
          allow="accelerometer; camera; encrypted-media; geolocation; gyroscope; microphone; midi; payment; usb; clipboard-read; clipboard-write"
        />
      </div>
    );
  };

  return (
    <div
      id="aether-preview-container"
      className={`w-full h-full min-h-full flex-1 flex flex-col bg-[#08090e] border-none overflow-hidden relative ${
        isFullscreen ? "fixed inset-0 z-[9999] bg-[#08090e]" : ""
      }`}
      style={{ width: "100%", height: "100%", minHeight: "100%" }}
    >
      {/* Top Modern Address Bar & Mode Navigation Group */}
      <div className="h-11 bg-zinc-950/95 border-b border-zinc-800/80 px-2 sm:px-3 flex items-center justify-between gap-1.5 sm:gap-2 shrink-0 z-30 select-none">
        {/* Left: Navigation Buttons & Mode Selector */}
        <div className="flex items-center gap-1 shrink-0">
          <button
            onClick={handleHistoryBack}
            disabled={historyIndex <= 0}
            className="hidden sm:block p-1.5 text-zinc-400 hover:text-white disabled:opacity-30 disabled:hover:text-zinc-400 rounded-lg transition-colors cursor-pointer"
            title="Back"
          >
            <ArrowLeft size={14} />
          </button>
          <button
            onClick={handleHistoryForward}
            disabled={historyIndex >= urlHistory.length - 1}
            className="hidden sm:block p-1.5 text-zinc-400 hover:text-white disabled:opacity-30 disabled:hover:text-zinc-400 rounded-lg transition-colors cursor-pointer"
            title="Forward"
          >
            <ArrowRight size={14} />
          </button>
          <button
            onClick={() => setKey((k) => k + 1)}
            className="p-1.5 text-zinc-300 hover:text-cyan-400 hover:bg-zinc-900 rounded-lg transition-colors cursor-pointer active:scale-95"
            title="Reload Preview"
          >
            <RefreshCw size={14} className={isLoading ? "animate-spin text-cyan-400" : ""} />
          </button>

          {/* Mode Switcher Tabs */}
          <div className="flex items-center bg-zinc-900 border border-zinc-800 rounded-lg p-0.5 ml-1">
            <button
              onClick={() => setRuntimeMode("web")}
              className={`px-2 py-1 text-[10px] font-bold rounded-md flex items-center gap-1 transition-all cursor-pointer ${
                runtimeMode === "web" ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 shadow-sm" : "text-zinc-400 hover:text-zinc-200"
              }`}
              title="Workspace Live App Preview"
            >
              <Globe size={11} />
              <span className="hidden md:inline">Web Preview</span>
            </button>
            <button
              onClick={() => {
                setRuntimeMode("url");
                if (!customWebUrl) {
                  setCustomWebUrl("https://www.google.com");
                  setUrlInput("https://www.google.com");
                }
              }}
              className={`px-2 py-1 text-[10px] font-bold rounded-md flex items-center gap-1 transition-all cursor-pointer ${
                runtimeMode === "url" ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 shadow-sm" : "text-zinc-400 hover:text-zinc-200"
              }`}
              title="Chrome Web Browser - Load any open link or Google"
            >
              <Compass size={11} />
              <span className="hidden md:inline">Web Browser</span>
            </button>
            <button
              onClick={() => setRuntimeMode("audit")}
              className={`px-2 py-1 text-[10px] font-bold rounded-md flex items-center gap-1 transition-all cursor-pointer ${
                runtimeMode === "audit" ? "bg-purple-500/20 text-purple-300 border border-purple-500/30 shadow-sm" : "text-zinc-400 hover:text-zinc-200"
              }`}
              title="Neural Codebase Audit"
            >
              <Shield size={11} />
              <span className="hidden xl:inline">Audit</span>
            </button>
          </div>
        </div>

        {/* Center: Live URL & Route Address Bar */}
        <form onSubmit={handleNavigate} className="hidden sm:flex flex-1 max-w-xl items-center">
          <div className="w-full h-7 bg-zinc-900/90 border border-zinc-800 focus-within:border-cyan-500/50 rounded-lg px-2.5 flex items-center gap-2 text-xs font-mono transition-all">
            {universalCompilerService.isCompilableFile(urlInput.replace("workspace://", "")) ? (
              <Terminal size={12} className="text-amber-400 shrink-0 animate-pulse" />
            ) : runtimeMode === "url" ? (
              <Globe size={12} className="text-cyan-400 shrink-0" />
            ) : (
              <Zap size={12} className="text-cyan-400 shrink-0" />
            )}
            
            <input
              type="text"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              className="w-full bg-transparent focus:outline-none text-zinc-200 placeholder:text-zinc-600 text-[11px] truncate font-mono"
              placeholder="Enter open link (e.g. google.com, github.com), search query, or workspace://..."
            />

            {/* Quick File Selector Dropdown covering ALL languages */}
            {files.length > 0 && (
              <select
                value={urlInput.replace("workspace://", "")}
                onChange={(e) => handleSelectFile(e.target.value)}
                className="bg-zinc-800 hover:bg-zinc-700 text-cyan-300 font-mono text-[10px] py-0.5 px-1.5 rounded border border-zinc-700 outline-none cursor-pointer shrink-0 transition-colors max-w-[140px] truncate"
                title="Select source or web file to preview"
              >
                {htmlFiles.length > 0 && (
                  <optgroup label="🌐 Web UI Files">
                    {htmlFiles.map((f) => (
                      <option key={f.id} value={f.name}>
                        📄 {f.name}
                      </option>
                    ))}
                  </optgroup>
                )}
                {compilableFiles.length > 0 && (
                  <optgroup label="⚡ Universal Code Files">
                    {compilableFiles.map((f) => (
                      <option key={f.id} value={f.name}>
                        ⚡ {f.name} ({universalCompilerService.getLanguageMeta(f.name).id})
                      </option>
                    ))}
                  </optgroup>
                )}
              </select>
            )}

            <button
              type="button"
              onClick={handleCopyUrl}
              className="p-1 text-zinc-500 hover:text-zinc-300 transition-colors shrink-0"
              title="Copy Preview URL"
            >
              {copiedUrl ? <Check size={11} className="text-emerald-400" /> : <Copy size={11} />}
            </button>
          </div>
        </form>

        {/* Right: Tools & Window Controls */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          {/* CORS Proxy Bypass Button */}
          {runtimeMode === "web" && (
            <button
              onClick={() => {
                const next = !isCorsBypassActive;
                setIsCorsBypassActive(next);
                const iframe = document.querySelector('iframe');
                if (iframe && iframe.contentWindow) {
                  (iframe.contentWindow as any).__AETHER_CORS_BYPASS_ENABLED__ = next;
                }
                appendPreviewLog(
                  "info",
                  next
                    ? "🛡️ CORS Proxy Bypass ENABLED: External APIs, CDNs, and custom IP/chat endpoints will transparently route via server proxy."
                    : "⚠️ CORS Proxy Bypass DISABLED: Direct browser network requests only.",
                  "Network Proxy"
                );
              }}
              className={`p-1.5 rounded-lg border text-[11px] transition-all flex items-center gap-1 cursor-pointer ${
                isCorsBypassActive
                  ? "bg-emerald-500/15 border-emerald-500/30 text-emerald-300 font-bold shadow-[0_0_8px_rgba(16,185,129,0.15)]"
                  : "bg-zinc-900/80 hover:bg-zinc-800 border-zinc-800 text-zinc-500 hover:text-zinc-300"
              }`}
              title={isCorsBypassActive ? "CORS Proxy Bypass Active: External APIs, CDNs & custom IPs bypass CORS" : "Enable CORS Proxy Bypass"}
            >
              <Shield size={12} className={isCorsBypassActive ? "text-emerald-400" : "text-zinc-500"} />
              <span className="hidden xl:inline text-[10px]">CORS Bypass</span>
            </button>
          )}

          {/* Network & Server Ports Hub Button */}
          <button
            onClick={() => setShowNetworkHub(true)}
            className="p-1.5 text-zinc-300 hover:text-cyan-400 bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-800 rounded-lg transition-all cursor-pointer flex items-center gap-1 text-[11px]"
            title="Server Ports, Local IPs & Network Hub"
          >
            <Network size={13} className="text-cyan-400" />
            <span className="hidden xl:inline text-[10px] font-bold text-zinc-300">Ports & IPs</span>
          </button>

          {/* Universal Error Scanner Button */}
          <button
            onClick={handleGlobalErrorScan}
            disabled={isScanningAllErrors}
            className="p-1.5 text-zinc-300 hover:text-amber-300 bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-800 rounded-lg transition-all cursor-pointer flex items-center gap-1 text-[11px]"
            title="Scan Entire Workspace for Errors across all languages"
          >
            {isScanningAllErrors ? <Loader2 size={13} className="animate-spin text-amber-400" /> : <FileSearch size={13} className="text-amber-400" />}
            <span className="hidden xl:inline text-[10px] font-bold text-zinc-300">Check Errors</span>
          </button>

          {/* Component Inspector Button */}
          {runtimeMode === "web" && (
            <button
              onClick={() => {
                const next = !isInspectorActive;
                setIsInspectorActive(next);
                const iframe = document.querySelector('iframe');
                if (iframe && iframe.contentWindow) {
                  (iframe.contentWindow as any).__aether_inspector_enabled = next;
                }
              }}
              className={`p-1.5 rounded-lg border text-[11px] transition-all flex items-center gap-1 cursor-pointer ${
                isInspectorActive 
                  ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-300 font-bold shadow-[0_0_12px_rgba(0,212,255,0.2)] animate-pulse' 
                  : 'bg-zinc-900/80 hover:bg-zinc-800 border-zinc-800 text-zinc-400 hover:text-white'
              }`}
              title="Visual Component Inspector"
            >
              <MousePointerClick size={13} />
            </button>
          )}

          {/* Viewport Toggles (Desktop Web View only) */}
          {runtimeMode === "web" && (
            <div className="hidden lg:flex items-center bg-zinc-900 border border-zinc-800 rounded-lg p-0.5">
              {(["desktop", "tablet", "mobile", "matrix"] as const).map((vpKey) => {
                const VpIcon = VIEWPORTS[vpKey].icon;
                return (
                  <button
                    key={vpKey}
                    onClick={() => setViewport(vpKey)}
                    className={`p-1 rounded text-xs transition-colors ${
                      viewport === vpKey ? "bg-zinc-800 text-cyan-400 shadow-sm" : "text-zinc-500 hover:text-zinc-300"
                    }`}
                    title={VIEWPORTS[vpKey].label}
                  >
                    <VpIcon size={13} />
                  </button>
                );
              })}
            </div>
          )}

          {/* Open in New Tab Button */}
          <button
            onClick={handlePopoutNewTab}
            className="p-1.5 text-zinc-300 hover:text-cyan-400 bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-800 rounded-lg transition-all cursor-pointer flex items-center gap-1 text-[11px]"
            title="Open in Browser Tab"
          >
            <ExternalLink size={13} />
          </button>

          {/* Console & Error Logs Toggle */}
          <button
            onClick={() => setShowLogs(!showLogs)}
            className={`p-1.5 rounded-lg transition-all relative cursor-pointer ${
              showLogs ? "bg-zinc-800 text-cyan-400" : "text-zinc-400 hover:text-white bg-zinc-900/80 hover:bg-zinc-800 border border-zinc-800"
            }`}
            title="Preview Console & Error Logs"
          >
            <Terminal size={13} />
            {errorCount > 0 && (
              <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-red-500 text-white text-[8px] font-black flex items-center justify-center rounded-full animate-pulse">
                {errorCount}
              </span>
            )}
          </button>

          {/* Fullscreen Toggle */}
          <button
            onClick={() => setIsFullscreen(!isFullscreen)}
            className="p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-900 border border-zinc-800 rounded-lg transition-colors hidden sm:block cursor-pointer"
            title={isFullscreen ? "Exit Fullscreen" : "Fullscreen"}
          >
            {isFullscreen ? <X size={13} /> : <Maximize2 size={13} />}
          </button>

          {/* Deploy Button */}
          <button
            onClick={() => {
              if (onOpenDeploy) {
                onOpenDeploy();
              } else {
                setShowPublishModal(true);
              }
            }}
            className="px-2.5 sm:px-3 py-1 bg-gradient-to-r from-cyan-500 to-emerald-400 hover:brightness-110 text-black font-black text-[10px] uppercase tracking-wider rounded-lg transition-all shadow-[0_0_12px_rgba(6,182,212,0.3)] flex items-center gap-1 cursor-pointer active:scale-95 shrink-0"
            title="Deploy Application"
          >
            <Rocket size={12} className="text-black fill-black" />
            <span className="hidden xs:inline">DEPLOY</span>
          </button>
        </div>
      </div>

      {/* Main Viewport Container */}
      <div className="flex-1 w-full h-full min-h-full relative flex flex-col items-center justify-center bg-[#07090e] overflow-hidden">
        {/* Toast / Notification Banner */}
        {inspectorNotification && (
          <div className="absolute top-4 z-50 bg-cyan-950/90 border border-cyan-500/50 text-cyan-200 px-4 py-2 rounded-xl text-xs font-bold shadow-[0_0_20px_rgba(0,212,255,0.3)] flex items-center gap-2 animate-in fade-in slide-in-from-top-3">
            <MousePointerClick size={14} className="text-cyan-400" />
            <span>{inspectorNotification}</span>
          </div>
        )}

        {/* Loading Overlay */}
        {isLoading && runtimeMode === "web" && (
          <div className="absolute inset-0 z-40 flex flex-col items-center justify-center bg-black/70 backdrop-blur-sm gap-3">
            <Loader2 size={32} className="text-cyan-400 animate-spin" />
            <span className="text-[10px] font-mono uppercase tracking-widest text-cyan-400 animate-pulse">
              Compiling Web Preview...
            </span>
          </div>
        )}

        {/* Matrix View Multi-Device Mode */}
        {viewport === 'matrix' && runtimeMode === 'web' ? (
          <div className="w-full h-full p-4 overflow-auto custom-scrollbar bg-[#05070a] grid grid-cols-1 xl:grid-cols-3 gap-4 items-start">
            <div className="flex flex-col items-center space-y-2">
              <span className="text-[10px] font-mono font-bold text-cyan-400 uppercase tracking-widest flex items-center gap-1.5">
                <Smartphone size={12} /> Mobile (375px)
              </span>
              <div className="w-[375px] h-[667px] max-w-full rounded-2xl border-2 border-zinc-800 shadow-2xl bg-zinc-950 overflow-hidden relative">
                <iframe srcDoc={srcDoc} className="w-full h-full border-none" title="Preview Mobile Matrix" />
              </div>
            </div>

            <div className="flex flex-col items-center space-y-2">
              <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-widest flex items-center gap-1.5">
                <Tablet size={12} /> Tablet (768px)
              </span>
              <div className="w-[768px] h-[700px] max-w-full rounded-2xl border-2 border-zinc-800 shadow-2xl bg-zinc-950 overflow-hidden relative">
                <iframe srcDoc={srcDoc} className="w-full h-full border-none" title="Preview Tablet Matrix" />
              </div>
            </div>

            <div className="flex flex-col items-center space-y-2">
              <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-widest flex items-center gap-1.5">
                <Monitor size={12} /> Desktop Fluid
              </span>
              <div className="w-full h-[700px] rounded-2xl border-2 border-zinc-800 shadow-2xl bg-zinc-950 overflow-hidden relative">
                <iframe srcDoc={srcDoc} className="w-full h-full border-none" title="Preview Desktop Matrix" />
              </div>
            </div>
          </div>
        ) : (
          /* Viewport Frame with Responsive Constraints */
          <div
            className={`h-full min-h-full flex-1 transition-all duration-300 flex flex-col overflow-hidden relative ${
              viewport !== "desktop" && runtimeMode === "web" && windowWidth > 800
                ? "border-x border-zinc-800 shadow-2xl bg-zinc-950"
                : "w-full bg-transparent"
            }`}
            style={{
              width:
                viewport === "desktop" || runtimeMode !== "web" || windowWidth <= 800
                  ? "100%"
                  : VIEWPORTS[viewport].w,
              maxWidth: "100%",
              height: "100%",
              minHeight: "100%",
              margin: "0 auto",
            }}
          >
            <div className="flex-1 w-full h-full min-h-full relative overflow-hidden bg-transparent flex flex-col">
              {renderPreviewContent()}
            </div>
          </div>
        )}

        {/* UNIFIED PREVIEW LOGS & ERROR DRAWER */}
        {showLogs && (
          <div className="absolute bottom-0 left-0 right-0 h-56 bg-zinc-950/95 border-t border-zinc-800 backdrop-blur-xl z-50 flex flex-col font-mono text-[11px] shadow-2xl">
            {/* Log Header with Filter Tabs & Error Check Action */}
            <div className="flex items-center justify-between px-3 py-1.5 border-b border-zinc-800 bg-zinc-900/80 shrink-0 select-none">
              <div className="flex items-center gap-2 overflow-hidden">
                <Terminal size={13} className="text-cyan-400 shrink-0" />
                <span className="font-bold text-zinc-200 text-[10px] uppercase tracking-wider shrink-0">
                  Preview Logs & Compiler Diagnostics
                </span>

                {/* Filter Pills */}
                <div className="flex items-center bg-zinc-950 border border-zinc-800 rounded-lg p-0.5 ml-2">
                  <button
                    onClick={() => setLogFilter("all")}
                    className={`px-2 py-0.5 text-[9px] font-bold rounded cursor-pointer ${
                      logFilter === "all" ? "bg-zinc-800 text-white" : "text-zinc-500 hover:text-zinc-300"
                    }`}
                  >
                    All ({previewLogs.length})
                  </button>
                  <button
                    onClick={() => setLogFilter("error")}
                    className={`px-2 py-0.5 text-[9px] font-bold rounded flex items-center gap-1 cursor-pointer ${
                      logFilter === "error" ? "bg-red-500/20 text-red-400 border border-red-500/30" : "text-zinc-500 hover:text-red-400"
                    }`}
                  >
                    <span>Errors ({errorCount})</span>
                  </button>
                  <button
                    onClick={() => setLogFilter("warn")}
                    className={`px-2 py-0.5 text-[9px] font-bold rounded cursor-pointer ${
                      logFilter === "warn" ? "bg-amber-500/20 text-amber-400" : "text-zinc-500 hover:text-amber-400"
                    }`}
                  >
                    Warnings ({warnCount})
                  </button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-1.5 shrink-0">
                {compilableFiles.length > 0 && (
                  <div className="flex items-center gap-1 bg-zinc-950 border border-zinc-800 rounded-lg p-0.5 mr-1">
                    <span className="text-[9px] text-zinc-500 font-bold px-1.5 uppercase shrink-0">Compile:</span>
                    <select
                      value={activeSourceFileName}
                      onChange={(e) => setActiveSourceFileName(e.target.value)}
                      className="bg-transparent text-amber-400 font-mono text-[9px] py-0.5 px-1 outline-none border-none cursor-pointer shrink-0 max-w-[120px] truncate"
                      title="Select compiler/backend code file to execute"
                    >
                      {compilableFiles.map((f) => (
                        <option key={f.id} value={f.name} className="bg-zinc-950 text-zinc-300">
                          {f.name}
                        </option>
                      ))}
                    </select>
                    <button
                      onClick={executeSelectedSourceFile}
                      disabled={isCompiling}
                      className="px-2 py-0.5 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/40 rounded text-[9px] font-bold flex items-center gap-1 cursor-pointer transition-colors"
                      title="Compile & Run selected code file"
                    >
                      {isCompiling ? <Loader2 size={10} className="animate-spin text-emerald-400" /> : <Play size={10} className="text-emerald-400 fill-emerald-400/20" />}
                      <span>{isCompiling ? "Running..." : "Run"}</span>
                    </button>
                  </div>
                )}
                <button
                  onClick={handleGlobalErrorScan}
                  disabled={isScanningAllErrors}
                  className="px-2 py-0.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded text-[10px] font-bold flex items-center gap-1 cursor-pointer"
                  title="Run static compiler diagnostics on all workspace files"
                >
                  {isScanningAllErrors ? <Loader2 size={11} className="animate-spin" /> : <FileSearch size={11} />}
                  <span>Scan All Files for Errors</span>
                </button>
                <button
                  onClick={() => setPreviewLogs([])}
                  className="text-[10px] text-zinc-400 hover:text-white uppercase font-bold px-2 py-0.5 rounded bg-zinc-800 hover:bg-zinc-700 transition-colors cursor-pointer"
                >
                  Clear
                </button>
                <button onClick={() => setShowLogs(false)} className="text-zinc-400 hover:text-white p-1 cursor-pointer">
                  <X size={13} />
                </button>
              </div>
            </div>

            {/* Log Entries Body */}
            <div className="flex-1 overflow-y-auto p-2 space-y-1.5 custom-scrollbar-vertical">
              {filteredLogs.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-zinc-500 italic py-6">
                  <Bug size={20} className="mb-2 opacity-50" />
                  <p>No preview or compiler log messages in this filter.</p>
                  <p className="text-[10px] text-zinc-600 mt-1">Click "Scan All Files for Errors" to check your entire codebase.</p>
                </div>
              ) : (
                filteredLogs.map((log) => (
                  <div
                    key={log.id}
                    className={`flex items-start justify-between p-1.5 rounded-lg border text-[11px] font-mono leading-relaxed transition-all ${
                      log.type === "error"
                        ? "bg-red-950/20 border-red-500/30 text-red-300"
                        : log.type === "warn"
                        ? "bg-amber-950/20 border-amber-500/30 text-amber-300"
                        : "bg-zinc-900/40 border-zinc-800/80 text-zinc-200"
                    }`}
                  >
                    <div className="flex items-start gap-2 min-w-0 pr-2">
                      <span className="text-zinc-500 whitespace-nowrap text-[10px] shrink-0 pt-0.5">
                        {new Date(log.timestamp).toLocaleTimeString()}
                      </span>
                      <span
                        className={`uppercase font-black text-[9px] px-1.5 py-0.2 rounded shrink-0 ${
                          log.type === "error"
                            ? "bg-red-500/20 text-red-400 border border-red-500/40"
                            : log.type === "warn"
                            ? "bg-amber-500/20 text-amber-400 border border-amber-500/40"
                            : "bg-cyan-500/20 text-cyan-400 border border-cyan-500/40"
                        }`}
                      >
                        {log.type}
                      </span>
                      {log.source && (
                        <span className="text-[10px] text-zinc-400 font-bold shrink-0">
                          {log.source}:
                        </span>
                      )}
                      <span className="break-all whitespace-pre-wrap">{log.message}</span>
                    </div>

                    {log.type === "error" && (
                      <button
                        onClick={() => {
                          const fixPrompt = `Fix error in workspace: ${log.message}`;
                          window.dispatchEvent(new CustomEvent('aether-insert-ai-prompt', { detail: { prompt: fixPrompt, autoSubmit: true } }));
                        }}
                        className="px-2 py-0.5 rounded bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 font-sans font-bold text-[9px] flex items-center gap-1 shrink-0 transition-colors cursor-pointer ml-2"
                        title="Fix error automatically with AI"
                      >
                        <Wand2 size={10} /> Auto-Fix with AI
                      </button>
                    )}
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>

      {/* Cloud Deploy Modal */}
      {showPublishModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-md p-4">
          <div className="bg-zinc-950 p-6 rounded-2xl border border-zinc-800 shadow-2xl max-w-sm w-full mx-4 flex flex-col relative">
            <button
              onClick={() => {
                setShowPublishModal(false);
                setPublishedUrl("");
              }}
              className="absolute top-4 right-4 text-zinc-400 hover:text-white cursor-pointer"
            >
              <X size={16} />
            </button>
            <h3 className="text-base font-bold text-white mb-2 flex items-center gap-2">
              <Rocket size={16} className="text-cyan-400" /> Deploy to Cloud
            </h3>
            <p className="text-xs text-zinc-400 mb-4">
              Publish your live workspace to a public edge subdomain.
            </p>

            {!publishedUrl ? (
              <div className="space-y-4">
                <div>
                  <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider mb-1 block">
                    Subdomain Slug
                  </label>
                  <input
                    type="text"
                    value={publishDomain}
                    onChange={(e) => setPublishDomain(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ""))}
                    placeholder="my-cool-app"
                    className="w-full bg-zinc-900 border border-zinc-800 focus:border-cyan-500/50 rounded-xl px-3 py-2 text-sm text-white outline-none font-mono"
                  />
                </div>

                <button
                  onClick={async () => {
                    if (!publishDomain) return;
                    setIsPublishing(true);
                    try {
                      const htmlContent = generateStandaloneHTML(files, activeHtmlFileName);
                      const response = await fetch("/api/publish", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({
                          html: htmlContent,
                          projectId: publishDomain,
                          title: publishDomain,
                        }),
                      });
                      const data = await response.json();
                      if (data.success) {
                        setPublishedUrl(data.url);
                      } else {
                        throw new Error(data.error || "Deploy failed");
                      }
                    } catch (err: any) {
                      console.error("Publish error:", err);
                    } finally {
                      setIsPublishing(false);
                    }
                  }}
                  disabled={isPublishing || !publishDomain}
                  className="w-full py-2.5 bg-gradient-to-r from-cyan-500 to-teal-400 hover:from-cyan-400 text-black font-bold uppercase tracking-wider text-xs rounded-xl transition-all disabled:opacity-40 flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/10 cursor-pointer"
                >
                  {isPublishing ? <Loader2 size={14} className="animate-spin" /> : <Globe size={14} />}
                  {isPublishing ? "Publishing to Global Net..." : "Push to Live Web"}
                </button>
              </div>
            ) : (
              <div className="space-y-4 text-center py-2">
                <div className="w-12 h-12 bg-emerald-500/10 text-emerald-400 rounded-full flex items-center justify-center mx-auto border border-emerald-500/20">
                  <CheckCircle2 size={24} />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Application Deployed!</h4>
                  <a
                    href={publishedUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs font-mono text-cyan-400 hover:underline block mt-1 break-all"
                  >
                    {publishedUrl}
                  </a>
                </div>
                <button
                  onClick={() => {
                    setShowPublishModal(false);
                    setPublishedUrl("");
                  }}
                  className="w-full py-2 bg-zinc-900 hover:bg-zinc-800 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
                >
                  Done
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* User Server Ports & Local IPs Hub Modal */}
      <NetworkHubModal
        isOpen={showNetworkHub}
        onClose={() => setShowNetworkHub(false)}
        onOpenInPreview={(url) => {
          setUrlInput(url);
          if (url.startsWith("workspace://")) {
            const target = url.replace("workspace://", "");
            if (target.startsWith("/api/ports/")) {
              setCustomWebUrl(target);
              setRuntimeMode("url");
            }
          }
        }}
      />
    </div>
  );
};

export default PreviewPane;
