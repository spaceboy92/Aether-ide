import React from 'react';
import { MultiLangTerminalPreview } from './MultiLangTerminalPreview';
import { FileNode } from '../../types';

interface UniversalTerminalPreviewProps {
  code?: string;
  language?: string;
  filename?: string;
  files?: FileNode[];
  onCodeFixed?: (filename: string, fixedContent: string) => void;
}

const UniversalTerminalPreview: React.FC<UniversalTerminalPreviewProps> = ({ 
  code, 
  language, 
  filename, 
  files = [],
  onCodeFixed 
}) => {
  // If complete files array is passed, use rich MultiLangTerminalPreview
  const effectiveFiles: FileNode[] = files.length > 0 ? files : [
    {
      id: 'f_active',
      name: filename || 'main.rs',
      content: code || '',
      language: language || 'rust',
      lastModified: Date.now()
    }
  ];

  return (
    <MultiLangTerminalPreview
      files={effectiveFiles}
      selectedFilename={filename}
      onCodeFixed={onCodeFixed}
    />
  );
};

export default UniversalTerminalPreview;
