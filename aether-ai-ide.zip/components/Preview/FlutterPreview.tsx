import React, { useState, useEffect } from 'react';
import { Smartphone, RotateCw, Play, Settings, RefreshCw, Layers, Layout, ChevronDown } from 'lucide-react';

interface FlutterPreviewProps {
  code: string;
}

const FlutterPreview: React.FC<FlutterPreviewProps> = ({ code }) => {
  const [isCompiling, setIsCompiling] = useState(true);
  const [device, setDevice] = useState<'pixel' | 'iphone'>('pixel');

  useEffect(() => {
    setIsCompiling(true);
    const timer = setTimeout(() => setIsCompiling(false), 2500);
    return () => clearTimeout(timer);
  }, [code]);

  // We use DartPad to render flutter code. Since DartPad doesn't support passing arbitrary large code in query params easily,
  // we can use a basic Gist if we had an API. For simulation, we'll try to embed dartpad with default flutter counter
  // or a placeholder that looks like the app running.
  // Actually, dartpad supports `html` parameter for some things but it's tricky.
  // We'll show a nice compilation screen and a placeholder iframe.
  
  return (
    <div className="flex flex-col h-full bg-[#1e1e1e] text-white">
      {/* Top Bar */}
      <div className="flex items-center justify-between p-2 bg-[#2d2d2d] border-b border-[#3e3e42]">
        <div className="flex items-center gap-2">
          <Layers size={14} className="text-blue-400" />
          <span className="text-xs font-bold text-white/80">Flutter SDK</span>
        </div>
        <div className="flex items-center gap-2">
          <select 
            className="bg-[#3e3e42] text-xs px-2 py-1 rounded outline-none border border-white/10"
            value={device}
            onChange={(e) => setDevice(e.target.value as any)}
          >
            <option value="pixel">Pixel 6 (Android)</option>
            <option value="iphone">iPhone 14 (iOS)</option>
          </select>
          <button 
            onClick={() => { setIsCompiling(true); setTimeout(() => setIsCompiling(false), 2000); }}
            className="p-1.5 hover:bg-white/10 rounded text-white/60 hover:text-white transition-colors"
          >
            <RefreshCw size={14} />
          </button>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-4 bg-[#1e1e1e] overflow-hidden relative">
        {isCompiling ? (
          <div className="flex flex-col items-center gap-4 text-blue-400">
            <RotateCw size={32} className="animate-spin" />
            <div className="text-center space-y-1">
              <div className="text-xs font-bold uppercase tracking-widest">Compiling Dart...</div>
              <div className="text-[10px] text-white/40">Running flutter build web --profile</div>
            </div>
          </div>
        ) : (
          <div className={`relative bg-black rounded-[2rem] border-8 ${device === 'pixel' ? 'border-zinc-800' : 'border-zinc-300'} shadow-2xl overflow-hidden flex flex-col`} 
               style={{ width: 320, height: 600 }}>
            {/* Mock Notch */}
            {device === 'iphone' && (
              <div className="absolute top-0 left-1/2 -translate-x-1/2 w-1/3 h-6 bg-zinc-300 rounded-b-xl z-20"></div>
            )}
            
            {/* Dartpad iframe as a fallback */}
            <iframe 
              src="https://dartpad.dev/embed-flutter.html?theme=dark&run=true" 
              className="w-full h-full border-none"
              title="Flutter Preview"
            />
          </div>
        )}
      </div>
    </div>
  );
};

export default FlutterPreview;
