import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  ArrowLeft, 
  Rocket, 
  LayoutGrid, 
  Gamepad2, 
  LineChart, 
  StickyNote, 
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { GALLERY_APPS, GalleryApp } from '../../data/galleryApps';

interface AppGalleryProps {
  onBack: () => void;
  onLaunchApp: (app: GalleryApp) => void;
}

const AppGallery: React.FC<AppGalleryProps> = ({ onBack, onLaunchApp }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All Projects');

  const filteredApps = selectedCategory === 'All Projects'
    ? GALLERY_APPS
    : GALLERY_APPS.filter(app => app.category === selectedCategory);

  return (
    <div className="flex flex-col h-full bg-black text-white selection:bg-orange-500/30">
      {/* Header */}
      <header className="px-6 py-6 md:px-12 md:py-12 border-b border-white/5 bg-black/40 backdrop-blur-3xl sticky top-0 z-20">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4 md:gap-6">
            <button 
              onClick={onBack}
              className="p-2 md:p-3 rounded-full bg-white/5 hover:bg-white/10 transition-colors text-white/40 hover:text-white"
            >
              <ArrowLeft size={18} />
            </button>
            <div>
              <h1 className="text-xl md:text-5xl font-black italic tracking-tighter">APP GALLERY</h1>
              <p className="text-[8px] md:text-sm font-bold text-white/30 uppercase tracking-[0.2em] mt-0.5 md:mt-1">Neural Architectures</p>
            </div>
          </div>
          
          <div className="hidden md:flex items-center gap-3 px-6 py-3 bg-orange-600/10 border border-orange-500/20 rounded-full">
            <Sparkles size={16} className="text-orange-400" />
            <span className="text-[10px] font-black uppercase tracking-widest text-orange-400">{filteredApps.length} Ready to Deploy</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto no-scrollbar">
        <div className="max-w-7xl mx-auto px-6 py-12 md:px-12 md:py-24">
          
          {/* Categories / Filters */}
          <div className="flex flex-wrap gap-4 mb-16">
            {['All Projects', 'Game', 'Utility', 'Visualizer'].map((cat) => (
              <button 
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-6 py-2.5 rounded-full text-[10px] font-black uppercase tracking-widest border transition-all cursor-pointer ${
                  selectedCategory === cat 
                    ? 'bg-white text-black border-white shadow-[0_0_15px_rgba(255,255,255,0.2)]' 
                    : 'bg-transparent border-white/10 text-white/40 hover:border-white/30 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* App Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {filteredApps.map((app, i) => (
              <motion.div
                key={app.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -10 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => onLaunchApp(app)}
                className="group relative h-[400px] md:h-[500px] rounded-[2.5rem] md:rounded-[3rem] bg-zinc-900 border border-white/5 hover:border-orange-500/30 overflow-hidden cursor-pointer transition-all duration-500 shadow-2xl"
              >
                {/* Background Image / Overlay */}
                <div className="absolute inset-0 z-0">
                  <img 
                    src={app.thumbnail} 
                    alt={app.title} 
                    className="w-full h-full object-cover opacity-30 grayscale group-hover:grayscale-0 group-hover:opacity-50 transition-all duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-transparent" />
                </div>

                {/* Content */}
                <div className="relative z-10 h-full p-8 md:p-10 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-3 mb-4 md:mb-6">
                      <div className={`p-2 md:p-3 rounded-xl md:rounded-2xl bg-${app.accentColor}-600/20 text-${app.accentColor}-400 border border-${app.accentColor}-500/20`}>
                        {app.category === 'Game' && <Gamepad2 size={18} />}
                        {app.category === 'Utility' && <StickyNote size={18} />}
                        {app.category === 'Visualizer' && <LineChart size={18} />}
                      </div>
                      <span className={`text-[8px] md:text-[10px] font-black uppercase tracking-widest text-${app.accentColor}-400`}>
                        {app.category}
                      </span>
                    </div>
                    
                    <h3 className="text-3xl md:text-4xl font-black text-white mb-2 md:mb-4 leading-none">{app.title}</h3>
                    <p className="text-xs md:text-sm font-medium text-white/40 leading-relaxed max-w-[200px] md:max-w-[240px]">
                      {app.description}
                    </p>
                  </div>

                  <div className="flex flex-col gap-4">
                    <div className="flex -space-x-2">
                       {[1,2,3].map(j => (
                         <div key={j} className="w-6 h-6 md:w-8 md:h-8 rounded-full border-2 border-zinc-900 bg-zinc-800 flex items-center justify-center overflow-hidden">
                           <img src={`https://ui-avatars.com/api/?name=User+${j}&background=random`} alt="user" />
                         </div>
                       ))}
                       <div className="w-6 h-6 md:w-8 md:h-8 rounded-full border-2 border-zinc-900 bg-zinc-800 flex items-center justify-center text-[7px] md:text-[8px] font-black">
                         +12
                       </div>
                    </div>

                    <button className="flex items-center justify-between w-full p-0.5 md:p-1 bg-white/5 rounded-full border border-white/5 group-hover:bg-orange-600 group-hover:border-orange-500 transition-all duration-500">
                      <span className="pl-5 md:pl-6 text-[8px] md:text-[10px] font-black uppercase tracking-widest text-white/40 group-hover:text-white transition-colors">Launch Project</span>
                      <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-white/10 group-hover:bg-white flex items-center justify-center group-hover:text-black transition-all">
                        <ArrowRight size={18} />
                      </div>
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}

            {/* Coming Soon Card */}
            <div className="h-[500px] rounded-[3rem] border-2 border-dashed border-white/10 flex flex-col items-center justify-center p-10 text-center space-y-6">
              <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center">
                <Rocket size={32} className="text-white/20" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white/40 italic">New Architectures Incoming</h3>
                <p className="text-xs font-bold text-white/10 uppercase tracking-widest mt-2">Daily updates scheduled</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AppGallery;
