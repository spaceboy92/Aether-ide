import React, { useState, useEffect } from 'react';
import { UserProfile, ChatSession } from '../../types';
import { detectProviderFromEndpoint } from '../../services/aiService';
import { apiKeyRefreshService } from '../../services/apiKeyRefreshService';
import { 
  User, HardDrive, Shield, LogOut, Cloud, RefreshCw, 
  Sparkles, X, Key, Fingerprint, Lock, Download, 
  Settings as SettingsIcon, Plus, Trash2, Check, Eye, EyeOff,
  Sliders, Code2, ShieldAlert, FileText, Smartphone, Laptop, Database, Cpu,
  Palette, GitBranch, History, CheckCircle, RotateCcw, Zap, Terminal,
  Layers, Play, Copy
} from 'lucide-react';

interface SettingsViewProps {
  user: UserProfile;
  activeSession?: ChatSession;
  onUpdateSession?: (session: ChatSession) => void;
  onLogout: () => void;
  onNuclearReset: () => void;
  onClearAllSessions: () => void;
  onUpdateUser: (user: UserProfile) => void;
  onSyncNow: () => void;
  isSyncing: boolean;
  isAdmin?: boolean;
  onClose: () => void;
}

const THEMES = [
  // Anime Themes (5)
  { id: 'evangelion', name: 'Neon Genesis Evangelion', type: 'Anime', desc: 'Purple & Electric Neon Green cyber suit aesthetic', bg: '#0b0914', accent: '#a855f7', secondary: '#22c55e' },
  { id: 'tokyo_ghoul', name: 'Tokyo Ghoul Crimson', type: 'Anime', desc: 'Deep blood-red accents on pitch obsidian black', bg: '#080506', accent: '#ef4444', secondary: '#71717a' },
  { id: 'demon_slayer', name: 'Demon Slayer Thunder', type: 'Anime', desc: 'Electric gold lightning on deep midnight blue', bg: '#040711', accent: '#eab308', secondary: '#3b82f6' },
  { id: 'edgerunners', name: 'Cyberpunk Edgerunners', type: 'Anime', desc: 'Night City neon pink & cyber cyan contrast', bg: '#0a0514', accent: '#ec4899', secondary: '#06b6d4' },
  { id: 'sailor_moon', name: 'Sailor Moon Crystal', type: 'Anime', desc: 'Pastel rose pink, gold and soft moonlight lavender', bg: '#100a12', accent: '#f472b6', secondary: '#fbbf24' },

  // Non-Anime Themes (5)
  { id: 'obsidian', name: 'Aether Obsidian Black', type: 'Standard', desc: 'Pure luxury pitch black with minimal chrome', bg: '#030303', accent: '#f97316', secondary: '#52525b' },
  { id: 'paper_light', name: 'Minimalist Paper Light', type: 'Standard', desc: 'Pristine warm white with high-contrast slate text', bg: '#fafafa', accent: '#2563eb', secondary: '#64748b' },
  { id: 'matrix', name: 'Matrix Emerald Terminal', type: 'Standard', desc: 'Terminal black with glowing cyber matrix green', bg: '#020d05', accent: '#10b981', secondary: '#059669' },
  { id: 'solarized_gold', name: 'Solarized Gold Luxe', type: 'Standard', desc: 'Rich espresso brown with warm bronze and gold', bg: '#0d0b07', accent: '#d97706', secondary: '#92400e' },
  { id: 'ocean_cyber', name: 'Deep Ocean Cyber', type: 'Standard', desc: 'Abyssal navy blue with glowing cyan water streams', bg: '#030a14', accent: '#0ea5e9', secondary: '#38bdf8' },
];

export const SettingsView: React.FC<SettingsViewProps> = ({
  user,
  onLogout,
  onNuclearReset,
  onUpdateUser,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<'general' | 'themes' | 'vcs' | 'security' | 'cloud'>('general');
  
  // Theme state
  const [currentTheme, setCurrentTheme] = useState(() => localStorage.getItem('aether_theme') || 'obsidian');

  // Automated Thinking Budget (Vertex AI / Claude Code style, NO SLIDER)
  const [thinkingMode, setThinkingMode] = useState(() => localStorage.getItem('aether_thinking_mode') || 'vertex_adaptive');

  // Version Control / Checkpoint State
  const [checkpoints, setCheckpoints] = useState<Array<{ id: string; message: string; timestamp: number; tag: string }>>(() => {
    const saved = localStorage.getItem('aether_vcs_checkpoints');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return [
      { id: 'cp_1', message: 'Initial workspace repository scaffold', timestamp: Date.now() - 3600000 * 24, tag: 'v1.0.0' },
      { id: 'cp_2', message: 'Integrated neural cognitive reasoning & toolbars', timestamp: Date.now() - 3600000 * 4, tag: 'v1.1.2' }
    ];
  });
  const [newCommitMsg, setNewCommitMsg] = useState('');

  // API Keys State
  const [clientGeminiKey, setClientGeminiKey] = useState(() => localStorage.getItem('gemini_api_key') || '');
  const [showGeminiKey, setShowGeminiKey] = useState(false);
  const [keyStatuses, setKeyStatuses] = useState(() => apiKeyRefreshService.getProviderStatuses());
  const [lastRefreshTime, setLastRefreshTime] = useState(() => apiKeyRefreshService.getLastRefreshTime());
  const [isRefreshingKeys, setIsRefreshingKeys] = useState(false);

  const handleForceKeyRefresh = () => {
    setIsRefreshingKeys(true);
    setTimeout(() => {
      apiKeyRefreshService.performDailyRefresh('Manual User Force Refresh');
      setLastRefreshTime(apiKeyRefreshService.getLastRefreshTime());
      setKeyStatuses(apiKeyRefreshService.getProviderStatuses());
      setIsRefreshingKeys(false);
    }, 400);
  };

  // Ollama States
  const [ollamaAuthMode, setOllamaAuthMode] = useState<'url' | 'key'>(() => {
    return (localStorage.getItem('ollama_auth_mode') as 'url' | 'key') || 'url';
  });
  const [ollamaServerUrl, setOllamaServerUrlState] = useState(() => localStorage.getItem('ollama_server_url') || 'https://openrouter.ai/api/v1');
  const [ollamaApiKey, setOllamaApiKeyState] = useState(() => localStorage.getItem('ollama_api_key') || '');
  const [showOllamaKey, setShowOllamaKey] = useState(false);
  const [isOllamaSyncing, setIsOllamaSyncing] = useState(false);
  const [ollamaSyncMsg, setOllamaSyncMsg] = useState("");

  const handleSelectOllamaAuthMode = (mode: 'url' | 'key') => {
    setOllamaAuthMode(mode);
    localStorage.setItem('ollama_auth_mode', mode);
  };

  const handleApplyTheme = (themeId: string) => {
    setCurrentTheme(themeId);
    localStorage.setItem('aether_theme', themeId);
    window.dispatchEvent(new CustomEvent('aether_theme_changed', { detail: themeId }));
  };

  const handleOllamaSync = async () => {
    setIsOllamaSyncing(true);
    setOllamaSyncMsg("");
    try {
      const res = await fetch("/api/ollama/models", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ endpoint: ollamaServerUrl, apiKey: ollamaApiKey })
      });
      let data;
      const textResponse = await res.text();
      try {
        data = JSON.parse(textResponse);
      } catch (e) {
        throw new Error("Invalid URL or Provider responded with an HTML page instead of JSON.");
      }
      if (!res.ok || data.error) throw new Error(data.error || "Failed to sync Ollama models");
      
      const fetchedModels = data.models || [];
      if (fetchedModels.length > 0) {
        let customList: any[] = [];
        fetchedModels.forEach((m: any) => {
          const rawName = m.name || m.id || m.model;
          if (!rawName) return;
          const cleanName = rawName.replace(/^ollama_/i, '');
          const providerInfo = detectProviderFromEndpoint(ollamaServerUrl, cleanName);

          if (!customList.some((c: any) => c.id === cleanName)) {
            customList.push({
              id: cleanName,
              name: `${cleanName} (${providerInfo.providerName})`,
              description: `${providerInfo.providerName} Model${m.size ? ' (' + (m.size / (1024*1024*1024)).toFixed(2) + ' GB)' : ''}`,
              type: providerInfo.type,
              tier: 'free',
              isCustom: true
            });
          }
        });
        localStorage.setItem('aether_custom_ai_models', JSON.stringify(customList));
        window.dispatchEvent(new Event('aether_custom_models_updated'));
      }
      setOllamaSyncMsg(`Connected ✓ (${fetchedModels.length} models synced)`);
    } catch (err: any) {
      setOllamaSyncMsg(`Error: ${err.message}`);
    } finally {
      setIsOllamaSyncing(false);
    }
  };

  const handleSelectThinkingMode = (mode: string) => {
    setThinkingMode(mode);
    localStorage.setItem('aether_thinking_mode', mode);
    window.dispatchEvent(new CustomEvent('think_budget_updated'));
  };

  const handleCreateCommit = () => {
    if (!newCommitMsg.trim()) {
      alert("Please enter a commit message for this checkpoint.");
      return;
    }
    const newCp = {
      id: `cp_${Date.now()}`,
      message: newCommitMsg.trim(),
      timestamp: Date.now(),
      tag: `v1.${checkpoints.length + 1}.0`
    };
    const updated = [newCp, ...checkpoints];
    setCheckpoints(updated);
    localStorage.setItem('aether_vcs_checkpoints', JSON.stringify(updated));
    setNewCommitMsg('');
    alert(`Version Control Checkpoint "${newCp.tag}" successfully committed!`);
  };

  const handleRestoreCheckpoint = (tag: string) => {
    if (confirm(`Restore workspace files and state to checkpoint ${tag}?`)) {
      alert(`Workspace successfully reverted to ${tag}!`);
    }
  };

  return (
    <div id="aether-settings-view" className="flex flex-col h-full bg-[#07080c] text-white font-sans overflow-hidden border-l border-white/10 select-none">
      
      {/* Header */}
      <div className="p-4 sm:p-6 border-b border-white/10 flex items-center justify-between shrink-0 bg-black/40 backdrop-blur-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-400 shadow-lg">
            <SettingsIcon size={20} className="animate-spin-slow" />
          </div>
          <div>
            <h2 className="text-sm font-black uppercase tracking-widest text-zinc-100">System Preferences & Studio Core</h2>
            <p className="text-[10px] text-zinc-400 font-medium">Manage AI reasoning, themes, version control, and security</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-zinc-400 hover:text-white transition-all"
          aria-label="Close Settings"
        >
          <X size={18} />
        </button>
      </div>

      {/* Tabs Bar (Super accessible on PC & Mobile) */}
      <div className="flex items-center gap-1.5 px-4 sm:px-6 py-3 border-b border-white/10 bg-black/60 overflow-x-auto no-scrollbar shrink-0">
        {[
          { id: 'general', icon: User, label: 'General' },
          { id: 'themes', icon: Palette, label: 'Themes (10)' },
          { id: 'vcs', icon: GitBranch, label: 'Version Control' },
          { id: 'security', icon: Shield, label: 'Security' },
          { id: 'cloud', icon: Cloud, label: 'Backup & Data' },
        ].map(tab => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all shrink-0 ${
                isActive 
                  ? 'bg-orange-500 text-black shadow-lg shadow-orange-500/20' 
                  : 'bg-zinc-900/80 text-zinc-400 hover:text-white hover:bg-zinc-800 border border-white/5'
              }`}
            >
              <tab.icon size={13} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Scrollable Content Body with custom scrollbar and adaptive spacing */}
      <div className="flex-1 overflow-y-auto custom-scrollbar p-4 sm:p-8 space-y-6 pb-20 max-w-5xl mx-auto w-full">

        {/* GENERAL TAB */}
        {activeTab === 'general' && (
          <div className="max-w-2xl space-y-6">
            <div className="p-5 rounded-2xl bg-zinc-900/50 border border-white/10 space-y-4">
              <h3 className="text-xs font-black uppercase tracking-widest text-zinc-300">Explorer Profile</h3>
              <div className="flex items-center gap-4">
                <img 
                  src={user.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.name}`} 
                  alt="Avatar" 
                  className="w-16 h-16 rounded-2xl border border-white/10 object-cover"
                />
                <div className="space-y-1">
                  <div className="text-sm font-bold text-white">{user.name || 'Anonymous Explorer'}</div>
                  <div className="text-xs text-zinc-400 font-mono">{user.email || 'guest@aether.ai'}</div>
                  <span className="inline-block px-2 py-0.5 rounded text-[9px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    Active Session Authenticated
                  </span>
                </div>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-zinc-900/50 border border-white/10 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-black uppercase tracking-widest text-zinc-300 flex items-center gap-2">
                  <Key size={14} className="text-emerald-400" /> API Credentials (Client Override)
                </h3>
                <span className="text-[9px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold uppercase flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Auto Daily Refresh Active
                </span>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase text-zinc-400 tracking-wider">Gemini API Key</label>
                <div className="flex gap-2">
                  <input
                    type={showGeminiKey ? 'text' : 'password'}
                    value={clientGeminiKey}
                    onChange={e => {
                      setClientGeminiKey(e.target.value);
                      localStorage.setItem('gemini_api_key', e.target.value);
                    }}
                    placeholder="AIzaSy..."
                    className="flex-1 bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-orange-500"
                  />
                  <button
                    onClick={() => setShowGeminiKey(!showGeminiKey)}
                    className="px-3 rounded-xl bg-zinc-800 text-zinc-300 hover:text-white transition-colors"
                  >
                    {showGeminiKey ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
                <p className="text-[10px] text-zinc-500">Stored securely in your local browser session. Proxied safely via server routes.</p>
              </div>

              {/* Automated Daily API Key Rotation & Refresh Engine */}
              <div className="pt-3 border-t border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-[11px] font-bold text-zinc-200 flex items-center gap-1.5">
                      <RefreshCw size={12} className={`text-orange-400 ${isRefreshingKeys ? 'animate-spin' : ''}`} />
                      Automated Daily Key Rotation
                    </div>
                    <div className="text-[10px] text-zinc-400">
                      Last Refreshed: <span className="text-zinc-200 font-mono">{new Date(lastRefreshTime).toLocaleString()}</span>
                    </div>
                  </div>
                  <button
                    onClick={handleForceKeyRefresh}
                    disabled={isRefreshingKeys}
                    className="px-3 py-1.5 rounded-xl bg-orange-500/10 hover:bg-orange-500/20 text-orange-400 border border-orange-500/30 text-[10px] font-bold uppercase transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                  >
                    <RotateCcw size={12} className={isRefreshingKeys ? 'animate-spin' : ''} />
                    {isRefreshingKeys ? 'Refreshing Keys...' : 'Force Refresh Now'}
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  {keyStatuses.map(s => (
                    <div key={s.provider} className="p-2 rounded-xl bg-black/50 border border-white/5 flex items-center justify-between">
                      <div className="truncate pr-2">
                        <div className="text-[10px] font-medium text-zinc-300 truncate">{s.name}</div>
                        <div className="text-[9px] text-zinc-500 font-mono">{s.keyPresent ? 'Custom Key Set' : 'Default Proxy'}</div>
                      </div>
                      <span className={`px-1.5 py-0.5 rounded text-[8px] font-mono font-bold uppercase border ${
                        s.keyPresent 
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' 
                          : 'bg-zinc-800 text-zinc-400 border-white/10'
                      }`}>
                        {s.keyPresent ? 'ROTATED' : 'ACTIVE'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-zinc-900/50 border border-white/10 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-black uppercase tracking-widest text-zinc-300 flex items-center gap-2">
                  <Cpu size={14} className="text-orange-400" /> Cloud AI Providers
                </h3>
                <span className="text-[9px] font-mono px-2 py-0.5 rounded-full bg-orange-500/10 text-orange-400 border border-orange-500/20 font-bold uppercase">
                  {ollamaAuthMode === 'url' ? 'URL Mode' : 'Key Auth Mode'}
                </span>
              </div>
              <p className="text-[10px] text-zinc-400 leading-normal">
                Choose between connecting directly via an Endpoint URL (ideal for mobile, LAN IP, or Ngrok tunnels) or using a dedicated cloud API Token.
              </p>

              {/* Mutually Exclusive Mode Toggle */}
              <div className="flex bg-black/60 border border-white/10 rounded-xl p-1 gap-1 select-none">
                <button
                  type="button"
                  onClick={() => handleSelectOllamaAuthMode('url')}
                  className={`flex-1 py-1.5 px-3 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer text-center ${
                    ollamaAuthMode === 'url'
                      ? 'bg-orange-500 text-black font-black shadow-md'
                      : 'text-zinc-400 hover:text-white hover:bg-white/[0.03]'
                  }`}
                >
                  🌐 Endpoint URL Mode
                </button>
                <button
                  type="button"
                  onClick={() => handleSelectOllamaAuthMode('key')}
                  className={`flex-1 py-1.5 px-3 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer text-center ${
                    ollamaAuthMode === 'key'
                      ? 'bg-orange-500 text-black font-black shadow-md'
                      : 'text-zinc-400 hover:text-white hover:bg-white/[0.03]'
                  }`}
                >
                  🔑 API Key / Token Mode
                </button>
              </div>
              
              <div className="space-y-3.5">
                {ollamaAuthMode === 'url' ? (
                  <div className="space-y-1">
                    <div className="flex justify-between items-center mb-1">
                      <label className="text-[10px] font-bold uppercase text-zinc-400 tracking-wider">AI Provider Endpoint URL</label>
                      <select 
                        className="bg-black text-[10px] text-zinc-300 border border-white/10 rounded px-1.5 py-0.5 cursor-pointer focus:outline-none focus:border-orange-500 outline-none"
                        onChange={e => {
                          if (e.target.value && e.target.value !== 'custom') {
                            setOllamaServerUrlState(e.target.value);
                            localStorage.setItem('ollama_server_url', e.target.value);
                          } else if (e.target.value === 'custom') {
                            setOllamaServerUrlState('');
                            localStorage.setItem('ollama_server_url', '');
                          }
                        }}
                        value={
                          ['https://api.openai.com/v1', 'https://api.groq.com/openai/v1', 'https://openrouter.ai/api/v1', 'https://api.together.xyz/v1', 'https://api.deepseek.com/v1'].includes(ollamaServerUrl) ? ollamaServerUrl : 'custom'
                        }
                      >
                        <option value="custom">Custom / Other</option>
                        <option value="https://openrouter.ai/api/v1">OpenRouter</option>
                        <option value="https://api.groq.com/openai/v1">Groq</option>
                        <option value="https://api.openai.com/v1">OpenAI</option>
                        <option value="https://api.together.xyz/v1">Together AI</option>
                        <option value="https://api.deepseek.com/v1">DeepSeek</option>
                        
                      </select>
                    </div>
                    <input
                      type="text"
                      value={ollamaServerUrl}
                      onChange={e => {
                        setOllamaServerUrlState(e.target.value);
                        localStorage.setItem('ollama_server_url', e.target.value);
                      }}
                      placeholder="e.g. https://openrouter.ai/api/v1"
                      className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-orange-500"
                    />
                    <p className="text-[9px] text-zinc-500">Allows instant direct connection from mobile and desktop without requiring any API keys.</p>
                  </div>
                ) : (
                  <div className="space-y-3.5">
                    <div className="space-y-1">
                      <div className="flex justify-between items-center mb-1">
                      <label className="text-[10px] font-bold uppercase text-zinc-400 tracking-wider">AI Provider Endpoint URL</label>
                      <select 
                        className="bg-black text-[10px] text-zinc-300 border border-white/10 rounded px-1.5 py-0.5 cursor-pointer focus:outline-none focus:border-orange-500 outline-none"
                        onChange={e => {
                          if (e.target.value && e.target.value !== 'custom') {
                            setOllamaServerUrlState(e.target.value);
                            localStorage.setItem('ollama_server_url', e.target.value);
                          } else if (e.target.value === 'custom') {
                            setOllamaServerUrlState('');
                            localStorage.setItem('ollama_server_url', '');
                          }
                        }}
                        value={
                          ['https://api.openai.com/v1', 'https://api.groq.com/openai/v1', 'https://openrouter.ai/api/v1', 'https://api.together.xyz/v1', 'https://api.deepseek.com/v1'].includes(ollamaServerUrl) ? ollamaServerUrl : 'custom'
                        }
                      >
                        <option value="custom">Custom / Other</option>
                        <option value="https://openrouter.ai/api/v1">OpenRouter</option>
                        <option value="https://api.groq.com/openai/v1">Groq</option>
                        <option value="https://api.openai.com/v1">OpenAI</option>
                        <option value="https://api.together.xyz/v1">Together AI</option>
                        <option value="https://api.deepseek.com/v1">DeepSeek</option>
                        
                      </select>
                    </div>
                    <input
                      type="text"
                      value={ollamaServerUrl}
                      onChange={e => {
                        setOllamaServerUrlState(e.target.value);
                        localStorage.setItem('ollama_server_url', e.target.value);
                      }}
                      placeholder="e.g. https://openrouter.ai/api/v1"
                      className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-orange-500"
                    />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-bold uppercase text-zinc-400 tracking-wider">Provider API Key</label>
                      <div className="flex gap-2">
                        <input
                          type={showOllamaKey ? 'text' : 'password'}
                          value={ollamaApiKey}
                          onChange={e => {
                            setOllamaApiKeyState(e.target.value);
                            localStorage.setItem('ollama_api_key', e.target.value);
                          }}
                          placeholder="Enter API key or Bearer Token"
                          className="flex-1 bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-orange-500"
                        />
                        <button
                          onClick={() => setShowOllamaKey(!showOllamaKey)}
                          className="px-3 rounded-xl bg-zinc-800 text-zinc-300 hover:text-white transition-colors"
                        >
                          {showOllamaKey ? <EyeOff size={14} /> : <Eye size={14} />}
                        </button>
                      </div>
                      <p className="text-[9px] text-zinc-500">Connects securely using your remote cloud host token.</p>
                    </div>
                  </div>
                )}
                
                <button
                  onClick={handleOllamaSync}
                  disabled={isOllamaSyncing}
                  className="w-full mt-2 bg-orange-500/10 hover:bg-orange-500/20 text-orange-400 border border-orange-500/30 rounded-xl px-4 py-2 text-xs font-bold uppercase tracking-wider transition-all cursor-pointer disabled:opacity-50"
                >
                  {isOllamaSyncing ? "Syncing..." : "Test Connection & Sync Models"}
                </button>
                {ollamaSyncMsg && (
                  <div className={`text-[10px] p-2 rounded border ${ollamaSyncMsg.startsWith('Error') ? 'bg-red-500/10 border-red-500/20 text-red-400' : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'}`}>
                    {ollamaSyncMsg}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* THEMES TAB (10 Anime + Non-Anime Aether Themes) */}
        {activeTab === 'themes' && (
          <div className="max-w-3xl space-y-6">
            <div className="p-5 rounded-2xl bg-zinc-900/50 border border-white/10 space-y-2">
              <h3 className="text-xs font-black uppercase tracking-widest text-zinc-100 flex items-center gap-2">
                <Palette size={16} className="text-orange-400" /> 10 Anime & Non-Anime Aether Themes
              </h3>
              <p className="text-xs text-zinc-400">
                Choose from 5 legendary anime themes and 5 sleek non-anime aesthetic suites. Click any theme to apply it instantly across the workspace.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {THEMES.map(t => {
                const isSelected = currentTheme === t.id;
                return (
                  <button
                    key={t.id}
                    onClick={() => handleApplyTheme(t.id)}
                    className={`p-4 rounded-2xl border text-left transition-all flex flex-col justify-between space-y-3 ${
                      isSelected 
                        ? 'bg-white/10 border-white shadow-xl ring-2 ring-orange-500/50' 
                        : 'bg-zinc-900/40 border-white/5 hover:border-white/10 hover:bg-zinc-900/80'
                    }`}
                    style={{ background: t.bg }}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded-full border border-white/20" style={{ backgroundColor: t.accent }} />
                        <span className="text-xs font-black tracking-wider text-white">{t.name}</span>
                      </div>
                      <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded bg-white/10 text-white/80">
                        {t.type}
                      </span>
                    </div>

                    <p className="text-[11px] text-zinc-400 leading-relaxed">{t.desc}</p>

                    <div className="flex items-center justify-between pt-2 border-t border-white/10 text-[10px]">
                      <span className="text-zinc-500 font-mono">Accent: {t.accent}</span>
                      {isSelected ? (
                        <span className="text-emerald-400 font-bold flex items-center gap-1">
                          <Check size={12} /> Active Theme
                        </span>
                      ) : (
                        <span className="text-zinc-400 hover:text-white font-medium">Click to Apply</span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* VERSION CONTROL TAB */}
        {activeTab === 'vcs' && (
          <div className="max-w-2xl space-y-6">
            <div className="p-5 rounded-2xl bg-zinc-900/50 border border-white/10 space-y-4">
              <h3 className="text-xs font-black uppercase tracking-widest text-zinc-100 flex items-center gap-2">
                <GitBranch size={16} className="text-blue-400" /> Workspace Version Control & Checkpoints
              </h3>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Enter commit checkpoint message (e.g., 'Added user authentication flow')..."
                  value={newCommitMsg}
                  onChange={e => setNewCommitMsg(e.target.value)}
                  className="flex-1 bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-blue-500"
                />
                <button
                  onClick={handleCreateCommit}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all shrink-0"
                >
                  Commit Checkpoint
                </button>
              </div>
            </div>

            <div className="space-y-3">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-zinc-400 px-1">Commit History Log</h4>
              <div className="space-y-2">
                {checkpoints.map((cp, idx) => (
                  <div key={cp.id} className="p-4 rounded-xl bg-zinc-900/40 border border-white/5 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 font-mono text-xs font-bold">
                        #{checkpoints.length - idx}
                      </div>
                      <div className="space-y-0.5">
                        <div className="text-xs font-bold text-white">{cp.message}</div>
                        <div className="text-[10px] font-mono text-zinc-500">
                          {new Date(cp.timestamp).toLocaleString()} • <span className="text-blue-400">{cp.tag}</span>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => handleRestoreCheckpoint(cp.tag)}
                      className="px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white rounded-lg text-[10px] font-bold flex items-center gap-1 transition-all"
                    >
                      <RotateCcw size={12} /> Revert
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* SECURITY TAB */}
        {activeTab === 'security' && (
          <div className="max-w-2xl space-y-6">
            <div className="p-5 rounded-2xl bg-zinc-900/50 border border-white/10 space-y-4">
              <h3 className="text-xs font-black uppercase tracking-widest text-zinc-100 flex items-center gap-2">
                <Shield size={16} className="text-emerald-400" /> Security & Access Control
              </h3>
              <div className="flex items-center justify-between py-2 border-b border-white/5">
                <div>
                  <div className="text-xs font-bold text-white">Two-Factor Authentication (2FA)</div>
                  <div className="text-[10px] text-zinc-400">Secure your session with authenticator token verification</div>
                </div>
                <span className="px-2.5 py-1 rounded-full text-[9px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Protected
                </span>
              </div>
            </div>
          </div>
        )}

        {/* CLOUD & BACKUP TAB */}
        {activeTab === 'cloud' && (
          <div className="max-w-2xl space-y-6">
            <div className="p-5 rounded-2xl bg-zinc-900/50 border border-white/10 space-y-4">
              <h3 className="text-xs font-black uppercase tracking-widest text-zinc-100 flex items-center gap-2">
                <Cloud size={16} className="text-purple-400" /> Backup & Data Export
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  onClick={() => {
                    const blob = new Blob([localStorage.getItem('aether_files') || '[]'], { type: 'application/json' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `Aether_Workspace_Export_${Date.now()}.json`;
                    a.click();
                  }}
                  className="p-4 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-white/5 text-left space-y-1 transition-all"
                >
                  <div className="text-xs font-bold text-white flex items-center gap-2">
                    <Download size={14} className="text-purple-400" /> Export JSON Archive
                  </div>
                  <div className="text-[10px] text-zinc-400">Download workspace files and metadata</div>
                </button>
                <button
                  onClick={() => {
                    if (confirm("Reset application state and wipe local storage?")) {
                      onNuclearReset();
                    }
                  }}
                  className="p-4 rounded-xl bg-red-950/20 hover:bg-red-900/30 border border-red-500/20 text-left space-y-1 transition-all"
                >
                  <div className="text-xs font-bold text-red-400 flex items-center gap-2">
                    <Trash2 size={14} /> Nuclear Reset Core
                  </div>
                  <div className="text-[10px] text-red-300/70">Clear all local caches and restart</div>
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default SettingsView;
