import React, { useState } from 'react';
import { UserProfile } from '../../types';
import { Palette, X, Sparkles, Zap, Code, Eye, MessageSquare, Check, RotateCcw } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface CustomizerViewProps {
  user: UserProfile;
  onUpdateUser: (user: UserProfile) => void;
  onClose: () => void;
}

const CustomizerView: React.FC<CustomizerViewProps> = ({ user, onUpdateUser, onClose }) => {
  const [activeTab, setActiveTab] = useState<'chat' | 'preview' | 'code' | 'history'>('chat');
  const [chatPrompt, setChatPrompt] = useState('');
  const [chatResponse, setChatResponse] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [draftSettings, setDraftSettings] = useState(user.customizerSettings || {});
  
  const createCheckpoint = () => {
    const newCheckpoint = {
        id: Date.now().toString(),
        timestamp: Date.now(),
        settings: { ...draftSettings }
    };
    onUpdateUser({ ...user, checkpoints: [...(user.checkpoints || []), newCheckpoint] });
  };

  const handleChat = async () => {
    if (!chatPrompt) return;
    setIsProcessing(true);
    setChatResponse(''); 
    try {
        const response = await fetch('/api/gemini/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt: `You are an expert UI customizer and Theme Generator for Aether IDE. The user wants this: ${chatPrompt}. 
            Generate a complete JSON configuration for settings like uiBackground, accentColor, uiDensity, font, particleEffects, animationSpeed, etc. 
            Provide the response as JSON wrapped in backticks (e.g. \`\`\`json {...} \`\`\`), and include a short explanation in markdown. You can emulate systems like Windows, macOS, Android, or create completely custom themes.`,
            currentFiles: [],
            history: [],
            attachments: [],
            modelId: "gemini-3.1-pro-preview"
          })
        });
        
        if (!response.ok) {
          throw new Error("Failed to communicate with AI customizer service");
        }
        
        const data = await response.json();
        const text = data.message || '';
        setChatResponse(text);

        const jsonMatch = text.match(/```json\n([\s\S]*?)\n```/);
        if (jsonMatch && jsonMatch[1]) {
            try {
                const parsed = JSON.parse(jsonMatch[1]);
                const newSettings = { ...draftSettings, ...parsed };
                setDraftSettings(newSettings);
            } catch (e) {
                console.error("Failed to parse AI configuration", e);
            }
        }
    } catch(err) {
        setChatResponse('Error generating response.');
    }
    setIsProcessing(false);
  };
  
  const handleApplyDraft = () => {
      createCheckpoint();
      onUpdateUser({ ...user, customizerSettings: draftSettings });
  };
  
  const handleRevert = (settings?: any) => {
      setDraftSettings(settings || user.customizerSettings || {});
  };

  const DEFAULT_THEMES = {
      "Modern Dark": { uiBackground: "#030303", accentColor: "#6366f1", uiDensity: "comfortable" },
      "Minimalist Light": { uiBackground: "#f3f4f6", accentColor: "#111827", uiDensity: "compact" },
      "Aether Neo": { uiBackground: "#0f172a", accentColor: "#22d3ee", uiDensity: "comfortable" },
      "Windows 11": { uiBackground: "#f3f3f3", accentColor: "#0067c0", uiDensity: "spacious", font: "Segoe UI" },
      "macOS Aqua": { uiBackground: "#f5f5f7", accentColor: "#007aff", uiDensity: "comfortable", font: "San Francisco" },
      "Android Material": { uiBackground: "#1e1e1e", accentColor: "#d0bcff", uiDensity: "comfortable", font: "Roboto" }
  };

  const handleApplyTheme = (themeName: string) => {
      setDraftSettings({ ...draftSettings, ...(DEFAULT_THEMES as any)[themeName] });
  };

  const handleExportJSON = () => {
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(draftSettings, null, 2));
      const downloadAnchorNode = document.createElement('a');
      downloadAnchorNode.setAttribute("href", dataStr);
      downloadAnchorNode.setAttribute("download", "theme_config.json");
      document.body.appendChild(downloadAnchorNode);
      downloadAnchorNode.click();
      downloadAnchorNode.remove();
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
          try {
              const json = JSON.parse(ev.target?.result as string);
              setDraftSettings({ ...draftSettings, ...json });
          } catch (e) {
              alert("Invalid JSON file");
          }
      };
      reader.readAsText(file);
      e.target.value = '';
  };

  return (
    <div className="flex-1 h-full w-full overflow-y-auto bg-aether-bg p-4 md:p-6 pb-24 custom-scrollbar animate-in fade-in duration-300">
      <input type="file" id="json-upload" className="hidden" accept=".json" onChange={handleImportJSON} />
      <div className="max-w-4xl mx-auto space-y-6">
        <header className="flex items-center justify-between">
            <h1 className="text-2xl font-bold text-white flex items-center gap-3">
              <Palette className="text-aether-accent" />
              Workspace Theme & Style
            </h1>
          <button onClick={onClose} className="p-2 rounded-full hover:bg-white/10 text-aether-muted hover:text-white">
            <X size={20} />
          </button>
        </header>

        {/* Tabs */}
        <div className="flex items-center gap-1 bg-aether-panel p-1 rounded-xl border border-white/5 overflow-x-auto">
            {[ {id: 'chat', label: 'Chat', icon: MessageSquare}, {id: 'preview', label: 'Preview', icon: Eye}, {id: 'code', label: 'Code', icon: Code}, {id: 'history', label: 'History', icon: RotateCcw} ].map(tab => (
                <button key={tab.id} onClick={() => setActiveTab(tab.id as any)} className={`flex-1 min-w-[80px] py-2 flex items-center justify-center gap-2 rounded-lg text-xs font-bold transition-all ${activeTab === tab.id ? 'bg-aether-accent text-black' : 'text-aether-muted hover:text-white'}`}>
                    <tab.icon size={14} /> {tab.label}
                </button>
            ))}
        </div>

        {activeTab === 'chat' && (
            <div className="bg-aether-panel border border-white/10 rounded-2xl p-4 md:p-6 space-y-4">
               <textarea 
                  value={chatPrompt}
                  onChange={(e) => setChatPrompt(e.target.value)}
                  placeholder="e.g., 'Make it look exactly like Windows 11' or 'Android Material You Theme'..."
                  className="w-full bg-black/50 border border-aether-border rounded-xl p-4 text-sm text-white outline-none focus:border-aether-accent min-h-[120px] resize-none"
               />
               <button 
                  onClick={handleChat}
                  disabled={isProcessing}
                  className="w-full py-3 bg-aether-accent text-black rounded-xl font-bold hover:brightness-110 transition-all disabled:opacity-50"
               >
                  {isProcessing ? 'Generating...' : 'Generate Customization'}
               </button>
               {chatResponse && (
                 <div className="bg-black/80 rounded-xl p-4 text-sm mt-4 border border-white/10 text-white markdown-body">
                    <ReactMarkdown>{chatResponse}</ReactMarkdown>
                 </div>
               )}
            </div>
        )}

        {activeTab === 'preview' && (
            <div className="bg-aether-panel border border-white/10 rounded-2xl p-6 min-h-[200px] flex flex-col gap-6">
                <div className="space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-aether-muted block">Theme Presets</label>
                    <div className="flex flex-wrap gap-2">
                       {Object.keys(DEFAULT_THEMES).map(t => (
                           <button key={t} onClick={() => handleApplyTheme(t)} className="px-3 py-1.5 bg-white/5 border border-white/5 rounded-lg text-xs hover:bg-white/10 hover:border-white/10 text-white font-semibold transition-all">
                               {t}
                           </button>
                       ))}
                    </div>
                </div>

                <div className="flex-1 min-h-[140px] flex items-center justify-center rounded-xl text-aether-muted border border-white/5"
                     style={{ backgroundColor: draftSettings.uiBackground || undefined }}>
                    <div className="text-center space-y-2">
                        <Eye size={32} className="mx-auto text-aether-accent animate-pulse" />
                        <p style={{ color: draftSettings.accentColor || 'inherit' }} className="text-xs font-bold uppercase tracking-widest">Live preview active</p>
                        <div className="px-4 py-2 rounded-lg border border-white/10 mt-2 text-xs font-semibold" style={{ padding: draftSettings.uiDensity === 'compact' ? '4px 8px' : '8px 16px', color: draftSettings.accentColor || 'inherit' }}>
                            Sample UI Component
                        </div>
                    </div>
                </div>

                {/* Manual Settings controls */}
                <div className="border-t border-white/5 pt-4 space-y-4">
                    <div>
                        <label className="text-[10px] font-black uppercase tracking-widest text-aether-muted block mb-2">Motion Profile</label>
                        <div className="grid grid-cols-3 gap-2">
                            {(['Fluid', 'Snap', 'Reduced'] as const).map((preset) => (
                                <button
                                    key={preset}
                                    onClick={() => setDraftSettings({ ...draftSettings, motionPreset: preset })}
                                    className={`py-2 px-3 rounded-lg border text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                                        (draftSettings.motionPreset || 'Fluid') === preset
                                            ? 'bg-aether-accent/10 border-aether-accent text-aether-accent'
                                            : 'bg-white/5 border-white/5 text-aether-muted hover:text-white hover:bg-white/10'
                                    }`}
                                >
                                    <Zap size={12} className={preset === 'Reduced' ? 'opacity-30' : ''} />
                                    {preset}
                                </button>
                            ))}
                        </div>
                        <p className="text-[10px] text-aether-muted mt-1.5 leading-relaxed">
                            {(draftSettings.motionPreset || 'Fluid') === 'Fluid' && 'Fluid: Smooth, natural, custom spring easing for a cinematic feel.'}
                            {(draftSettings.motionPreset || 'Fluid') === 'Snap' && 'Snap: Ultra-fast, immediate spring physics with aggressive stiffness.'}
                            {(draftSettings.motionPreset || 'Fluid') === 'Reduced' && 'Reduced: Essential linear fades with no spring oscillations, ideal for low performance.'}
                        </p>
                    </div>

                    <div>
                        <label className="text-[10px] font-black uppercase tracking-widest text-aether-muted block mb-2">UI Density</label>
                        <div className="grid grid-cols-2 gap-2">
                            {(['compact', 'cozy'] as const).map((density) => (
                                <button
                                    key={density}
                                    onClick={() => setDraftSettings({ ...draftSettings, uiDensity: density })}
                                    className={`py-2 px-3 rounded-lg border text-xs font-bold transition-all capitalize cursor-pointer ${
                                        (draftSettings.uiDensity || 'cozy') === density
                                            ? 'bg-aether-accent/10 border-aether-accent text-aether-accent'
                                            : 'bg-white/5 border-white/5 text-aether-muted hover:text-white hover:bg-white/10'
                                    }`}
                                >
                                    {density}
                                </button>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        )}

        {activeTab === 'code' && (
            <div className="space-y-4">
                <div className="flex gap-2">
                    <button onClick={() => document.getElementById('json-upload')?.click()} className="flex-1 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-xs font-bold text-white">Import JSON</button>
                    <button onClick={handleExportJSON} className="flex-1 py-2 bg-white/10 hover:bg-white/20 rounded-lg text-xs font-bold text-white">Export JSON</button>
                </div>
                <div className="bg-black rounded-2xl p-4 md:p-6 font-mono text-xs text-green-400 overflow-x-auto">
                    <pre>{JSON.stringify(draftSettings, null, 2)}</pre>
                </div>
            </div>
        )}
        
        {activeTab === 'history' && (
            <div className="bg-aether-panel border border-white/10 rounded-2xl p-4 space-y-2">
                {user.checkpoints?.map((cp) => (
                    <div key={cp.id} className="flex justify-between items-center bg-black/40 p-3 rounded-lg border border-white/5 text-xs text-white">
                        <span>{new Date(cp.timestamp).toLocaleString()}</span>
                        <button onClick={() => handleRevert(cp.settings)} className="text-aether-accent font-bold hover:underline">Revert</button>
                    </div>
                ))}
            </div>
        )}

        {/* Actions */}
        <div className="flex gap-2">
            <button onClick={handleApplyDraft} className="flex-1 py-3 bg-green-600 rounded-xl text-sm font-bold text-black border border-green-500">Apply Settings</button>
            <button onClick={() => handleRevert()} className="flex-1 py-3 bg-red-900/50 rounded-xl text-sm font-bold text-red-100 border border-red-700">Discard</button>
            <button onClick={() => setDraftSettings({})} className="flex-1 py-3 bg-white/5 rounded-xl text-sm font-bold text-white border border-white/10">Reset Default</button>
        </div>
      </div>
    </div>
  );
};
export default CustomizerView;
