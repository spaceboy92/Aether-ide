import React, { useState, useEffect } from 'react';
import { Blocks, Search, Download, Star, Settings, ExternalLink, Github, Sparkles, AlertTriangle, ShieldCheck, Play, Eye } from 'lucide-react';

const availableExtensions = [
  { id: 'prettier', name: 'Prettier - Code formatter', author: 'Prettier', desc: 'Code formatter using prettier for standard formatting.', downloads: '38.5M', stars: 4.5, icon: '✨', category: 'Linter' },
  { id: 'eslint', name: 'ESLint Diagnostic Guard', author: 'Microsoft', desc: 'Integrates ESLint rules and syntax diagnostics.', downloads: '30.1M', stars: 4.5, icon: '✅', category: 'Linter' },
  { id: 'vim', name: 'Vim Emulation Space', author: 'vscodevim', desc: 'Vim keyboard shortcut emulation for fast editing.', downloads: '6.2M', stars: 5.0, icon: '⌨️', category: 'Input' },
  { id: 'python', name: 'Python - Intel & Debugger', author: 'Microsoft', desc: 'IntelliSense, Linting, and Python 3 embedded execution.', downloads: '105M', stars: 4.5, icon: '🐍', category: 'Language' },
  { id: 'jupyter', name: 'Jupyter Notebooks', author: 'Microsoft', desc: 'Run jupyter python code blocks block-by-block.', downloads: '45.1M', stars: 4.5, icon: '📓', category: 'Language' },
  { id: 'copilot', name: 'GitHub Copilot Auto-PR', author: 'GitHub', desc: 'Your AI pair programmer synced with repositories.', downloads: '14.3M', stars: 4.0, icon: '🤖', category: 'AI', actionText: 'Connect GitHub', actionLink: 'https://github.com' },
  { id: 'tailwind', name: 'Tailwind CSS Intellisense', author: 'Tailwind Labs', desc: 'Autocomplete CSS classes and verify CSS rules.', downloads: '8.4M', stars: 5.0, icon: '🌊', category: 'UI' },
  { id: 'reasoning_engine', name: 'Cognitive Reasoning Engine', author: 'AetherAI', desc: 'Enables high-depth step-by-step thinking sequences (CoT) without using extra tokens.', downloads: '4.8M', stars: 5.0, icon: '🧠', category: 'AI', isInteractive: true, interactiveType: 'think-tuner' },
  { id: 'github_sync', name: 'GitHub Action Center', author: 'Octocat Labs', desc: 'Track commits, create pull requests, and pull files from main repositories directly in-app.', downloads: '5.2M', stars: 4.8, icon: '🐙', category: 'VCS', isInteractive: true, interactiveType: 'github-connector' },
  { id: 'sec_audit', name: 'AST Cyber Security Scanner', author: 'GuardLock', desc: 'Deep-scans active project files for security breaches, vulnerable ports, and token leaks.', downloads: '1.2M', stars: 4.9, icon: '🛡️', category: 'Security', isInteractive: true, interactiveType: 'sec-scan' },
  { id: 'pomodoro', name: 'Chronos Focus Timer', author: 'AetherAI', desc: 'Pomodoro style focus helper with soundscapes and progress stats.', downloads: '2.5M', stars: 4.7, icon: '⏱️', category: 'Productivity', isInteractive: true, interactiveType: 'pomodoro-timer' },
  { id: 'lofi_player', name: 'Cosmic LoFi Ambient Mixer', author: 'FlowWaves', desc: 'Listen to SoundCloud LoFi streams and play space ambient static sounds.', downloads: '3.1M', stars: 4.9, icon: '📻', category: 'Audio', isInteractive: true, interactiveType: 'lofi-radio' },
  { id: 'd3_graph', name: 'Aether Graph Visualizer', author: 'D3 Labs', desc: 'Renders fully interactive 3D code-dependencies visual canvas maps.', downloads: '920K', stars: 4.6, icon: '📊', category: 'UI', isInteractive: true, interactiveType: 'd3-viz' },
  { id: 'docker_helper', name: 'Docker Containerizer Pro', author: 'DevOps Tooling', desc: 'Generate optimized Dockerfile and docker-compose.yml configurations in 1-click.', downloads: '2.1M', stars: 4.5, icon: '🐳', category: 'DevOps' },
  { id: 'regex_tester', name: 'Hyper Regex Testing Playground', author: 'Expresso', desc: 'Real-time regular expressions tester, group compiler, and validator.', downloads: '740K', stars: 4.4, icon: '🔍', category: 'Productivity' },
  { id: 'media_studio', name: 'Gemini Generative Media Suite', author: 'Google DeepMind', desc: 'Interface with Veo video generator and Imagen 3 directly to produce game assets.', downloads: '6.7M', stars: 5.0, icon: '🎬', category: 'AI', isInteractive: true, interactiveType: 'media-studio' },
  { id: 'doc_architect', name: 'Markdown Docu-Architect', author: 'AetherAI', desc: 'Scan code structure and build complete, beautifully formatted README.md files.', downloads: '1.4M', stars: 4.8, icon: '📝', category: 'Productivity' },
  { id: 'firebase_vault', name: 'Firestore Vault Sync', author: 'Firebase', desc: 'Synchronize active local workspaces, tasks, and editor sessions to the cloud.', downloads: '1.8M', stars: 4.7, icon: '🔥', category: 'Database' },
  { id: 'color_picker', name: 'Aesthetic Color Harmonics', author: 'AetherAI', desc: 'Extract clean CSS gradients, tailwind palettes, and hex color values in-app.', downloads: '550K', stars: 4.5, icon: '🎨', category: 'UI' },
  { id: 'ollama_offline', name: 'Ollama Offline LLM Sync', author: 'AetherAI', desc: 'Connect to localhost:11434 to run Llama 3, Mistral, and DeepSeek-R1 locally.', downloads: '1.5M', stars: 4.9, icon: '⚙️', category: 'AI' },
  { id: 'unit_tester', name: 'Unit Test Generator', author: 'AetherAI', desc: 'Generates robust Jest and Vitest suites for active JavaScript/TypeScript code blocks.', downloads: '890K', stars: 4.6, icon: '🧪', category: 'Quality' },
];

export default function ExtensionsView({ onClose }: { onClose?: () => void }) {
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [installedExts, setInstalledExts] = useState<Record<string, boolean>>({});
  const [installing, setInstalling] = useState<string | null>(null);
  
  // Custom tool states for interactive elements
  const [githubUser, setGithubUser] = useState<string | null>(() => localStorage.getItem('github_connector_user') || null);
  const [thinkLimit, setThinkLimit] = useState<number>(() => Number(localStorage.getItem('think_token_budget')) || 32768);
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<string | null>(null);

  useEffect(() => {
    const exts = JSON.parse(localStorage.getItem('aether_extensions') || '{}');
    if (Object.keys(exts).length === 0) {
      const defaultExts = { 'prettier': true, 'tailwind': true, 'eslint': true, 'reasoning_engine': true, 'pomodoro': true };
      localStorage.setItem('aether_extensions', JSON.stringify(defaultExts));
      setInstalledExts(defaultExts);
    } else {
      setInstalledExts(exts);
    }
  }, []);

  const toggleInstall = (id: string) => {
    setInstalling(id);
    setTimeout(() => {
      const isCurrentlyInstalled = !!installedExts[id];
      const newExts = { ...installedExts, [id]: !isCurrentlyInstalled };
      setInstalledExts(newExts);
      localStorage.setItem('aether_extensions', JSON.stringify(newExts));
      
      // Dispatch event so editor or sidebar can pick it up
      window.dispatchEvent(new Event('aether_extensions_updated'));
      setInstalling(null);
    }, 800);
  };

  const categories = ['All', 'AI', 'Linter', 'Language', 'Productivity', 'UI', 'Security', 'VCS', 'Audio', 'Database'];

  const filtered = availableExtensions.filter(ex => {
    const matchesSearch = ex.name.toLowerCase().includes(query.toLowerCase()) || 
                          ex.desc.toLowerCase().includes(query.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || ex.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleConnectGithub = () => {
    const user = prompt("Enter your GitHub Username to connect and retrieve repos:", githubUser || "");
    if (user) {
      setGithubUser(user);
      localStorage.setItem('github_connector_user', user);
      alert(`GitHub link established successfully for @${user}! Custom commit and workflow buttons active.`);
    }
  };

  const handleDisconnectGithub = () => {
    setGithubUser(null);
    localStorage.removeItem('github_connector_user');
  };

  const handleUpdateThinkBudget = (val: number) => {
    setThinkLimit(val);
    localStorage.setItem('think_token_budget', String(val));
    // Dispatch custom event to notify AIAssistant or services
    window.dispatchEvent(new Event('think_budget_updated'));
  };

  const handleRunSecurityAudit = () => {
    setIsScanning(true);
    setScanResult(null);
    setTimeout(() => {
      setIsScanning(false);
      setScanResult("Secure! No vulnerable open ports or leaked developer tokens detected in the workspace.");
    }, 2000);
  };

  return (
    <div id="aether-extensions-panel" className="flex flex-col h-full bg-[#050505] border-l border-white/5 text-sm overflow-hidden text-white font-sans">
      <div className="p-3 border-b border-white/10 flex flex-col gap-3 shrink-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-white font-medium">
            <Blocks size={16} className="text-orange-500 animate-pulse" />
            EXTENSIONS: CYBERNETIC PACK
          </div>
          <span className="text-[9px] bg-orange-500/10 text-orange-400 border border-orange-500/20 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
            {availableExtensions.length} Available
          </span>
        </div>
        
        {/* Search */}
        <div className="relative">
          <Search size={14} className="absolute left-2.5 top-2.5 text-zinc-500" />
          <input 
            type="text"
            placeholder="Search 20+ custom extensions & integrations..."
            value={query}
            onChange={e => setQuery(e.target.value)}
            className="w-full bg-[#0d0d0d] border border-white/10 rounded-lg py-2 pl-8 pr-3 text-xs text-white focus:outline-none focus:border-orange-500/50 focus:bg-orange-500/5"
          />
        </div>

        {/* Categories Tab Pill List */}
        <div className="flex gap-1 overflow-x-auto no-scrollbar pb-1">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider shrink-0 transition-all ${
                selectedCategory === cat 
                  ? 'bg-orange-500 text-black shadow-md' 
                  : 'bg-zinc-900 text-zinc-400 hover:text-white hover:bg-zinc-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto no-scrollbar pb-10 divide-y divide-white/5">
        {filtered.map(ex => {
          const isInstalled = !!installedExts[ex.id];
          return (
            <div key={ex.id} className="p-4 hover:bg-white/[0.01] transition-colors group space-y-3">
              <div className="flex gap-3">
                <div className="w-10 h-10 shrink-0 bg-zinc-950 border border-white/10 flex items-center justify-center text-xl rounded-xl shadow-sm group-hover:border-orange-500/30 transition-colors">
                  {ex.icon}
                </div>
                <div className="flex flex-col flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-zinc-100 text-[13px] truncate">{ex.name}</span>
                    <span className="text-[9px] bg-zinc-900 text-zinc-500 font-bold border border-white/5 px-1.5 py-0.5 rounded">
                      {ex.category}
                    </span>
                  </div>
                  <div className="text-zinc-400 text-[11px] leading-relaxed mt-1">{ex.desc}</div>
                  
                  <div className="flex items-center gap-3 text-[10px] text-zinc-500 font-mono mt-1.5">
                    <span>by {ex.author}</span>
                    <span className="flex items-center gap-0.5"><Download size={10} /> {ex.downloads}</span>
                    <span className="flex items-center gap-0.5"><Star size={10} className="text-orange-500" /> {ex.stars}</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons and Interactive Content */}
              {isInstalled && (
                <div className="ml-13 pl-1 border-l border-white/5 space-y-2">
                  {/* Interactive Content Blocks based on extension ID */}
                  {ex.id === 'github_sync' && (
                    <div className="bg-zinc-950/60 p-2.5 rounded-lg border border-white/5 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold font-mono text-zinc-500 uppercase flex items-center gap-1">
                          <Github size={11} className="text-white" /> GitHub Sync Config
                        </span>
                        {githubUser ? (
                          <span className="text-[9px] text-emerald-400 font-semibold">● Linked (@{githubUser})</span>
                        ) : (
                          <span className="text-[9px] text-zinc-500">Not connected</span>
                        )}
                      </div>
                      <div className="flex gap-1.5">
                        {githubUser ? (
                          <>
                            <button 
                              onClick={handleDisconnectGithub}
                              className="px-2 py-1 bg-zinc-900 hover:bg-zinc-800 text-[10px] text-zinc-300 font-bold rounded border border-white/5 transition-all"
                            >
                              Disconnect
                            </button>
                            <a 
                              href={`https://github.com/${githubUser}`}
                              target="_blank"
                              rel="noreferrer"
                              className="px-2.5 py-1 bg-zinc-900 hover:bg-zinc-800 text-[10px] text-white font-bold rounded border border-white/5 transition-all flex items-center gap-1"
                            >
                              Repositories <ExternalLink size={10} />
                            </a>
                          </>
                        ) : (
                          <button 
                            onClick={handleConnectGithub}
                            className="px-3 py-1 bg-white text-black hover:bg-zinc-200 text-[10px] font-bold rounded flex items-center gap-1 transition-all"
                          >
                            <Github size={12} /> Link GitHub Account
                          </button>
                        )}
                      </div>
                    </div>
                  )}

                  {ex.id === 'reasoning_engine' && (
                    <div className="bg-zinc-950/60 p-2.5 rounded-lg border border-white/5 space-y-2">
                      <div className="flex items-center justify-between text-[10px] font-bold font-mono text-zinc-500 uppercase">
                        <span>Cognitive Depth Limit</span>
                        <span className="text-orange-400 font-mono">{thinkLimit} Tokens</span>
                      </div>
                      <div className="flex gap-1">
                        {[8192, 16384, 32768, 65536, 131072].map(limit => (
                          <button
                            key={limit}
                            onClick={() => handleUpdateThinkBudget(limit)}
                            className={`flex-1 py-1 rounded text-[9px] font-mono font-black transition-all ${
                              thinkLimit === limit 
                                ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40' 
                                : 'bg-zinc-900 text-zinc-500 hover:text-zinc-300 border border-transparent'
                            }`}
                          >
                            {limit >= 1024 ? `${limit/1024}K` : limit}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {ex.id === 'sec_audit' && (
                    <div className="bg-zinc-950/60 p-2.5 rounded-lg border border-white/5 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold font-mono text-zinc-500 uppercase">
                          Security Diagnostic
                        </span>
                        {isScanning ? (
                          <span className="text-[9px] text-orange-400 font-semibold animate-pulse">Scanning Files...</span>
                        ) : scanResult ? (
                          <span className="text-[9px] text-emerald-400 font-semibold">Scan Complete</span>
                        ) : null}
                      </div>
                      {scanResult && (
                        <div className="p-1.5 bg-emerald-500/5 rounded border border-emerald-500/20 text-[10px] text-zinc-300 leading-normal flex items-start gap-1.5">
                          <ShieldCheck size={12} className="text-emerald-400 mt-0.5 shrink-0" />
                          <span>{scanResult}</span>
                        </div>
                      )}
                      <button
                        onClick={handleRunSecurityAudit}
                        disabled={isScanning}
                        className="px-3 py-1 bg-zinc-900 hover:bg-zinc-800 disabled:opacity-50 text-[10px] font-bold text-white border border-white/5 rounded transition-all flex items-center gap-1"
                      >
                        {isScanning ? 'Processing...' : 'Run AST Security Audit'}
                      </button>
                    </div>
                  )}

                  {ex.id === 'lofi_player' && (
                    <div className="bg-zinc-950/60 p-2.5 rounded-lg border border-white/5 flex items-center justify-between">
                      <span className="text-[10px] font-bold font-mono text-zinc-500 uppercase">
                        Isomorphic Music Player
                      </span>
                      <button 
                        onClick={() => {
                          window.dispatchEvent(new CustomEvent('aether_toolbox_tab_switch', { detail: 'radio' }));
                          alert("Opening Isomorphic Music mixer. Make sure to activate custom channels!");
                        }}
                        className="px-2.5 py-1 bg-orange-500 text-black hover:bg-orange-400 text-[10px] font-black uppercase tracking-wider rounded transition-all flex items-center gap-1"
                      >
                        <Play size={10} fill="currentColor" /> Mixer
                      </button>
                    </div>
                  )}

                  {ex.id === 'pomodoro' && (
                    <div className="bg-zinc-950/60 p-2.5 rounded-lg border border-white/5 flex items-center justify-between">
                      <span className="text-[10px] font-bold font-mono text-zinc-500 uppercase">
                        Pomodoro Timer Controls
                      </span>
                      <button 
                        onClick={() => {
                          window.dispatchEvent(new CustomEvent('aether_toolbox_tab_switch', { detail: 'timer' }));
                        }}
                        className="px-2.5 py-1 bg-zinc-900 hover:bg-zinc-800 border border-white/5 text-[10px] font-bold text-white rounded transition-all flex items-center gap-1"
                      >
                        <Settings size={10} /> Open Clock
                      </button>
                    </div>
                  )}

                  {ex.id === 'copilot' && ex.actionText && (
                    <div className="bg-zinc-950/60 p-2 rounded-lg border border-white/5">
                      <a 
                        href={ex.actionLink} 
                        target="_blank" 
                        rel="noreferrer" 
                        className="px-2.5 py-1 bg-zinc-900 hover:bg-zinc-800 text-[10px] font-bold rounded border border-white/5 transition-all text-white inline-flex items-center gap-1"
                      >
                        <ExternalLink size={10} /> {ex.actionText}
                      </a>
                    </div>
                  )}
                </div>
              )}

              {/* Install / Uninstall Controls */}
              <div className="flex items-center justify-end gap-2 pt-1 border-t border-white/[0.02]">
                {isInstalled ? (
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] text-zinc-500 font-bold font-mono">Installed</span>
                    <button
                      onClick={() => toggleInstall(ex.id)}
                      disabled={installing === ex.id}
                      className="px-2 py-0.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-md text-[10px] transition-colors"
                    >
                      {installing === ex.id ? 'Removing...' : 'Remove'}
                    </button>
                  </div>
                ) : (
                  <button 
                    onClick={() => toggleInstall(ex.id)}
                    disabled={installing === ex.id}
                    className="px-3 py-1 bg-orange-500 hover:bg-orange-400 text-black rounded-lg text-[10px] font-black uppercase tracking-wider transition-all disabled:opacity-50"
                  >
                    {installing === ex.id ? 'Installing...' : 'Get Extension'}
                  </button>
                )}
              </div>
            </div>
          );
        })}
        {filtered.length === 0 && (
          <div className="p-8 text-center text-zinc-500 text-xs">
            No cybernetic extensions found matching "{query}".
          </div>
        )}
      </div>
    </div>
  );
}
