import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ChevronRight, 
  Plus,
  Search,
  Trash2,
  Sparkles,
  MessageSquare,
  Zap,
  ArrowRight,
  Clock,
  LayoutGrid
} from 'lucide-react';
import { ChatSession, UserProfile } from '../../types';

interface HomeDashboardProps {
  user?: UserProfile | null;
  sessions: ChatSession[];
  onSelectSession: (id: string) => void;
  onCreateSession: () => void;
  onDeleteSession: (id: string) => void;
  onStartTemplate?: (title: string, prompt: string) => void;
}

const HomeDashboard: React.FC<HomeDashboardProps> = ({ 
  user,
  sessions, 
  onSelectSession, 
  onCreateSession,
  onDeleteSession,
  onStartTemplate
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  
  const filteredSessions = sessions.filter(s => {
    if (!s) return false;
    const q = searchQuery ? searchQuery.toLowerCase() : "";
    const titleMatch = s.title ? s.title.toLowerCase().includes(q) : false;
    return titleMatch;
  });

  const renderSessionItem = (session: ChatSession, idx: number) => (
    <motion.div
      key={session.id}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: idx * 0.03, duration: 0.4 }}
      whileHover={{ scale: 1.01 }}
      whileTap={{ scale: 0.99 }}
      onClick={() => onSelectSession(session.id)}
      className="group flex items-center justify-between p-4 rounded-xl bg-white/[0.03] hover:bg-white/[0.08] transition-all cursor-pointer mb-2"
    >
      <div className="flex items-center gap-4">
        <div className="min-w-0">
          <h4 className="text-sm font-medium text-white truncate">{session.title}</h4>
          <p className="text-xs text-white/40 mt-1 truncate max-w-[200px] sm:max-w-[400px]">
             {session.messages[session.messages.length - 1]?.text || 'Empty'}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-4">
        <div className="text-xs text-white/30 hidden md:block">{new Date(session.lastUpdated).toLocaleDateString()}</div>
        <button 
          onClick={(e) => { e.stopPropagation(); onDeleteSession(session.id); }}
          className="text-white/20 hover:text-red-400 transition-colors"
        >
          <Trash2 size={16} />
        </button>
      </div>
    </motion.div>
  );

  return (
    <div className="flex flex-col h-full bg-transparent text-white overflow-hidden relative selection:bg-white/20">
      <div className="flex-1 overflow-y-auto no-scrollbar relative z-10 px-8 py-16">
        <div className="max-w-4xl mx-auto space-y-16">
          <section className="space-y-6">
            <motion.h1 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8 }}
              className="text-4xl font-light tracking-tight text-white/90"
            >
              Good {new Date().getHours() < 12 ? 'morning' : 'evening'}, <span className="font-normal text-white">{user?.name || 'Explorer'}</span>.
            </motion.h1>
            
            <motion.button 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              onClick={onCreateSession}
              className="group flex items-center gap-2 px-6 py-3 bg-white text-black rounded-lg text-sm font-medium hover:bg-white/90 transition-all"
            >
              <Plus size={16} />
              New Chat
            </motion.button>
          </section>

          <section className="space-y-6">
            <div className="flex items-center gap-3 border-b border-white/10 pb-4">
              <Search size={18} className="text-white/40" />
              <input 
                type="text" 
                placeholder="Search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent border-none outline-none text-sm text-white placeholder:text-white/40 font-light"
              />
            </div>

            <div className="space-y-2">
               {filteredSessions.length > 0 ? (
                 filteredSessions.map((s, i) => renderSessionItem(s, i))
               ) : (
                 <div className="text-white/30 text-sm font-light py-8 text-center">
                    No sessions found.
                 </div>
               )}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default HomeDashboard;
