import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, Settings, Save, Trash2, Plus, Play, Code, 
  MessageSquare, Image as ImageIcon, FileText, X, 
  ChevronDown, ChevronRight, Loader2, Copy, Check,
  Maximize2, Minimize2, Download, Share2, Book, Sparkles,
  Sliders, ShieldAlert, Cpu, Coins, Activity, Volume2, 
  VolumeX, Mic, Table, PlusCircle, Layers, FileCode, CheckCircle, HelpCircle, ArrowUp, Clock
} from 'lucide-react';
import { generateContent, generateContentStream, AVAILABLE_MODELS } from '../../services/aiService';
import { UserProfile } from '../../types';

interface Message {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
  attachments?: { name: string; type: 'image' | 'file'; data: string; mimeType: string }[];
}

interface TestCase {
  id: string;
  variables: Record<string, string>;
  output?: string;
  isProcessing?: boolean;
  error?: string;
  latency?: number; // ms
  charSpeed?: number; // chars per second
}

interface SafetyCategory {
  id: string;
  name: string;
  description: string;
  level: 'block_none' | 'block_few' | 'block_some' | 'block_most';
}

interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  modelId: string;
  systemInstruction: string;
  temperature: number;
  topK: number;
  topP: number;
  maxOutputTokens: number;
  // Freeform variable state
  mode: 'chat' | 'freeform';
  promptTemplate: string;
  testCases: TestCase[];
}

const DEFAULT_SESSION: ChatSession = {
  id: 'new',
  title: 'Untitled Prompt',
  messages: [],
  modelId: 'gemini-3.5-flash',
  systemInstruction: 'You are an advanced Application & 3D/2D Game AI Copilot. You generate complete, production-ready code decomposed across a clean multi-file project architecture (index.html, style.css, script.js / App.tsx, gameEngine.js). NEVER dump inline <style> or <script> tags into a single monolithic index.html file unless explicitly asked. Focus on modern Tailwind user interfaces, shadow-mapped WebGL graphics, client-side Web Audio synthesizers, and clean, modular application state managers.',
  temperature: 0.7,
  topK: 40,
  topP: 0.95,
  maxOutputTokens: 65536,
  mode: 'chat',
  promptTemplate: 'Optimize the following logic for performant execution in JavaScript:\n\n```js\n{{code}}\n```\n\nEnsure writing a clean, high-performance solution explaining why the updates are {{criteria}}.',
  testCases: [
    {
      id: 'tc-1',
      variables: { code: 'function multiply(arr) {\n  let x = 1;\n  for(let i=0; i<arr.length; i++) {\n    x = x * arr[i];\n  }\n  return x;\n}', criteria: 'optimal and memory-friendly' },
      output: ''
    },
    {
      id: 'tc-2',
      variables: { code: 'function findUnique(arr) {\n  let res = [];\n  for (let x of arr) {\n    if (!res.includes(x)) res.push(x);\n  }\n  return res;\n}', criteria: 'faster using HashSets' },
      output: ''
    }
  ]
};

// Preset Prompt Recipes (Extra Content Feature)
const PRESET_RECIPES = [
  {
    category: 'Developer Core',
    title: 'Type Schema Creator',
    description: 'Generates polished TypeScript schemas and validation rules.',
    system: 'You are an expert TypeScript architect. Convert the raw JSON or specification into high-fidelity Type declarations and optional Zod checkers.',
    template: 'Create a fully strictly-typed interface and matching Zod validator for a scenario with these fields:\n\n{{schema_fields}}\n\nWrite exhaustive types, jsdoc annotations, and describe nesting details.',
    vars: { schema_fields: 'id (uuid), name (string), email (validated), address (nested object with city, street, zipcode)' },
    model: 'gemini-3.1-pro-preview'
  },
  {
    category: 'Developer Core',
    title: 'SQL Query Architect',
    description: 'Safely converts natural queries into complex postgres instructions.',
    system: 'You are an expert PostgreSQL database analyst. Generate optimized SQL structures formatted clearly. Keep operations secure from SQL injection.',
    template: 'Formulate an optimized query that handles this requirement:\n\n{{requirement}}\n\nFor a schema involving these tables: {{tables}}.\n\nInclude indexes recommendations if applicable.',
    vars: { requirement: 'Calculates the year-over-year active user stickiness and transaction volumes', tables: 'users, payments, orders, login_logs' },
    model: 'gemini-3.5-flash'
  },
  {
    category: 'AI & Creative Workspace',
    title: '3D Physics World Generation',
    description: 'Generates complex 3D procedural scenes with custom geometry and physics interactions.',
    system: 'You are an advanced graphics engineer proficient in WebGL and native Three.js. You only use vanilla HTML/JS without React.',
    template: 'Generate vanilla Three.js and Cannon.js code for a 3D environment including: {{features}}. Include physics interaction with rigid bodies and collisions.',
    vars: { features: 'Procedural custom mesh using vertices/indices, distinct distinct textured shapes, lighting, and an animated character' },
    model: 'gemini-3.1-pro-preview'
  },
  {
    category: 'AI & Creative Workspace',
    title: '2D Game Engine Generator',
    description: 'Generates logic and mechanics for a complete 2D browser game engine.',
    system: 'You are a veteran game developer specializing in high-performance 2D HTML5 canvas games.',
    template: 'Build an interactive 2D game engine mechanism focusing on {{mechanic}} using pure HTML5 Canvas and JavaScript. Features include {{features}}.',
    vars: { mechanic: 'advanced collision detection and physics simulation', features: 'a Player class, enemy objects, lightweight physics, parallax scrolling' },
    model: 'gemini-3.1-pro-preview'
  }
];

interface AIStudioProps {
  user: UserProfile;
}

const AIStudio: React.FC<AIStudioProps> = ({ user }) => {
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    const saved = localStorage.getItem('aether_studio_sessions');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return [{ ...DEFAULT_SESSION, id: Date.now().toString() }];
  });
  
  const [activeSessionId, setActiveSessionId] = useState<string | null>(() => {
    return sessions[0]?.id || null;
  });

  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showSettings, setShowSettings] = useState(true);
  const [streamedResponse, setStreamedResponse] = useState('');
  const [attachments, setAttachments] = useState<{ name: string; type: 'image' | 'file'; data: string; mimeType: string }[]>([]);
  
  // Custom Safety Config
  const [safetyStates, setSafetyStates] = useState<SafetyCategory[]>([
    { id: 'harassment', name: 'Harassment', description: 'Negative/harmful comments targeting identities.', level: 'block_some' },
    { id: 'hate_speech', name: 'Hate Speech', description: 'Prejudice against protected groups.', level: 'block_some' },
    { id: 'sexually_explicit', name: 'Sexually Explicit', description: 'Adult content or suggestive prompts.', level: 'block_some' },
    { id: 'dangerous', name: 'Dangerous Content', description: 'Facilitating material harm or illegal acts.', level: 'block_some' }
  ]);

  // Application Audio State
  const [audioMode, setAudioMode] = useState<'muted' | 'browser' | 'premium'>(() => {
    return (localStorage.getItem('studio_audio_mode') as any) || 'muted';
  });
  const [voiceProfile, setVoiceProfile] = useState<'Kore' | 'Puck' | 'Fenrir' | 'Zephyr' | 'Charon'>(() => {
    return (localStorage.getItem('studio_voice_profile') as any) || 'Kore';
  });
  const [isSpeaking, setIsSpeaking] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const activeAudioRef = useRef<{ source: AudioBufferSourceNode; ctx: AudioContext } | null>(null);

  // Integration SDK code Generator Mode State
  const [showCodeModal, setShowCodeModal] = useState(false);
  const [activeSDKTab, setActiveSDKTab] = useState<'curl' | 'javascript'>('javascript');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const activeSession = sessions.find(s => s.id === activeSessionId) || sessions[0];

  // Save changes locally
  useEffect(() => {
    if (sessions.length > 0) {
      localStorage.setItem('aether_studio_sessions', JSON.stringify(sessions));
    }
  }, [sessions]);

  // Synchronize audio states with localStorage
  useEffect(() => {
    localStorage.setItem('studio_audio_mode', audioMode);
  }, [audioMode]);

  useEffect(() => {
    localStorage.setItem('studio_voice_profile', voiceProfile);
  }, [voiceProfile]);

  // Clean speaking on unmount
  useEffect(() => {
    return () => {
      stopAllSpeech();
    };
  }, []);

  const stopAllSpeech = () => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    if (activeAudioRef.current) {
      try {
        activeAudioRef.current.source.stop();
        activeAudioRef.current.ctx.close();
      } catch (e) {
        // ignore
      }
      activeAudioRef.current = null;
    }
    setIsSpeaking(null);
  };

  const handleSpeakText = async (text: string, id: string) => {
    if (isSpeaking === id) {
      stopAllSpeech();
      return;
    }

    stopAllSpeech();
    setIsSpeaking(id);

    const mode = audioMode === "muted" ? "premium" : audioMode;

    if (mode === "premium") {
      try {
        // Clear markup tags before synthesizing voice
        const cleanText = text
          .replace(/[#*`_~]/g, "")
          .replace(/\[.*?\]\(.*?\)/g, "")
          .replace(/```[\s\S]*?```/g, "[Refined block code omitted from voice readout]")
          .trim();

        const res = await fetch("/api/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: cleanText, voice: voiceProfile }),
        });

        if (!res.ok) throw new Error("Voice endpoint error");
        const data = await res.json();
        if (data.success && data.audio) {
          const binaryString = atob(data.audio);
          const len = binaryString.length;
          const bytes = new Uint8Array(len);
          const view = new DataView(bytes.buffer);
          for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }

          const numSamples = len / 2;
          const float32Data = new Float32Array(numSamples);
          for (let i = 0; i < numSamples; i++) {
            const sample = view.getInt16(i * 2, true);
            float32Data[i] = sample / 32768.0;
          }

          const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
          if (!AudioCtxClass) throw new Error("Audio player initialization failed");

          const audioCtx = new AudioCtxClass();
          const buffer = audioCtx.createBuffer(1, numSamples, 24000);
          buffer.getChannelData(0).set(float32Data);

          const source = audioCtx.createBufferSource();
          source.buffer = buffer;
          source.connect(audioCtx.destination);
          
          source.onended = () => {
            if (activeAudioRef.current?.source === source) {
              setIsSpeaking(null);
            }
          };

          source.start(0);
          activeAudioRef.current = { source, ctx: audioCtx };
        } else {
          throw new Error("No data received");
        }
      } catch (err) {
        console.warn("Premium speech synth failed, utilizing micro browser fallback...", err);
        const utterance = new SpeechSynthesisUtterance(text.replace(/[#*`_~]/g, ""));
        utterance.onend = () => setIsSpeaking(null);
        window.speechSynthesis.speak(utterance);
      }
    } else {
      const utterance = new SpeechSynthesisUtterance(text.replace(/[#*`_~]/g, ""));
      utterance.onend = () => setIsSpeaking(null);
      window.speechSynthesis.speak(utterance);
    }
  };

  const startVoiceRecording = () => {
    const SpeechRec = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRec) {
      alert("Browser voice dictation is unavailable in this environment.");
      return;
    }
    const recognition = new SpeechRec();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = "en-US";

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (e: any) => {
      const resultText = e.results[0][0].transcript;
      if (activeSession.mode === 'chat') {
        setInput(prev => prev ? prev + ' ' + resultText : resultText);
      } else {
        updateSession({ promptTemplate: activeSession.promptTemplate + ' ' + resultText });
      }
    };

    recognition.onerror = () => {
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  };

  const updateSession = (updates: Partial<ChatSession>) => {
    if (!activeSession) return;
    setSessions(prev => prev.map(s => s.id === activeSession.id ? { ...s, ...updates } : s));
  };

  // Helper: auto extract variable bindings from template text
  const extractVariables = (text: string): string[] => {
    const matches = [...text.matchAll(/\{\{([^}]+)\}\}/g)];
    return Array.from(new Set(matches.map(m => m[1].trim())));
  };

  // When prompt template updates, update variable names keeping schema
  const handleTemplateChange = (newText: string) => {
    const extracted = extractVariables(newText);
    const updatedTestCases = activeSession.testCases.map(tc => {
      const nextVars: Record<string, string> = {};
      extracted.forEach(key => {
        nextVars[key] = tc.variables[key] !== undefined ? tc.variables[key] : '';
      });
      return { ...tc, variables: nextVars };
    });

    updateSession({
      promptTemplate: newText,
      testCases: updatedTestCases
    });
  };

  const interpolateTemplate = (template: string, vars: Record<string, string>) => {
    let result = template;
    Object.entries(vars).forEach(([key, val]) => {
      const escapedKey = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const regex = new RegExp(`\\{\\{\\s*${escapedKey}\\s*\\}\\}`, 'g');
      result = result.replace(regex, val || '');
    });
    return result;
  };

  // Run structured variable interpolation test row
  const handleRunTestCase = async (tcId: string) => {
    if (isProcessing) return;
    
    const targetCaseIndex = activeSession.testCases.findIndex(c => c.id === tcId);
    if (targetCaseIndex === -1) return;

    const targetCase = activeSession.testCases[targetCaseIndex];
    const fullConstructedPrompt = interpolateTemplate(activeSession.promptTemplate, targetCase.variables);

    // Update processing state for single row
    setSessions(prev => prev.map(s => {
      if (s.id !== activeSession.id) return s;
      const tcs = [...s.testCases];
      tcs[targetCaseIndex] = { ...tcs[targetCaseIndex], isProcessing: true, output: '', error: undefined };
      return { ...s, testCases: tcs };
    }));

    const startTime = Date.now();

    try {
      const stream = generateContentStream(
        activeSession.modelId,
        fullConstructedPrompt,
        {
          temperature: activeSession.temperature,
          topK: activeSession.topK,
          topP: activeSession.topP,
          maxOutputTokens: activeSession.maxOutputTokens,
          systemInstruction: activeSession.systemInstruction
        }
      );

      let accumulated = '';
      for await (const chunk of stream) {
        accumulated += chunk;
        setSessions(prev => prev.map(s => {
          if (s.id !== activeSession.id) return s;
          const tcs = [...s.testCases];
          tcs[targetCaseIndex] = { ...tcs[targetCaseIndex], output: accumulated };
          return { ...s, testCases: tcs };
        }));
      }

      const totalTimeMs = Date.now() - startTime;
      const speedRate = Math.round(accumulated.length / (totalTimeMs / 1000 || 1));

      setSessions(prev => prev.map(s => {
        if (s.id !== activeSession.id) return s;
        const tcs = [...s.testCases];
        tcs[targetCaseIndex] = { 
          ...tcs[targetCaseIndex], 
          isProcessing: false, 
          latency: totalTimeMs,
          charSpeed: speedRate
        };
        return { ...s, testCases: tcs };
      }));

      // Application speak output if audio is on
      if (audioMode !== 'muted') {
        handleSpeakText(accumulated, tcId);
      }

    } catch (e: any) {
      console.error(e);
      setSessions(prev => prev.map(s => {
        if (s.id !== activeSession.id) return s;
        const tcs = [...s.testCases];
        tcs[targetCaseIndex] = { 
          ...tcs[targetCaseIndex], 
          isProcessing: false, 
          error: e?.message || 'Generation failed.'
        };
        return { ...s, testCases: tcs };
      }));
    }
  };

  const handleRunAllTestCases = async () => {
    if (isProcessing) return;
    setIsProcessing(true);
    try {
      const promises = activeSession.testCases.map(tc => handleRunTestCase(tc.id));
      await Promise.all(promises);
    } finally {
      setIsProcessing(false);
    }
  };

  const addNewTestCaseRow = () => {
    const extractedKeys = extractVariables(activeSession.promptTemplate);
    const initialVars: Record<string, string> = {};
    extractedKeys.forEach(k => { initialVars[k] = ''; });

    const newRow: TestCase = {
      id: 'tc-' + Date.now().toString(),
      variables: initialVars,
      output: ''
    };

    updateSession({
      testCases: [...activeSession.testCases, newRow]
    });
  };

  const deleteTestCaseRow = (tcId: string) => {
    updateSession({
      testCases: activeSession.testCases.filter(c => c.id !== tcId)
    });
  };

  const updateTestCaseValue = (tcId: string, varName: string, value: string) => {
    updateSession({
      testCases: activeSession.testCases.map(tc => {
        if (tc.id !== tcId) return tc;
        return {
          ...tc,
          variables: { ...tc.variables, [varName]: value }
        };
      })
    });
  };

  // Normal Chat Message Handling
  const handleSendChatMessage = async () => {
    if ((!input.trim() && attachments.length === 0) || isProcessing || !activeSession) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: Date.now(),
      attachments: [...attachments]
    };

    const updatedMessages = [...activeSession.messages, userMessage];
    updateSession({ messages: updatedMessages });
    setInput('');
    setAttachments([]);
    setIsProcessing(true);
    setStreamedResponse('');

    try {
      const stream = generateContentStream(
        activeSession.modelId,
        input,
        {
          temperature: activeSession.temperature,
          topK: activeSession.topK,
          topP: activeSession.topP,
          maxOutputTokens: activeSession.maxOutputTokens,
          systemInstruction: activeSession.systemInstruction
        },
        userMessage.attachments?.map(a => ({ mimeType: a.mimeType, data: a.data }))
      );

      let fullResponse = '';
      for await (const chunk of stream) {
        fullResponse += chunk;
        setStreamedResponse(fullResponse);
      }

      const modelMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: fullResponse,
        timestamp: Date.now()
      };

      updateSession({ messages: [...updatedMessages, modelMessage] });
      
      // Automatic tts readout if unmuted
      if (audioMode !== 'muted') {
        handleSpeakText(fullResponse, modelMessage.id);
      }

    } catch (e: any) {
      console.error(e);
      const errMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: `Error conducting inference: ${e.message || "Please verify your setup."}`,
        timestamp: Date.now()
      };
      updateSession({ messages: [...updatedMessages, errMessage] });
    } finally {
      setIsProcessing(false);
      setStreamedResponse('');
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (ev) => {
      const result = ev.target?.result as string;
      const base64 = result.split(',')[1];
      setAttachments(prev => [...prev, {
        name: file.name,
        type: file.type.startsWith('image/') ? 'image' : 'file',
        mimeType: file.type,
        data: base64
      }]);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const createNewSession = () => {
    const newSession = { ...DEFAULT_SESSION, id: Date.now().toString(), title: 'Untitled Studio Job' };
    setSessions(prev => [newSession, ...prev]);
    setActiveSessionId(newSession.id);
  };

  const deleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const rest = sessions.filter(s => s.id !== id);
    setSessions(rest);
    if (activeSessionId === id) {
      setActiveSessionId(rest[0]?.id || null);
    }
    if (rest.length === 0) {
      const newSession = { ...DEFAULT_SESSION, id: Date.now().toString() };
      setSessions([newSession]);
      setActiveSessionId(newSession.id);
    }
  };

  const handleLoadRecipe = (recipe: typeof PRESET_RECIPES[0]) => {
    const freshSession: ChatSession = {
      id: 'session-' + Date.now().toString(),
      title: `${recipe.title} Schema`,
      modelId: recipe.model,
      systemInstruction: recipe.system,
      temperature: 0.6,
      topK: 40,
      topP: 0.95,
      maxOutputTokens: 65536,
      mode: 'freeform',
      promptTemplate: recipe.template,
      messages: [],
      testCases: [
        {
          id: 'preset-tc-1',
          variables: recipe.vars,
          output: ''
        }
      ]
    };
    setSessions(prev => [freshSession, ...prev]);
    setActiveSessionId(freshSession.id);
  };

  // SDK Integrator Code Builders
  const getGeneratedSDKCode = () => {
    const activePrompt = activeSession.mode === 'chat' 
      ? (activeSession.messages[activeSession.messages.length - 1]?.text || 'Say Hello!') 
      : activeSession.promptTemplate;

    const systemPromptEscaped = activeSession.systemInstruction.replace(/"/g, '\\"').replace(/\n/g, '\\n');
    const promptEscaped = activePrompt.replace(/"/g, '\\"').replace(/\n/g, '\\n');

    switch (activeSDKTab) {
      case 'javascript':
        return `import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

async function runPrompt() {
  const response = await ai.models.generateContent({
    model: "${activeSession.modelId}",
    contents: "${promptEscaped}",
    config: {
      systemInstruction: "${systemPromptEscaped}",
      temperature: ${activeSession.temperature},
      topP: ${activeSession.topP},
      maxOutputTokens: ${activeSession.maxOutputTokens},
    }
  });

  console.log("Response text:", response.text);
}

runPrompt();`;

      case 'curl':
        return `curl -s "https://generativelanguage.googleapis.com/v1beta/models/${activeSession.modelId}:generateContent?key=\${GEMINI_API_KEY}" \\
  -H "Content-Type: application/json" \\
  -d '{
    "contents": [
      { "parts": [{ "text": "${promptEscaped}" }] }
    ],
    "generationConfig": {
      "temperature": ${activeSession.temperature},
      "topP": ${activeSession.topP},
      "maxOutputTokens": ${activeSession.maxOutputTokens},
      "systemInstruction": {
        "parts": [{ "text": "${systemPromptEscaped}" }]
      }
    }
  }'`;
    }
  };

  const currentExtractedVariables = extractVariables(activeSession.promptTemplate || '');

  // Estimated pricing matrices based on real fees
  const isSelectedPro = activeSession.modelId.includes('pro');
  const rateInput = isSelectedPro ? 0.0075 : 0.000075;
  const rateOutput = isSelectedPro ? 0.03 : 0.0003;
  
  const estimateCharsAndTokens = () => {
    let charCount = 0;
    if (activeSession.mode === 'chat') {
      charCount = input.length + activeSession.systemInstruction.length;
    } else {
      charCount = activeSession.promptTemplate.length + activeSession.systemInstruction.length;
    }
    const estTokens = Math.ceil(charCount * 0.25);
    const estCost = (estTokens / 1000) * rateInput;
    return { tokens: estTokens, cost: estCost };
  };

  const calculations = estimateCharsAndTokens();

  return (
    <div className="flex h-full w-full bg-neutral-950 text-white font-sans overflow-hidden border-t border-white/5 relative">
      <style>{`
        @keyframes subtleWave {
          0%, 100% { transform: scaleY(0.4); }
          50% { transform: scaleY(1.1); }
        }
        .voice-pulse-1 { animation: subtleWave 0.6s infinite ease-in-out alternate; }
        .voice-pulse-2 { animation: subtleWave 0.8s infinite ease-in-out alternate 0.15s; }
        .voice-pulse-3 { animation: subtleWave 0.5s infinite ease-in-out alternate 0.3s; }
        .voice-pulse-4 { animation: subtleWave 0.7s infinite ease-in-out alternate 0.45s; }
        .voice-pulse-5 { animation: subtleWave 0.9s infinite ease-in-out alternate 0.2s; }
      `}</style>

      {/* Prompts Side bar */}
      <div className="w-64 border-r border-white/10 bg-neutral-900/40 backdrop-blur-md flex flex-col shrink-0 flex-1 md:flex-initial hidden md:flex">
        <div className="p-4 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Layers className="text-orange-500 w-4 h-4 animate-pulse" />
            <span className="text-[10px] font-black uppercase tracking-wider text-white/50">Build Studio</span>
          </div>
          <button 
            onClick={createNewSession}
            className="p-1.5 hover:bg-white/5 border border-white/5 rounded-lg text-white/50 hover:text-white transition-all flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider"
          >
            <Plus size={12} /> Add
          </button>
        </div>

        {/* Sessions Stack */}
        <div className="flex-1 overflow-y-auto p-2.5 space-y-1.5 scrollbar-thin">
          <span className="text-[9px] font-bold text-white/30 uppercase tracking-widest px-2 block mb-1">PROMPTS RUNSTACK</span>
          {sessions.map(session => (
            <div 
              key={session.id}
              onClick={() => setActiveSessionId(session.id)}
              className={`group px-3 py-2 rounded-xl cursor-pointer flex flex-col justify-between transition-all border ${
                activeSessionId === session.id 
                  ? 'bg-gradient-to-r from-orange-600/10 to-orange-500/10 border-orange-500/30 text-white' 
                  : 'border-transparent text-white/50 hover:bg-white/[0.02] hover:text-white/80'
              }`}
            >
              <div className="flex items-center justify-between gap-1">
                <div className="flex items-center gap-2 overflow-hidden w-full">
                  {session.mode === 'chat' ? <MessageSquare size={13} className="text-orange-400 shrink-0" /> : <Table size={13} className="text-orange-500 shrink-0" />}
                  <span className="text-xs font-semibold truncate leading-none">{session.title}</span>
                </div>
                <button 
                  onClick={(e) => deleteSession(session.id, e)} 
                  className="opacity-0 group-hover:opacity-100 p-0.5 hover:text-rose-400 transition-opacity whitespace-nowrap shrink-0"
                >
                  <Trash2 size={11} />
                </button>
              </div>

              {/* Mini details label */}
              <div className="flex items-center gap-1 text-[8px] uppercase tracking-wider mt-1 text-white/20">
                <span>{session.modelId.replace('-preview', '').replace('gemini-', '')}</span>
                <span>•</span>
                <span>{session.mode}</span>
              </div>
            </div>
          ))}

          {/* Quick preset Recipes list */}
          <div className="pt-6 border-t border-white/5 mt-4">
            <span className="text-[9px] font-bold text-white/30 uppercase tracking-widest px-2 block mb-2">PROMPT CATALOG presets</span>
            <div className="space-y-1">
              {PRESET_RECIPES.map((recipe, idx) => (
                <button
                  key={idx}
                  onClick={() => handleLoadRecipe(recipe)}
                  className="w-full text-left p-2 rounded-lg bg-white/[0.01] hover:bg-white/[0.03] border border-white/5 transition-all text-white/60 hover:text-white"
                >
                  <div className="text-[10px] font-bold text-orange-400 flex items-center justify-between">
                    <span>{recipe.title}</span>
                    <Sparkles size={8} />
                  </div>
                  <div className="text-[9px] text-white/30 truncate">{recipe.description}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Diagnostic Status Box */}
        <div className="p-3 bg-white/[0.01] border-t border-white/10 flex flex-col gap-1.5">
          <div className="flex items-center justify-between text-[9px] font-bold text-white/40 uppercase">
            <span>Server Ingress</span>
            <span className="text-emerald-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Ready
            </span>
          </div>
          <div className="text-[8px] font-mono text-white/30 leading-tight">
            API endpoint: <span className="text-orange-400">@google/genai v1beta</span>
          </div>
        </div>
      </div>

      {/* Primary Workspace */}
      <div className="flex-1 flex flex-col min-w-0 bg-neutral-950 relative">
        {/* Workspace Toolbar */}
        <div className="h-14 border-b border-white/10 flex items-center justify-between px-4 bg-neutral-900/20 backdrop-blur-sm z-10 relative">
          <div className="flex items-center gap-4">
            <div className="flex flex-col hidden sm:flex">
              <span className="text-[8px] font-bold text-white/30 uppercase tracking-widest leading-none mb-1">Inference Engine</span>
              <div className="relative group">
                <select 
                  value={activeSession?.modelId}
                  onChange={(e) => updateSession({ modelId: e.target.value })}
                  className="bg-transparent text-xs font-bold text-orange-400 outline-none appearance-none pr-5 cursor-pointer leading-none"
                >
                  {AVAILABLE_MODELS.map(model => (
                    <option key={model.id} value={model.id} className="bg-neutral-950 text-white">
                      {model.name}
                    </option>
                  ))}
                </select>
                <ChevronDown size={10} className="absolute right-0 top-1/2 -translate-y-1/2 pointer-events-none text-white/40" />
              </div>
            </div>
          </div>

          {/* Mode selection tabs CENTERED */}
          <div className="absolute left-1/2 -translate-x-1/2 flex gap-1.5 p-1 bg-black/40 backdrop-blur-xl border border-white/10 rounded-xl shadow-2xl shadow-orange-500/10 hidden md:flex z-50">
            <button
              onClick={() => updateSession({ mode: 'chat' })}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-bold tracking-widest transition-all uppercase ${
                activeSession.mode === 'chat' 
                  ? 'bg-gradient-to-r from-orange-600 to-orange-500 text-white shadow-lg shadow-orange-500/25 border border-white/10' 
                  : 'text-white/40 hover:text-white/90 hover:bg-white/5 border border-transparent'
              }`}
            >
              <MessageSquare size={13} className={activeSession.mode === 'chat' ? 'text-white' : 'text-orange-400'} /> Chat
            </button>
            <button
              onClick={() => updateSession({ mode: 'freeform' })}
              className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-xs font-bold tracking-widest transition-all uppercase ${
                activeSession.mode === 'freeform' 
                  ? 'bg-gradient-to-r from-orange-600 to-orange-500 text-white shadow-lg shadow-orange-500/25 border border-white/10' 
                  : 'text-white/40 hover:text-white/90 hover:bg-white/5 border border-transparent'
              }`}
            >
              <Table size={13} className={activeSession.mode === 'freeform' ? 'text-white' : 'text-orange-500'} /> Canvas
            </button>
          </div>

          {/* Action Toolbar */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowCodeModal(true)}
              className="p-2 text-white/40 hover:text-white hover:bg-white/5 border border-transparent hover:border-white/5 rounded-xl transition-all flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider"
              title="Get SDK Code Snippet"
            >
              <Code size={15} /> <span className="hidden md:inline">Get Code</span>
            </button>

            <button
              onClick={() => setShowSettings(!showSettings)}
              className={`p-2 rounded-xl border transition-all ${
                showSettings 
                  ? 'bg-orange-600/10 border-orange-500/20 text-orange-400' 
                  : 'text-white/40 border-transparent hover:bg-white/5 hover:text-white'
              }`}
              title="Toggle Variable Configuration"
            >
              <Sliders size={15} />
            </button>

            {activeSession.mode === 'freeform' ? (
              <button
                onClick={handleRunAllTestCases}
                disabled={isProcessing || activeSession.testCases.length === 0}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-400 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl text-xs font-bold uppercase tracking-widest transition-all shadow-lg shadow-orange-900/20"
              >
                {isProcessing ? <Loader2 size={13} className="animate-spin" /> : <Play size={13} fill="currentColor" />}
                Run Pipeline
              </button>
            ) : (
              <button
                onClick={handleSendChatMessage}
                disabled={isProcessing || (!input.trim() && attachments.length === 0)}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-600 to-orange-500 hover:from-orange-500 hover:to-orange-400 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl text-xs font-bold uppercase tracking-widest transition-all shadow-lg shadow-orange-900/20"
              >
                {isProcessing ? <Loader2 size={13} className="animate-spin" /> : <Play size={13} fill="currentColor" />}
                Run Prompt
              </button>
            )}
          </div>
        </div>

        {/* Dynamic Studio Work area */}
        <div className="flex-1 flex overflow-hidden min-h-0">
          
          {/* Main workspace layout content stream */}
          <div className="flex-1 flex flex-col min-w-0 overflow-y-auto scrollbar-thin">
            
            {/* System Instructions Header config */}
            <div className="p-4 border-b border-white/5 bg-white/[0.01] flex flex-col gap-1.5 shrink-0">
              <div className="flex items-center justify-between">
                <span className="text-[9px] font-black text-white/40 uppercase tracking-widest">Global System Instruction</span>
                <span className="text-[9px] text-orange-400/50 uppercase tracking-wider font-mono">Governs model behavior schema</span>
              </div>
              <textarea
                value={activeSession.systemInstruction}
                onChange={(e) => updateSession({ systemInstruction: e.target.value })}
                placeholder="Set background instruction directive behaviors for the model..."
                className="w-full bg-neutral-900/50 border border-white/5 rounded-xl p-3 text-xs text-white/80 outline-none focus:border-orange-500/50 resize-none h-16 custom-scrollbar transition-all"
              />
            </div>

            {/* If Chat Workspace render chat stack */}
            {activeSession.mode === 'chat' ? (
              <div className="flex-1 flex flex-col min-h-0 relative">
                
                {/* Chat items scroll list */}
                <div className="flex-1 overflow-y-auto p-4 space-y-6 scroll-smooth scrollbar-thin">
                  {activeSession.messages.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center p-8 text-center max-w-md mx-auto my-auto space-y-3">
                      <div className="w-12 h-12 rounded-full bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-400 shadow-[0_0_20px_rgba(249,115,22,0.1)]">
                        <MessageSquare size={20} />
                      </div>
                      <span className="text-[10px] font-black uppercase tracking-widest text-white">Neural Chat Canvas</span>
                      <p className="text-[11px] text-white/30 leading-relaxed">
                        Experiment with system inputs, parameters, and neural models in interactive message structures. Attach assets and optimize real-time.
                      </p>
                    </div>
                  ) : (
                    activeSession.messages.map((msg) => (
                      <div key={msg.id} className={`flex flex-col gap-1.5 ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                        <div className="flex items-center gap-2 px-1">
                          <span className={`text-[8px] font-black uppercase tracking-[0.2em] ${msg.role === 'user' ? 'text-orange-400/60' : 'text-orange-500/60'}`}>
                            {msg.role === 'user' ? 'Test Input' : 'Response'}
                          </span>
                        </div>
                        
                        <div className={`max-w-[90%] border relative group rounded-2xl p-4.5 ${
                          msg.role === 'user' 
                            ? 'bg-zinc-900/60 border-white/5 text-zinc-100 shadow-xl' 
                            : 'bg-white/[0.02] border-white/5 text-white/90'
                        }`}>
                          <div className="text-[13px] whitespace-pre-wrap leading-relaxed markdown-body font-medium">
                            {msg.text}
                          </div>

                          {/* Trigger speaks & attachments */}
                          {msg.attachments && msg.attachments.length > 0 && (
                            <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t border-white/5">
                              {msg.attachments.map((att, i) => (
                                <div key={i} className="flex items-center gap-2 bg-black/40 px-2.5 py-1.5 rounded-xl border border-white/5 text-[9px] text-white/40">
                                  {att.type === 'image' ? <ImageIcon size={10} /> : <FileText size={10} />}
                                  <span className="truncate max-w-[150px]">{att.name}</span>
                                </div>
                              ))}
                            </div>
                          )}

                          {/* Speak control */}
                          <div className="absolute right-2.5 top-2.5 opacity-0 group-hover:opacity-100 transition-all">
                            <button
                              onClick={() => handleSpeakText(msg.text, msg.id)}
                              className={`p-1.5 rounded-full border transition-all ${
                                isSpeaking === msg.id 
                                  ? 'bg-orange-500/10 border-orange-500/20 text-orange-400' 
                                  : 'bg-black/60 border-white/5 text-white/20 hover:text-white hover:bg-black/80'
                              }`}
                            >
                              {isSpeaking === msg.id ? <VolumeX size={12} /> : <Volume2 size={12} />}
                            </button>
                          </div>
                        </div>
                        
                        {/* If speaking show mini graphic audio bars under the bubble */}
                        {isSpeaking === msg.id && (
                          <div className="flex items-center gap-0.5 px-3 py-1 bg-orange-500/5 rounded-full border border-orange-500/10 mt-1">
                            <span className="text-[7px] text-orange-400/80 font-bold uppercase tracking-widest mr-2">Neural Link ({voiceProfile})</span>
                            <div className="w-[1.5px] h-2 bg-orange-400 rounded-full voice-pulse-1" />
                            <div className="w-[1.5px] h-2 bg-orange-500 rounded-full voice-pulse-2" />
                            <div className="w-[1.5px] h-3 bg-orange-600 rounded-full voice-pulse-3" />
                            <div className="w-[1.5px] h-2 bg-orange-500 rounded-full voice-pulse-4" />
                            <div className="w-[1.5px] h-2 bg-orange-400 rounded-full voice-pulse-5" />
                          </div>
                        )}
                      </div>
                    ))
                  )}

                  {isProcessing && streamedResponse && (
                    <div className="flex flex-col gap-1.5 items-start">
                      <div className="flex items-center gap-1 px-1">
                        <Loader2 size={10} className="text-orange-400 animate-spin" />
                        <span className="text-[8px] font-black uppercase tracking-widest text-orange-400">Stream Inbound</span>
                      </div>
                      <div className="max-w-[90%] bg-white/[0.01] border border-white/5 rounded-2xl p-4.5 text-[13px] whitespace-pre-wrap leading-relaxed text-white/70 italic">
                        {streamedResponse}
                        <span className="inline-block w-1.5 h-4 ml-1 bg-orange-500 animate-pulse align-middle" />
                      </div>
                    </div>
                  )}

                  <div ref={messagesEndRef} />
                </div>

                {/* Input block console */}
                <div className="p-3.5 bg-neutral-950 border-t border-white/5 relative z-10">
                  <div className="relative bg-white/[0.02] border border-white/5 rounded-2xl focus-within:border-orange-500/50 focus-within:bg-white/[0.04] transition-all p-2 flex flex-col gap-2">
                    
                    {/* Tiny stats bar inside controller */}
                    <div className="flex items-center justify-between text-[8px] font-mono text-white/20 select-none">
                      <span>PROJECTED: {calculations.tokens} TOKENS ($~{calculations.cost.toFixed(6)})</span>
                      <span>{input.length} characters</span>
                    </div>

                    {attachments.length > 0 && (
                      <div className="flex gap-2 p-1 overflow-x-auto">
                        {attachments.map((att, i) => (
                          <div key={i} className="relative group shrink-0">
                            {att.type === 'image' ? (
                              <img src={`data:${att.mimeType};base64,${att.data}`} alt="User input upload preview" className="h-10 w-10 rounded-lg object-cover border border-white/10" />
                            ) : (
                              <div className="h-10 w-10 rounded-lg bg-white/5 flex items-center justify-center border border-white/10">
                                <FileText size={16} className="text-white/40" />
                              </div>
                            )}
                            <button 
                              onClick={() => setAttachments(prev => prev.filter((_, idx) => idx !== i))}
                              className="absolute -top-1 -right-1 bg-rose-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <X size={8} />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}

                    <textarea 
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          handleSendChatMessage();
                        }
                      }}
                      placeholder="Input diagnostic instruction or message prompt query here..."
                      className="w-full bg-transparent text-xs text-white px-2 py-1 outline-none resize-none min-h-[50px] max-h-[140px] overflow-y-auto placeholder:text-white/20"
                    />

                    {/* Controller Action Row */}
                    <div className="flex items-center justify-between border-t border-white/5 pt-2">
                      <div className="flex items-center gap-1">
                        <button 
                          onClick={() => fileInputRef.current?.click()} 
                          className="p-1 px-2.5 rounded-lg text-white/50 hover:text-white hover:bg-white/5 border border-white/5 text-[9px] font-bold uppercase tracking-wider transition-all flex items-center gap-1"
                          title="Attach file payload"
                        >
                          <ImageIcon size={12} /> File
                        </button>
                        <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileUpload} />

                        <button
                          onClick={startVoiceRecording}
                          className={`p-1 px-2.5 rounded-lg text-[9px] font-bold uppercase tracking-wider transition-all flex items-center gap-1 border ${
                            isListening 
                              ? 'bg-rose-600/20 border-rose-500/30 text-rose-400 glow font-black' 
                              : 'text-white/50 hover:text-white hover:bg-white/5 border-white/5'
                          }`}
                          title="Microphone voice-to-text dictation"
                        >
                          <Mic size={12} className={isListening ? 'animate-bounce' : ''} /> 
                          {isListening ? 'Recording...' : 'Dictate'}
                        </button>
                      </div>

                      <div className="flex gap-1">
                        <button
                          onClick={handleSendChatMessage}
                          disabled={isProcessing || (!input.trim() && attachments.length === 0)}
                          className="flex items-center gap-1 px-3 py-1 bg-orange-600 hover:bg-orange-500 disabled:opacity-50 text-white rounded-xl text-[10px] font-black uppercase tracking-wider transition-all"
                        >
                          <ArrowUp size={12} /> Send
                        </button>
                      </div>
                    </div>

                  </div>
                </div>

              </div>
            ) : (
              /* If Freeform variable Matrix Mode (Google AI Studio Signature) */
              <div className="p-4 space-y-6">
                
                {/* Visual canvas editor */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Prompt Engineering Canvas</span>
                    <span className="text-[8px] font-bold text-orange-400 bg-orange-500/10 px-2 py-0.5 rounded-full uppercase tracking-wider">
                      Write variable structures with double squiggly braces e.g. {"{{variable}}"}
                    </span>
                  </div>
                  <div className="relative border border-white/10 rounded-2xl bg-neutral-900/10 focus-within:border-orange-500/40 p-1 transition-all">
                    <textarea
                      value={activeSession.promptTemplate}
                      onChange={(e) => handleTemplateChange(e.target.value)}
                      placeholder="Write your pipeline framework here..."
                      className="w-full bg-transparent p-4 text-xs font-mono text-white/90 outline-none resize-none min-h-[140px] focus:outline-none custom-scrollbar"
                    />

                    {/* Quick variables tracker */}
                    <div className="px-4 pb-3 flex flex-wrap gap-1.5 border-t border-white/5 pt-2.5">
                      <span className="text-[8px] font-black text-white/20 uppercase tracking-widest flex items-center mr-1">Extracted Variables:</span>
                      {currentExtractedVariables.length === 0 ? (
                        <span className="text-[8px] font-semibold text-white/30 italic">None yet (Add variables with double braces to unlock the Test Matrix below!)</span>
                      ) : (
                        currentExtractedVariables.map(v => (
                          <span key={v} className="bg-gradient-to-r from-orange-600/20 to-amber-600/20 border border-orange-500/20 text-orange-300 font-mono text-[9px] font-bold px-2 py-0.5 rounded-lg flex items-center gap-1 shadow-sm">
                            <span className="w-1 h-1 rounded-full bg-orange-400" /> {v}
                          </span>
                        ))
                      )}
                    </div>
                  </div>
                </div>

                {/* Variable test matrix table */}
                <div className="space-y-3.5">
                  <div className="flex items-center justify-between pb-1 border-b border-white/5">
                    <div className="flex items-center gap-2">
                      <Table size={14} className="text-pink-400" />
                      <span className="text-[10px] font-black text-white/40 uppercase tracking-widest">Variable Evaluation Matrix</span>
                      <span className="bg-white/5 px-2 py-0.5 rounded text-[8px] font-mono text-white/40">{activeSession.testCases.length} rows</span>
                    </div>

                    <button
                      onClick={addNewTestCaseRow}
                      className="p-1 px-2.5 hover:bg-white/5 border border-white/10 rounded-lg text-white/50 hover:text-white transition-all flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider"
                    >
                      <PlusCircle size={12} className="text-pink-400" /> Add case row
                    </button>
                  </div>

                  {/* Table structure */}
                  <div className="border border-white/5 rounded-2xl overflow-x-auto bg-white/[0.01]">
                    <div className="min-w-[650px]">
                      
                      {/* Grid Header */}
                      <div className="grid grid-cols-[50px_2fr_3fr_60px] gap-4 bg-white/[0.02] p-3 text-[9px] font-black uppercase text-white/30 tracking-widest border-b border-white/5">
                        <div className="text-center">Run</div>
                        <div>Target Variables</div>
                        <div>Model Output Pipeline</div>
                        <div className="text-right">Action</div>
                      </div>

                      {/* Grid Rows */}
                      <div className="divide-y divide-white/5">
                        {activeSession.testCases.length === 0 ? (
                          <div className="p-8 text-center text-[11px] text-white/30 italic">No test evaluation matrix rows structured. Define variables above and add a case.</div>
                        ) : (
                          activeSession.testCases.map((tc, idx) => (
                            <div key={tc.id} className="grid grid-cols-[50px_2fr_3fr_60px] gap-4 p-3.5 items-start hover:bg-white/[0.01] transition-colors relative">
                              
                              {/* Run cell buttons */}
                              <div className="flex items-center justify-center pt-1">
                                <button
                                  onClick={() => handleRunTestCase(tc.id)}
                                  disabled={tc.isProcessing}
                                  className="p-1.5 rounded-lg bg-orange-600/10 hover:bg-orange-600 text-orange-400 hover:text-white transition-all border border-orange-500/20 disabled:opacity-40"
                                >
                                  {tc.isProcessing ? <Loader2 size={11} className="animate-spin" /> : <Play size={11} fill="currentColor" />}
                                </button>
                              </div>

                              {/* Target inputs cells */}
                              <div className="space-y-2">
                                {currentExtractedVariables.length === 0 ? (
                                  <div className="text-[10px] text-white/20 italic">No custom variables defined. Write e.g. {"{{criteria}}"} inside the prompt canvas.</div>
                                ) : (
                                  currentExtractedVariables.map(v => (
                                    <div key={v} className="space-y-1">
                                      <span className="text-[8px] font-mono font-bold text-orange-400 uppercase">{v}</span>
                                      <input
                                        type="text"
                                        placeholder={`Insert case value for variable [${v}]`}
                                        value={tc.variables[v] || ''}
                                        onChange={(e) => updateTestCaseValue(tc.id, v, e.target.value)}
                                        className="w-full bg-neutral-900 border border-white/5 rounded-lg px-2.5 py-1 text-[11px] text-white/90 focus:border-orange-500/40 outline-none"
                                      />
                                    </div>
                                  ))
                                )}
                              </div>

                              {/* Output displays cells with diagnostics */}
                              <div className="space-y-1.5 select-text">
                                <div className={`p-3 rounded-lg border text-[11px] font-sans leading-relaxed whitespace-pre-wrap max-h-56 overflow-y-auto scrollbar-none relative ${
                                  tc.error 
                                    ? 'bg-rose-950/20 border-rose-500/20 text-rose-300' 
                                    : tc.isProcessing 
                                    ? 'bg-orange-950/10 border-orange-500/10 text-orange-200'
                                    : 'bg-black/20 border-white/5 text-white/75'
                                }`}>
                                  {tc.isProcessing && !tc.output && (
                                    <span className="text-[10px] text-white/40 italic flex items-center gap-2">
                                      <Loader2 size={10} className="animate-spin text-orange-400" /> Computing model sequence...
                                    </span>
                                  )}
                                  {tc.error ? tc.error : tc.output ? tc.output : (!tc.isProcessing && 'Row evaluated output prints here after execution.')}
                                </div>

                                {/* Dynamic stats row */}
                                {(tc.latency || tc.charSpeed) && (
                                  <div className="flex items-center gap-3.5 text-[8px] font-mono text-white/30 uppercase">
                                    <span className="flex items-center gap-1"><Clock size={9} /> Latency: {tc.latency}ms</span>
                                    <span className="flex items-center gap-1"><Activity size={9} /> Generation: {tc.charSpeed} chars/s</span>
                                  </div>
                                )}
                              </div>

                              {/* Delete actions */}
                              <div className="flex items-center justify-end pt-1">
                                <button
                                  onClick={() => deleteTestCaseRow(tc.id)}
                                  className="p-1 px-2.5 rounded-lg text-white/30 hover:text-rose-400 hover:bg-rose-500/10 border border-transparent hover:border-rose-500/10 transition-all"
                                  title="Remove evaluation row"
                                >
                                  <X size={12} />
                                </button>
                              </div>

                            </div>
                          ))
                        )}
                      </div>

                    </div>
                  </div>
                </div>

              </div>
            )}
          </div>

          {/* Right Parameters panel */}
          {showSettings && (
            <div className="w-80 border-l border-white/10 bg-neutral-900/20 flex flex-col shrink-0 animate-in slide-in-from-right duration-300 overflow-y-auto scrollbar-thin">
              <div className="p-4 border-b border-white/10 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2">
                  <Sliders size={14} className="text-orange-500" />
                  <span className="text-[10px] font-black uppercase tracking-wider text-white">Execution Settings</span>
                </div>
                <button onClick={() => setShowSettings(false)} className="text-white/40 hover:text-white"><X size={15} /></button>
              </div>

              <div className="p-5 space-y-6">
                
                {/* Application Sync Audio Panel */}
                <div className="p-3.5 rounded-2xl bg-white/[0.01] border border-white/5 space-y-3.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] font-black uppercase text-white/30 tracking-widest">Application Speech Grid</span>
                    <span className="text-[8px] text-orange-400 font-bold uppercase tracking-widest pl-1 bg-orange-500/10 px-2 py-0.5 rounded-full">TTS Mode ON</span>
                  </div>

                  <div className="space-y-1">
                    <span className="text-[8px] font-bold text-white/30 uppercase tracking-widest">Character profile</span>
                    <div className="relative group">
                      <select
                        value={voiceProfile}
                        onChange={(e) => setVoiceProfile(e.target.value as any)}
                        className="w-full bg-neutral-950 border border-white/5 rounded-xl px-3 py-1.5 text-xs text-white outline-none appearance-none font-bold pr-6"
                      >
                        <option value="Kore">Kore (Cheerful & Radiant)</option>
                        <option value="Puck">Puck (Fast & Vibrant)</option>
                        <option value="Fenrir">Fenrir (Quiet Baritone)</option>
                        <option value="Zephyr">Zephyr (Professional)</option>
                        <option value="Charon">Charon (Deep Voyageur)</option>
                      </select>
                      <ChevronDown size={11} className="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none text-white/40" />
                    </div>
                  </div>

                  {/* Mode switcher */}
                  <div className="grid grid-cols-3 gap-1 bg-black p-1 border border-white/5 rounded-xl text-center">
                    {(['muted', 'browser', 'premium'] as const).map(m => (
                      <button
                        key={m}
                        onClick={() => {
                          setAudioMode(m);
                          if (m === 'muted') stopAllSpeech();
                        }}
                        className={`py-1 rounded-lg text-[9px] font-bold uppercase tracking-wider transition-all ${
                          audioMode === m 
                            ? 'bg-orange-600 text-white shadow' 
                            : 'text-white/40 hover:text-white hover:bg-white/[0.02]'
                        }`}
                      >
                        {m === 'muted' ? 'Mute' : m === 'browser' ? 'Browser' : 'Neural'}
                      </button>
                    ))}
                  </div>

                  {/* Demo reading button */}
                  <button
                    onClick={() => handleSpeakText("Welcome to the Gemini Build Studio workspace prompt engine! Fully synthesized speech feedback active.", "test-reading")}
                    className="w-full py-1.5 bg-white/5 hover:bg-white/10 text-white rounded-lg text-[9px] font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1"
                  >
                    {isSpeaking === "test-reading" ? "Interrup Voice Readout" : "Sample Voice Engine"}
                  </button>
                </div>

                {/* SLiders */}
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <label className="text-[9px] font-bold text-white/40 uppercase">Temperature</label>
                    <span className="text-xs font-mono text-orange-400 font-bold">{activeSession?.temperature}</span>
                  </div>
                  <input 
                    type="range" min="0" max="2" step="0.1" 
                    value={activeSession?.temperature}
                    onChange={(e) => updateSession({ temperature: parseFloat(e.target.value) })}
                    className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:bg-orange-500 [&::-webkit-slider-thumb]:rounded-full"
                  />
                  <p className="text-[9px] text-white/30 leading-snug">Controls randomness. Low temperatures produce strict and direct answers, high values foster creativity.</p>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between">
                    <label className="text-[9px] font-bold text-white/40 uppercase">Max Output Tokens</label>
                    <span className="text-xs font-mono text-orange-400 font-bold">{activeSession?.maxOutputTokens}</span>
                  </div>
                  <input 
                    type="range" min="1024" max="131072" step="1024" 
                    value={activeSession?.maxOutputTokens}
                    onChange={(e) => updateSession({ maxOutputTokens: parseInt(e.target.value) })}
                    className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:bg-orange-500 [&::-webkit-slider-thumb]:rounded-full"
                  />
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between">
                    <label className="text-[9px] font-bold text-white/40 uppercase">Top K</label>
                    <span className="text-xs font-mono text-orange-400 font-bold">{activeSession?.topK}</span>
                  </div>
                  <input 
                    type="range" min="1" max="100" step="1" 
                    value={activeSession?.topK}
                    onChange={(e) => updateSession({ topK: parseInt(e.target.value) })}
                    className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:bg-orange-500 [&::-webkit-slider-thumb]:rounded-full"
                  />
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between">
                    <label className="text-[9px] font-bold text-white/40 uppercase">Top P</label>
                    <span className="text-xs font-mono text-orange-400 font-bold">{activeSession?.topP}</span>
                  </div>
                  <input 
                    type="range" min="0" max="1" step="0.01" 
                    value={activeSession?.topP}
                    onChange={(e) => updateSession({ topP: parseFloat(e.target.value) })}
                    className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:bg-orange-500 [&::-webkit-slider-thumb]:rounded-full"
                  />
                </div>

                {/* Safety block sliders (Extra features) */}
                <div className="pt-4 border-t border-white/5 space-y-4 mt-6">
                  <div className="flex items-center gap-2">
                    <ShieldAlert size={13} className="text-rose-400" />
                    <span className="text-[9px] font-black uppercase text-white/30 tracking-widest">Safety Shield Sliders</span>
                  </div>

                  <div className="space-y-3">
                    {safetyStates.map(category => (
                      <div key={category.id} className="space-y-1 bg-white/[0.01] border border-white/5 p-2 rounded-lg">
                        <div className="flex items-center justify-between">
                          <span className="text-[9px] font-bold text-white/60">{category.name}</span>
                          <span className="text-[8px] font-bold uppercase tracking-wider text-orange-400">
                            {category.level.split('_')[1]}
                          </span>
                        </div>
                        <div className="grid grid-cols-4 gap-1 pt-1 text-center">
                          {(['block_none', 'block_few', 'block_some', 'block_most'] as const).map(lvl => (
                            <button
                              key={lvl}
                              onClick={() => {
                                setSafetyStates(prev => prev.map(s => s.id === category.id ? { ...s, level: lvl } : s));
                              }}
                              className={`py-0.5 rounded text-[8px] tracking-tight font-bold transition-all uppercase ${
                                category.level === lvl 
                                  ? lvl === 'block_most' 
                                    ? 'bg-rose-600 text-white'
                                    : lvl === 'block_some'
                                    ? 'bg-amber-600 text-white'
                                    : 'bg-orange-600 text-white'
                                  : 'bg-white/5 text-white/30 hover:bg-white/10 hover:text-white/60'
                              }`}
                            >
                              {lvl.split('_')[1]}
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Cost indexing information matrix */}
                <div className="border-t border-white/5 pt-4 space-y-3">
                  <div className="flex items-center gap-1.5">
                    <Coins size={13} className="text-yellow-400" />
                    <span className="text-[9px] font-black uppercase text-white/30 tracking-widest">Rate and Budget Matrix</span>
                  </div>
                  <div className="bg-black/40 border border-white/5 p-3 rounded-xl space-y-1.5 text-[10px] font-mono leading-relaxed">
                    <div className="flex justify-between text-white/40">
                      <span>Input cost (Pro):</span>
                      <span className="text-white">$0.0075 / 1k tok</span>
                    </div>
                    <div className="flex justify-between text-white/40">
                      <span>Input cost (Flash):</span>
                      <span className="text-white">$0.000075 / 1k tok</span>
                    </div>
                    <div className="h-[1px] bg-white/5 my-1" />
                    <span className="text-[8px] text-white/20 uppercase tracking-wide block">Pricing scales logically on computational model tiers.</span>
                  </div>
                </div>

              </div>
            </div>
          )}

        </div>
      </div>

      {/* Integration Code modal */}
      <AnimatePresence>
        {showCodeModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-[200] flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-neutral-950 border border-white/15 w-full max-w-3xl rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]"
            >
              <div className="p-4 border-b border-white/10 flex items-center justify-between bg-white/[0.01]">
                <div className="flex items-center gap-2">
                  <FileCode className="text-orange-400 w-4.5 h-4.5 animate-bounce" />
                  <span className="text-xs font-black uppercase tracking-widest text-white">Dynamic Integration Studio - Get Code</span>
                </div>
                <button
                  onClick={() => setShowCodeModal(false)}
                  className="p-1 text-white/40 hover:text-white hover:bg-white/5 rounded-lg transition-colors"
                >
                  <X size={16} />
                </button>
              </div>

              {/* Code Modal Tabs tab-layout bar */}
              <div className="flex items-center justify-between p-3 border-b border-white/5 bg-neutral-900/10">
                <div className="flex gap-1.5">
                  {(['javascript', 'curl'] as const).map(sdk => (
                    <button
                      key={sdk}
                      onClick={() => setActiveSDKTab(sdk)}
                      className={`px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all ${
                        activeSDKTab === sdk 
                          ? 'bg-orange-600/15 border border-orange-500/30 text-orange-400' 
                          : 'text-white/40 border border-transparent hover:text-white hover:bg-white/5'
                      }`}
                    >
                      {sdk === 'javascript' ? 'JavaScript SDK' : 'cURL' }
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => {
                    navigator.clipboard.writeText(getGeneratedSDKCode());
                  }}
                  className="p-1 px-3 bg-white/5 hover:bg-white/10 border border-white/5 text-white text-[9px] font-bold uppercase tracking-wider rounded-lg transition-all flex items-center gap-1"
                >
                  <Copy size={11} /> Copy Code
                </button>
              </div>

              {/* Code display workspace */}
              <div className="flex-1 overflow-y-auto p-4 bg-black font-mono text-xs leading-relaxed text-orange-200 scrollbar-none antialiased">
                <pre className="p-4 rounded-xl bg-white/[0.01] border border-white/5 overflow-x-auto whitespace-pre">
                  {getGeneratedSDKCode()}
                </pre>
              </div>

              {/* Instructions footer */}
              <div className="p-3 bg-white/[0.01] border-t border-white/15 flex items-center justify-between text-[11px] text-white/40">
                <span className="flex items-center gap-1.5"><CheckCircle size={12} className="text-emerald-400" /> Compatible with modern @google/genai libraries</span>
                <span>Configured dynamically matching studio parameters</span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
};

export default AIStudio;
