import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  Search, 
  Trash2, 
  ArrowLeft, 
  MessageSquare, 
  Clock, 
  ChevronRight, 
  Plus, 
  AlertTriangle 
} from 'lucide-react';
import { ChatSession } from '../../types';

interface ChatsPageProps {
  sessions: ChatSession[];
  onSelectSession: (id: string) => void;
  onDeleteSession: (id: string) => void;
  onClearAllSessions: () => void;
  onBack: () => void;
  onNewChat: () => void;
}

const ChatsPage: React.FC<ChatsPageProps> = ({
  sessions,
  onSelectSession,
  onDeleteSession,
  onClearAllSessions,
  onBack,
  onNewChat
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const filteredSessions = sessions.filter(session => 
    session.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    session.messages.some(m => m.text.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="flex flex-col h-full bg-[#050505] text-white">
      {/* Header */}
      <header className="flex items-center justify-between p-6 border-b border-white/5 bg-black/40 backdrop-blur-md sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <motion.button
            whileHover={{ scale: 1.05, backgroundColor: "rgba(255,255,255,0.1)" }}
            whileTap={{ scale: 0.95 }}
            onClick={onBack}
            className="p-2 rounded-full text-zinc-400 hover:text-white transition-colors"
          >
            <ArrowLeft size={20} />
          </motion.button>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Recent Chats</h1>
            <p className="text-zinc-500 text-sm">{sessions.length} total sessions</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setShowClearConfirm(true)}
            className="px-4 py-2 text-sm font-medium text-red-400 hover:text-red-300 bg-red-500/10 hover:bg-red-500/20 rounded-lg transition-colors border border-red-500/20"
          >
            Clear All
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onNewChat}
            className="flex items-center gap-2 px-4 py-2 bg-orange-600 hover:bg-orange-500 text-white text-sm font-semibold rounded-lg transition-colors shadow-lg shadow-orange-900/20"
          >
            <Plus size={16} />
            New Chat
          </motion.button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-6 lg:p-10">
        <div className="max-w-4xl mx-auto space-y-8">
          
          {/* Search */}
          <div className="relative group">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-zinc-500 group-focus-within:text-orange-500 transition-colors">
              <Search size={18} />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search conversations, ideas, code..."
              className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-11 pr-4 text-white placeholder-zinc-500 focus:outline-none focus:border-orange-500/50 focus:ring-1 focus:ring-orange-500/50 transition-all"
            />
          </div>

          {/* Session List */}
          {filteredSessions.length > 0 ? (
            <div className="space-y-3">
              {filteredSessions.map((session, i) => (
                <motion.div
                  key={session.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="group flex items-center justify-between p-4 bg-white/[0.02] border border-white/5 hover:border-white/20 rounded-xl transition-all cursor-pointer hover:bg-white/[0.04]"
                  onClick={() => onSelectSession(session.id)}
                >
                  <div className="flex items-center gap-4 min-w-0">
                    <div className="h-10 w-10 rounded-full bg-white/5 flex items-center justify-center text-orange-400 group-hover:bg-orange-500/10 group-hover:scale-110 transition-all shrink-0">
                      <MessageSquare size={18} />
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-semibold text-zinc-200 group-hover:text-white truncate transition-colors">
                        {session.title || "Untitled Session"}
                      </h3>
                      <div className="flex items-center gap-2 text-xs text-zinc-500 mt-1">
                        <Clock size={12} />
                        <span>
                          {new Date(session.lastUpdated).toLocaleDateString(undefined, {
                            month: 'short',
                            day: 'numeric',
                            hour: 'numeric',
                            minute: '2-digit'
                          })}
                        </span>
                        <span className="w-1 h-1 rounded-full bg-zinc-700"></span>
                        <span>{session.messages.length} messages</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteSession(session.id);
                      }}
                      className="p-2 text-zinc-500 hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-colors"
                      title="Delete Chat"
                    >
                      <Trash2 size={16} />
                    </button>
                    <div className="p-2 text-zinc-500 group-hover:text-white transition-colors">
                      <ChevronRight size={18} />
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-20 text-zinc-500">
              <div className="h-16 w-16 bg-white/5 rounded-full flex items-center justify-center mb-4">
                <MessageSquare size={24} className="text-zinc-600" />
              </div>
              <h3 className="text-lg font-medium text-zinc-300 mb-2">No chats found</h3>
              <p className="text-center max-w-sm">
                {searchQuery 
                  ? "We couldn't find any chats matching your search query. Try different keywords." 
                  : "You haven't started any conversations yet."}
              </p>
              {!searchQuery && (
                <button
                  onClick={onNewChat}
                  className="mt-6 px-6 py-2 bg-white/10 hover:bg-white/20 text-white rounded-lg transition-colors font-medium text-sm"
                >
                  Start your first chat
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Clear Confirmation Modal */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-[#111] border border-white/10 rounded-2xl p-6 max-w-sm w-full shadow-2xl"
          >
            <div className="flex items-center gap-3 text-red-400 mb-4">
              <AlertTriangle size={24} />
              <h2 className="text-lg font-bold">Clear All History?</h2>
            </div>
            <p className="text-zinc-400 text-sm mb-6">
              This will permanently delete all your chat history and files. This action cannot be undone. Are you sure you want to proceed?
            </p>
            <div className="flex justify-end gap-3">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="px-4 py-2 text-sm font-medium text-zinc-300 hover:text-white bg-white/5 hover:bg-white/10 rounded-lg transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onClearAllSessions();
                  setShowClearConfirm(false);
                }}
                className="px-4 py-2 text-sm font-medium text-white bg-red-600 hover:bg-red-500 rounded-lg transition-colors shadow-lg shadow-red-900/20"
              >
                Yes, delete everything
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};
export default ChatsPage;
