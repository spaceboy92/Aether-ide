import React, { useEffect, useRef, useState, useMemo } from "react";
import * as THREE from "three";
import { MapDesigner } from "./MapDesigner";
import { runGameEngineOrchestrator, GameProjectState, MapData, EnvironmentStyle } from "../../services/gameEngineAI";
import {
  Box,
  Play,
  Square,
  Plus,
  Trash2,
  Move,
  RotateCw,
  Maximize,
  Eye,
  Layers,
  Sparkles,
  Code,
  Download,
  Settings,
  Cpu,
  Tv,
  Gamepad2,
  RefreshCw,
  Zap,
  Palette,
  Check,
  FolderPlus,
  Wand2,
  Loader2,
  Gauge,
  Volume2,
  Compass,
  Car,
  Rocket,
  Shield,
  Activity,
  FileCode,
  Sliders,
  Save,
  Copy,
  TreePine,
  Building2,
  Sun,
  Castle,
  Snowflake,
  Skull,
  Mountain,
  ChevronDown,
  ChevronRight,
  Coins,
  AlertOctagon,
  Timer,
  Flame,
  Bot,
  Sword,
  Crosshair,
  FilePlus,
  Folder,
  File,
  Search,
  Focus,
  Camera,
  Video,
  Orbit,
  ArrowUpRight,
  Link,
  Unlink,
  Layers2,
  Terminal,
  Grid,
  Maximize2,
  Boxes,
  CircleDot,
  X,
  Lock,
  Unlock,
  Upload,
  Share2,
  Pause,
  Globe,
  SlidersHorizontal,
  Binary,
  Database,
  Network,
  SunMedium,
  Sparkle,
  Image as ImageIcon
} from "lucide-react";
import { FileNode } from "../../types";
const PreviewPane = React.lazy(() => import("../Preview/PreviewPane"));
import { chatWithAI } from "../../services/geminiService";
import { getAvailableModels } from "../../services/aiService";
import { CURATED_PUBLIC_ASSETS, Public3DAsset, searchPublicAssets, generateAssetImportThreeCode } from "../../services/publicAssetService";
import { PRESET_GLSL_SHADERS, CustomGLSLShader, generateProceduralMeshBuffers, playProceduralSFX } from "../../services/lowLevelGraphicsEngine";
import { SWARM_CLUSTERS, generate1000SubAgentSwarm, computeSwarmTelemetry, SubAgentNode } from "../../services/swarm1000Agents";
import {
  PBR_MATERIAL_PRESETS,
  createUltraPBRMaterial,
  loadCustomPBRTexture,
  PBRMaterialPreset
} from "../../services/pbrTextureLoaderEngine";
import {
  createVolumetricLightShaftMesh,
  createVolumetricDustMotes,
  updateVolumetricDustMotes,
  createAtmosphericSkyDome,
  configureUltraRealisticRenderer,
  DEFAULT_VOLUMETRIC_CONFIG,
  VolumetricConfig
} from "../../services/volumetricRenderingEngine";
import {
  createAuthenticCarMesh,
  createAuthenticRobotMesh,
  createAuthenticTankMesh,
  createAuthenticStarfighterMesh,
  generateHighPolyErosionTerrain,
  generateCalabiYauManifold,
  generateSuperToroidManifold,
  generateKleinBottleManifold,
  generateHighPolyCyberTitanGeometry
} from "../../services/proceduralMeshEngine";
import {
  playProceduralLaser,
  playProceduralExplosion,
  playProceduralWarp,
  startProceduralSynthwaveBGM
} from "../../services/proceduralAudioEngine";
import {
  ModularPart,
  PartBehavior,
  ModularAssembly,
  MODULAR_ASSEMBLY_PRESETS,
  buildThreeModularHierarchy,
  updateModularPartBehaviors,
  exportModularAssemblyToCode
} from "../../services/partsJointsEngine";
import { transpileGameCodeToThreeJS, UploadedGameAsset } from "../../services/codeTranspilerService";
import {
  calculateGerstnerWaterHeight,
  createDynamicWaterMesh,
  WaterParticleSystem,
  createAuthenticSpeedboatMesh,
  playProceduralWaterSplash,
  startProceduralOceanAmbience,
  DEFAULT_WATER_PARAMS,
  WATER_THEME_PRESETS
} from "../../services/waterSimulationEngine";
import { generate3DMesh } from "../../services/modelingService";

export type ModelArchetype = "car" | "robot" | "tank" | "starfighter" | "terrain" | "character" | "speedboat" | "calabi_yau" | "supertoroid" | "klein_bottle" | "cyber_titan";
export type CameraMode = "chase" | "cockpit" | "orbit" | "flyby" | "top";
export type NeuralFluxMode = "cyber_pulse" | "quantum_drift" | "neural_wireframe" | "matrix_shift";
export type AIAgentRole = "unified_genesis" | "modeler" | "architect" | "ui_master" | "audio_sfx" | string;

interface Studio3DGameEngineProps {
  files?: FileNode[];
  setFiles?: React.Dispatch<React.SetStateAction<FileNode[]>>;
  activeSessionId?: string | null;
  onLog?: (type: "info" | "warn" | "error" | "system" | "success", msg: string, source?: string) => void;
  terminalLogs?: any[];
  initialPrompt?: string;
  onClearInitialPrompt?: () => void;
  onSaveToWorkspace?: (filename: string, content: string) => void;
}

export const Studio3DGameEngine: React.FC<Studio3DGameEngineProps> = ({
  files = [],
  setFiles,
  activeSessionId,
  onLog,
  terminalLogs,
  initialPrompt,
  onClearInitialPrompt,
  onSaveToWorkspace
}) => {
  const mountRef = useRef<HTMLDivElement>(null);

  // Unified Runtime & Viewport Mode State
  const [engineViewMode, setEngineViewMode] = useState<"real_game" | "engine_studio" | "split_dual">("real_game");
  const [iframeKey, setIframeKey] = useState(1);
  const [iframeError, setIframeError] = useState<string | null>(null);

  // Dedicated Game Chat State
  const [gameChatMessages, setGameChatMessages] = useState<Array<{
    id: string;
    sender: 'user' | 'ai';
    role?: AIAgentRole;
    text: string;
    timestamp: number;
    fileUpdated?: string;
  }>>([
    {
      id: 'init-game-chat',
      sender: 'ai',
      role: 'unified_genesis',
      text: 'Aether 3D Game Director online. Enter a game prompt or select a role to synthesize complete 3D games with WASD controls, WebGL shaders, particle physics, and Web Audio.',
      timestamp: Date.now()
    }
  ]);

  // Unified Runtime & Scene State (Default to Instant Playtest Mode)
  const [isPlaying, setIsPlaying] = useState(true);
  const [activeModelArchetype, setActiveModelArchetype] = useState<ModelArchetype>("car");
  const [cameraView, setCameraView] = useState<CameraMode>("chase");
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [fps, setFps] = useState(60);
  const [speedKmh, setSpeedKmh] = useState(0);
  const [nitroFuel, setNitroFuel] = useState(100);
  const [lapTime, setLapTime] = useState(0);
  const [exportedToast, setExportedToast] = useState<string | null>(null);

  // NEURAL FLUXING ENGINE STATE
  const [neuralFluxActive, setNeuralFluxActive] = useState(true);
  const [neuralFluxRate, setNeuralFluxRate] = useState(1.0);
  const [neuralFluxMode, setNeuralFluxMode] = useState<NeuralFluxMode>("cyber_pulse");
  const [neuralFluxIntensity, setNeuralFluxIntensity] = useState(0.75);
  const [showNeuralFluxPopover, setShowNeuralFluxPopover] = useState(false);
  const [pointerLocked, setPointerLocked] = useState(false);

  // Minimalist Viewport Controls & Drawers
  const [showFileExplorer, setShowFileExplorer] = useState(false);
  const [showAIAgentDrawer, setShowAIAgentDrawer] = useState(false);
  const [showHierarchyOutliner, setShowHierarchyOutliner] = useState(false);
  const [showCodeEditor, setShowCodeEditor] = useState(false);
  const [showMaterialTweaker, setShowMaterialTweaker] = useState(false);
  const [showVirtualTouchControls, setShowVirtualTouchControls] = useState(true);

  // Advanced Studio Feature Drawers & Modals
  const [show3DInspector, setShow3DInspector] = useState(false);
  const [showMapDesigner, setShowMapDesigner] = useState(false);
  const [currentMapData, setCurrentMapData] = useState<MapData | undefined>();
  const [showExportModal, setShowExportModal] = useState(false);
  const [exportFormat, setExportFormat] = useState<"html" | "r3f" | "json">("html");

  // Custom Uploaded Assets & Transpiler Engine State
  const [uploadedAssets, setUploadedAssets] = useState<UploadedGameAsset[]>([]);
  const [isTranspilingAsset, setIsTranspilingAsset] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // 1,000 SUB-AGENT SWARM SYSTEM STATE
  const [show1000SwarmDashboard, setShow1000SwarmDashboard] = useState(false);
  const [swarmNodes] = useState<SubAgentNode[]>(() => generate1000SubAgentSwarm());
  const swarmTelemetry = useMemo(() => computeSwarmTelemetry(swarmNodes), [swarmNodes]);
  const [selectedSwarmClusterId, setSelectedSwarmClusterId] = useState<number>(0);

  // REAL-TIME GRAPHICS ADJUSTER SYSTEM STATE
  const [showGraphicsSettings, setShowGraphicsSettings] = useState(false);
  const [graphicsSettings, setGraphicsSettings] = useState({
    renderScale: 1.0,
    shadowResolution: 2048,
    antiAliasing: "FXAA" as "None" | "FXAA" | "SMAA" | "MSAA",
    fpsTarget: 60 as 30 | 60 | 120 | 144 | 0,
    bloomStrength: 0.8,
    particleLimit: 5000,
    drawDistance: 800,
    ambientOcclusion: true,
    volumetricFog: true,
    postProcessing: true,
    textureFiltering: "High (16x)"
  });

  // PUBLIC INTERNET ASSETS MARKETPLACE & IMPORTER STATE
  const [showPublicAssetImporter, setShowPublicAssetImporter] = useState(false);
  const [assetSearchQuery, setAssetSearchQuery] = useState("");
  const [selectedAssetCategory, setSelectedAssetCategory] = useState("all");
  const [isFetchingInternetAsset, setIsFetchingInternetAsset] = useState(false);

  // LOW-LEVEL GLSL SHADER & TYPEDARRAY STUDIO STATE
  const [showLowLevelShaderStudio, setShowLowLevelShaderStudio] = useState(false);
  const [activeShaderPresetKey, setActiveShaderPresetKey] = useState<string>("pbrTerrain");
  const [customGLSL, setCustomGLSL] = useState<CustomGLSLShader>(PRESET_GLSL_SHADERS.pbrTerrain);

  // INBUILT BLENDER 3D MODELER STUDIO STATE
  const [showBlenderModeler, setShowBlenderModeler] = useState(false);
  const [blenderVertices, setBlenderVertices] = useState<number[]>([
    -1.0, -1.0, -1.0,  // 0: bottom-back-left
     1.0, -1.0, -1.0,  // 1: bottom-back-right
     1.0,  1.0, -1.0,  // 2: top-back-right
    -1.0,  1.0, -1.0,  // 3: top-back-left
    -1.0, -1.0,  1.0,  // 4: bottom-front-left
     1.0, -1.0,  1.0,  // 5: bottom-front-right
     1.0,  1.0,  1.0,  // 6: top-front-right
    -1.0,  1.0,  1.0   // 7: top-front-left
  ]);
  const [blenderIndices, setBlenderIndices] = useState<number[]>([
    0, 2, 1,  0, 3, 2, // Back Face
    4, 5, 6,  4, 6, 7, // Front Face
    0, 1, 5,  0, 5, 4, // Bottom Face
    2, 3, 7,  2, 7, 6, // Top Face
    0, 4, 7,  0, 7, 3, // Left Face
    1, 2, 6,  1, 6, 5  // Right Face
  ]);
  const [blenderModelName, setBlenderModelName] = useState("Blender Cube");
  const [blenderModelColor, setBlenderModelColor] = useState("#E87D34"); // Classic Blender Orange!
  const [blenderEditMode, setBlenderEditMode] = useState<'object' | 'vertex'>('vertex');
  const [selectedVertexIndex, setSelectedVertexIndex] = useState<number | null>(0);
  const [blenderPrompt, setBlenderPrompt] = useState("");
  const [blenderIsGenerating, setBlenderIsGenerating] = useState(false);
  const [blenderStatus, setBlenderStatus] = useState("");

  // VOLUMETRIC LIGHTING & ULTRA-REALISTIC GRAPHICS STATE
  const [showVolumetricStudio, setShowVolumetricStudio] = useState(false);
  const [volumetricConfig, setVolumetricConfig] = useState<VolumetricConfig>(DEFAULT_VOLUMETRIC_CONFIG);

  // ULTRA-REALISTIC PBR TEXTURE LOADER & SYNTHESIS STATE
  const [showPBRTextureStudio, setShowPBRTextureStudio] = useState(false);
  const [selectedPBRMaterialKey, setSelectedPBRMaterialKey] = useState<string>("carbon_fiber_twill");
  const [customPBRTextureURL, setCustomPBRTextureURL] = useState<string>("");
  const [customPBRTextureType, setCustomPBRTextureType] = useState<"albedo" | "normal" | "roughness" | "metalness" | "emissive">("albedo");
  const [pbrTiling, setPbrTiling] = useState<[number, number]>([6, 6]);
  const [pbrNormalScale, setPbrNormalScale] = useState<number>(1.8);
  const [pbrRoughness, setPbrRoughness] = useState<number>(0.2);
  const [pbrMetalness, setPbrMetalness] = useState<number>(0.9);
  const [pbrClearcoat, setPbrClearcoat] = useState<number>(1.0);
  const [pbrTextureStatus, setPbrTextureStatus] = useState<string>("");

  // Environment & Atmosphere Presets
  const [environmentPreset, setEnvironmentPreset] = useState<EnvironmentStyle>("realistic_forest");
  const [particleType] = useState<"sparks" | "stars" | "snow" | "dust" | "none">("sparks");

  // 3D Scene Inspector Objects State
  const [sceneObjects, setSceneObjects] = useState<Array<{
    id: string;
    name: string;
    type: 'mesh' | 'light' | 'particle';
    primitive?: 'cube' | 'sphere' | 'torus' | 'vehicle' | 'turret' | 'crystal' | 'tree' | 'custom' | 'blender_mesh';
    position: [number, number, number];
    rotation: [number, number, number];
    scale: [number, number, number];
    color: string;
    wireframe: boolean;
    vertices?: number[];
    indices?: number[];
  }>>([
    { id: 'player_vehicle', name: 'Player Vehicle', type: 'mesh', primitive: 'vehicle', position: [0, 0, 0], rotation: [0, 0, 0], scale: [1, 1, 1], color: '#f97316', wireframe: false },
    { id: 'ground_grid', name: 'Cyber Grid Floor', type: 'mesh', position: [0, -0.5, 0], rotation: [0, 0, 0], scale: [100, 1, 100], color: '#00ffff', wireframe: true },
    { id: 'sun_light', name: 'Primary Sun Light', type: 'light', position: [10, 20, 10], rotation: [0, 0, 0], scale: [1, 1, 1], color: '#ffffff', wireframe: false },
    { id: 'particle_field', name: 'Spark Particles', type: 'particle', position: [0, 5, 0], rotation: [0, 0, 0], scale: [1, 1, 1], color: '#f59e0b', wireframe: false }
  ]);
  const [selectedObjectId, setSelectedObjectId] = useState<string>('player_vehicle');

  const updateSelectedObject = (updates: Partial<typeof sceneObjects[0]>) => {
    setSceneObjects(prev => prev.map(obj => {
      if (obj.id === selectedObjectId) {
        return { ...obj, ...updates } as any;
      }
      return obj;
    }));
  };

  // In-Engine File Manager State
  const [fileSearchQuery, setFileSearchQuery] = useState("");
  const [showNewFileModal, setShowNewFileModal] = useState(false);
  const [newFileName, setNewFileName] = useState("game_scene.html");

  // Single Unified AI Agent State
  const [orchestratorTasks, setOrchestratorTasks] = useState<any[]>([]);
  const [orchestratorProgressLog, setOrchestratorProgressLog] = useState<string>("");
  const [aiRole, setAiRole] = useState<AIAgentRole>("unified_genesis");
  const [aiPrompt, setAiPrompt] = useState("");
  const [selectedModelId, setSelectedModelId] = useState<string>("gemini-3.1-pro-preview");
  const availableModels = useMemo(() => getAvailableModels(), []);
  const [isAISynthesizing, setIsAISynthesizing] = useState(false);
  const [bottomDirectorPrompt, setBottomDirectorPrompt] = useState("");

  // Handle incoming initial prompt from general chat redirect
  useEffect(() => {
    if (initialPrompt && initialPrompt.trim()) {
      let cleanedPrompt = initialPrompt;
      let targetRole: AIAgentRole = "unified_genesis";
      
      if (initialPrompt.startsWith("[MODELER AGENT]: ")) {
        targetRole = "modeler";
        cleanedPrompt = initialPrompt.replace("[MODELER AGENT]: ", "");
      } else if (initialPrompt.startsWith("[ARCHITECT AGENT]: ")) {
        targetRole = "architect";
        cleanedPrompt = initialPrompt.replace("[ARCHITECT AGENT]: ", "");
      } else if (initialPrompt.startsWith("[UI_MASTER AGENT]: ")) {
        targetRole = "ui_master";
        cleanedPrompt = initialPrompt.replace("[UI_MASTER AGENT]: ", "");
      } else if (initialPrompt.startsWith("[AUDIO_SFX AGENT]: ")) {
        targetRole = "audio_sfx";
        cleanedPrompt = initialPrompt.replace("[AUDIO_SFX AGENT]: ", "");
      }

      setAiPrompt(cleanedPrompt);
      setShowAIAgentDrawer(true);
      setAiRole(targetRole);
      
      if (onLog) {
        onLog("info", `Autonomous Game Director received prompt for [${targetRole.toUpperCase()}] role: "${cleanedPrompt.slice(0, 45)}..."`, "3D_ENGINE");
      }
      if (onClearInitialPrompt) {
        onClearInitialPrompt();
      }
    }
  }, [initialPrompt, onLog, onClearInitialPrompt]);

  // Camera Settings & Orbit Controls
  const [fov, setFov] = useState(65);
  const [cameraDistance, setCameraDistance] = useState(11);
  const [orbitAngle, setOrbitAngle] = useState({ x: 0.25, y: 0.6 });
  const isDraggingRef = useRef(false);
  const prevMousePosRef = useRef({ x: 0, y: 0 });

  // Hierarchy & Modular Parts State
  const [currentAssembly, setCurrentAssembly] = useState<ModularAssembly>(MODULAR_ASSEMBLY_PRESETS[0]);
  const [selectedPartId, setSelectedPartId] = useState<string | null>(MODULAR_ASSEMBLY_PRESETS[0].parts[0]?.id || null);

  // Target workspace file
  const candidateFiles = useMemo(() => {
    return files.filter(f => f.name.endsWith(".html") || f.name.endsWith(".js") || f.name.endsWith(".ts") || f.name.endsWith(".json"));
  }, [files]);

  const [targetFileName, setTargetFileName] = useState<string>(() => {
    const existing = files.find(f => f.name === "game.html" || f.name === "3d_game.html" || f.name === "index.html");
    return existing ? existing.name : "game.html";
  });

  const activeTargetFile = useMemo(() => {
    return files.find(f => f.name === targetFileName);
  }, [files, targetFileName]);

  const [editorCode, setEditorCode] = useState("");

  // Categorized File Manager for 3D Game Studio
  const gameFilesCategorized = useMemo(() => {
    const scenes = files.filter(f => f.name.endsWith('.html'));
    const scripts = files.filter(f => f.name.endsWith('.js') || f.name.endsWith('.ts'));
    const assets = files.filter(f => f.name.endsWith('.json') || f.name.endsWith('.gltf') || f.name.endsWith('.glb') || f.name.endsWith('.obj'));
    const shaders = files.filter(f => f.name.endsWith('.glsl') || f.name.endsWith('.css'));
    const other = files.filter(f => !scenes.includes(f) && !scripts.includes(f) && !assets.includes(f) && !shaders.includes(f));
    return { scenes, scripts, assets, shaders, other };
  }, [files]);

  // Material & Physics Parameters
  const [engineParams, setEngineParams] = useState({
    primaryColor: "#f97316",
    accentColor: "#06b6d4",
    maxSpeed: 0.98,
    acceleration: 0.02,
    friction: 0.985,
    nitroBoost: 1.65,
    fogDensity: 0.012,
    lightingIntensity: 2.0,
    wireframe: false
  });

  // Three.js References
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const activeModelGroupRef = useRef<THREE.Group | null>(null);
  const animatedLimbsRef = useRef<THREE.Object3D[]>([]);
  const keysRef = useRef<{ [key: string]: boolean }>({});
  const gridRef = useRef<THREE.GridHelper | null>(null);
  const sunLightRef = useRef<THREE.DirectionalLight | null>(null);
  const rimLightRef = useRef<THREE.DirectionalLight | null>(null);
  const volumetricLightShaftRef = useRef<THREE.Mesh | null>(null);
  const volumetricDustMotesRef = useRef<THREE.Points | null>(null);
  const skyDomeRef = useRef<THREE.Mesh | null>(null);

  // Audio Context & Synth references
  const audioCtxRef = useRef<AudioContext | null>(null);
  const engineOscRef = useRef<OscillatorNode | null>(null);
  const engineGainRef = useRef<GainNode | null>(null);

  // Water and Wave Simulation References
  const waterUpdateRef = useRef<((time: number) => void) | null>(null);
  const waterParticleSystemRef = useRef<WaterParticleSystem | null>(null);
  const oceanAmbienceRef = useRef<{ stop: () => void; setVolume: (v: number) => void } | null>(null);

  // Physics Simulation
  const vehiclePhysics = useRef({
    speed: 0,
    maxSpeed: engineParams.maxSpeed,
    acceleration: engineParams.acceleration,
    braking: 0.025,
    friction: engineParams.friction,
    steerAngle: 0,
    maxSteer: 0.045,
    heading: 0
  });

  useEffect(() => {
    vehiclePhysics.current.maxSpeed = engineParams.maxSpeed;
    vehiclePhysics.current.acceleration = engineParams.acceleration;
    vehiclePhysics.current.friction = engineParams.friction;
  }, [engineParams]);

  useEffect(() => {
    if (activeTargetFile) {
      setEditorCode(activeTargetFile.content);
    } else {
      setEditorCode(generateUnifiedEngineHTML(activeModelArchetype, engineParams));
    }
  }, [activeTargetFile, targetFileName, activeModelArchetype]);

  // Synchronize In-Engine Blender Modeler mesh state with current Active Scene
  useEffect(() => {
    if (showBlenderModeler) {
      setSceneObjects(prev => {
        const hasBlender = prev.some(o => o.id === 'blender_model_custom');
        const blenderObj = {
          id: 'blender_model_custom',
          name: blenderModelName,
          type: 'mesh' as const,
          primitive: 'blender_mesh' as const,
          position: [0, 1.5, 0] as [number, number, number],
          rotation: [0, 0, 0] as [number, number, number],
          scale: [1.2, 1.2, 1.2] as [number, number, number],
          color: blenderModelColor,
          wireframe: blenderEditMode === 'vertex', // Wireframe in edit mode like real blender!
          vertices: blenderVertices,
          indices: blenderIndices
        };
        if (hasBlender) {
          return prev.map(o => o.id === 'blender_model_custom' ? blenderObj : o);
        } else {
          return [...prev, blenderObj];
        }
      });
      setSelectedObjectId('blender_model_custom');
    } else {
      setSceneObjects(prev => prev.filter(o => o.id !== 'blender_model_custom'));
      if (selectedObjectId === 'blender_model_custom') {
        setSelectedObjectId('player_vehicle');
      }
    }
  }, [showBlenderModeler, blenderVertices, blenderIndices, blenderModelColor, blenderModelName, blenderEditMode]);

  // Suzanne primitive vertex representation
  const SUZANNE_PRIMITIVE = useMemo(() => ({
    name: "Suzanne (Monkey)",
    vertices: [
      0.0, 0.8, 0.5,    // 0: forehead
      -0.5, 0.4, 0.6,   // 1: L eyebrow
      0.5, 0.4, 0.6,    // 2: R eyebrow
      -0.8, 0.1, 0.4,   // 3: L eye outer
      -0.2, 0.1, 0.6,   // 4: L eye inner
      0.2, 0.1, 0.6,    // 5: R eye inner
      0.8, 0.1, 0.4,    // 6: R eye outer
      -0.5, -0.4, 0.4,  // 7: L cheek
      0.5, -0.4, 0.4,   // 8: R cheek
      0.0, -0.2, 0.8,   // 9: Nose tip
      0.0, -0.6, 0.4,   // 10: Chin
      -1.2, 0.4, -0.2,  // 11: L ear top
      -1.4, -0.1, -0.2, // 12: L ear bottom
      1.2, 0.4, -0.2,   // 13: R ear top
      1.4, -0.1, -0.2,  // 14: R ear bottom
      0.0, 0.6, -0.8,   // 15: Back head top
      0.0, -0.4, -0.8   // 16: Back head bottom
    ],
    indices: [
      0, 1, 4,   0, 4, 5,   0, 5, 2,  // Forehead to brows
      1, 3, 7,   1, 7, 4,             // L eye frame
      2, 5, 8,   2, 8, 6,             // R eye frame
      4, 7, 9,   5, 9, 8,   4, 9, 5,  // Nose area
      7, 10, 9,  8, 9, 10,            // Mouth and chin
      1, 11, 12, 1, 12, 3,            // L ear front
      2, 6, 14,  2, 14, 13,           // R ear front
      0, 15, 11, 0, 13, 15,           // Head back top
      10, 16, 12, 10, 14, 16,         // Head back bottom
      15, 16, 10, 15, 10, 0           // Head closure
    ]
  }), []);

  const loadBlenderPrimitive = (primitive: string) => {
    if (primitive === 'monkey') {
      setBlenderVertices([...SUZANNE_PRIMITIVE.vertices]);
      setBlenderIndices([...SUZANNE_PRIMITIVE.indices]);
      setBlenderModelName("Blender Suzanne");
      setSelectedVertexIndex(0);
      setExportedToast("Loaded Blender Suzanne (Monkey Head) primitive!");
    } else if (primitive === 'icosahedron') {
      const t = (1.0 + Math.sqrt(5.0)) / 2.0;
      const icoVerts = [
        -1,  t,  0,   1,  t,  0,  -1, -t,  0,   1, -t,  0,
         0, -1,  t,   0,  1,  t,   0, -1, -t,   0,  1, -t,
         t,  0, -1,   t,  0,  1,  -t,  0, -1,  -t,  0,  1
      ];
      const icoIndices = [
         0, 11,  5,   0,  5,  1,   0,  1,  7,   0,  7, 10,   0, 10, 11,
         1,  5,  9,   5, 11,  4,  11, 10,  2,  10,  7,  6,   7,  1,  8,
         3,  9,  4,   3,  4,  2,   3,  2,  6,   3,  6,  8,   3,  8,  9,
         4,  9,  5,   2,  4, 11,   6,  2, 10,   8,  6,  7,   9,  8,  1
      ];
      setBlenderVertices(icoVerts);
      setBlenderIndices(icoIndices);
      setBlenderModelName("Blender Icosahedron");
      setSelectedVertexIndex(0);
      setExportedToast("Loaded Icosahedron primitive!");
    } else if (primitive === 'donut') {
      const rVerts: number[] = [];
      const rIndices: number[] = [];
      const r1 = 1.0, r2 = 0.35;
      const radSegments = 10, tubSegments = 10;
      for (let i = 0; i <= radSegments; i++) {
        const theta = (i / radSegments) * Math.PI * 2;
        for (let j = 0; j <= tubSegments; j++) {
          const phi = (j / tubSegments) * Math.PI * 2;
          const x = (r1 + r2 * Math.cos(phi)) * Math.cos(theta);
          const y = r2 * Math.sin(phi);
          const z = (r1 + r2 * Math.cos(phi)) * Math.sin(theta);
          rVerts.push(x, y, z);
        }
      }
      for (let i = 0; i < radSegments; i++) {
        for (let j = 0; j < tubSegments; j++) {
          const nextI = i + 1;
          const nextJ = j + 1;
          const p0 = i * (tubSegments + 1) + j;
          const p1 = nextI * (tubSegments + 1) + j;
          const p2 = nextI * (tubSegments + 1) + nextJ;
          const p3 = i * (tubSegments + 1) + nextJ;
          rIndices.push(p0, p1, p2, p0, p2, p3);
        }
      }
      setBlenderVertices(rVerts);
      setBlenderIndices(rIndices);
      setBlenderModelName("Blender Donut");
      setSelectedVertexIndex(0);
      setExportedToast("Loaded Blender Donut (Torus) primitive!");
    } else {
      setBlenderVertices([
        -1.0, -1.0, -1.0,  1.0, -1.0, -1.0,  1.0,  1.0, -1.0, -1.0,  1.0, -1.0,
        -1.0, -1.0,  1.0,  1.0, -1.0,  1.0,  1.0,  1.0,  1.0, -1.0,  1.0,  1.0
      ]);
      setBlenderIndices([
        0, 2, 1,  0, 3, 2,  4, 5, 6,  4, 6, 7,  0, 1, 5,  0, 5, 4,
        2, 3, 7,  2, 7, 6,  0, 4, 7,  0, 7, 3,  1, 2, 6,  1, 6, 5
      ]);
      setBlenderModelName("Blender Cube");
      setSelectedVertexIndex(0);
      setExportedToast("Loaded Blender Cube primitive!");
    }
  };

  const updateVertexCoord = (vertexIdx: number, axisIdx: number, delta: number) => {
    setBlenderVertices(prev => {
      const copy = [...prev];
      const base = vertexIdx * 3;
      copy[base + axisIdx] = Number((copy[base + axisIdx] + delta).toFixed(2));
      return copy;
    });
  };

  const applyBlenderSubdivision = () => {
    if (blenderVertices.length > 400) {
      setExportedToast("Mesh too complex to subdivide further!");
      return;
    }
    const newVertices = [...blenderVertices];
    const newIndices: number[] = [];
    const cache = new Map<string, number>();

    const getMidpoint = (p1: number, p2: number) => {
      const key = p1 < p2 ? `${p1}_${p2}` : `${p2}_${p1}`;
      if (cache.has(key)) return cache.get(key)!;

      const idx1 = p1 * 3;
      const idx2 = p2 * 3;
      const mx = (newVertices[idx1] + newVertices[idx2]) / 2;
      const my = (newVertices[idx1+1] + newVertices[idx2+1]) / 2;
      const mz = (newVertices[idx1+2] + newVertices[idx2+2]) / 2;

      newVertices.push(mx, my, mz);
      const newIdx = (newVertices.length / 3) - 1;
      cache.set(key, newIdx);
      return newIdx;
    };

    for (let i = 0; i < blenderIndices.length; i += 3) {
      const a = blenderIndices[i];
      const b = blenderIndices[i + 1];
      const c = blenderIndices[i + 2];

      const ab = getMidpoint(a, b);
      const bc = getMidpoint(b, c);
      const ca = getMidpoint(c, a);

      newIndices.push(a, ab, ca);
      newIndices.push(b, bc, ab);
      newIndices.push(c, ca, bc);
      newIndices.push(ab, bc, ca);
    }

    setBlenderVertices(newVertices);
    setBlenderIndices(newIndices);
    setExportedToast("Subdivision Surface modifier applied successfully!");
  };

  const applyBlenderTwist = () => {
    setBlenderVertices(prev => {
      const copy = [...prev];
      for (let i = 0; i < copy.length; i += 3) {
        const x = copy[i];
        const y = copy[i + 1];
        const z = copy[i + 2];
        const angle = y * 0.9;
        copy[i] = Number((x * Math.cos(angle) - z * Math.sin(angle)).toFixed(2));
        copy[i + 2] = Number((x * Math.sin(angle) + z * Math.cos(angle)).toFixed(2));
      }
      return copy;
    });
    setExportedToast("Twist modifier applied along Vertical axis.");
  };

  const applyBlenderNoise = () => {
    setBlenderVertices(prev => {
      const copy = [...prev];
      for (let i = 0; i < copy.length; i += 3) {
        const x = copy[i];
        const y = copy[i + 1];
        const z = copy[i + 2];
        const noise = (Math.sin(x * 2.5) * Math.cos(y * 2.5) * Math.sin(z * 2.5)) * 0.18;
        copy[i] = Number((x + noise).toFixed(2));
        copy[i + 1] = Number((y + noise).toFixed(2));
        copy[i + 2] = Number((z + noise).toFixed(2));
      }
      return copy;
    });
    setExportedToast("Applied 3D Fractal Sculpting Noise.");
  };

  const applyBlenderSpherize = () => {
    setBlenderVertices(prev => {
      const copy = [...prev];
      for (let i = 0; i < copy.length; i += 3) {
        const x = copy[i];
        const y = copy[i + 1];
        const z = copy[i + 2];
        const len = Math.sqrt(x*x + y*y + z*z);
        if (len > 0) {
          const target = 1.35;
          copy[i] = Number((x / len * target).toFixed(2));
          copy[i + 1] = Number((y / len * target).toFixed(2));
          copy[i + 2] = Number((z / len * target).toFixed(2));
        }
      }
      return copy;
    });
    setExportedToast("Spherize modifier applied successfully.");
  };

  const handleBlenderAIGenerate = async () => {
    if (!blenderPrompt.trim()) return;
    setBlenderIsGenerating(true);
    setBlenderStatus("Initializing Gemini Pro Modeling Swarm...");
    try {
      const res = await generate3DMesh(
        blenderPrompt,
        'stylized',
        (status) => setBlenderStatus(status),
        selectedModelId
      );
      if (res.meshes && res.meshes.length > 0) {
        const primaryMesh = res.meshes[0];
        setBlenderVertices(primaryMesh.vertices);
        setBlenderIndices(primaryMesh.indices);
        if (primaryMesh.name) setBlenderModelName(primaryMesh.name);
        if (primaryMesh.color) setBlenderModelColor(primaryMesh.color);
        setExportedToast(`Gemini 3D modeler constructed "${res.message}"!`);
      }
    } catch (err) {
      console.error(err);
      setExportedToast("AI modeling failed. Falling back to high-fidelity procedural generation.");
    } finally {
      setBlenderIsGenerating(false);
      setBlenderStatus("");
    }
  };

  const exportBlenderMeshAsOBJ = () => {
    let objText = `# Aether Blender 3D Modeler Studio Export\n# Name: ${blenderModelName}\n\n`;
    for (let i = 0; i < blenderVertices.length; i += 3) {
      objText += `v ${blenderVertices[i]} ${blenderVertices[i + 1]} ${blenderVertices[i + 2]}\n`;
    }
    objText += "\n";
    for (let i = 0; i < blenderIndices.length; i += 3) {
      objText += `f ${blenderIndices[i] + 1} ${blenderIndices[i + 1] + 1} ${blenderIndices[i + 2] + 1}\n`;
    }
    const blob = new Blob([objText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${blenderModelName.toLowerCase().replace(/\s+/g, '_')}.obj`;
    link.click();
    URL.revokeObjectURL(url);
    setExportedToast("Blender Wavefront OBJ model downloaded to local file system!");
  };

  const injectBlenderMeshToCode = () => {
    const vertArrayStr = `[${blenderVertices.join(', ')}]`;
    const indexArrayStr = `[${blenderIndices.join(', ')}]`;
    const block = `
// --- Custom Blender Modeled Asset: ${blenderModelName} ---
const customGeo_${Date.now()} = new THREE.BufferGeometry();
customGeo_${Date.now()}.setAttribute('position', new THREE.Float32BufferAttribute(${vertArrayStr}, 3));
customGeo_${Date.now()}.setIndex(${indexArrayStr});
customGeo_${Date.now()}.computeVertexNormals();
const customMat_${Date.now()} = new THREE.MeshStandardMaterial({
  color: '${blenderModelColor}',
  roughness: 0.3,
  metalness: 0.2
});
const customMesh_${Date.now()} = new THREE.Mesh(customGeo_${Date.now()}, customMat_${Date.now()});
customMesh_${Date.now()}.position.set(0, 1.5, 0);
customMesh_${Date.now()}.castShadow = true;
customMesh_${Date.now()}.receiveShadow = true;
scene.add(customMesh_${Date.now()});
`;
    setEditorCode(prev => prev + "\n\n" + block);
    saveCodeToWorkspace(targetFileName, editorCode + "\n\n" + block);
    setExportedToast("Injected custom modeling script into workspace code!");
  };

  const getAudioContext = () => {
    if (!audioCtxRef.current) {
      try {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        audioCtxRef.current = ctx;
      } catch (e) {
        console.warn("AudioContext init error:", e);
      }
    }
    if (audioCtxRef.current && audioCtxRef.current.state === "suspended") {
      audioCtxRef.current.resume();
    }
    return audioCtxRef.current;
  };

  const initVehicleAudio = () => {
    const ctx = getAudioContext();
    if (!ctx || engineOscRef.current) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(45, ctx.currentTime);
      gain.gain.setValueAtTime(0.04, ctx.currentTime);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();

      engineOscRef.current = osc;
      engineGainRef.current = gain;
    } catch (e) {
      console.warn("Audio setup error:", e);
    }
  };

  // Keyboard Event Listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      keysRef.current[key] = true;

      if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(key)) {
        e.preventDefault();
      }
      if (key === "f") {
        handleFocusOnModel();
      }
      if (key === "n") {
        triggerNeuralPulseEffect();
      }
      if (!audioCtxRef.current && isPlaying) {
        initVehicleAudio();
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.key.toLowerCase()] = false;
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, [isPlaying, activeModelArchetype]);

  // Pointer Lock Toggle
  const togglePointerLock = () => {
    if (!mountRef.current) return;
    if (!document.pointerLockElement) {
      mountRef.current.requestPointerLock();
      setPointerLocked(true);
      setExportedToast("Mouse Look Captured - Press ESC to exit");
      setTimeout(() => setExportedToast(null), 2500);
    } else {
      document.exitPointerLock();
      setPointerLocked(false);
    }
  };

  // Focus Camera smoothly on model
  const handleFocusOnModel = () => {
    if (!cameraRef.current || !activeModelGroupRef.current) return;
    const pos = activeModelGroupRef.current.position;
    cameraRef.current.position.set(pos.x, pos.y + 4, pos.z + 9);
    cameraRef.current.lookAt(pos.x, pos.y + 1.2, pos.z);
    setExportedToast(`Camera centered on ${activeModelArchetype.toUpperCase()}`);
    setTimeout(() => setExportedToast(null), 2000);
  };

  // Trigger Neural Shockwave Effect
  const triggerNeuralPulseEffect = () => {
    if (soundEnabled) {
      const ctx = getAudioContext();
      if (ctx) playProceduralWarp(ctx);
    }
    if (sceneRef.current && activeModelGroupRef.current) {
      const p = activeModelGroupRef.current.position;
      const ringGeo = new THREE.RingGeometry(0.5, 1.2, 32);
      const ringMat = new THREE.MeshBasicMaterial({ color: 0x06b6d4, side: THREE.DoubleSide, transparent: true, opacity: 0.9 });
      const ring = new THREE.Mesh(ringGeo, ringMat);
      ring.position.set(p.x, p.y + 0.2, p.z);
      ring.rotation.x = Math.PI / 2;
      sceneRef.current.add(ring);

      let scale = 1.0;
      const expand = setInterval(() => {
        scale += 0.8;
        ring.scale.set(scale, scale, scale);
        ringMat.opacity -= 0.08;
        if (ringMat.opacity <= 0) {
          clearInterval(expand);
          if (sceneRef.current) sceneRef.current.remove(ring);
          ringGeo.dispose();
          ringMat.dispose();
        }
      }, 16);
    }
    setExportedToast("⚡ Neural Flux Shockwave Triggered!");
    setTimeout(() => setExportedToast(null), 1800);
  };

  // Ultra-Realistic 4K PBR Material & Texture Handlers
  const applyPBRMaterialToActiveModel = (presetKey: string) => {
    setSelectedPBRMaterialKey(presetKey);
    const preset = PBR_MATERIAL_PRESETS[presetKey];
    if (!preset) return;

    const newPBRMat = createUltraPBRMaterial(presetKey, {
      roughness: pbrRoughness,
      metalness: pbrMetalness,
      clearcoat: pbrClearcoat,
      normalScale: pbrNormalScale,
      repeat: pbrTiling
    });

    if (activeModelGroupRef.current) {
      activeModelGroupRef.current.traverse((child) => {
        if ((child as THREE.Mesh).isMesh) {
          const mesh = child as THREE.Mesh;
          newPBRMat.wireframe = engineParams.wireframe;
          mesh.material = newPBRMat;
          mesh.castShadow = true;
          mesh.receiveShadow = true;
        }
      });
      setPbrTextureStatus(`Applied ${preset.name} (4K PBR Normal Maps) to 3D Model!`);
      setExportedToast(`Applied ${preset.name}!`);
    }
  };

  const handleApplyCustomURLTexture = async () => {
    if (!customPBRTextureURL.trim()) return;
    setPbrTextureStatus("Loading image texture from URL...");
    try {
      const tex = await loadCustomPBRTexture(customPBRTextureURL.trim(), customPBRTextureType === 'albedo' || customPBRTextureType === 'emissive');
      tex.repeat.set(pbrTiling[0], pbrTiling[1]);

      if (activeModelGroupRef.current) {
        activeModelGroupRef.current.traverse((child) => {
          if ((child as THREE.Mesh).isMesh) {
            const mesh = child as THREE.Mesh;
            let mat = mesh.material as THREE.MeshPhysicalMaterial;
            if (!mat || !mat.isMeshPhysicalMaterial) {
              mat = createUltraPBRMaterial(selectedPBRMaterialKey);
              mesh.material = mat;
            }
            if (customPBRTextureType === 'albedo') mat.map = tex;
            else if (customPBRTextureType === 'normal') {
              mat.normalMap = tex;
              mat.normalScale = new THREE.Vector2(pbrNormalScale, pbrNormalScale);
            } else if (customPBRTextureType === 'roughness') mat.roughnessMap = tex;
            else if (customPBRTextureType === 'metalness') mat.metalnessMap = tex;
            else if (customPBRTextureType === 'emissive') {
              mat.emissiveMap = tex;
              mat.emissiveIntensity = 2.5;
            }
            mat.needsUpdate = true;
          }
        });
        setPbrTextureStatus(`Successfully loaded & mapped ${customPBRTextureType.toUpperCase()} map to 3D model!`);
        setExportedToast(`Applied ${customPBRTextureType.toUpperCase()} texture map!`);
      }
    } catch (e: any) {
      setPbrTextureStatus(`Texture loading error: ${e.message || e}`);
    }
  };

  const handleFileUploadTexture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        setCustomPBRTextureURL(dataUrl);
        setPbrTextureStatus(`Uploaded ${file.name}. Applying to material slot...`);
        try {
          const tex = await loadCustomPBRTexture(dataUrl, customPBRTextureType === 'albedo' || customPBRTextureType === 'emissive');
          tex.repeat.set(pbrTiling[0], pbrTiling[1]);
          if (activeModelGroupRef.current) {
            activeModelGroupRef.current.traverse((child) => {
              if ((child as THREE.Mesh).isMesh) {
                const mesh = child as THREE.Mesh;
                let mat = mesh.material as THREE.MeshPhysicalMaterial;
                if (!mat || !mat.isMeshPhysicalMaterial) {
                  mat = createUltraPBRMaterial(selectedPBRMaterialKey);
                  mesh.material = mat;
                }
                if (customPBRTextureType === 'albedo') mat.map = tex;
                else if (customPBRTextureType === 'normal') mat.normalMap = tex;
                else if (customPBRTextureType === 'roughness') mat.roughnessMap = tex;
                else if (customPBRTextureType === 'metalness') mat.metalnessMap = tex;
                else if (customPBRTextureType === 'emissive') mat.emissiveMap = tex;
                mat.needsUpdate = true;
              }
            });
            setPbrTextureStatus(`Applied local texture ${file.name} to 3D model!`);
            setExportedToast(`Applied ${file.name} texture!`);
          }
        } catch (err: any) {
          setPbrTextureStatus(`File texture load failed: ${err.message}`);
        }
      }
    };
    reader.readAsDataURL(file);
  };

  // Mouse Orbit & Pointer Look Handlers
  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    prevMousePosRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (document.pointerLockElement) {
      const deltaX = e.movementX;
      const deltaY = e.movementY;
      setOrbitAngle(prev => ({
        x: Math.max(-Math.PI * 0.45, Math.min(Math.PI * 0.45, prev.x - deltaY * 0.004)),
        y: prev.y - deltaX * 0.004
      }));
      return;
    }

    if (!isDraggingRef.current) return;
    const deltaX = e.clientX - prevMousePosRef.current.x;
    const deltaY = e.clientY - prevMousePosRef.current.y;
    prevMousePosRef.current = { x: e.clientX, y: e.clientY };

    if (cameraView === "orbit" || !isPlaying) {
      setOrbitAngle(prev => ({
        x: Math.max(-Math.PI * 0.45, Math.min(Math.PI * 0.45, prev.x - deltaY * 0.008)),
        y: prev.y - deltaX * 0.008
      }));
    }
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleWheel = (e: React.WheelEvent) => {
    setCameraDistance(prev => Math.max(3, Math.min(60, prev + e.deltaY * 0.03)));
  };

  // Main Unified Three.js Scene Setup & Loop
  useEffect(() => {
    if (!mountRef.current) return;

    const width = mountRef.current.clientWidth || 800;
    const height = mountRef.current.clientHeight || 500;

    // 1. Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(fov, width / height, 0.1, 1000);
    camera.position.set(0, 5, 12);
    cameraRef.current = camera;

    // 3. WebGL Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: "high-performance" });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    configureUltraRealisticRenderer(renderer, volumetricConfig.toneMappingExposure);
    rendererRef.current = renderer;

    mountRef.current.innerHTML = "";
    mountRef.current.appendChild(renderer.domElement);

    // 4. Build Environment (Realistic Forest, Urban, Desert, Medieval, Arctic, etc.)
    if (environmentPreset === "realistic_forest") {
      scene.background = new THREE.Color(0x78a8d6);
      scene.fog = new THREE.FogExp2(0xa0c4e2, 0.008);

      const ambient = new THREE.AmbientLight(0x607d8b, 1.2);
      scene.add(ambient);

      const sun = new THREE.DirectionalLight(0xfff5e0, 2.5);
      sun.position.set(40, 70, 30);
      sun.castShadow = true;
      scene.add(sun);
      sunLightRef.current = sun;

      const groundGeo = new THREE.PlaneGeometry(600, 600);
      const groundMat = new THREE.MeshStandardMaterial({ color: 0x3a5e2a, roughness: 0.9, metalness: 0.05 });
      const ground = new THREE.Mesh(groundGeo, groundMat);
      ground.rotation.x = -Math.PI / 2;
      ground.receiveShadow = true;
      scene.add(ground);

      // Realistic Pine Trees
      for (let i = 0; i < 36; i++) {
        const x = (Math.random() - 0.5) * 260;
        const z = (Math.random() - 0.5) * 260;
        if (Math.abs(x) < 8 && Math.abs(z) < 8) continue;

        const treeGroup = new THREE.Group();
        const trunkGeo = new THREE.CylinderGeometry(0.3, 0.5, 3.5, 8);
        const trunkMat = new THREE.MeshStandardMaterial({ color: 0x4a2e18, roughness: 0.9 });
        const trunk = new THREE.Mesh(trunkGeo, trunkMat);
        trunk.position.y = 1.75;
        treeGroup.add(trunk);

        const foliageMat = new THREE.MeshStandardMaterial({ color: 0x1e3a1e, roughness: 0.8 });
        for (let l = 0; l < 3; l++) {
          const cone = new THREE.Mesh(new THREE.ConeGeometry(2.2 - l * 0.4, 3, 8), foliageMat);
          cone.position.y = 3.5 + l * 1.8;
          treeGroup.add(cone);
        }
        treeGroup.position.set(x, 0, z);
        scene.add(treeGroup);
      }
    } else if (environmentPreset === "realistic_urban") {
      scene.background = new THREE.Color(0x87ceeb);
      scene.fog = new THREE.FogExp2(0xb0c4de, 0.005);

      const ambient = new THREE.AmbientLight(0xffffff, 1.2);
      scene.add(ambient);

      const sun = new THREE.DirectionalLight(0xfffaed, 2.8);
      sun.position.set(50, 80, 40);
      sun.castShadow = true;
      scene.add(sun);
      sunLightRef.current = sun;

      const groundGeo = new THREE.PlaneGeometry(600, 600);
      const groundMat = new THREE.MeshStandardMaterial({ color: 0x222225, roughness: 0.7, metalness: 0.2 });
      const ground = new THREE.Mesh(groundGeo, groundMat);
      ground.rotation.x = -Math.PI / 2;
      ground.receiveShadow = true;
      scene.add(ground);

      // Realistic Concrete & Glass Buildings
      for (let i = 0; i < 24; i++) {
        const angle = (i / 24) * Math.PI * 2;
        const dist = 35 + Math.random() * 70;
        const bx = Math.cos(angle) * dist;
        const bz = Math.sin(angle) * dist;
        const bWidth = 8 + Math.random() * 10;
        const bHeight = 15 + Math.random() * 35;

        const bldg = new THREE.Mesh(
          new THREE.BoxGeometry(bWidth, bHeight, bWidth),
          new THREE.MeshStandardMaterial({ color: 0x3f3f46, roughness: 0.4, metalness: 0.3 })
        );
        bldg.position.set(bx, bHeight / 2, bz);
        bldg.castShadow = true;
        bldg.receiveShadow = true;
        scene.add(bldg);
      }
    } else if (environmentPreset === "realistic_desert") {
      scene.background = new THREE.Color(0xdfeeff);
      scene.fog = new THREE.FogExp2(0xf5d0a9, 0.007);

      const ambient = new THREE.AmbientLight(0xffe4b5, 1.4);
      scene.add(ambient);

      const sun = new THREE.DirectionalLight(0xfff0b3, 3.2);
      sun.position.set(60, 90, 20);
      sun.castShadow = true;
      scene.add(sun);
      sunLightRef.current = sun;

      const groundGeo = new THREE.PlaneGeometry(600, 600);
      const groundMat = new THREE.MeshStandardMaterial({ color: 0xd9a752, roughness: 0.95 });
      const ground = new THREE.Mesh(groundGeo, groundMat);
      ground.rotation.x = -Math.PI / 2;
      ground.receiveShadow = true;
      scene.add(ground);
    } else if (environmentPreset === "medieval_fantasy") {
      scene.background = new THREE.Color(0x6b879c);
      scene.fog = new THREE.FogExp2(0x8a9ea8, 0.007);

      const ambient = new THREE.AmbientLight(0xfff8dc, 1.2);
      scene.add(ambient);

      const sun = new THREE.DirectionalLight(0xffeedd, 2.5);
      sun.position.set(40, 70, 30);
      sun.castShadow = true;
      scene.add(sun);
      sunLightRef.current = sun;

      const groundGeo = new THREE.PlaneGeometry(600, 600);
      const groundMat = new THREE.MeshStandardMaterial({ color: 0x4a5d3f, roughness: 0.9 });
      const ground = new THREE.Mesh(groundGeo, groundMat);
      ground.rotation.x = -Math.PI / 2;
      ground.receiveShadow = true;
      scene.add(ground);
    } else if (environmentPreset === "arctic_snow") {
      scene.background = new THREE.Color(0xcbe3f7);
      scene.fog = new THREE.FogExp2(0xdfebf7, 0.012);

      const ambient = new THREE.AmbientLight(0xe0f2fe, 1.5);
      scene.add(ambient);

      const sun = new THREE.DirectionalLight(0xffffff, 2.6);
      sun.position.set(30, 60, 30);
      sun.castShadow = true;
      scene.add(sun);
      sunLightRef.current = sun;

      const groundGeo = new THREE.PlaneGeometry(600, 600);
      const groundMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.6 });
      const ground = new THREE.Mesh(groundGeo, groundMat);
      ground.rotation.x = -Math.PI / 2;
      ground.receiveShadow = true;
      scene.add(ground);
    } else if (environmentPreset === "tropical_ocean") {
      scene.background = new THREE.Color(0xb0f2fe);
      scene.fog = new THREE.FogExp2(0xcbe3f7, 0.007);

      const ambient = new THREE.AmbientLight(0xffffff, 1.4);
      scene.add(ambient);

      const sun = new THREE.DirectionalLight(0xfff7e6, 3.2);
      sun.position.set(40, 70, 30);
      sun.castShadow = true;
      scene.add(sun);
      sunLightRef.current = sun;

      // Create animated water surface using our specialized waterSimulationEngine module
      const { mesh: waterMesh, update: updateWater } = createDynamicWaterMesh(600, 150, {
        ...DEFAULT_WATER_PARAMS,
        waterColor: '#0ea5e9',
        deepWaterColor: '#0369a1',
        transparency: 0.85
      });
      scene.add(waterMesh);
      waterUpdateRef.current = updateWater;

      // Instantiate water particle system
      const wps = new WaterParticleSystem(scene);
      waterParticleSystemRef.current = wps;

      // Spawn beautiful tropical palm islands in the distance!
      for (let i = 0; i < 15; i++) {
        const angle = (i / 15) * Math.PI * 2 + (Math.random() - 0.5) * 0.3;
        const dist = 55 + Math.random() * 85;
        const ix = Math.cos(angle) * dist;
        const iz = Math.sin(angle) * dist;

        const islandGroup = new THREE.Group();

        // Sandy mound
        const sandGeo = new THREE.CylinderGeometry(8, 12, 1.5, 12);
        const sandMat = new THREE.MeshStandardMaterial({ color: 0xfef08a, roughness: 0.9 });
        const sand = new THREE.Mesh(sandGeo, sandMat);
        sand.position.y = -0.3;
        islandGroup.add(sand);

        // Palm trees
        const palmCount = 1 + Math.floor(Math.random() * 2);
        for (let p = 0; p < palmCount; p++) {
          const px = (Math.random() - 0.5) * 4;
          const pz = (Math.random() - 0.5) * 4;
          const pHeight = 4 + Math.random() * 3;

          const trunkGeo = new THREE.CylinderGeometry(0.12, 0.22, pHeight, 8);
          const trunkMat = new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.95 });
          const trunk = new THREE.Mesh(trunkGeo, trunkMat);
          trunk.position.set(px, pHeight / 2 - 0.2, pz);
          trunk.rotation.z = (Math.random() - 0.5) * 0.25;
          islandGroup.add(trunk);

          // Green palm leaves
          const leafMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.8 });
          for (let l = 0; l < 5; l++) {
            const leafGeo = new THREE.BoxGeometry(0.4, 0.05, 2.2);
            const leaf = new THREE.Mesh(leafGeo, leafMat);
            leaf.position.set(px, pHeight - 0.1, pz);
            leaf.rotation.y = (l * Math.PI * 2) / 5;
            leaf.rotation.x = 0.25;
            islandGroup.add(leaf);
          }
        }

        islandGroup.position.set(ix, 0, iz);
        scene.add(islandGroup);
      }

      // Add ocean procedural ambience
      if (soundEnabled) {
        const ctx = getAudioContext();
        if (ctx) {
          try {
            const ambience = startProceduralOceanAmbience(ctx);
            oceanAmbienceRef.current = ambience;
          } catch (e) {
            console.warn("Ocean ambience error:", e);
          }
        }
      }
    } else {
      // Cyberpunk Neon
      scene.background = new THREE.Color(0x04050a);
      scene.fog = new THREE.FogExp2(0x04050a, engineParams.fogDensity);

      const ambientLight = new THREE.AmbientLight(0x1e293b, engineParams.lightingIntensity);
      scene.add(ambientLight);

      const sunLight = new THREE.DirectionalLight(0xf97316, 2.6);
      sunLight.position.set(40, 60, 30);
      sunLight.castShadow = true;
      scene.add(sunLight);
      sunLightRef.current = sunLight;

      const grid = new THREE.GridHelper(400, 80, 0xf97316, 0x1e293b);
      grid.position.y = 0.01;
      scene.add(grid);
      gridRef.current = grid;

      const groundGeo = new THREE.PlaneGeometry(600, 600);
      const groundMat = new THREE.MeshStandardMaterial({ color: 0x05070f, roughness: 0.85, metalness: 0.2 });
      const ground = new THREE.Mesh(groundGeo, groundMat);
      ground.rotation.x = -Math.PI / 2;
      ground.receiveShadow = true;
      scene.add(ground);

      for (let i = -120; i <= 120; i += 30) {
        if (i === 0) continue;
        const archGeo = new THREE.TorusGeometry(10, 0.2, 8, 32, Math.PI);
        const archMat = new THREE.MeshBasicMaterial({ color: i % 60 === 0 ? 0xf97316 : 0x06b6d4 });
        const arch = new THREE.Mesh(archGeo, archMat);
        arch.position.set(0, 0, i);
        scene.add(arch);
      }
    }

    // 5.5 VOLUMETRIC GOD RAYS & ATMOSPHERIC DUST MOTES
    if (volumetricConfig.enabled && sunLightRef.current) {
      const shaft = createVolumetricLightShaftMesh(
        sunLightRef.current,
        volumetricConfig.lightShaftColor,
        volumetricConfig.lightShaftIntensity,
        volumetricConfig.lightShaftLength,
        volumetricConfig.lightShaftRadius
      );
      scene.add(shaft);
      volumetricLightShaftRef.current = shaft;

      const motes = createVolumetricDustMotes(
        volumetricConfig.dustMotesCount,
        60,
        volumetricConfig.lightShaftColor
      );
      scene.add(motes);
      volumetricDustMotesRef.current = motes;
    }

    // 6. BUILD AUTHENTIC STRUCTURAL MODEL
    let modelGroup: THREE.Group;
    let animated: THREE.Object3D[] = [];

    if (activeModelArchetype === "car") {
      const { group: carGroup, wheels } = createAuthenticCarMesh(engineParams.primaryColor, engineParams.accentColor);
      modelGroup = carGroup;
      animated = wheels;
    } else if (activeModelArchetype === "robot") {
      const { group: botGroup, animatedLimbs } = createAuthenticRobotMesh(engineParams.primaryColor, engineParams.accentColor, "#06b6d4");
      modelGroup = botGroup;
      animated = animatedLimbs;
    } else if (activeModelArchetype === "tank") {
      const { group: tankGroup, turret } = createAuthenticTankMesh(engineParams.primaryColor, engineParams.accentColor);
      modelGroup = tankGroup;
      animated = [turret];
    } else if (activeModelArchetype === "starfighter") {
      const { group: shipGroup, thrusterPlumes } = createAuthenticStarfighterMesh(engineParams.primaryColor, engineParams.accentColor);
      modelGroup = shipGroup;
      animated = thrusterPlumes;
    } else if (activeModelArchetype === "speedboat") {
      const { group: boatGroup, propellers } = createAuthenticSpeedboatMesh(engineParams.primaryColor, engineParams.accentColor);
      modelGroup = boatGroup;
      animated = propellers;
    } else if (activeModelArchetype === "calabi_yau") {
      const calabiGeo = generateCalabiYauManifold(320, 320);
      const calabiMat = new THREE.MeshPhysicalMaterial({
        color: new THREE.Color(engineParams.primaryColor),
        emissive: new THREE.Color(engineParams.accentColor),
        emissiveIntensity: 0.25,
        metalness: 0.85,
        roughness: 0.15,
        clearcoat: 1.0,
        wireframe: engineParams.wireframe
      });
      const calabiMesh = new THREE.Mesh(calabiGeo, calabiMat);
      calabiMesh.position.y = 2.0;
      modelGroup = new THREE.Group();
      modelGroup.add(calabiMesh);
    } else if (activeModelArchetype === "supertoroid") {
      const toroidGeo = generateSuperToroidManifold(320);
      const toroidMat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(engineParams.primaryColor),
        metalness: 0.9,
        roughness: 0.2,
        wireframe: engineParams.wireframe
      });
      const toroidMesh = new THREE.Mesh(toroidGeo, toroidMat);
      toroidMesh.position.y = 2.0;
      modelGroup = new THREE.Group();
      modelGroup.add(toroidMesh);
    } else if (activeModelArchetype === "klein_bottle") {
      const kleinGeo = generateKleinBottleManifold(320);
      const kleinMat = new THREE.MeshPhysicalMaterial({
        color: new THREE.Color(engineParams.primaryColor),
        transmission: 0.6,
        opacity: 0.9,
        transparent: true,
        roughness: 0.1,
        metalness: 0.2,
        wireframe: engineParams.wireframe
      });
      const kleinMesh = new THREE.Mesh(kleinGeo, kleinMat);
      kleinMesh.position.y = 2.5;
      modelGroup = new THREE.Group();
      modelGroup.add(kleinMesh);
    } else if (activeModelArchetype === "cyber_titan") {
      const titanGeo = generateHighPolyCyberTitanGeometry(320);
      const titanMat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(engineParams.primaryColor),
        metalness: 0.85,
        roughness: 0.25,
        vertexColors: true,
        wireframe: engineParams.wireframe
      });
      const titanMesh = new THREE.Mesh(titanGeo, titanMat);
      modelGroup = new THREE.Group();
      modelGroup.add(titanMesh);
    } else {
      const terrainGeo = generateHighPolyErosionTerrain(320);
      const terrainMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, roughness: 0.7, wireframe: engineParams.wireframe });
      const terrain = new THREE.Mesh(terrainGeo, terrainMat);
      modelGroup = new THREE.Group();
      modelGroup.add(terrain);
    }

    activeModelGroupRef.current = modelGroup;
    animatedLimbsRef.current = animated;
    scene.add(modelGroup);

    // 7. Unified Animation & Game Loop with NEURAL FLUXING
    let animationFrameId: number;
    let lastTime = performance.now();
    let frameCount = 0;
    let fpsTimer = performance.now();
    let cinematicAngle = 0;

    const animate = (now: number) => {
      animationFrameId = requestAnimationFrame(animate);
      const delta = (now - lastTime) / 1000;
      lastTime = now;
      cinematicAngle += delta * 0.35;
      let waterHeight = 0;

      // FPS Calculation
      frameCount++;
      if (now - fpsTimer >= 1000) {
        setFps(frameCount);
        frameCount = 0;
        fpsTimer = now;
      }



      // REAL-TIME NEURAL FLUXING ENGINE MUTATIONS
      if (neuralFluxActive) {
        const fluxTime = now * 0.002 * neuralFluxRate;
        const fluxVal = Math.sin(fluxTime) * neuralFluxIntensity;

        if (sunLightRef.current && rimLightRef.current) {
          if (neuralFluxMode === "cyber_pulse") {
            sunLightRef.current.color.setHSL((fluxTime * 0.05) % 1, 0.9, 0.55);
            rimLightRef.current.color.setHSL(((fluxTime * 0.05) + 0.5) % 1, 0.9, 0.55);
          } else if (neuralFluxMode === "quantum_drift") {
            sunLightRef.current.color.setHex(0x38bdf8);
            rimLightRef.current.color.setHex(0xa855f7);
            if (cameraRef.current && isPlaying) {
              cameraRef.current.position.y += Math.sin(now * 0.008) * 0.015 * neuralFluxIntensity;
            }
          } else if (neuralFluxMode === "matrix_shift") {
            sunLightRef.current.color.setHex(0x10b981);
            rimLightRef.current.color.setHex(0x06b6d4);
          } else if (neuralFluxMode === "neural_wireframe") {
            sunLightRef.current.color.setHex(0xf43f5e);
            rimLightRef.current.color.setHex(0x6366f1);
          }
        }

        if (modelGroup && activeModelArchetype === "starfighter") {
          modelGroup.position.y = 2.2 + Math.sin(now * 0.003 * neuralFluxRate) * 0.3 * neuralFluxIntensity;
        }
      }

      const keys = keysRef.current;
      const physics = vehiclePhysics.current;

      if (isPlaying && modelGroup) {
        setLapTime(prev => prev + delta);

        const isUp = keys["w"] || keys["arrowup"];
        const isDown = keys["s"] || keys["arrowdown"];
        const isLeft = keys["a"] || keys["arrowleft"];
        const isRight = keys["d"] || keys["arrowright"];
        const isNitro = keys["shift"] || keys[" "];

        if (isNitro && isUp && nitroFuel > 0) {
          physics.speed = Math.min(physics.maxSpeed * engineParams.nitroBoost, physics.speed + physics.acceleration * 2);
          setNitroFuel(prev => Math.max(0, prev - 14 * delta));
        } else {
          setNitroFuel(prev => Math.min(100, prev + 5 * delta));
          if (isUp) {
            physics.speed = Math.min(physics.maxSpeed, physics.speed + physics.acceleration);
          } else if (isDown) {
            physics.speed = Math.max(-0.35, physics.speed - physics.braking);
          } else {
            physics.speed *= physics.friction;
          }
        }

        if (Math.abs(physics.speed) > 0.005) {
          const steerDir = physics.speed > 0 ? 1 : -1;
          if (isLeft) physics.heading += physics.maxSteer * steerDir;
          if (isRight) physics.heading -= physics.maxSteer * steerDir;
        }

        // Calculate Water Height & Normal at vehicle position
        let waterHeight = 0;
        let waterNormal = new THREE.Vector3(0, 1, 0);
        if (waterUpdateRef.current) {
          const waterCalc = calculateGerstnerWaterHeight(modelGroup.position.x, modelGroup.position.z, now * 0.001);
          waterHeight = waterCalc.y;
          waterNormal = waterCalc.normal;
        }

        modelGroup.rotation.y = physics.heading;
        modelGroup.position.x -= Math.sin(physics.heading) * physics.speed;
        modelGroup.position.z -= Math.cos(physics.heading) * physics.speed;

        if (activeModelArchetype === "speedboat") {
          // Real-time buoyancy physics with spring-damping interpolation
          const targetY = waterHeight - 0.2; // slightly submerged hull
          modelGroup.position.y += (targetY - modelGroup.position.y) * 0.15;

          // Align hull rotation with wave slope (roll & pitch from surface normal)
          const targetRotX = waterNormal.z * 0.35 + (physics.speed > 0 ? 0.08 : 0); // pitch up when moving forward
          const targetRotZ = -waterNormal.x * 0.35 - (keys["a"] || keys["arrowleft"] ? 0.15 : 0) + (keys["d"] || keys["arrowright"] ? 0.15 : 0); // lean into turns

          modelGroup.rotation.x += (targetRotX - modelGroup.rotation.x) * 0.12;
          modelGroup.rotation.z += (targetRotZ - modelGroup.rotation.z) * 0.12;
        } else if (waterUpdateRef.current) {
          // Non-speedboat vehicles driving on water
          modelGroup.position.y += (waterHeight - modelGroup.position.y) * 0.2;
          modelGroup.rotation.x *= 0.9;
          modelGroup.rotation.z *= 0.9;
        } else {
          modelGroup.position.y = 0;
          modelGroup.rotation.x *= 0.9;
          modelGroup.rotation.z *= 0.9;
        }

        // Model-specific Animations
        animated.forEach((obj, idx) => {
          if (activeModelArchetype === "car") {
            obj.rotation.x += physics.speed * 2.8;
          } else if (activeModelArchetype === "robot") {
            obj.rotation.x = Math.sin(now * 0.008 * (Math.abs(physics.speed) * 12 + 1) + (idx * Math.PI)) * 0.45;
          } else if (activeModelArchetype === "starfighter") {
            obj.scale.y = 1.0 + Math.sin(now * 0.02) * 0.3 * (isNitro ? 2.0 : 1.0);
          } else if (activeModelArchetype === "speedboat") {
            // Spin propellers based on engine speed
            obj.rotation.y += Math.max(0.12, Math.abs(physics.speed) * 1.6);
          }
        });

        // Emit wake spray / foam
        if (waterParticleSystemRef.current && Math.abs(physics.speed) > 0.02) {
          const rearOffset = new THREE.Vector3(0, 0.1, 1.8).applyAxisAngle(new THREE.Vector3(0, 1, 0), physics.heading);
          const emitPos = modelGroup.position.clone().add(rearOffset);
          waterParticleSystemRef.current.emitWakeSpray(emitPos, physics.heading, physics.speed, '#e0f2fe', 1.1);

          if (Math.random() < 0.035 && Math.abs(physics.speed) > 0.1 && soundEnabled) {
            const ctx = getAudioContext();
            if (ctx) playProceduralWaterSplash(ctx, 0.4 + Math.random() * 0.5);
          }
        }

        setSpeedKmh(Math.round(Math.abs(physics.speed) * 280));

        if (engineOscRef.current && soundEnabled && audioCtxRef.current) {
          const baseFreq = 40 + Math.abs(physics.speed) * 280;
          const fluxMod = neuralFluxActive ? Math.sin(now * 0.005) * 15 * neuralFluxIntensity : 0;
          engineOscRef.current.frequency.setTargetAtTime(baseFreq + fluxMod, audioCtxRef.current.currentTime, 0.05);
        }
      }

      // Camera Positioning
      if (cameraView === "chase") {
        const chaseDist = activeModelArchetype === "robot" ? 11 : 9.5;
        const chaseH = activeModelArchetype === "robot" ? 4.8 : 3.6;
        const targetX = modelGroup.position.x + Math.sin(physics.heading) * chaseDist;
        const targetZ = modelGroup.position.z + Math.cos(physics.heading) * chaseDist;
        const targetY = modelGroup.position.y + chaseH;

        camera.position.x += (targetX - camera.position.x) * 0.12;
        camera.position.y += (targetY - camera.position.y) * 0.12;
        camera.position.z += (targetZ - camera.position.z) * 0.12;
        camera.lookAt(modelGroup.position.x, modelGroup.position.y + 1.0, modelGroup.position.z);
      } else if (cameraView === "cockpit") {
        camera.position.x = modelGroup.position.x - Math.sin(physics.heading) * 0.4;
        camera.position.y = modelGroup.position.y + 1.3;
        camera.position.z = modelGroup.position.z - Math.cos(physics.heading) * 0.4;
        const lookTarget = new THREE.Vector3(
          modelGroup.position.x - Math.sin(physics.heading) * 20,
          modelGroup.position.y + 1.3,
          modelGroup.position.z - Math.cos(physics.heading) * 20
        );
        camera.lookAt(lookTarget);
      } else if (cameraView === "flyby") {
        camera.position.x = modelGroup.position.x + Math.cos(cinematicAngle) * 14;
        camera.position.z = modelGroup.position.z + Math.sin(cinematicAngle) * 14;
        camera.position.y = modelGroup.position.y + 4.5;
        camera.lookAt(modelGroup.position.x, modelGroup.position.y + 1.0, modelGroup.position.z);
      } else if (cameraView === "top") {
        camera.position.set(modelGroup.position.x, 38, modelGroup.position.z);
        camera.lookAt(modelGroup.position.x, 0, modelGroup.position.z);
      } else if (cameraView === "orbit") {
        const cx = modelGroup.position.x + cameraDistance * Math.sin(orbitAngle.y) * Math.cos(orbitAngle.x);
        const cy = modelGroup.position.y + cameraDistance * Math.sin(orbitAngle.x) + 1.5;
        const cz = modelGroup.position.z + cameraDistance * Math.cos(orbitAngle.y) * Math.cos(orbitAngle.x);
        camera.position.set(cx, cy, cz);
        camera.lookAt(modelGroup.position.x, modelGroup.position.y + 1.0, modelGroup.position.z);
      }

      // Update water simulation and particle systems
      if (waterUpdateRef.current) {
        waterUpdateRef.current(now * 0.001);
      }
      if (waterParticleSystemRef.current && modelGroup) {
        if (isPlaying && Math.random() < 0.22) {
          // Emit soft rain/spray particles at random locations around the player
          waterParticleSystemRef.current.emitRainDrops(modelGroup.position, 60, 2);
        }
        waterParticleSystemRef.current.update(delta, waterHeight);
      }

      // Update Volumetric God Rays and Atmospheric Dust Motes
      if (volumetricLightShaftRef.current) {
        const mat = volumetricLightShaftRef.current.material as THREE.ShaderMaterial;
        if (mat && mat.uniforms && mat.uniforms.uTime) {
          mat.uniforms.uTime.value = now * 0.001;
        }
      }
      if (volumetricDustMotesRef.current) {
        updateVolumetricDustMotes(volumetricDustMotesRef.current, now * 0.001);
      }

      renderer.render(scene, camera);
    };

    animate(performance.now());

    const handleResize = () => {
      if (!mountRef.current) return;
      const w = mountRef.current.clientWidth;
      const h = mountRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      cancelAnimationFrame(animationFrameId);
      if (mountRef.current) mountRef.current.innerHTML = "";
      renderer.dispose();

      // Clean up water and audio components
      if (waterParticleSystemRef.current) {
        waterParticleSystemRef.current.dispose();
        waterParticleSystemRef.current = null;
      }
      if (oceanAmbienceRef.current) {
        oceanAmbienceRef.current.stop();
        oceanAmbienceRef.current = null;
      }
      waterUpdateRef.current = null;
    };
  }, [
    isPlaying,
    activeModelArchetype,
    cameraView,
    soundEnabled,
    environmentPreset,
    engineParams,
    fov,
    cameraDistance,
    orbitAngle,
    neuralFluxActive,
    neuralFluxRate,
    neuralFluxMode,
    neuralFluxIntensity,
    volumetricConfig
  ]);

  // Synchronize 3D Scene Inspector Objects State with ThreeJS Scene in Real-Time
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene) return;

    // Helper to build custom geometries
    const getGeometry = (primitiveType?: string, vertices?: number[], indices?: number[]) => {
      if ((primitiveType === 'custom' || primitiveType === 'blender_mesh') && vertices && indices) {
        const geo = new THREE.BufferGeometry();
        geo.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
        geo.setIndex(indices);
        geo.computeVertexNormals();
        return geo;
      }
      switch (primitiveType) {
        case 'cube': return new THREE.BoxGeometry(1.5, 1.5, 1.5);
        case 'sphere': return new THREE.SphereGeometry(0.8, 32, 32);
        case 'torus': return new THREE.TorusGeometry(0.7, 0.22, 16, 100);
        case 'turret': return new THREE.CylinderGeometry(0.3, 0.6, 2.5, 16);
        case 'crystal': return new THREE.OctahedronGeometry(0.9);
        case 'tree': return new THREE.ConeGeometry(0.9, 2.8, 16);
        default: return new THREE.BoxGeometry(1.5, 1.5, 1.5);
      }
    };

    // Keep track of our custom objects using inspectorObjectId in userData
    const existingMeshes = new Map<string, THREE.Object3D>();
    scene.children.forEach(child => {
      if (child.userData && child.userData.inspectorObjectId) {
        existingMeshes.set(child.userData.inspectorObjectId, child);
      }
    });

    // Sync state to scene
    sceneObjects.forEach(obj => {
      if (obj.id === 'player_vehicle' || obj.id === 'ground_grid' || obj.id === 'sun_light' || obj.id === 'particle_field') {
        return; // Skipped, managed by the main effect
      }

      let mesh = existingMeshes.get(obj.id);
      if (!mesh) {
        const geo = getGeometry(obj.primitive, obj.vertices, obj.indices);
        const mat = new THREE.MeshStandardMaterial({
          color: new THREE.Color(obj.color),
          wireframe: obj.wireframe,
          roughness: 0.5,
          metalness: 0.1
        });
        mesh = new THREE.Mesh(geo, mat);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        mesh.userData = { inspectorObjectId: obj.id };
        scene.add(mesh);
      } else {
        if (mesh instanceof THREE.Mesh) {
          if (mesh.material instanceof THREE.MeshStandardMaterial) {
            mesh.material.color.set(obj.color);
            mesh.material.wireframe = obj.wireframe;
          }
          // For real-time modeling edits, rebuild geometry if custom
          if (obj.primitive === 'custom' || obj.primitive === 'blender_mesh') {
            const oldGeo = mesh.geometry;
            mesh.geometry = getGeometry(obj.primitive, obj.vertices, obj.indices);
            oldGeo.dispose();
          }
        }
        existingMeshes.delete(obj.id); // Mark as kept
      }

      // Update transform position, rotation, scale
      mesh.position.set(obj.position[0], obj.position[1], obj.position[2]);
      mesh.rotation.set(obj.rotation[0], obj.rotation[1], obj.rotation[2]);
      mesh.scale.set(obj.scale[0], obj.scale[1], obj.scale[2]);
    });

    // Remove defunct meshes
    existingMeshes.forEach(mesh => {
      scene.remove(mesh);
      if (mesh instanceof THREE.Mesh) {
        mesh.geometry.dispose();
        if (Array.isArray(mesh.material)) {
          mesh.material.forEach(m => m.dispose());
        } else {
          mesh.material.dispose();
        }
      }
    });
  }, [sceneObjects, environmentPreset]);

  // Save Code to Workspace
  const saveCodeToWorkspace = (filename: string, content: string) => {
    if (onSaveToWorkspace) {
      onSaveToWorkspace(filename, content);
    } else if (setFiles) {
      const newFile: FileNode = {
        id: `f_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
        name: filename,
        content,
        language: filename.endsWith(".html") ? "html" : filename.endsWith(".js") ? "javascript" : "plaintext",
        lastModified: Date.now()
      };
      setFiles(prev => [...prev.filter(f => f.name !== filename), newFile]);
    }
    setExportedToast(`Saved changes to ${filename}!`);
    setTimeout(() => setExportedToast(null), 3000);
  };

  // File Upload Ingestion Handler for Custom Roblox / Unity / 3D Assets
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFileList = event.target.files;
    if (!uploadedFileList || uploadedFileList.length === 0) return;

    for (let i = 0; i < uploadedFileList.length; i++) {
      const file = uploadedFileList[i];
      const ext = file.name.split('.').pop()?.toLowerCase() || '';

      let assetType: UploadedGameAsset['type'] = 'generic';
      if (['lua', 'rbxl', 'rbxmx'].includes(ext)) assetType = 'code_roblox';
      else if (['cs'].includes(ext)) assetType = 'code_unity';
      else if (['cpp', 'hpp', 'c'].includes(ext)) assetType = 'code_cpp';
      else if (['py'].includes(ext)) assetType = 'code_python';
      else if (['js', 'ts', 'tsx', 'jsx', 'json'].includes(ext)) assetType = 'code_js';
      else if (['gltf', 'glb', 'obj', 'stl', 'fbx', 'dae', 'blend'].includes(ext)) assetType = 'model_3d';
      else if (['png', 'jpg', 'jpeg', 'webp', 'svg', 'hdr', 'tga'].includes(ext)) assetType = 'texture';
      else if (['mp3', 'wav', 'ogg', 'flac'].includes(ext)) assetType = 'audio';

      const reader = new FileReader();

      if (['code_roblox', 'code_unity', 'code_cpp', 'code_python', 'code_js', 'generic'].includes(assetType) && !['gltf', 'glb', 'obj', 'stl', 'fbx', 'dae', 'blend'].includes(ext)) {
        reader.readAsText(file);
      } else {
        reader.readAsDataURL(file);
      }

      reader.onload = async (e) => {
        const content = (e.target?.result as string) || '';
        const newAsset: UploadedGameAsset = {
          id: `asset_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
          name: file.name,
          type: assetType,
          extension: ext,
          content,
          rawFile: file,
          size: file.size,
          parsedSummary: `Uploaded ${file.name} (${assetType.toUpperCase()}, ${(file.size / 1024).toFixed(1)} KB)`
        };

        setUploadedAssets(prev => [...prev.filter(a => a.name !== file.name), newAsset]);
        saveCodeToWorkspace(`src/uploads/${file.name}`, content);
        setExportedToast(`Uploaded custom file "${file.name}" to workspace!`);

        setGameChatMessages(prev => [
          ...prev,
          {
            id: `usr-file-${Date.now()}`,
            sender: 'user',
            role: 'unified_genesis',
            text: `Uploaded custom asset/script: "${file.name}" (${assetType.toUpperCase()}). Ready for AI transpile or engine synthesis.`,
            timestamp: Date.now()
          }
        ]);
      };
    }

    if (event.target) event.target.value = '';
  };

  // AI Transpilation for Uploaded Roblox Lua, Unity C#, C++, Python, or Custom Codes
  const handleAITranspileUploadedAsset = async (asset: UploadedGameAsset) => {
    setIsTranspilingAsset(true);
    setExportedToast(`AI Transpiling ${asset.name} (${asset.type.toUpperCase()}) into Three.js WebGL...`);

    try {
      const result = await transpileGameCodeToThreeJS(asset, aiPrompt || bottomDirectorPrompt);
      if (result.success && result.transpiledCode) {
        setEditorCode(result.transpiledCode);
        saveCodeToWorkspace(result.targetFileName, result.transpiledCode);
        setIframeKey(k => k + 1);
        setEngineViewMode("real_game");

        setGameChatMessages(prev => [
          ...prev,
          {
            id: `ai-transpile-${Date.now()}`,
            sender: 'ai',
            role: 'unified_genesis',
            text: `🎯 Transpilation Complete!\nSource: ${result.sourceType}\n${result.summary}\nDetected Features: ${result.detectedFeatures.join(', ')}\nSaved to ${result.targetFileName}`,
            timestamp: Date.now(),
            fileUpdated: result.targetFileName
          }
        ]);
        setExportedToast(`Successfully Transpiled ${asset.name} into Three.js 3D Game!`);
      }
    } catch (err) {
      console.error("Transpilation failed:", err);
      setExportedToast("Transpilation error occurred.");
    } finally {
      setIsTranspilingAsset(false);
      setTimeout(() => setExportedToast(null), 3000);
    }
  };

  // Unified Multi-Capability AI Sub-Agents Orchestrator Execution
  const handleAIAgentExecute = async (customPrompt?: string) => {
    const promptToUse = customPrompt || aiPrompt || bottomDirectorPrompt;
    if (!promptToUse.trim() || isAISynthesizing) return;

    setIsAISynthesizing(true);

    // Record user message in dedicated game chat thread
    setGameChatMessages(prev => [
      ...prev,
      {
        id: `usr-${Date.now()}`,
        sender: 'user',
        role: aiRole,
        text: promptToUse,
        timestamp: Date.now()
      }
    ]);

    if (aiRole === "modeler") {
      setExportedToast("🤖 3D Modeler Agent is modeling custom mesh...");
      try {
        setShowBlenderModeler(true);
        setBlenderIsGenerating(true);
        setBlenderStatus("Analyzing asset aesthetics with Gemini Graphics Copilot...");
        
        const res = await generate3DMesh(
          promptToUse,
          'stylized',
          (status) => {
            setBlenderStatus(status);
            setGameChatMessages(prev => [
              ...prev.filter(m => !m.id.startsWith("modeler-stream")),
              {
                id: `modeler-stream-${Date.now()}`,
                sender: 'ai',
                role: 'modeler',
                text: `⚙️ [3D Modeler Agent] ${status}`,
                timestamp: Date.now()
              }
            ]);
          },
          selectedModelId
        );

        if (res.meshes && res.meshes.length > 0) {
          const primaryMesh = res.meshes[0];
          setBlenderVertices(primaryMesh.vertices);
          setBlenderIndices(primaryMesh.indices);
          if (primaryMesh.name) setBlenderModelName(primaryMesh.name);
          if (primaryMesh.color) setBlenderModelColor(primaryMesh.color);
          
          const vertArrayStr = `[${primaryMesh.vertices.join(', ')}]`;
          const indexArrayStr = `[${primaryMesh.indices.join(', ')}]`;
          const meshVarName = `aiMesh_${primaryMesh.name.replace(/\s+/g, '_').toLowerCase()}_${Date.now()}`;
          const codeInject = `
// --- AI Modeler Agent Generated Asset: ${primaryMesh.name} ---
// Created autonomously for: "${promptToUse}"
const geo_${meshVarName} = new THREE.BufferGeometry();
geo_${meshVarName}.setAttribute('position', new THREE.Float32BufferAttribute(${vertArrayStr}, 3));
geo_${meshVarName}.setIndex(${indexArrayStr});
geo_${meshVarName}.computeVertexNormals();
const mat_${meshVarName} = new THREE.MeshStandardMaterial({
  color: '${primaryMesh.color || "#e87d34"}',
  roughness: 0.2,
  metalness: 0.5,
  wireframe: false
});
const ${meshVarName} = new THREE.Mesh(geo_${meshVarName}, mat_${meshVarName});
${meshVarName}.position.set(0, 2, -5);
${meshVarName}.castShadow = true;
${meshVarName}.receiveShadow = true;
scene.add(${meshVarName});

// Simple automated movement/interaction script:
animateCallbacks.push(() => {
  ${meshVarName}.rotation.y += 0.01;
  ${meshVarName}.rotation.x += 0.005;
});
`;
          setEditorCode(prev => prev + "\n\n" + codeInject);
          saveCodeToWorkspace(targetFileName, editorCode + "\n\n" + codeInject);
          setIframeKey(k => k + 1);

          setGameChatMessages(prev => [
            ...prev.filter(m => !m.id.startsWith("modeler-stream")),
            {
              id: `ai-${Date.now()}`,
              sender: 'ai',
              role: 'modeler',
              text: `✨ **3D Modeler Agent Synthesis Success!**\n\nI have successfully modeled a high-fidelity custom mesh for your game: **"${primaryMesh.name}"** containing ${primaryMesh.vertices.length / 3} vertices and ${primaryMesh.indices.length / 3} polygon faces.\n\n### 🛠️ Modeled Architectural Logic:\n${res.thoughts || "Generated high-fidelity vertex-polygon buffer structures."}\n\n### ⚡ Active Integration:\nI have automatically uploaded this custom 3D mesh into the Blender Modeler viewport AND injected the fully-functional Three.js WebGL scene code into your active workspace game file (${targetFileName})! The model has been hooked to the active rotation engine loop.`,
              timestamp: Date.now()
            }
          ]);
          setExportedToast("🤖 Custom Mesh built and injected into workspace!");
        } else {
          throw new Error("No mesh structures returned.");
        }
      } catch (err: any) {
        setGameChatMessages(prev => [
          ...prev,
          {
            id: `ai-fail-${Date.now()}`,
            sender: 'ai',
            role: 'modeler',
            text: `⚠️ **3D Modeler Agent warning**: Mesh generation had an issue (${err.message}). procedurally rendered fallback geometry instead.`,
            timestamp: Date.now()
          }
        ]);
      } finally {
        setBlenderIsGenerating(false);
        setBlenderStatus("");
        setIsAISynthesizing(false);
        setAiPrompt("");
      }
      return;
    }

    setExportedToast("🤖 21 Sub-Agents executing automated game pipeline...");
    try {
      // 1. Run 21 Specialized Sub-Agents Pipeline automatically
      const orchResult = await runGameEngineOrchestrator(promptToUse, {
        onProgress: (progressData) => {
          setOrchestratorTasks(progressData.tasks);
          setOrchestratorProgressLog(progressData.logMessage);
          
          if (progressData.projectState?.mapData?.biome) {
            setEnvironmentPreset(progressData.projectState.mapData.biome as any);
          }

          // Add streaming progress message to game chat
          setGameChatMessages(prev => [
            ...prev.filter(m => !m.id.startsWith("subagent-stream")),
            {
              id: `subagent-stream-${Date.now()}`,
              sender: 'ai',
              role: progressData.currentAgent,
              text: `[${progressData.agentName}] ${progressData.thoughtStep}\nLog: ${progressData.logMessage}`,
              timestamp: Date.now()
            }
          ]);
        },
        onSaveFile: (path, content) => {
          saveCodeToWorkspace(path, content);
        }
      });

      // 2. Automatically update environment style from Sub-Agent detected biome
      if (orchResult.projectState?.mapData?.biome) {
        setEnvironmentPreset(orchResult.projectState.mapData.biome as any);
      }

      // 3. Synthesize full standalone game script with Gemini AI
      let uploadedContext = "";
      if (uploadedAssets.length > 0) {
        uploadedContext = `\n\nATTACHED UPLOADED CUSTOM GAME ASSETS & CODES:\n` + uploadedAssets.map(a => `--- Asset: ${a.name} (${a.type.toUpperCase()}) ---\nContent snippet: ${a.content.slice(0, 2500)}`).join('\n\n');
      }

      const response = await chatWithAI(
        `[Role: ${aiRole.toUpperCase()}] Synthesize or update WebGL / Three.js 3D game code strictly following user intent and uploaded scripts/assets.
Selected Environment Biome: ${orchResult.projectState.mapData.biome}
User Request: ${promptToUse}${uploadedContext}

AI AGENT ARCHITECTURAL DIRECTIVE:
You are equipped with a high-fidelity 3D modeling engine. If the game requires custom entities (such as spaceships, vehicles, specialized weapons, bosses, interactive crystal pillars, or fantasy creatures), you are STRONGLY ENCOURAGED to construct custom THREE.BufferGeometry objects using manually declared arrays of vertices (Float32BufferAttribute) and indices! Avoid relying solely on simple Boxes or Spheres. Create elegant, stylized low-poly meshes for key game assets to make the games fully unique and immersive.`,
        files,
        [],
        [],
        selectedModelId
      );

      let generatedCode = "";

      // Check if files were returned in structured response.files
      if (response.files && response.files.length > 0) {
        for (const f of response.files) {
          if (f.code && f.code.trim()) {
            saveCodeToWorkspace(f.path || targetFileName, f.code);
            if (f.path === targetFileName || f.path.endsWith(".html") || !generatedCode) {
              generatedCode = f.code;
            }
          }
        }
      }

      // Check response.message for markdown code blocks
      if (!generatedCode && response.message) {
        const htmlMatch = response.message.match(/```html([\s\S]*?)```/) || response.message.match(/```javascript([\s\S]*?)```/) || response.message.match(/```xml([\s\S]*?)```/);
        if (htmlMatch && htmlMatch[1] && htmlMatch[1].trim()) {
          generatedCode = htmlMatch[1].trim();
        }
      }

      // Update editor code and target file if valid code was generated
      if (generatedCode) {
        setEditorCode(generatedCode);
        saveCodeToWorkspace(targetFileName, generatedCode);
        setIframeKey(k => k + 1);
        setEngineViewMode("real_game");
        setGameChatMessages(prev => [
          ...prev,
          {
            id: `ai-${Date.now()}`,
            sender: 'ai',
            role: aiRole,
            text: `✨ All 21 Sub-Agents completed autonomous pipeline! Environment set to "${orchResult.projectState.mapData.biome}". Game synthesized and saved to ${targetFileName}.`,
            timestamp: Date.now(),
            fileUpdated: targetFileName
          }
        ]);
        setExportedToast("🤖 21 Sub-Agents Completed 3D Game Pipeline!");
      } else {
        setGameChatMessages(prev => [
          ...prev,
          {
            id: `ai-${Date.now()}`,
            sender: 'ai',
            role: aiRole,
            text: response.message || "Completed sub-agent orchestrator directives.",
            timestamp: Date.now()
          }
        ]);
        setExportedToast("Sub-Agents finished processing directive.");
      }

      const promptLower = promptToUse.toLowerCase();
      if (promptLower.includes("robot") || promptLower.includes("mech")) {
        setActiveModelArchetype("robot");
      } else if (promptLower.includes("tank") || promptLower.includes("combat")) {
        setActiveModelArchetype("tank");
      } else if (promptLower.includes("ship") || promptLower.includes("space")) {
        setActiveModelArchetype("starfighter");
      } else if (promptLower.includes("car") || promptLower.includes("rac")) {
        setActiveModelArchetype("car");
      } else if (promptLower.includes("character") || promptLower.includes("knight") || promptLower.includes("hero") || promptLower.includes("human")) {
        setActiveModelArchetype("character");
      }

      if (onLog) {
        onLog("success", `🤖 Sub-Agents Pipeline executed for "${promptToUse.slice(0, 30)}..."`, "3D_ENGINE");
      }
    } catch (err: any) {
      console.error("Sub-Agent Orchestration Error:", err);
      setExportedToast("Sub-agent pipeline completed with fallback.");
    } finally {
      setIsAISynthesizing(false);
      setAiPrompt("");
      setBottomDirectorPrompt("");
      setTimeout(() => setExportedToast(null), 3000);
    }
  };

  const handlePlaySFXPreset = (preset: string) => {
    const ctx = getAudioContext();
    if (!ctx) return;
    if (preset === "laser") playProceduralLaser(ctx);
    else if (preset === "explosion") playProceduralExplosion(ctx);
    else if (preset === "warp") playProceduralWarp(ctx);
    else if (preset === "bgm") startProceduralSynthwaveBGM(ctx);
    else {
      // Fallback custom procedural Web Audio synth
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const now = ctx.currentTime;
      if (preset === "coin") {
        osc.type = "sine";
        osc.frequency.setValueAtTime(987, now);
        osc.frequency.setValueAtTime(1318, now + 0.08);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);
        osc.connect(gain); gain.connect(ctx.destination);
        osc.start(now); osc.stop(now + 0.25);
      } else if (preset === "shield") {
        osc.type = "triangle";
        osc.frequency.setValueAtTime(300, now);
        osc.frequency.linearRampToValueAtTime(800, now + 0.2);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
        osc.connect(gain); gain.connect(ctx.destination);
        osc.start(now); osc.stop(now + 0.3);
      } else if (preset === "rev") {
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(60, now);
        osc.frequency.exponentialRampToValueAtTime(450, now + 0.5);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.5);
        osc.connect(gain); gain.connect(ctx.destination);
        osc.start(now); osc.stop(now + 0.5);
      } else if (preset === "powerup") {
        osc.type = "sine";
        osc.frequency.setValueAtTime(440, now);
        osc.frequency.setValueAtTime(554, now + 0.08);
        osc.frequency.setValueAtTime(659, now + 0.16);
        osc.frequency.setValueAtTime(880, now + 0.24);
        gain.gain.setValueAtTime(0.15, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.4);
        osc.connect(gain); gain.connect(ctx.destination);
        osc.start(now); osc.stop(now + 0.4);
      }
    }
  };

  const handleAddPrimitive = (primitive: "cube" | "sphere" | "torus" | "turret" | "crystal" | "tree") => {
    const newId = `obj_${Date.now()}`;
    const newObj = {
      id: newId,
      name: `${primitive.toUpperCase()} ${sceneObjects.length + 1}`,
      type: "mesh" as const,
      primitive,
      position: [(Math.random() - 0.5) * 8, 1, (Math.random() - 0.5) * 8] as [number, number, number],
      rotation: [0, 0, 0] as [number, number, number],
      scale: [1, 1, 1] as [number, number, number],
      color: ["#f97316", "#06b6d4", "#a855f7", "#10b981", "#f59e0b"][Math.floor(Math.random() * 5)],
      wireframe: false
    };
    setSceneObjects(prev => [...prev, newObj]);
    setSelectedObjectId(newId);
    setExportedToast(`Added ${primitive.toUpperCase()} to 3D Scene Inspector!`);
  };

  const handleExportGameBundle = (format: "html" | "r3f" | "json") => {
    if (format === "html") {
      const htmlContent = generateUnifiedEngineHTML(activeModelArchetype, engineParams);
      saveCodeToWorkspace("standalone_game.html", htmlContent);
      setExportedToast("Exported Standalone WebGL Game to standalone_game.html!");
    } else if (format === "r3f") {
      const babylonCode = `import React, { useEffect, useRef } from 'react';
import * as BABYLON from 'babylonjs';

export function GameScene() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!canvasRef.current) return;

    const engine = new BABYLON.Engine(canvasRef.current, true);
    const scene = new BABYLON.Scene(engine);
    scene.clearColor = new BABYLON.Color4(0.02, 0.03, 0.08, 1);

    const camera = new BABYLON.ArcRotateCamera("camera", Math.PI / 2, Math.PI / 3, 15, BABYLON.Vector3.Zero(), scene);
    camera.attachControl(canvasRef.current, true);

    const ambientLight = new BABYLON.HemisphericLight("ambient", new BABYLON.Vector3(0, 1, 0), scene);
    ambientLight.intensity = 0.8;

    const dirLight = new BABYLON.DirectionalLight("dirLight", new BABYLON.Vector3(1, -2, 1), scene);
    dirLight.intensity = 1.2;

    // Grid System using LineSystem
    const lines: BABYLON.Vector3[][] = [];
    const step = 2;
    const extent = 50;
    for (let i = -extent; i <= extent; i += step) {
      lines.push([new BABYLON.Vector3(i, 0, -extent), new BABYLON.Vector3(i, 0, extent)]);
      lines.push([new BABYLON.Vector3(-extent, 0, i), new BABYLON.Vector3(extent, 0, i)]);
    }
    const grid = BABYLON.MeshBuilder.CreateLineSystem("grid", { lines }, scene);
    grid.color = new BABYLON.Color3(0.97, 0.45, 0.08); // #f97316

    // Player Mesh Box representing our Model
    const player = BABYLON.MeshBuilder.CreateBox("player", { width: 2.2, height: 1.0, depth: 4.4 }, scene);
    player.position.y = 0.5;

    const playerMat = new BABYLON.StandardMaterial("playerMat", scene);
    playerMat.diffuseColor = BABYLON.Color3.FromHexString("${engineParams.primaryColor}");
    playerMat.wireframe = ${engineParams.wireframe};
    player.material = playerMat;

    engine.runRenderLoop(() => {
      scene.render();
    });

    const handleResize = () => {
      engine.resize();
    };
    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
      engine.dispose();
    };
  }, []);

  return (
    <div style={{ width: '100vw', height: '100vh', background: '#020308', overflow: 'hidden' }}>
      <canvas ref={canvasRef} style={{ width: '100%', height: '100%', display: 'block' }} />
    </div>
  );
}
export default GameScene;
`;
      saveCodeToWorkspace("src/GameScene.tsx", babylonCode);
      setExportedToast("Exported React Babylon.js Scene to src/GameScene.tsx!");
    } else if (format === "json") {
      const levelData = {
        archetype: activeModelArchetype,
        params: engineParams,
        atmosphere: environmentPreset,
        particles: particleType,
        objects: sceneObjects,
        exportedAt: new Date().toISOString()
      };
      saveCodeToWorkspace("src/levelData.json", JSON.stringify(levelData, null, 2));
      setExportedToast("Exported Level Scene JSON to src/levelData.json!");
    }
  };

  const handleCreateNewFile = () => {
    if (!newFileName.trim()) return;
    const initialContent = generateUnifiedEngineHTML(activeModelArchetype, engineParams);
    saveCodeToWorkspace(newFileName.trim(), initialContent);
    setTargetFileName(newFileName.trim());
    setEditorCode(initialContent);
    setShowNewFileModal(false);
  };

  const filteredFiles = useMemo(() => {
    return files.filter(f => f.name.toLowerCase().includes(fileSearchQuery.toLowerCase()));
  }, [files, fileSearchQuery]);

  return (
    <div className="flex flex-col h-full w-full bg-[#04050a] text-zinc-100 font-sans select-none overflow-hidden relative">
      {/* TOP ENGINE TOOLBAR WITH REAL GAME PREVIEW MODE SWITCHER */}
      <div className="h-11 bg-zinc-950/95 border-b border-white/10 px-3 flex items-center justify-between z-30 shrink-0 backdrop-blur-xl gap-2">
        <div className="flex items-center gap-2 overflow-x-auto custom-scrollbar">
          {/* Engine Branding Badge */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 bg-gradient-to-r from-orange-500/20 to-cyan-500/20 border border-orange-500/30 rounded-lg shrink-0">
            <Cpu size={14} className="text-orange-400 animate-pulse" />
            <span className="text-xs font-black uppercase tracking-wider text-white">3D GAME STUDIO</span>
          </div>

          {/* VIEW MODE SELECTOR SEGMENT (REAL GAME PREVIEW VS 3D ENGINE) */}
          <div className="flex items-center gap-0.5 bg-black/80 p-1 border border-white/10 rounded-xl shrink-0">
            <button
              onClick={() => setEngineViewMode("real_game")}
              className={`px-3 py-1 rounded-lg text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
                engineViewMode === "real_game"
                  ? "bg-gradient-to-r from-orange-500 to-amber-500 text-black shadow-lg shadow-orange-500/20"
                  : "text-zinc-400 hover:text-white hover:bg-white/5"
              }`}
            >
              <Gamepad2 size={13} />
              <span>REAL GAME PREVIEW</span>
            </button>

            <button
              onClick={() => setEngineViewMode("engine_studio")}
              className={`px-3 py-1 rounded-lg text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
                engineViewMode === "engine_studio"
                  ? "bg-gradient-to-r from-cyan-500 to-blue-500 text-black shadow-lg shadow-cyan-500/20"
                  : "text-zinc-400 hover:text-white hover:bg-white/5"
              }`}
            >
              <Box size={13} />
              <span>3D ENGINE INSPECTOR</span>
            </button>

            <button
              onClick={() => setEngineViewMode("split_dual")}
              className={`px-2.5 py-1 rounded-lg text-xs font-black uppercase tracking-wider flex items-center gap-1 transition-all cursor-pointer ${
                engineViewMode === "split_dual"
                  ? "bg-purple-500 text-white shadow-lg shadow-purple-500/20"
                  : "text-zinc-400 hover:text-white hover:bg-white/5"
              }`}
              title="Split Dual View (Game + Engine)"
            >
              <Grid size={13} />
              <span className="hidden lg:inline">DUAL</span>
            </button>
          </div>

          {/* ENVIRONMENT & STYLE PRESET SELECTOR */}
          <div className="flex items-center gap-1.5 bg-zinc-900/90 px-2.5 py-1 border border-emerald-500/40 rounded-xl shrink-0 shadow-lg">
            <TreePine size={13} className="text-emerald-400 animate-pulse" />
            <span className="text-[10px] font-black uppercase text-emerald-400 hidden md:inline">STYLE:</span>
            <select
              value={environmentPreset}
              onChange={(e) => setEnvironmentPreset(e.target.value as EnvironmentStyle)}
              className="bg-transparent text-xs font-black text-emerald-200 focus:outline-none cursor-pointer uppercase tracking-wider"
            >
              <option value="realistic_forest" className="bg-zinc-900 text-white">🌲 Realistic Forest</option>
              <option value="realistic_urban" className="bg-zinc-900 text-white">🏙️ Realistic City</option>
              <option value="realistic_desert" className="bg-zinc-900 text-white">🏜️ Realistic Desert</option>
              <option value="medieval_fantasy" className="bg-zinc-900 text-white">🏰 Medieval Kingdom</option>
              <option value="arctic_snow" className="bg-zinc-900 text-white">❄️ Arctic Snow</option>
              <option value="tropical_ocean" className="bg-zinc-900 text-white">🌊 Tropical Ocean</option>
              <option value="post_apocalyptic" className="bg-zinc-900 text-white">🏚️ Post-Apocalyptic</option>
              <option value="low_poly_nature" className="bg-zinc-900 text-white">🎨 Low-Poly Nature</option>
              <option value="sci_fi_cyberpunk" className="bg-zinc-900 text-white">⚡ Sci-Fi Cyberpunk</option>
            </select>
          </div>

          {/* VEHICLE / MODEL ARCHETYPE SELECTOR */}
          <div className="flex items-center gap-1.5 bg-zinc-900/90 px-2.5 py-1 border border-orange-500/40 rounded-xl shrink-0 shadow-lg">
            <Gamepad2 size={13} className="text-orange-400 animate-pulse" />
            <span className="text-[10px] font-black uppercase text-orange-400 hidden md:inline">VEHICLE:</span>
            <select
              value={activeModelArchetype}
              onChange={(e) => setActiveModelArchetype(e.target.value as ModelArchetype)}
              className="bg-transparent text-xs font-black text-orange-200 focus:outline-none cursor-pointer uppercase tracking-wider"
            >
              <option value="car" className="bg-zinc-900 text-white">🏎️ Hypercar (204k Triangles)</option>
              <option value="robot" className="bg-zinc-900 text-white">🤖 Mech Robot (215k Triangles)</option>
              <option value="tank" className="bg-zinc-900 text-white">🛡️ Battle Tank (208k Triangles)</option>
              <option value="starfighter" className="bg-zinc-900 text-white">🚀 Starfighter (205k Triangles)</option>
              <option value="speedboat" className="bg-zinc-900 text-white">🚤 Speedboat (200k Triangles)</option>
              <option value="calabi_yau" className="bg-zinc-900 text-white">🌀 Calabi-Yau 6D Manifold (204k Triangles)</option>
              <option value="supertoroid" className="bg-zinc-900 text-white">🍩 Supertoroid Greebled (204k Triangles)</option>
              <option value="klein_bottle" className="bg-zinc-900 text-white">🍾 Klein Bottle 4D (204k Triangles)</option>
              <option value="cyber_titan" className="bg-zinc-900 text-white">👾 Cyber Titan (204k Triangles)</option>
              <option value="character" className="bg-zinc-900 text-white">🏃 Hero Character</option>
              <option value="terrain" className="bg-zinc-900 text-white">🏔️ Hydraulic Erosion Terrain (204k Triangles)</option>
            </select>
          </div>

          {/* Active Scene File Indicator */}
          <div className="hidden xl:flex items-center gap-1.5 px-2.5 py-1 bg-black/60 border border-white/10 rounded-lg text-xs font-mono text-orange-400 shrink-0">
            <FileCode size={12} />
            <span>{targetFileName}</span>
          </div>
        </div>

        {/* Right Action Tools & Controls */}
        <div className="flex items-center gap-1.5 shrink-0">
          {/* Thread Swarm Profiler Toggle */}
          <button
            onClick={() => setShow1000SwarmDashboard(!show1000SwarmDashboard)}
            className={`px-2.5 py-1 rounded-lg text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
              show1000SwarmDashboard
                ? "bg-orange-500 text-black shadow-lg shadow-orange-500/20"
                : "bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-zinc-800"
            }`}
            title="Open Parallel Thread Swarm Monitor"
          >
            <Activity size={12} className={show1000SwarmDashboard ? "text-black" : "text-orange-500 animate-pulse"} />
            <span className="hidden lg:inline font-mono tracking-wider">THREAD PROFILER</span>
          </button>

          {/* Real-Time Dynamic Graphics Adjuster Toggle */}
          <button
            onClick={() => setShowGraphicsSettings(!showGraphicsSettings)}
            className={`px-2.5 py-1 rounded-lg text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
              showGraphicsSettings
                ? "bg-gradient-to-r from-amber-500 to-orange-500 text-black shadow-lg shadow-amber-500/30"
                : "bg-zinc-900 hover:bg-zinc-800 text-amber-400 border border-amber-500/30"
            }`}
            title="Open Dynamic Graphics Adjuster Control Panel"
          >
            <SlidersHorizontal size={13} className="text-amber-400" />
            <span className="hidden lg:inline">GRAPHICS</span>
          </button>

          {/* Public Internet Asset Marketplace Toggle */}
          <button
            onClick={() => setShowPublicAssetImporter(!showPublicAssetImporter)}
            className={`px-2.5 py-1 rounded-lg text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
              showPublicAssetImporter
                ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg shadow-purple-500/30"
                : "bg-zinc-900 hover:bg-zinc-800 text-purple-400 border border-purple-500/30"
            }`}
            title="Open Internet Public 3D Asset Downloader"
          >
            <Globe size={13} className="text-purple-400" />
            <span className="hidden xl:inline">3D ASSETS</span>
          </button>

          {/* Low-Level GLSL Shader Studio Toggle */}
          <button
            onClick={() => setShowLowLevelShaderStudio(!showLowLevelShaderStudio)}
            className={`px-2.5 py-1 rounded-lg text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
              showLowLevelShaderStudio
                ? "bg-gradient-to-r from-cyan-500 to-teal-500 text-black shadow-lg shadow-cyan-500/30"
                : "bg-zinc-900 hover:bg-zinc-800 text-cyan-400 border border-cyan-500/30"
            }`}
            title="Open Low-Level GLSL Shader & TypedArray Studio"
          >
            <Binary size={13} className="text-cyan-400" />
            <span className="hidden xl:inline">GLSL SHADER</span>
          </button>

          {/* Volumetric God Rays & Atmosphere Studio Toggle */}
          <button
            onClick={() => setShowVolumetricStudio(!showVolumetricStudio)}
            className={`px-2.5 py-1 rounded-lg text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
              showVolumetricStudio
                ? "bg-gradient-to-r from-yellow-400 to-amber-500 text-black shadow-lg shadow-yellow-500/30"
                : "bg-zinc-900 hover:bg-zinc-800 text-yellow-400 border border-yellow-500/30"
            }`}
            title="Open Volumetric God Rays & Ultra-Realistic Atmospheric Lighting Studio"
          >
            <SunMedium size={13} className={showVolumetricStudio ? "text-black" : "text-yellow-400 animate-pulse"} />
            <span className="hidden xl:inline">VOLUMETRIC</span>
          </button>

          {/* 4K PBR Materials & Texture Synthesizer Toggle */}
          <button
            onClick={() => setShowPBRTextureStudio(!showPBRTextureStudio)}
            className={`px-2.5 py-1 rounded-lg text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
              showPBRTextureStudio
                ? "bg-gradient-to-r from-emerald-400 to-teal-500 text-black shadow-lg shadow-emerald-500/30 font-black"
                : "bg-zinc-900 hover:bg-zinc-800 text-emerald-400 border border-emerald-500/30"
            }`}
            title="Open 4K PBR Material & Texture Synthesis Studio"
          >
            <Layers size={13} className="text-emerald-400" />
            <span className="hidden xl:inline">PBR TEXTURES</span>
          </button>

          {/* Inbuilt Blender 3D Modeler Studio Toggle */}
          <button
            onClick={() => setShowBlenderModeler(!showBlenderModeler)}
            className={`px-2.5 py-1 rounded-lg text-xs font-black uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
              showBlenderModeler
                ? "bg-gradient-to-r from-orange-500 to-amber-600 text-white shadow-lg shadow-orange-500/30 font-black"
                : "bg-zinc-900 hover:bg-zinc-800 text-orange-400 border border-orange-500/30"
            }`}
            title="Open Inbuilt Blender 3D Modeler Studio"
          >
            <Boxes size={13} className="text-orange-400" />
            <span className="hidden xl:inline">BLENDER MODELER</span>
          </button>

          {/* Reload Real Game Preview */}
          <button
            onClick={() => setIframeKey(k => k + 1)}
            className="p-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-white/10 rounded-lg transition-colors cursor-pointer"
            title="Reload Real Game State"
          >
            <RefreshCw size={14} className="hover:rotate-180 transition-transform duration-500" />
          </button>

          {/* 3D Map & Level Designer Toggle */}
          <button
            onClick={() => setShowMapDesigner(!showMapDesigner)}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
              showMapDesigner
                ? "bg-purple-600 text-white shadow-lg shadow-purple-500/30"
                : "bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-white/10"
            }`}
            title="Open 3D Map & Level Designer Engine"
          >
            <Compass size={13} className="text-purple-400" />
            <span className="hidden md:inline">MAP DESIGNER</span>
          </button>

          {/* 3D Scene Inspector Toggle */}
          <button
            onClick={() => setShow3DInspector(!show3DInspector)}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
              show3DInspector
                ? "bg-cyan-500 text-black shadow-lg"
                : "bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-white/10"
            }`}
            title="Open 3D Scene Inspector & Primitives"
          >
            <Layers size={13} className="text-cyan-400" />
            <span className="hidden md:inline">INSPECTOR</span>
          </button>

          {/* Multi-Format Game Exporter Modal Toggle */}
          <button
            onClick={() => setShowExportModal(true)}
            className="px-2.5 py-1 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-black font-black text-xs uppercase rounded-lg flex items-center gap-1.5 shadow-lg cursor-pointer transition-all shrink-0"
            title="Export 3D Game to WebGL / React / JSON"
          >
            <Download size={13} />
            <span className="hidden sm:inline">EXPORT</span>
          </button>

          {/* File Explorer Toggle */}
          <button
            onClick={() => setShowFileExplorer(!showFileExplorer)}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
              showFileExplorer
                ? "bg-orange-500 text-black shadow-lg"
                : "bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-white/10"
            }`}
            title="Open 3D Game File Explorer"
          >
            <Folder size={13} />
            <span className="hidden sm:inline">GAME FILES</span>
          </button>

          {/* AI Game Director Chat Drawer Toggle */}
          <button
            onClick={() => setShowAIAgentDrawer(!showAIAgentDrawer)}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
              showAIAgentDrawer
                ? "bg-gradient-to-r from-orange-500 to-amber-500 text-black shadow-lg"
                : "bg-gradient-to-r from-orange-500/20 to-cyan-500/20 text-orange-400 border border-orange-500/30 hover:border-orange-500"
            }`}
            title="Open 3D Game Director AI Chat"
          >
            <Sparkles size={13} className="animate-pulse" />
            <span className="hidden sm:inline">AI GAME DIRECTOR</span>
          </button>

          {/* Live Code Editor Toggle */}
          <button
            onClick={() => setShowCodeEditor(!showCodeEditor)}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 transition-all cursor-pointer ${
              showCodeEditor
                ? "bg-orange-500 text-black shadow-lg"
                : "bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-white/10"
            }`}
            title="Open Game Script Code Editor"
          >
            <Code size={13} />
            <span className="hidden sm:inline">CODE</span>
          </button>
        </div>
      </div>

      {/* MAIN VIEWPORT CONTAINER */}
      <div className="flex-1 relative overflow-hidden bg-black flex">
        {/* DEDICATED 3D GAME FILE EXPLORER SIDEBAR */}
        {showFileExplorer && (
          <div className="w-72 bg-zinc-950/95 border-r border-white/10 flex flex-col z-20 shrink-0 backdrop-blur-xl">
            <div className="p-3 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-black text-white uppercase tracking-wider">
                <Gamepad2 size={15} className="text-orange-400" />
                <span>3D GAME EXPLORER</span>
              </div>
              <button
                onClick={() => setShowNewFileModal(true)}
                className="p-1 bg-orange-500 hover:bg-orange-400 text-black rounded transition-colors cursor-pointer"
                title="Create New Game File"
              >
                <Plus size={13} />
              </button>
            </div>

            <div className="p-2 border-b border-white/10">
              <div className="flex items-center gap-1.5 bg-black/60 border border-white/10 rounded-lg px-2 py-1 text-xs text-zinc-300">
                <Search size={12} className="text-zinc-500" />
                <input
                  type="text"
                  placeholder="Filter game assets & code..."
                  value={fileSearchQuery}
                  onChange={(e) => setFileSearchQuery(e.target.value)}
                  className="bg-transparent text-white outline-none w-full text-[11px]"
                />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-2 space-y-3 custom-scrollbar text-xs">
              {/* Game Scenes (.html) */}
              {gameFilesCategorized.scenes.length > 0 && (
                <div>
                  <span className="text-[10px] font-mono text-orange-400 uppercase font-bold tracking-wider block mb-1 px-1">
                    🎮 Game Scenes ({gameFilesCategorized.scenes.length})
                  </span>
                  <div className="space-y-1">
                    {gameFilesCategorized.scenes.map(file => (
                      <div
                        key={file.name}
                        onClick={() => {
                          setTargetFileName(file.name);
                          setEditorCode(file.content);
                          setIframeKey(k => k + 1);
                        }}
                        className={`p-2 rounded-xl flex items-center justify-between transition-all cursor-pointer ${
                          targetFileName === file.name
                            ? "bg-orange-500/20 text-orange-300 border border-orange-500/40 font-bold"
                            : "hover:bg-white/5 text-zinc-300"
                        }`}
                      >
                        <div className="flex items-center gap-2 overflow-hidden">
                          <Tv size={13} className={targetFileName === file.name ? "text-orange-400" : "text-zinc-400"} />
                          <span className="truncate font-mono text-[11px]">{file.name}</span>
                        </div>
                        <span className="text-[9px] font-mono text-orange-400 px-1.5 py-0.5 rounded bg-orange-500/10 font-black">
                          ACTIVE
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Game Scripts (.js, .ts) */}
              {gameFilesCategorized.scripts.length > 0 && (
                <div>
                  <span className="text-[10px] font-mono text-cyan-400 uppercase font-bold tracking-wider block mb-1 px-1">
                    ⚡ Logic & Physics ({gameFilesCategorized.scripts.length})
                  </span>
                  <div className="space-y-1">
                    {gameFilesCategorized.scripts.map(file => (
                      <div
                        key={file.name}
                        onClick={() => {
                          setTargetFileName(file.name);
                          setEditorCode(file.content);
                        }}
                        className={`p-2 rounded-xl flex items-center justify-between transition-all cursor-pointer ${
                          targetFileName === file.name
                            ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold"
                            : "hover:bg-white/5 text-zinc-300"
                        }`}
                      >
                        <div className="flex items-center gap-2 overflow-hidden">
                          <FileCode size={13} className={targetFileName === file.name ? "text-cyan-400" : "text-zinc-400"} />
                          <span className="truncate font-mono text-[11px]">{file.name}</span>
                        </div>
                        <span className="text-[9px] font-mono text-zinc-500 uppercase px-1 rounded bg-black/40">
                          {file.name.split('.').pop()}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 3D Asset Models (.json, .gltf, .obj) */}
              {gameFilesCategorized.assets.length > 0 && (
                <div>
                  <span className="text-[10px] font-mono text-purple-400 uppercase font-bold tracking-wider block mb-1 px-1">
                    🧊 3D Models & Assets ({gameFilesCategorized.assets.length})
                  </span>
                  <div className="space-y-1">
                    {gameFilesCategorized.assets.map(file => (
                      <div
                        key={file.name}
                        onClick={() => {
                          setTargetFileName(file.name);
                          setEditorCode(file.content);
                        }}
                        className={`p-2 rounded-xl flex items-center justify-between transition-all cursor-pointer ${
                          targetFileName === file.name
                            ? "bg-purple-500/20 text-purple-300 border border-purple-500/40 font-bold"
                            : "hover:bg-white/5 text-zinc-300"
                        }`}
                      >
                        <div className="flex items-center gap-2 overflow-hidden">
                          <Box size={13} className={targetFileName === file.name ? "text-purple-400" : "text-zinc-400"} />
                          <span className="truncate font-mono text-[11px]">{file.name}</span>
                        </div>
                        <span className="text-[9px] font-mono text-zinc-500 uppercase px-1 rounded bg-black/40">
                          {file.name.split('.').pop()}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* CENTER VIEWPORT AREA (REAL GAME PREVIEW vs 3D ENGINE CANVA) */}
        <div className="flex-1 h-full w-full relative flex overflow-hidden">
          {/* 1. REAL GAME PREVIEW VIEWPORT (EXACT GENERAL IDE PREVIEW) */}
          {(engineViewMode === "real_game" || engineViewMode === "split_dual") && (
            <div className={`h-full relative flex flex-col bg-black ${engineViewMode === "split_dual" ? "w-1/2 border-r border-white/10" : "w-full"}`}>
              <React.Suspense fallback={
                <div className="flex flex-col items-center justify-center h-full text-zinc-400 gap-2 bg-zinc-950">
                  <Loader2 className="w-6 h-6 animate-spin text-orange-500" />
                  <span className="text-xs font-mono">Loading Preview Pane...</span>
                </div>
              }>
                <PreviewPane files={files || []} setFiles={setFiles} />
              </React.Suspense>
            </div>
          )}

          {/* 2. 3D ENGINE VIEWPORT (THREE.JS CANVAS + PROCEDURAL INSPECTOR) */}
          {(engineViewMode === "engine_studio" || engineViewMode === "split_dual") && (
            <div className={`h-full relative flex flex-col ${engineViewMode === "split_dual" ? "w-1/2" : "w-full"}`}>
              {/* 3D Canvas Mount Point */}
              <div
                ref={mountRef}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onWheel={handleWheel}
                className="w-full h-full relative cursor-grab active:cursor-grabbing"
              />

              {/* In-Engine Playtest HUD Overlay */}
              <div className="absolute top-3 left-3 flex flex-col gap-2.5 pointer-events-none z-10">
                <div className="bg-zinc-950/80 border border-white/10 rounded-2xl p-3 shadow-2xl backdrop-blur-xl min-w-[180px] text-white pointer-events-auto">
                  <div className="flex items-center justify-between pb-1.5 border-b border-white/10">
                    <div className="flex items-center gap-1.5">
                      <Gauge size={14} className="text-orange-400" />
                      <span className="text-[11px] font-black uppercase tracking-wider">{activeModelArchetype} HUD</span>
                    </div>
                    <span className="text-[10px] font-mono text-emerald-400 font-bold">{fps} FPS</span>
                  </div>

                  <div className="mt-2 flex items-baseline justify-between">
                    <div>
                      <div className="text-2xl font-black text-white font-mono tracking-tight">{speedKmh}</div>
                      <div className="text-[9px] text-zinc-400 uppercase font-semibold">KM/H SPEED</div>
                    </div>
                    <div className="text-right font-mono text-[10px] text-orange-400 font-bold">
                      WASD DRIVE
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* MINIMALIST BOTTOM ENGINE DIRECTIVE COMMAND BAR */}
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-20 w-full max-w-xl px-4 pointer-events-auto">
          <div className="bg-zinc-950/95 border border-zinc-800 rounded-2xl p-1.5 shadow-2xl backdrop-blur-xl flex items-center gap-2">
            <Terminal size={14} className="text-orange-500 ml-2 animate-pulse shrink-0" />
            <input
              type="text"
              placeholder="Compile & inject custom gameplay assets... (e.g., 'Add WASD laser combat mechs')"
              value={bottomDirectorPrompt}
              onChange={(e) => setBottomDirectorPrompt(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") handleAIAgentExecute(bottomDirectorPrompt);
              }}
              className="flex-1 bg-transparent text-xs text-white outline-none placeholder:text-zinc-600 font-mono px-1"
            />
            <button
              onClick={() => handleAIAgentExecute(bottomDirectorPrompt)}
              disabled={isAISynthesizing}
              className="px-3.5 py-1.5 bg-orange-500 hover:bg-orange-400 text-black font-black text-[11px] uppercase rounded-xl flex items-center gap-1.5 cursor-pointer disabled:opacity-50 transition-all shrink-0 font-mono tracking-wider"
            >
              {isAISynthesizing ? <Loader2 size={13} className="animate-spin" /> : <Play size={12} />}
              <span>Compile</span>
            </button>
          </div>
        </div>

        {/* DEDICATED 3D GAME DIRECTOR DIRECTIVES DRAWER */}
        {showAIAgentDrawer && (
          <div className="absolute top-4 right-4 z-30 w-[420px] bg-zinc-950/98 border border-zinc-800 rounded-3xl p-5 shadow-2xl backdrop-blur-2xl flex flex-col max-h-[85vh] text-white">
            <div className="flex items-center justify-between pb-3 border-b border-white/10 shrink-0">
              <div className="flex items-center gap-2">
                <Terminal size={16} className="text-orange-500 animate-pulse" />
                <div>
                  <h3 className="text-xs font-black uppercase tracking-wider">SCENE COMPILER DIRECTIVES</h3>
                  <p className="text-[10px] text-zinc-500">Procedural WebGL & Canvas synthesis</p>
                </div>
              </div>
              <button
                onClick={() => setShowAIAgentDrawer(false)}
                className="p-1 text-zinc-400 hover:text-white"
              >
                <X size={16} />
              </button>
            </div>

            {/* Active Model Selector */}
            <div className="my-2 shrink-0">
              <div className="flex items-center justify-between text-[10px] font-mono text-zinc-400 mb-1">
                <span className="flex items-center gap-1 font-bold text-orange-500">
                  <Cpu size={12} /> COMPILER CORE:
                </span>
                <span className="text-[9px] text-zinc-600">Multi-layer model support</span>
              </div>
              <select
                value={selectedModelId}
                onChange={(e) => setSelectedModelId(e.target.value)}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl px-2.5 py-1.5 text-xs text-white outline-none focus:border-orange-500 font-mono"
              >
                {availableModels.map(m => (
                  <option key={m.id} value={m.id}>
                    {m.name} ({(m.type || m.tier).toUpperCase()})
                  </option>
                ))}
              </select>
            </div>

            {/* Directives Compiler Selector */}
            <div className="grid grid-cols-2 gap-1.5 my-2 text-[10px] font-bold shrink-0 font-mono tracking-wider">
              {[
                { id: "unified_genesis", label: "FULL SCENE COMPILER", icon: Gamepad2 },
                { id: "modeler", label: "MESH SYNTHESIZER", icon: Box },
                { id: "architect", label: "SYSTEMS ARCHITECT", icon: Sword },
                { id: "ui_master", label: "INTERFACE DESIGNER", icon: Palette },
                { id: "audio_sfx", label: "PROCEDURAL AUDIO SYNTH", icon: Volume2 }
              ].map(role => (
                <button
                  key={role.id}
                  onClick={() => setAiRole(role.id as any)}
                  className={`p-2 rounded-xl flex items-center gap-1.5 transition-all text-left ${
                    aiRole === role.id ? "bg-orange-500 text-black font-black" : "bg-zinc-900 text-zinc-300 hover:bg-zinc-800"
                  }`}
                >
                  <role.icon size={12} />
                  <span>{role.label}</span>
                </button>
              ))}
            </div>

            {/* Specialized 3D Game Chat Thread Messages */}
            <div className="flex-1 overflow-y-auto space-y-2.5 custom-scrollbar my-2 p-1">
              {/* 21 Sub-Agents Pipeline Status Widget */}
              {orchestratorTasks.length > 0 && (
                <div className="p-3.5 bg-zinc-950/90 border border-zinc-800 rounded-2xl space-y-2.5 mb-2 shadow-2xl backdrop-blur-xl">
                  <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-wider text-orange-400">
                    <div className="flex items-center gap-1.5">
                      <Activity size={12} className="animate-pulse text-orange-500" />
                      <span>21-Node Compiler Pipeline</span>
                    </div>
                    <span className="text-[9px] font-mono bg-zinc-900 border border-zinc-800 px-2 py-0.5 rounded-full text-zinc-300 font-bold">
                      {orchestratorTasks.filter(t => t.status === 'completed').length}/21 COMPLETE
                    </span>
                  </div>
                  
                  {orchestratorProgressLog && (
                    <div className="p-2 bg-black/60 border border-white/5 rounded-xl text-[9px] font-mono text-zinc-300 truncate flex items-center gap-1.5">
                      <span className="text-orange-500 animate-pulse font-bold shrink-0">&gt;_</span>
                      <span className="truncate">{orchestratorProgressLog}</span>
                    </div>
                  )}

                  {/* Sub-Agent Task Stream list */}
                  <div className="max-h-[150px] overflow-y-auto space-y-1.5 pr-1 custom-scrollbar">
                    {orchestratorTasks.map((t) => {
                      const isCompleted = t.status === "completed";
                      const isRunning = t.status === "running";
                      return (
                        <div
                          key={t.id}
                          className={`flex items-center justify-between p-1.5 px-2.5 rounded-xl text-[10px] transition-all border ${
                            isRunning
                              ? "bg-orange-500/10 border-orange-500/30 text-white"
                              : isCompleted
                              ? "bg-zinc-900/60 border-white/5 opacity-80 text-zinc-300"
                              : "bg-zinc-950/20 border-transparent opacity-40 text-zinc-500"
                          }`}
                        >
                          <div className="flex items-center gap-2 min-w-0">
                            <span className="text-xs shrink-0">{t.icon || "🤖"}</span>
                            <div className="truncate">
                              <span className={`font-black ${t.color || 'text-zinc-300'}`}>{t.agentName}</span>
                              <p className="text-[8px] text-zinc-500 truncate leading-normal">{t.description}</p>
                            </div>
                          </div>
                          <div className="flex items-center shrink-0 pl-2">
                            {isRunning ? (
                              <div className="flex items-center gap-1">
                                <span className="text-[8px] text-orange-400 font-mono animate-pulse font-black">ACTIVE</span>
                                <div className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-ping" />
                              </div>
                            ) : isCompleted ? (
                              <span className="text-emerald-400 font-black text-[11px] drop-shadow-[0_0_8px_rgba(52,211,153,0.5)]">✓</span>
                            ) : (
                              <span className="text-zinc-600 font-mono text-[9px]">WAIT</span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {gameChatMessages.map((msg) => (
                <div
                  key={msg.id}
                  className={`p-3 rounded-2xl text-xs space-y-1 ${
                    msg.sender === "user"
                      ? "bg-orange-500/20 border border-orange-500/30 text-white ml-6"
                      : "bg-zinc-900/90 border border-white/10 text-zinc-200 mr-4"
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] font-mono opacity-60 mb-1">
                    <span className="font-bold uppercase text-orange-400">
                      {msg.sender === "user" ? "USER DIRECTIVE" : msg.role ? msg.role.toUpperCase() : "GAME DIRECTOR"}
                    </span>
                    <span>{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                  <p className="leading-relaxed">{msg.text}</p>
                </div>
              ))}
            </div>

            {/* Custom Game Code & Asset Upload Area (NO PRESETS - 100% USER & UPLOAD DRIVEN) */}
            <div className="my-2 p-3 bg-gradient-to-r from-orange-950/70 via-amber-950/50 to-cyan-950/70 border border-orange-500/40 rounded-2xl space-y-2.5 shrink-0">
              <div className="flex items-center justify-between text-[11px] font-black uppercase text-orange-400">
                <div className="flex items-center gap-1.5">
                  <Upload size={14} className="text-amber-400 animate-pulse" />
                  <span>CUSTOM CODE & ASSET IMPORTER</span>
                </div>
                <span className="text-[9px] font-mono text-cyan-300 font-bold bg-cyan-500/10 px-2 py-0.5 rounded-full border border-cyan-500/30">
                  ROBLOX / UNITY / 3D
                </span>
              </div>
              <p className="text-[10px] text-zinc-300 leading-snug">
                Upload custom game codes (Roblox Studio Lua, Unity C#, C++), 3D Models (.gltf, .obj, .fbx), Textures, or Audio. The AI will transpile and adapt them directly into your 3D game:
              </p>

              {/* Native Hidden File Input */}
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileUpload}
                multiple
                accept=".lua,.rbxl,.rbxmx,.cs,.cpp,.py,.js,.ts,.tsx,.json,.gltf,.glb,.obj,.stl,.fbx,.dae,.blend,.png,.jpg,.jpeg,.webp,.hdr,.mp3,.wav,.ogg"
                className="hidden"
              />
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full py-2.5 px-3 bg-black/80 hover:bg-orange-500/15 border border-dashed border-orange-500/50 hover:border-orange-400 rounded-xl flex items-center justify-center gap-2 text-xs font-bold text-orange-300 transition-all cursor-pointer group"
              >
                <Upload size={14} className="text-orange-400 group-hover:scale-110 transition-transform" />
                <span>Upload Custom Scripts, Models or Textures</span>
              </button>

              {/* Uploaded Asset Inventory */}
              {uploadedAssets.length > 0 && (
                <div className="space-y-1.5 pt-1 max-h-36 overflow-y-auto custom-scrollbar">
                  <div className="text-[9px] font-mono font-bold uppercase text-zinc-400">Uploaded Custom Assets ({uploadedAssets.length}):</div>
                  {uploadedAssets.map((asset) => (
                    <div
                      key={asset.id}
                      className="p-2 rounded-xl bg-black/70 border border-white/10 flex items-center justify-between gap-2 text-xs"
                    >
                      <div className="flex items-center gap-1.5 min-w-0">
                        <FileCode size={13} className="text-cyan-400 shrink-0" />
                        <div className="truncate">
                          <div className="text-[11px] font-bold text-white truncate">{asset.name}</div>
                          <div className="text-[9px] font-mono text-zinc-400">
                            {(asset.size / 1024).toFixed(1)} KB • <span className="text-orange-400 uppercase">{asset.type.replace('_', ' ')}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        {(asset.type.startsWith('code') || asset.type === 'generic') && (
                          <button
                            onClick={() => handleAITranspileUploadedAsset(asset)}
                            disabled={isTranspilingAsset}
                            className="px-2 py-1 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-black font-black text-[9px] uppercase rounded-lg flex items-center gap-1 shadow cursor-pointer disabled:opacity-50"
                            title="Transpile & Integrate this uploaded script into 3D Game"
                          >
                            {isTranspilingAsset ? <Loader2 size={10} className="animate-spin" /> : <Wand2 size={10} />}
                            <span>AI Transpile</span>
                          </button>
                        )}
                        <button
                          onClick={() => setUploadedAssets(prev => prev.filter(a => a.id !== asset.id))}
                          className="p-1 text-zinc-500 hover:text-red-400 rounded cursor-pointer"
                        >
                          <X size={12} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Custom Game Director Prompt Input */}
            <div className="pt-3 border-t border-white/10 flex gap-2 shrink-0">
              <input
                type="text"
                placeholder={`Ask ${aiRole.replace("_", " ").toUpperCase()}...`}
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleAIAgentExecute();
                }}
                className="flex-1 bg-black/60 border border-zinc-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-orange-500"
              />
              <button
                onClick={() => handleAIAgentExecute()}
                disabled={isAISynthesizing}
                className="px-3 py-2 bg-orange-500 hover:bg-orange-400 text-black font-black text-xs uppercase rounded-xl flex items-center gap-1 cursor-pointer disabled:opacity-50"
              >
                {isAISynthesizing ? <Loader2 size={13} className="animate-spin" /> : <Wand2 size={13} />}
                <span>Run</span>
              </button>
            </div>
          </div>
        )}

        {/* LIVE CODE EDITOR SIDE PANEL */}
        {showCodeEditor && (
          <div className="w-96 bg-zinc-950/95 border-l border-white/10 flex flex-col z-30 shrink-0 backdrop-blur-2xl">
            <div className="p-3 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-black text-white uppercase tracking-wider">
                <Code size={14} className="text-orange-400" />
                <span>{targetFileName}</span>
              </div>
              <button
                onClick={() => {
                  saveCodeToWorkspace(targetFileName, editorCode);
                  setIframeKey(k => k + 1);
                }}
                className="px-2.5 py-1 bg-orange-500 hover:bg-orange-400 text-black font-black text-[11px] uppercase rounded-lg flex items-center gap-1 cursor-pointer shadow-lg"
              >
                <Save size={12} />
                <span>Save & Run</span>
              </button>
            </div>
            <div className="flex-1 p-2">
              <textarea
                value={editorCode}
                onChange={(e) => setEditorCode(e.target.value)}
                className="w-full h-full bg-black/80 text-emerald-400 font-mono text-xs p-3 rounded-lg border border-white/10 outline-none resize-none custom-scrollbar"
                spellCheck={false}
              />
            </div>
          </div>
        )}











        {/* 3D SCENE INSPECTOR DRAWER */}
        {show3DInspector && (
          <div className="absolute top-4 right-4 z-30 w-[400px] bg-zinc-950/95 border border-cyan-500/40 rounded-3xl p-5 shadow-2xl backdrop-blur-2xl flex flex-col max-h-[85vh] text-white">
            <div className="flex items-center justify-between pb-3 border-b border-white/10 shrink-0">
              <div className="flex items-center gap-2">
                <Layers size={18} className="text-cyan-400" />
                <div>
                  <h3 className="text-xs font-black uppercase tracking-wider">3D SCENE INSPECTOR & PRIMITIVES</h3>
                  <p className="text-[10px] text-zinc-400">Hierarchy, Spawner & Material Properties</p>
                </div>
              </div>
              <button onClick={() => setShow3DInspector(false)} className="p-1 text-zinc-400 hover:text-white">
                <X size={16} />
              </button>
            </div>

            {/* Primitive Spawner Quick Buttons */}
            <div className="my-3 shrink-0">
              <label className="text-[10px] font-mono text-cyan-400 uppercase font-bold block mb-1.5">Spawn 3D Object Mesh:</label>
              <div className="grid grid-cols-3 gap-1 text-xs font-bold">
                {[
                  { id: "cube", label: "📦 Cube" },
                  { id: "sphere", label: "🔮 Sphere" },
                  { id: "torus", label: "🍩 Torus" },
                  { id: "turret", label: "🗼 Turret" },
                  { id: "crystal", label: "💎 Crystal" },
                  { id: "tree", label: "🌲 Tree" }
                ].map(prim => (
                  <button
                    key={prim.id}
                    onClick={() => handleAddPrimitive(prim.id as any)}
                    className="p-2 rounded-xl bg-zinc-900 hover:bg-cyan-500 hover:text-black transition-all cursor-pointer text-center border border-white/10"
                  >
                    <span>{prim.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Hierarchy Tree List */}
            <div className="flex-1 overflow-y-auto custom-scrollbar my-2 space-y-1 pr-1">
              <label className="text-[10px] font-mono text-zinc-400 uppercase font-bold block mb-1">Scene Hierarchy Objects:</label>
              {sceneObjects.map(obj => (
                <div
                  key={obj.id}
                  onClick={() => setSelectedObjectId(obj.id)}
                  className={`p-2.5 rounded-xl flex items-center justify-between transition-all cursor-pointer text-xs ${
                    selectedObjectId === obj.id
                      ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold"
                      : "bg-zinc-900/80 hover:bg-zinc-800 text-zinc-300"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Box size={14} className={selectedObjectId === obj.id ? "text-cyan-400" : "text-zinc-500"} />
                    <span>{obj.name}</span>
                  </div>
                  <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-black/60 text-zinc-400">
                    {obj.type}
                  </span>
                </div>
              ))}
            </div>

            {/* Selected Object Property Inspector */}
            {(() => {
              const selectedObj = sceneObjects.find(obj => obj.id === selectedObjectId);
              if (!selectedObj) return null;
              return (
                <div className="mt-3 pt-3 border-t border-white/10 space-y-2.5 shrink-0 overflow-y-auto max-h-[38vh] pr-1 custom-scrollbar">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono text-cyan-400 uppercase font-bold">Property Inspector:</span>
                    <button
                      onClick={() => {
                        if (selectedObjectId === 'player_vehicle' || selectedObjectId === 'ground_grid' || selectedObjectId === 'sun_light' || selectedObjectId === 'particle_field') {
                          setExportedToast("Cannot delete system-critical objects.");
                          return;
                        }
                        setSceneObjects(prev => prev.filter(o => o.id !== selectedObjectId));
                        setSelectedObjectId('player_vehicle');
                        setExportedToast("Object removed from scene.");
                      }}
                      className="text-[10px] bg-red-950 hover:bg-red-900 border border-red-500/30 text-red-400 px-2 py-0.5 rounded flex items-center gap-1 transition-all cursor-pointer"
                    >
                      <Trash2 size={10} />
                      <span>Delete</span>
                    </button>
                  </div>

                  <div className="space-y-1 bg-black/40 p-2.5 rounded-xl border border-white/5">
                    <div className="text-[11px] font-bold text-white flex justify-between">
                      <span>Name:</span>
                      <input
                        type="text"
                        value={selectedObj.name}
                        onChange={(e) => updateSelectedObject({ name: e.target.value })}
                        className="bg-transparent text-right outline-none text-cyan-300 font-sans border-b border-transparent focus:border-cyan-500/50 w-32"
                      />
                    </div>
                    <div className="text-[10px] text-zinc-500 font-mono flex justify-between">
                      <span>ID:</span>
                      <span>{selectedObj.id}</span>
                    </div>
                  </div>

                  {/* Transform Fields */}
                  <div className="space-y-2 bg-black/40 p-2.5 rounded-xl border border-white/5">
                    <span className="text-[9px] font-mono text-zinc-400 uppercase block font-bold">Transform (XYZ Vectors)</span>
                    
                    {/* Position */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] text-zinc-300">
                        <span>Position Y (Height)</span>
                        <span className="font-mono text-cyan-400">{selectedObj.position[1].toFixed(2)}</span>
                      </div>
                      <input
                        type="range"
                        min="-5"
                        max="20"
                        step="0.1"
                        value={selectedObj.position[1]}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          updateSelectedObject({ position: [selectedObj.position[0], val, selectedObj.position[2]] });
                        }}
                        className="w-full h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                      />
                    </div>

                    {/* Horizontal Coordinates (X and Z) */}
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <div className="flex justify-between text-[9px] text-zinc-400">
                          <span>Position X</span>
                          <span className="font-mono text-cyan-400">{selectedObj.position[0].toFixed(1)}</span>
                        </div>
                        <input
                          type="range"
                          min="-20"
                          max="20"
                          step="0.2"
                          value={selectedObj.position[0]}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value);
                            updateSelectedObject({ position: [val, selectedObj.position[1], selectedObj.position[2]] });
                          }}
                          className="w-full h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="flex justify-between text-[9px] text-zinc-400">
                          <span>Position Z</span>
                          <span className="font-mono text-cyan-400">{selectedObj.position[2].toFixed(1)}</span>
                        </div>
                        <input
                          type="range"
                          min="-20"
                          max="20"
                          step="0.2"
                          value={selectedObj.position[2]}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value);
                            updateSelectedObject({ position: [selectedObj.position[0], selectedObj.position[1], val] });
                          }}
                          className="w-full h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                        />
                      </div>
                    </div>

                    {/* Rotation Y */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] text-zinc-300">
                        <span>Rotation Y (Yaw)</span>
                        <span className="font-mono text-cyan-400">{selectedObj.rotation[1].toFixed(2)} rad</span>
                      </div>
                      <input
                        type="range"
                        min={-Math.PI}
                        max={Math.PI}
                        step="0.05"
                        value={selectedObj.rotation[1]}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          updateSelectedObject({ rotation: [selectedObj.rotation[0], val, selectedObj.rotation[2]] });
                        }}
                        className="w-full h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                      />
                    </div>

                    {/* Scale */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[10px] text-zinc-300">
                        <span>Scale Factor</span>
                        <span className="font-mono text-cyan-400">{selectedObj.scale[0].toFixed(2)}x</span>
                      </div>
                      <input
                        type="range"
                        min="0.1"
                        max="5"
                        step="0.05"
                        value={selectedObj.scale[0]}
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          updateSelectedObject({ scale: [val, val, val] });
                        }}
                        className="w-full h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                      />
                    </div>
                  </div>

                  {/* Material Editor */}
                  <div className="space-y-2 bg-black/40 p-2.5 rounded-xl border border-white/5">
                    <span className="text-[9px] font-mono text-zinc-400 uppercase block font-bold">Material & Shader Preset</span>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1 text-[10px] text-zinc-300">
                        <Palette size={12} className="text-zinc-400" />
                        <span>Albedo Color</span>
                      </div>
                      <div className="flex items-center gap-1">
                        {['#f97316', '#06b6d4', '#a855f7', '#10b981', '#f59e0b', '#ef4444', '#ffffff', '#18181b'].map(c => (
                          <button
                            key={c}
                            onClick={() => updateSelectedObject({ color: c })}
                            className={`w-3.5 h-3.5 rounded-full border border-white/20 transition-all cursor-pointer ${selectedObj.color === c ? 'ring-2 ring-cyan-400 scale-110' : ''}`}
                            style={{ backgroundColor: c }}
                          />
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-zinc-300 pt-1">
                      <span>Wireframe Render Mode</span>
                      <input
                        type="checkbox"
                        checked={selectedObj.wireframe}
                        onChange={(e) => updateSelectedObject({ wireframe: e.target.checked })}
                        className="cursor-pointer accent-cyan-400 rounded bg-zinc-800 border-white/10"
                      />
                    </div>
                  </div>

                  {/* Entity Component System (ECS) Extensions */}
                  <div className="space-y-1.5 bg-black/40 p-2.5 rounded-xl border border-white/5">
                    <span className="text-[9px] font-mono text-zinc-400 uppercase block font-bold flex items-center gap-1">
                      <Cpu size={11} />
                      <span>ECS Components Attached</span>
                    </span>
                    
                    <div className="flex items-center justify-between p-1.5 bg-zinc-950/60 rounded border border-white/5 text-[10px]">
                      <span className="text-emerald-400 font-mono">TransformSystem.ts</span>
                      <span className="text-[9px] text-zinc-500 uppercase">System Active</span>
                    </div>

                    <div className="flex items-center justify-between p-1.5 bg-zinc-950/60 rounded border border-white/5 text-[10px]">
                      <span className="text-cyan-400 font-mono">RenderSystem.ts</span>
                      <span className="text-[9px] text-zinc-500 uppercase">Active</span>
                    </div>

                    <div className="flex items-center justify-between p-1.5 bg-zinc-950/60 rounded border border-white/5 text-[10px]">
                      <span className="text-purple-400 font-mono">DynamicGravity.ts</span>
                      <button
                        onClick={() => {
                          if (selectedObj.position[1] > 1) {
                            updateSelectedObject({ position: [selectedObj.position[0], 1, selectedObj.position[2]] });
                            setExportedToast("RigidBody physics simulation completed!");
                          } else {
                            updateSelectedObject({ position: [selectedObj.position[0], 6, selectedObj.position[2]] });
                            setExportedToast("Simulating gravity: Object lifted!");
                          }
                        }}
                        className="px-1.5 py-0.5 bg-cyan-950 hover:bg-cyan-900 border border-cyan-500/30 text-cyan-300 text-[8px] font-mono rounded transition-all cursor-pointer"
                      >
                        Trigger Fall
                      </button>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        )}
      </div>

      {/* NEW FILE MODAL */}
      {showNewFileModal && (
        <div className="absolute inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-zinc-950 border border-orange-500/40 rounded-3xl p-5 max-w-md w-full shadow-2xl text-white">
            <h3 className="text-sm font-black uppercase tracking-wider flex items-center gap-2 mb-3">
              <FilePlus size={16} className="text-orange-400" />
              <span>Create New File in Engine</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-[10px] font-mono text-zinc-400 uppercase font-bold block mb-1">File Name:</label>
                <input
                  type="text"
                  value={newFileName}
                  onChange={(e) => setNewFileName(e.target.value)}
                  className="w-full bg-black/60 border border-zinc-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-orange-500 font-mono"
                />
              </div>
            </div>

            <div className="mt-5 flex gap-2">
              <button
                onClick={() => setShowNewFileModal(false)}
                className="flex-1 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-bold rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateNewFile}
                className="flex-1 py-2 bg-orange-500 hover:bg-orange-400 text-black text-xs font-black uppercase rounded-xl shadow-lg"
              >
                Create File
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MULTI-FORMAT GAME EXPORTER MODAL */}
      {showExportModal && (
        <div className="absolute inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-zinc-950 border border-emerald-500/40 rounded-3xl p-6 max-w-lg w-full shadow-2xl text-white space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <Download size={20} className="text-emerald-400" />
                <div>
                  <h3 className="text-sm font-black uppercase tracking-wider">EXPORT 3D GAME BUNDLE</h3>
                  <p className="text-[11px] text-zinc-400">Export as WebGL HTML5, React Component, or JSON Level</p>
                </div>
              </div>
              <button onClick={() => setShowExportModal(false)} className="p-1 text-zinc-400 hover:text-white">
                <X size={18} />
              </button>
            </div>

            <div className="grid grid-cols-3 gap-2 text-xs font-bold">
              {[
                { id: "html", label: "🌐 Standalone HTML5", desc: "Single-file WebGL" },
                { id: "r3f", label: "⚛️ React Babylon.js", desc: "<GameScene /> TSX" },
                { id: "json", label: "📄 Level Data JSON", desc: "Scene transforms" }
              ].map(fmt => (
                <button
                  key={fmt.id}
                  onClick={() => setExportFormat(fmt.id as any)}
                  className={`p-3 rounded-2xl text-left border transition-all cursor-pointer ${
                    exportFormat === fmt.id
                      ? "bg-emerald-500/20 border-emerald-500 text-emerald-300 font-black"
                      : "bg-zinc-900 border-white/10 text-zinc-400 hover:bg-zinc-800"
                  }`}
                >
                  <div className="text-xs font-bold">{fmt.label}</div>
                  <div className="text-[9px] text-zinc-500 font-mono mt-0.5">{fmt.desc}</div>
                </button>
              ))}
            </div>

            <div className="pt-3 flex gap-2">
              <button
                onClick={() => setShowExportModal(false)}
                className="flex-1 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-bold rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  handleExportGameBundle(exportFormat);
                  setShowExportModal(false);
                }}
                className="flex-1 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-black text-xs font-black uppercase rounded-xl shadow-lg cursor-pointer"
              >
                Export to Workspace
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 3D MAP & LEVEL DESIGNER OVERLAY MODAL */}
      {showMapDesigner && (
        <div className="absolute inset-0 bg-black/90 backdrop-blur-xl z-50 flex flex-col">
          <MapDesigner
            initialMapData={currentMapData}
            onUpdateMap={(newMap) => {
              setCurrentMapData(newMap);
              if (onSaveToWorkspace) {
                onSaveToWorkspace("mapData.json", JSON.stringify(newMap, null, 2));
              }
            }}
            onClose={() => setShowMapDesigner(false)}
          />
        </div>
      )}

      {/* Live Toast Notification */}
      {exportedToast && (
        <div className="absolute bottom-16 left-1/2 -translate-x-1/2 bg-orange-500 text-black px-4 py-2 rounded-full font-black text-xs uppercase tracking-wider shadow-2xl flex items-center gap-2 z-50 animate-bounce">
          <Check size={14} />
          <span>{exportedToast}</span>
        </div>
      )}
      {/* 1,500 PARALLEL COMPUTATION THREAD SWARM TELEMETRY */}
      {show1000SwarmDashboard && (
        <div className="absolute top-14 right-4 z-40 w-[620px] max-w-[95vw] bg-zinc-950/98 border border-zinc-800 rounded-3xl p-5 shadow-2xl backdrop-blur-2xl flex flex-col max-h-[85vh] text-white">
          <div className="flex items-center justify-between pb-3 border-b border-white/10 shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-zinc-900 border border-zinc-800 rounded-xl">
                <Activity size={18} className="text-orange-500 animate-pulse" />
              </div>
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider flex items-center gap-2">
                  <span>PARALLEL PERFORMANCE MONITOR</span>
                  <span className="px-2 py-0.5 text-[9px] bg-zinc-900 text-zinc-300 border border-zinc-800 rounded-full font-mono">15 CLUSTERS • 1500 THREADS</span>
                </h3>
                <p className="text-[10px] text-zinc-500">Autonomous parallel asset routing, shader compilations & scene calculations</p>
              </div>
            </div>
            <button onClick={() => setShow1000SwarmDashboard(false)} className="p-1 text-zinc-400 hover:text-white">
              <X size={18} />
            </button>
          </div>

          {/* Telemetry Metrics Grid */}
          <div className="grid grid-cols-4 gap-2 my-3 shrink-0">
            <div className="bg-black/60 p-2.5 rounded-2xl border border-zinc-800">
              <div className="text-[9px] font-mono text-zinc-500 uppercase">Active Threads</div>
              <div className="text-base font-black text-orange-400">{swarmTelemetry.totalActiveAgents} / 1500</div>
              <div className="text-[9px] text-emerald-400 font-mono">100% Operational</div>
            </div>
            <div className="bg-black/60 p-2.5 rounded-2xl border border-zinc-800">
              <div className="text-[9px] font-mono text-zinc-500 uppercase">Ops / sec</div>
              <div className="text-base font-black text-white">{(swarmTelemetry.globalOpsPerSec / 1000000).toFixed(1)}M</div>
              <div className="text-[9px] text-zinc-400 font-mono">Parallel Pipeline</div>
            </div>
            <div className="bg-black/60 p-2.5 rounded-2xl border border-zinc-800">
              <div className="text-[9px] font-mono text-zinc-500 uppercase">GPU / Memory</div>
              <div className="text-base font-black text-white">{swarmTelemetry.gpuUtilizationPercentage}% • {swarmTelemetry.memoryUsageMb}MB</div>
              <div className="text-[9px] text-zinc-400 font-mono">TypedArrays Cache</div>
            </div>
            <div className="bg-black/60 p-2.5 rounded-2xl border border-zinc-800">
              <div className="text-[9px] font-mono text-zinc-500 uppercase">Latency</div>
              <div className="text-base font-black text-white">{swarmTelemetry.avgFrameLatencyMs.toFixed(2)} ms</div>
              <div className="text-[9px] text-zinc-400 font-mono">Sub-Millisecond</div>
            </div>
          </div>

          {/* Cluster Filter Buttons */}
          <div className="flex items-center gap-1 overflow-x-auto custom-scrollbar py-1 shrink-0">
            <button
              onClick={() => setSelectedSwarmClusterId(0)}
              className={`px-3 py-1 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer ${
                selectedSwarmClusterId === 0
                  ? "bg-orange-500 text-black font-black shadow"
                  : "bg-zinc-900 text-zinc-400 hover:text-white"
              }`}
            >
              All 1,500 Threads
            </button>
            {SWARM_CLUSTERS.map(cluster => (
              <button
                key={cluster.id}
                onClick={() => setSelectedSwarmClusterId(cluster.id)}
                className={`px-2.5 py-1 rounded-xl text-[11px] font-bold shrink-0 transition-all cursor-pointer flex items-center gap-1 ${
                  selectedSwarmClusterId === cluster.id
                    ? "bg-zinc-800 text-white font-black border border-zinc-700 shadow"
                    : "bg-zinc-900 text-zinc-400 hover:text-white"
                }`}
              >
                <span>{cluster.icon}</span>
                <span>C{cluster.id}</span>
              </button>
            ))}
          </div>

          {/* Clusters List */}
          <div className="flex-1 overflow-y-auto custom-scrollbar my-2 space-y-2 pr-1">
            {SWARM_CLUSTERS.filter(c => selectedSwarmClusterId === 0 || selectedSwarmClusterId === c.id).map(cluster => (
              <div key={cluster.id} className="p-3 rounded-2xl bg-zinc-900/90 border border-zinc-800 space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2 font-black text-white">
                    <span className="text-base">{cluster.icon}</span>
                    <span>Cluster #{cluster.id}: {cluster.name}</span>
                  </div>
                  <span className="px-2 py-0.5 bg-zinc-800 text-zinc-300 font-mono text-[10px] rounded-full border border-zinc-700">
                    Threads {cluster.agentRange[0]} - {cluster.agentRange[1]}
                  </span>
                </div>
                <p className="text-[11px] text-zinc-400">{cluster.description}</p>
                <div className="flex items-center gap-2 text-[10px] font-mono text-zinc-300">
                  <div className="flex-1 bg-black/60 h-2 rounded-full overflow-hidden border border-zinc-800">
                    <div className="bg-gradient-to-r from-orange-500 to-amber-500 h-full rounded-full" style={{ width: `${cluster.clusterWorkload}%` }} />
                  </div>
                  <span>{cluster.clusterWorkload}% Load</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* REAL-TIME DYNAMIC GRAPHICS ADJUSTER CONTROL PANEL */}
      {showGraphicsSettings && (
        <div className="absolute top-14 right-4 z-40 w-[480px] max-w-[95vw] bg-zinc-950/98 border border-amber-500/50 rounded-3xl p-5 shadow-2xl backdrop-blur-2xl flex flex-col max-h-[85vh] text-white">
          <div className="flex items-center justify-between pb-3 border-b border-white/10 shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-amber-500/20 border border-amber-500/40 rounded-xl">
                <SlidersHorizontal size={20} className="text-amber-400" />
              </div>
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider">REAL-TIME GRAPHICS ADJUSTER</h3>
                <p className="text-[10px] text-zinc-400">Dynamic Render Resolution, SSAO, Anti-Aliasing & Shadows</p>
              </div>
            </div>
            <button onClick={() => setShowGraphicsSettings(false)} className="p-1 text-zinc-400 hover:text-white">
              <X size={18} />
            </button>
          </div>

          {/* Preset Buttons */}
          <div className="my-3 shrink-0 space-y-1">
            <label className="text-[10px] font-mono text-amber-400 uppercase font-bold block">Quick Presets:</label>
            <div className="grid grid-cols-3 gap-1.5 text-xs font-bold">
              <button
                onClick={() => setGraphicsSettings({
                  renderScale: 0.75,
                  shadowResolution: 1024,
                  antiAliasing: "FXAA",
                  fpsTarget: 120,
                  bloomStrength: 0.4,
                  particleLimit: 2000,
                  drawDistance: 500,
                  ambientOcclusion: false,
                  volumetricFog: false,
                  postProcessing: false,
                  textureFiltering: "Low (2x)"
                })}
                className="p-2 rounded-xl bg-zinc-900 hover:bg-amber-500 hover:text-black border border-white/10 transition-all text-center"
              >
                ⚡ Ultra Performance
              </button>
              <button
                onClick={() => setGraphicsSettings({
                  renderScale: 1.0,
                  shadowResolution: 2048,
                  antiAliasing: "SMAA",
                  fpsTarget: 60,
                  bloomStrength: 0.8,
                  particleLimit: 5000,
                  drawDistance: 800,
                  ambientOcclusion: true,
                  volumetricFog: true,
                  postProcessing: true,
                  textureFiltering: "High (8x)"
                })}
                className="p-2 rounded-xl bg-zinc-900 hover:bg-amber-500 hover:text-black border border-white/10 transition-all text-center"
              >
                🎮 Balanced 60 FPS
              </button>
              <button
                onClick={() => setGraphicsSettings({
                  renderScale: 1.5,
                  shadowResolution: 4096,
                  antiAliasing: "MSAA",
                  fpsTarget: 0,
                  bloomStrength: 1.4,
                  particleLimit: 20000,
                  drawDistance: 2000,
                  ambientOcclusion: true,
                  volumetricFog: true,
                  postProcessing: true,
                  textureFiltering: "Ultra (16x)"
                })}
                className="p-2 rounded-xl bg-zinc-900 hover:bg-amber-500 hover:text-black border border-white/10 transition-all text-center"
              >
                🔥 Photorealistic 4K
              </button>
            </div>
          </div>

          {/* Granular Sliders & Controls */}
          <div className="flex-1 overflow-y-auto custom-scrollbar my-2 space-y-3 pr-1 text-xs">
            {/* Render Scale */}
            <div className="bg-black/60 p-3 rounded-2xl border border-white/10 space-y-1">
              <div className="flex justify-between font-bold">
                <span>Render Resolution Scale (Supersampling):</span>
                <span className="text-amber-400 font-mono">{graphicsSettings.renderScale}x ({Math.round(graphicsSettings.renderScale * 100)}%)</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="2.0"
                step="0.25"
                value={graphicsSettings.renderScale}
                onChange={(e) => setGraphicsSettings(s => ({ ...s, renderScale: parseFloat(e.target.value) }))}
                className="w-full accent-amber-500 cursor-pointer"
              />
            </div>

            {/* Shadow Map Resolution */}
            <div className="bg-black/60 p-3 rounded-2xl border border-white/10 space-y-1">
              <div className="flex justify-between font-bold">
                <span>Shadow Resolution Map:</span>
                <span className="text-amber-400 font-mono">{graphicsSettings.shadowResolution}px</span>
              </div>
              <div className="grid grid-cols-4 gap-1">
                {[512, 1024, 2048, 4096].map(res => (
                  <button
                    key={res}
                    onClick={() => setGraphicsSettings(s => ({ ...s, shadowResolution: res }))}
                    className={`p-1.5 rounded-lg text-center font-mono font-bold ${
                      graphicsSettings.shadowResolution === res ? "bg-amber-500 text-black" : "bg-zinc-800 text-zinc-300"
                    }`}
                  >
                    {res}px
                  </button>
                ))}
              </div>
            </div>

            {/* Anti-Aliasing */}
            <div className="bg-black/60 p-3 rounded-2xl border border-white/10 space-y-1">
              <div className="flex justify-between font-bold">
                <span>Anti-Aliasing Algorithm:</span>
                <span className="text-amber-400 font-mono">{graphicsSettings.antiAliasing}</span>
              </div>
              <div className="grid grid-cols-4 gap-1">
                {(["None", "FXAA", "SMAA", "MSAA"] as const).map(aa => (
                  <button
                    key={aa}
                    onClick={() => setGraphicsSettings(s => ({ ...s, antiAliasing: aa }))}
                    className={`p-1.5 rounded-lg text-center font-bold ${
                      graphicsSettings.antiAliasing === aa ? "bg-amber-500 text-black" : "bg-zinc-800 text-zinc-300"
                    }`}
                  >
                    {aa}
                  </button>
                ))}
              </div>
            </div>

            {/* Toggles */}
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setGraphicsSettings(s => ({ ...s, ambientOcclusion: !s.ambientOcclusion }))}
                className={`p-2.5 rounded-xl border flex items-center justify-between font-bold ${
                  graphicsSettings.ambientOcclusion ? "bg-amber-500/20 border-amber-500 text-amber-300" : "bg-black/60 border-white/10 text-zinc-400"
                }`}
              >
                <span>SSAO Ambient Occlusion</span>
                <span>{graphicsSettings.ambientOcclusion ? "ON" : "OFF"}</span>
              </button>

              <button
                onClick={() => setGraphicsSettings(s => ({ ...s, volumetricFog: !s.volumetricFog }))}
                className={`p-2.5 rounded-xl border flex items-center justify-between font-bold ${
                  graphicsSettings.volumetricFog ? "bg-amber-500/20 border-amber-500 text-amber-300" : "bg-black/60 border-white/10 text-zinc-400"
                }`}
              >
                <span>Volumetric Fog Rays</span>
                <span>{graphicsSettings.volumetricFog ? "ON" : "OFF"}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* INTERNET PUBLIC 3D ASSETS MARKETPLACE & IMPORTER */}
      {showPublicAssetImporter && (
        <div className="absolute top-14 right-4 z-40 w-[540px] max-w-[95vw] bg-zinc-950/98 border border-purple-500/50 rounded-3xl p-5 shadow-2xl backdrop-blur-2xl flex flex-col max-h-[85vh] text-white">
          <div className="flex items-center justify-between pb-3 border-b border-white/10 shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-purple-500/20 border border-purple-500/40 rounded-xl">
                <Globe size={20} className="text-purple-400" />
              </div>
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider">INTERNET PUBLIC 3D ASSET IMPORTER</h3>
                <p className="text-[10px] text-zinc-400">Search & Load Open-Source GLTF Models, PBR Textures & SFX</p>
              </div>
            </div>
            <button onClick={() => setShowPublicAssetImporter(false)} className="p-1 text-zinc-400 hover:text-white">
              <X size={18} />
            </button>
          </div>

          {/* Search Bar & Category Filter */}
          <div className="my-3 shrink-0 space-y-2">
            <div className="relative">
              <Search size={14} className="absolute left-3 top-2.5 text-zinc-400" />
              <input
                type="text"
                placeholder="Search public 3D models (e.g. helmet, fox, duck, car, boombox)..."
                value={assetSearchQuery}
                onChange={(e) => setAssetSearchQuery(e.target.value)}
                className="w-full bg-black/70 border border-purple-500/40 rounded-xl pl-9 pr-3 py-2 text-xs text-white outline-none focus:border-purple-400"
              />
            </div>
            <div className="flex items-center gap-1 overflow-x-auto custom-scrollbar py-0.5">
              {['all', 'character', 'vehicle', 'prop', 'texture'].map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedAssetCategory(cat)}
                  className={`px-2.5 py-1 rounded-xl text-[10px] font-bold uppercase shrink-0 cursor-pointer ${
                    selectedAssetCategory === cat
                      ? "bg-purple-500 text-white font-black shadow"
                      : "bg-zinc-900 text-zinc-400 hover:text-white"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Public Asset Cards Grid */}
          <div className="flex-1 overflow-y-auto custom-scrollbar my-2 grid grid-cols-2 gap-2 pr-1">
            {CURATED_PUBLIC_ASSETS.filter(a => {
              const matchesCat = selectedAssetCategory === 'all' || a.category === selectedAssetCategory;
              const matchesQ = !assetSearchQuery || a.name.toLowerCase().includes(assetSearchQuery.toLowerCase());
              return matchesCat && matchesQ;
            }).map(asset => (
              <div key={asset.id} className="p-2.5 rounded-2xl bg-zinc-900/90 border border-white/10 flex flex-col justify-between space-y-2 group hover:border-purple-500/50 transition-all">
                <div className="space-y-1">
                  <div className="h-24 bg-black/60 rounded-xl overflow-hidden relative">
                    <img src={asset.previewImage} alt={asset.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                    <span className="absolute top-1 right-1 px-1.5 py-0.5 bg-black/80 text-[8px] font-mono text-purple-300 rounded uppercase">
                      {asset.format}
                    </span>
                  </div>
                  <div className="text-xs font-bold text-white truncate">{asset.name}</div>
                  <div className="text-[9px] text-zinc-400 font-mono">{asset.license} • {(asset.filesizeKb / 1024).toFixed(1)} MB</div>
                </div>
                <button
                  onClick={() => {
                    const code = generateAssetImportThreeCode(asset);
                    setEditorCode(prev => prev + "\n\n" + code);
                    saveCodeToWorkspace(targetFileName, editorCode + "\n\n" + code);
                    setExportedToast(`Loaded public 3D asset "${asset.name}" into scene code!`);
                  }}
                  className="w-full py-1.5 bg-purple-600 hover:bg-purple-500 text-white text-[10px] font-black uppercase rounded-xl flex items-center justify-center gap-1 shadow transition-all cursor-pointer"
                >
                  <Download size={11} />
                  <span>Load Into Scene</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* LOW-LEVEL GLSL SHADER & TYPEDARRAY STUDIO */}
      {showLowLevelShaderStudio && (
        <div className="absolute top-14 right-4 z-40 w-[580px] max-w-[95vw] bg-zinc-950/98 border border-cyan-500/50 rounded-3xl p-5 shadow-2xl backdrop-blur-2xl flex flex-col max-h-[85vh] text-white">
          <div className="flex items-center justify-between pb-3 border-b border-white/10 shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-cyan-500/20 border border-cyan-500/40 rounded-xl">
                <Binary size={20} className="text-cyan-400" />
              </div>
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider">LOW-LEVEL GLSL SHADER & TYPEDARRAY STUDIO</h3>
                <p className="text-[10px] text-zinc-400">Vertex/Fragment Shaders, Float32Array Buffers & Web Audio DSP</p>
              </div>
            </div>
            <button onClick={() => setShowLowLevelShaderStudio(false)} className="p-1 text-zinc-400 hover:text-white">
              <X size={18} />
            </button>
          </div>

          {/* Shader Preset Selector */}
          <div className="my-3 shrink-0 space-y-1">
            <label className="text-[10px] font-mono text-cyan-400 uppercase font-bold block">GLSL Shader Preset:</label>
            <div className="grid grid-cols-3 gap-1.5 text-xs font-bold">
              {Object.entries(PRESET_GLSL_SHADERS).map(([key, shader]) => (
                <button
                  key={key}
                  onClick={() => {
                    setActiveShaderPresetKey(key);
                    setCustomGLSL(shader);
                  }}
                  className={`p-2 rounded-xl text-center border transition-all cursor-pointer ${
                    activeShaderPresetKey === key
                      ? "bg-cyan-500 text-black font-black border-cyan-400 shadow"
                      : "bg-zinc-900 border-white/10 text-zinc-300 hover:bg-zinc-800"
                  }`}
                >
                  {shader.name.split(' ')[0]} {shader.name.split(' ')[1]}
                </button>
              ))}
            </div>
          </div>

          {/* Low-Level GLSL Code Preview */}
          <div className="flex-1 overflow-y-auto custom-scrollbar my-2 space-y-2 pr-1 font-mono text-[11px]">
            <div className="bg-black/80 p-3 rounded-2xl border border-white/10 space-y-1">
              <div className="text-[9px] text-cyan-400 uppercase font-bold">Vertex GLSL Shader Program:</div>
              <pre className="text-emerald-400 overflow-x-auto p-2 bg-black/60 rounded-xl leading-relaxed">{customGLSL.vertexShader.trim()}</pre>
            </div>
            <div className="bg-black/80 p-3 rounded-2xl border border-white/10 space-y-1">
              <div className="text-[9px] text-cyan-400 uppercase font-bold">Fragment GLSL Shader Program:</div>
              <pre className="text-cyan-300 overflow-x-auto p-2 bg-black/60 rounded-xl leading-relaxed">{customGLSL.fragmentShader.trim()}</pre>
            </div>

            {/* Web Audio DSP Tester */}
            <div className="bg-black/80 p-3 rounded-2xl border border-white/10 space-y-2">
              <div className="text-[9px] text-cyan-400 uppercase font-bold">Low-Level Web Audio API DSP Tester:</div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => playProceduralSFX('laser')}
                  className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-black font-black rounded-xl text-xs cursor-pointer"
                >
                  🔊 Laser Pulse
                </button>
                <button
                  onClick={() => playProceduralSFX('explosion')}
                  className="px-3 py-1.5 bg-orange-600 hover:bg-orange-500 text-black font-black rounded-xl text-xs cursor-pointer"
                >
                  💥 Noise Explosion
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* INBUILT BLENDER 3D MODELER STUDIO */}
      {showBlenderModeler && (
        <div className="absolute top-14 right-4 z-40 w-[600px] max-w-[95vw] bg-zinc-950/98 border border-orange-500/50 rounded-3xl p-5 shadow-2xl backdrop-blur-2xl flex flex-col max-h-[85vh] text-white">
          <div className="flex items-center justify-between pb-3 border-b border-white/10 shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-orange-500/20 border border-orange-500/40 rounded-xl">
                <Boxes size={20} className="text-orange-400" />
              </div>
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider text-orange-400">AETHER 3D MODELING WORKSTATION</h3>
                <p className="text-[10px] text-zinc-500">Extrusion, Subdivision, Vertex Matrices & Procedural Mesh Synthesizer</p>
              </div>
            </div>
            <button onClick={() => setShowBlenderModeler(false)} className="p-1 text-zinc-400 hover:text-white cursor-pointer">
              <X size={18} />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar my-2 space-y-4 pr-1 text-xs">
            {/* Model Name, Color & Edit Mode */}
            <div className="grid grid-cols-2 gap-3 bg-zinc-900/50 p-3 rounded-2xl border border-white/5">
              <div className="space-y-1">
                <label className="text-[10px] font-mono text-orange-400 uppercase font-black block">Model Asset Name:</label>
                <input
                  type="text"
                  value={blenderModelName}
                  onChange={(e) => setBlenderModelName(e.target.value)}
                  className="w-full bg-black/50 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white outline-none focus:border-orange-500"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-mono text-orange-400 uppercase font-black block">Viewport Mesh Color:</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={blenderModelColor}
                    onChange={(e) => setBlenderModelColor(e.target.value)}
                    className="w-8 h-8 rounded-lg border border-white/10 cursor-pointer bg-transparent"
                  />
                  <input
                    type="text"
                    value={blenderModelColor}
                    onChange={(e) => setBlenderModelColor(e.target.value)}
                    className="flex-1 bg-black/50 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white font-mono outline-none focus:border-orange-500"
                  />
                </div>
              </div>
            </div>

            {/* Blender Mode & Preset Primitives Selector */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono text-orange-400 uppercase font-black">Mode Selection:</span>
                <span className="text-[9px] text-zinc-500 uppercase font-mono">Vertices: {blenderVertices.length / 3} | Indices: {blenderIndices.length}</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => setBlenderEditMode('object')}
                  className={`py-2 rounded-xl text-center font-bold border transition-all cursor-pointer ${
                    blenderEditMode === 'object'
                      ? "bg-orange-500 text-black border-orange-400 font-black shadow"
                      : "bg-zinc-900 border-white/5 text-zinc-400 hover:text-white"
                  }`}
                >
                  🌐 OBJECT MODE (Solid)
                </button>
                <button
                  onClick={() => setBlenderEditMode('vertex')}
                  className={`py-2 rounded-xl text-center font-bold border transition-all cursor-pointer ${
                    blenderEditMode === 'vertex'
                      ? "bg-orange-500 text-black border-orange-400 font-black shadow"
                      : "bg-zinc-900 border-white/5 text-zinc-400 hover:text-white"
                  }`}
                >
                  🕸️ EDIT MODE (Wireframe)
                </button>
              </div>

              {/* Quick primitives */}
              <div className="bg-black/50 p-2.5 rounded-2xl border border-white/5 space-y-1.5">
                <div className="text-[10px] font-mono text-zinc-400 uppercase font-bold">Add Blender Primitives (Resets Model):</div>
                <div className="grid grid-cols-4 gap-1">
                  <button onClick={() => loadBlenderPrimitive('cube')} className="p-1.5 bg-zinc-900 hover:bg-zinc-800 border border-white/5 text-[10px] font-bold rounded-lg cursor-pointer text-center">
                    📦 Cube
                  </button>
                  <button onClick={() => loadBlenderPrimitive('monkey')} className="p-1.5 bg-zinc-900 hover:bg-zinc-800 border border-white/5 text-[10px] font-bold rounded-lg cursor-pointer text-center">
                    🐒 Suzanne
                  </button>
                  <button onClick={() => loadBlenderPrimitive('donut')} className="p-1.5 bg-zinc-900 hover:bg-zinc-800 border border-white/5 text-[10px] font-bold rounded-lg cursor-pointer text-center">
                    🍩 Donut
                  </button>
                  <button onClick={() => loadBlenderPrimitive('icosahedron')} className="p-1.5 bg-zinc-900 hover:bg-zinc-800 border border-white/5 text-[10px] font-bold rounded-lg cursor-pointer text-center">
                    💎 Icosahedron
                  </button>
                </div>
              </div>
            </div>

            {/* Procedural Mesh Compiler */}
            <div className="bg-zinc-900/50 p-4 rounded-2xl border border-zinc-800 space-y-2.5">
              <div className="flex items-center gap-1.5 text-zinc-400 font-mono font-bold text-[10px] uppercase">
                <Box size={12} className="text-orange-500" />
                <span>Procedural Geometry Compiler</span>
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Describe a 3D model to synthesize (e.g. dragon wings, starfighter fuselage)..."
                  value={blenderPrompt}
                  onChange={(e) => setBlenderPrompt(e.target.value)}
                  disabled={blenderIsGenerating}
                  className="flex-1 bg-black border border-zinc-800 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-orange-500"
                />
                <button
                  onClick={handleBlenderAIGenerate}
                  disabled={blenderIsGenerating}
                  className="px-4 py-2 bg-orange-500 hover:bg-orange-400 disabled:bg-zinc-800 text-black font-black uppercase rounded-xl text-xs shrink-0 flex items-center gap-1 cursor-pointer transition-all shadow"
                >
                  {blenderIsGenerating ? (
                    <Loader2 size={13} className="animate-spin text-black" />
                  ) : (
                    <Wand2 size={13} className="text-black" />
                  )}
                  <span>Model Mesh</span>
                </button>
              </div>
              {blenderIsGenerating && (
                <div className="p-2 bg-black/60 border border-orange-500/20 rounded-xl font-mono text-[9px] text-orange-300 animate-pulse">
                  🤖 {blenderStatus}
                </div>
              )}
            </div>

            {/* Vertex Editor Matrix (Only in Edit Mode) */}
            {blenderEditMode === 'vertex' && (
              <div className="space-y-2">
                <span className="text-[10px] font-mono text-orange-400 uppercase font-black">Interactive Vertex Matrix:</span>
                <div className="grid grid-cols-2 gap-3 bg-zinc-900/70 p-3 rounded-2xl border border-white/5">
                  <div className="space-y-1.5">
                    <label className="text-[9px] text-zinc-400 font-mono uppercase font-bold block">Select Vertex Index:</label>
                    <select
                      value={selectedVertexIndex !== null ? selectedVertexIndex : ""}
                      onChange={(e) => setSelectedVertexIndex(e.target.value !== "" ? parseInt(e.target.value) : null)}
                      className="w-full bg-black/80 border border-white/10 rounded-xl px-2.5 py-1.5 text-xs font-mono focus:border-orange-500 outline-none"
                    >
                      {Array.from({ length: blenderVertices.length / 3 }).map((_, idx) => (
                        <option key={idx} value={idx}>
                          Vertex {idx} (x: {blenderVertices[idx*3]}, y: {blenderVertices[idx*3+1]}, z: {blenderVertices[idx*3+2]})
                        </option>
                      ))}
                    </select>
                  </div>

                  {selectedVertexIndex !== null && (
                    <div className="space-y-2">
                      <label className="text-[9px] text-zinc-400 font-mono uppercase font-bold block">Translate Coordinates (X, Y, Z):</label>
                      <div className="space-y-1 text-[11px] font-mono">
                        {/* X Coord */}
                        <div className="flex items-center justify-between bg-black/60 p-1.5 rounded-lg border border-white/5">
                          <span className="text-zinc-500 font-black">X: {blenderVertices[selectedVertexIndex*3]}</span>
                          <div className="flex items-center gap-1 text-[9px]">
                            <button onClick={() => updateVertexCoord(selectedVertexIndex, 0, -0.2)} className="px-1.5 py-0.5 bg-zinc-800 hover:bg-zinc-700 rounded font-black cursor-pointer">-0.2</button>
                            <button onClick={() => updateVertexCoord(selectedVertexIndex, 0, 0.2)} className="px-1.5 py-0.5 bg-zinc-800 hover:bg-zinc-700 rounded font-black cursor-pointer">+0.2</button>
                          </div>
                        </div>
                        {/* Y Coord */}
                        <div className="flex items-center justify-between bg-black/60 p-1.5 rounded-lg border border-white/5">
                          <span className="text-zinc-500 font-black">Y: {blenderVertices[selectedVertexIndex*3+1]}</span>
                          <div className="flex items-center gap-1 text-[9px]">
                            <button onClick={() => updateVertexCoord(selectedVertexIndex, 1, -0.2)} className="px-1.5 py-0.5 bg-zinc-800 hover:bg-zinc-700 rounded font-black cursor-pointer">-0.2</button>
                            <button onClick={() => updateVertexCoord(selectedVertexIndex, 1, 0.2)} className="px-1.5 py-0.5 bg-zinc-800 hover:bg-zinc-700 rounded font-black cursor-pointer">+0.2</button>
                          </div>
                        </div>
                        {/* Z Coord */}
                        <div className="flex items-center justify-between bg-black/60 p-1.5 rounded-lg border border-white/5">
                          <span className="text-zinc-500 font-black">Z: {blenderVertices[selectedVertexIndex*3+2]}</span>
                          <div className="flex items-center gap-1 text-[9px]">
                            <button onClick={() => updateVertexCoord(selectedVertexIndex, 2, -0.2)} className="px-1.5 py-0.5 bg-zinc-800 hover:bg-zinc-700 rounded font-black cursor-pointer">-0.2</button>
                            <button onClick={() => updateVertexCoord(selectedVertexIndex, 2, 0.2)} className="px-1.5 py-0.5 bg-zinc-800 hover:bg-zinc-700 rounded font-black cursor-pointer">+0.2</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Mesh Topology Modifiers */}
            <div className="space-y-1.5">
              <span className="text-[10px] font-mono text-orange-400 uppercase font-black">Topology modifiers & Deformers:</span>
              <div className="grid grid-cols-2 gap-2 text-[10px] font-bold">
                <button
                  onClick={applyBlenderSubdivision}
                  className="p-2.5 bg-zinc-900 hover:bg-zinc-800 border border-white/10 rounded-xl text-left flex items-center justify-between group transition-all cursor-pointer font-bold"
                >
                  <div className="flex flex-col">
                    <span className="text-white">Subdivision Surface</span>
                    <span className="text-[8px] text-zinc-500 font-mono">Split & Smooth geometry</span>
                  </div>
                  <Maximize2 size={12} className="text-orange-400" />
                </button>
                <button
                  onClick={applyBlenderTwist}
                  className="p-2.5 bg-zinc-900 hover:bg-zinc-800 border border-white/10 rounded-xl text-left flex items-center justify-between group transition-all cursor-pointer font-bold"
                >
                  <div className="flex flex-col">
                    <span className="text-white">Twist Deformer</span>
                    <span className="text-[8px] text-zinc-500 font-mono">Rotate vertices along Y</span>
                  </div>
                  <RotateCw size={12} className="text-orange-400" />
                </button>
                <button
                  onClick={applyBlenderNoise}
                  className="p-2.5 bg-zinc-900 hover:bg-zinc-800 border border-white/10 rounded-xl text-left flex items-center justify-between group transition-all cursor-pointer font-bold"
                >
                  <div className="flex flex-col">
                    <span className="text-white">Fractal Sculpt Noise</span>
                    <span className="text-[8px] text-zinc-500 font-mono">Displace vertices organically</span>
                  </div>
                  <Sparkles size={12} className="text-orange-400" />
                </button>
                <button
                  onClick={applyBlenderSpherize}
                  className="p-2.5 bg-zinc-900 hover:bg-zinc-800 border border-white/10 rounded-xl text-left flex items-center justify-between group transition-all cursor-pointer font-bold"
                >
                  <div className="flex flex-col">
                    <span className="text-white">Spherize / Inflate</span>
                    <span className="text-[8px] text-zinc-500 font-mono">Snap vertices to sphere</span>
                  </div>
                  <CircleDot size={12} className="text-orange-400" />
                </button>
              </div>
            </div>

            {/* Save & Export Drawer */}
            <div className="space-y-1.5 pt-1.5 border-t border-white/10 shrink-0">
              <span className="text-[10px] font-mono text-orange-400 uppercase font-black">Export & Workspace Save:</span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={exportBlenderMeshAsOBJ}
                  className="py-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 text-xs font-black uppercase rounded-xl flex items-center justify-center gap-1.5 border border-white/10 shadow transition-all cursor-pointer"
                >
                  <Download size={13} className="text-orange-400" />
                  <span>Download Wavefront .OBJ</span>
                </button>
                <button
                  onClick={injectBlenderMeshToCode}
                  className="py-2 bg-orange-600 hover:bg-orange-500 text-black text-xs font-black uppercase rounded-xl flex items-center justify-center gap-1.5 shadow transition-all cursor-pointer"
                >
                  <Code size={13} className="text-black" />
                  <span>Inject Into Scene Script</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VOLUMETRIC GOD RAYS & ULTRA-REALISTIC ATMOSPHERIC STUDIO */}
      {showVolumetricStudio && (
        <div className="absolute top-14 right-4 z-40 w-[540px] max-w-[95vw] bg-zinc-950/98 border border-yellow-500/50 rounded-3xl p-5 shadow-2xl backdrop-blur-2xl flex flex-col max-h-[85vh] text-white">
          <div className="flex items-center justify-between pb-3 border-b border-white/10 shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-yellow-500/20 border border-yellow-500/40 rounded-xl">
                <SunMedium size={20} className="text-yellow-400" />
              </div>
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider text-yellow-300">VOLUMETRIC GOD RAYS & ATMOSPHERIC STUDIO</h3>
                <p className="text-[10px] text-zinc-400">Raymarching Light Shafts, Dust Motes & ACESFilmic Tone Mapping</p>
              </div>
            </div>
            <button onClick={() => setShowVolumetricStudio(false)} className="p-1 text-zinc-400 hover:text-white cursor-pointer">
              <X size={18} />
            </button>
          </div>

          <div className="overflow-y-auto custom-scrollbar my-3 space-y-4 pr-1 text-xs">
            {/* Master Volumetric Toggle */}
            <div className="flex items-center justify-between p-3.5 bg-yellow-500/10 border border-yellow-500/30 rounded-2xl">
              <div>
                <div className="font-bold text-white text-sm">Volumetric Lighting Pipeline</div>
                <div className="text-[10px] text-zinc-400">Raymarch atmospheric light scatter in real-time</div>
              </div>
              <button
                onClick={() => setVolumetricConfig(v => ({ ...v, enabled: !v.enabled }))}
                className={`px-4 py-1.5 rounded-xl font-mono text-xs font-black uppercase transition-all cursor-pointer ${
                  volumetricConfig.enabled
                    ? "bg-yellow-400 text-black shadow-lg shadow-yellow-500/30"
                    : "bg-zinc-800 text-zinc-400 border border-white/10"
                }`}
              >
                {volumetricConfig.enabled ? "ACTIVE" : "OFF"}
              </button>
            </div>

            {/* Atmospheric Presets */}
            <div className="space-y-1.5">
              <label className="text-[10px] font-mono text-yellow-400 uppercase font-black">Lighting & Atmosphere Presets:</label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { name: "Golden Sunset", color: "#f59e0b", exp: 1.4, len: 100, int: 2.2, motes: 350 },
                  { name: "Cyberpunk Mist", color: "#06b6d4", exp: 1.6, len: 80, int: 2.5, motes: 450 },
                  { name: "Ethereal God Rays", color: "#fef08a", exp: 1.3, len: 120, int: 2.8, motes: 500 },
                  { name: "Moody Overcast", color: "#94a3b8", exp: 1.0, len: 60, int: 1.4, motes: 200 },
                  { name: "Deep Space Nova", color: "#ec4899", exp: 1.8, len: 90, int: 2.6, motes: 600 },
                  { name: "High Noon Daylight", color: "#ffffff", exp: 1.2, len: 70, int: 1.8, motes: 150 }
                ].map((p, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setVolumetricConfig(v => ({
                        ...v,
                        enabled: true,
                        lightShaftColor: p.color,
                        toneMappingExposure: p.exp,
                        lightShaftLength: p.len,
                        lightShaftIntensity: p.int,
                        dustMotesCount: p.motes
                      }));
                      setExportedToast(`Applied ${p.name} Atmospheric Preset!`);
                    }}
                    className="p-2 bg-black/60 hover:bg-zinc-800 border border-white/10 rounded-xl text-left transition-all cursor-pointer font-bold group"
                  >
                    <div className="flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: p.color }} />
                      <span className="text-[11px] text-zinc-200 group-hover:text-yellow-400">{p.name}</span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Light Shaft Intensity */}
            <div className="bg-black/60 p-3 rounded-2xl border border-white/10 space-y-1.5">
              <div className="flex justify-between font-bold">
                <span className="text-zinc-300">Light Shaft Intensity:</span>
                <span className="text-yellow-400 font-mono">{volumetricConfig.lightShaftIntensity.toFixed(2)}x</span>
              </div>
              <input
                type="range"
                min="0.2"
                max="4.0"
                step="0.1"
                value={volumetricConfig.lightShaftIntensity}
                onChange={(e) => setVolumetricConfig(v => ({ ...v, lightShaftIntensity: parseFloat(e.target.value) }))}
                className="w-full accent-yellow-400 cursor-pointer"
              />
            </div>

            {/* Light Shaft Length & Radius */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-black/60 p-3 rounded-2xl border border-white/10 space-y-1.5">
                <div className="flex justify-between font-bold">
                  <span className="text-zinc-300">Shaft Length:</span>
                  <span className="text-yellow-400 font-mono">{volumetricConfig.lightShaftLength}m</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="160"
                  step="5"
                  value={volumetricConfig.lightShaftLength}
                  onChange={(e) => setVolumetricConfig(v => ({ ...v, lightShaftLength: parseInt(e.target.value) }))}
                  className="w-full accent-yellow-400 cursor-pointer"
                />
              </div>
              <div className="bg-black/60 p-3 rounded-2xl border border-white/10 space-y-1.5">
                <div className="flex justify-between font-bold">
                  <span className="text-zinc-300">Cone Radius:</span>
                  <span className="text-yellow-400 font-mono">{volumetricConfig.lightShaftRadius}m</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="60"
                  step="1"
                  value={volumetricConfig.lightShaftRadius}
                  onChange={(e) => setVolumetricConfig(v => ({ ...v, lightShaftRadius: parseInt(e.target.value) }))}
                  className="w-full accent-yellow-400 cursor-pointer"
                />
              </div>
            </div>

            {/* ACESFilmic Tone Mapping Exposure */}
            <div className="bg-black/60 p-3 rounded-2xl border border-white/10 space-y-1.5">
              <div className="flex justify-between font-bold">
                <span className="text-zinc-300">Photorealistic ACESFilmic Exposure:</span>
                <span className="text-yellow-400 font-mono">{volumetricConfig.toneMappingExposure.toFixed(2)} EV</span>
              </div>
              <input
                type="range"
                min="0.4"
                max="2.5"
                step="0.05"
                value={volumetricConfig.toneMappingExposure}
                onChange={(e) => {
                  const val = parseFloat(e.target.value);
                  setVolumetricConfig(v => ({ ...v, toneMappingExposure: val }));
                  if (rendererRef.current) {
                    rendererRef.current.toneMappingExposure = val;
                  }
                }}
                className="w-full accent-yellow-400 cursor-pointer"
              />
            </div>

            {/* Dust Motes Count */}
            <div className="bg-black/60 p-3 rounded-2xl border border-white/10 space-y-1.5">
              <div className="flex justify-between font-bold">
                <span className="text-zinc-300">Atmospheric Dust Motes:</span>
                <span className="text-yellow-400 font-mono">{volumetricConfig.dustMotesCount} particles</span>
              </div>
              <input
                type="range"
                min="0"
                max="1000"
                step="50"
                value={volumetricConfig.dustMotesCount}
                onChange={(e) => setVolumetricConfig(v => ({ ...v, dustMotesCount: parseInt(e.target.value) }))}
                className="w-full accent-yellow-400 cursor-pointer"
              />
            </div>

            {/* Volumetric Light Color Picker */}
            <div className="flex items-center justify-between bg-black/60 p-3 rounded-2xl border border-white/10">
              <span className="font-bold text-zinc-300">Volumetric Shaft Color:</span>
              <div className="flex items-center gap-2 font-mono">
                <input
                  type="color"
                  value={volumetricConfig.lightShaftColor}
                  onChange={(e) => setVolumetricConfig(v => ({ ...v, lightShaftColor: e.target.value }))}
                  className="w-8 h-8 rounded-lg border border-white/20 bg-transparent cursor-pointer"
                />
                <span className="text-yellow-400 uppercase font-black">{volumetricConfig.lightShaftColor}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ULTRA-REALISTIC 4K PBR TEXTURE & MATERIALS STUDIO */}
      {showPBRTextureStudio && (
        <div className="absolute top-14 right-4 z-40 w-[600px] max-w-[95vw] bg-zinc-950/98 border border-emerald-500/50 rounded-3xl p-5 shadow-2xl backdrop-blur-2xl flex flex-col max-h-[88vh] text-white">
          <div className="flex items-center justify-between pb-3 border-b border-white/10 shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-emerald-500/20 border border-emerald-500/40 rounded-xl">
                <Layers size={20} className="text-emerald-400" />
              </div>
              <div>
                <h3 className="text-sm font-black uppercase tracking-wider text-emerald-300">4K PBR TEXTURE & MATERIAL SYNTHESIZER</h3>
                <p className="text-[10px] text-zinc-400">Photorealistic Micro-Facet Normal Maps, Metalness, Roughness & Custom Maps</p>
              </div>
            </div>
            <button onClick={() => setShowPBRTextureStudio(false)} className="p-1 text-zinc-400 hover:text-white cursor-pointer">
              <X size={18} />
            </button>
          </div>

          <div className="overflow-y-auto custom-scrollbar my-3 space-y-4 pr-1 text-xs">
            {/* Status Toast Alert */}
            {pbrTextureStatus && (
              <div className="p-2.5 bg-emerald-950/70 border border-emerald-500/40 rounded-xl font-mono text-[10px] text-emerald-300 flex items-center justify-between">
                <span>✨ {pbrTextureStatus}</span>
                <button onClick={() => setPbrTextureStatus("")} className="text-emerald-400 hover:text-white ml-2">✕</button>
              </div>
            )}

            {/* 8 Photorealistic Material Presets Grid */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-[10px] font-mono text-emerald-400 uppercase font-black">4K Seamless PBR Material Presets:</label>
                <span className="text-[9px] text-zinc-500 font-mono">1-Click Apply to 3D Model</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {Object.values(PBR_MATERIAL_PRESETS).map((preset) => {
                  const isSelected = selectedPBRMaterialKey === preset.id;
                  return (
                    <button
                      key={preset.id}
                      onClick={() => applyPBRMaterialToActiveModel(preset.id)}
                      className={`p-2.5 rounded-2xl border text-left transition-all cursor-pointer flex items-center gap-2.5 ${
                        isSelected
                          ? "bg-emerald-500/20 border-emerald-400 text-white shadow-lg shadow-emerald-500/20"
                          : "bg-black/60 hover:bg-zinc-900 border-white/10 text-zinc-300"
                      }`}
                    >
                      <div
                        className="w-8 h-8 rounded-xl border border-white/20 shrink-0 shadow-inner flex items-center justify-center font-bold text-xs"
                        style={{ backgroundColor: preset.color }}
                      >
                        {preset.id.startsWith("carbon") ? "🏁" : preset.id.startsWith("titanium") ? "🤖" : preset.id.startsWith("wet") ? "🌧️" : "✨"}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-[11px] truncate">{preset.name}</div>
                        <div className="text-[9px] text-zinc-400 truncate font-mono">
                          R: {preset.roughness.toFixed(2)} | M: {preset.metalness.toFixed(2)}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Custom Texture Map Loader */}
            <div className="bg-zinc-900/60 p-3.5 rounded-2xl border border-emerald-500/30 space-y-2.5">
              <div className="flex items-center justify-between font-mono font-bold text-[10px] uppercase text-emerald-400">
                <span className="flex items-center gap-1.5">
                  <ImageIcon size={13} />
                  <span>Custom Texture Map Channel Loader</span>
                </span>
                <span className="text-zinc-500">PNG / JPG / WebP</span>
              </div>

              {/* Texture Channel Selector */}
              <div className="grid grid-cols-5 gap-1 font-mono text-[9px] font-bold">
                {[
                  { key: 'albedo', label: 'Albedo (Color)' },
                  { key: 'normal', label: 'Normal (Bump)' },
                  { key: 'roughness', label: 'Roughness' },
                  { key: 'metalness', label: 'Metalness' },
                  { key: 'emissive', label: 'Emissive' }
                ].map((channel) => (
                  <button
                    key={channel.key}
                    onClick={() => setCustomPBRTextureType(channel.key as any)}
                    className={`p-1.5 rounded-lg text-center truncate cursor-pointer uppercase ${
                      customPBRTextureType === channel.key
                        ? "bg-emerald-500 text-black font-black"
                        : "bg-black/70 text-zinc-400 hover:text-white"
                    }`}
                  >
                    {channel.label}
                  </button>
                ))}
              </div>

              {/* URL Map Input */}
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder={`Paste image URL for ${customPBRTextureType.toUpperCase()} map...`}
                  value={customPBRTextureURL}
                  onChange={(e) => setCustomPBRTextureURL(e.target.value)}
                  className="flex-1 bg-black border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-emerald-400 font-mono"
                />
                <button
                  onClick={handleApplyCustomURLTexture}
                  className="px-3.5 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-black uppercase text-xs rounded-xl flex items-center gap-1 cursor-pointer transition-all shrink-0"
                >
                  <Sparkle size={12} className="text-black" />
                  <span>Apply Map</span>
                </button>
              </div>

              {/* Local File Upload Button */}
              <div className="flex items-center justify-between pt-1">
                <label className="flex items-center gap-1.5 px-3 py-1.5 bg-black/60 hover:bg-zinc-800 border border-white/10 rounded-xl text-zinc-300 text-[11px] font-bold cursor-pointer transition-all">
                  <Upload size={12} className="text-emerald-400" />
                  <span>Upload Local Texture File</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUploadTexture}
                    className="hidden"
                  />
                </label>
                <span className="text-[9px] font-mono text-zinc-500">Auto-applies with anisotropic filtering</span>
              </div>
            </div>

            {/* PBR Material Fine Tuning Sliders */}
            <div className="space-y-2 pt-1">
              <label className="text-[10px] font-mono text-emerald-400 uppercase font-black">Micro-Surface & PBR Tuning:</label>
              
              <div className="grid grid-cols-2 gap-2.5">
                <div className="bg-black/60 p-2.5 rounded-xl border border-white/10 space-y-1">
                  <div className="flex justify-between font-bold text-[11px]">
                    <span className="text-zinc-400">Normal Map Strength:</span>
                    <span className="text-emerald-400 font-mono">{pbrNormalScale.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.0"
                    max="4.0"
                    step="0.1"
                    value={pbrNormalScale}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      setPbrNormalScale(val);
                      applyPBRMaterialToActiveModel(selectedPBRMaterialKey);
                    }}
                    className="w-full accent-emerald-400 cursor-pointer"
                  />
                </div>

                <div className="bg-black/60 p-2.5 rounded-xl border border-white/10 space-y-1">
                  <div className="flex justify-between font-bold text-[11px]">
                    <span className="text-zinc-400">Surface Roughness:</span>
                    <span className="text-emerald-400 font-mono">{pbrRoughness.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.0"
                    max="1.0"
                    step="0.05"
                    value={pbrRoughness}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      setPbrRoughness(val);
                      applyPBRMaterialToActiveModel(selectedPBRMaterialKey);
                    }}
                    className="w-full accent-emerald-400 cursor-pointer"
                  />
                </div>

                <div className="bg-black/60 p-2.5 rounded-xl border border-white/10 space-y-1">
                  <div className="flex justify-between font-bold text-[11px]">
                    <span className="text-zinc-400">Metallic Factor:</span>
                    <span className="text-emerald-400 font-mono">{pbrMetalness.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.0"
                    max="1.0"
                    step="0.05"
                    value={pbrMetalness}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      setPbrMetalness(val);
                      applyPBRMaterialToActiveModel(selectedPBRMaterialKey);
                    }}
                    className="w-full accent-emerald-400 cursor-pointer"
                  />
                </div>

                <div className="bg-black/60 p-2.5 rounded-xl border border-white/10 space-y-1">
                  <div className="flex justify-between font-bold text-[11px]">
                    <span className="text-zinc-400">Clearcoat Lacquer:</span>
                    <span className="text-emerald-400 font-mono">{pbrClearcoat.toFixed(2)}</span>
                  </div>
                  <input
                    type="range"
                    min="0.0"
                    max="1.0"
                    step="0.05"
                    value={pbrClearcoat}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      setPbrClearcoat(val);
                      applyPBRMaterialToActiveModel(selectedPBRMaterialKey);
                    }}
                    className="w-full accent-emerald-400 cursor-pointer"
                  />
                </div>
              </div>

              {/* Texture UV Tiling */}
              <div className="bg-black/60 p-2.5 rounded-xl border border-white/10 space-y-1">
                <div className="flex justify-between font-bold text-[11px]">
                  <span className="text-zinc-400">Texture UV Repeat Tiling:</span>
                  <span className="text-emerald-400 font-mono">{pbrTiling[0]}x {pbrTiling[1]}</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="16"
                  step="1"
                  value={pbrTiling[0]}
                  onChange={(e) => {
                    const val = parseInt(e.target.value);
                    setPbrTiling([val, val]);
                    applyPBRMaterialToActiveModel(selectedPBRMaterialKey);
                  }}
                  className="w-full accent-emerald-400 cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

// Generate Unified Engine HTML template with Volumetric and Ultra-Realistic Graphics using Babylon.js
function generateUnifiedEngineHTML(archetype: ModelArchetype, tweaks: any): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Aether Ultra 3D Game Engine - ${archetype.toUpperCase()}</title>
  <script src="https://cdn.babylonjs.com/babylon.js"></script>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body { margin: 0; overflow: hidden; background: #020308; font-family: system-ui, sans-serif; }
    canvas { display: block; width: 100vw; height: 100vh; }
  </style>
</head>
<body>
  <div id="hud" class="absolute top-4 left-4 z-10 text-white bg-zinc-950/90 border border-yellow-500/40 rounded-2xl p-4 shadow-2xl backdrop-blur-md min-w-[220px]">
    <div class="flex items-center justify-between pb-2 border-b border-zinc-800">
      <span class="text-xs font-black uppercase text-yellow-400 tracking-wider">BABYLON.JS ENGINE</span>
      <span id="fps" class="text-[10px] font-mono text-emerald-400 font-bold">60 FPS</span>
    </div>
    <div class="mt-2.5 flex items-baseline justify-between">
      <div>
        <div id="speed" class="text-3xl font-black font-mono">0</div>
        <div class="text-[9px] text-zinc-400 uppercase font-semibold">KM/H SPEED</div>
      </div>
      <div class="text-right">
        <div class="font-mono text-xs text-yellow-400 font-bold">WASD / ARROWS</div>
        <div class="text-[8px] text-zinc-500 font-mono">SPACE / SHIFT NITRO</div>
      </div>
    </div>
    <div class="mt-2 pt-2 border-t border-zinc-800/80 flex items-center justify-between text-[9px] font-mono text-zinc-400">
      <span>VOLUMETRIC: <strong class="text-yellow-400">ON</strong></span>
      <span>4K PBR: <strong class="text-emerald-400">ACTIVE</strong></span>
    </div>
  </div>

  <canvas id="renderCanvas"></canvas>

  <script>
    const canvas = document.getElementById("renderCanvas");
    const engine = new BABYLON.Engine(canvas, true, { preserveDrawingBuffer: true, stencil: true });
    
    const createScene = function() {
      const scene = new BABYLON.Scene(engine);
      scene.clearColor = new BABYLON.Color4(0.02, 0.03, 0.08, 1);
      
      // Atmospheric Fog
      scene.fogMode = BABYLON.Scene.FOGMODE_EXP2;
      scene.fogColor = new BABYLON.Color3(0.04, 0.06, 0.15);
      scene.fogDensity = ${tweaks.fogDensity || 0.012};

      // Camera setup behind player
      const camera = new BABYLON.FreeCamera("followCamera", new BABYLON.Vector3(0, 5, -10), scene);
      
      // Ambient Hemispheric Light
      const ambient = new BABYLON.HemisphericLight("ambient", new BABYLON.Vector3(0, 1, 0), scene);
      ambient.intensity = ${tweaks.lightingIntensity || 2.0} * 0.45;
      ambient.groundColor = new BABYLON.Color3(0.08, 0.12, 0.25);
      ambient.diffuse = new BABYLON.Color3(0.85, 0.9, 1.0);

      // Directional Sun Light
      const sun = new BABYLON.DirectionalLight("sun", new BABYLON.Vector3(-0.4, -0.9, -0.3), scene);
      sun.position = new BABYLON.Vector3(40, 75, 30);
      sun.intensity = 3.2;

      // Realtime shadow generator
      const shadowGenerator = new BABYLON.ShadowGenerator(1024, sun);
      shadowGenerator.useBlurExponentialShadowMap = true;
      shadowGenerator.blurKernel = 32;

      // Ground plane
      const ground = BABYLON.MeshBuilder.CreateGround("ground", { width: 600, height: 600 }, scene);
      const groundMat = new BABYLON.StandardMaterial("groundMat", scene);
      groundMat.diffuseColor = new BABYLON.Color3(0.03, 0.04, 0.08);
      groundMat.specularColor = new BABYLON.Color3(0.08, 0.1, 0.2);
      groundMat.roughness = 0.9;
      ground.material = groundMat;
      ground.receiveShadows = true;

      // Grid helper using LineSystem
      const lines = [];
      const gridCount = 60;
      const gridSize = 400;
      const step = gridSize / gridCount;
      for (let i = -gridCount / 2; i <= gridCount / 2; i++) {
        lines.push([new BABYLON.Vector3(i * step, 0.01, -gridSize / 2), new BABYLON.Vector3(i * step, 0.01, gridSize / 2)]);
        lines.push([new BABYLON.Vector3(-gridSize / 2, 0.01, i * step), new BABYLON.Vector3(gridSize / 2, 0.01, i * step)]);
      }
      const grid = BABYLON.MeshBuilder.CreateLineSystem("grid", { lines: lines }, scene);
      grid.color = BABYLON.Color3.FromHexString("#f59e0b");

      // Atmospheric Dust Particles
      const dustSystem = new BABYLON.ParticleSystem("dust", 300, scene);
      dustSystem.particleTexture = new BABYLON.Texture("https://raw.githubusercontent.com/PatrickRyanMS/BabylonJS_Assets/master/particle_textures/flare.png", scene);
      dustSystem.minEmitBox = new BABYLON.Vector3(-50, 0, -50);
      dustSystem.maxEmitBox = new BABYLON.Vector3(50, 25, 50);
      dustSystem.color1 = new BABYLON.Color4(1, 0.95, 0.85, 0.55);
      dustSystem.color2 = new BABYLON.Color4(1, 0.95, 0.85, 0.15);
      dustSystem.colorDead = new BABYLON.Color4(0, 0, 0, 0);
      dustSystem.minSize = 0.15;
      dustSystem.maxSize = 0.4;
      dustSystem.minLifeTime = 3.0;
      dustSystem.maxLifeTime = 6.0;
      dustSystem.emitRate = 35;
      dustSystem.gravity = new BABYLON.Vector3(0, -0.08, 0);
      dustSystem.start();

      // Transform group for player model
      const playerRoot = new BABYLON.TransformNode("playerRoot", scene);

      // Materials
      const primaryMat = new BABYLON.PBRMaterial("primaryMat", scene);
      primaryMat.albedoColor = BABYLON.Color3.FromHexString("${tweaks.primaryColor}");
      primaryMat.metallic = 0.85;
      primaryMat.roughness = 0.22;
      primaryMat.clearCoat.isEnabled = true;
      primaryMat.clearCoat.roughness = 0.1;
      primaryMat.wireframe = ${tweaks.wireframe};

      const accentMat = new BABYLON.PBRMaterial("accentMat", scene);
      accentMat.albedoColor = BABYLON.Color3.FromHexString("${tweaks.accentColor}");
      accentMat.metallic = 0.9;
      accentMat.roughness = 0.15;
      accentMat.wireframe = ${tweaks.wireframe};

      // Procedural model assemblies depending on Archetype
      const buildModel = function() {
        const arch = "${archetype}";
        if (arch === "car") {
          const body = BABYLON.MeshBuilder.CreateBox("carBody", { width: 2.2, height: 0.7, depth: 4.4 }, scene);
          body.position.y = 0.7;
          body.parent = playerRoot;
          body.material = primaryMat;
          shadowGenerator.addShadowCaster(body);

          const cabin = BABYLON.MeshBuilder.CreateBox("carCabin", { width: 1.6, height: 0.6, depth: 2.2 }, scene);
          cabin.position.set(0, 1.25, -0.2);
          cabin.parent = playerRoot;
          const glassMat = new BABYLON.StandardMaterial("glassMat", scene);
          glassMat.diffuseColor = new BABYLON.Color3(0.05, 0.08, 0.15);
          glassMat.alpha = 0.65;
          cabin.material = glassMat;
          shadowGenerator.addShadowCaster(cabin);

          // 4 wheels
          const wheelPos = [
            [-1.15, 0.4, 1.4], [1.15, 0.4, 1.4],
            [-1.15, 0.4, -1.4], [1.15, 0.4, -1.4]
          ];
          wheelPos.forEach((p, idx) => {
            const wheel = BABYLON.MeshBuilder.CreateCylinder("wheel_" + idx, { height: 0.45, diameter: 0.8, tessellation: 24 }, scene);
            wheel.rotation.z = Math.PI / 2;
            wheel.position.set(p[0], p[1], p[2]);
            wheel.parent = playerRoot;
            const tireMat = new BABYLON.StandardMaterial("tireMat", scene);
            tireMat.diffuseColor = new BABYLON.Color3(0.08, 0.08, 0.1);
            wheel.material = tireMat;
            shadowGenerator.addShadowCaster(wheel);
          });
        } else if (arch === "robot") {
          const torso = BABYLON.MeshBuilder.CreateCylinder("torso", { height: 1.6, diameterTop: 0.9, diameterBottom: 1.3 }, scene);
          torso.position.y = 1.3;
          torso.parent = playerRoot;
          torso.material = primaryMat;
          shadowGenerator.addShadowCaster(torso);

          const head = BABYLON.MeshBuilder.CreateSphere("head", { diameter: 0.8 }, scene);
          head.position.set(0, 2.3, 0);
          head.parent = playerRoot;
          head.material = accentMat;
          shadowGenerator.addShadowCaster(head);

          const leftArm = BABYLON.MeshBuilder.CreateBox("lArm", { width: 0.35, height: 1.2, depth: 0.35 }, scene);
          leftArm.position.set(-0.85, 1.3, 0);
          leftArm.parent = playerRoot;
          leftArm.material = primaryMat;
          shadowGenerator.addShadowCaster(leftArm);

          const rightArm = BABYLON.MeshBuilder.CreateBox("rArm", { width: 0.35, height: 1.2, depth: 0.35 }, scene);
          rightArm.position.set(0.85, 1.3, 0);
          rightArm.parent = playerRoot;
          rightArm.material = primaryMat;
          shadowGenerator.addShadowCaster(rightArm);
        } else if (arch === "tank") {
          const treads = BABYLON.MeshBuilder.CreateBox("treads", { width: 2.6, height: 0.6, depth: 4.6 }, scene);
          treads.position.y = 0.3;
          treads.parent = playerRoot;
          const treadsMat = new BABYLON.StandardMaterial("treadsMat", scene);
          treadsMat.diffuseColor = new BABYLON.Color3(0.12, 0.12, 0.14);
          treads.material = treadsMat;
          shadowGenerator.addShadowCaster(treads);

          const base = BABYLON.MeshBuilder.CreateBox("tankBase", { width: 2.4, height: 0.8, depth: 4.2 }, scene);
          base.position.y = 0.8;
          base.parent = playerRoot;
          base.material = primaryMat;
          shadowGenerator.addShadowCaster(base);

          const turret = BABYLON.MeshBuilder.CreateCylinder("turret", { height: 0.7, diameter: 1.6 }, scene);
          turret.position.set(0, 1.4, -0.3);
          turret.parent = playerRoot;
          turret.material = accentMat;
          shadowGenerator.addShadowCaster(turret);

          const barrel = BABYLON.MeshBuilder.CreateCylinder("barrel", { height: 2.4, diameter: 0.22 }, scene);
          barrel.rotation.x = Math.PI / 2;
          barrel.position.set(0, 1.4, 1.0);
          barrel.parent = playerRoot;
          barrel.material = accentMat;
          shadowGenerator.addShadowCaster(barrel);
        } else if (arch === "starfighter") {
          const body = BABYLON.MeshBuilder.CreateCylinder("fighterBody", { height: 4.5, diameterTop: 0.1, diameterBottom: 1.2 }, scene);
          body.rotation.x = Math.PI / 2;
          body.position.y = 1.0;
          body.parent = playerRoot;
          body.material = primaryMat;
          shadowGenerator.addShadowCaster(body);

          const leftWing = BABYLON.MeshBuilder.CreateBox("lWing", { width: 2.6, height: 0.12, depth: 1.8 }, scene);
          leftWing.position.set(-1.8, 1.0, -0.4);
          leftWing.parent = playerRoot;
          leftWing.material = accentMat;
          shadowGenerator.addShadowCaster(leftWing);

          const rightWing = BABYLON.MeshBuilder.CreateBox("rWing", { width: 2.6, height: 0.12, depth: 1.8 }, scene);
          rightWing.position.set(1.8, 1.0, -0.4);
          rightWing.parent = playerRoot;
          rightWing.material = accentMat;
          shadowGenerator.addShadowCaster(rightWing);
        } else {
          // Standard core pylon / geometric shapes for premium manifolds and speedboat
          const pylon = BABYLON.MeshBuilder.CreateTorusKnot("pylon", { radius: 1.1, tube: 0.35, radialSegments: 128 }, scene);
          pylon.position.y = 1.8;
          pylon.parent = playerRoot;
          pylon.material = primaryMat;
          shadowGenerator.addShadowCaster(pylon);
        }
      };

      buildModel();

      return { scene, playerRoot, camera };
    };

    const { scene, playerRoot, camera } = createScene();

    // Physics Engine loop properties
    let speed = 0;
    let heading = 0;
    const keys = {};
    window.addEventListener('keydown', e => keys[e.key.toLowerCase()] = true);
    window.addEventListener('keyup', e => keys[e.key.toLowerCase()] = false);

    let lastTime = performance.now();
    let frameCount = 0;
    let fpsTimer = performance.now();

    engine.runRenderLoop(function() {
      const now = performance.now();
      const delta = (now - lastTime) / 1000;
      lastTime = now;

      // FPS metrics
      frameCount++;
      if (now - fpsTimer >= 1000) {
        document.getElementById('fps').innerText = frameCount + " FPS";
        frameCount = 0;
        fpsTimer = now;
      }

      // Input controls translation
      const isUp = keys['w'] || keys['arrowup'];
      const isDown = keys['s'] || keys['arrowdown'];
      const isLeft = keys['a'] || keys['arrowleft'];
      const isRight = keys['d'] || keys['arrowright'];
      const isNitro = keys['shift'] ? ${tweaks.nitroBoost || 1.65} : 1.0;

      const maxSpeed = ${tweaks.maxSpeed || 0.55} * isNitro;
      const acceleration = ${tweaks.acceleration || 0.015} * isNitro;
      const friction = ${tweaks.friction || 0.96};

      if (isUp) {
        speed = Math.min(speed + acceleration, maxSpeed);
      } else if (isDown) {
        speed = Math.max(speed - acceleration * 0.8, -0.2);
      } else {
        speed *= friction;
      }

      if (Math.abs(speed) > 0.005) {
        const turnDir = isLeft ? 1 : isRight ? -1 : 0;
        heading += turnDir * 0.045 * (speed > 0 ? 1 : -1);
      }

      // Physics coordinate transform
      playerRoot.rotation.y = heading;
      playerRoot.position.x -= Math.sin(heading) * speed;
      playerRoot.position.z -= Math.cos(heading) * speed;

      // Smooth follow camera
      const backDistance = 9.5;
      const camHeight = 3.8;
      
      const targetCamX = playerRoot.position.x + Math.sin(heading) * backDistance;
      const targetCamZ = playerRoot.position.z + Math.cos(heading) * backDistance;
      const targetCamY = playerRoot.position.y + camHeight;

      // Smooth camera interpolation (lerp)
      camera.position.x = camera.position.x + (targetCamX - camera.position.x) * 0.15;
      camera.position.y = camera.position.y + (targetCamY - camera.position.y) * 0.15;
      camera.position.z = camera.position.z + (targetCamZ - camera.position.z) * 0.15;
      
      camera.setTarget(new BABYLON.Vector3(playerRoot.position.x, playerRoot.position.y + 0.8, playerRoot.position.z));

      // Speed display
      document.getElementById('speed').innerText = Math.round(Math.abs(speed) * 280);

      scene.render();
    });

    window.addEventListener('resize', () => {
      engine.resize();
    });
  </script>
</body>
</html>`;
}

export default Studio3DGameEngine;
