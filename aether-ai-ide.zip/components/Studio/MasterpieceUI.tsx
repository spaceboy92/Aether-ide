import React, { useState, useRef } from 'react';
import { 
  LayoutGrid, 
  MessageSquare, 
  Settings, 
  ArrowUpRight, 
  Plus, 
  ArrowUp, 
  Sparkles,
  History,
  Clock,
  Code,
  Layers,
  Cpu,
  Globe,
  Terminal,
  Zap,
  Smartphone,
  MoreVertical,
  Share2,
  Trash2,
  Edit2
} from 'lucide-react';
import { motion } from 'motion/react';
import BlackHoleBackground from '../UI/BlackHoleBackground';
import { AIChatInput } from '../AI/AIAssistant/AIChatInput';

interface MasterpieceUIProps {
  onStart: (prompt: string, attachments?: any[], modelId?: string) => void;
  sessions?: any[];
  onSelectSession?: (id: string) => void;
  onOpenSettings?: () => void;
  onShowGallery?: () => void;
  onViewAllSessions?: () => void;
  onRenameSession?: (id: string, title: string) => void;
  onDeleteSession?: (id: string) => void;
}

const MasterpieceUI: React.FC<MasterpieceUIProps> = ({ 
  onStart, 
  sessions = [], 
  onSelectSession, 
  onOpenSettings,
  onShowGallery,
  onViewAllSessions,
  onRenameSession,
  onDeleteSession
}) => {
  const [prompt, setPrompt] = useState('');
  const [attachments, setAttachments] = useState<any[]>([]);
  const [referencedFiles, setReferencedFiles] = useState<any[]>([]);
  const [showFileDropdown, setShowFileDropdown] = useState(false);
  const [selectedModel, setSelectedModel] = useState('aether-pro');
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [activeType, setActiveType] = useState<'web' | 'mobile' | 'fullstack' | 'android'>('web');
  const [thinkingLevel, setThinkingLevel] = useState(true);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, type: "image" | "file") => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const result = ev.target?.result as string;
        const base64 = result.split(",")[1];
        setAttachments((prev) => [
          ...prev,
          {
            name: file.name,
            type: type === "image" ? "image" : "file",
            mimeType: file.type || "text/plain",
            data: base64,
          },
        ]);
      };
      reader.readAsDataURL(file);
    });
    e.target.value = "";
  };

  const handleLaunch = (customPrompt?: string, customAttachments?: any[], customModel?: string) => {
    const raw = (customPrompt !== undefined ? customPrompt : prompt).trim();
    const activeAtts = customAttachments || attachments;
    if (!raw && activeAtts.length === 0) return;

    let targetPrompt = raw;
    if (activeType === 'android' && !targetPrompt.toLowerCase().includes('android')) {
      targetPrompt += ' Build as an Android Compose App.';
    } else if (activeType === 'mobile' && !targetPrompt.toLowerCase().includes('mobile')) {
      targetPrompt += ' Optimize for Responsive Mobile Viewport.';
    } else if (activeType === 'fullstack' && !targetPrompt.toLowerCase().includes('fullstack') && !targetPrompt.toLowerCase().includes('server')) {
      targetPrompt += ' Structure as a Full-Stack application with clean client and backend architecture.';
    }

    if (thinkingLevel && !targetPrompt.includes('[DEEP REASONING')) {
      targetPrompt = `[DEEP REASONING & ORCHESTRATION MODE]:\n${targetPrompt}`;
    }

    onStart(targetPrompt, activeAtts, customModel || selectedModel);
  };

  const suggestions = [
    "3D Cyberpunk Game Arena with Physics",
    "Subscription SaaS Revenue & Analytics Dashboard",
    "Android Jetpack Compose Counter App",
    "Markdown Notes Workspace with Local Storage",
    "Real-Time Collaborative Code Editor & Canvas",
    "AI Travel Itinerary Planner with Maps",
  ];

  const starters = [
    {
      title: "Hyper-Scale SaaS Command Center",
      desc: "Multi-layered telemetry dashboard tracking virtual microservices, live worker threads, active Recharts bandwidth streams, and interactive system logs.",
      level: "Enterprise L5",
      badgeColor: "text-emerald-400 border-emerald-500/20 bg-emerald-500/10",
      modules: ["Recharts Pipeline", "Simulated Multi-Threads", "Log Streamer", "Dynamic State Filters"],
      icon: Cpu,
      prompt: "Build an elite Enterprise SaaS Command Center dashboard. The application must feature high-performance real-time telemetry streaming simulation, a dynamic multi-tab layout, active system throughput gauges, dynamic system load visualizers, interactive performance charts (using recharts), database worker node control panel to spin up/down simulated threads, a real-time system log feed with severity level color coding, data table sorting/filtering, and local storage state sync."
    },
    {
      title: "AOSP Android OS Simulator Suite",
      desc: "Full virtual smartphone environment rendering custom hardware metrics, swipe notification shade, dynamic camera view, setting apps, and Aether Shell.",
      level: "OS Emulator L5",
      badgeColor: "text-orange-400 border-orange-500/20 bg-orange-500/10",
      modules: ["Aether Shell Terminal", "Setting App Control", "Multitasking Recents", "Material You Engine"],
      icon: Smartphone,
      prompt: "Create an AOSP-inspired Android OS Virtual Smartphone Environment. It should implement an interactive terminal emulator (Aether Shell), a live setting app with configurable theme modes, quick toggle shortcuts shade, a play store containing custom APK downloads, interactive phone contacts, local storage persistence, and swipe-up multitasking recents panel with memory clearing."
    },
    {
      title: "Autonomous LLM Agent Playground",
      desc: "Next-gen AI engineering sandbox featuring side-by-side agent comparison, hyperparameter adjustment dials, token telemetry, and markdown formatting.",
      level: "AI Master L4",
      badgeColor: "text-purple-400 border-purple-500/20 bg-purple-500/10",
      modules: ["Agent Comparison", "Hyperparameter Dials", "Token Metrics Telemetry", "Markdown Rich-text"],
      icon: Sparkles,
      prompt: "Design a high-fidelity Autonomous AI Agent Chat Playground. Features must include support for model choosing dropdown, interactive slide parameter dials (temperature, system prompt), real-time output stream simulator with token stats, multi-agent side-by-side chats, a clean markdown rich-text renderer for agent responses, persistent conversation logs, and editable system instructions."
    },
    {
      title: "Interactive Web 3D Physics Arena",
      desc: "Mathematical canvas-rendered particle dynamics model supporting drag-and-drop gravity well anchors, boundary friction, and synthesizer audio.",
      level: "Simulation L4",
      badgeColor: "text-cyan-400 border-cyan-500/20 bg-cyan-500/10",
      modules: ["HTML5 Canvas Engine", "Audio Synthesizer", "Gravity Field Multipliers", "Friction Math"],
      icon: Code,
      prompt: "Build an interactive Web 3D Particle Physics Sandbox utilizing HTML5 Canvas. The canvas must calculate high-frequency particle collisions, custom user gravity-well anchors, drag-and-drop interactive force nodes, friction variables, speed multipliers, and trigger real-time sound frequencies using the browser's Web Audio API Synthesizer."
    },
    {
      title: "Express Full-Stack API Broker",
      desc: "High-integrity architecture modeling server controllers, middleware interceptors, live proxy request monitoring, and workspace database schemas.",
      level: "Full-Stack L5",
      badgeColor: "text-blue-400 border-blue-500/20 bg-blue-500/10",
      modules: ["Server-Auth Controller", "Proxy Request logs", "Middleware simulation", "Database schemas"],
      icon: Terminal,
      prompt: "Create a complete, fully interactive Express Full-Stack Server-authoritative system layout. Must contain dynamic mock database structures, network logs dashboard, middleware interceptors, live proxy requests, status codes logs, and a beautiful client interface with complete data flow schemas."
    },
    {
      title: "Collaborative Agile Sprint Manager",
      desc: "Enterprise Kanban workspace supporting fluid drag state transitions, priority tagging, interactive task checklists, and live velocity burndowns.",
      level: "Workflow L4",
      badgeColor: "text-pink-400 border-pink-500/20 bg-pink-500/10",
      modules: ["Fluid Kanban Lanes", "Velocity Burndowns", "Subtask checklist tree", "Audit Logs"],
      icon: Layers,
      prompt: "Build a highly collaborative Agile Sprint Planner and Kanban board. Feature complete drag-and-drop simulation across lanes (To-Do, Active, Review, Completed), custom story points tracker, priority tagging, interactive task checklists with percentage bars, activity audits logs, and a dynamic burndown progress chart."
    }
  ];

  return (
    <div className="relative w-full h-full text-zinc-200 selection:bg-orange-500/20 bg-black/20 overflow-y-auto overflow-x-hidden custom-scrollbar">
      
      {/* Interactive Cosmic Black Hole Background */}
      <div className="fixed inset-0 z-0 pointer-events-auto overflow-hidden">
        <BlackHoleBackground isLowPerf={false} />
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/20 to-black/70 pointer-events-none" />
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-10 md:py-14 pb-28">
        
        {/* Top Workspace Header */}
        <header className="flex items-center justify-between mb-8 sm:mb-12 md:mb-16">
          <div className="flex items-center gap-2.5 sm:gap-3">
            <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl sm:rounded-2xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-500 shadow-sm shadow-orange-500/10">
              <Sparkles size={16} className="sm:w-[18px] sm:h-[18px]" />
            </div>
            <div>
              <span className="text-xs sm:text-sm font-bold tracking-tight text-white block">Aether Studio</span>
              <span className="text-[10px] sm:text-[11px] font-medium text-zinc-500">Autonomous Web & Mobile Architect</span>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-3">
            <button 
              onClick={onShowGallery}
              className="flex items-center gap-1.5 px-2.5 sm:px-4 py-1.5 sm:py-2 bg-white/5 hover:bg-orange-500/10 border border-white/10 hover:border-orange-500/30 rounded-xl text-zinc-300 hover:text-white transition-all text-xs font-semibold"
            >
              <LayoutGrid size={13} className="sm:w-[14px] sm:h-[14px]" />
              <span className="hidden sm:inline">Gallery</span>
            </button>

            <button 
              onClick={onViewAllSessions}
              className="flex items-center gap-1.5 px-2.5 sm:px-4 py-1.5 sm:py-2 bg-white/5 hover:bg-orange-500/10 border border-white/10 hover:border-orange-500/30 rounded-xl text-zinc-300 hover:text-white transition-all text-xs font-semibold"
            >
              <History size={13} className="sm:w-[14px] sm:h-[14px]" />
              <span className="hidden sm:inline">Sessions</span>
            </button>

            <button 
              onClick={onOpenSettings}
              className="flex items-center gap-1.5 px-2.5 sm:px-4 py-1.5 sm:py-2 bg-white/5 hover:bg-orange-500/10 border border-white/10 hover:border-orange-500/30 rounded-xl text-zinc-300 hover:text-white transition-all text-xs font-semibold"
            >
              <Settings size={13} className="sm:w-[14px] sm:h-[14px]" />
              <span className="hidden sm:inline">Settings</span>
            </button>
          </div>
        </header>

        {/* Hero Title */}
        <div className="flex flex-col items-center text-center mb-6 sm:mb-8">
          <motion.h1 
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-xl sm:text-3xl md:text-4xl font-bold tracking-tight text-white mb-1 sm:mb-2 leading-tight font-display"
          >
            What would you like to <span className="text-orange-500">create</span>?
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-zinc-400 text-xs sm:text-sm max-w-md leading-relaxed font-normal px-2"
          >
            Describe a web app, layout, or mobile project in plain language.
          </motion.p>
        </div>

        {/* Core Prompt Input Area */}
        <motion.div 
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="w-full max-w-3xl mx-auto mb-8 sm:mb-10"
        >
          <div className="bg-zinc-950/90 border border-white/10 hover:border-orange-500/30 rounded-2xl p-3 sm:p-4 shadow-2xl backdrop-blur-2xl transition-all">
            
            {/* Direct Auto-Platform Routing */}
            <div className="flex flex-wrap items-center justify-between gap-2 mb-3 px-1">
              <div className="flex flex-wrap gap-1 p-0.5 bg-black/60 rounded-xl border border-white/5">
                {(['web', 'mobile', 'fullstack', 'android'] as const).map((type) => (
                  <button 
                    key={type}
                    onClick={() => setActiveType(type)}
                    className={`px-3 py-1 rounded-lg text-xs font-semibold tracking-tight transition-all cursor-pointer ${
                      activeType === type 
                        ? 'bg-orange-500 text-black font-bold shadow' 
                        : 'text-zinc-400 hover:text-white'
                    }`}
                  >
                    {type === 'web' ? 'Web App' : type === 'mobile' ? 'Mobile View' : type === 'fullstack' ? 'Full Stack' : 'Android'}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-orange-500/10 border border-orange-500/20 text-orange-400 text-xs font-semibold tracking-wider">
                <Sparkles size={12} className="text-orange-400" />
                <span>Unified AI Engine</span>
              </div>
            </div>

            {/* General Chat Unified AIChatInput */}
            <AIChatInput
              input={prompt}
              setInput={setPrompt}
              isProcessing={false}
              isEnhancing={false}
              isListening={false}
              isTyping={null}
              attachments={attachments}
              setAttachments={setAttachments}
              handleSend={() => handleLaunch()}
              handleEnhance={() => {}}
              handleCapturePreview={() => {}}
              toggleVoiceInput={() => {}}
              onStopProcessing={() => {}}
              textareaRef={textareaRef as any}
              fileInputRef={fileInputRef as any}
              folderInputRef={folderInputRef as any}
              imageInputRef={imageInputRef as any}
              handleFileUpload={handleFileUpload}
              handleKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  if (prompt.trim() || attachments.length > 0) {
                    handleLaunch();
                  }
                }
              }}
              dynamicShortcuts={[]}
              onSendMessage={(p, atts, m) => handleLaunch(p, atts, m)}
              selectedModel={selectedModel}
              referencedFiles={referencedFiles}
              setReferencedFiles={setReferencedFiles}
              showFileDropdown={showFileDropdown}
              filteredFiles={[]}
              handleSelectFileRef={() => {}}
            />
          </div>

          {/* Instant Prompt Starters */}
          <div className="mt-3 flex flex-wrap justify-center gap-1">
            {suggestions.map((text, i) => (
              <button 
                key={i}
                onClick={() => {
                  setPrompt(text);
                  handleLaunch(text);
                }}
                className="px-2.5 py-1 bg-white/[0.02] border border-white/5 hover:border-orange-500/30 hover:bg-orange-500/10 rounded-full text-[11px] text-zinc-400 hover:text-white transition-all cursor-pointer"
              >
                {text}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Starter Blueprints Grid */}
        <div className="mb-14">
          <h2 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-5 flex items-center gap-2">
            <Zap size={15} className="text-orange-500 animate-pulse" />
            Complex Master Blueprints
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {starters.map((starter, i) => {
              const IconComp = starter.icon;
              return (
                <div 
                  key={i}
                  onClick={() => handleLaunch(starter.prompt)}
                  className="p-6 bg-zinc-950/60 border border-white/10 hover:border-orange-500/40 rounded-3xl cursor-pointer transition-all duration-300 group hover:bg-zinc-900/80 hover:shadow-[0_20px_50px_rgba(249,115,22,0.04)] flex flex-col justify-between"
                >
                  <div>
                    {/* Top line with Icon & Complexity level badge */}
                    <div className="flex items-start justify-between gap-4 mb-4">
                      <div className="w-11 h-11 rounded-2xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-500 group-hover:scale-110 transition-transform duration-300">
                        <IconComp size={20} />
                      </div>
                      
                      <span className={`px-2.5 py-1 rounded-full text-[9px] font-bold tracking-widest uppercase border ${starter.badgeColor}`}>
                        {starter.level}
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-white group-hover:text-orange-500 transition-colors duration-300">{starter.title}</h3>
                    <p className="text-xs text-zinc-400 mt-2 leading-relaxed">{starter.desc}</p>
                  </div>

                  {/* Modules Pills */}
                  <div className="mt-5 pt-4 border-t border-white/5">
                    <div className="text-[9px] uppercase font-black tracking-widest text-zinc-600 mb-2">Key Modules</div>
                    <div className="flex flex-wrap gap-1.5">
                      {starter.modules.map((mod, idx) => (
                        <span 
                          key={idx} 
                          className="px-2 py-0.5 rounded bg-white/5 border border-white/10 text-[8px] font-mono font-bold text-zinc-500 group-hover:text-zinc-300 group-hover:border-orange-500/10 transition-colors"
                        >
                          {mod}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Recent Workspaces */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xs font-bold uppercase tracking-wider text-zinc-400 flex items-center gap-2">
              <History size={15} className="text-orange-500" />
              Recent Workspace Instances
            </h2>
            <button 
              onClick={onViewAllSessions}
              className="text-xs font-semibold text-zinc-400 hover:text-white transition-colors"
            >
              View All ({sessions.length})
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pb-20">
            {sessions.length > 0 ? (
              sessions.slice(0, 3).map((s) => (
                <div 
                  key={s.id}
                  onClick={() => onSelectSession?.(s.id)}
                  className="relative p-4 bg-zinc-950/60 border border-white/10 hover:border-orange-500/40 rounded-2xl cursor-pointer transition-all group hover:bg-zinc-900 flex flex-col justify-between min-h-[160px] overflow-hidden"
                >
                  {/* Automated Session Snapshot Thumbnail Header */}
                  {s.thumbnailUrl && (
                    <div className="w-full h-24 mb-3 rounded-xl overflow-hidden border border-white/10 bg-black relative">
                      <img 
                        src={s.thumbnailUrl} 
                        alt="Session Snapshot" 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-80 group-hover:opacity-100"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute bottom-1.5 left-2 px-1.5 py-0.5 rounded bg-black/70 backdrop-blur-md text-[9px] font-mono text-orange-400 border border-orange-500/30 flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                        <span>SNAPSHOT</span>
                      </div>
                    </div>
                  )}

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded-md bg-white/5 border border-white/10 text-zinc-400">
                        {s.id.slice(0, 8)}
                      </span>
                      
                      <div className="flex items-center gap-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveDropdown(activeDropdown === s.id ? null : s.id);
                          }}
                          className="p-1 text-zinc-500 hover:text-white transition-colors rounded-md hover:bg-white/10"
                        >
                          <MoreVertical size={15} />
                        </button>
                      </div>
                    </div>
                    
                    {activeDropdown === s.id && (
                      <>
                        <div 
                          className="fixed inset-0 z-40"
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveDropdown(null);
                          }}
                        />
                        <div className="absolute right-4 top-12 z-50 w-40 bg-[#0f1115] border border-white/10 rounded-xl shadow-2xl py-1 animate-in fade-in zoom-in-95 duration-100">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveDropdown(null);
                              window.dispatchEvent(new CustomEvent("aether_open_share"));
                            }}
                            className="w-full text-left px-3 py-2 text-xs text-white/70 hover:text-white hover:bg-white/5 flex items-center gap-2"
                          >
                            <Share2 size={12} className="text-sky-400" /> Share Project
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveDropdown(null);
                              const newTitle = window.prompt("Enter new title for session:", s.title);
                              if (newTitle && newTitle.trim() && onRenameSession) {
                                onRenameSession(s.id, newTitle.trim());
                              }
                            }}
                            className="w-full text-left px-3 py-2 text-xs text-white/70 hover:text-white hover:bg-white/5 flex items-center gap-2"
                          >
                            <Edit2 size={12} className="text-amber-400" /> Rename
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveDropdown(null);
                              if (confirm("Are you sure you want to delete this session? This action cannot be undone.") && onDeleteSession) {
                                onDeleteSession(s.id);
                              }
                            }}
                            className="w-full text-left px-3 py-2 text-xs text-rose-400 hover:bg-rose-500/10 flex items-center gap-2"
                          >
                            <Trash2 size={12} /> Delete Session
                          </button>
                        </div>
                      </>
                    )}

                    <h3 className="text-sm font-bold text-white truncate group-hover:text-orange-500 transition-colors pr-2">{s.title || 'Untitled Workspace'}</h3>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-zinc-500 mt-4">
                    <Clock size={12} />
                    <span>{new Date(s.lastUpdated).toLocaleDateString()}</span>
                    <span className="ml-auto text-[11px] text-zinc-400 font-mono">{s.messages?.length || 0} msgs</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="col-span-3 py-10 border border-dashed border-white/10 rounded-2xl text-center text-zinc-500 text-xs">
                No active workspace sessions yet. Start a new build above!
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};

export default MasterpieceUI;
