import React from 'react';
import { motion } from 'motion/react';

export const WelcomeAnimation = ({ onComplete }: { onComplete: () => void }) => {
    return (
        <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onAnimationComplete={onComplete}
            className="fixed inset-0 z-[200] bg-black flex items-center justify-center"
        >
            <motion.div
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ duration: 1, ease: "easeOut" }}
                className="text-center"
            >
                <div className="text-6xl font-black text-white mb-4 tracking-tighter uppercase italic">
                    <span className="text-blue-600">BMW</span> M-SERIES
                </div>
                <div className="text-white/60 font-mono text-sm uppercase tracking-widest">
                    Collaboration Initialized
                </div>
            </motion.div>
        </motion.div>
    );
};
