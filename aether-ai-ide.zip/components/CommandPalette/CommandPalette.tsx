import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, File, Terminal, RefreshCw, Layout, Package, Moon, Sun, Settings, Box, Palette, Code2, 
  ShoppingBag, Cpu, CloudUpload, TrendingUp, ShieldCheck, Database, Wand2, Volume2, Network, Gauge, Globe, GitBranch, Bot, Sparkles, KeyRound, Sliders
} from 'lucide-react';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectCommand: (commandId: string, payload?: any) => void;
  files: any[];
}

interface CommandItem {
  id: string;
  title: string;
  category: 'AGENTS' | 'SUB-AGENTS' | 'ASI TOOLS' | 'SYSTEM';
  icon: React.ReactNode;
  payload?: any;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({ isOpen, onClose, onSelectCommand, files }) => {
  const [search, setSearch] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setSearch('');
      setSelectedIndex(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  const defaultCommands: CommandItem[] = [
    // AGENTS
    { id: 'open-chat', title: 'AI Co-Pilot Chat Agent (/chat)', category: 'AGENTS', icon: <Bot size={16} className="text-orange-400" /> },
    { id: 'open-evolution', title: 'Evolution Core Agent (Autonomous Code Refactorer) (/refactor)', category: 'AGENTS', icon: <Sparkles size={16} className="text-amber-400" /> },
    { id: 'open-tasks', title: 'Task Runner Agent (Background Process Coordinator)', category: 'AGENTS', icon: <Cpu size={16} className="text-blue-400" /> },

    // SUB-AGENTS
    { id: 'open-security', title: 'Gatekeeper Security Sub-Agent (Vulnerability Inspector) (/security)', category: 'SUB-AGENTS', icon: <ShieldCheck size={16} className="text-emerald-400" /> },
    { id: 'open-profiler', title: 'Activity Monitor Sub-Agent (Performance Profiler) (/profiler)', category: 'SUB-AGENTS', icon: <Gauge size={16} className="text-green-400" /> },
    { id: 'open-history', title: 'Time Machine Git Sub-Agent (File Revision History) (/history)', category: 'SUB-AGENTS', icon: <GitBranch size={16} className="text-cyan-400" /> },
    { id: 'open-database', title: 'Database Engine Sub-Agent (Firestore & SQL Inspector) (/database)', category: 'SUB-AGENTS', icon: <Database size={16} className="text-amber-400" /> },

    // ASI TOOLS
    { id: 'open-uistudio', title: 'Tailwind UI Component & Theme Studio (/uistudio)', category: 'ASI TOOLS', icon: <Palette size={16} className="text-violet-400" /> },
    { id: 'open-audiosynth', title: 'Web Audio & Sound FX Studio (AudioSynthStudio)', category: 'ASI TOOLS', icon: <Volume2 size={16} className="text-red-400" /> },
    { id: 'open-dependencygraph', title: 'Code Architecture & Module Graph Visualizer', category: 'ASI TOOLS', icon: <Network size={16} className="text-indigo-400" /> },
    { id: 'open-api-playground', title: 'Safari API Studio (REST & HTTP Request Tester) (/api)', category: 'ASI TOOLS', icon: <Globe size={16} className="text-sky-400" /> },
    { id: 'open-datatransformer', title: 'Automator Studio (Data Transformer & JSON Engine)', category: 'ASI TOOLS', icon: <Wand2 size={16} className="text-pink-400" /> },
    { id: 'open-jwt', title: 'JWT Token Decoder & Inspector (/jwt)', category: 'ASI TOOLS', icon: <KeyRound size={16} className="text-orange-400" /> },
    { id: 'open-env', title: 'Environment Variable Manager (.env) (/env)', category: 'ASI TOOLS', icon: <Sliders size={16} className="text-cyan-400" /> },
    { id: 'open-files', title: 'Workspace Finder (File Tree & Project Files)', category: 'ASI TOOLS', icon: <File size={16} className="text-blue-400" /> },
    { id: 'open-search', title: 'Spotlight Search (Global Workspace Search) (/search)', category: 'ASI TOOLS', icon: <Search size={16} className="text-purple-400" /> },
    { id: 'toggle-terminal', title: 'Linux Terminal Shell (Terminal Console) (/terminal)', category: 'ASI TOOLS', icon: <Terminal size={16} className="text-emerald-400" /> },

    // SYSTEM
    { id: 'deploy-app', title: 'Deploy App to Cloud Run (/deploy)', category: 'SYSTEM', icon: <CloudUpload size={16} className="text-emerald-400" /> },
    { id: 'new-file', title: 'Create New File (/new)', category: 'SYSTEM', icon: <File size={16} /> },
    { id: 'format-doc', title: 'Format Active Document (/format)', category: 'SYSTEM', icon: <Layout size={16} /> },
    { id: 'install-package', title: 'Install NPM Package (/install)', category: 'SYSTEM', icon: <Package size={16} /> },
    { id: 'run-doctor', title: 'Run Aether Health Doctor (/doctor)', category: 'SYSTEM', icon: <TrendingUp size={16} className="text-green-400" /> },
    { id: 'create-rust-file', title: 'Create Rust Native Program (main.rs) (/rust)', category: 'SYSTEM', icon: <Code2 size={16} className="text-amber-500" /> },
    { id: 'export-zip', title: 'Export Project to ZIP (/zip)', category: 'SYSTEM', icon: <CloudUpload size={16} /> },
    { id: 'clear-chat', title: 'Purge Session Chat Messages (/clear)', category: 'SYSTEM', icon: <Wand2 size={16} className="text-rose-400" /> },
    { id: 'open-3d-engine', title: 'Open 3D Studio Game Engine', category: 'SYSTEM', icon: <Cpu size={16} /> },
    { id: 'open-marketplace', title: 'Aether Extensions Marketplace', category: 'SYSTEM', icon: <ShoppingBag size={16} /> },
    { id: 'open-settings', title: 'IDE System Settings', category: 'SYSTEM', icon: <Settings size={16} /> },
    { id: 'toggle-sidebar', title: 'Toggle Left Sidebar', category: 'SYSTEM', icon: <Box size={16} /> },
  ];

  const fileCommands: CommandItem[] = files.map(f => ({
    id: `open-file-${f.name}`,
    title: `Open File: ${f.name}`,
    category: 'ASI TOOLS',
    icon: <Code2 size={16} className="text-cyan-400" />,
    payload: f.name
  }));

  const allCommands = [...defaultCommands, ...fileCommands];
  const filteredCommands = allCommands.filter(c => 
    c.title.toLowerCase().includes(search.toLowerCase()) || 
    c.category.toLowerCase().includes(search.toLowerCase())
  );

  useEffect(() => {
    setSelectedIndex(0);
  }, [search]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex(prev => (prev + 1) % filteredCommands.length);
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex(prev => (prev - 1 + filteredCommands.length) % filteredCommands.length);
      }
      if (e.key === 'Enter' && filteredCommands[selectedIndex]) {
        e.preventDefault();
        onSelectCommand(filteredCommands[selectedIndex].id, filteredCommands[selectedIndex].payload);
        onClose();
      }
      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, filteredCommands, selectedIndex, onClose, onSelectCommand]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-start justify-center pt-[12vh] bg-black/70 backdrop-blur-md" onClick={onClose}>
      <div 
        className="w-[92%] max-w-[650px] bg-[#0c0e14] border border-white/15 rounded-2xl shadow-2xl overflow-hidden flex flex-col font-sans"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center px-4 py-3.5 border-b border-white/10 text-white/50 bg-black/40">
          <Search size={20} className="mr-3 text-orange-400" />
          <input 
            ref={inputRef}
            type="text" 
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search AGENTS, SUB-AGENTS, ASI TOOLS, or files... (Cmd+K)" 
            className="w-full bg-transparent text-white text-sm outline-none placeholder:text-white/30"
          />
        </div>
        <div className="max-h-[60vh] overflow-y-auto py-2 custom-scrollbar">
          {filteredCommands.length > 0 ? filteredCommands.map((cmd, idx) => (
            <div 
              key={cmd.id}
              onMouseEnter={() => setSelectedIndex(idx)}
              onClick={() => {
                onSelectCommand(cmd.id, cmd.payload);
                onClose();
              }}
              className={`flex items-center justify-between px-4 py-2.5 mx-2 rounded-xl cursor-pointer transition-all ${
                idx === selectedIndex ? 'bg-orange-500/20 text-white border border-orange-500/30' : 'text-white/70 hover:bg-white/5'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="shrink-0 p-1.5 rounded-lg bg-white/5 border border-white/10">{cmd.icon}</div>
                <div className="truncate text-xs font-semibold">{cmd.title}</div>
              </div>
              <span className={`text-[9px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-md border shrink-0 ${
                cmd.category === 'AGENTS' ? 'bg-orange-500/20 text-orange-300 border-orange-500/30' :
                cmd.category === 'SUB-AGENTS' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' :
                cmd.category === 'ASI TOOLS' ? 'bg-purple-500/20 text-purple-300 border-purple-500/30' :
                'bg-white/10 text-zinc-400 border-white/10'
              }`}>
                {cmd.category}
              </span>
            </div>
          )) : (
            <div className="px-4 py-8 text-center text-white/40 text-xs font-mono">No matching tools or files found.</div>
          )}
        </div>
        <div className="bg-[#06070a] px-4 py-2.5 border-t border-white/10 text-[10px] text-white/40 flex justify-between font-mono">
          <span><kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white/60">↑</kbd> <kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white/60">↓</kbd> navigate</span>
          <span><kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white/60">Enter</kbd> execute</span>
          <span><kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white/60">Esc</kbd> close</span>
        </div>
      </div>
    </div>
  );
};

