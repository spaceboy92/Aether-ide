import path from 'path';
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, '.', '');
    return {
      server: {
        port: 3000,
        host: '0.0.0.0',
        hmr: false,
      },
      plugins: [
        react(), 
        tailwindcss(),
        // VitePWA disabled to avoid OOM during build
      ],
      define: {
        'process.env': {}
      },
      build: {
        sourcemap: false,
        minify: 'esbuild',
        cssMinify: true,
        reportCompressedSize: false,
        chunkSizeWarningLimit: 10000,
        target: 'esnext',
        assetsInlineLimit: 0,
        rollupOptions: {
          maxParallelFileOps: 2,
          output: {
            compact: true,
            manualChunks(id) {
              if (id.includes('node_modules')) {
                if (id.includes('react/') || id.includes('react-dom/') || id.includes('scheduler/')) return 'vendor-react';
                if (id.includes('motion/')) return 'vendor-motion';
                if (id.includes('three')) return 'vendor-three';
                if (id.includes('monaco-editor') || id.includes('@monaco-editor')) return 'vendor-monaco';
                if (id.includes('firebase') || id.includes('@firebase')) return 'vendor-firebase';
                if (id.includes('lucide-react')) return 'vendor-icons';
                if (id.includes('recharts') || id.includes('d3')) return 'vendor-charts';
              }
            }
          }
        }
      },
      optimizeDeps: {
        include: ['react', 'react-dom', 'motion', 'motion/react']
      },
      resolve: {
        alias: {
          '@': path.resolve(__dirname, '.'),
        },
        dedupe: ['react', 'react-dom']
      }
    };
});
