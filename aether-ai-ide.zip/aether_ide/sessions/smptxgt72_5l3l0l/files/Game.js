const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const player = new Player(canvas.width / 2, canvas.height / 2);
let enemies = [];
let frame = 0;
let gameOver = false;

function spawnEnemy() {
    const size = 30 + Math.random() * 30;
    enemies.push({
        x: Math.random() * canvas.width,
        y: -size,
        vx: (Math.random() - 0.5) * 4,
        vy: 2 + Math.random() * 5,
        size: size
    });
}

function update() {
    if (gameOver) return;

    frame++;
    if (frame % 30 === 0) spawnEnemy();

    ctx.fillStyle = 'rgba(5, 5, 5, 0.3)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    player.draw(ctx);

    enemies.forEach((e, index) => {
        e.x += e.vx;
        e.y += e.vy;

        ctx.fillStyle = '#f0f';
        ctx.shadowBlur = 10;
        ctx.shadowColor = '#f0f';
        ctx.fillRect(e.x, e.y, e.size, e.size);
        ctx.shadowBlur = 0;

        // Collision
        const dx = player.x - (e.x + e.size / 2);
        const dy = player.y - (e.y + e.size / 2);
        if (Math.sqrt(dx*dx + dy*dy) < e.size / 2 + 10) {
            gameOver = true;
            alert('Game Over! Refresh to restart.');
        }

        if (e.y > canvas.height) enemies.splice(index, 1);
    });

    requestAnimationFrame(update);
}

window.addEventListener('mousemove', (e) => {
    player.update(e.clientX, e.clientY);
});

update();