// Aether Studio Pro — Unified IDE & Collaborative Whiteboard Engine

document.addEventListener('DOMContentLoaded', () => {
  // ==========================================
  // 1. SOUND SYNTHESIZER (WEB AUDIO API)
  // ==========================================
  let audioCtx = null;
  let soundEnabled = true;

  function initAudio() {
    if (!audioCtx) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (AudioContextClass) audioCtx = new AudioContextClass();
    }
    if (audioCtx && audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  }

  function playSound(type) {
    if (!soundEnabled) return;
    try {
      initAudio();
      if (!audioCtx) return;
      const now = audioCtx.currentTime;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);

      if (type === 'click') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(800, now);
        osc.frequency.exponentialRampToValueAtTime(400, now + 0.05);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
        osc.start(now);
        osc.stop(now + 0.05);
      } else if (type === 'run') {
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(320, now);
        osc.frequency.exponentialRampToValueAtTime(640, now + 0.12);
        gain.gain.setValueAtTime(0.12, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
        osc.start(now);
        osc.stop(now + 0.15);
      } else if (type === 'clear') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(300, now);
        osc.frequency.exponentialRampToValueAtTime(100, now + 0.1);
        gain.gain.setValueAtTime(0.08, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
        osc.start(now);
        osc.stop(now + 0.1);
      } else if (type === 'success') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, now); // C5
        osc.frequency.setValueAtTime(659.25, now + 0.08); // E5
        osc.frequency.setValueAtTime(783.99, now + 0.16); // G5
        gain.gain.setValueAtTime(0.1, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
        osc.start(now);
        osc.stop(now + 0.3);
      }
    } catch (e) {
      // Audio policy safe fallback
    }
  }

  document.addEventListener('pointerdown', () => initAudio(), { once: true });

  // Sound Toggle
  const soundToggleBtn = document.getElementById('soundToggleBtn');
  soundToggleBtn?.addEventListener('click', () => {
    soundEnabled = !soundEnabled;
    soundToggleBtn.innerHTML = soundEnabled 
      ? `<i data-lucide="volume-2" class="w-4 h-4 text-cyan-400"></i>` 
      : `<i data-lucide="volume-x" class="w-4 h-4 text-slate-500"></i>`;
    if (window.lucide) lucide.createIcons();
    playSound('click');
  });

  // ==========================================
  // 2. CODE EDITOR & FILES STATE
  // ==========================================
  const editor = document.getElementById('editor');
  const lineNumbers = document.getElementById('lineNumbers');
  const runCodeBtn = document.getElementById('runCode');
  const clearCodeBtn = document.getElementById('clearCode');
  const formatCodeBtn = document.getElementById('formatCodeBtn');
  const cursorPosDisplay = document.getElementById('cursorPos');
  const consoleLogs = document.getElementById('consoleLogs');
  const clearConsoleBtn = document.getElementById('clearConsoleBtn');
  const execTimeBadge = document.getElementById('execTime');
  const consoleStatusBadge = document.getElementById('consoleStatusBadge');

  const fileTemplates = {
    'script.js': `// ✨ Aether Live JavaScript Playground\n// Access the interactive Whiteboard canvas via 'window.canvas' or 'window.ctx'\n\nfunction generateCollabVisual() {\n  console.log("🚀 Initializing Aether Graphics Pipeline...");\n  const ctx = window.ctx;\n  const w = window.canvas.width;\n  const h = window.canvas.height;\n\n  // Draw glowing futuristic cyber arcs on canvas\n  for (let i = 0; i < 15; i++) {\n    const radius = 40 + i * 18;\n    ctx.beginPath();\n    ctx.arc(w / 2, h / 2, radius, 0, Math.PI * 1.5);\n    ctx.strokeStyle = \`hsla(\${i * 24 + 180}, 90%, 65%, 0.75)\`;\n    ctx.lineWidth = 3;\n    ctx.stroke();\n  }\n  \n  console.info("✨ Rendered 15 geometric resonance circles.");\n  return { status: "SUCCESS", timestamp: Date.now() };\n}\n\nconst result = generateCollabVisual();\nconsole.log("Execution Result:", result);`,
    'index.html': `<!-- Dynamic Template Component -->\n<div class="glass-card p-4 rounded-xl bg-slate-900 border border-slate-700">\n  <h2 class="text-cyan-400 font-bold text-lg">Aether Workspace v2.0</h2>\n  <p class="text-slate-300 text-sm">Collaborative real-time coding & canvas engine.</p>\n</div>`,
    'shader.glsl': `// Procedural Canvas Particles\nlet particles = [];\nfor (let i = 0; i < 60; i++) {\n  particles.push({\n    x: Math.random() * window.canvas.width,\n    y: Math.random() * window.canvas.height,\n    vx: (Math.random() - 0.5) * 2,\n    vy: (Math.random() - 0.5) * 2,\n    color: ['#6366f1', '#06b6d4', '#10b981'][i % 3]\n  });\n}\n\nparticles.forEach(p => {\n  window.ctx.fillStyle = p.color;\n  window.ctx.beginPath();\n  window.ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);\n  window.ctx.fill();\n});\n\nconsole.log("Generated", particles.length, "dynamic cosmic particles!");`
  };

  let currentFile = 'script.js';
  editor.value = fileTemplates['script.js'];

  function updateLineNumbers() {
    const lines = editor.value.split('\n').length;
    lineNumbers.innerHTML = Array.from({ length: lines }, (_, i) => i + 1).join('<br>');
  }

  function updateCursorPos() {
    const selStart = editor.selectionStart;
    const textBefore = editor.value.substring(0, selStart);
    const lines = textBefore.split('\n');
    const currentLine = lines.length;
    const currentCol = lines[lines.length - 1].length + 1;
    cursorPosDisplay.textContent = `Ln ${currentLine}, Col ${currentCol}`;
  }

  editor.addEventListener('input', () => {
    fileTemplates[currentFile] = editor.value;
    updateLineNumbers();
    updateCursorPos();
  });

  editor.addEventListener('keyup', updateCursorPos);
  editor.addEventListener('click', updateCursorPos);
  editor.addEventListener('scroll', () => {
    lineNumbers.scrollTop = editor.scrollTop;
  });

  // Tab Switching
  const fileTabs = document.querySelectorAll('.file-tab');
  fileTabs.forEach(tab => {
    tab.addEventListener('click', () => {
      fileTabs.forEach(t => t.classList.remove('active-tab'));
      tab.classList.add('active-tab');
      const file = tab.getAttribute('data-file');
      currentFile = file;
      editor.value = fileTemplates[file] || '';
      updateLineNumbers();
      updateCursorPos();
      playSound('click');
    });
  });

  // Format Code
  formatCodeBtn?.addEventListener('click', () => {
    playSound('click');
    try {
      const lines = editor.value.split('\n').map(l => l.trimEnd());
      editor.value = lines.join('\n');
      updateLineNumbers();
    } catch (e) {}
  });

  // Clear Code
  clearCodeBtn?.addEventListener('click', () => {
    playSound('clear');
    editor.value = '';
    updateLineNumbers();
    updateCursorPos();
  });

  // Custom Log Append
  function appendConsoleLog(type, ...args) {
    const row = document.createElement('div');
    row.className = 'flex items-start gap-2 text-xs font-mono';
    
    const time = new Date().toLocaleTimeString().split(' ')[0];
    let badge = `<span class="text-slate-500 text-[10px]">[${time}]</span>`;
    let content = args.map(arg => {
      if (typeof arg === 'object') {
        try { return JSON.stringify(arg, null, 2); } catch (e) { return String(arg); }
      }
      return String(arg);
    }).join(' ');

    if (type === 'error') {
      row.innerHTML = `${badge} <span class="text-rose-400 font-semibold">✕ Error:</span> <span class="text-rose-300">${escapeHtml(content)}</span>`;
    } else if (type === 'warn') {
      row.innerHTML = `${badge} <span class="text-amber-400 font-semibold">⚠ Warn:</span> <span class="text-amber-200">${escapeHtml(content)}</span>`;
    } else if (type === 'info') {
      row.innerHTML = `${badge} <span class="text-cyan-400 font-semibold">ℹ Info:</span> <span class="text-cyan-200">${escapeHtml(content)}</span>`;
    } else {
      row.innerHTML = `${badge} <span class="text-emerald-400 font-semibold">›</span> <span class="text-slate-200">${escapeHtml(content)}</span>`;
    }

    consoleLogs.appendChild(row);
    consoleLogs.scrollTop = consoleLogs.scrollHeight;
  }

  function escapeHtml(str) {
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  clearConsoleBtn?.addEventListener('click', () => {
    consoleLogs.innerHTML = `<div class="text-slate-500 italic">// Console cleared</div>`;
    execTimeBadge.textContent = '';
    playSound('click');
  });

  // Run Code Execution
  function executeCode() {
    playSound('run');
    const startTime = performance.now();
    consoleStatusBadge.textContent = 'Executing...';
    consoleStatusBadge.className = 'text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30';

    const originalLog = console.log;
    const originalWarn = console.warn;
    const originalError = console.error;
    const originalInfo = console.info;

    console.log = (...args) => { originalLog(...args); appendConsoleLog('log', ...args); };
    console.warn = (...args) => { originalWarn(...args); appendConsoleLog('warn', ...args); };
    console.error = (...args) => { originalError(...args); appendConsoleLog('error', ...args); };
    console.info = (...args) => { originalInfo(...args); appendConsoleLog('info', ...args); };

    try {
      const runner = new Function('canvas', 'ctx', editor.value);
      runner(canvas, ctx);
      
      const duration = (performance.now() - startTime).toFixed(1);
      execTimeBadge.textContent = `${duration}ms`;
      consoleStatusBadge.textContent = 'Success';
      consoleStatusBadge.className = 'text-[9px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30';
      
      playSound('success');
      if (window.confetti) {
        window.confetti({
          particleCount: 35,
          spread: 60,
          origin: { y: 0.9, x: 0.25 },
          colors: ['#6366f1', '#06b6d4', '#10b981']
        });
      }
    } catch (err) {
      appendConsoleLog('error', err.message);
      consoleStatusBadge.textContent = 'Failed';
      consoleStatusBadge.className = 'text-[9px] px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-400 border border-rose-500/30';
    } finally {
      console.log = originalLog;
      console.warn = originalWarn;
      console.error = originalError;
      console.info = originalInfo;
    }
  }

  runCodeBtn?.addEventListener('click', executeCode);

  // Keyboard Shortcut: Ctrl + Enter to Run
  window.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      executeCode();
    }
  });

  // ==========================================
  // 3. INFINITE WHITEBOARD ENGINE
  // ==========================================
  const canvas = document.getElementById('canvas');
  const ctx = canvas.getContext('2d');
  window.canvas = canvas;
  window.ctx = ctx;

  const colorPicker = document.getElementById('colorPicker');
  const brushSize = document.getElementById('brushSize');
  const brushSizeVal = document.getElementById('brushSizeVal');
  const eraserBtn = document.getElementById('eraserBtn');
  const clearCanvasBtn = document.getElementById('clearCanvas');
  const downloadBtn = document.getElementById('downloadCanvas');
  const stickyLayer = document.getElementById('stickyLayer');
  const gridToggleBtn = document.getElementById('gridToggleBtn');
  const canvasWrapper = document.getElementById('canvasWrapper');

  // Tools
  let activeTool = 'brush'; // 'select', 'brush', 'highlighter', 'rect', 'circle', 'arrow', 'text', 'sticky', 'laser', 'eraser'
  let currentColor = '#6366f1';
  let currentSize = 3;
  let isDrawing = false;
  let startX = 0;
  let startY = 0;
  let zoomLevel = 1.0;
  let historyStack = [];
  let redoStack = [];
  let laserTrails = [];

  function saveCanvasState() {
    if (historyStack.length > 25) historyStack.shift();
    historyStack.push(canvas.toDataURL());
    redoStack = [];
  }

  function restoreCanvasState(dataUrl) {
    const img = new Image();
    img.src = dataUrl;
    img.onload = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);
    };
  }

  function resizeCanvas() {
    const parent = canvas.parentElement;
    if (!parent) return;
    const temp = document.createElement('canvas');
    temp.width = canvas.width;
    temp.height = canvas.height;
    const tCtx = temp.getContext('2d');
    tCtx.drawImage(canvas, 0, 0);

    canvas.width = parent.offsetWidth;
    canvas.height = parent.offsetHeight;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.drawImage(temp, 0, 0);
  }

  window.addEventListener('resize', resizeCanvas);
  setTimeout(() => {
    resizeCanvas();
    updateLineNumbers();
  }, 50);

  // Tool Buttons Setup
  const toolButtons = {
    select: document.getElementById('toolSelect'),
    brush: document.getElementById('toolBrush'),
    highlighter: document.getElementById('toolHighlighter'),
    rect: document.getElementById('toolRect'),
    circle: document.getElementById('toolCircle'),
    arrow: document.getElementById('toolArrow'),
    text: document.getElementById('toolText'),
    sticky: document.getElementById('toolSticky'),
    laser: document.getElementById('toolLaser'),
    eraser: document.getElementById('eraserBtn')
  };

  function setTool(toolName) {
    activeTool = toolName;
    Object.values(toolButtons).forEach(btn => {
      if (!btn) return;
      btn.classList.remove('bg-brand-600', 'text-white', 'active-tool', 'ring-2', 'ring-brand-400');
      btn.classList.add('text-slate-400');
    });
    if (toolButtons[toolName]) {
      toolButtons[toolName].classList.add('bg-brand-600', 'text-white', 'active-tool');
      toolButtons[toolName].classList.remove('text-slate-400');
    }
    playSound('click');
  }

  Object.keys(toolButtons).forEach(name => {
    toolButtons[name]?.addEventListener('click', () => setTool(name));
  });

  // Color Palettes
  document.querySelectorAll('.color-dot').forEach(dot => {
    dot.addEventListener('click', (e) => {
      const color = dot.getAttribute('data-color');
      currentColor = color;
      colorPicker.value = color;
      document.querySelectorAll('.color-dot').forEach(d => d.classList.remove('ring-2', 'ring-white', 'scale-110'));
      dot.classList.add('ring-2', 'ring-white', 'scale-110');
      if (activeTool === 'eraser') setTool('brush');
      playSound('click');
    });
  });

  colorPicker.addEventListener('input', (e) => {
    currentColor = e.target.value;
    if (activeTool === 'eraser') setTool('brush');
  });

  brushSize.addEventListener('input', (e) => {
    currentSize = parseInt(e.target.value, 10);
    brushSizeVal.textContent = currentSize;
  });

  // Pointer Coordinates
  function getPos(e) {
    const rect = canvas.getBoundingClientRect();
    return {
      x: (e.clientX - rect.left) / zoomLevel,
      y: (e.clientY - rect.top) / zoomLevel
    };
  }

  // Canvas Drawing Handlers
  let snapshotData = null;

  function startDraw(e) {
    if (activeTool === 'select') return;
    const pos = getPos(e);
    startX = pos.x;
    startY = pos.y;

    if (activeTool === 'sticky') {
      createStickyNote(pos.x, pos.y);
      setTool('select');
      return;
    }

    if (activeTool === 'text') {
      createInlineText(pos.x, pos.y);
      setTool('select');
      return;
    }

    isDrawing = true;
    saveCanvasState();
    snapshotData = ctx.getImageData(0, 0, canvas.width, canvas.height);

    if (activeTool === 'brush' || activeTool === 'highlighter' || activeTool === 'eraser') {
      ctx.beginPath();
      ctx.moveTo(pos.x, pos.y);
    }
  }

  function draw(e) {
    if (!isDrawing && activeTool !== 'laser') return;
    const pos = getPos(e);

    if (activeTool === 'laser') {
      renderLaserPointer(e.clientX, e.clientY);
      return;
    }

    if (activeTool === 'brush') {
      ctx.strokeStyle = currentColor;
      ctx.lineWidth = currentSize;
      ctx.globalAlpha = 1.0;
      ctx.lineTo(pos.x, pos.y);
      ctx.stroke();
    } else if (activeTool === 'highlighter') {
      ctx.strokeStyle = currentColor;
      ctx.lineWidth = currentSize * 3;
      ctx.globalAlpha = 0.25;
      ctx.lineTo(pos.x, pos.y);
      ctx.stroke();
    } else if (activeTool === 'eraser') {
      ctx.strokeStyle = '#0b0f19';
      ctx.lineWidth = currentSize * 4;
      ctx.globalAlpha = 1.0;
      ctx.lineTo(pos.x, pos.y);
      ctx.stroke();
    } else if (snapshotData && (activeTool === 'rect' || activeTool === 'circle' || activeTool === 'arrow')) {
      ctx.putImageData(snapshotData, 0, 0);
      ctx.strokeStyle = currentColor;
      ctx.lineWidth = currentSize;
      ctx.globalAlpha = 1.0;

      if (activeTool === 'rect') {
        ctx.strokeRect(startX, startY, pos.x - startX, pos.y - startY);
      } else if (activeTool === 'circle') {
        ctx.beginPath();
        const radius = Math.hypot(pos.x - startX, pos.y - startY);
        ctx.arc(startX, startY, radius, 0, Math.PI * 2);
        ctx.stroke();
      } else if (activeTool === 'arrow') {
        drawArrow(startX, startY, pos.x, pos.y);
      }
    }
  }

  function endDraw() {
    if (!isDrawing) return;
    isDrawing = false;
    ctx.globalAlpha = 1.0;
    ctx.beginPath();
  }

  function drawArrow(fromX, fromY, toX, toY) {
    const headlen = 14;
    const angle = Math.atan2(toY - fromY, toX - fromX);
    ctx.beginPath();
    ctx.moveTo(fromX, fromY);
    ctx.lineTo(toX, toY);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(toX, toY);
    ctx.lineTo(toX - headlen * Math.cos(angle - Math.PI / 6), toY - headlen * Math.sin(angle - Math.PI / 6));
    ctx.moveTo(toX, toY);
    ctx.lineTo(toX - headlen * Math.cos(angle + Math.PI / 6), toY - headlen * Math.sin(angle + Math.PI / 6));
    ctx.stroke();
  }

  function renderLaserPointer(clientX, clientY) {
    const rect = canvasWrapper.getBoundingClientRect();
    const dot = document.createElement('div');
    dot.className = 'laser-trail';
    dot.style.left = `${clientX - rect.left}px`;
    dot.style.top = `${clientY - rect.top}px`;
    dot.style.width = '16px';
    dot.style.height = '16px';
    canvasWrapper.appendChild(dot);
    setTimeout(() => dot.remove(), 400);
  }

  // Canvas Events
  canvas.addEventListener('mousedown', startDraw);
  canvas.addEventListener('mousemove', draw);
  canvas.addEventListener('mouseup', endDraw);
  canvas.addEventListener('mouseleave', endDraw);

  // Touch support
  canvas.addEventListener('touchstart', (e) => { e.preventDefault(); startDraw(e.touches[0]); }, { passive: false });
  canvas.addEventListener('touchmove', (e) => { e.preventDefault(); draw(e.touches[0]); }, { passive: false });
  canvas.addEventListener('touchend', endDraw);

  // Sticky Notes System
  function createStickyNote(x, y) {
    playSound('click');
    const note = document.createElement('div');
    const colors = ['sticky-note-yellow', 'sticky-note-pink', 'sticky-note-blue'];
    const chosen = colors[Math.floor(Math.random() * colors.length)];
    note.className = `sticky-note-element ${chosen}`;
    note.style.left = `${x}px`;
    note.style.top = `${y}px`;
    
    note.innerHTML = `
      <div class="flex justify-between items-center mb-1 text-[10px] opacity-75 font-mono">
        <span>STICKY NOTE</span>
        <button class="remove-sticky text-black hover:opacity-100 font-bold">✕</button>
      </div>
      <div contenteditable="true" class="outline-none min-h-[60px] text-xs leading-relaxed">Type ideas, tasks, or code architecture notes here...</div>
    `;

    stickyLayer.appendChild(note);

    // Enable drag
    let isDragging = false, offX = 0, offY = 0;
    note.addEventListener('mousedown', (e) => {
      if (e.target.classList.contains('remove-sticky')) {
        note.remove();
        playSound('clear');
        return;
      }
      if (e.target.getAttribute('contenteditable') === 'true') return;
      isDragging = true;
      offX = e.clientX - note.offsetLeft;
      offY = e.clientY - note.offsetTop;
    });

    window.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      note.style.left = `${e.clientX - offX}px`;
      note.style.top = `${e.clientY - offY}px`;
    });

    window.addEventListener('mouseup', () => isDragging = false);
  }

  function createInlineText(x, y) {
    const text = prompt('Enter Whiteboard Text:', 'Architecture Sync');
    if (text) {
      saveCanvasState();
      ctx.font = 'bold 18px "Plus Jakarta Sans", sans-serif';
      ctx.fillStyle = currentColor;
      ctx.fillText(text, x, y);
    }
  }

  // Undo / Redo
  const undoBtn = document.getElementById('undoBtn');
  const redoBtn = document.getElementById('redoBtn');

  undoBtn?.addEventListener('click', () => {
    if (historyStack.length > 0) {
      redoStack.push(canvas.toDataURL());
      const last = historyStack.pop();
      restoreCanvasState(last);
      playSound('click');
    }
  });

  redoBtn?.addEventListener('click', () => {
    if (redoStack.length > 0) {
      historyStack.push(canvas.toDataURL());
      const next = redoStack.pop();
      restoreCanvasState(next);
      playSound('click');
    }
  });

  // Clear Canvas
  clearCanvasBtn?.addEventListener('click', () => {
    playSound('clear');
    saveCanvasState();
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    stickyLayer.innerHTML = '';
  });

  // Export Canvas
  downloadBtn?.addEventListener('click', () => {
    playSound('success');
    const exportCanvas = document.createElement('canvas');
    exportCanvas.width = canvas.width;
    exportCanvas.height = canvas.height;
    const eCtx = exportCanvas.getContext('2d');
    eCtx.fillStyle = '#0b0f19';
    eCtx.fillRect(0, 0, exportCanvas.width, exportCanvas.height);
    eCtx.drawImage(canvas, 0, 0);

    const link = document.createElement('a');
    link.download = `aether-whiteboard-${Date.now()}.png`;
    link.href = exportCanvas.toDataURL('image/png');
    link.click();
  });

  // Grid Pattern Toggle
  let gridStyle = 0;
  gridToggleBtn?.addEventListener('click', () => {
    playSound('click');
    gridStyle = (gridStyle + 1) % 3;
    canvasWrapper.classList.remove('bg-grid-pattern', 'bg-isometric-pattern');
    if (gridStyle === 0) canvasWrapper.classList.add('bg-grid-pattern');
    else if (gridStyle === 1) canvasWrapper.classList.add('bg-isometric-pattern');
  });

  // Zoom Controls
  const zoomInBtn = document.getElementById('zoomInBtn');
  const zoomOutBtn = document.getElementById('zoomOutBtn');
  const zoomResetBtn = document.getElementById('zoomResetBtn');
  const zoomDisplay = document.getElementById('zoomDisplay');

  function updateZoom(newZoom) {
    zoomLevel = Math.max(0.4, Math.min(2.5, newZoom));
    zoomDisplay.textContent = `${Math.round(zoomLevel * 100)}%`;
    canvas.style.transformOrigin = '0 0';
    canvas.style.transform = `scale(${zoomLevel})`;
  }

  zoomInBtn?.addEventListener('click', () => updateZoom(zoomLevel + 0.15));
  zoomOutBtn?.addEventListener('click', () => updateZoom(zoomLevel - 0.15));
  zoomResetBtn?.addEventListener('click', () => updateZoom(1.0));

  // ==========================================
  // 4. VIEW LAYOUT SWITCHER
  // ==========================================
  const viewSplitBtn = document.getElementById('viewSplitBtn');
  const viewEditorBtn = document.getElementById('viewEditorBtn');
  const viewCanvasBtn = document.getElementById('viewCanvasBtn');
  const editorSection = document.getElementById('editorSection');
  const canvasSection = document.getElementById('canvasSection');

  function setViewMode(mode) {
    [viewSplitBtn, viewEditorBtn, viewCanvasBtn].forEach(b => {
      b.classList.remove('bg-brand-600', 'text-white', 'shadow-sm');
      b.classList.add('text-slate-400');
    });

    if (mode === 'split') {
      viewSplitBtn.classList.add('bg-brand-600', 'text-white', 'shadow-sm');
      editorSection.style.display = 'flex';
      editorSection.style.width = '50%';
      canvasSection.style.display = 'flex';
      canvasSection.style.width = '50%';
    } else if (mode === 'editor') {
      viewEditorBtn.classList.add('bg-brand-600', 'text-white', 'shadow-sm');
      editorSection.style.display = 'flex';
      editorSection.style.width = '100%';
      canvasSection.style.display = 'none';
    } else if (mode === 'canvas') {
      viewCanvasBtn.classList.add('bg-brand-600', 'text-white', 'shadow-sm');
      editorSection.style.display = 'none';
      canvasSection.style.display = 'flex';
      canvasSection.style.width = '100%';
    }
    setTimeout(resizeCanvas, 50);
  }

  viewSplitBtn?.addEventListener('click', () => setViewMode('split'));
  viewEditorBtn?.addEventListener('click', () => setViewMode('editor'));
  viewCanvasBtn?.addEventListener('click', () => setViewMode('canvas'));

  // ==========================================
  // 5. SIMULATED PEER COLLABORATION CURSORS
  // ==========================================
  const peer1 = document.getElementById('peerCursor1');
  const peer2 = document.getElementById('peerCursor2');
  let angle1 = 0, angle2 = Math.PI;

  function animatePeers() {
    if (peer1 && peer2) {
      angle1 += 0.015;
      angle2 += 0.02;
      const cx1 = 280 + Math.sin(angle1) * 140;
      const cy1 = 260 + Math.cos(angle1 * 1.5) * 90;
      const cx2 = 480 + Math.cos(angle2) * 160;
      const cy2 = 360 + Math.sin(angle2 * 1.2) * 110;
      
      peer1.style.transform = `translate(${cx1}px, ${cy1}px)`;
      peer2.style.transform = `translate(${cx2}px, ${cy2}px)`;
    }
    requestAnimationFrame(animatePeers);
  }
  animatePeers();

  // ==========================================
  // 6. MODALS: SHARE, SHORTCUTS, SNIPPETS
  // ==========================================
  const shareModalBtn = document.getElementById('shareModalBtn');
  const shareModal = document.getElementById('shareModal');
  const closeShareModal = document.getElementById('closeShareModal');
  const copyLinkBtn = document.getElementById('copyLinkBtn');

  shareModalBtn?.addEventListener('click', () => {
    shareModal.classList.remove('hidden');
    shareModal.classList.add('flex');
    playSound('click');
  });
  closeShareModal?.addEventListener('click', () => {
    shareModal.classList.add('hidden');
    shareModal.classList.remove('flex');
  });
  copyLinkBtn?.addEventListener('click', () => {
    const copyInput = document.getElementById('shareUrlInput');
    copyInput.select();
    navigator.clipboard.writeText(copyInput.value);
    copyLinkBtn.innerHTML = `<i data-lucide="check" class="w-3.5 h-3.5"></i> Copied!`;
    if (window.lucide) lucide.createIcons();
    playSound('success');
    setTimeout(() => {
      copyLinkBtn.innerHTML = `<i data-lucide="copy" class="w-3.5 h-3.5"></i> Copy`;
      if (window.lucide) lucide.createIcons();
    }, 2000);
  });

  // Shortcuts Modal
  const shortcutsBtn = document.getElementById('shortcutsBtn');
  const shortcutsModal = document.getElementById('shortcutsModal');
  const closeShortcutsModal = document.getElementById('closeShortcutsModal');

  shortcutsBtn?.addEventListener('click', () => {
    shortcutsModal.classList.remove('hidden');
    shortcutsModal.classList.add('flex');
    playSound('click');
  });
  closeShortcutsModal?.addEventListener('click', () => {
    shortcutsModal.classList.add('hidden');
    shortcutsModal.classList.remove('flex');
  });

  // Snippets Modal
  const snippetsBtn = document.getElementById('snippetsBtn');
  const snippetsModal = document.getElementById('snippetsModal');
  const closeSnippetsModal = document.getElementById('closeSnippetsModal');

  snippetsBtn?.addEventListener('click', () => {
    snippetsModal.classList.remove('hidden');
    snippetsModal.classList.add('flex');
    playSound('click');
  });
  closeSnippetsModal?.addEventListener('click', () => {
    snippetsModal.classList.add('hidden');
    snippetsModal.classList.remove('flex');
  });

  document.querySelectorAll('.snippet-item').forEach(item => {
    item.addEventListener('click', () => {
      const snippetType = item.getAttribute('data-snippet');
      if (snippetType === 'particles') {
        editor.value = fileTemplates['shader.glsl'];
      } else if (snippetType === 'fibonacci') {
        editor.value = `// ⚡ High-Speed Quicksort & Prime Telemetry\nfunction benchmark() {\n  console.time("Quicksort 10k Items");\n  const arr = Array.from({ length: 10000 }, () => Math.floor(Math.random() * 100000));\n  arr.sort((a, b) => a - b);\n  console.timeEnd("Quicksort 10k Items");\n\n  console.info("Sorted Sample:", arr.slice(0, 5), "...", arr.slice(-5));\n  return { count: arr.length, median: arr[5000] };\n}\n\nconsole.log("Benchmark Result:", benchmark());`;
      } else if (snippetType === 'audio') {
        editor.value = `// 🎵 Web Audio Synth Arpeggio\nconst ctx = new (window.AudioContext || window.webkitAudioContext)();\nconst notes = [261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 493.88, 523.25];\n\nnotes.forEach((freq, idx) => {\n  setTimeout(() => {\n    const osc = ctx.createOscillator();\n    const gain = ctx.createGain();\n    osc.type = 'triangle';\n    osc.frequency.value = freq;\n    osc.connect(gain);\n    gain.connect(ctx.destination);\n    gain.gain.setValueAtTime(0.1, ctx.currentTime);\n    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.35);\n    osc.start();\n    osc.stop(ctx.currentTime + 0.35);\n    console.info("Playing note:", freq.toFixed(1) + "Hz");\n  }, idx * 140);\n});`;
      }
      snippetsModal.classList.add('hidden');
      snippetsModal.classList.remove('flex');
      updateLineNumbers();
      playSound('success');
    });
  });

  // Keyboard Shortcuts (B, E, N, L, V)
  window.addEventListener('keydown', (e) => {
    if (document.activeElement === editor || document.activeElement.getAttribute('contenteditable') === 'true') return;
    const key = e.key.toLowerCase();
    if (key === 'b') setTool('brush');
    else if (key === 'e') setTool('eraser');
    else if (key === 'n') setTool('sticky');
    else if (key === 'l') setTool('laser');
    else if (key === 'v') setTool('select');
    else if (key === 'r') setTool('rect');
    else if (key === 'c') setTool('circle');
  });
});