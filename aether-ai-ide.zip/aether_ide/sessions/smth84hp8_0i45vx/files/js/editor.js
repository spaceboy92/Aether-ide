// Code Editor & Virtual File System
window.AetherEditor = (function() {
    const defaultFiles = {
        'index.html': `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>App</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="style.css">
</head>
<body class="bg-zinc-900 flex items-center justify-center h-screen">
  <div class="text-center">
    <h1 class="text-4xl font-bold text-white mb-4 animate-bounce">Hello Aether!</h1>
    <button id="btn" class="px-6 py-2 bg-orange-500 hover:bg-orange-400 text-black font-bold rounded-full transition-transform active:scale-95">
      Click Me
    </button>
  </div>
  <script src="script.js"></script>
</body>
</html>`,
        'style.css': `/* Add your styles here */
body {
  font-family: system-ui, sans-serif;
  margin: 0;
  overflow: hidden;
}`,
        'script.js': `// Add your logic here
console.log("Application started.");

const btn = document.getElementById('btn');
let count = 0;

if(btn) {
  btn.addEventListener('click', () => {
    count++;
    btn.textContent = \`Clicked \${count} times\`;
    console.log("Button clicked! Count:", count);
  });
}`
    };

    let files = { ...defaultFiles };
    let activeFile = 'index.html';
    let isSyncing = false;

    // DOM Elements
    const textArea = document.getElementById('code-editor');
    const fileTree = document.getElementById('file-tree');
    const editorTabs = document.getElementById('editor-tabs');
    const previewFrame = document.getElementById('preview-frame');
    const refreshBtn = document.getElementById('refresh-preview');

    // Initialize CodeMirror
    const editor = CodeMirror.fromTextArea(textArea, {
        mode: 'htmlmixed',
        theme: 'material-palenight',
        lineNumbers: true,
        autoCloseTags: true,
        autoCloseBrackets: true,
        tabSize: 2,
        indentUnit: 2
    });

    // File mapping modes
    const modeMap = {
        'html': 'htmlmixed',
        'css': 'css',
        'js': 'javascript'
    };

    function getFileExtension(filename) {
        return filename.split('.').pop();
    }

    function renderFileTree() {
        fileTree.innerHTML = '';
        editorTabs.innerHTML = '';

        Object.keys(files).forEach(filename => {
            const ext = getFileExtension(filename);
            
            // Sidebar Item
            const item = document.createElement('div');
            item.className = `px-4 py-1.5 text-sm cursor-pointer flex items-center gap-2 transition-colors ${activeFile === filename ? 'bg-zinc-800/50 text-white border-l-2 border-orange-500' : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/30'}`;
            
            let icon = 'file';
            if(ext === 'html') icon = 'file-code';
            if(ext === 'css') icon = 'file';
            if(ext === 'js') icon = 'file-code';

            item.innerHTML = `<i data-lucide="${icon}" class="w-4 h-4 ${ext==='html'?'text-orange-400':ext==='css'?'text-blue-400':'text-yellow-400'}"></i> ${filename}`;
            item.addEventListener('click', () => switchFile(filename));
            fileTree.appendChild(item);

            // Top Tab
            const tab = document.createElement('div');
            tab.className = `px-3 py-1.5 text-xs flex items-center gap-2 cursor-pointer border-r border-zinc-800 transition-colors ${activeFile === filename ? 'bg-zinc-950 text-white border-t-2 border-t-orange-500' : 'bg-zinc-900 text-zinc-500 hover:bg-zinc-800'}`;
            tab.innerHTML = `<span>${filename}</span>`;
            tab.addEventListener('click', () => switchFile(filename));
            editorTabs.appendChild(tab);
        });
        lucide.createIcons();
    }

    function switchFile(filename) {
        // Save current
        files[activeFile] = editor.getValue();
        
        activeFile = filename;
        const ext = getFileExtension(filename);
        
        editor.setOption('mode', modeMap[ext] || 'javascript');
        editor.setValue(files[filename]);
        
        renderFileTree();
    }

    // Console Interceptor Script to inject into iframe
    const consoleInterceptor = `
        <script>
            (function() {
                const originalConsole = window.console;
                function safeArgs(args) {
                    return Array.from(args).map(arg => {
                        try {
                            if (arg instanceof Error) return arg.message + (arg.stack ? '\\n' + arg.stack : '');
                            return typeof arg === 'object' ? JSON.parse(JSON.stringify(arg)) : arg;
                        } catch(e) {
                            return String(arg);
                        }
                    });
                }
                window.console = {
                    log: function(...args) { window.parent.postMessage({ source: 'aether-preview', type: 'log', args: safeArgs(args) }, '*'); originalConsole.log.apply(originalConsole, args); },
                    warn: function(...args) { window.parent.postMessage({ source: 'aether-preview', type: 'warn', args: safeArgs(args) }, '*'); originalConsole.warn.apply(originalConsole, args); },
                    error: function(...args) { window.parent.postMessage({ source: 'aether-preview', type: 'error', args: safeArgs(args) }, '*'); originalConsole.error.apply(originalConsole, args); }
                };
                window.onerror = function(msg, url, line, col, error) {
                    window.parent.postMessage({ source: 'aether-preview', type: 'error', args: [\`\${msg} at \${line}:\${col}\`] }, '*');
                    return false;
                };
            })();
        </script>
    `;

    function updatePreview() {
        // Save current active file content
        files[activeFile] = editor.getValue();

        let htmlContent = files['index.html'] || '';
        const cssContent = files['style.css'] || '';
        const jsContent = files['script.js'] || '';

        // Inject CSS
        if (cssContent) {
            const styleTag = `<style>${cssContent}</style>`;
            if (htmlContent.includes('</head>')) {
                htmlContent = htmlContent.replace('</head>', `${styleTag}</head>`);
            } else {
                htmlContent += styleTag;
            }
        }

        // Inject Interceptor & JS
        const scriptTag = `<script>${jsContent}</script>`;
        if (htmlContent.includes('</body>')) {
            htmlContent = htmlContent.replace('</body>', `${consoleInterceptor}${scriptTag}</body>`);
        } else {
            htmlContent += consoleInterceptor + scriptTag;
        }

        // Write to iframe
        const blob = new Blob([htmlContent], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        previewFrame.src = url;
    }

    // Debounce preview update and sync
    let timeout;
    editor.on('change', () => {
        if (isSyncing) return; // Prevent echo loops

        clearTimeout(timeout);
        timeout = setTimeout(() => {
            files[activeFile] = editor.getValue();
            updatePreview();
            
            // Broadcast change
            if (window.AetherSync) {
                window.AetherSync.broadcast('FILE_UPDATE', {
                    filename: activeFile,
                    content: files[activeFile]
                });
            }
        }, 500);
    });

    refreshBtn.addEventListener('click', updatePreview);

    // Initial setup
    editor.setValue(files[activeFile]);
    renderFileTree();
    setTimeout(updatePreview, 1000); // Initial render

    return {
        refresh: () => setTimeout(() => editor.refresh(), 10),
        receiveSync: (filename, content) => {
            files[filename] = content;
            if (filename === activeFile) {
                isSyncing = true;
                const cursor = editor.getCursor();
                editor.setValue(content);
                editor.setCursor(cursor);
                isSyncing = false;
            }
            updatePreview();
        }
    };
})();