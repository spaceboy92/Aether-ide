const axios = require('axios');
(async () => {
  try {
    const res = await axios.post('http://localhost:3000/api/ollama/proxy', {
      serverUrl: 'https://api.openai.com',
      apiKey: 'sk-12345',
      endpoint: '/api/chat',
      method: 'POST',
      body: {
        model: 'gpt-3.5-turbo',
        messages: [{role: 'user', content: 'hello'}],
        stream: false
      }
    });
    console.log("Success:", res.data);
  } catch (err) {
    console.log("Error status:", err.response?.status);
    console.log("Error data:", err.response?.data);
  }
})();
