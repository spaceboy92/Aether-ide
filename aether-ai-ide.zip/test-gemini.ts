import { GoogleGenAI, Type } from "@google/genai";
async function test() {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  const schema = {
    type: Type.OBJECT,
    properties: {
      message: { type: Type.STRING },
      files: { type: Type.ARRAY, items: { type: Type.OBJECT, properties: { path: { type: Type.STRING }, code: { type: Type.STRING } } } }
    }
  };
  try {
    await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: "Hello",
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
        tools: [{ codeExecution: {} }]
      }
    });
    console.log("Success without thinkingConfig");
  } catch (e) { console.error("Error without thinkingConfig:", e.message); }

  try {
    await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: "Hello",
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
        tools: [{ codeExecution: {} }],
        thinkingConfig: { thinkingLevel: 1 }
      }
    });
    console.log("Success with thinkingConfig");
  } catch (e) { console.error("Error with thinkingConfig:", e.message); }
}
test();
