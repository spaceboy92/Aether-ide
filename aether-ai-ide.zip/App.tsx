import React, {
  useEffect,
  useState,
  useCallback,
  useRef,
  useMemo,
  Suspense,
  lazy,
} from "react";
import { AnimatePresence, motion, MotionConfig } from "motion/react";
import { useAuth } from "./hooks/useAuth";

import {
  applyPerformanceSettings,
} from "./utils/appUtils";
import {
  saveFile,
  saveFiles,
  generateStandaloneHTML,
  saveFullSession,
  exportProjectToZip,
  triggerFileDownload,
  getDefaultTemplate,
  applySearchReplace,
} from "./services/fileService";
import { getTemplateById } from "./services/projectTemplates";
import {
  FileNode,
  AgentAction,
  ChatSession,
} from "./types";
import { useAutonomousAgent } from "./hooks/useAutonomousAgent";
import { useSessionSnapshot } from "./hooks/useSessionSnapshot";
import { formatSmartTitleFromPrompt, extractAppNameFromFiles } from "./services/chatIdentityService";
import SystemLoader from "./components/UI/SystemLoader";

import { generateId } from "./utils/id";
import { 
  chatWithAI,
  MODELS
} from "./services/geminiService";
import { classifyIntentAndDivision } from "./components/AI/AIAssistant/orchestratorClassifier";
import { backupToDrive } from "./services/workspaceService";
import ErrorBoundary from "./components/UI/ErrorBoundary";
import { connectivityService } from "./services/connectivityService";
import { apiKeyRefreshService } from "./services/apiKeyRefreshService";
import { storageService } from "./services/storageService";
import { NotificationToast } from "./components/UI/NotificationSystem";
import { formatterService } from "./services/formatterService";
import { aetherAstEngine } from "./services/aetherAstEngine";
import { opfsService } from "./services/opfsService";

import { useAppUI } from "./hooks/useAppUI";
import { useAppSessions } from "./hooks/useAppSessions";
import { useAppFileSystem } from "./hooks/useAppFileSystem";
import { useAppDiagnostics } from "./hooks/useAppDiagnostics";
import { useUserInitialization } from "./hooks/useUserInitialization";

import MonacoEditorWrapper from "./components/Editor/MonacoEditorWrapper";
import PreviewPane from "./components/Preview/PreviewPane";
import AIAssistant from "./components/AI/AIAssistant";
import FileExplorer from "./components/Files/FileExplorer";

// Dynamic import retry helper to prevent transient chunk fetch errors
const lazyWithRetry = <T extends React.ComponentType<any>>(factory: () => Promise<any>) =>
  lazy(async () => {
    try {
      const module = await factory();
      return 'default' in module ? module : { default: module };
    } catch (error) {
      console.warn("Dynamic module import failed, retrying...", error);
      await new Promise((res) => setTimeout(res, 300));
      try {
        const module = await factory();
        return 'default' in module ? module : { default: module };
      } catch (retryError) {
        console.error("Dynamic module import failed after retry:", retryError);
        throw retryError;
      }
    }
  });

// Lazy loaded secondary components
const ImageAssetViewer = lazyWithRetry(() => import("./components/Editor/ImageAssetViewer").then(m => ({ default: m.ImageAssetViewer })));
const SettingsView = lazyWithRetry(() => import("./components/Settings/SettingsView"));
const CustomizerView = lazyWithRetry(() => import("./components/Settings/CustomizerView"));
const SearchView = lazyWithRetry(() => import("./components/Files/SearchView"));
const ResourceDashboard = lazyWithRetry(() => import("./components/UI/ResourceDashboard"));
const FileHistoryView = lazyWithRetry(() => import("./components/Files/FileHistoryView"));
const SystemTerminal = lazyWithRetry(() => import("./components/Tools/SystemTerminal"));
const MasterpieceUI = lazyWithRetry(() => import("./components/Studio/MasterpieceUI"));
const ChatsPage = lazyWithRetry(() => import("./components/Studio/ChatsPage"));
const AppGallery = lazyWithRetry(() => import("./components/Gallery/AppGallery"));
const Studio3DGameEngine = lazyWithRetry(() => import("./components/Studio/Studio3DGameEngine").then(m => ({ default: m.Studio3DGameEngine })));
const EvolutionCore = lazyWithRetry(() => import("./components/Tools/EvolutionCore").then(m => ({ default: m.EvolutionCore })));
const LoginScreen = lazyWithRetry(() => import("./components/Auth/LoginScreen"));
const BlackHoleBackground = lazyWithRetry(() => import("./components/UI/BlackHoleBackground"));
const CommandPalette = lazyWithRetry(() => import("./components/Layout/CommandPalette"));
const ShareModal = lazyWithRetry(() => import("./components/Layout/ShareModal"));
const OllamaIntegrationModal = lazyWithRetry(() => import("./components/Tools/OllamaIntegrationModal").then(m => ({ default: m.OllamaIntegrationModal })));
const GitHubSyncModal = lazyWithRetry(() => import("./components/Tools/GitHubSyncModal").then(m => ({ default: m.GitHubSyncModal })));
const DeployModal = lazyWithRetry(() => import("./components/Tools/DeployModal").then(m => ({ default: m.DeployModal })));
const CollaborationModal = lazyWithRetry(() => import("./components/Tools/CollaborationModal").then(m => ({ default: m.CollaborationModal })));
const MoatInspectorModal = lazyWithRetry(() => import("./components/Tools/MoatInspectorModal").then(m => ({ default: m.MoatInspectorModal })));
const ApiPlayground = lazyWithRetry(() => import("./components/Tools/ApiPlayground"));
const SecurityScannerView = lazyWithRetry(() => import("./components/Tools/SecurityScannerView"));
const DatabaseStudio = lazyWithRetry(() => import("./components/Tools/DatabaseStudio"));
const DataTransformerStudio = lazyWithRetry(() => import("./components/Tools/DataTransformerStudio"));
const PerformanceProfiler = lazyWithRetry(() => import("./components/Tools/PerformanceProfiler"));
const AudioSynthStudio = lazyWithRetry(() => import("./components/Tools/AudioSynthStudio"));
const UIComponentStudio = lazyWithRetry(() => import("./components/Tools/UIComponentStudio"));
const DependencyGraphStudio = lazyWithRetry(() => import("./components/Tools/DependencyGraphStudio"));
const TaskRunnerView = lazyWithRetry(() => import("./components/Tools/TaskRunnerView"));
const JWTDecoder = lazyWithRetry(() => import("./components/Tools/JWTDecoder").then(m => ({ default: m.JWTDecoder })));
const EnvManager = lazyWithRetry(() => import("./components/Tools/EnvManager").then(m => ({ default: m.EnvManager })));

import { socketService } from "./services/socketService";
import { useCloudSync } from "./hooks/useCloudSync";
import PCWorkspace from "./components/Layout/PCWorkspace";
import MobileWorkspace from "./components/Layout/MobileWorkspace";

const App = () => {
  const {
    user,
    loading: authLoading,
    completeLogin,
    loginGuest,
    logout,
    nuclearReset,
    updateUser,
  } = useAuth();

  const ui = useAppUI();
  const diagnostics = useAppDiagnostics();
  const { addLog, setTerminalLogs, terminalLogs, systemStats } = diagnostics;
  
  const [perfMode, setPerfMode] = useState<"high" | "low">(() => {
    try {
      return (localStorage.getItem('aether_perf_mode') as "high" | "low") || "high";
    } catch (e) {
      console.warn("Storage is disabled, defaulting to high performance mode:", e);
      return "high";
    }
  });
  const [chatCompactMode, setChatCompactMode] = useState<boolean>(true);
  const [autoPilotMode, setAutoPilotMode] = useState<boolean>(true);
  const [isMobile, setIsMobile] = useState<boolean>(() => {
    if (typeof window !== "undefined") {
      return window.innerWidth < 1024;
    }
    return false;
  });

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 1024);
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('aether_perf_mode', perfMode);
    } catch (e) {
      console.warn("Storage write failed:", e);
    }
    applyPerformanceSettings();
  }, [perfMode]);

  const sessionsState = useAppSessions(user, false, addLog);
  const { sessions, setSessions, activeSessionId, setActiveSessionId, autoSave } = sessionsState;

  const fileSystem = useAppFileSystem(activeSessionId);
  const { files, setFiles, activeFileId, setActiveFileId, handleRenameFile } = fileSystem;

  useUserInitialization(user, updateUser, completeLogin, addLog, setPerfMode);

  const [activeUsers, setActiveUsers] = useState<any[]>([]);
  const [remoteCursors, setRemoteCursors] = useState<any[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<"online" | "offline">(connectivityService.getStatus());
  const [pendingPrompt, setPendingPrompt] = useState<string | null>(null);
  const [gameEnginePrompt, setGameEnginePrompt] = useState<string>("");
  const [currentShareUrl, setCurrentShareUrl] = useState("");
  const [showOllamaModal, setShowOllamaModal] = useState(false);
  const [showGitHubModal, setShowGitHubModal] = useState(false);
  const [showDeployModal, setShowDeployModal] = useState(false);
  const [showCollaborationModal, setShowCollaborationModal] = useState(false);
  const [showMoatModal, setShowMoatModal] = useState(false);

  // OPFS Offline Workspace Caching Effect
  useEffect(() => {
    if (activeSessionId && files.length > 0) {
      const timer = setTimeout(() => {
        opfsService.saveToOPFSCache(activeSessionId, files).catch(console.error);
      }, 1000); // Debounce OPFS writes by 1s
      return () => clearTimeout(timer);
    }
  }, [activeSessionId, files]);

  // Check if workspace contains web-related files
  const hasWebFiles = useMemo(() => {
    if (!files || files.length === 0) return true;
    return files.some((f) => {
      const name = f.name.toLowerCase();
      const ext = name.split('.').pop() || '';
      if (['html', 'htm', 'jsx', 'tsx', 'vue', 'svelte', 'css', 'scss', 'js', 'ts'].includes(ext)) {
        return true;
      }
      const content = (f.content || "").toLowerCase();
      return content.includes('<html') || content.includes('<div') || content.includes('react') || content.includes('vite') || content.includes('express');
    });
  }, [files]);

  useEffect(() => {
    if (!hasWebFiles && (ui.activeTab === "preview" || (ui.activeTab as string) === "split")) {
      ui.setActiveTab("editor");
    }
  }, [hasWebFiles, ui.activeTab]);

  const handleClearMemory = useCallback(() => {
    setTerminalLogs(prev => prev.slice(-10));
    setSessions(prev => prev.map(s => s.messages.length > 5 ? { ...s, messages: s.messages.slice(-5) } : s));
    addLog("success", "Extreme Memory Purge: Radically pruned session history and terminal logs.", "SYSTEM");
  }, [addLog, setTerminalLogs, setSessions]);

  useEffect(() => {
    if (activeSessionId && user) {
      const handleCursor = ({ userId, position }: any) => {
        setRemoteCursors((prev) => {
          const filtered = prev.filter((c) => c.userId !== userId);
          return [...filtered, { userId, position, userName: "Contributor", color: "#00ffd4" }];
        });
      };
      socketService.onCursor(handleCursor);
      return () => { socketService.off('user-cursor-moved', handleCursor); };
    }
  }, [activeSessionId, user]);

  useEffect(() => {
    if (user) {
      socketService.connect();
      socketService.registerUser({
        id: user.id,
        name: user.name || "Incognito",
        photoURL: user.photoURL || `https://ui-avatars.com/api/?name=${user.name}&background=random`,
      });
      const handlePresence = (users: any[]) => setActiveUsers(users);
      socketService.onPresenceUpdate(handlePresence);
      return () => { socketService.off('presence-update', handlePresence); }
    }
  }, [user]);

  useEffect(() => {
    apiKeyRefreshService.init();
    const unsub = connectivityService.subscribe((status) => {
      setConnectionStatus(status);
      addLog(status === "online" ? "success" : "warn", `Aether connection status changed: ${status.toUpperCase()}`);
    });
    return unsub;
  }, [addLog]);

  useEffect(() => {
    const handleOpenTool = (e: any) => {
      const tool = e.detail?.tool;
      if (tool === 'jwt_decoder') ui.setShowJwtDecoder(true);
      if (tool === 'env_manager') ui.setShowEnvManager(true);
    };
    window.addEventListener('aether-open-tool', handleOpenTool);
    return () => window.removeEventListener('aether-open-tool', handleOpenTool);
  }, [ui]);

  const { googleDriveConnected } = useCloudSync(user, connectionStatus, addLog);

  const activeSession = sessions.find((s) => s.id === activeSessionId);
  const sendMessageRef = useRef<any>(null);

  useEffect(() => {
    const handleInsertPrompt = (e: any) => {
      if (e.detail && e.detail.prompt) {
        const promptText = e.detail.prompt;
        const isAutoSubmit = e.detail.autoSubmit;

        // Force open chat panel
        if (window.innerWidth < 1024) {
          window.dispatchEvent(new CustomEvent('aether-switch-mobile-tab', { detail: { tab: 'assistant' } }));
        } else {
          // Tell PC Workspace to open the chat pane
          window.dispatchEvent(new CustomEvent('aether-open-chat'));
        }

        if (isAutoSubmit) {
          const finalPrompt = "[CODE AUDITOR & DEBUGGER Core Agent Engaged: Carefully inspect the current project state, active files, and syntax for any compile errors, unclosed HTML/React tags, unclosed brackets, or run-time exceptions. Fix them with targeted updates.]\n\n" + promptText;
          
          setTimeout(() => {
            if (sendMessageRef.current && activeSession) {
              const classification = classifyIntentAndDivision(finalPrompt, "", finalPrompt, files, "AUTO", []);
              const modelToUse = user?.aiSettings?.defaultModel || MODELS.AETHER_PRO;
              sendMessageRef.current(finalPrompt, [], modelToUse, false, activeSession, classification.spawnedAgents || ["fix_agent", "error_analyzer", "root_cause"]);
            } else {
              setPendingPrompt(finalPrompt);
            }
          }, 150);
        }
      }
    };

    window.addEventListener('aether-insert-ai-prompt', handleInsertPrompt as EventListener);
    return () => window.removeEventListener('aether-insert-ai-prompt', handleInsertPrompt as EventListener);
  }, [activeSession, files, user?.aiSettings?.defaultModel, ui]);

  const handleUpdateSession = useCallback((updatedSession: ChatSession) => {
    setSessions((prev) => {
      const exists = prev.some((s) => s.id === updatedSession.id);
      const nextSessions = exists
        ? prev.map((s) => (s.id === updatedSession.id ? updatedSession : s))
        : [updatedSession, ...prev];
      if (activeSessionId === updatedSession.id) {
        autoSave(updatedSession.id, files, nextSessions);
      }
      return nextSessions;
    });
  }, [activeSessionId, files, setSessions, autoSave]);

  const handleDeploy = async () => {
    addLog("system", "Compiling project for cloud deployment...");
    try {
      const html = generateStandaloneHTML(files);
      const res = await fetch("/api/publish", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ html, projectId: activeSessionId, title: activeSession?.title || "Untitled App" }),
      });
      if (!res.ok) throw new Error("Deployment node rejected the payload.");
      const { url } = await res.json();
      window.open(url, "_blank");
      addLog("success", "Project successfully deployed to cloud server.");
    } catch (err: any) {
      addLog("error", `Deployment sequence failed: ${err.message}`);
    }
  };

  const handleExportProject = async () => {
    if (files.length === 0) return addLog("warn", "Workspace is empty. Nothing to export.");
    try {
      const zip = await exportProjectToZip(files);
      triggerFileDownload(zip, `${activeSession?.title || "aether-project"}.zip`);
      addLog("success", "Project successfully archived and prepared for download.");
    } catch (err) { addLog("error", "Project export failed. Please try again."); }
  };

  const handleApplyProjectTemplate = useCallback(async (type: string) => {
    const tmplFiles = getTemplateById(type, activeSessionId || generateId("s"));
    if (tmplFiles && tmplFiles.length > 0) {
      setFiles(tmplFiles);
      setActiveFileId(tmplFiles[0].id);
      if (activeSessionId) {
        await saveFiles(activeSessionId, tmplFiles);
      }
      addLog("success", `Applied project template: "${type}" (${tmplFiles.length} files).`, "WORKSPACE");
    }
  }, [activeSessionId, addLog]);

  const createNewSession = async (initialPrompt?: string | any, seedFiles?: FileNode[], initialAttachments?: any[]) => {
    const promptStr = typeof initialPrompt === "string" ? initialPrompt : undefined;
    const sessionTitle = typeof initialPrompt === "object" && initialPrompt?.title 
      ? initialPrompt.title 
      : (promptStr ? formatSmartTitleFromPrompt(promptStr) : (seedFiles ? "🖼️ Gallery App" : "⚡ New Node"));
    
    const sessionId = generateId("s");
    const newSession: ChatSession = {
      id: sessionId,
      title: sessionTitle,
      messages: [],
      lastUpdated: Date.now(),
    };
    setSessions((prev) => [newSession, ...prev]);
    setActiveSessionId(newSession.id);
    if (seedFiles && Array.isArray(seedFiles)) {
      setFiles(seedFiles);
      if (seedFiles.length > 0) setActiveFileId(seedFiles[0].id);
      try { await saveFiles(sessionId, seedFiles); } catch (err) { addLog("error", "Failed to save initial files to local storage."); }
      ui.setActiveTab("preview");
    } else {
      const template = getDefaultTemplate(sessionId);
      setFiles(template);
      if (template.length > 0) setActiveFileId(template[0].id);
      try { await saveFiles(sessionId, template); } catch (err) {}
      ui.setActiveTab("chat");
      if (promptStr) {
        const classification = classifyIntentAndDivision(promptStr, "", promptStr, template, "AUTO", []);
        const modelToUse = user?.aiSettings?.defaultModel || MODELS.AETHER_PRO;
        if (sendMessageRef.current) {
          setPendingPrompt(null);
          sendMessageRef.current(promptStr, initialAttachments || [], modelToUse, false, newSession, classification.spawnedAgents);
        } else {
          setPendingPrompt(promptStr);
        }
      }
    }
    if (user) {
      try { await storageService.saveSession({ id: newSession.id, title: newSession.title, messages: newSession.messages, updatedAt: newSession.lastUpdated }); } catch (e) {}
    }
  };

  const handleDeleteSession = useCallback(async (id: string) => {
    setSessions((prev) => prev.filter((s) => s.id !== id));
    if (activeSessionId === id) setActiveSessionId(null);
    storageService.deleteSession(id).catch(console.error);
    addLog("system", `Session ${id} deleted.`);
  }, [activeSessionId, setSessions, setActiveSessionId, addLog]);

  const handleRenameSession = useCallback((id: string, newTitle: string) => {
    setSessions((prev) => prev.map((s) => s.id === id ? { ...s, title: newTitle } : s));
  }, []);

  const handleShareSession = useCallback(async () => {
    if (!activeSessionId || !user) return;
    try {
      const url = new URL(window.location.origin + window.location.pathname);
      url.searchParams.set("session", activeSessionId);
      setCurrentShareUrl(url.toString());
      ui.setShowShareModal(true);
      const session = sessions.find((s) => s.id === activeSessionId);
      if (session) await saveFullSession(sessions, files);
    } catch (error) { addLog("error", "Failed to create share link."); }
  }, [activeSessionId, user, sessions, files, ui]);

  const handleCommandPaletteSelect = (cmdId: string, payload?: any) => {
    switch (cmdId) {
      case "new-file": {
        const nf = { id: generateId("f"), name: "untitled", content: "", language: "plaintext", lastModified: Date.now() };
        setFiles((prev) => [...prev, nf]);
        setActiveFileId(nf.id);
        if (activeSessionId) saveFile(activeSessionId, nf);
        break;
      }
      case "deploy": handleDeploy(); break;
      case "format-doc":
        if (activeFileId) {
          const file = files.find((f) => f.id === activeFileId);
          if (!file) return;
          (async () => {
            try {
              addLog("info", "AI analyzing and formatting code structure...", "EDITOR");
              const response = await chatWithAI(`Format the following code cleanly. Return ONLY the code.\n\n${file.content}`, [], [], [], MODELS.AETHER_PRO);
              const formattedContent = response.message.replace(/^```[a-z]*\n|```$/g, "").trim();
              setFiles((prev) => prev.map((f) => f.id === activeFileId ? { ...f, content: formattedContent } : f));
              if (activeSessionId) saveFile(activeSessionId, { ...file, content: formattedContent });
              addLog("success", "Code successfully formatted automatically.", "EDITOR");
            } catch (e: any) { addLog("error", `Formatting failed: ${e.message}`, "EDITOR"); }
          })();
        }
        break;
      case "clear-logs": setTerminalLogs([]); addLog("system", "Terminal logs cleared."); break;
      case "export-zip": handleExportProject(); break;
      case "open-3d-engine": ui.setActiveTab("preview"); addLog("info", "Mounted 3D Game Engine Viewport in Preview.", "3D_ENGINE"); break;
      case "create-rust-file": {
        const rustStarter = `// Rust Native Program\nfn main() {\n    println!("Hello from Aether IDE Rust Native Runner!");\n\n    let numbers = vec![1, 2, 3, 4, 5];\n    let sum: i32 = numbers.iter().sum();\n    println!("Sum of numbers: {}", sum);\n}\n`;
        const newFileId = `f_rust_${Date.now()}`;
        const newRustFile = {
          id: newFileId,
          name: "main.rs",
          language: "rust",
          content: rustStarter,
          lastModified: Date.now()
        };
        setFiles(prev => [...prev.filter(f => f.name !== "main.rs"), newRustFile]);
        setActiveFileId(newFileId);
        ui.setActiveTab("editor");
        addLog("success", "Created and opened main.rs with Rust support.", "RUST");
        break;
      }
      case "nuclear-reset": if (confirm("WARNING: This will purge all local nodes and user profile. Proceed?")) nuclearReset(); break;
      case "toggle-sidebar": ui.setSidebarMode((prev) => (prev ? null : "files")); break;
      case "open-extensions": ui.setSidebarMode("extensions"); break;
      case "open-api-playground": ui.setSidebarMode("api_playground"); break;
      case "open-security-auditor": ui.setSidebarMode("security"); break;
      case "open-database-studio": ui.setSidebarMode("database"); break;
      case "open-regex-studio": ui.setSidebarMode("datatransformer"); break;
      case "open-ui-studio": ui.setSidebarMode("uistudio"); break;
      case "open-audio-synth": ui.setSidebarMode("audiosynth"); break;
      case "open-dependency-graph": ui.setSidebarMode("dependencygraph"); break;
      case "open-profiler": ui.setSidebarMode("profiler"); break;
      case "open-jwt": ui.setShowJwtDecoder(true); break;
      case "open-env": ui.setShowEnvManager(true); break;
      case "run-doctor":
        window.dispatchEvent(new CustomEvent("aether_run_terminal_cmd", { detail: "aether doctor" }));
        break;
      default:
        if (cmdId.startsWith("open-file-") && payload) {
          const fileToOpen = files.find((f) => f.name === payload);
          if (fileToOpen) { setActiveFileId(fileToOpen.id); ui.setActiveTab("editor"); }
        }
        break;
    }
  };

  const handleAgentActions = useCallback(async (actions: AgentAction[]) => {
    if (!actions || actions.length === 0) return;

    let hasFileChanges = false;
    let lastFileId: string | null = null;

    setFiles((prevFiles) => {
      let updatedFiles = [...prevFiles];

      for (const action of actions) {
        if (!action) continue;

        if (action.action === 'terminal_command') {
          continue;
        }

        const rawPath = action.path || "script.js";
        const cleanPath = rawPath.replace(/^\.\//, '').replace(/^\//, '');
        const cleanBase = cleanPath.split('/').pop()?.toLowerCase() || cleanPath.toLowerCase();
        const ext = cleanPath.split('.').pop()?.toLowerCase() || 'js';

        // 1. Multi-tier Smart File Resolution:
        // Tier A: Exact path or name match
        let existingIndex = updatedFiles.findIndex(
          (f) => f.name === cleanPath || f.name === rawPath || (f.path && (f.path === cleanPath || f.path === rawPath))
        );

        // Tier B: Case-insensitive name match
        if (existingIndex === -1) {
          existingIndex = updatedFiles.findIndex(
            (f) => f.name.toLowerCase() === cleanPath.toLowerCase() || (f.path && f.path.toLowerCase() === cleanPath.toLowerCase())
          );
        }

        // Tier C: Basename match (e.g., 'src/App.tsx' matches 'App.tsx' if not a directory path and not creating a new file)
        if (existingIndex === -1 && !cleanPath.includes('/') && action.action !== 'create') {
          existingIndex = updatedFiles.findIndex(
            (f) => (f.name.split('/').pop()?.toLowerCase() || '') === cleanBase
          );
        }

        // Tier D: Type-based single-file matching (prevents creating duplicate game.js / script.js / styles.css ONLY when not creating a folder/new file)
        if (existingIndex === -1 && !cleanPath.includes('/') && action.action !== 'create') {
          if (['js', 'ts', 'jsx', 'tsx', 'mjs'].includes(ext)) {
            // If the workspace has a primary script (e.g. script.js or game.js) and the AI called it game.js/script.js/main.js/app.js/index.js
            const jsFiles = updatedFiles.filter(f => ['js', 'ts', 'jsx', 'tsx', 'mjs'].includes((f.name.split('.').pop() || '').toLowerCase()));
            if (jsFiles.length === 1 && ['script.js', 'game.js', 'main.js', 'app.js', 'index.js'].includes(cleanBase)) {
              existingIndex = updatedFiles.findIndex(f => f.id === jsFiles[0].id);
            } else if (['script.js', 'game.js', 'main.js', 'app.js', 'index.js'].includes(cleanBase)) {
              const primaryMatch = updatedFiles.findIndex(f => ['script.js', 'game.js', 'main.js', 'app.js', 'index.js'].includes(f.name.toLowerCase()));
              if (primaryMatch !== -1) existingIndex = primaryMatch;
            }
          } else if (ext === 'css' && ['style.css', 'styles.css', 'app.css', 'index.css', 'main.css'].includes(cleanBase)) {
            const cssFiles = updatedFiles.filter(f => (f.name.split('.').pop() || '').toLowerCase() === 'css');
            if (cssFiles.length === 1) {
              existingIndex = updatedFiles.findIndex(f => f.id === cssFiles[0].id);
            }
          } else if (ext === 'html' && ['index.html', 'main.html', 'app.html'].includes(cleanBase)) {
            const htmlFiles = updatedFiles.filter(f => (f.name.split('.').pop() || '').toLowerCase() === 'html');
            if (htmlFiles.length === 1) {
              existingIndex = updatedFiles.findIndex(f => f.id === htmlFiles[0].id);
            }
          }
        }

        if (action.action === 'delete') {
          if (existingIndex !== -1) {
            hasFileChanges = true;
            updatedFiles.splice(existingIndex, 1);
          }
        } else if (action.action === 'create' || action.action === 'update') {
          hasFileChanges = true;
          const lang = ['tsx', 'ts'].includes(ext)
            ? 'typescript'
            : ext === 'jsx'
            ? 'javascript'
            : ext === 'html'
            ? 'html'
            : ext === 'css'
            ? 'css'
            : ext === 'json'
            ? 'json'
            : ext === 'rs'
            ? 'rust'
            : ext === 'py'
            ? 'python'
            : 'javascript';

          if (existingIndex !== -1) {
            const currentFile = updatedFiles[existingIndex];
            const newContent = applySearchReplace(currentFile.content, action.content || '');
            const updatedFile: FileNode = {
              ...currentFile,
              content: newContent,
              language: lang,
              lastModified: Date.now()
            };
            updatedFiles[existingIndex] = updatedFile;
            lastFileId = updatedFile.id;
          } else {
            const newFile: FileNode = {
              id: generateId("f"),
              name: cleanPath,
              content: action.content || '',
              language: lang,
              lastModified: Date.now()
            };
            updatedFiles.push(newFile);
            lastFileId = newFile.id;

            // If a truly new script or CSS file is created, auto-link it in index.html if not already linked
            const htmlIndex = updatedFiles.findIndex(f => f.name.toLowerCase() === 'index.html');
            if (htmlIndex !== -1 && (ext === 'js' || ext === 'css')) {
              let htmlContent = updatedFiles[htmlIndex].content;
              if (ext === 'js' && !htmlContent.includes(cleanPath) && !htmlContent.includes(cleanBase)) {
                if (htmlContent.includes('</body>')) {
                  htmlContent = htmlContent.replace('</body>', `  <script src="${cleanPath}"></script>\n</body>`);
                } else {
                  htmlContent += `\n<script src="${cleanPath}"></script>`;
                }
                updatedFiles[htmlIndex] = { ...updatedFiles[htmlIndex], content: htmlContent, lastModified: Date.now() };
              } else if (ext === 'css' && !htmlContent.includes(cleanPath) && !htmlContent.includes(cleanBase)) {
                if (htmlContent.includes('</head>')) {
                  htmlContent = htmlContent.replace('</head>', `  <link rel="stylesheet" href="${cleanPath}">\n</head>`);
                } else {
                  htmlContent = `<link rel="stylesheet" href="${cleanPath}">\n` + htmlContent;
                }
                updatedFiles[htmlIndex] = { ...updatedFiles[htmlIndex], content: htmlContent, lastModified: Date.now() };
              }
            }
          }
        }
      }

      if (hasFileChanges) {
        // Auto-Pilot: Automatic AST Self-Repair Pass - RUNS ALWAYS to ensure code resilient auto-healing
        try {
          const { fixedFiles, fixedCount } = aetherAstEngine.autoFixDiagnostics(updatedFiles);
          if (fixedCount > 0) {
            updatedFiles = fixedFiles;
            addLog("info", `⚡ Auto-Pilot: Automatically healed ${fixedCount} AST syntax/import issues.`, "AUTO_PILOT");
          }
        } catch (e) {}

        if (activeSessionId) {
          saveFiles(activeSessionId, updatedFiles).catch(console.error);
        }
      }

      return updatedFiles;
    });

    if (hasFileChanges) {
      if (autoPilotMode) {
        ui.setActiveTab("preview");
      } else if (window.innerWidth < 1024 && lastFileId) {
        setActiveFileId(lastFileId);
        ui.setActiveTab("editor");
        ui.setSidebarMode(null);
      }
    }
  }, [activeSessionId, ui, setFiles, setActiveFileId, autoPilotMode, addLog]);

  const { isProcessing, sendMessage, stopProcessing } = useAutonomousAgent({
    files,
    activeSession,
    onUpdateSession: handleUpdateSession,
    onAgentAction: handleAgentActions,
    onToolCall: async () => {},
    addLog,
    terminalLogs,
  });

  useSessionSnapshot({
    activeSession,
    files,
    activeFileId,
    onUpdateSession: handleUpdateSession,
    isProcessing,
  });

  // Automatically synchronize chat title with app name whenever app name changes in project files
  useEffect(() => {
    if (!activeSession) return;
    const detectedAppName = extractAppNameFromFiles(files);
    if (detectedAppName && activeSession.title !== detectedAppName) {
      handleUpdateSession({
        ...activeSession,
        title: detectedAppName,
        lastUpdated: Date.now()
      });
    }
  }, [files, activeSession, handleUpdateSession]);

  sendMessageRef.current = sendMessage;

  useEffect(() => {
    if (pendingPrompt && activeSession && activeSession.id === activeSessionId && !isProcessing) {
      const promptToSend = pendingPrompt;
      setPendingPrompt(null);
      const classification = classifyIntentAndDivision(promptToSend, "", promptToSend, files, "AUTO", []);
      const modelToUse = user?.aiSettings?.defaultModel || MODELS.AETHER_PRO;
      sendMessage(promptToSend, [], modelToUse, false, activeSession, classification.spawnedAgents);
    }
  }, [pendingPrompt, activeSession, activeSessionId, isProcessing, sendMessage, files, user?.aiSettings?.defaultModel]);

  useEffect(() => {
    const settings = user?.customizerSettings || {};
    const root = document.documentElement;
    
    if (settings.uiBackground) {
      root.style.setProperty('--color-aether-bg', settings.uiBackground);
      document.body.style.backgroundColor = settings.uiBackground;
    } else {
      root.style.removeProperty('--color-aether-bg');
      document.body.style.backgroundColor = '';
    }
    
    if (settings.accentColor) {
      root.style.setProperty('--color-aether-accent', settings.accentColor);
    } else {
      root.style.removeProperty('--color-aether-accent');
    }
  }, [user?.customizerSettings]);

  useEffect(() => {
    const handleOpenDeploy = () => setShowDeployModal(true);
    const handleOpenShare = () => {
      handleShareSession();
    };

    window.addEventListener("aether_open_deploy", handleOpenDeploy);
    window.addEventListener("aether_open_share", handleOpenShare);

    return () => {
      window.removeEventListener("aether_open_deploy", handleOpenDeploy);
      window.removeEventListener("aether_open_share", handleOpenShare);
    };
  }, [ui, handleShareSession]);

  if (authLoading) return <><Suspense fallback={null}><BlackHoleBackground isLowPerf={perfMode === 'low'} /></Suspense><SystemLoader message="Loading Aether Workspace..." fullScreen /></>;
  if (!user) return <><Suspense fallback={null}><BlackHoleBackground isLowPerf={perfMode === 'low'} /></Suspense><Suspense fallback={<SystemLoader message="Loading Login..." fullScreen />}><LoginScreen onLogin={() => {}} onGuestLogin={loginGuest} onCompleteProfile={completeLogin} loading={authLoading} /></Suspense></>;

  const activeFile = files.find((f) => f.id === activeFileId);

  const motionPreset = user?.customizerSettings?.motionPreset || 'Fluid';

  const getTransitionConfig = (preset: 'Fluid' | 'Snap' | 'Reduced') => {
    switch (preset) {
      case 'Snap':
        return { type: "spring", stiffness: 350, damping: 25, mass: 0.6 };
      case 'Reduced':
        return { type: "tween", duration: 0.05, ease: "linear" };
      case 'Fluid':
      default:
        return { type: "spring", stiffness: 120, damping: 20, mass: 1 };
    }
  };

  const currentTransition = getTransitionConfig(motionPreset as any) as any;

  if (true) {
    return (
      <MotionConfig transition={currentTransition} reducedMotion={motionPreset === 'Reduced' ? 'always' : 'never'}>
        <ErrorBoundary>
        <Suspense fallback={null}><BlackHoleBackground isLowPerf={perfMode === 'low'} /></Suspense>
        <div className="w-full h-full min-h-full flex-1 flex flex-col overflow-hidden relative">
          {isMobile ? (
            <MobileWorkspace
              user={user}
              files={files}
              setFiles={setFiles}
              activeFileId={activeFileId}
              setActiveFileId={setActiveFileId}
              activeSessionId={activeSessionId}
              setActiveSessionId={setActiveSessionId}
              sessions={sessions}
              setSessions={setSessions}
              isProcessing={isProcessing}
              isSyncing={false}
              connectionStatus={connectionStatus}
              googleDriveConnected={googleDriveConnected}
              activeUsers={activeUsers}
              systemStats={systemStats}
              activeFont={user?.font || "'Inter', sans-serif"}
              minimapEnabled={user?.editorSettings?.minimap ?? true}
              perfMode={perfMode}
              onTogglePerfMode={() => setPerfMode(prev => prev === 'low' ? 'high' : 'low')}
              onOptimizeMemory={handleClearMemory}
              chatCompactMode={chatCompactMode}
              onToggleChatCompact={() => setChatCompactMode(prev => !prev)}
              autoPilotMode={autoPilotMode}
              setAutoPilotMode={setAutoPilotMode}
              addLog={addLog}
              handleRenameFile={handleRenameFile}
              handleExportProject={handleExportProject}
              handleApplyTemplate={handleApplyProjectTemplate}
              handleAgentAction={handleAgentActions}
              handleUploadFiles={() => {}}
              createNewSession={createNewSession}
              handleDeleteSession={handleDeleteSession}
              handleRenameSession={handleRenameSession}
              sendMessage={sendMessage}
              stopProcessing={stopProcessing}
              autoSave={autoSave}
              handleCommandPaletteSelect={handleCommandPaletteSelect}
              focusMode={ui.focusMode}
              setFocusMode={ui.setFocusMode}
              zenMode={ui.zenMode}
              setZenMode={ui.setZenMode}
              onOpenHealth={() => ui.setSidebarMode("health")}
              onOpenSettings={() => ui.setSidebarMode("settings")}
              sidebarMode={ui.sidebarMode}
              setSidebarMode={ui.setSidebarMode}
              onUpdateUser={updateUser}
              onLogout={logout}
              onNuclearReset={nuclearReset}
              onClearAllSessions={() => setSessions([])}
              onSyncNow={() => {}}
            />
          ) : (
            <PCWorkspace
              user={user}
              files={files}
              setFiles={setFiles}
              activeFileId={activeFileId}
              setActiveFileId={setActiveFileId}
              activeSessionId={activeSessionId}
              setActiveSessionId={setActiveSessionId}
              sessions={sessions}
              setSessions={setSessions}
              isProcessing={isProcessing}
              isSyncing={false}
              connectionStatus={connectionStatus}
              googleDriveConnected={googleDriveConnected}
              activeUsers={activeUsers}
              systemStats={systemStats}
              activeFont={user?.font || "'Inter', sans-serif"}
              minimapEnabled={user?.editorSettings?.minimap ?? true}
              perfMode={perfMode}
              onTogglePerfMode={() => setPerfMode(prev => prev === 'low' ? 'high' : 'low')}
              onOptimizeMemory={handleClearMemory}
              chatCompactMode={chatCompactMode}
              onToggleChatCompact={() => setChatCompactMode(prev => !prev)}
              autoPilotMode={autoPilotMode}
              setAutoPilotMode={setAutoPilotMode}
              addLog={addLog}
              handleRenameFile={handleRenameFile}
              handleExportProject={handleExportProject}
              handleApplyTemplate={handleApplyProjectTemplate}
              handleAgentAction={handleAgentActions}
              handleUploadFiles={() => {}}
              createNewSession={createNewSession}
              handleDeleteSession={handleDeleteSession}
              handleRenameSession={handleRenameSession}
              sendMessage={sendMessage}
              stopProcessing={stopProcessing}
              autoSave={autoSave}
              handleCommandPaletteSelect={handleCommandPaletteSelect}
              focusMode={ui.focusMode}
              setFocusMode={ui.setFocusMode}
              zenMode={ui.zenMode}
              setZenMode={ui.setZenMode}
              onOpenHealth={() => ui.setSidebarMode("health")}
              onOpenSettings={() => ui.setSidebarMode("settings")}
              sidebarMode={ui.sidebarMode}
              setSidebarMode={ui.setSidebarMode}
              onUpdateUser={updateUser}
              onLogout={logout}
              onNuclearReset={nuclearReset}
              onClearAllSessions={() => setSessions([])}
              onSyncNow={() => {}}
            />
          )}
          <NotificationToast />
        </div>
      </ErrorBoundary>
      </MotionConfig>
    );
  }
};

export default App;
