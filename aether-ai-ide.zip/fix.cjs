const fs = require('fs');
const file = 'components/Layout/MainHeader.tsx';
let content = fs.readFileSync(file, 'utf8');

const compHtml = `
const NetworkBoosterButton = () => {
  const [boost, setBoost] = React.useState(false);
  React.useEffect(() => {
    const handle = () => setBoost(localStorage.getItem('aether_network_boost') === 'true');
    handle();
    window.addEventListener('aether_network_boost', handle);
    return () => window.removeEventListener('aether_network_boost', handle);
  }, []);
  
  return (
    <button
      onClick={() => {
        localStorage.setItem('aether_network_boost', (!boost).toString());
        window.dispatchEvent(new Event('aether_network_boost'));
      }}
      className={\`hidden md:flex items-center gap-2 px-3 py-1.5 border rounded-xl transition-all mr-2 \${
        boost ? 'bg-purple-500/10 border-purple-500/30 shadow-[0_0_15px_rgba(168,85,247,0.15)]' : 'bg-white/[0.03] hover:bg-white/[0.08] border-white/5'
      }\`}
      title={boost ? "Network Booster: ACTIVE" : "Network Booster: INACTIVE"}
    >
      <Rocket size={14} className={boost ? "text-purple-400 animate-pulse" : "text-zinc-500"} />
      <span className={\`text-[9px] font-black uppercase tracking-widest \${boost ? "text-purple-300" : "text-white/40"}\`}>
        Boost
      </span>
    </button>
  );
};
`;

if (!content.includes('const NetworkBoosterButton =')) {
  content = content.replace('export default MainHeader;', compHtml + '\nexport default MainHeader;');
  fs.writeFileSync(file, content);
  console.log("Fixed MainHeader");
}
