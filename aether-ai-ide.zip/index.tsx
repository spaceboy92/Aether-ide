import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import PublishedApp from './PublishedApp';
import ErrorBoundary from './components/ErrorBoundary';
import { FirebaseProvider } from './components/Auth/FirebaseProvider';
import './index.css';

import { parseAIResponse } from './services/geminiService';

// Global safety net for parseAIResponse
(window as any).parseAIResponse = parseAIResponse;

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);

// Suppress benign WebSocket errors in iframe environment
const originalConsoleError = console.error;
console.error = (...args) => {
  if (args[0] && typeof args[0] === 'string' && (args[0].includes('WebSocket') || args[0].includes('vite'))) {
    return;
  }
  originalConsoleError(...args);
};

window.addEventListener('unhandledrejection', (event) => {
  if (event.reason) {
    const isWebSocketError = 
      (typeof event.reason === 'string' && event.reason.includes('WebSocket')) ||
      (event.reason.message?.includes('WebSocket')) || 
      (event.reason.stack?.includes('WebSocket'));
      
    if (isWebSocketError) {
      event.preventDefault();
      return;
    }
  }
});

const pathname = window.location.pathname;
const searchParams = new URLSearchParams(window.location.search);
const deployId = searchParams.get('app');
const isDeployment = !!deployId;

try {
  root.render(
    <React.StrictMode>
      <ErrorBoundary>
        <FirebaseProvider>
          {isDeployment && deployId ? <PublishedApp deployId={deployId} /> : <App />}
        </FirebaseProvider>
      </ErrorBoundary>
    </React.StrictMode>
  );
} catch (err) {
  console.error("Critical rendering error at startup:", err);
  rootElement.innerHTML = `<div style="padding:40px;color:#ff6666;font-family:sans-serif;background:#090a0f;height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;">
    <h2 style="font-size:24px;margin-bottom:12px;">Workspace Initialization Error</h2>
    <p style="color:#aaa;max-width:500px;margin-bottom:24px;">${err instanceof Error ? err.message : String(err)}</p>
    <button onclick="window.location.reload()" style="background:#f97316;color:#000;border:none;padding:10px 20px;border-radius:8px;cursor:pointer;font-weight:bold;">Reload Aether Workspace</button>
  </div>`;
}

// Unregister Service Workers in dev/preview
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.getRegistrations().then(function(registrations) {
    for(let registration of registrations) {
      registration.unregister()
    }
  })
}

