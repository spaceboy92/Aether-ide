const fs = require('fs');
let code = fs.readFileSync('services/geminiService.ts', 'utf8');

const catchTargetStream = `    } catch (error: any) {
      const errMsg = error.message || String(error);
      if (errMsg.includes("503") || errMsg.includes("overloaded") || errMsg.includes("429")) {
         console.warn(\`Gemini \${activeModelId} overloaded or rate limited. Trying again...\`);
         if (retryCount < maxRetries) {
             retryCount++;
             if (activeModelId === MODELS.GEMINI_FLASH) {
                activeModelId = "gemini-1.5-flash-8b";
             } else if (activeModelId === MODELS.GEMINI_PRO) {
                activeModelId = MODELS.GEMINI_FLASH;
             }
             continue;
         }
      }
      console.error("Gemini stream error details:", error);
      throw new Error(\`Gemini AI service notice: \${errMsg}. Please verify model configuration or network connection.\`);
    }`;

const newCatchStream = `    } catch (error: any) {
      const errMsg = error.message || String(error);
      if (errMsg.includes("503") || errMsg.includes("overloaded") || errMsg.includes("429") || errMsg.includes("UNAVAILABLE")) {
         console.warn(\`Gemini \${activeModelId} overloaded or rate limited. Trying again...\`);
         if (retryCount < maxRetries) {
             retryCount++;
             if (activeModelId === MODELS.GEMINI_FLASH) {
                activeModelId = "gemini-1.5-flash-8b";
             } else if (activeModelId === MODELS.GEMINI_PRO) {
                activeModelId = MODELS.GEMINI_FLASH;
             }
             continue;
         } else {
             throw new Error(\`The AI provider is currently experiencing high demand and returning a 503 Service Unavailable error. Please wait a moment and try again.\`);
         }
      }
      console.error("Gemini stream error details:", error);
      throw new Error(\`AI service notice: \${errMsg}\`);
    }`;

let patched = false;
if (code.includes(catchTargetStream)) {
  code = code.replace(catchTargetStream, newCatchStream);
  patched = true;
  console.log("Patched catch stream");
} else {
    // If exact block not found, let's just do a string replace for the generic error
    code = code.replace(/Gemini AI service notice:/g, "AI service notice:");
    // replace 503 catch condition if possible via regex
    code = code.replace(/throw new Error\(`Gemini AI service notice: \${errMsg}\. Please verify model configuration or network connection\.`\);/g, "throw new Error(`The AI Provider returned an error: ${errMsg}`);");
    patched = true;
    console.log("Patched catch via generic replace");
}

const ollamaTarget1 = `  if (isOllamaModel(modelId)) {
    return chatWithOllamaStream(modelId, prompt, currentFiles, history, onChunk);
  }`;
const ollamaTarget2 = `  if (isOllamaModel(modelId)) {
    let finalRes: SimpleAIResponse = { thoughts: "", message: "", files: [] };
    await chatWithOllamaStream(modelId, prompt, currentFiles, history, (th, msg) => {
      finalRes = { thoughts: th, message: msg, files: [] };
    });
    return finalRes;
  }`;

if (code.includes(ollamaTarget1)) {
    code = code.replace(ollamaTarget1, "");
    console.log("Removed isOllamaModel check from stream");
}
if (code.includes(ollamaTarget2)) {
    code = code.replace(ollamaTarget2, "");
    console.log("Removed isOllamaModel check from non-stream");
}


fs.writeFileSync('services/geminiService.ts', code);
