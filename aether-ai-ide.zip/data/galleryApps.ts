
export interface GalleryApp {
  id: string;
  title: string;
  description: string;
  category: 'Game' | 'Utility' | 'Visualizer' | 'AI';
  thumbnail: string;
  files: { name: string; content: string; language: string }[];
  accentColor: string;
}

export const GALLERY_APPS: GalleryApp[] = [
  {
    id: 'vector-pong',
    title: 'Vector Pong',
    description: 'A high-speed neon arcade classic with physics and scoring.',
    category: 'Game',
    thumbnail: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=400',
    accentColor: 'orange',
    files: [
      {
        name: 'index.html',
        language: 'html',
        content: `<!DOCTYPE html>
<html>
<head>
    <title>Vector Pong</title>
    <style>
        body { margin: 0; background: #000; overflow: hidden; font-family: 'Inter', sans-serif; }
        canvas { display: block; filter: drop-shadow(0 0 10px rgba(249, 115, 22, 0.5)); }
        #ui { position: absolute; top: 20px; width: 100%; text-align: center; color: #fff; font-size: 40px; font-weight: 900; letter-spacing: 10px; pointer-events: none; }
    </style>
</head>
<body>
    <div id="ui">00 - 00</div>
    <canvas id="game"></canvas>
    <script>
        const canvas = document.getElementById('game');
        const ctx = canvas.getContext('2d');
        const ui = document.getElementById('ui');

        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        const paddle = { w: 15, h: 100, speed: 8 };
        const p1 = { x: 50, y: canvas.height/2 - 50, score: 0 };
        const p2 = { x: canvas.width - 65, y: canvas.height/2 - 50, score: 0 };
        const ball = { x: canvas.width/2, y: canvas.height/2, vx: 5, vy: 5, r: 8 };

        const keys = {};
        window.addEventListener('keydown', e => keys[e.key] = true);
        window.addEventListener('keyup', e => keys[e.key] = false);

        function update() {
            // P1 Controls
            if (keys['w'] && p1.y > 0) p1.y -= paddle.speed;
            if (keys['s'] && p1.y < canvas.height - paddle.h) p1.y += paddle.speed;

            // P2 AI
            const target = ball.y - paddle.h/2;
            p2.y += (target - p2.y) * 0.12;
            p2.y = Math.max(0, Math.min(canvas.height - paddle.h, p2.y));

            ball.x += ball.vx;
            ball.y += ball.vy;

            if (ball.y < ball.r || ball.y > canvas.height - ball.r) ball.vy *= -1;

            // Collisions
            if (ball.vx < 0 && ball.x - ball.r < p1.x + paddle.w && ball.y > p1.y && ball.y < p1.y + paddle.h) {
                ball.vx *= -1.1;
                ball.x = p1.x + paddle.w + ball.r;
            }
            if (ball.vx > 0 && ball.x + ball.r > p2.x && ball.y > p2.y && ball.y < p2.y + paddle.h) {
                ball.vx *= -1.1;
                ball.x = p2.x - ball.r;
            }

            // Scoring
            if (ball.x < 0) { p2.score++; reset(); }
            if (ball.x > canvas.width) { p1.score++; reset(); }

            ui.innerText = \`\${p1.score.toString().padStart(2, '0')} - \${p2.score.toString().padStart(2, '0')}\`;
        }

        function reset() {
            ball.x = canvas.width/2;
            ball.y = canvas.height/2;
            ball.vx = 5 * (Math.random() > 0.5 ? 1 : -1);
            ball.vy = 5 * (Math.random() > 0.5 ? 1 : -1);
        }

        function draw() {
            ctx.fillStyle = 'rgba(0,0,0,0.2)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            ctx.fillStyle = '#f97316';
            ctx.fillRect(p1.x, p1.y, paddle.w, paddle.h);
            ctx.fillRect(p2.x, p2.y, paddle.w, paddle.h);
            
            ctx.beginPath();
            ctx.arc(ball.x, ball.y, ball.r, 0, Math.PI*2);
            ctx.fill();

            requestAnimationFrame(() => {
                update();
                draw();
            });
        }
        draw();
    </script>
</body>
</html>`
      }
    ]
  },
  {
    id: 'neural-notes',
    title: 'Neural Notes',
    description: 'A minimalist markdown editor with focus mode and local persistence.',
    category: 'Utility',
    thumbnail: 'https://images.unsplash.com/photo-1517842645767-c639042777db?auto=format&fit=crop&q=80&w=400',
    accentColor: 'amber',
    files: [
      {
        name: 'index.html',
        language: 'html',
        content: `<!DOCTYPE html>
<html>
<head>
    <title>Neural Notes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700&family=JetBrains+Mono&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; background: #0a0a0a; color: #fff; }
        .mono { font-family: 'JetBrains Mono', monospace; }
    </style>
</head>
<body class="p-8 md:p-24 flex flex-col h-screen">
    <header class="flex justify-between items-center mb-12">
        <h1 class="text-2xl font-black uppercase tracking-[0.3em] text-orange-500">Neural Notes</h1>
        <div class="text-[10px] font-bold text-white/20 uppercase tracking-widest">v1.0.0 // Sync Active</div>
    </header>
    
    <main class="flex-1 flex flex-col">
        <textarea id="editor" class="flex-1 bg-transparent border-none outline-none resize-none text-xl leading-relaxed text-white/80 placeholder:text-white/10" placeholder="Begin the neural transmission..."></textarea>
    </main>
    
    <footer class="mt-12 pt-8 border-t border-white/5 flex justify-between text-[10px] font-bold uppercase tracking-widest text-white/40">
        <div id="stats">0 Words // 0 Characters</div>
        <div>All changes saved locally</div>
    </footer>

    <script>
        const editor = document.getElementById('editor');
        const stats = document.getElementById('stats');

        editor.value = localStorage.getItem('neural_note_content') || '';
        
        editor.addEventListener('input', () => {
            const text = editor.value;
            localStorage.setItem('neural_note_content', text);
            
            const words = text.trim() ? text.trim().split(/\\s+/).length : 0;
            const chars = text.length;
            stats.innerText = \`\${words} Words // \${chars} Characters\`;
        });
    </script>
</body>
</html>`
      }
    ]
  },
  {
    id: 'crypto-pulse',
    title: 'Crypto Pulse',
    description: 'Real-time cryptocurrency ticker with dynamic charting and market insights.',
    category: 'Visualizer',
    thumbnail: 'https://images.unsplash.com/photo-1621761191319-c6fb62004040?auto=format&fit=crop&q=80&w=400',
    accentColor: 'orange',
    files: [
      {
        name: 'index.html',
        language: 'html',
        content: `<!DOCTYPE html>
<html>
<head>
    <title>Crypto Pulse</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        @keyframes pulse-slow { 0%, 100% { opacity: 0.4; } 50% { opacity: 1; } }
        .pulse { animation: pulse-slow 3s infinite; }
    </style>
</head>
<body class="bg-[#050505] text-white p-6 font-sans">
    <nav class="flex justify-between items-center mb-12">
        <div class="flex items-center gap-3">
            <div class="p-2 bg-orange-500/20 rounded-lg text-orange-400">
                <i data-lucide="trending-up"></i>
            </div>
            <h1 class="text-xl font-bold tracking-tight">CryptoPulse</h1>
        </div>
        <div class="px-4 py-1.5 bg-white/5 rounded-full border border-white/10 text-[10px] font-bold uppercase tracking-widest flex items-center gap-2">
            <div class="w-2 h-2 bg-emerald-500 rounded-full pulse"></div>
            Market Live
        </div>
    </nav>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <div class="bg-white/[0.03] border border-white/5 rounded-3xl p-6">
            <p class="text-[10px] font-bold text-white/40 uppercase mb-2">Bitcoin / USD</p>
            <h2 class="text-3xl font-bold mb-4">$64,281.40</h2>
            <div class="text-xs font-bold text-emerald-400">+2.45% (24h)</div>
        </div>
        <div class="bg-white/[0.03] border border-white/5 rounded-3xl p-6">
            <p class="text-[10px] font-bold text-white/40 uppercase mb-2">Ethereum / USD</p>
            <h2 class="text-3xl font-bold mb-4">$3,420.15</h2>
            <div class="text-xs font-bold text-emerald-400">+1.12% (24h)</div>
        </div>
        <div class="bg-white/[0.03] border border-white/5 rounded-3xl p-6">
            <p class="text-[10px] font-bold text-white/40 uppercase mb-2">Solana / USD</p>
            <h2 class="text-3xl font-bold mb-4">$145.82</h2>
            <div class="text-xs font-bold text-rose-400">-0.85% (24h)</div>
        </div>
    </div>

    <div class="bg-white/[0.02] border border-white/5 rounded-[2rem] p-8 h-96 flex items-center justify-center relative overflow-hidden">
        <div class="absolute inset-0 opacity-10 pointer-events-none">
            <svg class="w-full h-full" viewBox="0 0 1000 400" preserveAspectRatio="none">
                <path d="M0,300 Q250,100 500,250 T1000,150" fill="none" stroke="currentColor" stroke-width="2" />
            </svg>
        </div>
        <div class="text-center">
            <i data-lucide="bar-chart-2" class="w-12 h-12 text-white/10 mx-auto mb-4"></i>
            <p class="text-sm font-medium text-white/30">Aggregate Market Visualization Loading...</p>
        </div>
    </div>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>`
      }
    ]
  },
  {
    id: 'molecule-3d',
    title: 'BioStructure 3D',
    description: 'Interactive 3D molecule visualizer with rotation and structure inspection.',
    category: 'Visualizer',
    thumbnail: 'https://images.unsplash.com/photo-1532187863486-abf9d39d6618?auto=format&fit=crop&q=80&w=400',
    accentColor: 'blue',
    files: [
      {
        name: 'index.html',
        language: 'html',
        content: `<!DOCTYPE html>
<html>
<head>
    <title>BioStructure 3D</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <style>
        body { margin: 0; background: #000; overflow: hidden; }
        #ui { position: absolute; bottom: 20px; left: 20px; color: #fff; font-family: sans-serif; pointer-events: none; }
    </style>
</head>
<body>
    <div id="ui">
        <h1 style="margin:0; font-size: 24px; font-weight: 900; color: #3b82f6;">H2O Structure</h1>
        <p style="opacity: 0.5; font-size: 10px; text-transform: uppercase; letter-spacing: 2px;">Molecular Render Engine v1.2</p>
    </div>
    <script>
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        document.body.appendChild(renderer.domElement);

        const group = new THREE.Group();
        scene.add(group);

        const createAtom = (color, size, x, y, z) => {
            const geo = new THREE.SphereGeometry(size, 32, 32);
            const mat = new THREE.MeshPhongMaterial({ color, shininess: 100 });
            const mesh = new THREE.Mesh(geo, mat);
            mesh.position.set(x, y, z);
            group.add(mesh);
            return mesh;
        };

        const createBond = (x1, y1, z1, x2, y2, z2) => {
            const start = new THREE.Vector3(x1, y1, z1);
            const end = new THREE.Vector3(x2, y2, z2);
            const distance = start.distanceTo(end);
            const geo = new THREE.CylinderGeometry(0.1, 0.1, distance, 8);
            const mat = new THREE.MeshPhongMaterial({ color: 0x888888 });
            const mesh = new THREE.Mesh(geo, mat);
            
            mesh.position.copy(start.clone().lerp(end, 0.5));
            mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), end.clone().sub(start).normalize());
            group.add(mesh);
        };

        createAtom(0xff0000, 1, 0, 0, 0); // Oxygen
        createAtom(0xffffff, 0.6, 1.2, 1, 0); // Hydrogen 1
        createAtom(0xffffff, 0.6, -1.2, 1, 0); // Hydrogen 2
        
        createBond(0, 0, 0, 1.2, 1, 0);
        createBond(0, 0, 0, -1.2, 1, 0);

        const light = new THREE.PointLight(0xffffff, 1, 100);
        light.position.set(10, 10, 10);
        scene.add(light);
        scene.add(new THREE.AmbientLight(0x404040));

        camera.position.z = 5;

        function animate() {
            requestAnimationFrame(animate);
            group.rotation.y += 0.01;
            group.rotation.x += 0.005;
            renderer.render(scene, camera);
        }
        animate();

        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        });
    </script>
</body>
</html>`
      }
    ]
  },
  {
    id: 'solar-orbit-3d',
    title: 'Solar Orbit 3D Simulator',
    description: 'An interactive 3D solar system simulator rendered in WebGL with orbital velocities and planetary inspection cards.',
    category: 'Visualizer',
    thumbnail: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=400',
    accentColor: 'amber',
    files: [
      {
        name: 'index.html',
        language: 'html',
        content: `<!DOCTYPE html>
<html>
<head>
    <title>Solar Orbit 3D Simulator</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
    <style>
        body { margin: 0; background: #010103; overflow: hidden; font-family: sans-serif; color: #fff; }
        #hud { position: absolute; top: 20px; left: 20px; z-index: 10; pointer-events: none; }
        .title { font-size: 24px; font-weight: 900; color: #f59e0b; text-transform: uppercase; letter-spacing: 3px; }
        .sub { font-size: 10px; opacity: 0.5; letter-spacing: 2px; text-transform: uppercase; margin-top: 4px; }
        #info { position: absolute; bottom: 20px; right: 20px; background: rgba(0,0,0,0.8); border: 1px solid rgba(255,255,255,0.1); padding: 15px; border-radius: 12px; width: 240px; }
    </style>
</head>
<body>
    <div id="hud">
        <div class="title">Orbis Solar Engine</div>
        <div class="sub">Keplerian Orbital Dynamics v2.4</div>
    </div>
    <div id="info">
        <div style="font-size: 12px; color: #f59e0b; font-weight: bold;">System Status</div>
        <div style="font-size: 11px; opacity: 0.7; margin-top: 5px;">Click or drag to rotate camera view. Orbiting 4 primary planetary bodies around Sol Singularity.</div>
    </div>
    <script>
        const scene = new THREE.Scene();
        const camera = new THREE.PerspectiveCamera(60, window.innerWidth/window.innerHeight, 0.1, 1000);
        const renderer = new THREE.WebGLRenderer({ antialias: true });
        renderer.setSize(window.innerWidth, window.innerHeight);
        document.body.appendChild(renderer.domElement);

        const sunGeo = new THREE.SphereGeometry(2.5, 32, 32);
        const sunMat = new THREE.MeshBasicMaterial({ color: 0xfba919 });
        const sun = new THREE.Mesh(sunGeo, sunMat);
        scene.add(sun);

        const light = new THREE.PointLight(0xffffff, 2, 200);
        scene.add(light);
        scene.add(new THREE.AmbientLight(0x222222));

        const createPlanet = (radius, dist, color, speed) => {
            const group = new THREE.Group();
            scene.add(group);
            const p = new THREE.Mesh(new THREE.SphereGeometry(radius, 24, 24), new THREE.MeshPhongMaterial({ color }));
            p.position.x = dist;
            group.add(p);
            
            // Orbit line
            const orbitGeo = new THREE.RingGeometry(dist-0.05, dist+0.05, 64);
            const orbitMat = new THREE.MeshBasicMaterial({ color: 0xffffff, opacity: 0.08, transparent: true, side: THREE.DoubleSide });
            const orbit = new THREE.Mesh(orbitGeo, orbitMat);
            orbit.rotation.x = Math.PI/2;
            scene.add(orbit);

            return { group, p, speed };
        };

        const planets = [
            createPlanet(0.4, 4.5, 0xa3a3a3, 0.03), // Mercury
            createPlanet(0.7, 7.0, 0xfcd34d, 0.02), // Venus
            createPlanet(0.85, 10.0, 0x3b82f6, 0.015), // Earth
            createPlanet(0.55, 13.5, 0xef4444, 0.01) // Mars
        ];

        camera.position.set(0, 15, 22);
        camera.lookAt(0, 0, 0);

        function animate() {
            requestAnimationFrame(animate);
            planets.forEach(pl => pl.group.rotation.y += pl.speed);
            renderer.render(scene, camera);
        }
        animate();

        window.addEventListener('resize', () => {
            camera.aspect = window.innerWidth / window.innerHeight;
            camera.updateProjectionMatrix();
            renderer.setSize(window.innerWidth, window.innerHeight);
        });
    </script>
</body>
</html>`
      }
    ]
  },
  {
    id: 'synth-studio',
    title: 'Neural Synth Studio',
    description: 'Interactive Web Audio API synthesizer featuring real-time oscilloscope visualization, frequency filters, and envelope controls.',
    category: 'Utility',
    thumbnail: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&q=80&w=400',
    accentColor: 'orange',
    files: [
      {
        name: 'index.html',
        language: 'html',
        content: `<!DOCTYPE html>
<html>
<head>
    <title>Neural Synth Studio</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-[#08080a] text-white p-8 font-sans flex flex-col h-screen">
    <header class="flex justify-between items-center mb-8 pb-4 border-b border-white/10">
        <div>
            <h1 class="text-2xl font-black uppercase tracking-widest text-orange-500">Neural Synth Studio</h1>
            <p class="text-xs text-white/40 font-mono mt-1">WebAudio Frequency Generator & Oscilloscope</p>
        </div>
    </header>
    <main class="flex-1 flex flex-col gap-6">
        <div class="bg-black border border-white/10 rounded-2xl p-4 h-48 flex items-center justify-center relative overflow-hidden">
            <canvas id="osc" class="w-full h-full"></canvas>
            <div class="absolute top-3 left-3 text-[10px] font-mono text-orange-400">OSCILLOSCOPE LIVE</div>
        </div>
        <div class="grid grid-cols-4 md:grid-cols-8 gap-3">
            <button class="key bg-zinc-900 border border-white/10 hover:border-orange-500/50 hover:bg-orange-500/20 active:scale-95 py-10 rounded-xl font-bold text-center transition-all" data-freq="261.63">C4</button>
            <button class="key bg-zinc-900 border border-white/10 hover:border-orange-500/50 hover:bg-orange-500/20 active:scale-95 py-10 rounded-xl font-bold text-center transition-all" data-freq="293.66">D4</button>
            <button class="key bg-zinc-900 border border-white/10 hover:border-orange-500/50 hover:bg-orange-500/20 active:scale-95 py-10 rounded-xl font-bold text-center transition-all" data-freq="329.63">E4</button>
            <button class="key bg-zinc-900 border border-white/10 hover:border-orange-500/50 hover:bg-orange-500/20 active:scale-95 py-10 rounded-xl font-bold text-center transition-all" data-freq="349.23">F4</button>
            <button class="key bg-zinc-900 border border-white/10 hover:border-orange-500/50 hover:bg-orange-500/20 active:scale-95 py-10 rounded-xl font-bold text-center transition-all" data-freq="392.00">G4</button>
            <button class="key bg-zinc-900 border border-white/10 hover:border-orange-500/50 hover:bg-orange-500/20 active:scale-95 py-10 rounded-xl font-bold text-center transition-all" data-freq="440.00">A4</button>
            <button class="key bg-zinc-900 border border-white/10 hover:border-orange-500/50 hover:bg-orange-500/20 active:scale-95 py-10 rounded-xl font-bold text-center transition-all" data-freq="493.88">B4</button>
            <button class="key bg-zinc-900 border border-white/10 hover:border-orange-500/50 hover:bg-orange-500/20 active:scale-95 py-10 rounded-xl font-bold text-center transition-all" data-freq="523.25">C5</button>
        </div>
    </main>
    <script>
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const canvas = document.getElementById('osc');
        const cCtx = canvas.getContext('2d');
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 256;

        document.querySelectorAll('.key').forEach(btn => {
            btn.addEventListener('mousedown', () => {
                if (ctx.state === 'suspended') ctx.resume();
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.type = 'sawtooth';
                osc.frequency.setValueAtTime(parseFloat(btn.dataset.freq), ctx.currentTime);
                gain.gain.setValueAtTime(0.3, ctx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.2);
                osc.connect(gain);
                gain.connect(analyser);
                analyser.connect(ctx.destination);
                osc.start();
                osc.stop(ctx.currentTime + 1.2);
            });
        });

        function draw() {
            requestAnimationFrame(draw);
            canvas.width = canvas.parentElement.clientWidth;
            canvas.height = canvas.parentElement.clientHeight;
            const buffer = new Uint8Array(analyser.frequencyBinCount);
            analyser.getByteTimeDomainData(buffer);
            cCtx.fillStyle = '#050505';
            cCtx.fillRect(0, 0, canvas.width, canvas.height);
            cCtx.lineWidth = 2;
            cCtx.strokeStyle = '#f97316';
            cCtx.beginPath();
            const sliceWidth = canvas.width * 1.0 / buffer.length;
            let x = 0;
            for(let i = 0; i < buffer.length; i++) {
                const v = buffer[i] / 128.0;
                const y = v * canvas.height / 2;
                if(i === 0) cCtx.moveTo(x, y);
                else cCtx.lineTo(x, y);
                x += sliceWidth;
            }
            cCtx.stroke();
        }
        draw();
    </script>
</body>
</html>`
      }
    ]
  },
  {
    id: 'neon-dungeon',
    title: 'Neon Rogue Crawler',
    description: 'Grid-based cyberpunk roguelike with turn-based tactical combat, floor progression, and energy weapon pickups.',
    category: 'Game',
    thumbnail: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&q=80&w=400',
    accentColor: 'orange',
    files: [
      {
        name: 'index.html',
        language: 'html',
        content: `<!DOCTYPE html>
<html>
<head>
    <title>Neon Rogue Crawler</title>
    <style>
        body { margin: 0; background: #000; color: #fff; font-family: monospace; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; }
        #grid { display: grid; grid-template-columns: repeat(12, 36px); gap: 2px; background: #111; padding: 10px; border: 2px solid #f97316; border-radius: 8px; }
        .cell { width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; font-size: 20px; background: #09090b; border-radius: 4px; }
        .player { color: #38bdf8; font-weight: bold; }
        .enemy { color: #ef4444; }
        .chest { color: #eab308; }
        #log { margin-top: 15px; font-size: 14px; color: #f97316; min-height: 20px; }
    </style>
</head>
<body>
    <div style="margin-bottom:10px; font-weight:bold; letter-spacing:2px;">NEON ROGUE CRAWLER [USE WASD or ARROWS]</div>
    <div id="grid"></div>
    <div id="log">Welcome, Cyber Agent. Retrieve the energy core!</div>
    <script>
        const grid = document.getElementById('grid');
        const log = document.getElementById('log');
        let px = 1, py = 1, score = 0;
        let map = [];
        for (let y = 0; y < 12; y++) {
            map[y] = [];
            for (let x = 0; x < 12; x++) {
                if (x === 0 || x === 11 || y === 0 || y === 11) map[y][x] = '#';
                else if (Math.random() < 0.12) map[y][x] = 'E';
                else if (Math.random() < 0.06) map[y][x] = 'C';
                else map[y][x] = '.';
            }
        }
        map[py][px] = '@';

        function render() {
            grid.innerHTML = '';
            for (let y = 0; y < 12; y++) {
                for (let x = 0; x < 12; x++) {
                    const c = document.createElement('div');
                    c.className = 'cell';
                    if (map[y][x] === '@') { c.innerText = '👾'; c.classList.add('player'); }
                    else if (map[y][x] === 'E') { c.innerText = '🤖'; c.classList.add('enemy'); }
                    else if (map[y][x] === 'C') { c.innerText = '💎'; c.classList.add('chest'); }
                    else if (map[y][x] === '#') { c.innerText = '◼'; c.style.color = '#333'; }
                    grid.appendChild(c);
                }
            }
        }

        window.addEventListener('keydown', e => {
            let nx = px, ny = py;
            if (e.key === 'ArrowUp' || e.key === 'w') ny--;
            if (e.key === 'ArrowDown' || e.key === 's') ny++;
            if (e.key === 'ArrowLeft' || e.key === 'a') nx--;
            if (e.key === 'ArrowRight' || e.key === 'd') nx++;
            if (map[ny][nx] !== '#') {
                if (map[ny][nx] === 'E') { log.innerText = '⚡ You eliminated a Rogue Security Drone! (+100 XP)'; score += 100; }
                else if (map[ny][nx] === 'C') { log.innerText = '💎 Energy core acquired! (+250 Credits)'; score += 250; }
                else { log.innerText = \`Agent moving through sector (\${nx}, \${ny}). Score: \${score}\`; }
                map[py][px] = '.';
                px = nx; py = ny;
                map[py][px] = '@';
                render();
            }
        });
        render();
    </script>
</body>
</html>`
      }
    ]
  }
];
