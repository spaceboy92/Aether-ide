const fs = require('fs');
let code = fs.readFileSync('components/Tools/OllamaIntegrationModal.tsx', 'utf8');

const target = `<div className="space-y-2">
            <label className="text-[10px] font-black uppercase tracking-wider text-zinc-400 flex items-center justify-between">
              <span>Ollama Endpoint URL</span>
              <span className="text-zinc-500 font-mono font-normal">Default: http://127.0.0.1:11434</span>
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={endpoint}
                onChange={(e) => setEndpoint(e.target.value)}
                className="flex-1 bg-black/60 border border-zinc-800 rounded-xl px-3.5 py-2 text-xs font-mono text-zinc-200 focus:outline-none focus:border-orange-500"
                placeholder="http://127.0.0.1:11434 or http://localhost:11434"
              />
              <button`;

const replacement = `<div className="space-y-2">
            <div className="flex items-end justify-between">
              <label className="text-[10px] font-black uppercase tracking-wider text-zinc-400 flex items-center justify-between">
                <span>AI Provider Endpoint URL</span>
              </label>
              <select 
                className="bg-black text-[10px] text-zinc-300 border border-zinc-800 rounded px-1.5 py-0.5 cursor-pointer focus:outline-none focus:border-orange-500 outline-none"
                onChange={e => {
                  if (e.target.value && e.target.value !== 'custom') {
                    setEndpoint(e.target.value);
                  } else if (e.target.value === 'custom') {
                    setEndpoint('');
                  }
                }}
                value={
                  ['https://api.openai.com/v1', 'https://api.groq.com/openai/v1', 'https://openrouter.ai/api/v1', 'https://api.together.xyz/v1', 'https://api.deepseek.com/v1', 'http://localhost:11434', 'http://127.0.0.1:11434'].includes(endpoint) ? endpoint : 'custom'
                }
              >
                <option value="custom">Custom / Other</option>
                <option value="https://openrouter.ai/api/v1">OpenRouter</option>
                <option value="https://api.groq.com/openai/v1">Groq</option>
                <option value="https://api.openai.com/v1">OpenAI</option>
                <option value="https://api.together.xyz/v1">Together AI</option>
                <option value="https://api.deepseek.com/v1">DeepSeek</option>
                <option value="http://127.0.0.1:11434">Local Ollama</option>
              </select>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={endpoint}
                onChange={(e) => setEndpoint(e.target.value)}
                className="flex-1 bg-black/60 border border-zinc-800 rounded-xl px-3.5 py-2 text-xs font-mono text-zinc-200 focus:outline-none focus:border-orange-500"
                placeholder="e.g. https://openrouter.ai/api/v1"
              />
              <button`;

let patched = false;
if (code.includes(target)) {
  code = code.replace(target, replacement);
  patched = true;
  console.log("Patched modal URL input");
}

if(patched) {
  fs.writeFileSync('components/Tools/OllamaIntegrationModal.tsx', code);
} else {
  console.log("Could not find targets");
}
