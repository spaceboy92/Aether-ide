const fs = require('fs');
const file = 'components/Layout/MainHeader.tsx';
let content = fs.readFileSync(file, 'utf8');

// replace React import if it doesn't have useState
if (!content.includes('useState')) {
  content = content.replace(
    'import React from "react";',
    'import React, { useState } from "react";'
  );
}

// add import for Rocket icon if missing
if (!content.includes('Rocket')) {
  content = content.replace(
    '  Laptop\n} from "lucide-react";',
    '  Laptop,\n  Rocket\n} from "lucide-react";'
  );
}

// add state
if (!content.includes('networkBoost')) {
  content = content.replace(
    'const MainHeader: React.FC<MainHeaderProps> = ({',
    'const MainHeader: React.FC<MainHeaderProps> = ({\n  networkBoost = false,\n  setNetworkBoost = () => {},\n  '
  );
}

const buttonHtml = `
        {/* Network Booster */}
        <button
          onClick={() => {
            if (typeof window !== 'undefined') {
              const current = localStorage.getItem('aether_network_boost') === 'true';
              localStorage.setItem('aether_network_boost', (!current).toString());
              window.dispatchEvent(new Event('aether_network_boost'));
            }
          }}
          className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-white/[0.03] hover:bg-white/[0.08] border border-white/5 rounded-xl transition-all mr-2"
          title="Network Booster"
        >
          <Rocket size={14} className="text-purple-400" />
          <span className="text-[9px] font-black uppercase tracking-widest text-white/70">Boost</span>
        </button>

        {/* Extra Desktop Controls */}`;

content = content.replace(
  '{/* Extra Desktop Controls */}',
  buttonHtml
);

fs.writeFileSync(file, content);
