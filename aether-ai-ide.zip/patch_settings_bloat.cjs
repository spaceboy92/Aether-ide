const fs = require('fs');

let settingsCode = fs.readFileSync('components/Settings/SettingsView.tsx', 'utf8');
const settingsTarget = `const savedStr = localStorage.getItem('aether_custom_ai_models');
        let customList = savedStr ? JSON.parse(savedStr) : [];`;
const settingsReplacement = `let customList: any[] = [];`;

if (settingsCode.includes(settingsTarget)) {
  settingsCode = settingsCode.replace(settingsTarget, settingsReplacement);
  fs.writeFileSync('components/Settings/SettingsView.tsx', settingsCode);
  console.log("Patched SettingsView");
}

let modalCode = fs.readFileSync('components/Tools/OllamaIntegrationModal.tsx', 'utf8');
const modalTarget = `const savedStr = localStorage.getItem('aether_custom_ai_models');
          let customList = savedStr ? JSON.parse(savedStr) : [];`;
const modalReplacement = `let customList: any[] = [];`;

if (modalCode.includes(modalTarget)) {
  modalCode = modalCode.replace(modalTarget, modalReplacement);
  fs.writeFileSync('components/Tools/OllamaIntegrationModal.tsx', modalCode);
  console.log("Patched OllamaIntegrationModal");
}
