import { FileNode } from "../types";
import { generateContent } from "./aiService";
import { Terminal, Flame, Cpu, Code2, Sparkles, AlertCircle, FileCode, CheckCircle2, ShieldAlert } from "lucide-react";

export interface CompilerDiagnostic {
  file: string;
  line: number;
  column?: number;
  severity: "error" | "warning" | "info";
  code?: string; // e.g. "E0308", "SyntaxError", "CS0103", "gcc: error"
  message: string;
  sourceSnippet?: string;
  fixSuggestion?: string;
  autoFixable?: boolean;
}

export interface CompilationResult {
  success: boolean;
  language: string;
  filename: string;
  stdout: string;
  stderr: string;
  exitCode: number;
  durationMs: number;
  runtime: string;
  diagnostics: CompilerDiagnostic[];
  rawOutput?: string;
}

export interface WorkspaceErrorReport {
  scannedAt: number;
  totalFiles: number;
  filesWithErrors: number;
  totalErrors: number;
  totalWarnings: number;
  diagnostics: CompilerDiagnostic[];
}

export interface LanguageDefinition {
  id: string;
  name: string;
  extensions: string[];
  compiler: string;
  cmd: string;
  color: string;
  category: "systems" | "scripting" | "web" | "mobile" | "data" | "jvm";
  sampleCode: string;
}

export const SUPPORTED_LANGUAGES: LanguageDefinition[] = [
  {
    id: "python",
    name: "Python 3.10",
    extensions: [".py", ".pyw"],
    compiler: "Python Native Interpreter / CPython",
    cmd: "python3",
    color: "text-yellow-400",
    category: "scripting",
    sampleCode: `def main():\n    print("Hello from Python 3.10!")\n    numbers = [x * 2 for x in range(5)]\n    print(f"Computed numbers: {numbers}")\n\nif __name__ == "__main__":\n    main()`
  },
  {
    id: "rust",
    name: "Rust 2021",
    extensions: [".rs"],
    compiler: "rustc Native Compiler / Cargo",
    cmd: "cargo run",
    color: "text-orange-500",
    category: "systems",
    sampleCode: `fn main() {\n    println!("Hello from high-performance Rust!");\n    let msg = String::from("Aether Universal Engine");\n    println!("Target: {}", msg);\n}`
  },
  {
    id: "cpp",
    name: "C++ (C++20)",
    extensions: [".cpp", ".cc", ".cxx", ".hpp"],
    compiler: "GCC / Clang Compiler (g++ -O2)",
    cmd: "g++ -O2",
    color: "text-sky-400",
    category: "systems",
    sampleCode: `#include <iostream>\n#include <vector>\n#include <numeric>\n\nint main() {\n    std::cout << "Hello from C++20 Engine!" << std::endl;\n    std::vector<int> v = {1, 2, 3, 4, 5};\n    int sum = std::accumulate(v.begin(), v.end(), 0);\n    std::cout << "Vector Sum = " << sum << std::endl;\n    return 0;\n}`
  },
  {
    id: "c",
    name: "C (C17)",
    extensions: [".c", ".h"],
    compiler: "GCC C Compiler (gcc -O2)",
    cmd: "gcc -O2",
    color: "text-blue-400",
    category: "systems",
    sampleCode: `#include <stdio.h>\n\nint main() {\n    printf("Hello from C17 Kernel!\\n");\n    int a = 10, b = 20;\n    printf("Result: %d + %d = %d\\n", a, b, a + b);\n    return 0;\n}`
  },
  {
    id: "go",
    name: "Go (Golang 1.22)",
    extensions: [".go"],
    compiler: "Go Toolchain Compiler",
    cmd: "go run",
    color: "text-cyan-400",
    category: "systems",
    sampleCode: `package main\n\nimport "fmt"\n\nfunc main() {\n    fmt.Println("Hello from Go concurrent runtime!")\n    ch := make(chan string)\n    go func() { ch <- "Channel Data Received" }()\n    fmt.Println(<-ch)\n}`
  },
  {
    id: "java",
    name: "Java (OpenJDK 21)",
    extensions: [".java"],
    compiler: "Java Virtual Machine (javac / java)",
    cmd: "java",
    color: "text-amber-500",
    category: "jvm",
    sampleCode: `public class Main {\n    public static void main(String[] args) {\n        System.out.println("Hello from OpenJDK 21 JVM!");\n        var list = java.util.List.of("Alpha", "Beta", "Gamma");\n        list.forEach(System.out::println);\n    }\n}`
  },
  {
    id: "kotlin",
    name: "Kotlin 2.0",
    extensions: [".kt", ".kts"],
    compiler: "Kotlin JVM / Native Compiler",
    cmd: "kotlinc",
    color: "text-purple-400",
    category: "jvm",
    sampleCode: `fun main() {\n    println("Hello from Kotlin 2.0!")\n    val items = listOf("Compose", "Coroutines", "Multiplatform")\n    println("Capabilities: \${items.joinToString()}")\n}`
  },
  {
    id: "csharp",
    name: "C# / .NET 8",
    extensions: [".cs"],
    compiler: ".NET Core 8.0 Compiler (Roslyn)",
    cmd: "dotnet run",
    color: "text-indigo-400",
    category: "systems",
    sampleCode: `using System;\n\nclass Program {\n    static void Main() {\n        Console.WriteLine("Hello from .NET 8 C#!");\n        int sum = 40 + 2;\n        Console.WriteLine($"Computed answer: {sum}");\n    }\n}`
  },
  {
    id: "typescript",
    name: "TypeScript 5.4",
    extensions: [".ts", ".tsx"],
    compiler: "TypeScript Compiler / TSX Node V8",
    cmd: "npx tsx",
    color: "text-blue-400",
    category: "web",
    sampleCode: `interface User {\n  id: number;\n  name: string;\n  role: string;\n}\n\nconst user: User = {\n  id: 1,\n  name: "Aether Developer",\n  role: "Lead Architect"\n};\n\nconsole.log("TypeScript Engine Active:", user);`
  },
  {
    id: "javascript",
    name: "JavaScript (Node.js 20)",
    extensions: [".js", ".mjs", ".cjs"],
    compiler: "Node.js V8 JavaScript Runtime",
    cmd: "node",
    color: "text-yellow-300",
    category: "web",
    sampleCode: `console.log("Hello from Node.js V8 Engine!");\nconst data = [1, 2, 3].map(n => n ** 3);\nconsole.log("Cube array:", data);`
  },
  {
    id: "ruby",
    name: "Ruby 3.3",
    extensions: [".rb"],
    compiler: "Ruby YJIT Runtime",
    cmd: "ruby",
    color: "text-red-400",
    category: "scripting",
    sampleCode: `puts "Hello from Ruby 3.3!"\ngreetings = ["Ruby", "Rails", "Fiber"]\nputs greetings.map(&:upcase).join(", ")`
  },
  {
    id: "php",
    name: "PHP 8.3",
    extensions: [".php"],
    compiler: "PHP 8.3 Zend Engine",
    cmd: "php",
    color: "text-indigo-300",
    category: "web",
    sampleCode: `<?php\necho "Hello from PHP 8.3 Zend Engine!\\n";\n$items = ["Fast", "Modern", "Typed"];\nprint_r($items);\n?>`
  },
  {
    id: "bash",
    name: "Bash / Shell",
    extensions: [".sh", ".bash", ".zsh"],
    compiler: "GNU Bash 5.2 Shell Container",
    cmd: "bash",
    color: "text-emerald-400",
    category: "scripting",
    sampleCode: `#!/bin/bash\necho "Hello from Bash Linux VM Sandbox!"\necho "Date: $(date)"\necho "Uptime: $(uptime)"`
  },
  {
    id: "lua",
    name: "Lua 5.4 / Roblox Script",
    extensions: [".lua"],
    compiler: "Lua 5.4 JIT Engine",
    cmd: "lua",
    color: "text-blue-300",
    category: "scripting",
    sampleCode: `print("Hello from Lua 5.4!")\nlocal table_data = { score = 100, player = "Hero" }\nfor k, v in pairs(table_data) do\n    print(k .. ": " .. tostring(v))\nend`
  },
  {
    id: "sql",
    name: "SQL (SQLite3 / Postgres)",
    extensions: [".sql"],
    compiler: "SQLite 3.45 Engine & Schema Validator",
    cmd: "sqlite3",
    color: "text-teal-400",
    category: "data",
    sampleCode: `CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT, role TEXT);\nINSERT INTO users (name, role) VALUES ('Alice', 'Admin'), ('Bob', 'Developer');\nSELECT * FROM users;`
  },
  {
    id: "swift",
    name: "Swift 5.9",
    extensions: [".swift"],
    compiler: "Swift Native Compiler",
    cmd: "swift",
    color: "text-orange-400",
    category: "mobile",
    sampleCode: `import Foundation\n\nprint("Hello from Swift 5.9!")\nlet numbers = [10, 20, 30]\nprint("Sum: \\(numbers.reduce(0, +))")`
  },
  {
    id: "dart",
    name: "Dart 3.4",
    extensions: [".dart"],
    compiler: "Dart AOT & JIT Virtual Machine",
    cmd: "dart run",
    color: "text-sky-500",
    category: "mobile",
    sampleCode: `void main() {\n  print('Hello from Dart 3.4 VM!');\n  final list = ['Flutter', 'Native', 'Server'];\n  print(list.join(' • '));\n}`
  },
  {
    id: "r",
    name: "R Statistical Engine",
    extensions: [".r", ".R"],
    compiler: "R Statistical Computing Language",
    cmd: "Rscript",
    color: "text-blue-500",
    category: "data",
    sampleCode: `cat("Hello from R Statistical Engine!\\n")\nx <- c(12, 15, 23, 42, 56)\ncat("Mean:", mean(x), "SD:", sd(x), "\\n")`
  }
];

export class UniversalCompilerService {
  /**
   * Detect language metadata from filename or extension
   */
  public getLanguageMeta(filename: string): LanguageDefinition {
    const lower = filename.toLowerCase();
    for (const lang of SUPPORTED_LANGUAGES) {
      if (lang.extensions.some(ext => lower.endsWith(ext))) {
        return lang;
      }
    }
    return {
      id: "generic",
      name: "Universal Code File",
      extensions: [],
      compiler: "Universal Compiler Engine",
      cmd: "exec",
      color: "text-zinc-400",
      category: "scripting",
      sampleCode: `// Code file: ${filename}`
    };
  }

  /**
   * Check if a file is a runnable/compilable code file
   */
  public isCompilableFile(filename: string): boolean {
    const lower = filename.toLowerCase();
    return SUPPORTED_LANGUAGES.some(lang => lang.extensions.some(ext => lower.endsWith(ext)));
  }

  /**
   * Compile and execute any code file in any language
   */
  public async compileAndExecute(
    file: FileNode,
    allFiles: FileNode[] = []
  ): Promise<CompilationResult> {
    const startTime = Date.now();
    const langMeta = this.getLanguageMeta(file.name);

    // 1. Try Linux VM Container Backend First
    try {
      const response = await fetch("/api/multilang/execute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filename: file.name,
          code: file.content,
          language: langMeta.id,
          files: allFiles.map(f => ({ name: f.name, content: f.content }))
        })
      });

      if (response.ok) {
        const data = await response.json();
        const duration = data.durationMs || (Date.now() - startTime);
        
        // Parse diagnostics if stderr contains compiler errors
        let diagnostics: CompilerDiagnostic[] = [];
        if (data.stderr && data.stderr.trim()) {
          diagnostics = this.parseRawCompilerErrors(data.stderr, file.name, langMeta.id);
        }

        // If local compiler ran and returned output
        if (data.stdout || data.stderr) {
          return {
            success: data.success && (!data.stderr || data.stderr.trim() === ""),
            language: langMeta.id,
            filename: file.name,
            stdout: data.stdout || "",
            stderr: data.stderr || "",
            exitCode: data.stderr && !data.stdout ? 1 : 0,
            durationMs: duration,
            runtime: data.runtime || `${langMeta.name} (Linux Container)`,
            diagnostics,
            rawOutput: (data.stdout || "") + (data.stderr ? `\n${data.stderr}` : "")
          };
        }
      }
    } catch (e) {
      console.warn("Backend multilang execution error, switching to AI compiler simulation:", e);
    }

    // 2. High-Fidelity Universal Compiler Engine via Gemini 3.7 Flash
    try {
      const prompt = `You are a high-performance compiler and virtual runtime engine for "${langMeta.name}".
You are compiling and executing the file "${file.name}".

SOURCE CODE:
\`\`\`${langMeta.id}
${file.content}
\`\`\`

TASK:
1. Perform exact static compiler checks (syntax analysis, type checking, borrow-checker for Rust, semicolons/imports for C/C++/Java/Go, indentation for Python, etc.).
2. If there are syntax errors or compiler failures, output the EXACT compiler error messages in standard ${langMeta.compiler} diagnostic format with line numbers and file paths.
3. If the code compiles cleanly, simulate execution and output the exact stdout program results.
4. Also extract all structured diagnostic errors into a JSON block if errors exist.

Return pure JSON matching this schema:
{
  "success": boolean,
  "exitCode": number,
  "stdout": "program stdout text",
  "stderr": "compiler or runtime error text",
  "diagnostics": [
    {
      "file": "${file.name}",
      "line": number,
      "column": number,
      "severity": "error" | "warning",
      "code": "e.g. E0308 or SyntaxError or CS0103",
      "message": "clear explanation of error",
      "sourceSnippet": "offending code line",
      "fixSuggestion": "how to correct this error",
      "autoFixable": true
    }
  ]
}`;

      const aiResponse = await generateContent("gemini-3.7-flash", prompt, {
        responseMimeType: "application/json",
        temperature: 0.1
      });

      const duration = Date.now() - startTime;
      if (aiResponse) {
        const parsed = JSON.parse(aiResponse);
        return {
          success: parsed.success ?? (parsed.diagnostics?.length === 0),
          language: langMeta.id,
          filename: file.name,
          stdout: parsed.stdout || "",
          stderr: parsed.stderr || (parsed.diagnostics?.length > 0 ? parsed.diagnostics.map((d: any) => `Error [${d.code || 'Diagnostic'}]: ${d.message} (Line ${d.line})`).join('\n') : ""),
          exitCode: parsed.exitCode ?? (parsed.success ? 0 : 1),
          durationMs: duration,
          runtime: `${langMeta.name} (Universal Toolchain)`,
          diagnostics: (parsed.diagnostics || []).map((d: any) => ({
            file: d.file || file.name,
            line: Number(d.line) || 1,
            column: d.column ? Number(d.column) : undefined,
            severity: d.severity || "error",
            code: d.code || "CompilerError",
            message: d.message || "Compilation error",
            sourceSnippet: d.sourceSnippet || "",
            fixSuggestion: d.fixSuggestion || "Check syntax",
            autoFixable: d.autoFixable !== false
          })),
          rawOutput: (parsed.stdout || "") + (parsed.stderr ? `\n${parsed.stderr}` : "")
        };
      }
    } catch (aiErr: any) {
      console.error("Universal compilation engine failure:", aiErr);
    }

    // Fallback if both fail
    return {
      success: false,
      language: langMeta.id,
      filename: file.name,
      stdout: "",
      stderr: `Universal Compiler execution timed out or encountered an unexpected system state.`,
      exitCode: 1,
      durationMs: Date.now() - startTime,
      runtime: langMeta.name,
      diagnostics: [
        {
          file: file.name,
          line: 1,
          severity: "error",
          code: "SystemFault",
          message: "Could not complete compiler pass",
          fixSuggestion: "Verify file syntax and try again"
        }
      ]
    };
  }

  /**
   * Perform static code analysis and check for syntax/compiler errors
   */
  public async checkFileErrors(
    file: FileNode,
    allFiles: FileNode[] = []
  ): Promise<{ hasErrors: boolean; diagnostics: CompilerDiagnostic[]; summary: string }> {
    const langMeta = this.getLanguageMeta(file.name);

    try {
      const prompt = `You are a strict static code analyzer and compiler error checker.
Analyze the following source code file "${file.name}" in language "${langMeta.name}".

SOURCE CODE:
\`\`\`${langMeta.id}
${file.content}
\`\`\`

Return a JSON object:
{
  "hasErrors": boolean,
  "summary": "1-sentence summary of code validity",
  "diagnostics": [
    {
      "file": "${file.name}",
      "line": number,
      "column": number,
      "severity": "error" | "warning" | "info",
      "code": "error code like E0308 or SyntaxError or NameError",
      "message": "exact error explanation",
      "sourceSnippet": "code snippet on that line",
      "fixSuggestion": "exact step to fix",
      "autoFixable": boolean
    }
  ]
}`;

      const response = await generateContent("gemini-3.7-flash", prompt, {
        responseMimeType: "application/json",
        temperature: 0.1
      });

      if (response) {
        const parsed = JSON.parse(response);
        const diagnostics: CompilerDiagnostic[] = (parsed.diagnostics || []).map((d: any) => ({
          file: d.file || file.name,
          line: Number(d.line) || 1,
          column: d.column ? Number(d.column) : undefined,
          severity: d.severity || "error",
          code: d.code || "SyntaxError",
          message: d.message || "Syntax issue detected",
          sourceSnippet: d.sourceSnippet || "",
          fixSuggestion: d.fixSuggestion || "Review line syntax",
          autoFixable: d.autoFixable !== false
        }));

        return {
          hasErrors: parsed.hasErrors ?? diagnostics.some(d => d.severity === "error"),
          diagnostics,
          summary: parsed.summary || (diagnostics.length === 0 ? "0 errors detected" : `${diagnostics.length} issues found`)
        };
      }
    } catch (err) {
      console.error("Static error check error:", err);
    }

    return {
      hasErrors: false,
      diagnostics: [],
      summary: "Static analysis complete"
    };
  }

  /**
   * Scan entire workspace and check all files across all languages for errors
   */
  public async scanWorkspace(files: FileNode[]): Promise<WorkspaceErrorReport> {
    const compilableFiles = files.filter(f => this.isCompilableFile(f.name) && f.content.trim().length > 0);
    const allDiagnostics: CompilerDiagnostic[] = [];

    // Parallel check in small batches of 4
    for (let i = 0; i < compilableFiles.length; i += 4) {
      const batch = compilableFiles.slice(i, i + 4);
      const results = await Promise.all(
        batch.map(file => this.checkFileErrors(file, files))
      );
      results.forEach(res => {
        allDiagnostics.push(...res.diagnostics);
      });
    }

    const errors = allDiagnostics.filter(d => d.severity === "error");
    const warnings = allDiagnostics.filter(d => d.severity === "warning");
    const filesWithErrors = new Set(errors.map(d => d.file)).size;

    return {
      scannedAt: Date.now(),
      totalFiles: compilableFiles.length,
      filesWithErrors,
      totalErrors: errors.length,
      totalWarnings: warnings.length,
      diagnostics: allDiagnostics
    };
  }

  /**
   * AI Auto-Fix code errors for any language
   */
  public async autoFixCode(
    file: FileNode,
    diagnostics: CompilerDiagnostic[] = []
  ): Promise<{ success: boolean; fixedContent: string; changelog: string }> {
    const langMeta = this.getLanguageMeta(file.name);
    const issuesText = diagnostics.map((d, i) => `Issue #${i + 1} (Line ${d.line}): ${d.message} [Code: ${d.code || 'None'}] -> Suggestion: ${d.fixSuggestion}`).join('\n');

    try {
      const prompt = `You are a master software engineer fixing compiler, syntax, and runtime errors in ${langMeta.name}.
File: "${file.name}"

DIAGNOSTICS & ERRORS TO FIX:
${issuesText || 'Fix all syntax, type, borrow-checker, and runtime bugs in this file.'}

ORIGINAL SOURCE CODE:
\`\`\`${langMeta.id}
${file.content}
\`\`\`

Return a JSON object:
{
  "success": true,
  "changelog": "Brief 1-2 bullet points explaining exact code corrections made",
  "fixedCode": "Full corrected code here"
}`;

      const response = await generateContent("gemini-3.7-flash", prompt, {
        responseMimeType: "application/json",
        temperature: 0.1
      });

      if (response) {
        const parsed = JSON.parse(response);
        let clean = parsed.fixedCode || "";
        // Strip accidental markdown fences if any
        clean = clean.replace(/^```[a-zA-Z0-9_-]*\n/, "").replace(/\n```$/, "").trim();

        return {
          success: true,
          fixedContent: clean || file.content,
          changelog: parsed.changelog || "Fixed compiler syntax and type mismatches."
        };
      }
    } catch (err) {
      console.error("AutoFix failed:", err);
    }

    return {
      success: false,
      fixedContent: file.content,
      changelog: "Fix operation failed."
    };
  }

  /**
   * Parser for raw compiler stderr logs (gcc, rustc, python, etc.)
   */
  private parseRawCompilerErrors(stderr: string, filename: string, language: string): CompilerDiagnostic[] {
    const diagnostics: CompilerDiagnostic[] = [];
    const lines = stderr.split('\n');

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];

      // Python Traceback line detection: File "main.py", line 14, in <module>
      const pyMatch = line.match(/File "([^"]+)", line (\d+)(?:, in (.+))?/);
      if (pyMatch) {
        const nextLine = lines[i + 1] || "";
        const errLine = lines[i + 2] || lines[i + 1] || "";
        diagnostics.push({
          file: pyMatch[1],
          line: parseInt(pyMatch[2], 10),
          severity: "error",
          code: errLine.split(':')[0]?.trim() || "PythonError",
          message: errLine.trim() || nextLine.trim() || "Python runtime exception",
          sourceSnippet: nextLine.trim(),
          fixSuggestion: "Check traceback exception and variable definitions",
          autoFixable: true
        });
        continue;
      }

      // Rust error: error[E0308]: mismatched types --> src/main.rs:4:5
      const rustMatch = line.match(/error(?:\[([^\]]+)\])?: (.+)/);
      if (rustMatch) {
        const nextLocMatch = lines[i + 1]?.match(/--> ([^:]+):(\d+):(\d+)/);
        diagnostics.push({
          file: nextLocMatch ? nextLocMatch[1] : filename,
          line: nextLocMatch ? parseInt(nextLocMatch[2], 10) : 1,
          column: nextLocMatch ? parseInt(nextLocMatch[3], 10) : undefined,
          severity: "error",
          code: rustMatch[1] || "rustc:error",
          message: rustMatch[2],
          fixSuggestion: "Check Rust types and borrow checker rules",
          autoFixable: true
        });
        continue;
      }

      // GCC/Clang: main.cpp:12:5: error: 'x' was not declared in this scope
      const gccMatch = line.match(/^([^:]+):(\d+):(\d+):\s+(error|warning):\s+(.+)/);
      if (gccMatch) {
        diagnostics.push({
          file: gccMatch[1],
          line: parseInt(gccMatch[2], 10),
          column: parseInt(gccMatch[3], 10),
          severity: gccMatch[4] === "warning" ? "warning" : "error",
          code: "GCCError",
          message: gccMatch[5],
          fixSuggestion: "Check syntax and declarations",
          autoFixable: true
        });
        continue;
      }
    }

    return diagnostics;
  }
}

export const universalCompilerService = new UniversalCompilerService();
export default universalCompilerService;
