import { FileNode, ChatMessage } from '../types';
import { parseAIResponse, SimpleAIResponse } from './geminiService';
import { addCustomModel, CustomAIModel, detectProviderFromEndpoint } from './aiService';

export const autoFetchAndSyncOllamaModels = async (): Promise<CustomAIModel[]> => {
  try {
    const models = await fetchInstalledOllamaModels();
    if (!models || models.length === 0) return [];

    const serverUrl = getOllamaServerUrl();
    const fetchedModels: CustomAIModel[] = [];

    for (const m of models) {
      const modelTag = m.name || m.model;
      if (!modelTag) continue;
      const cleanName = modelTag.replace(/^ollama_/i, '');
      const providerInfo = detectProviderFromEndpoint(serverUrl, cleanName);

      const added = addCustomModel({
        id: cleanName,
        name: `${cleanName} (${providerInfo.providerName})`,
        description: `${providerInfo.providerName} Model: ${cleanName} (${m.details?.parameter_size || 'Installed'})`,
        type: providerInfo.type
      });
      fetchedModels.push(added);
    }
    return fetchedModels;
  } catch (err) {
    return [];
  }
};

export const getOllamaAuthMode = (): 'url' | 'key' => {
  if (typeof window !== 'undefined') {
    return (localStorage.getItem('ollama_auth_mode') as 'url' | 'key') || 'url';
  }
  return 'url';
};

export const getOllamaServerUrl = (): string => {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('ollama_server_url') || 'http://localhost:11434';
  }
  return 'http://localhost:11434';
};

export const setOllamaServerUrl = (url: string): void => {
  if (typeof window !== 'undefined') {
    let cleanUrl = url.trim().replace(/\/+$/, '');
    if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
      cleanUrl = 'http://' + cleanUrl;
    }
    localStorage.setItem('ollama_server_url', cleanUrl);
  }
};

export const getOllamaApiKey = (): string => {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('ollama_api_key') || '';
  }
  return '';
};

export const setOllamaApiKey = (key: string): void => {
  if (typeof window !== 'undefined') {
    localStorage.setItem('ollama_api_key', key.trim());
  }
};

export interface OllamaModelTag {
  name: string;
  model: string;
  modified_at?: string;
  size?: number;
  details?: {
    family?: string;
    parameter_size?: string;
    format?: string;
  };
}

export const fetchInstalledOllamaModels = async (customServerUrl?: string): Promise<OllamaModelTag[]> => {
  const serverUrl = customServerUrl || getOllamaServerUrl();
  const apiKey = getOllamaApiKey();

  // Attempt 1: Server-side Proxy (Prioritized to bypass browser CORS & Mixed Content on localhost)
  try {
    const res = await fetch(`/api/ollama/tags?serverUrl=${encodeURIComponent(serverUrl)}&apiKey=${encodeURIComponent(apiKey)}`);
    if (res.ok) {
      const data = await res.json();
      return data.models || [];
    }
  } catch (err: any) {}

  // Attempt 2: Direct Fetch from browser
  try {
    const headers: any = { 'Accept': 'application/json' };
    if (apiKey) {
      headers['Authorization'] = `Bearer ${apiKey}`;
    }
    const res = await fetch(`${serverUrl}/api/tags`, {
      method: 'GET',
      headers
    });
    if (res.ok) {
      const data = await res.json();
      return data.models || [];
    }
  } catch (err) {}

  return [];
};

const generateOllamaHelpfulErrorMessage = (modelName: string, serverUrl: string, detail: string): SimpleAIResponse => {
  const message = `### ⚠️ Ollama Connection Error

Unable to communicate with Ollama model **\`${modelName}\`** at **${serverUrl}**.

**Error Details:** \`${detail}\`

---

### 🛠️ Step-by-Step Fix:

#### 1. Enable CORS Origins on Ollama
In modern browsers, cross-origin web app requests to \`http://localhost:11434\` require CORS headers enabled on your Ollama server:

- **macOS / Linux Terminal:**
  \`\`\`bash
  OLLAMA_ORIGINS="*" ollama serve
  \`\`\`
- **Windows (Command Prompt):**
  \`\`\`cmd
  set OLLAMA_ORIGINS=*
  ollama serve
  \`\`\`
- **Windows (PowerShell):**
  \`\`\`powershell
  $env:OLLAMA_ORIGINS="*"
  ollama serve
  \`\`\`

#### 2. Confirm the Model is Pulled
Ensure the target model is installed on your local machine:
\`\`\`bash
ollama pull ${modelName}
\`\`\`

#### 3. Remote / LAN Setup
If Ollama is hosted on a different computer, network server, or tunnel:
1. Open **Settings → AI Engine & Keys**.
2. Enter your Ollama URL in **Ollama Endpoint URL** (e.g., \`http://192.168.1.100:11434\` or \`https://xxxx.ngrok-free.app\`).

---

💡 **Instant Alternative:** Select **Qwen 2.5 (In-Browser WebGPU)** from the AI Model dropdown to run local AI completely offline inside your browser without any server setup!`;

  return {
    message,
    thoughts: `Ollama connection failed to ${serverUrl}: ${detail}`,
    files: [],
    commands: []
  };
};

export const chatWithOllamaStream = async (
  modelId: string,
  prompt: string,
  currentFiles: FileNode[],
  history: ChatMessage[],
  onChunk: (thoughts: string, message: string, steps?: { step: string; status: string }[], codeFragment?: string) => void,
  onRawChunk?: (text: string) => void
): Promise<SimpleAIResponse> => {
  const serverUrl = getOllamaServerUrl();
  let targetModelName = modelId.replace(/^ollama[_:]/i, '');
  if (targetModelName === 'nemotron') targetModelName = 'nemotron-mini';

  const workspaceMap = currentFiles.map(f => `- ${f.name} (${f.language || 'text'}, ${f.content?.length || 0} bytes)`).join('\n');
  const systemPrompt = `You are Aether Ollama Agent, powered by local LLM model (${targetModelName}).
You function as both a helpful AI coding assistant and an autonomous co-developer.

WORKSPACE FILES:
${workspaceMap || 'Workspace is empty.'}

Generate high quality code with proper syntax and file paths when requested. Use standard markdown code blocks with file names like \`\`\`tsx path=src/App.tsx.`;

  const messages: { role: string; content: string }[] = [
    { role: 'system', content: systemPrompt }
  ];

  for (const h of history) {
    messages.push({
      role: h.role === 'model' ? 'assistant' : 'user',
      content: h.text
    });
  }
  messages.push({ role: 'user', content: prompt });

  onChunk("Connecting to Ollama server...", `[OLLAMA ENGINE: ${targetModelName}] Connecting to ${serverUrl}...`, [{ step: `Streaming from Ollama (${targetModelName})...`, status: "active" }]);

  let reader: ReadableStreamDefaultReader<Uint8Array> | null = null;
  let connectionErrorDetail = "";

  const apiKey = getOllamaApiKey();

  // Attempt 1: Express Server Proxy (Prioritized to bypass CORS & Mixed Content)
  try {
    const proxyRes = await fetch('/api/ollama/proxy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        serverUrl,
        apiKey,
        endpoint: '/api/chat',
        method: 'POST',
        body: {
          model: targetModelName,
          messages: messages,
          stream: true
        }
      })
    });

    if (proxyRes.ok && proxyRes.body) {
      reader = proxyRes.body.getReader();
    } else {
      const errJson = await proxyRes.json().catch(() => ({}));
      connectionErrorDetail = errJson.error || `Proxy returned HTTP ${proxyRes.status}`;
    }
  } catch (proxyErr: any) {
    console.warn("Ollama Proxy failed, trying direct browser fetch...", proxyErr);
  }

  // Attempt 2: Direct Browser Request Fallback
  if (!reader) {
    try {
      const headers: any = { 'Content-Type': 'application/json' };
      if (apiKey) {
        headers['Authorization'] = `Bearer ${apiKey}`;
      }
      const res = await fetch(`${serverUrl}/api/chat`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          model: targetModelName,
          messages: messages,
          stream: true
        })
      });
      if (res.ok && res.body) {
        reader = res.body.getReader();
      } else if (!res.ok) {
        const errTxt = await res.text().catch(() => '');
        connectionErrorDetail = `Ollama HTTP ${res.status}: ${errTxt || 'Model not found or request rejected'}`;
      }
    } catch (directErr: any) {
      connectionErrorDetail = directErr?.message || connectionErrorDetail || "Failed to fetch from Ollama server";
    }
  }

  if (!reader) {
    console.warn(`[OLLAMA UNREACHABLE] ${targetModelName} at ${serverUrl} failed (${connectionErrorDetail}). Seamlessly falling back to Cloud AI Engine...`);
    
    onChunk(
      `Ollama endpoint ${serverUrl} unreachable (${connectionErrorDetail}). Routing request via Cloud AI Fallback...`,
      `[OLLAMA ENGINE: ${targetModelName}] Local Ollama endpoint at **\`${serverUrl}\`** was unreachable (\`${connectionErrorDetail}\`).\n\n> ⚡ **Seamless Cloud Fallback:** Automatically executing your request via **Gemini 3.7 Flash Cloud Engine**...\n\n`,
      [{ step: "Cloud AI Fallback active...", status: "active" }]
    );

    try {
      const fallbackRes = await fetch('/api/gemini/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          modelId: 'gemini-3.7-flash',
          prompt: `[Requested Model: ${targetModelName} (Ollama)]\n${prompt}`,
          currentFiles,
          history
        })
      });

      if (fallbackRes.ok && fallbackRes.body) {
        const fallbackReader = fallbackRes.body.getReader();
        const decoder = new TextDecoder();
        let fullText = "";
        let extractedThoughts = "";

        while (true) {
          const { done, value } = await fallbackReader.read();
          if (done) break;
          const chunk = decoder.decode(value, { stream: true });
          if (chunk) {
            fullText += chunk;
            const thinkMatch = fullText.match(/<(?:think|thought|reasoning)>([\s\S]*?)(?:<\/(?:think|thought|reasoning)>|$)/i);
            if (thinkMatch && thinkMatch[1]) extractedThoughts = thinkMatch[1].trim();

            const msgMatch = fullText.match(/"message"\s*:\s*"((?:[^"\\]|\\.)*)/);
            let progressiveMsg = "";
            if (msgMatch) {
              progressiveMsg = msgMatch[1].replace(/\\n/g, '\n').replace(/\\"/g, '"');
            } else {
              progressiveMsg = fullText.replace(/<(?:think|thought|reasoning)>[\s\S]*?(?:<\/(?:think|thought|reasoning)>|$)/gi, '').trim();
            }

            const headerNotice = `> ℹ️ **Ollama Connection Note:** Local Ollama server at \`${serverUrl}\` was unreachable (\`${connectionErrorDetail}\`). Processed using **Cloud AI Engine**.\n\n`;
            onChunk(extractedThoughts || `Cloud AI Fallback (${targetModelName})`, headerNotice + progressiveMsg);
          }
        }

        const parsed = parseAIResponse(fullText, extractedThoughts);
        return {
          ...parsed,
          message: `> ℹ️ **Ollama Connection Note:** Local Ollama server at \`${serverUrl}\` was unreachable (\`${connectionErrorDetail}\`). Processed using **Cloud AI Engine**.\n\n` + parsed.message
        };
      }
    } catch (fallbackErr) {
      console.error("Cloud AI Fallback failed as well:", fallbackErr);
    }

    return generateOllamaHelpfulErrorMessage(targetModelName, serverUrl, connectionErrorDetail);
  }

  const decoder = new TextDecoder();
  let accumulatedText = "";
  let buffer = "";

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || "";

      for (const line of lines) {
        if (!line.trim()) continue;
        try {
          const parsed = JSON.parse(line);
          const chunkContent = parsed.message?.content || parsed.response || "";
          accumulatedText += chunkContent;

          let progressiveMsg = "Generating response via Ollama...";
          let thoughtsToPass = `Streaming from Ollama (${targetModelName})`;

          const thoughtsMatch = accumulatedText.match(/"thoughts"\s*:\s*"([^"]*)/);
          if (thoughtsMatch && thoughtsMatch[1]) {
            thoughtsToPass = thoughtsMatch[1].replace(/\\n/g, '\n').replace(/\\"/g, '"');
          }

          const messageMatch = accumulatedText.match(/"message"\s*:\s*"([^"]*)/);
          if (messageMatch && messageMatch[1]) {
            progressiveMsg = messageMatch[1].replace(/\\n/g, '\n').replace(/\\"/g, '"');
          } else {
            progressiveMsg = accumulatedText;
          }

          onChunk(thoughtsToPass, progressiveMsg, [{ step: `Ollama streaming active (${targetModelName})...`, status: "active" }]);
        } catch (e) {
          // Ignore JSON parse error on incomplete line chunks
        }
      }
    }

    return parseAIResponse(accumulatedText);
  } catch (err: any) {
    console.error("Ollama streaming read error:", err);
    return generateOllamaHelpfulErrorMessage(targetModelName, serverUrl, err?.message || "Stream interrupted");
  }
};
