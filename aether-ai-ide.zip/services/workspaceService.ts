import { getAccessToken } from './firebaseAuthService';

async function retryWithBackoff<T extends Response | any>(fn: () => Promise<T>, retries = 3, delay = 1000): Promise<T> {
    try {
        const response = await fn();
        if (response instanceof Response && !response.ok) {
            if (response.status === 401) {
                localStorage.removeItem("google_drive_access_token");
            }
        }
        return response;
    } catch (error: any) {
        if (retries > 0 && (error?.status === 429 || error?.message?.includes('429'))) {
            console.warn(`Drive/Tasks Rate limit hit, retrying in ${delay}ms...`);
            await new Promise(resolve => setTimeout(resolve, delay));
            return retryWithBackoff(fn, retries - 1, delay * 2);
        }
        throw error;
    }
}

/**
 * GOOGLE TASKS API
 */
export const getTaskLists = async () => {
    const token = await getAccessToken();
    if (!token) return { items: [] };

    const res = await retryWithBackoff(() => fetch('https://tasks.googleapis.com/tasks/v1/users/@me/lists', {
        headers: { Authorization: `Bearer ${token}` }
    }));
    return await res.json();
};

export const getTasks = async (listId: string) => {
    const token = await getAccessToken();
    if (!token) return { items: [] };

    const res = await retryWithBackoff(() => fetch(`https://tasks.googleapis.com/tasks/v1/lists/${listId}/tasks?showCompleted=true`, {
        headers: { Authorization: `Bearer ${token}` }
    }));
    return await res.json();
};

export const createTask = async (listId: string, title: string, status: string = 'needsAction') => {
    const token = await getAccessToken();
    if (!token) throw new Error("No token");

    const res = await retryWithBackoff(() => fetch(`https://tasks.googleapis.com/tasks/v1/lists/${listId}/tasks`, {
        method: 'POST',
        headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ title, status })
    }));
    return await res.json();
};

export const updateTask = async (listId: string, taskId: string, title: string, status: string) => {
    const token = await getAccessToken();
    if (!token) throw new Error("No token");

    // Need to get the existing task to ensure etag is proper and we don't overwrite everything
    const existingReq = await retryWithBackoff(() => fetch(`https://tasks.googleapis.com/tasks/v1/lists/${listId}/tasks/${taskId}`, {
        headers: { Authorization: `Bearer ${token}` }
    }));
    const existing = await existingReq.json();

    const res = await retryWithBackoff(() => fetch(`https://tasks.googleapis.com/tasks/v1/lists/${listId}/tasks/${taskId}`, {
        method: 'PUT',
        headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ ...existing, title, status })
    }));
    return await res.json();
};

export const deleteTask = async (listId: string, taskId: string) => {
    const token = await getAccessToken();
    if (!token) throw new Error("No token");
    await retryWithBackoff(() => fetch(`https://tasks.googleapis.com/tasks/v1/lists/${listId}/tasks/${taskId}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
    }));
};

/**
 * GOOGLE DRIVE API
 */
async function getOrCreateFolder(token: string, folderName: string): Promise<string> {
    const searchRes = await retryWithBackoff(() => fetch(`https://www.googleapis.com/drive/v3/files?q=name='${folderName}' and mimeType='application/vnd.google-apps.folder' and trashed=false`, {
        headers: { Authorization: `Bearer ${token}` }
    }));
    const searchData = await searchRes.json();
    if (searchData.files && searchData.files.length > 0) return searchData.files[0].id;

    const createRes = await retryWithBackoff(() => fetch(`https://www.googleapis.com/drive/v3/files`, {
        method: 'POST',
        headers: { 
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name: folderName,
            mimeType: 'application/vnd.google-apps.folder'
        })
    }));
    const folderData = await createRes.json();
    return folderData.id;
}

export const backupToDrive = async (fileName: string, base64Data: string) => {
    const token = await getAccessToken();
    if (!token) throw new Error("No token");

    const folderId = await getOrCreateFolder(token, 'Aether IDE');
    const metadata = { name: fileName, parents: [folderId] };
    const boundary = '-------314159265358979323846';
    const delimiter = "\r\n--" + boundary + "\r\n";
    const close_delim = "\r\n--" + boundary + "--";

    // base64Data is often formatted as data:application/zip;base64,....
    // We only need the payload part.
    let pureBase64 = base64Data;
    if (pureBase64.includes(',')) {
        pureBase64 = pureBase64.split(',')[1];
    }

    const body = delimiter +
        'Content-Type: application/json\r\n\r\n' +
        JSON.stringify(metadata) +
        delimiter +
        'Content-Type: application/zip\r\n' +
        'Content-Transfer-Encoding: base64\r\n\r\n' +
        pureBase64 +
        close_delim;

    const res = await retryWithBackoff(() => fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': `multipart/related; boundary=${boundary}`
        },
        body: body
    }));

    if (!res.ok) {
         const errorData = await res.json().catch(() => ({}));
         console.error('Google Drive Backup Failed:', res.status, errorData);
         throw new Error(`Backup failed: ${res.statusText || 'Unknown Error'}`);
    }
    return await res.json();
};

export const syncAppStateToDrive = async (stateData: any) => {
    const token = await getAccessToken();
    if (!token) return;

    const folderId = await getOrCreateFolder(token, 'Aether IDE');

    // Search for existing aether_app_state.json inside the folder
    const searchRes = await retryWithBackoff(() => fetch(`https://www.googleapis.com/drive/v3/files?q=name='aether_app_state.json' and '${folderId}' in parents and trashed=false`, {
        headers: { Authorization: `Bearer ${token}` }
    }));
    const searchData = await searchRes.json();
    const existingId = searchData.files && searchData.files[0]?.id;

    const metadata = { name: 'aether_app_state.json', mimeType: 'application/json', parents: [folderId] };
    const boundary = '-------314159265358979323846';
    const delimiter = "\r\n--" + boundary + "\r\n";
    const close_delim = "\r\n--" + boundary + "--";

    const body = delimiter +
        'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
        JSON.stringify(metadata) +
        delimiter +
        'Content-Type: application/json\r\n\r\n' +
        JSON.stringify(stateData) +
        close_delim;

    const method = existingId ? 'PATCH' : 'POST';
    const url = existingId ? `https://www.googleapis.com/upload/drive/v3/files/${existingId}?uploadType=multipart` : 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';

    const res = await retryWithBackoff(() => fetch(url, {
        method,
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': `multipart/related; boundary=${boundary}`
        },
        body: body
    }));
    
    if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        console.error('Google Drive Sync Failed:', res.status, errorData);
    }
};

export const loadAppStateFromDrive = async () => {
    const token = await getAccessToken();
    if (!token) return null;

    const folderId = await getOrCreateFolder(token, 'Aether IDE');

    const searchRes = await retryWithBackoff(() => fetch(`https://www.googleapis.com/drive/v3/files?q=name='aether_app_state.json' and '${folderId}' in parents and trashed=false`, {
        headers: { Authorization: `Bearer ${token}` }
    }));
    const searchData = await searchRes.json();
    const existingId = searchData.files && searchData.files[0]?.id;

    if (!existingId) return null;

    const res = await retryWithBackoff(() => fetch(`https://www.googleapis.com/drive/v3/files/${existingId}?alt=media`, {
        headers: { Authorization: `Bearer ${token}` }
    }));
    
    if (!res.ok) return null;
    return await res.json();
};
