import { 
  collection, 
  getDocs, 
  getDoc,
  query, 
  where, 
  setDoc, 
  deleteDoc, 
  doc,
  writeBatch
} from 'firebase/firestore';
import { db, auth } from './firebase';
import { ChatSession, FileNode, UserProfile } from '../types';

// Get or create persistent User ID (supports signed in user OR guest user from first launch)
export const getEffectiveUserId = (): string => {
  if (auth?.currentUser?.uid) return auth.currentUser.uid;
  if (typeof window === 'undefined') return 'guest_default';
  let guestId = localStorage.getItem('aether_guest_uid');
  if (!guestId) {
    guestId = 'guest_' + Date.now().toString(36) + '_' + Math.random().toString(36).substring(2, 7);
    localStorage.setItem('aether_guest_uid', guestId);
  }
  return guestId;
};

// Helper to deeply sanitize undefined properties to null for Firestore compatibility
const sanitize = (val: any): any => {
  return JSON.parse(JSON.stringify(val, (key, value) => {
    return value === undefined ? null : value;
  }));
};

export const firestoreService = {
  // User Profile
  async saveUserProfile(profile: UserProfile): Promise<void> {
    if (!db) return;
    const uid = getEffectiveUserId();
    const userRef = doc(db, 'users', uid);
    await setDoc(userRef, sanitize({
      ...profile,
      ownerId: uid,
      updatedAt: Date.now()
    }), { merge: true });
  },

  async getUserProfile(): Promise<UserProfile | null> {
    if (!db) return null;
    const uid = getEffectiveUserId();
    const userRef = doc(db, 'users', uid);
    const snap = await getDoc(userRef);
    return snap.exists() ? (snap.data() as UserProfile) : null;
  },

  // Chat Sessions (stored in Firestore for both registered & guest users)
  async saveChatSession(session: ChatSession): Promise<void> {
    if (!db) return;
    const uid = getEffectiveUserId();
    const sessionRef = doc(db, 'chat_sessions', session.id);
    await setDoc(sessionRef, sanitize({
      id: session.id,
      title: session.title,
      messages: session.messages || [],
      lastUpdated: session.lastUpdated || Date.now(),
      ownerId: uid
    }), { merge: true });
  },

  async getChatSessions(): Promise<ChatSession[]> {
    if (!db) return [];
    const uid = getEffectiveUserId();
    try {
      const q = query(
        collection(db, 'chat_sessions'),
        where('ownerId', '==', uid)
      );
      const snap = await getDocs(q);
      const sessions: ChatSession[] = [];
      snap.forEach((doc) => {
        sessions.push(doc.data() as ChatSession);
      });
      return sessions;
    } catch (e) {
      console.warn("Could not query chat sessions from Firestore:", e);
      return [];
    }
  },

  async getSingleChatSession(sessionId: string): Promise<ChatSession | null> {
    if (!db) return null;
    try {
      const docRef = doc(db, 'chat_sessions', sessionId);
      const snap = await getDoc(docRef);
      return snap.exists() ? (snap.data() as ChatSession) : null;
    } catch (e) {
      console.warn("Could not fetch single chat session:", e);
      return null;
    }
  },

  async deleteChatSession(sessionId: string): Promise<void> {
    const sessionRef = doc(db, 'chat_sessions', sessionId);
    await deleteDoc(sessionRef);
  },

  // Projects & Files (stored in Firestore for both registered & guest users)
  async saveProject(projectId: string, name: string, description = '', tasks: any[] = []): Promise<void> {
    const uid = getEffectiveUserId();
    const projectRef = doc(db, 'projects', projectId);
    await setDoc(projectRef, sanitize({
      id: projectId,
      name,
      description,
      ownerId: uid,
      tasks: tasks || [],
      createdAt: Date.now(),
      updatedAt: Date.now()
    }), { merge: true });
  },

  async saveFile(projectId: string, file: FileNode): Promise<void> {
    const uid = getEffectiveUserId();
    await this.saveProject(projectId, file.name.split('/').pop() || 'Project File');
    
    const fileRef = doc(db, 'projects', projectId, 'files', file.id);
    await setDoc(fileRef, sanitize({
      id: file.id,
      name: file.name,
      content: file.content || '',
      language: file.language || 'plaintext',
      lastModified: file.lastModified || Date.now(),
      ownerId: uid
    }), { merge: true });
  },

  async saveFiles(projectId: string, files: FileNode[]): Promise<void> {
    if (files.length === 0) return;
    const uid = getEffectiveUserId();
    await this.saveProject(projectId, 'Workspace Project');
    
    const batch = writeBatch(db);
    files.forEach(file => {
      const fileRef = doc(db, 'projects', projectId, 'files', file.id);
      batch.set(fileRef, sanitize({
        id: file.id,
        name: file.name,
        content: file.content || '',
        language: file.language || 'plaintext',
        lastModified: file.lastModified || Date.now(),
        ownerId: uid
      }), { merge: true });
    });
    await batch.commit();
  },

  async deleteFile(projectId: string, fileId: string): Promise<void> {
    const fileRef = doc(db, 'projects', projectId, 'files', fileId);
    await deleteDoc(fileRef);
  },

  async deleteProjectAndFiles(projectId: string): Promise<void> {
    const projectRef = doc(db, 'projects', projectId);
    try {
      const filesSnap = await getDocs(collection(db, 'projects', projectId, 'files'));
      const batch = writeBatch(db);
      filesSnap.forEach(fDoc => {
        batch.delete(fDoc.ref);
      });
      batch.delete(projectRef);
      await batch.commit();
    } catch (e) {
      console.warn("Delete project error:", e);
    }
  },

  async getFiles(projectId: string): Promise<FileNode[]> {
    try {
      const filesRef = collection(db, 'projects', projectId, 'files');
      const snap = await getDocs(filesRef);
      const files: FileNode[] = [];
      snap.forEach((doc) => {
        files.push(doc.data() as FileNode);
      });
      return files;
    } catch (e) {
      console.warn("Could not load project files from Firestore:", e);
      return [];
    }
  },

  // COMPLETE DATABASE WIPE / RESET (Deletes all files & data in Firestore for user/guest)
  async deleteAllDatabaseData(): Promise<{ success: boolean; deletedCount: number }> {
    const uid = getEffectiveUserId();
    let deletedCount = 0;

    // 1. Delete all chat sessions
    try {
      const chatSnap = await getDocs(query(collection(db, 'chat_sessions'), where('ownerId', '==', uid)));
      if (!chatSnap.empty) {
        const batch1 = writeBatch(db);
        chatSnap.forEach(d => {
          batch1.delete(d.ref);
          deletedCount++;
        });
        await batch1.commit();
      }
    } catch (e) {
      console.warn("Error deleting chat_sessions:", e);
    }

    // 2. Delete all projects & nested files
    try {
      const projSnap = await getDocs(query(collection(db, 'projects'), where('ownerId', '==', uid)));
      for (const pDoc of projSnap.docs) {
        const pId = pDoc.id;
        const filesSnap = await getDocs(collection(db, 'projects', pId, 'files'));
        if (!filesSnap.empty) {
          const batchFiles = writeBatch(db);
          filesSnap.forEach(fDoc => {
            batchFiles.delete(fDoc.ref);
            deletedCount++;
          });
          await batchFiles.commit();
        }
        await deleteDoc(pDoc.ref);
        deletedCount++;
      }
    } catch (e) {
      console.warn("Error deleting projects:", e);
    }

    // 3. Clear local storage caches
    if (typeof window !== 'undefined') {
      localStorage.removeItem('aether_saved_files');
      localStorage.removeItem('aether_chat_sessions');
      localStorage.removeItem('aether_active_session_id');
      localStorage.removeItem('aether_user_profile');
    }

    return { success: true, deletedCount };
  }
};
