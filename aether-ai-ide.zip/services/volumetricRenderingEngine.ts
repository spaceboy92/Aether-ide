import * as THREE from 'three';

// ============================================================================
// VOLUMETRIC RENDERING & ULTRA-REALISTIC GRAPHICS PIPELINE
// - Volumetric God Rays (Raymarching Light Shafts with Mie Scattering)
// - Physical Atmospheric Rayleigh Sky Dome
// - Exponential Height Fog & Dynamic Mist
// - Volumetric Atmospheric Particle Fields (Dust Motes, Embers, Rain Streaks)
// - ACESFilmic Tone Mapping & Contact Shadows Configuration
// ============================================================================

export interface VolumetricConfig {
  enabled: boolean;
  rayDensity: number;
  rayDecay: number;
  rayWeight: number;
  rayExposure: number;
  lightShaftColor: string;
  lightShaftIntensity: number;
  lightShaftLength: number;
  lightShaftRadius: number;
  dustMotesCount: number;
  dustMotesSpeed: number;
  atmosphericFogDensity: number;
  toneMappingExposure: number;
  enableBloom: boolean;
}

export const DEFAULT_VOLUMETRIC_CONFIG: VolumetricConfig = {
  enabled: true,
  rayDensity: 0.92,
  rayDecay: 0.95,
  rayWeight: 0.55,
  rayExposure: 0.6,
  lightShaftColor: '#fff3d1',
  lightShaftIntensity: 1.8,
  lightShaftLength: 80,
  lightShaftRadius: 25,
  dustMotesCount: 300,
  dustMotesSpeed: 0.05,
  atmosphericFogDensity: 0.008,
  toneMappingExposure: 1.25,
  enableBloom: true
};

/**
 * 1. VOLUMETRIC LIGHT SHAFTS (GOD RAYS) CONE / CYLINDER MESH WITH GLSL RAY SCATTERING
 */
export function createVolumetricLightShaftMesh(
  lightSource: THREE.DirectionalLight | THREE.SpotLight,
  colorHex = '#fff3d1',
  intensity = 1.8,
  length = 80,
  radius = 25
): THREE.Mesh {
  const geometry = new THREE.ConeGeometry(radius, length, 32, 32, true);
  // Re-orient cone so apex is at origin (light source) pointing downward
  geometry.rotateX(Math.PI / 2);
  geometry.translate(0, 0, length / 2);

  const customShaderMaterial = new THREE.ShaderMaterial({
    uniforms: {
      uTime: { value: 0.0 },
      uColor: { value: new THREE.Color(colorHex) },
      uIntensity: { value: intensity },
      uLength: { value: length }
    },
    vertexShader: `
      varying vec3 vWorldPosition;
      varying vec3 vNormal;
      varying vec2 vUv;
      varying float vDistance;

      void main() {
        vUv = uv;
        vNormal = normalize(normalMatrix * normal);
        vec4 worldPos = modelMatrix * vec4(position, 1.0);
        vWorldPosition = worldPos.xyz;
        vDistance = length(position.z);
        gl_Position = projectionMatrix * viewMatrix * worldPos;
      }
    `,
    fragmentShader: `
      uniform float uTime;
      uniform vec3 uColor;
      uniform float uIntensity;
      uniform float uLength;

      varying vec3 vWorldPosition;
      varying vec3 vNormal;
      varying vec2 vUv;
      varying float vDistance;

      // 3D Simplex-like noise approximation for atmospheric dust within light shaft
      float hash(vec3 p) {
        return fract(sin(dot(p, vec3(12.9898, 78.233, 45.164))) * 43758.5453);
      }

      float noise3D(vec3 p) {
        vec3 i = floor(p);
        vec3 f = fract(p);
        f = f * f * (3.0 - 2.0 * f);
        return mix(
          mix(mix(hash(i + vec3(0,0,0)), hash(i + vec3(1,0,0)), f.x),
              mix(hash(i + vec3(0,1,0)), hash(i + vec3(1,1,0)), f.x), f.y),
          mix(mix(hash(i + vec3(0,0,1)), hash(i + vec3(1,0,1)), f.x),
              mix(hash(i + vec3(0,1,1)), hash(i + vec3(1,1,1)), f.x), f.y), f.z
        );
      }

      void main() {
        // Distance falloff from apex
        float distFalloff = 1.0 - clamp(vDistance / uLength, 0.0, 1.0);
        distFalloff = pow(distFalloff, 1.4);

        // Edge softening (fresnel-like rim falloff for smooth cone boundary)
        vec3 viewDir = normalize(cameraPosition - vWorldPosition);
        float edgeSoft = pow(max(0.0, dot(vNormal, viewDir)), 0.6);

        // Animated atmospheric turbulence & drifting dust motes inside the beam
        vec3 noiseCoord = vWorldPosition * 0.06 + vec3(0.0, -uTime * 0.15, uTime * 0.05);
        float beamNoise = noise3D(noiseCoord) * 0.4 + 0.6;

        float alpha = distFalloff * edgeSoft * beamNoise * uIntensity * 0.28;
        vec3 finalCol = uColor * (1.0 + beamNoise * 0.3);

        gl_FragColor = vec4(finalCol, clamp(alpha, 0.0, 0.85));
      }
    `,
    transparent: true,
    blending: THREE.AdditiveBlending,
    side: THREE.DoubleSide,
    depthWrite: false
  });

  const mesh = new THREE.Mesh(geometry, customShaderMaterial);
  mesh.name = "Volumetric_God_Ray_Shaft";
  mesh.position.copy(lightSource.position);
  mesh.lookAt(0, 0, 0);

  return mesh;
}

/**
 * 2. VOLUMETRIC ATMOSPHERIC DUST MOTES / EMBERS PARTICLE FIELD
 */
export function createVolumetricDustMotes(count = 300, areaRadius = 50, colorHex = '#fef08a'): THREE.Points {
  const geometry = new THREE.BufferGeometry();
  const positions = new Float32Array(count * 3);
  const scales = new Float32Array(count);
  const randomSpeeds = new Float32Array(count * 3);

  for (let i = 0; i < count; i++) {
    positions[i * 3] = (Math.random() - 0.5) * areaRadius * 2;
    positions[i * 3 + 1] = Math.random() * 25 + 0.5;
    positions[i * 3 + 2] = (Math.random() - 0.5) * areaRadius * 2;

    scales[i] = Math.random() * 2.5 + 1.0;

    randomSpeeds[i * 3] = (Math.random() - 0.5) * 0.02;
    randomSpeeds[i * 3 + 1] = Math.random() * 0.015 + 0.005;
    randomSpeeds[i * 3 + 2] = (Math.random() - 0.5) * 0.02;
  }

  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geometry.setAttribute('scale', new THREE.BufferAttribute(scales, 1));

  // Circular soft particle canvas
  const canvas = document.createElement('canvas');
  canvas.width = canvas.height = 64;
  const ctx = canvas.getContext('2d')!;
  const gradient = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
  gradient.addColorStop(0, 'rgba(255,255,255,1)');
  gradient.addColorStop(0.3, 'rgba(255,240,180,0.8)');
  gradient.addColorStop(0.7, 'rgba(255,200,100,0.2)');
  gradient.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 64, 64);

  const texture = new THREE.CanvasTexture(canvas);

  const material = new THREE.PointsMaterial({
    size: 0.6,
    map: texture,
    color: new THREE.Color(colorHex),
    transparent: true,
    blending: THREE.AdditiveBlending,
    depthWrite: false,
    opacity: 0.85
  });

  const points = new THREE.Points(geometry, material);
  points.name = "Volumetric_Dust_Motes";
  points.userData = { speeds: randomSpeeds, areaRadius };

  return points;
}

/**
 * Updates dust motes position every frame with micro-Brownian flow
 */
export function updateVolumetricDustMotes(points: THREE.Points, time: number) {
  if (!points || !points.geometry) return;
  const posAttr = points.geometry.getAttribute('position') as THREE.BufferAttribute;
  const speeds = points.userData.speeds as Float32Array;
  const radius = (points.userData.areaRadius as number) || 50;

  for (let i = 0; i < posAttr.count; i++) {
    let x = posAttr.getX(i) + speeds[i * 3] + Math.sin(time * 0.8 + i) * 0.01;
    let y = posAttr.getY(i) + speeds[i * 3 + 1];
    let z = posAttr.getZ(i) + speeds[i * 3 + 2] + Math.cos(time * 0.8 + i) * 0.01;

    // Wrap around boundaries
    if (y > 28) y = 0.5;
    if (Math.abs(x) > radius) x = -Math.sign(x) * radius;
    if (Math.abs(z) > radius) z = -Math.sign(z) * radius;

    posAttr.setXYZ(i, x, y, z);
  }
  posAttr.needsUpdate = true;
}

/**
 * 3. ATMOSPHERIC RAYLEIGH / MIE SKY DOME WITH SOLAR HALO
 */
export function createAtmosphericSkyDome(sunPosition = new THREE.Vector3(50, 80, 40)): THREE.Mesh {
  const geometry = new THREE.SphereGeometry(450, 32, 32);
  const material = new THREE.ShaderMaterial({
    uniforms: {
      uSunPosition: { value: sunPosition.clone().normalize() },
      uRayleighColor: { value: new THREE.Color(0x2563eb) },
      uHorizonColor: { value: new THREE.Color(0x93c5fd) },
      uGroundColor: { value: new THREE.Color(0x1e293b) },
      uSunColor: { value: new THREE.Color(0xfff7ed) }
    },
    vertexShader: `
      varying vec3 vWorldPosition;
      void main() {
        vec4 worldPos = modelMatrix * vec4(position, 1.0);
        vWorldPosition = normalize(worldPos.xyz);
        gl_Position = projectionMatrix * viewMatrix * worldPos;
      }
    `,
    fragmentShader: `
      uniform vec3 uSunPosition;
      uniform vec3 uRayleighColor;
      uniform vec3 uHorizonColor;
      uniform vec3 uGroundColor;
      uniform vec3 uSunColor;
      varying vec3 vWorldPosition;

      void main() {
        float height = vWorldPosition.y;
        
        // Atmosphere gradient
        vec3 skyColor;
        if (height > 0.0) {
          skyColor = mix(uHorizonColor, uRayleighColor, pow(height, 0.5));
        } else {
          skyColor = mix(uHorizonColor, uGroundColor, pow(-height, 0.4));
        }

        // Solar Disc & Mie Halo
        float cosTheta = dot(vWorldPosition, uSunPosition);
        float sunDisc = smoothstep(0.9992, 0.9998, cosTheta) * 8.0;
        float mieHalo = pow(max(0.0, cosTheta), 32.0) * 1.5;

        vec3 finalColor = skyColor + uSunColor * (sunDisc + mieHalo);
        gl_FragColor = vec4(finalColor, 1.0);
      }
    `,
    side: THREE.BackSide,
    depthWrite: false
  });

  const skyDome = new THREE.Mesh(geometry, material);
  skyDome.name = "Atmospheric_Sky_Dome";
  return skyDome;
}

/**
 * 4. CONFIGURING ULTRA-REALISTIC RENDERER (ACES Filmic, PCF Soft Shadows, Physical Exposure)
 */
export function configureUltraRealisticRenderer(renderer: THREE.WebGLRenderer, exposure = 1.25) {
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = exposure;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.useLegacyLights = false;
}
