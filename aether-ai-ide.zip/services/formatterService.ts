import { FileNode } from '../types';

/**
 * Service to format code files using our server-side Prettier service.
 */
export const formatterService = {
  /**
   * Formats a given file's content cleanly.
   */
  async formatFile(content: string, language: string): Promise<string> {
    if (!content) return '';

    try {
      const response = await fetch('/api/format', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ content, language }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data.formatted) {
          return data.formatted;
        }
      }
      throw new Error('Server returned non-ok response');
    } catch (err) {
      console.warn('[Formatter] Server-side prettier failed, falling back to simple local formatter', err);
      return this.formatLocally(content, language);
    }
  },

  /**
   * Fallback simple formatter to tidy code locally in case of offline/network issues.
   */
  formatLocally(content: string, language: string): string {
    const lang = (language || '').toLowerCase();
    
    // Very basic tidy fallback for JSON
    if (lang === 'json') {
      try {
        return JSON.stringify(JSON.parse(content), null, 2);
      } catch (e) {
        return content;
      }
    }

    // Basic indentation/whitespace helper for generic code
    const lines = content.split('\n');
    let indentLevel = 0;
    const formattedLines = lines.map((line) => {
      let trimmed = line.trim();
      
      // Decrease indent if line starts with closing brace
      if (trimmed.startsWith('}') || trimmed.startsWith(']')) {
        indentLevel = Math.max(0, indentLevel - 1);
      }

      const indentStr = '  '.repeat(indentLevel);
      const result = indentStr + trimmed;

      // Increase indent if line ends with opening brace
      if (trimmed.endsWith('{') || trimmed.endsWith('[')) {
        indentLevel++;
      }

      return result;
    });

    return formattedLines.join('\n');
  }
};
