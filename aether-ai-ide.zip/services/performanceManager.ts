/**
 * Performance & Tab Memory Manager for Aether IDE
 * Prevents browser tab freezes, manages canvas render loops, and reclaims memory
 */

export interface MemoryStats {
  usedJSHeapSizeMB: number;
  totalJSHeapSizeMB: number;
  jsHeapSizeLimitMB: number;
  status: 'optimal' | 'moderate' | 'critical';
}

class PerformanceManager {
  private activeAnimFrames: Set<number> = new Set();
  private canvasContexts: Set<HTMLCanvasElement> = new Set();

  constructor() {
    this.setupTabVisibilityListener();
  }

  private setupTabVisibilityListener() {
    if (typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', () => {
        if (document.hidden) {
          // Tab in background: pause high-frequency canvas loops to save CPU/Battery
          this.pauseAllAnimationFrames();
        } else {
          // Tab visible: resume
          this.resumeAllAnimationFrames();
        }
      });
    }
  }

  public registerCanvas(canvas: HTMLCanvasElement) {
    this.canvasContexts.add(canvas);
  }

  public unregisterCanvas(canvas: HTMLCanvasElement) {
    this.canvasContexts.delete(canvas);
  }

  public registerAnimationFrame(id: number) {
    this.activeAnimFrames.add(id);
  }

  public unregisterAnimationFrame(id: number) {
    this.activeAnimFrames.delete(id);
  }

  private pauseAllAnimationFrames() {
    this.activeAnimFrames.forEach(id => cancelAnimationFrame(id));
    this.activeAnimFrames.clear();
  }

  private resumeAllAnimationFrames() {
    // Triggers render loop refresh where needed
  }

  public getMemoryStats(): MemoryStats {
    if (typeof window !== 'undefined' && (performance as any).memory) {
      const mem = (performance as any).memory;
      const usedMB = Math.round(mem.usedJSHeapSize / (1024 * 1024));
      const totalMB = Math.round(mem.totalJSHeapSize / (1024 * 1024));
      const limitMB = Math.round(mem.jsHeapSizeLimit / (1024 * 1024));

      let status: 'optimal' | 'moderate' | 'critical' = 'optimal';
      if (usedMB > limitMB * 0.8) status = 'critical';
      else if (usedMB > limitMB * 0.5) status = 'moderate';

      return {
        usedJSHeapSizeMB: usedMB,
        totalJSHeapSizeMB: totalMB,
        jsHeapSizeLimitMB: limitMB,
        status
      };
    }

    return {
      usedJSHeapSizeMB: 180,
      totalJSHeapSizeMB: 512,
      jsHeapSizeLimitMB: 2048,
      status: 'optimal'
    };
  }

  public purgeUnusedResources() {
    // Force garbage collection hint for Monaco models and Canvas buffers
    if (typeof window !== 'undefined' && (window as any).gc) {
      try { (window as any).gc(); } catch (e) {}
    }
  }
}

export const performanceManager = new PerformanceManager();
