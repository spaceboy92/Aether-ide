import { FileNode } from '../types';

export interface ChatIdentity {
  title: string;
  description: string;
  tags: string[];
}

export function formatSmartTitleFromPrompt(prompt: string): string {
  const clean = (prompt || '').trim();
  if (!clean) return "⚡ Neural Workspace Node";

  const lower = clean.toLowerCase();

  let emoji = "⚡";
  if (lower.includes("weather") || lower.includes("forecast") || lower.includes("climate")) emoji = "🌤️";
  else if (lower.includes("game") || lower.includes("3d") || lower.includes("arcade") || lower.includes("sim") || lower.includes("unity") || lower.includes("unreal")) emoji = "🎮";
  else if (lower.includes("todo") || lower.includes("task") || lower.includes("kanban") || lower.includes("plan") || lower.includes("note")) emoji = "📝";
  else if (lower.includes("chat") || lower.includes("messaging") || lower.includes("bot") || lower.includes("ai") || lower.includes("assistant")) emoji = "🤖";
  else if (lower.includes("dashboard") || lower.includes("analytics") || lower.includes("metrics") || lower.includes("chart") || lower.includes("stats")) emoji = "📊";
  else if (lower.includes("music") || lower.includes("audio") || lower.includes("sound") || lower.includes("synth") || lower.includes("player")) emoji = "🎵";
  else if (lower.includes("e-commerce") || lower.includes("shop") || lower.includes("store") || lower.includes("cart") || lower.includes("marketplace")) emoji = "🛒";
  else if (lower.includes("crypto") || lower.includes("finance") || lower.includes("bank") || lower.includes("wallet") || lower.includes("stock")) emoji = "💰";
  else if (lower.includes("editor") || lower.includes("code") || lower.includes("ide") || lower.includes("compiler")) emoji = "💻";
  else if (lower.includes("auth") || lower.includes("security") || lower.includes("login") || lower.includes("jwt")) emoji = "🛡️";
  else if (lower.includes("api") || lower.includes("database") || lower.includes("server") || lower.includes("backend") || lower.includes("express")) emoji = "⚙️";
  else if (lower.includes("mobile") || lower.includes("app") || lower.includes("ios") || lower.includes("android") || lower.includes("flutter")) emoji = "📱";

  // Strip common prompt lead-ins
  let topic = clean
    .replace(/^(please\s+)?(can\s+you\s+)?(build|create|make|design|generate|implement|develop|code|setup|construct)\s+(a|an|the|me\s+a|me\s+an)?\s+/i, '')
    .trim();

  const words = topic.replace(/[^\w\s-]/g, '').split(/\s+/).filter(Boolean);
  if (words.length > 0) {
    const mainWords = words.slice(0, 4).map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase());
    const combined = mainWords.join(" ");
    return `${emoji} ${combined.length > 30 ? combined.slice(0, 27) + "..." : combined}`;
  }

  return `${emoji} Neural Project Node`;
}

export function extractAppNameFromFiles(files: FileNode[]): string | null {
  if (!files || files.length === 0) return null;

  const genericNames = [
    'my app', 'untitled', 'new app', 'untitled app', 'ai studio app', 'aether app',
    'my google ai studio app', 'my-app', 'aether-ide', 'aether-project', 'app',
    'vite-project', 'react app', 'vite app', 'vite + react', 'vite + react + ts', 'document'
  ];

  // 1. Check metadata.json
  const metadataFile = files.find(f => f.name === 'metadata.json' || f.name.endsWith('/metadata.json'));
  if (metadataFile && metadataFile.content) {
    try {
      const parsed = JSON.parse(metadataFile.content);
      if (parsed.name && typeof parsed.name === 'string') {
        const clean = parsed.name.trim();
        if (clean && !genericNames.includes(clean.toLowerCase())) {
          return clean;
        }
      }
    } catch (e) {}
  }

  // 2. Check index.html (or html entry point) <title> tag
  const htmlFile = files.find(f => f.name === 'index.html' || f.name.endsWith('/index.html') || f.name.endsWith('.html'));
  if (htmlFile && htmlFile.content) {
    const match = htmlFile.content.match(/<title>([^<]+)<\/title>/i);
    if (match && match[1]) {
      const cleanTitle = match[1].trim();
      if (cleanTitle && !genericNames.includes(cleanTitle.toLowerCase())) {
        return cleanTitle;
      }
    }
  }

  // 3. Check package.json
  const packageFile = files.find(f => f.name === 'package.json' || f.name.endsWith('/package.json'));
  if (packageFile && packageFile.content) {
    try {
      const parsed = JSON.parse(packageFile.content);
      if (parsed.title && typeof parsed.title === 'string' && parsed.title.trim()) {
        const cleanTitle = parsed.title.trim();
        if (!genericNames.includes(cleanTitle.toLowerCase())) return cleanTitle;
      }
      if (parsed.name && typeof parsed.name === 'string') {
        const cleanName = parsed.name.trim();
        if (cleanName && !genericNames.includes(cleanName.toLowerCase())) {
          return cleanName.replace(/[-_]/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
        }
      }
    } catch (e) {}
  }

  return null;
}

export async function generateSmartChatIdentity(
  prompt: string,
  files: FileNode[] = []
): Promise<ChatIdentity> {
  const appNameInFiles = extractAppNameFromFiles(files);
  const defaultTitle = appNameInFiles || formatSmartTitleFromPrompt(prompt);

  try {
    const cleanPrompt = prompt.trim();
    if (!cleanPrompt) {
      return {
        title: '⚡ New Session',
        description: 'Conversational developer workspace session',
        tags: ['workspace', 'general']
      };
    }

    // Try calling backend AI title summarizer if available
    const response = await fetch('/api/ai/smart-chat-identity', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prompt: cleanPrompt,
        files: files.map(f => ({ name: f.name }))
      })
    }).catch(() => null);

    if (response && response.ok) {
      const data = await response.json();
      if (data && data.title) {
        return {
          title: data.title,
          description: data.description || `Session focusing on ${data.title.toLowerCase()}`,
          tags: Array.isArray(data.tags) ? data.tags : ['workspace', 'aether']
        };
      }
    }

    const tags: string[] = [];
    const lower = cleanPrompt.toLowerCase();
    if (lower.includes('game') || lower.includes('3d') || lower.includes('three')) tags.push('game-dev');
    if (lower.includes('shader') || lower.includes('glsl') || lower.includes('material')) tags.push('graphics');
    if (lower.includes('react') || lower.includes('ui') || lower.includes('component')) tags.push('react');
    if (lower.includes('fix') || lower.includes('bug') || lower.includes('error')) tags.push('debugging');
    if (lower.includes('api') || lower.includes('backend') || lower.includes('server')) tags.push('backend');
    if (tags.length === 0) tags.push('development');

    return {
      title: defaultTitle,
      description: cleanPrompt.length > 80 ? cleanPrompt.slice(0, 77) + '...' : cleanPrompt,
      tags
    };
  } catch (err) {
    return {
      title: defaultTitle,
      description: prompt.slice(0, 60),
      tags: ['workspace']
    };
  }
}
