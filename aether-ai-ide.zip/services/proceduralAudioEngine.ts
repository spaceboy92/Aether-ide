/**
 * Procedural Audio Synthesis Engine for Aether IDE
 * 100% Local Client-Side Web Audio API (Zero External Asset Dependency)
 */

export interface SoundPreset {
  id: string;
  name: string;
  category: 'vehicles' | 'weapons' | 'impacts' | 'ambient' | 'music';
  description: string;
  trigger: (ctx: AudioContext) => void;
  codeSnippet: string;
}

/**
 * 1. Procedural High-RPM V8/V12 Supercar Engine Synthesizer
 */
export function createProceduralEngineNode(ctx: AudioContext) {
  const masterGain = ctx.createGain();
  masterGain.gain.setValueAtTime(0.08, ctx.currentTime);

  // Fundamental Sawtooth Oscillator (Firing frequency)
  const osc1 = ctx.createOscillator();
  osc1.type = 'sawtooth';
  osc1.frequency.setValueAtTime(45, ctx.currentTime);

  // Sub-harmonic Square (Piston rumble)
  const osc2 = ctx.createOscillator();
  osc2.type = 'square';
  osc2.frequency.setValueAtTime(22.5, ctx.currentTime);

  // Exhaust Distortion Waveshaper
  const waveShaper = ctx.createWaveShaper();
  const n_samples = 44100;
  const curve = new Float32Array(n_samples);
  const deg = Math.PI / 180;
  const k = 50;
  for (let i = 0; i < n_samples; ++i) {
    const x = (i * 2) / n_samples - 1;
    curve[i] = ((3 + k) * x * 20 * deg) / (Math.PI + k * Math.abs(x));
  }
  waveShaper.curve = curve;

  // Lowpass Resonant Exhaust Filter
  const filter = ctx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(450, ctx.currentTime);
  filter.Q.setValueAtTime(4, ctx.currentTime);

  osc1.connect(waveShaper);
  osc2.connect(waveShaper);
  waveShaper.connect(filter);
  filter.connect(masterGain);

  osc1.start();
  osc2.start();

  return {
    node: masterGain,
    setRPM: (rpmRatio: number) => { // 0.0 to 1.0
      const targetFreq = 35 + rpmRatio * 280;
      const targetFilter = 300 + rpmRatio * 1800;
      osc1.frequency.setTargetAtTime(targetFreq, ctx.currentTime, 0.05);
      osc2.frequency.setTargetAtTime(targetFreq * 0.5, ctx.currentTime, 0.05);
      filter.frequency.setTargetAtTime(targetFilter, ctx.currentTime, 0.05);
    },
    stop: () => {
      try {
        osc1.stop();
        osc2.stop();
      } catch (e) {}
    }
  };
}

/**
 * 2. Sci-Fi Plasma / Laser Blaster SFX
 */
export function playProceduralLaser(ctx: AudioContext, pitch = 880) {
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = 'sawtooth';
  osc.frequency.setValueAtTime(pitch, ctx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(60, ctx.currentTime + 0.18);

  gain.gain.setValueAtTime(0.15, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.18);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start();
  osc.stop(ctx.currentTime + 0.18);
}

/**
 * 3. Procedural Explosion & Sub-Bass Detonation SFX
 */
export function playProceduralExplosion(ctx: AudioContext) {
  // Noise Buffer Generator
  const bufferSize = ctx.sampleRate * 0.8;
  const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const output = buffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) {
    output[i] = Math.random() * 2 - 1;
  }

  const whiteNoise = ctx.createBufferSource();
  whiteNoise.buffer = buffer;

  const filter = ctx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(800, ctx.currentTime);
  filter.frequency.exponentialRampToValueAtTime(30, ctx.currentTime + 0.7);

  const gain = ctx.createGain();
  gain.gain.setValueAtTime(0.35, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.7);

  // Sub-Bass Kick Thud
  const subOsc = ctx.createOscillator();
  const subGain = ctx.createGain();
  subOsc.type = 'sine';
  subOsc.frequency.setValueAtTime(140, ctx.currentTime);
  subOsc.frequency.exponentialRampToValueAtTime(25, ctx.currentTime + 0.4);
  subGain.gain.setValueAtTime(0.3, ctx.currentTime);
  subGain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);

  whiteNoise.connect(filter);
  filter.connect(gain);
  gain.connect(ctx.destination);

  subOsc.connect(subGain);
  subGain.connect(ctx.destination);

  whiteNoise.start();
  subOsc.start();
  whiteNoise.stop(ctx.currentTime + 0.8);
  subOsc.stop(ctx.currentTime + 0.8);
}

/**
 * 4. Procedural Cybernetic Warp / Shield Pickup SFX
 */
export function playProceduralWarp(ctx: AudioContext) {
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = 'sine';
  osc.frequency.setValueAtTime(120, ctx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(1400, ctx.currentTime + 0.35);

  gain.gain.setValueAtTime(0.12, ctx.currentTime);
  gain.gain.linearRampToValueAtTime(0.2, ctx.currentTime + 0.2);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);

  osc.connect(gain);
  gain.connect(ctx.destination);

  osc.start();
  osc.stop(ctx.currentTime + 0.4);
}

/**
 * 5. Procedural Algorithmic Synthwave BGM Loop Generator
 */
export function startProceduralSynthwaveBGM(ctx: AudioContext): { stop: () => void } {
  let isRunning = true;
  const tempo = 125; // BPM
  const stepTime = (60 / tempo) / 4; // 16th notes
  const scale = [130.81, 146.83, 155.56, 174.61, 196.00, 207.65, 233.08, 261.63]; // C Minor Pentatonic/Aeolian

  let currentStep = 0;

  const playStep = () => {
    if (!isRunning) return;

    const time = ctx.currentTime;

    // Bassline Arpeggio
    if (currentStep % 2 === 0) {
      const bassFreq = scale[currentStep % scale.length] * 0.5;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(bassFreq, time);
      gain.gain.setValueAtTime(0.06, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + stepTime * 1.5);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(time);
      osc.stop(time + stepTime * 1.5);
    }

    // Procedural Hi-Hat (Every 16th note off-beat)
    if (currentStep % 2 === 1) {
      const bufferSize = ctx.sampleRate * 0.04;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;

      const noise = ctx.createBufferSource();
      noise.buffer = buffer;
      const filter = ctx.createBiquadFilter();
      filter.type = 'highpass';
      filter.frequency.setValueAtTime(7000, time);
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.03, time);
      gain.gain.exponentialRampToValueAtTime(0.0001, time + 0.04);
      noise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      noise.start(time);
    }

    currentStep = (currentStep + 1) % 32;
    setTimeout(playStep, stepTime * 1000);
  };

  playStep();

  return {
    stop: () => {
      isRunning = false;
    }
  };
}

export const PROCEDURAL_AUDIO_PRESETS: SoundPreset[] = [
  {
    id: 'laser_blaster',
    name: 'Plasma Blaster Chirp',
    category: 'weapons',
    description: 'High-frequency downward exponential pitch sweep for laser weapons.',
    trigger: (ctx) => playProceduralLaser(ctx, 950),
    codeSnippet: `function playLaser() {
  const ctx = new (window.AudioContext || window.webkitAudioContext)();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = 'sawtooth';
  osc.frequency.setValueAtTime(950, ctx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(60, ctx.currentTime + 0.18);
  gain.gain.setValueAtTime(0.15, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.18);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start();
  osc.stop(ctx.currentTime + 0.18);
}`
  },
  {
    id: 'explosion_detonation',
    name: 'Sub-Bass Detonation & Blast',
    category: 'impacts',
    description: 'Layered white-noise burst and sweeping sub-sine wave impact.',
    trigger: (ctx) => playProceduralExplosion(ctx),
    codeSnippet: `function playExplosion() {
  const ctx = new (window.AudioContext || window.webkitAudioContext)();
  const bufferSize = ctx.sampleRate * 0.8;
  const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
  const noise = ctx.createBufferSource();
  noise.buffer = buffer;
  const filter = ctx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(800, ctx.currentTime);
  filter.frequency.exponentialRampToValueAtTime(30, ctx.currentTime + 0.7);
  const gain = ctx.createGain();
  gain.gain.setValueAtTime(0.35, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.7);
  noise.connect(filter);
  filter.connect(gain);
  gain.connect(ctx.destination);
  noise.start();
}`
  },
  {
    id: 'warp_booster',
    name: 'Quantum Warp Accelerator',
    category: 'vehicles',
    description: 'Ascending sine wave harmonics with volume swell for nitro/teleportation.',
    trigger: (ctx) => playProceduralWarp(ctx),
    codeSnippet: `function playWarpBoost() {
  const ctx = new (window.AudioContext || window.webkitAudioContext)();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = 'sine';
  osc.frequency.setValueAtTime(120, ctx.currentTime);
  osc.frequency.exponentialRampToValueAtTime(1400, ctx.currentTime + 0.35);
  gain.gain.setValueAtTime(0.15, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.4);
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start();
  osc.stop(ctx.currentTime + 0.4);
}`
  }
];
