
import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, doc, getDocFromCache } from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';

let app: any = null;
try {
  app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
} catch (e) {
  console.warn("Firebase initializeApp failed:", e);
}

let dbInstance: any = null;
try {
  if (app) {
    const dbId = (firebaseConfig as any)?.firestoreDatabaseId;
    if (dbId) {
      try {
        dbInstance = getFirestore(app, dbId);
      } catch (err) {
        console.warn("Failed to get named Firestore database, falling back to default:", err);
        dbInstance = getFirestore(app);
      }
    } else {
      dbInstance = getFirestore(app);
    }
  }
} catch (e) {
  console.warn("Firestore initialization error:", e);
}

let authInstance: any = null;
try {
  if (app) {
    authInstance = getAuth(app);
  }
} catch (e) {
  console.warn("Firebase auth initialization error:", e);
}

export const db = dbInstance;
export const auth = authInstance;

// Validate connection
export async function testFirebaseConnection() {
  if (!db) return;
  try {
    await getDocFromCache(doc(db, '_connection_test_', 'ping'));
  } catch (e) {
    console.log('Firebase connection initialized');
  }
}

export default app;

