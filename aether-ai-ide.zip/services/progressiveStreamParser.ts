/**
 * Progressive Real-Time Stream Parser for Universal AI Model Outputs
 * Decodes partial JSON structures, markdown code blocks, think tags, and streaming files
 * with zero-lag progressive unescaping and live metric tracking.
 */

export interface StreamingFileFragment {
  path: string;
  operation: 'create' | 'update' | 'delete';
  code: string;
  language: string;
  lineCount: number;
  isComplete: boolean;
}

export interface StreamMetrics {
  startTime: number;
  totalChars: number;
  totalTokens: number;
  tokensPerSec: number;
  elapsedMs: number;
  phase: 'thinking' | 'planning' | 'synthesizing' | 'refactoring' | 'finalizing';
  activeFile?: string;
}

export interface ProgressiveStreamState {
  thoughts: string;
  reasoningSteps: { step: string; status: 'active' | 'completed' | 'pending' }[];
  message: string;
  files: Record<string, StreamingFileFragment>;
  activeFile?: StreamingFileFragment;
  commands: string[];
  metrics: StreamMetrics;
  rawPreamble?: string;
  isJsonStructured: boolean;
}

/**
 * Progressively unescape string literal contents from partial JSON streams
 */
export function progressiveUnescape(raw: string): string {
  if (!raw) return '';
  return raw
    .replace(/\\n/g, '\n')
    .replace(/\\t/g, '\t')
    .replace(/\\r/g, '\r')
    .replace(/\\"/g, '"')
    .replace(/\\\\/g, '\\')
    .replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => {
      try {
        return String.fromCharCode(parseInt(hex, 16));
      } catch {
        return '';
      }
    });
}

/**
 * Detect language from file extension
 */
export function detectLanguageFromPath(filePath: string): string {
  const ext = filePath.split('.').pop()?.toLowerCase() || '';
  const map: Record<string, string> = {
    ts: 'typescript',
    tsx: 'typescript',
    js: 'javascript',
    jsx: 'javascript',
    html: 'html',
    css: 'css',
    json: 'json',
    py: 'python',
    rs: 'rust',
    cpp: 'cpp',
    c: 'c',
    go: 'go',
    java: 'java',
    kt: 'kotlin',
    cs: 'csharp',
    sh: 'bash',
    sql: 'sql',
    rb: 'ruby',
    php: 'php',
    lua: 'lua'
  };
  return map[ext] || ext || 'text';
}

/**
 * Extract progressive streaming state from accumulated raw stream text
 */
export function parseProgressiveStream(
  fullText: string,
  startTime: number = Date.now()
): ProgressiveStreamState {
  const elapsedMs = Math.max(1, Date.now() - startTime);
  const totalChars = fullText.length;
  const estimatedTokens = Math.ceil(totalChars / 3.8);
  const tokensPerSec = Math.round((estimatedTokens / (elapsedMs / 1000)) * 10) / 10;

  let thoughts = '';
  const reasoningSteps: { step: string; status: 'active' | 'completed' | 'pending' }[] = [];
  let message = '';
  const files: Record<string, StreamingFileFragment> = {};
  const commands: string[] = [];

  // 1. Extract <think> / <thought> / <reasoning> tags
  const thinkMatch = fullText.match(/<(?:think|thought|reasoning|reasoning_content)>([\s\S]*?)(?:<\/(?:think|thought|reasoning|reasoning_content)>|$)/i);
  if (thinkMatch && thinkMatch[1]) {
    thoughts = thinkMatch[1].trim();
  }

  // 2. Extract JSON "thoughts" field
  const jsonThoughtMatch = fullText.match(/"thoughts"\s*:\s*"((?:[^"\\]|\\.)*)/);
  if (jsonThoughtMatch && !thoughts) {
    thoughts = progressiveUnescape(jsonThoughtMatch[1]);
  }

  // 3. Extract JSON reasoning steps
  const stepsMatch = fullText.match(/"reasoningSteps"\s*:\s*\[([\s\S]*?)(\]|$)/);
  if (stepsMatch && stepsMatch[1]) {
    const stepItems = stepsMatch[1].match(/\{[\s\S]*?\}/g);
    if (stepItems) {
      stepItems.forEach(item => {
        const stepMatch = item.match(/"step"\s*:\s*"((?:[^"\\]|\\.)*)"/);
        const statusMatch = item.match(/"status"\s*:\s*"((?:[^"\\]|\\.)*)"/);
        if (stepMatch) {
          reasoningSteps.push({
            step: progressiveUnescape(stepMatch[1]),
            status: (statusMatch ? statusMatch[1] : 'active') as any
          });
        }
      });
    }
  }

  // 4. Extract progressive "message" field
  const jsonMessageMatch = fullText.match(/"message"\s*:\s*"((?:[^"\\]|\\.)*)/);
  if (jsonMessageMatch) {
    message = progressiveUnescape(jsonMessageMatch[1]);
  } else if (thinkMatch) {
    // Stripped text without think tags
    const withoutThink = fullText.replace(/<(?:think|thought|reasoning|reasoning_content)>[\s\S]*?(?:<\/(?:think|thought|reasoning|reasoning_content)>|$)/gi, '').trim();
    if (!withoutThink.startsWith('{')) {
      message = withoutThink;
    }
  } else if (!fullText.trim().startsWith('{')) {
    // Pure Markdown / Natural Language Stream
    message = fullText.trim();
  }

  // 5. Extract JSON files array
  // Match full and partial file objects
  const fileObjPattern = /\{\s*"operation"\s*:\s*"([^"]+)"\s*,\s*"path"\s*:\s*"([^"]+)"\s*,\s*"code"\s*:\s*"/g;
  let fileMatch;

  while ((fileMatch = fileObjPattern.exec(fullText)) !== null) {
    const operation = (fileMatch[1] as any) || 'update';
    const filePath = fileMatch[2];
    const codeStartIndex = fileMatch.index + fileMatch[0].length;

    let codeEndIndex = -1;
    let isEscaped = false;
    for (let i = codeStartIndex; i < fullText.length; i++) {
      const char = fullText[i];
      if (isEscaped) {
        isEscaped = false;
        continue;
      }
      if (char === '\\') {
        isEscaped = true;
        continue;
      }
      if (char === '"') {
        codeEndIndex = i;
        break;
      }
    }

    const isComplete = codeEndIndex !== -1;
    const rawCode = isComplete
      ? fullText.slice(codeStartIndex, codeEndIndex)
      : fullText.slice(codeStartIndex);

    const unescapedCode = progressiveUnescape(rawCode);
    const lineCount = unescapedCode.split('\n').length;

    files[filePath] = {
      path: filePath,
      operation,
      code: unescapedCode,
      language: detectLanguageFromPath(filePath),
      lineCount,
      isComplete
    };
  }

  // Also support shorthand {"path": "...", "code": "..."}
  const altFilePattern = /\{\s*"path"\s*:\s*"([^"]+)"\s*,\s*"code"\s*:\s*"/g;
  let altMatch;
  while ((altMatch = altFilePattern.exec(fullText)) !== null) {
    const filePath = altMatch[1];
    if (files[filePath]) continue; // already parsed

    const codeStartIndex = altMatch.index + altMatch[0].length;
    let codeEndIndex = -1;
    let isEscaped = false;
    for (let i = codeStartIndex; i < fullText.length; i++) {
      const char = fullText[i];
      if (isEscaped) {
        isEscaped = false;
        continue;
      }
      if (char === '\\') {
        isEscaped = true;
        continue;
      }
      if (char === '"') {
        codeEndIndex = i;
        break;
      }
    }

    const isComplete = codeEndIndex !== -1;
    const rawCode = isComplete
      ? fullText.slice(codeStartIndex, codeEndIndex)
      : fullText.slice(codeStartIndex);

    const unescapedCode = progressiveUnescape(rawCode);
    files[filePath] = {
      path: filePath,
      operation: 'update',
      code: unescapedCode,
      language: detectLanguageFromPath(filePath),
      lineCount: unescapedCode.split('\n').length,
      isComplete
    };
  }

  // Also check markdown code blocks (e.g. ```typescript path=App.tsx\n ... )
  const mdBlockPattern = /```(?:([a-zA-Z0-9_-]+)(?:\s+(?:path|file)=([^\n\r]+))?)?\n([\s\S]*?)(?:```|$)/g;
  let mdMatch;
  while ((mdMatch = mdBlockPattern.exec(fullText)) !== null) {
    const lang = mdMatch[1] || 'typescript';
    const filePath = mdMatch[2] || (Object.keys(files).length === 0 ? 'snippet.' + (lang === 'typescript' ? 'tsx' : lang) : `file_${Object.keys(files).length + 1}.${lang}`);
    const codeContent = mdMatch[3];
    const isComplete = fullText.slice(mdMatch.index).includes('```\n') || fullText.slice(mdMatch.index + mdMatch[0].length - 3, mdMatch.index + mdMatch[0].length) === '```';

    if (!files[filePath] || files[filePath].code.length < codeContent.length) {
      files[filePath] = {
        path: filePath,
        operation: 'update',
        code: codeContent,
        language: detectLanguageFromPath(filePath) || lang,
        lineCount: codeContent.split('\n').length,
        isComplete
      };
    }
  }

  // 6. Extract commands
  const cmdPattern = /"commands"\s*:\s*\[([\s\S]*?)(\]|$)/;
  const cmdMatch = fullText.match(cmdPattern);
  if (cmdMatch && cmdMatch[1]) {
    const items = cmdMatch[1].match(/"((?:[^"\\]|\\.)*)"/g);
    if (items) {
      items.forEach(c => {
        const clean = progressiveUnescape(c.slice(1, -1));
        if (clean.trim()) commands.push(clean.trim());
      });
    }
  }

  // Determine active streaming file
  const fileEntries = Object.values(files);
  const activeFile = fileEntries.find(f => !f.isComplete) || fileEntries[fileEntries.length - 1];

  // Determine stream phase
  let phase: StreamMetrics['phase'] = 'thinking';
  if (fileEntries.length > 0) {
    phase = fileEntries.some(f => !f.isComplete) ? 'synthesizing' : 'finalizing';
  } else if (reasoningSteps.length > 0 || message.length > 0) {
    phase = 'planning';
  }

  // Auto-generate reasoning steps if empty
  if (reasoningSteps.length === 0) {
    if (thoughts) {
      reasoningSteps.push({ step: 'Analyzing system context & user requirements...', status: 'completed' });
    }
    if (fileEntries.length > 0) {
      fileEntries.forEach((f, idx) => {
        reasoningSteps.push({
          step: `Synthesizing ${f.path} (${f.lineCount} lines)...`,
          status: f.isComplete ? 'completed' : 'active'
        });
      });
    } else {
      reasoningSteps.push({ step: 'Formulating neural plan & logic structures...', status: 'active' });
    }
  }

  // Enrich progressive message if it stopped at 1-2 lines while files are streaming
  let enrichedMessage = message;
  if (fileEntries.length > 0) {
    if (!enrichedMessage || enrichedMessage.trim().length < 20) {
      enrichedMessage = `Synthesizing workspace files (${fileEntries.map(f => f.path).join(', ')})...`;
    }
  }

  return {
    thoughts,
    reasoningSteps,
    message: enrichedMessage,
    files,
    activeFile,
    commands,
    metrics: {
      startTime,
      totalChars,
      totalTokens: estimatedTokens,
      tokensPerSec: Math.max(1, tokensPerSec),
      elapsedMs,
      phase,
      activeFile: activeFile?.path
    },
    isJsonStructured: fullText.trim().startsWith('{') || fullText.includes('"message"') || fullText.includes('"files"')
  };
}
