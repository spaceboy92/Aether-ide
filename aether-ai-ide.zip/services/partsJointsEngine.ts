import * as THREE from 'three';

export type JointType = 'fixed' | 'hinge' | 'ball_socket' | 'prismatic' | 'spring';

export type BehaviorType =
  | 'rotate_continuous'
  | 'aim_target'
  | 'laser_emitter'
  | 'spring_suspension'
  | 'hover_oscillate'
  | 'light_pulse'
  | 'thruster_particles'
  | 'custom_script';

export interface PartBehavior {
  id: string;
  type: BehaviorType;
  enabled: boolean;
  name: string;
  params: {
    speed?: number;
    axis?: 'x' | 'y' | 'z';
    frequency?: number;
    amplitude?: number;
    fireRate?: number;
    projectileColor?: string;
    projectileSpeed?: number;
    recoilAmount?: number;
    minAngle?: number;
    maxAngle?: number;
    stiffness?: number;
    damping?: number;
    pulseColor?: string;
    scriptCode?: string;
    [key: string]: any;
  };
}

export interface ModularPart {
  id: string;
  name: string;
  type:
    | 'box'
    | 'cylinder'
    | 'sphere'
    | 'torus'
    | 'cone'
    | 'blaster_cannon'
    | 'jet_thruster'
    | 'wheel_hub'
    | 'robotic_arm'
    | 'cockpit_pod'
    | 'sensor_eye'
    | 'shield_emitter';
  parentId: string | null; // null = root part
  jointType: JointType;
  jointAnchor: [number, number, number]; // pivot point relative to parent
  jointAxis: [number, number, number];   // rotation/sliding axis
  jointLimits: [number, number];         // [min, max] in radians or units
  position: [number, number, number];
  rotation: [number, number, number];   // Euler angles (radians)
  scale: [number, number, number];
  color: string;
  metalness: number;
  roughness: number;
  emissive: string;
  wireframe: boolean;
  behaviors: PartBehavior[];
}

export interface ModularAssembly {
  id: string;
  name: string;
  category: 'mechs' | 'vehicles' | 'spaceships' | 'turrets' | 'robots';
  description: string;
  rootPartId: string;
  parts: ModularPart[];
}

/**
 * 1. Generate Geometry for specific part types
 */
export function createPartGeometry(part: ModularPart): THREE.BufferGeometry {
  const [sx, sy, sz] = part.scale;
  switch (part.type) {
    case 'box':
      return new THREE.BoxGeometry(sx, sy, sz);
    case 'cylinder':
      return new THREE.CylinderGeometry(sx * 0.5, sx * 0.5, sy, 32);
    case 'sphere':
      return new THREE.SphereGeometry(sx * 0.5, 32, 32);
    case 'torus':
      return new THREE.TorusGeometry(sx * 0.5, sy * 0.15, 16, 48);
    case 'cone':
      return new THREE.ConeGeometry(sx * 0.5, sy, 32);
    case 'blaster_cannon': {
      // Composite barrel geometry with muzzle bore
      const barrel = new THREE.CylinderGeometry(sx * 0.18, sx * 0.22, sy * 1.4, 24);
      barrel.rotateZ(Math.PI / 2);
      return barrel;
    }
    case 'jet_thruster': {
      // Conical nozzle with exhaust bell
      const nozzle = new THREE.ConeGeometry(sx * 0.45, sy * 0.8, 24, 1, true);
      nozzle.rotateX(Math.PI);
      return nozzle;
    }
    case 'wheel_hub': {
      const wheel = new THREE.CylinderGeometry(sx * 0.5, sx * 0.5, sy * 0.4, 32);
      wheel.rotateZ(Math.PI / 2);
      return wheel;
    }
    case 'robotic_arm': {
      return new THREE.BoxGeometry(sx * 0.25, sy * 1.2, sz * 0.25);
    }
    case 'cockpit_pod': {
      const pod = new THREE.SphereGeometry(sx * 0.6, 24, 24);
      pod.scale(1.0, 0.7, 1.4);
      return pod;
    }
    case 'sensor_eye': {
      return new THREE.SphereGeometry(sx * 0.35, 24, 24);
    }
    case 'shield_emitter': {
      const ring = new THREE.TorusGeometry(sx * 0.5, sy * 0.08, 16, 32);
      return ring;
    }
    default:
      return new THREE.BoxGeometry(sx, sy, sz);
  }
}

/**
 * 2. Pre-built Modular Assemblies with Joints & Attached Behaviors
 */
export const MODULAR_ASSEMBLY_PRESETS: ModularAssembly[] = [
  // A. Modular Combat Titan Mech
  {
    id: 'combat_titan_mech',
    name: 'Goliath Mark-IV Combat Mech',
    category: 'mechs',
    description: 'Articulated dual-leg combat walker with 360° sensor eye, rotary railgun, and shock-absorber suspension joints.',
    rootPartId: 'mech_pelvis',
    parts: [
      {
        id: 'mech_pelvis',
        name: 'Pelvis & Hip Core',
        type: 'box',
        parentId: null,
        jointType: 'fixed',
        jointAnchor: [0, 0, 0],
        jointAxis: [0, 1, 0],
        jointLimits: [0, 0],
        position: [0, 2.0, 0],
        rotation: [0, 0, 0],
        scale: [1.6, 0.8, 1.2],
        color: '#1e293b',
        metalness: 0.85,
        roughness: 0.25,
        emissive: '#000000',
        wireframe: false,
        behaviors: [
          {
            id: 'b_hover',
            type: 'hover_oscillate',
            enabled: true,
            name: 'Pneumatic Hip Sway',
            params: { frequency: 1.5, amplitude: 0.08, axis: 'y' }
          }
        ]
      },
      {
        id: 'mech_torso',
        name: 'Armored Torso & Reactor',
        type: 'box',
        parentId: 'mech_pelvis',
        jointType: 'hinge',
        jointAnchor: [0, 0.6, 0],
        jointAxis: [0, 1, 0],
        jointLimits: [-Math.PI * 0.4, Math.PI * 0.4],
        position: [0, 0.8, 0],
        rotation: [0, 0, 0],
        scale: [2.2, 1.6, 1.6],
        color: '#f97316',
        metalness: 0.9,
        roughness: 0.2,
        emissive: '#451a03',
        wireframe: false,
        behaviors: [
          {
            id: 'b_pulse',
            type: 'light_pulse',
            enabled: true,
            name: 'Reactor Pulse',
            params: { frequency: 2.0, pulseColor: '#f97316' }
          }
        ]
      },
      {
        id: 'mech_head',
        name: 'Tracking Sensor Eye',
        type: 'sensor_eye',
        parentId: 'mech_torso',
        jointType: 'ball_socket',
        jointAnchor: [0, 1.0, 0.4],
        jointAxis: [0, 1, 0],
        jointLimits: [-Math.PI * 0.5, Math.PI * 0.5],
        position: [0, 1.0, 0.4],
        rotation: [0, 0, 0],
        scale: [1.0, 1.0, 1.0],
        color: '#06b6d4',
        metalness: 0.9,
        roughness: 0.1,
        emissive: '#06b6d4',
        wireframe: false,
        behaviors: [
          {
            id: 'b_aim',
            type: 'aim_target',
            enabled: true,
            name: 'Target Tracking Gimbal',
            params: { speed: 4.0 }
          }
        ]
      },
      {
        id: 'mech_arm_r',
        name: 'Right Arm Shoulder Joint',
        type: 'robotic_arm',
        parentId: 'mech_torso',
        jointType: 'hinge',
        jointAnchor: [1.4, 0.4, 0],
        jointAxis: [1, 0, 0],
        jointLimits: [-Math.PI * 0.5, Math.PI * 0.5],
        position: [1.4, 0.1, 0],
        rotation: [0, 0, 0],
        scale: [1.0, 1.2, 1.0],
        color: '#334155',
        metalness: 0.8,
        roughness: 0.3,
        emissive: '#000000',
        wireframe: false,
        behaviors: []
      },
      {
        id: 'mech_blaster_r',
        name: 'Rotary Plasma Blaster',
        type: 'blaster_cannon',
        parentId: 'mech_arm_r',
        jointType: 'fixed',
        jointAnchor: [0.1, -0.8, 0.5],
        jointAxis: [0, 0, 1],
        jointLimits: [0, 0],
        position: [0.1, -0.8, 0.6],
        rotation: [0, 0, 0],
        scale: [1.2, 1.4, 1.2],
        color: '#0ea5e9',
        metalness: 0.9,
        roughness: 0.15,
        emissive: '#0284c7',
        wireframe: false,
        behaviors: [
          {
            id: 'b_laser',
            type: 'laser_emitter',
            enabled: true,
            name: 'Auto-Fire Plasma Blaster',
            params: { fireRate: 6.0, projectileColor: '#0ea5e9', projectileSpeed: 45, recoilAmount: 0.15 }
          },
          {
            id: 'b_rot',
            type: 'rotate_continuous',
            enabled: true,
            name: 'Continuous Barrel Spin',
            params: { speed: 8.0, axis: 'z' }
          }
        ]
      },
      {
        id: 'mech_leg_l',
        name: 'Left Hydraulic Leg',
        type: 'robotic_arm',
        parentId: 'mech_pelvis',
        jointType: 'hinge',
        jointAnchor: [-0.8, -0.4, 0],
        jointAxis: [1, 0, 0],
        jointLimits: [-Math.PI * 0.3, Math.PI * 0.3],
        position: [-0.8, -0.9, 0],
        rotation: [0, 0, 0],
        scale: [1.2, 1.4, 1.2],
        color: '#1e293b',
        metalness: 0.8,
        roughness: 0.4,
        emissive: '#000000',
        wireframe: false,
        behaviors: [
          {
            id: 'b_susp_l',
            type: 'spring_suspension',
            enabled: true,
            name: 'Left Stride Spring',
            params: { stiffness: 120, damping: 8, amplitude: 0.12 }
          }
        ]
      },
      {
        id: 'mech_leg_r',
        name: 'Right Hydraulic Leg',
        type: 'robotic_arm',
        parentId: 'mech_pelvis',
        jointType: 'hinge',
        jointAnchor: [0.8, -0.4, 0],
        jointAxis: [1, 0, 0],
        jointLimits: [-Math.PI * 0.3, Math.PI * 0.3],
        position: [0.8, -0.9, 0],
        rotation: [0, 0, 0],
        scale: [1.2, 1.4, 1.2],
        color: '#1e293b',
        metalness: 0.8,
        roughness: 0.4,
        emissive: '#000000',
        wireframe: false,
        behaviors: [
          {
            id: 'b_susp_r',
            type: 'spring_suspension',
            enabled: true,
            name: 'Right Stride Spring',
            params: { stiffness: 120, damping: 8, amplitude: 0.12 }
          }
        ]
      }
    ]
  },

  // B. Modular Cyber Hover-Tank
  {
    id: 'cyber_hover_tank',
    name: 'Specter Heavy Hover Tank',
    category: 'vehicles',
    description: 'Armored heavy chassis with 360° rotating turret ring, dual railguns, and 4 anti-gravity repulsor pods.',
    rootPartId: 'tank_chassis',
    parts: [
      {
        id: 'tank_chassis',
        name: 'Heavy Armored Hull',
        type: 'box',
        parentId: null,
        jointType: 'fixed',
        jointAnchor: [0, 0, 0],
        jointAxis: [0, 1, 0],
        jointLimits: [0, 0],
        position: [0, 1.2, 0],
        rotation: [0, 0, 0],
        scale: [3.4, 0.9, 4.8],
        color: '#0f172a',
        metalness: 0.88,
        roughness: 0.25,
        emissive: '#000000',
        wireframe: false,
        behaviors: [
          {
            id: 'b_hover_tank',
            type: 'hover_oscillate',
            enabled: true,
            name: 'Anti-Grav Repulsor Hover',
            params: { frequency: 1.8, amplitude: 0.1, axis: 'y' }
          }
        ]
      },
      {
        id: 'tank_turret_ring',
        name: 'Turret Ring Gimbal',
        type: 'cylinder',
        parentId: 'tank_chassis',
        jointType: 'hinge',
        jointAnchor: [0, 0.6, 0.2],
        jointAxis: [0, 1, 0],
        jointLimits: [-Math.PI, Math.PI],
        position: [0, 0.6, 0.2],
        rotation: [0, 0, 0],
        scale: [2.2, 0.5, 2.2],
        color: '#3b82f6',
        metalness: 0.9,
        roughness: 0.2,
        emissive: '#1d4ed8',
        wireframe: false,
        behaviors: [
          {
            id: 'b_aim_turret',
            type: 'aim_target',
            enabled: true,
            name: 'Aim At Target / Cursor',
            params: { speed: 3.5 }
          }
        ]
      },
      {
        id: 'tank_railgun_barrel',
        name: 'Dual Railgun Barrel',
        type: 'blaster_cannon',
        parentId: 'tank_turret_ring',
        jointType: 'hinge',
        jointAnchor: [0, 0.3, 1.2],
        jointAxis: [1, 0, 0],
        jointLimits: [-0.2, 0.7],
        position: [0, 0.3, 1.6],
        rotation: [0, 0, 0],
        scale: [1.4, 2.4, 1.4],
        color: '#60a5fa',
        metalness: 0.95,
        roughness: 0.1,
        emissive: '#2563eb',
        wireframe: false,
        behaviors: [
          {
            id: 'b_railgun_fire',
            type: 'laser_emitter',
            enabled: true,
            name: 'High-Velocity Railgun Fire',
            params: { fireRate: 3.0, projectileColor: '#60a5fa', projectileSpeed: 60, recoilAmount: 0.3 }
          }
        ]
      },
      {
        id: 'tank_pod_fl',
        name: 'Front-Left Repulsor Pod',
        type: 'shield_emitter',
        parentId: 'tank_chassis',
        jointType: 'fixed',
        jointAnchor: [-1.8, -0.3, 1.8],
        jointAxis: [0, 1, 0],
        jointLimits: [0, 0],
        position: [-1.8, -0.3, 1.8],
        rotation: [Math.PI / 2, 0, 0],
        scale: [1.2, 1.2, 1.2],
        color: '#06b6d4',
        metalness: 0.9,
        roughness: 0.1,
        emissive: '#0891b2',
        wireframe: false,
        behaviors: [
          {
            id: 'b_spin_fl',
            type: 'rotate_continuous',
            enabled: true,
            name: 'Repulsor Field Spin',
            params: { speed: 4.0, axis: 'z' }
          }
        ]
      },
      {
        id: 'tank_pod_fr',
        name: 'Front-Right Repulsor Pod',
        type: 'shield_emitter',
        parentId: 'tank_chassis',
        jointType: 'fixed',
        jointAnchor: [1.8, -0.3, 1.8],
        jointAxis: [0, 1, 0],
        jointLimits: [0, 0],
        position: [1.8, -0.3, 1.8],
        rotation: [Math.PI / 2, 0, 0],
        scale: [1.2, 1.2, 1.2],
        color: '#06b6d4',
        metalness: 0.9,
        roughness: 0.1,
        emissive: '#0891b2',
        wireframe: false,
        behaviors: [
          {
            id: 'b_spin_fr',
            type: 'rotate_continuous',
            enabled: true,
            name: 'Repulsor Field Spin',
            params: { speed: -4.0, axis: 'z' }
          }
        ]
      }
    ]
  },

  // C. Modular Vector-Thrust Starfighter
  {
    id: 'modular_starfighter',
    name: 'Valkyrie Vector Starfighter',
    category: 'spaceships',
    description: 'Aerodynamic fighter craft with jointed variable-sweep wings, twin afterburners, and wingtip plasma cannons.',
    rootPartId: 'ship_fuselage',
    parts: [
      {
        id: 'ship_fuselage',
        name: 'Central Monocoque Fuselage',
        type: 'cockpit_pod',
        parentId: null,
        jointType: 'fixed',
        jointAnchor: [0, 0, 0],
        jointAxis: [0, 1, 0],
        jointLimits: [0, 0],
        position: [0, 1.5, 0],
        rotation: [0, 0, 0],
        scale: [2.0, 1.4, 4.2],
        color: '#0f172a',
        metalness: 0.9,
        roughness: 0.18,
        emissive: '#000000',
        wireframe: false,
        behaviors: [
          {
            id: 'b_ship_hover',
            type: 'hover_oscillate',
            enabled: true,
            name: 'Atmospheric Bank & Float',
            params: { frequency: 1.2, amplitude: 0.08, axis: 'y' }
          }
        ]
      },
      {
        id: 'ship_thruster_l',
        name: 'Left Ion Vector Nozzle',
        type: 'jet_thruster',
        parentId: 'ship_fuselage',
        jointType: 'ball_socket',
        jointAnchor: [-0.8, 0, -2.2],
        jointAxis: [1, 1, 0],
        jointLimits: [-0.4, 0.4],
        position: [-0.8, 0, -2.2],
        rotation: [0, 0, 0],
        scale: [1.1, 1.5, 1.1],
        color: '#f97316',
        metalness: 0.95,
        roughness: 0.1,
        emissive: '#ea580c',
        wireframe: false,
        behaviors: [
          {
            id: 'b_part_l',
            type: 'thruster_particles',
            enabled: true,
            name: 'Ion Plume Emitter',
            params: { speed: 8.0, pulseColor: '#f97316' }
          }
        ]
      },
      {
        id: 'ship_thruster_r',
        name: 'Right Ion Vector Nozzle',
        type: 'jet_thruster',
        parentId: 'ship_fuselage',
        jointType: 'ball_socket',
        jointAnchor: [0.8, 0, -2.2],
        jointAxis: [1, 1, 0],
        jointLimits: [-0.4, 0.4],
        position: [0.8, 0, -2.2],
        rotation: [0, 0, 0],
        scale: [1.1, 1.5, 1.1],
        color: '#f97316',
        metalness: 0.95,
        roughness: 0.1,
        emissive: '#ea580c',
        wireframe: false,
        behaviors: [
          {
            id: 'b_part_r',
            type: 'thruster_particles',
            enabled: true,
            name: 'Ion Plume Emitter',
            params: { speed: 8.0, pulseColor: '#f97316' }
          }
        ]
      },
      {
        id: 'ship_cannon_l',
        name: 'Left Wingtip Plasma Blaster',
        type: 'blaster_cannon',
        parentId: 'ship_fuselage',
        jointType: 'fixed',
        jointAnchor: [-2.2, 0.1, 0.5],
        jointAxis: [0, 0, 1],
        jointLimits: [0, 0],
        position: [-2.2, 0.1, 0.5],
        rotation: [0, 0, 0],
        scale: [1.0, 1.6, 1.0],
        color: '#38bdf8',
        metalness: 0.9,
        roughness: 0.2,
        emissive: '#0284c7',
        wireframe: false,
        behaviors: [
          {
            id: 'b_laser_l',
            type: 'laser_emitter',
            enabled: true,
            name: 'Wingtip Rapid Laser',
            params: { fireRate: 5.0, projectileColor: '#38bdf8', projectileSpeed: 50, recoilAmount: 0.1 }
          }
        ]
      }
    ]
  }
];

/**
 * 3. Build Live Three.js Hierarchy with Nested Joints & Pivots
 */
export function buildThreeModularHierarchy(
  parts: ModularPart[],
  onPartClick?: (partId: string) => void
): { rootGroup: THREE.Group; partObjectMap: Map<string, THREE.Object3D> } {
  const rootGroup = new THREE.Group();
  const partObjectMap = new Map<string, THREE.Object3D>();
  const jointPivotMap = new Map<string, THREE.Group>();

  // 1. Create 3D Mesh and Pivot for each part
  parts.forEach(part => {
    const geo = createPartGeometry(part);
    const mat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(part.color),
      metalness: part.metalness,
      roughness: part.roughness,
      emissive: new THREE.Color(part.emissive),
      wireframe: part.wireframe
    });

    const mesh = new THREE.Mesh(geo, mat);
    mesh.name = `part_${part.id}`;
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    (mesh as any).partData = part;

    // Joint Pivot container to allow rotation around anchor
    const pivot = new THREE.Group();
    pivot.name = `pivot_${part.id}`;
    pivot.position.set(...part.position);
    pivot.rotation.set(...part.rotation);

    pivot.add(mesh);
    jointPivotMap.set(part.id, pivot);
    partObjectMap.set(part.id, mesh);
  });

  // 2. Build parent-child tree hierarchy
  parts.forEach(part => {
    const pivot = jointPivotMap.get(part.id);
    if (!pivot) return;

    if (part.parentId && jointPivotMap.has(part.parentId)) {
      const parentPivot = jointPivotMap.get(part.parentId)!;
      parentPivot.add(pivot);
    } else {
      rootGroup.add(pivot);
    }
  });

  return { rootGroup, partObjectMap };
}

/**
 * 4. Update Part Behaviors (Tick Evaluation)
 */
export function updateModularPartBehaviors(
  parts: ModularPart[],
  partObjectMap: Map<string, THREE.Object3D>,
  delta: number,
  time: number,
  inputState: { isFiring?: boolean; targetPos?: THREE.Vector3; speed?: number },
  scene?: THREE.Scene,
  laserPool?: THREE.Mesh[]
) {
  parts.forEach(part => {
    const mesh = partObjectMap.get(part.id);
    const pivot = mesh?.parent;
    if (!mesh || !pivot) return;

    part.behaviors.forEach(b => {
      if (!b.enabled) return;

      switch (b.type) {
        case 'rotate_continuous': {
          const speed = (b.params.speed ?? 2.0) * delta;
          const axis = b.params.axis || 'y';
          if (axis === 'x') mesh.rotation.x += speed;
          else if (axis === 'y') mesh.rotation.y += speed;
          else if (axis === 'z') mesh.rotation.z += speed;
          break;
        }

        case 'hover_oscillate': {
          const freq = b.params.frequency ?? 2.0;
          const amp = b.params.amplitude ?? 0.1;
          const offset = Math.sin(time * freq) * amp;
          if (b.params.axis === 'x') mesh.position.x = offset;
          else if (b.params.axis === 'z') mesh.position.z = offset;
          else mesh.position.y = offset;
          break;
        }

        case 'light_pulse': {
          const freq = b.params.frequency ?? 2.0;
          const pulse = (Math.sin(time * freq) + 1.0) * 0.5;
          const mat = (mesh as THREE.Mesh).material as THREE.MeshStandardMaterial;
          if (mat && mat.emissive) {
            const baseCol = new THREE.Color(b.params.pulseColor || part.color);
            mat.emissive.copy(baseCol).multiplyScalar(pulse * 1.5);
          }
          break;
        }

        case 'aim_target': {
          if (inputState.targetPos) {
            const worldPos = new THREE.Vector3();
            mesh.getWorldPosition(worldPos);
            const dir = inputState.targetPos.clone().sub(worldPos).normalize();
            const angleY = Math.atan2(dir.x, dir.z);
            mesh.rotation.y = THREE.MathUtils.lerp(mesh.rotation.y, angleY, (b.params.speed ?? 4.0) * delta);
          }
          break;
        }

        case 'spring_suspension': {
          const stiffness = b.params.stiffness ?? 100;
          const amp = b.params.amplitude ?? 0.1;
          const speedImpact = (inputState.speed ?? 0) * 2.0;
          const bounce = Math.sin(time * 8.0) * amp * speedImpact;
          mesh.position.y = bounce;
          break;
        }

        case 'custom_script': {
          if (b.params.scriptCode) {
            try {
              const fn = new Function('mesh', 'pivot', 'delta', 'time', 'input', b.params.scriptCode);
              fn(mesh, pivot, delta, time, inputState);
            } catch (err) {
              // Silently catch custom script runtime errors
            }
          }
          break;
        }
      }
    });
  });
}

/**
 * 5. Code Exporter: Generates standalone Three.js modular assembly constructor function
 */
export function exportModularAssemblyToCode(assembly: ModularAssembly): string {
  const partsJSON = JSON.stringify(assembly.parts, null, 2);

  return `// ===================================================
// MODULAR ASSEMBLED 3D MODEL & JOINT HIERARCHY
// Assembly: ${assembly.name} (${assembly.parts.length} Connected Parts)
// ===================================================

function buildModular${assembly.name.replace(/[^a-zA-Z0-9]/g, '')}() {
  const parts = ${partsJSON};
  const rootGroup = new THREE.Group();
  const pivots = new Map();
  const meshes = new Map();

  // 1. Build Mesh & Pivot for each jointed part
  parts.forEach(part => {
    let geo;
    const [sx, sy, sz] = part.scale;
    switch(part.type) {
      case 'cylinder': geo = new THREE.CylinderGeometry(sx*0.5, sx*0.5, sy, 24); break;
      case 'sphere': geo = new THREE.SphereGeometry(sx*0.5, 24, 24); break;
      case 'cone': geo = new THREE.ConeGeometry(sx*0.5, sy, 24); break;
      case 'torus': geo = new THREE.TorusGeometry(sx*0.5, sy*0.15, 16, 32); break;
      case 'blaster_cannon': {
        geo = new THREE.CylinderGeometry(sx*0.18, sx*0.22, sy*1.4, 20);
        geo.rotateZ(Math.PI / 2);
        break;
      }
      case 'jet_thruster': {
        geo = new THREE.ConeGeometry(sx*0.45, sy*0.8, 20, 1, true);
        geo.rotateX(Math.PI);
        break;
      }
      default: geo = new THREE.BoxGeometry(sx, sy, sz); break;
    }

    const mat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(part.color),
      metalness: part.metalness,
      roughness: part.roughness,
      emissive: new THREE.Color(part.emissive)
    });

    const mesh = new THREE.Mesh(geo, mat);
    mesh.castShadow = true;

    const pivot = new THREE.Group();
    pivot.position.set(...part.position);
    pivot.rotation.set(...part.rotation);
    pivot.add(mesh);

    pivots.set(part.id, pivot);
    meshes.set(part.id, mesh);
  });

  // 2. Link Parent-Child Joint Hierarchy
  parts.forEach(part => {
    const pivot = pivots.get(part.id);
    if (part.parentId && pivots.has(part.parentId)) {
      pivots.get(part.parentId).add(pivot);
    } else {
      rootGroup.add(pivot);
    }
  });

  // 3. Attach Update Loop
  rootGroup.userData.updateBehaviors = function(delta, time, input = {}) {
    parts.forEach(part => {
      const mesh = meshes.get(part.id);
      if (!mesh) return;

      part.behaviors.forEach(b => {
        if (!b.enabled) return;
        if (b.type === 'rotate_continuous') {
          const spd = (b.params.speed || 2.0) * delta;
          if (b.params.axis === 'x') mesh.rotation.x += spd;
          else if (b.params.axis === 'z') mesh.rotation.z += spd;
          else mesh.rotation.y += spd;
        } else if (b.type === 'hover_oscillate') {
          mesh.position.y = Math.sin(time * (b.params.frequency || 2.0)) * (b.params.amplitude || 0.1);
        } else if (b.type === 'light_pulse') {
          const pulse = (Math.sin(time * (b.params.frequency || 2.0)) + 1) * 0.5;
          mesh.material.emissive.copy(new THREE.Color(b.params.pulseColor || part.color)).multiplyScalar(pulse);
        }
      });
    });
  };

  return rootGroup;
}`;
}
