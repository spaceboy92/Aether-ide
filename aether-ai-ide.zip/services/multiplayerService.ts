import { db } from './firebase';
import { doc, setDoc, onSnapshot, getDoc } from 'firebase/firestore';

export interface PeerUser {
  id: string;
  name: string;
  role: 'host' | 'editor' | 'client_reviewer' | 'spectator';
  color: string;
  avatarUrl: string;
  cursor?: { x: number; y: number };
  activeFile?: string;
  status: 'online' | 'idle' | 'presenting';
  joinedAt: number;
}

export interface FeedbackPin {
  id: string;
  authorName: string;
  authorRole: string;
  xPercent: number;
  yPercent: number;
  comment: string;
  resolved: boolean;
  timestamp: number;
  deviceViewport: 'desktop' | 'tablet' | 'mobile';
}

export interface MultiplayerRoom {
  roomId: string;
  title: string;
  hostId: string;
  isLocked: boolean;
  presentationMode: boolean;
  agencyWhitelabel: {
    enabled: boolean;
    agencyName: string;
    clientName: string;
    brandColor: string;
    approvedByClient: boolean;
  };
  peers: PeerUser[];
  feedbackPins: FeedbackPin[];
}

const ROOM_STORAGE_KEY = 'aether_multiplayer_room_v2';

class MultiplayerService {
  private currentRoom: MultiplayerRoom | null = null;
  private listeners: Array<(room: MultiplayerRoom) => void> = [];
  private unsubscribeFirestore: (() => void) | null = null;

  constructor() {
    this.loadState();
  }

  public getOrCreatePeerId(): string {
    let peerId = localStorage.getItem('aether_multiplayer_peer_id');
    if (!peerId) {
      peerId = 'peer_' + Math.random().toString(36).substring(2, 8);
      localStorage.setItem('aether_multiplayer_peer_id', peerId);
    }
    return peerId;
  }

  public getMyPeerName(): string {
    try {
      const savedUser = localStorage.getItem('aether_user_profile');
      if (savedUser) {
        const u = JSON.parse(savedUser);
        if (u && u.name) return u.name;
      }
    } catch {}
    return 'Developer';
  }

  private loadState() {
    try {
      let roomIdFromUrl: string | null = null;
      if (typeof window !== "undefined") {
        const params = new URLSearchParams(window.location.search);
        roomIdFromUrl = params.get('room');
      }

      if (roomIdFromUrl) {
        this.currentRoom = {
          roomId: roomIdFromUrl,
          title: 'Collaborative Session',
          hostId: 'user_host_1',
          isLocked: false,
          presentationMode: false,
          agencyWhitelabel: {
            enabled: false,
            agencyName: 'Aether Studio',
            clientName: 'Acme Labs',
            brandColor: '#3B82F6',
            approvedByClient: false,
          },
          peers: [
            {
              id: this.getOrCreatePeerId(),
              name: this.getMyPeerName() + ' (You)',
              role: 'editor',
              color: '#3B82F6',
              avatarUrl: `https://ui-avatars.com/api/?name=${encodeURIComponent(this.getMyPeerName())}&background=random`,
              status: 'online',
              joinedAt: Date.now(),
            }
          ],
          feedbackPins: [],
        };
      } else {
        const saved = localStorage.getItem(ROOM_STORAGE_KEY);
        if (saved) {
          this.currentRoom = JSON.parse(saved);
        } else {
          this.createInitialRoom('client-onboarding-sprint');
        }
      }
    } catch {
      this.createInitialRoom('client-onboarding-sprint');
    }

    if (this.currentRoom?.roomId) {
      this.initFirestoreRealtime(this.currentRoom.roomId);
    }
  }

  private initFirestoreRealtime(roomId: string) {
    if (!db) return;
    if (this.unsubscribeFirestore) {
      this.unsubscribeFirestore();
      this.unsubscribeFirestore = null;
    }

    try {
      const roomRef = doc(db, 'multiplayer_rooms', roomId);
      this.unsubscribeFirestore = onSnapshot(roomRef, (snapshot) => {
        if (snapshot.exists()) {
          const remoteData = snapshot.data() as MultiplayerRoom;
          
          // Enroll ourselves as a peer if we are not listed yet
          const myId = this.getOrCreatePeerId();
          const hasMe = remoteData.peers.some(p => p.id === myId);
          if (!hasMe) {
            const colors = ['#EC4899', '#8B5CF6', '#F59E0B', '#06B6D4', '#10B981'];
            const myPeer: PeerUser = {
              id: myId,
              name: this.getMyPeerName() + ' (You)',
              role: 'editor',
              color: colors[Math.floor(Math.random() * colors.length)],
              avatarUrl: `https://ui-avatars.com/api/?name=${encodeURIComponent(this.getMyPeerName())}&background=random`,
              status: 'online',
              joinedAt: Date.now(),
            };
            remoteData.peers.push(myPeer);
            this.currentRoom = remoteData;
            this.saveState();
          } else {
            this.currentRoom = remoteData;
            try {
              localStorage.setItem(ROOM_STORAGE_KEY, JSON.stringify(remoteData));
            } catch (e) {
              console.warn("Local storage save error:", e);
            }
            this.notifyListeners();
          }
        }
      }, (err) => {
        console.warn('Firestore real-time room sync error:', err);
      });
    } catch (e) {
      console.warn('Could not initialize Firestore real-time listener:', e);
    }
  }

  public getRoom(): MultiplayerRoom {
    if (!this.currentRoom) {
      this.createInitialRoom('aether-live-room');
    }
    return this.currentRoom!;
  }

  public createInitialRoom(title: string = 'client-presentation'): MultiplayerRoom {
    const roomId = 'room_' + Math.random().toString(36).substring(2, 8);
    this.currentRoom = {
      roomId,
      title,
      hostId: 'user_host_1',
      isLocked: false,
      presentationMode: false,
      agencyWhitelabel: {
        enabled: true,
        agencyName: 'Aether Digital Studio',
        clientName: 'Acme Growth Labs',
        brandColor: '#10B981',
        approvedByClient: false,
      },
      peers: [
        {
          id: 'user_host_1',
          name: 'You (Lead Engineer)',
          role: 'host',
          color: '#3B82F6',
          avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=faces',
          status: 'online',
          joinedAt: Date.now(),
        },
        {
          id: 'client_rep_2',
          name: 'Sarah (Client Stakeholder)',
          role: 'client_reviewer',
          color: '#10B981',
          avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=faces',
          status: 'online',
          joinedAt: Date.now() - 300000,
        },
      ],
      feedbackPins: [
        {
          id: 'pin_1',
          authorName: 'Sarah (Client)',
          authorRole: 'client_reviewer',
          xPercent: 68,
          yPercent: 24,
          comment: 'Can we change this button CTA text to "Claim Founder Access"?',
          resolved: false,
          timestamp: Date.now() - 600000,
          deviceViewport: 'desktop',
        },
      ],
    };
    this.saveState();
    this.initFirestoreRealtime(roomId);
    return this.currentRoom;
  }

  public async saveState() {
    if (this.currentRoom) {
      try {
        localStorage.setItem(ROOM_STORAGE_KEY, JSON.stringify(this.currentRoom));
      } catch (e) {
        console.warn('Failed to save room state locally:', e);
      }
      this.notifyListeners();

      // Write state to Firestore database for real-time remote user syncing
      if (db) {
        try {
          const roomRef = doc(db, 'multiplayer_rooms', this.currentRoom.roomId);
          await setDoc(roomRef, JSON.parse(JSON.stringify(this.currentRoom)), { merge: true });
        } catch (e) {
          console.warn('Could not save room state to Firestore:', e);
        }
      }
    }
  }

  public togglePresentationMode(enabled?: boolean) {
    if (!this.currentRoom) return;
    this.currentRoom.presentationMode = enabled !== undefined ? enabled : !this.currentRoom.presentationMode;
    this.saveState();
  }

  public updateWhitelabel(updates: Partial<MultiplayerRoom['agencyWhitelabel']>) {
    if (!this.currentRoom) return;
    this.currentRoom.agencyWhitelabel = { ...this.currentRoom.agencyWhitelabel, ...updates };
    this.saveState();
  }

  public addFeedbackPin(pin: Omit<FeedbackPin, 'id' | 'timestamp' | 'resolved'>): FeedbackPin {
    if (!this.currentRoom) this.getRoom();
    const newPin: FeedbackPin = {
      ...pin,
      id: 'pin_' + Math.random().toString(36).substring(2, 9),
      timestamp: Date.now(),
      resolved: false,
    };
    this.currentRoom!.feedbackPins.push(newPin);
    this.saveState();
    return newPin;
  }

  public toggleResolvePin(pinId: string) {
    if (!this.currentRoom) return;
    this.currentRoom.feedbackPins = this.currentRoom.feedbackPins.map((p) =>
      p.id === pinId ? { ...p, resolved: !p.resolved } : p
    );
    this.saveState();
  }

  public deletePin(pinId: string) {
    if (!this.currentRoom) return;
    this.currentRoom.feedbackPins = this.currentRoom.feedbackPins.filter((p) => p.id !== pinId);
    this.saveState();
  }

  public addPeer(name: string, role: PeerUser['role']): PeerUser {
    if (!this.currentRoom) this.getRoom();
    const colors = ['#EC4899', '#8B5CF6', '#F59E0B', '#06B6D4', '#10B981'];
    const newPeer: PeerUser = {
      id: 'peer_' + Math.random().toString(36).substring(2, 8),
      name,
      role,
      color: colors[Math.floor(Math.random() * colors.length)],
      avatarUrl: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random`,
      status: 'online',
      joinedAt: Date.now(),
    };
    this.currentRoom!.peers.push(newPeer);
    this.saveState();
    return newPeer;
  }

  public removePeer(peerId: string) {
    if (!this.currentRoom) return;
    this.currentRoom.peers = this.currentRoom.peers.filter((p) => p.id !== peerId);
    this.saveState();
  }

  public subscribe(fn: (room: MultiplayerRoom) => void) {
    this.listeners.push(fn);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== fn);
    };
  }

  private notifyListeners() {
    if (this.currentRoom) {
      for (const listener of this.listeners) {
        listener(this.currentRoom);
      }
    }
  }
}

export const multiplayerService = new MultiplayerService();
