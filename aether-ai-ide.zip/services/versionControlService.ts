import { FileNode } from '../types';

export interface FileChange {
  path: string;
  status: 'added' | 'modified' | 'deleted';
  type: 'added' | 'modified' | 'deleted';
  oldContent?: string;
  previousContent?: string;
  newContent?: string;
  diff?: string;
  diffSummary?: string;
  additions: number;
  deletions: number;
}

export interface GitCommit {
  hash: string;
  shortHash: string;
  timestamp: number;
  formattedDate: string;
  formattedTime: string;
  relativeTime: string;
  author: 'user' | 'ai' | 'system';
  prompt: string;
  branch: string;
  tag?: string;
  sessionId?: string;
  filesSnapshot: FileNode[];
  changes: FileChange[];
  stats: {
    totalFiles: number;
    filesChanged: number;
    additions: number;
    deletions: number;
  };
}

export interface CreateCommitOptions {
  prompt: string;
  files: FileNode[];
  author: 'user' | 'ai' | 'system';
  branch?: string;
  tag?: string;
  sessionId?: string;
}

export interface PersistenceHealth {
  status: 'healthy' | 'warning' | 'critical';
  storageUsedBytes: number;
  formattedStorageUsed: string;
  commitCount: number;
  totalSnapshots: number;
  activeBranch: string;
  filesInWorkspace: number;
  lastBackupTime?: string;
  corruptedSnapshots: number;
  recommendations: string[];
}

function getRelativeTime(timestamp: number): string {
  const diff = Date.now() - timestamp;
  const seconds = Math.floor(diff / 1000);
  if (seconds < 60) return 'just now';
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

class VersionControlService {
  private storageKey = 'aether_git_vcs_commits';
  private activeBranchKey = 'aether_git_vcs_active_branch';
  private branchesKey = 'aether_git_vcs_branches';

  private commits: GitCommit[] = [];
  private activeBranch: string = 'main';
  private branches: string[] = ['main'];

  constructor() {
    this.loadState();
  }

  private loadState() {
    try {
      const storedCommits = localStorage.getItem(this.storageKey);
      if (storedCommits) {
        this.commits = JSON.parse(storedCommits);
      }
      const storedActiveBranch = localStorage.getItem(this.activeBranchKey);
      if (storedActiveBranch) {
        this.activeBranch = storedActiveBranch;
      }
      const storedBranches = localStorage.getItem(this.branchesKey);
      if (storedBranches) {
        this.branches = JSON.parse(storedBranches);
      }
    } catch (e) {
      console.warn('Failed to load version control history from localStorage:', e);
    }
  }

  private saveState() {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.commits));
      localStorage.setItem(this.activeBranchKey, this.activeBranch);
      localStorage.setItem(this.branchesKey, JSON.stringify(this.branches));
    } catch (e) {
      console.warn('Failed to persist version control history:', e);
    }
  }

  public getCommits(sessionId?: string, branch?: string): GitCommit[] {
    return this.commits
      .filter(c => {
        if (branch && c.branch !== branch) return false;
        if (sessionId && c.sessionId && c.sessionId !== sessionId) return false;
        return true;
      })
      .map(c => ({
        ...c,
        relativeTime: getRelativeTime(c.timestamp)
      }))
      .sort((a, b) => b.timestamp - a.timestamp);
  }

  public getCommitByHash(hash: string): GitCommit | undefined {
    return this.commits.find(c => c.hash === hash || c.shortHash === hash);
  }

  public getAllBranches(): string[] {
    return Array.from(new Set(['main', ...this.branches]));
  }

  public getActiveBranch(): string {
    return this.activeBranch;
  }

  public setActiveBranch(branch: string): void {
    const clean = branch.trim() || 'main';
    this.activeBranch = clean;
    if (!this.branches.includes(clean)) {
      this.branches.push(clean);
    }
    this.saveState();
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('aether_git_branch_changed', { detail: clean }));
    }
  }

  public createBranch(branchName: string): boolean {
    const clean = branchName.trim().replace(/\s+/g, '-').toLowerCase();
    if (!clean) return false;
    if (!this.branches.includes(clean)) {
      this.branches.push(clean);
      this.activeBranch = clean;
      this.saveState();
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('aether_git_branch_changed', { detail: clean }));
      }
      return true;
    }
    return false;
  }

  public deleteBranch(branchName: string): boolean {
    if (branchName === 'main' || branchName === this.activeBranch) return false;
    this.branches = this.branches.filter(b => b !== branchName);
    this.saveState();
    return true;
  }

  public async createCommit(options: CreateCommitOptions): Promise<GitCommit> {
    const branch = options.branch || this.activeBranch || 'main';
    const currentFiles = options.files || [];
    
    // Find previous commit in the same branch/session to compute diffs
    const previousCommits = this.getCommits(options.sessionId, branch);
    const lastCommit = previousCommits.length > 0 ? previousCommits[0] : null;
    
    const changes: FileChange[] = [];
    let totalAdditions = 0;
    let totalDeletions = 0;

    const lastFileMap = new Map<string, FileNode>();
    if (lastCommit && lastCommit.filesSnapshot) {
      lastCommit.filesSnapshot.forEach(f => {
        const key = f.path || f.name;
        lastFileMap.set(key, f);
      });
    }

    const currentFileMap = new Map<string, FileNode>();
    currentFiles.forEach(f => {
      const key = f.path || f.name;
      currentFileMap.set(key, f);
    });

    // Check current files vs previous
    currentFileMap.forEach((file, key) => {
      const content = file.content || '';
      if (!lastFileMap.has(key)) {
        const lines = content.split('\n').length;
        changes.push({
          path: key,
          status: 'added',
          type: 'added',
          newContent: content,
          diffSummary: `Added (+${lines} lines)`,
          additions: lines,
          deletions: 0
        });
        totalAdditions += lines;
      } else {
        const prev = lastFileMap.get(key)!;
        const prevContent = prev.content || '';
        if (prevContent !== content) {
          const prevLines = prevContent.split('\n').length;
          const newLines = content.split('\n').length;
          const adds = Math.max(0, newLines - prevLines) + 1;
          const dels = Math.max(0, prevLines - newLines);
          changes.push({
            path: key,
            status: 'modified',
            type: 'modified',
            oldContent: prevContent,
            previousContent: prevContent,
            newContent: content,
            diffSummary: `Modified (+${adds}/-${dels})`,
            additions: adds,
            deletions: dels
          });
          totalAdditions += adds;
          totalDeletions += dels;
        }
      }
    });

    // Check deleted files
    lastFileMap.forEach((prevFile, key) => {
      if (!currentFileMap.has(key)) {
        const dels = (prevFile.content || '').split('\n').length;
        changes.push({
          path: key,
          status: 'deleted',
          type: 'deleted',
          oldContent: prevFile.content,
          previousContent: prevFile.content,
          diffSummary: `Deleted (-${dels} lines)`,
          additions: 0,
          deletions: dels
        });
        totalDeletions += dels;
      }
    });

    const now = new Date();
    const hash = Array.from(crypto.getRandomValues(new Uint8Array(20)))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');

    const newCommit: GitCommit = {
      hash,
      shortHash: hash.slice(0, 7),
      timestamp: now.getTime(),
      formattedDate: now.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }),
      formattedTime: now.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' }),
      relativeTime: 'just now',
      author: options.author,
      prompt: options.prompt,
      branch,
      tag: options.tag,
      sessionId: options.sessionId,
      filesSnapshot: currentFiles.map(f => ({ ...f })),
      changes,
      stats: {
        totalFiles: currentFiles.length,
        filesChanged: changes.length,
        additions: totalAdditions,
        deletions: totalDeletions
      }
    };

    this.commits.unshift(newCommit);
    // Keep max 250 commits
    if (this.commits.length > 250) {
      this.commits = this.commits.slice(0, 250);
    }

    this.saveState();

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('aether_git_commit_created', { detail: newCommit }));
    }

    return newCommit;
  }

  public async revertToCommit(hash: string, currentFiles: FileNode[], sessionId?: string): Promise<{ files: FileNode[] }> {
    const target = this.commits.find(c => c.hash === hash || c.shortHash === hash);
    if (!target) {
      throw new Error(`Commit with hash ${hash} not found`);
    }

    const reconstructed: FileNode[] = (target.filesSnapshot || []).map(f => ({
      ...f,
      lastModified: Date.now()
    }));

    // Create a rollback commit
    await this.createCommit({
      prompt: `Revert to [${target.shortHash}]: ${target.prompt.slice(0, 40)}`,
      files: reconstructed,
      author: 'system',
      branch: target.branch,
      sessionId
    });

    return { files: reconstructed };
  }

  /**
   * Restore or repair a single file from a specific commit snapshot without overwriting other files.
   */
  public async restoreSingleFile(
    hash: string, 
    filePath: string, 
    currentFiles: FileNode[], 
    sessionId?: string
  ): Promise<{ files: FileNode[]; restoredFile: FileNode }> {
    const target = this.commits.find(c => c.hash === hash || c.shortHash === hash);
    if (!target) {
      throw new Error(`Commit with hash ${hash} not found`);
    }

    const snapshotFile = target.filesSnapshot.find(f => (f.path || f.name) === filePath || f.name === filePath);
    if (!snapshotFile) {
      throw new Error(`File ${filePath} not found in commit [${target.shortHash}]`);
    }

    const updatedFiles = currentFiles.map(f => {
      if ((f.path || f.name) === filePath || f.name === filePath) {
        return {
          ...f,
          content: snapshotFile.content || '',
          lastModified: Date.now()
        };
      }
      return f;
    });

    // If file didn't exist in currentFiles, add it
    const exists = updatedFiles.some(f => (f.path || f.name) === filePath || f.name === filePath);
    if (!exists) {
      updatedFiles.push({
        ...snapshotFile,
        lastModified: Date.now()
      });
    }

    await this.createCommit({
      prompt: `Restored file ${filePath} from [${target.shortHash}]`,
      files: updatedFiles,
      author: 'user',
      branch: this.activeBranch,
      sessionId
    });

    return { files: updatedFiles, restoredFile: snapshotFile };
  }

  /**
   * Directly update a file's code and register a repair commit in VCS.
   */
  public async updateAndCommitFile(
    filePath: string,
    newContent: string,
    currentFiles: FileNode[],
    commitMessage: string,
    sessionId?: string
  ): Promise<{ files: FileNode[] }> {
    let fileFound = false;
    const updatedFiles = currentFiles.map(f => {
      if ((f.path || f.name) === filePath || f.name === filePath) {
        fileFound = true;
        return {
          ...f,
          content: newContent,
          lastModified: Date.now()
        };
      }
      return f;
    });

    if (!fileFound) {
      const fileName = filePath.includes('/') ? filePath.split('/').pop()! : filePath;
      const ext = fileName.includes('.') ? fileName.split('.').pop()!.toLowerCase() : 'ts';
      const langMap: Record<string, string> = {
        ts: 'typescript',
        tsx: 'typescript',
        js: 'javascript',
        jsx: 'javascript',
        html: 'html',
        css: 'css',
        json: 'json',
        md: 'markdown',
        py: 'python',
        glsl: 'glsl',
        sql: 'sql'
      };
      updatedFiles.push({
        id: `file-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        name: fileName,
        path: filePath,
        content: newContent,
        language: langMap[ext] || 'typescript',
        lastModified: Date.now()
      });
    }

    await this.createCommit({
      prompt: commitMessage || `Edit & repair ${filePath}`,
      files: updatedFiles,
      author: 'user',
      branch: this.activeBranch,
      sessionId
    });

    return { files: updatedFiles };
  }

  /**
   * Emergency recover from the latest valid snapshot in history
   */
  public emergencyRecoverLatest(sessionId?: string): { files: FileNode[]; commit: GitCommit } | null {
    const valid = this.commits.filter(c => c.filesSnapshot && c.filesSnapshot.length > 0);
    if (valid.length === 0) return null;
    const latest = valid[0];
    const files = latest.filesSnapshot.map(f => ({ ...f, lastModified: Date.now() }));
    return { files, commit: latest };
  }

  /**
   * Diagnose persistence health and localStorage usage
   */
  public diagnosePersistence(currentFiles: FileNode[]): PersistenceHealth {
    let storageUsed = 0;
    try {
      const commitRaw = localStorage.getItem(this.storageKey) || '';
      storageUsed += commitRaw.length * 2; // UTF-16 bytes approx
      const branchRaw = localStorage.getItem(this.branchesKey) || '';
      storageUsed += branchRaw.length * 2;
    } catch (e) {
      // ignore
    }

    let corrupted = 0;
    for (const c of this.commits) {
      if (!c.hash || !Array.isArray(c.filesSnapshot) || !c.timestamp) {
        corrupted++;
      }
    }

    const recommendations: string[] = [];
    if (this.commits.length === 0) {
      recommendations.push('No Git commits created yet. Create a baseline snapshot now.');
    }
    if (currentFiles.length === 0 && this.commits.length > 0) {
      recommendations.push('Workspace appears empty! Use Emergency Recovery to restore files.');
    }
    if (storageUsed > 4 * 1024 * 1024) {
      recommendations.push('Storage usage is high (>4MB). Export backup bundle or clear older commits.');
    }
    if (corrupted > 0) {
      recommendations.push(`${corrupted} corrupted snapshot(s) found. Run repair to prune corrupt entries.`);
    }

    const status = corrupted > 0 || (currentFiles.length === 0 && this.commits.length > 0)
      ? 'critical'
      : this.commits.length === 0 || storageUsed > 3 * 1024 * 1024
      ? 'warning'
      : 'healthy';

    const latestCommit = this.commits.length > 0 ? this.commits[0] : null;

    return {
      status,
      storageUsedBytes: storageUsed,
      formattedStorageUsed: formatBytes(storageUsed),
      commitCount: this.commits.length,
      totalSnapshots: this.commits.reduce((acc, c) => acc + (c.filesSnapshot?.length || 0), 0),
      activeBranch: this.activeBranch,
      filesInWorkspace: currentFiles.length,
      lastBackupTime: latestCommit ? `${latestCommit.formattedDate} ${latestCommit.formattedTime}` : undefined,
      corruptedSnapshots: corrupted,
      recommendations
    };
  }

  /**
   * Export JSON bundle of Git Version Control history & snapshots for offline backup
   */
  public exportBundle(): string {
    const bundle = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      activeBranch: this.activeBranch,
      branches: this.branches,
      commits: this.commits
    };
    return JSON.stringify(bundle, null, 2);
  }

  /**
   * Import JSON backup bundle
   */
  public importBundle(jsonString: string): { importedCount: number; files?: FileNode[] } {
    try {
      const data = JSON.parse(jsonString);
      if (!data || !Array.isArray(data.commits)) {
        throw new Error('Invalid Git bundle format. Missing commits array.');
      }

      const existingHashes = new Set(this.commits.map(c => c.hash));
      let imported = 0;

      for (const c of data.commits) {
        if (c.hash && !existingHashes.has(c.hash)) {
          this.commits.push(c);
          imported++;
        }
      }

      if (Array.isArray(data.branches)) {
        this.branches = Array.from(new Set([...this.branches, ...data.branches]));
      }

      if (data.activeBranch && this.branches.includes(data.activeBranch)) {
        this.activeBranch = data.activeBranch;
      }

      this.commits.sort((a, b) => b.timestamp - a.timestamp);
      this.saveState();

      const latestFiles = this.commits.length > 0 && this.commits[0].filesSnapshot
        ? this.commits[0].filesSnapshot.map(f => ({ ...f, lastModified: Date.now() }))
        : undefined;

      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('aether_git_commit_created'));
      }

      return { importedCount: imported, files: latestFiles };
    } catch (e: any) {
      throw new Error(`Failed to import bundle: ${e.message}`);
    }
  }

  /**
   * Find the git commit associated with a chat message by hash or timestamp correlation
   */
  public findCommitForMessage(msg: { id: string; commitHash?: string; timestamp?: number; text?: string }, sessionId?: string): GitCommit | undefined {
    if (msg.commitHash) {
      const direct = this.getCommitByHash(msg.commitHash);
      if (direct) return direct;
    }
    const sessionCommits = this.getCommits(sessionId);
    if (msg.timestamp) {
      // Find commit within 12 seconds of message timestamp
      const near = sessionCommits.find(c => Math.abs(c.timestamp - msg.timestamp!) < 12000);
      if (near) return near;
    }
    return undefined;
  }

  /**
   * Restore all workspace code to the exact state produced at that AI response/checkpoint
   */
  public async restoreFromMessageCheckpoint(
    msg: { id: string; commitHash?: string; commitSnapshot?: FileNode[]; timestamp?: number; text?: string },
    currentFiles: FileNode[],
    sessionId?: string
  ): Promise<{ files: FileNode[]; commit: GitCommit }> {
    let targetCommit: GitCommit | undefined = this.findCommitForMessage(msg, sessionId);

    if (targetCommit) {
      const result = await this.revertToCommit(targetCommit.hash, currentFiles, sessionId);
      return { files: result.files, commit: targetCommit };
    }

    // If commitSnapshot is available directly on the message
    if (msg.commitSnapshot && msg.commitSnapshot.length > 0) {
      const reconstructed: FileNode[] = msg.commitSnapshot.map(f => ({
        ...f,
        lastModified: Date.now()
      }));

      const rollbackCommit = await this.createCommit({
        prompt: `Restored workspace to AI response checkpoint [${msg.id.slice(0, 8)}]`,
        files: reconstructed,
        author: 'system',
        sessionId
      });

      return { files: reconstructed, commit: rollbackCommit };
    }

    throw new Error('No valid Git snapshot found for this AI response checkpoint.');
  }

  /**
   * Clean corrupted entries
   */
  public repairCorruptSnapshots(): number {
    const initial = this.commits.length;
    this.commits = this.commits.filter(c => c && c.hash && Array.isArray(c.filesSnapshot) && c.timestamp);
    this.saveState();
    return initial - this.commits.length;
  }

  public clearHistory(sessionId?: string): void {
    if (sessionId) {
      this.commits = this.commits.filter(c => c.sessionId !== sessionId);
    } else {
      this.commits = [];
    }
    this.saveState();

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('aether_git_history_cleared'));
    }
  }
}

export const versionControlService = new VersionControlService();
