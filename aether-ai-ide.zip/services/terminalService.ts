import { socketService } from "./socketService";
import { aetherCliService } from "./aetherCliService";

export interface TerminalEntry {
  id: string;
  type: 'command' | 'output' | 'error' | 'system' | 'info';
  content: string;
  source?: string;
  timestamp: number;
  cwd?: string;
}

type TerminalListener = (entry: TerminalEntry) => void;

class TerminalService {
  private listeners: Set<TerminalListener> = new Set();
  private logs: TerminalEntry[] = [];
  private cwd: string = '/';
  private initializedSocket = false;

  constructor() {
    this.setupGlobalErrorCapture();
  }

  public initSocketListeners() {
    if (this.initializedSocket) return;
    this.initializedSocket = true;
    socketService.connect();
    socketService.onTerminalEvent((event: any) => {
      if (event.cwd) {
        this.cwd = event.cwd;
      }
      const entry: TerminalEntry = {
        id: `term-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
        type: event.type || 'output',
        content: event.stdout || event.stderr || event.content || '',
        source: 'SERVER',
        timestamp: event.timestamp || Date.now(),
        cwd: event.cwd
      };
      this.addEntry(entry);
    });
  }

  private setupGlobalErrorCapture() {
    if (typeof window === 'undefined') return;

    // Capture uncaught client runtime errors
    window.addEventListener('error', (event: ErrorEvent) => {
      const msg = event.error?.stack || event.message || 'Unhandled Client Error';
      this.logError(`[RUNTIME ERROR]: ${msg}`, 'CLIENT');
    });

    // Capture unhandled promise rejections
    window.addEventListener('unhandledrejection', (event: PromiseRejectionEvent) => {
      const reason = event.reason?.stack || event.reason?.message || String(event.reason);
      this.logError(`[UNHANDLED REJECTION]: ${reason}`, 'CLIENT');
    });

    // Hook console.error
    const originalConsoleError = console.error;
    console.error = (...args: any[]) => {
      originalConsoleError.apply(console, args);
      const message = args.map(a => {
        if (typeof a === 'object' && a !== null) {
          try {
            return JSON.stringify(a);
          } catch (e) {
            try {
              return `[Object: ${a.constructor?.name || 'Object'}]`;
            } catch (_) {
              return '[Unserializable Object]';
            }
          }
        }
        return String(a);
      }).join(' ');
      if (!message.includes('WebSocket') && !message.includes('vite') && !message.includes('HMR')) {
        this.logError(`[CONSOLE ERROR]: ${message}`, 'CONSOLE');
      }
    };
  }

  public subscribe(listener: TerminalListener): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  public getLogs(): TerminalEntry[] {
    return [...this.logs];
  }

  public getCwd(): string {
    return this.cwd;
  }

  public setCwd(dir: string) {
    this.cwd = dir;
  }

  public addEntry(entry: TerminalEntry) {
    this.logs.push(entry);
    if (this.logs.length > 500) {
      this.logs.shift();
    }
    this.listeners.forEach(fn => fn(entry));
  }

  public logCommand(cmd: string, cwd: string = this.cwd) {
    this.addEntry({
      id: `cmd-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      type: 'command',
      content: `${cwd} $ ${cmd}`,
      source: 'USER',
      timestamp: Date.now(),
      cwd
    });
  }

  public logOutput(text: string, source: string = 'SYSTEM', cwd: string = this.cwd) {
    if (!text) return;
    this.addEntry({
      id: `out-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      type: 'output',
      content: text,
      source,
      timestamp: Date.now(),
      cwd
    });
  }

  public logError(text: string, source: string = 'SYSTEM', cwd: string = this.cwd) {
    if (!text) return;
    this.addEntry({
      id: `err-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      type: 'error',
      content: text,
      source,
      timestamp: Date.now(),
      cwd
    });
  }

  public logSystem(text: string, source: string = 'SYSTEM') {
    this.addEntry({
      id: `sys-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      type: 'system',
      content: text,
      source,
      timestamp: Date.now(),
      cwd: this.cwd
    });
  }

  public clear() {
    this.logs = [];
    const clearEntry: TerminalEntry = {
      id: `clear-${Date.now()}`,
      type: 'system',
      content: 'Terminal logs cleared.',
      timestamp: Date.now()
    };
    this.listeners.forEach(fn => fn(clearEntry));
  }

  public async executeCommand(command: string, currentCwd: string = this.cwd, sandboxMode: boolean = true): Promise<{ stdout: string; stderr: string; exitCode: number; cwd: string }> {
    const trimmed = command.trim();
    this.logCommand(trimmed, currentCwd);

    if (!trimmed) {
      return { stdout: '', stderr: '', exitCode: 0, cwd: currentCwd };
    }

    // Client-side built-in commands handling
    if (trimmed === 'clear' || trimmed === 'cls') {
      this.clear();
      return { stdout: 'Cleared', stderr: '', exitCode: 0, cwd: currentCwd };
    }

    // Aether CLI Tooling Processor
    if (trimmed.startsWith('aether ') || trimmed === 'aether') {
      const parts = trimmed.split(/\s+/);
      const args = parts.slice(1);
      const res = await aetherCliService.handleAetherCommand(args, trimmed, currentCwd);
      if (res.stdout) {
        this.logOutput(res.stdout, 'AETHER_CLI', currentCwd);
      }
      if (res.stderr) {
        this.logError(res.stderr, 'AETHER_CLI_ERR', currentCwd);
      }
      return {
        stdout: res.stdout,
        stderr: res.stderr,
        exitCode: res.exitCode,
        cwd: currentCwd
      };
    }

    // Slash commands handling (/build, /lint, /publish, /commit, /deploy, /test, /jwt, /env)
    if (trimmed.startsWith('/')) {
      const parts = trimmed.slice(1).trim().split(/\s+/);
      const slashCmd = parts[0].toLowerCase();
      const args = parts.slice(1);

      if (slashCmd === 'build') {
        this.logOutput('⚡ [SLASH CMD]: Running npm run build...', 'COMMAND');
        return this.executeCommand('npm run build', currentCwd);
      } else if (slashCmd === 'lint') {
        this.logOutput('⚡ [SLASH CMD]: Running npm run lint...', 'COMMAND');
        return this.executeCommand('npm run lint', currentCwd);
      } else if (slashCmd === 'publish' || slashCmd === 'deploy') {
        this.logOutput('⚡ [SLASH CMD]: Preparing production build & deployment...', 'COMMAND');
        return this.executeCommand('npm run build', currentCwd);
      } else if (slashCmd === 'commit') {
        const msg = args.join(' ') || 'feat: update workspace changes';
        this.logOutput(`⚡ [SLASH CMD]: Committing workspace changes with message "${msg}"...`, 'COMMAND');
        return this.executeCommand(`git add . && git commit -m "${msg}"`, currentCwd);
      } else if (slashCmd === 'test') {
        this.logOutput('⚡ [SLASH CMD]: Running test suite...', 'COMMAND');
        return this.executeCommand('npm test', currentCwd);
      } else if (slashCmd === 'jwt') {
        const msg = 'Opening JWT Token Decoder & Inspector...';
        this.logOutput(`⚡ [SLASH CMD]: ${msg}`, 'COMMAND');
        window.dispatchEvent(new CustomEvent('aether-open-tool', { detail: { tool: 'jwt_decoder' } }));
        return { stdout: msg, stderr: '', exitCode: 0, cwd: currentCwd };
      } else if (slashCmd === 'env') {
        const msg = 'Opening Environment Variable Manager...';
        this.logOutput(`⚡ [SLASH CMD]: ${msg}`, 'COMMAND');
        window.dispatchEvent(new CustomEvent('aether-open-tool', { detail: { tool: 'env_manager' } }));
        return { stdout: msg, stderr: '', exitCode: 0, cwd: currentCwd };
      }
    }

    // Quick aliases for Aether CLI commands
    if (['keys', 'keybindings', 'shortcuts', 'core', 'concepts', 'doctor', 'tree'].includes(trimmed)) {
      const res = await aetherCliService.handleAetherCommand([trimmed], trimmed, currentCwd);
      if (res.stdout) this.logOutput(res.stdout, 'AETHER_CLI', currentCwd);
      if (res.stderr) this.logError(res.stderr, 'AETHER_CLI_ERR', currentCwd);
      return { stdout: res.stdout, stderr: res.stderr, exitCode: res.exitCode, cwd: currentCwd };
    }

    if (trimmed.startsWith('ext ') || trimmed === 'ext' || trimmed.startsWith('extensions ') || trimmed === 'extensions') {
      const parts = trimmed.split(/\s+/);
      const res = await aetherCliService.handleAetherCommand(['ext', ...parts.slice(1)], trimmed, currentCwd);
      if (res.stdout) this.logOutput(res.stdout, 'AETHER_CLI', currentCwd);
      if (res.stderr) this.logError(res.stderr, 'AETHER_CLI_ERR', currentCwd);
      return { stdout: res.stdout, stderr: res.stderr, exitCode: res.exitCode, cwd: currentCwd };
    }

    if (trimmed === 'help') {
      const helpMsg = `Aether Developer Shell & CLI Command Center:
  - aether <cmd>       : Aether CLI suite (core, keys, ext, gen, ai, build, test, doctor)
  - aether core        : View IDE Core Concepts (Multi-File, AI engine, OPFS, 3D WebGL)
  - aether keys        : View all global keyboard shortcuts & keybindings
  - aether ext list    : View and manage marketplace extensions & plugins
  - aether doctor      : Run complete system and environment health audit
  - aether tree        : View project directory visual ASCII tree
  - ls [path]          : List workspace directory contents
  - pwd                : Print working directory
  - cd <path>          : Change active working directory
  - cat <file>         : View file contents
  - node <file>        : Execute Node.js script
  - python3 <file>     : Execute Python script
  - npm <command>      : Run npm CLI commands
  - git <command>      : Version control operations
  - sysinfo / status   : Real-time CPU, RAM, process, & uptime stats
  - errors             : List all registered application runtime errors
  - env                : Display environment configuration
  - ping               : Test network latency
  - clear / cls        : Clear terminal log history`;
      this.logOutput(helpMsg, 'HELP');
      return { stdout: helpMsg, stderr: '', exitCode: 0, cwd: currentCwd };
    }

    if (trimmed === 'errors') {
      const errors = this.logs.filter(l => l.type === 'error');
      if (errors.length === 0) {
        this.logOutput('No real application errors registered in active session.', 'DIAGNOSTICS');
      } else {
        errors.slice(-15).forEach(e => {
          this.logError(`[${new Date(e.timestamp).toLocaleTimeString()}] (${e.source}): ${e.content}`, 'REGISTERED_ERROR');
        });
      }
      return { stdout: `Displayed ${errors.length} errors`, stderr: '', exitCode: 0, cwd: currentCwd };
    }

    if (trimmed === 'sysinfo' || trimmed === 'status') {
      try {
        const res = await fetch('/api/stats');
        const stats = await res.json();
        const output = `System Metrics & Container Environment:
  - Node Version: ${stats.nodeVersion || 'v20.x'}
  - Memory Usage: ${stats.mem || '12%'}
  - Server Uptime: ${stats.uptime || '0h'}
  - Environment: ${stats.environment || 'development'}
  - Architecture: ${stats.platform || 'linux'} (${stats.arch || 'x64'})
  - Active PID: ${stats.pid || 1}`;
        this.logOutput(output, 'SYSINFO');
        return { stdout: output, stderr: '', exitCode: 0, cwd: currentCwd };
      } catch (e: any) {
        this.logError(`Failed to fetch system stats: ${e.message}`, 'SYSINFO');
      }
    }

    if (trimmed === 'ping') {
      const start = Date.now();
      try {
        await fetch('/api/health');
        const lat = Date.now() - start;
        const msg = `PING /api/health: 64 bytes time=${lat}ms status=200 OK`;
        this.logOutput(msg, 'NETWORK');
        return { stdout: msg, stderr: '', exitCode: 0, cwd: currentCwd };
      } catch (e: any) {
        this.logError(`PING failed: ${e.message}`, 'NETWORK');
      }
    }

    try {
      const response = await fetch('/api/exec', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: trimmed, cwd: currentCwd, sandboxMode })
      });

      const data = await response.json();

      if (data.cwd) {
        this.cwd = data.cwd;
      }

      if (data.stdout) {
        this.logOutput(data.stdout, 'EXEC', data.cwd || currentCwd);
      }
      if (data.stderr) {
        this.logError(data.stderr, 'EXEC_ERR', data.cwd || currentCwd);
      }

      return {
        stdout: data.stdout || '',
        stderr: data.stderr || '',
        exitCode: data.exitCode ?? 0,
        cwd: data.cwd || currentCwd
      };
    } catch (err: any) {
      const errMsg = `Execution error: ${err.message || 'Server connection failed'}`;
      this.logError(errMsg, 'SYSTEM_ERR');
      return { stdout: '', stderr: errMsg, exitCode: 1, cwd: currentCwd };
    }
  }
}

export const terminalService = new TerminalService();
