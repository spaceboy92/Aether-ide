export interface WorkspaceSymbol {
  name: string;
  kind: 'function' | 'class' | 'interface' | 'variable' | 'type' | 'struct' | 'enum' | 'import';
  filePath: string;
  lineNumber: number;
  column: number;
  documentation?: string;
  signature?: string;
}

export interface WorkspaceDiagnostic {
  filePath: string;
  lineNumber: number;
  column: number;
  message: string;
  severity: 'error' | 'warning' | 'info';
  code?: string;
}

class WorkspaceLSP {
  private symbolIndex: Map<string, WorkspaceSymbol[]> = new Map();
  private diagnosticsCache: Map<string, WorkspaceDiagnostic[]> = new Map();
  private fileContents: Map<string, string> = new Map();

  /**
   * Index or update a single file in the workspace AST symbol map
   */
  public indexFile(filePath: string, content: string): void {
    this.fileContents.set(filePath, content);
    const symbols: WorkspaceSymbol[] = [];
    const lines = content.split('\n');

    const ext = filePath.split('.').pop()?.toLowerCase() || '';

    lines.forEach((line, idx) => {
      const lineNum = idx + 1;

      // JS / TS Parsing
      if (['ts', 'tsx', 'js', 'jsx'].includes(ext)) {
        // Functions
        const fnMatch = line.match(/(?:export\s+)?(?:async\s+)?function\s+([a-zA-Z0-9_$]+)\s*\(([^)]*)\)/);
        if (fnMatch) {
          symbols.push({
            name: fnMatch[1],
            kind: 'function',
            filePath,
            lineNumber: lineNum,
            column: line.indexOf(fnMatch[1]) + 1,
            signature: `function ${fnMatch[1]}(${fnMatch[2]})`,
            documentation: `Exported function declared in ${filePath}`
          });
        }

        // Arrow Functions / Const assignments
        const constFnMatch = line.match(/(?:export\s+)?const\s+([a-zA-Z0-9_$]+)\s*=\s*(?:async\s*)?\(([^)]*)\)\s*=>/);
        if (constFnMatch) {
          symbols.push({
            name: constFnMatch[1],
            kind: 'function',
            filePath,
            lineNumber: lineNum,
            column: line.indexOf(constFnMatch[1]) + 1,
            signature: `const ${constFnMatch[1]} = (${constFnMatch[2]}) => ...`,
            documentation: `Arrow function in ${filePath}`
          });
        }

        // Interfaces & Types & Classes
        const classMatch = line.match(/(?:export\s+)?class\s+([a-zA-Z0-9_$]+)/);
        if (classMatch) {
          symbols.push({
            name: classMatch[1],
            kind: 'class',
            filePath,
            lineNumber: lineNum,
            column: line.indexOf(classMatch[1]) + 1,
            signature: `class ${classMatch[1]}`,
            documentation: `Class declaration in ${filePath}`
          });
        }

        const interfaceMatch = line.match(/(?:export\s+)?interface\s+([a-zA-Z0-9_$]+)/);
        if (interfaceMatch) {
          symbols.push({
            name: interfaceMatch[1],
            kind: 'interface',
            filePath,
            lineNumber: lineNum,
            column: line.indexOf(interfaceMatch[1]) + 1,
            signature: `interface ${interfaceMatch[1]}`,
            documentation: `TypeScript Interface in ${filePath}`
          });
        }

        const typeMatch = line.match(/(?:export\s+)?type\s+([a-zA-Z0-9_$]+)/);
        if (typeMatch) {
          symbols.push({
            name: typeMatch[1],
            kind: 'type',
            filePath,
            lineNumber: lineNum,
            column: line.indexOf(typeMatch[1]) + 1,
            signature: `type ${typeMatch[1]}`,
            documentation: `TypeScript Type Alias in ${filePath}`
          });
        }
      }

      // Python Parsing
      if (ext === 'py') {
        const pyFn = line.match(/def\s+([a-zA-Z0-9_]+)\s*\(([^)]*)\):/);
        if (pyFn) {
          symbols.push({
            name: pyFn[1],
            kind: 'function',
            filePath,
            lineNumber: lineNum,
            column: line.indexOf(pyFn[1]) + 1,
            signature: `def ${pyFn[1]}(${pyFn[2]})`,
            documentation: `Python function in ${filePath}`
          });
        }

        const pyClass = line.match(/class\s+([a-zA-Z0-9_]+)/);
        if (pyClass) {
          symbols.push({
            name: pyClass[1],
            kind: 'class',
            filePath,
            lineNumber: lineNum,
            column: line.indexOf(pyClass[1]) + 1,
            signature: `class ${pyClass[1]}`,
            documentation: `Python Class in ${filePath}`
          });
        }
      }

      // Rust Parsing
      if (ext === 'rs') {
        const rsFn = line.match(/(?:pub\s+)?fn\s+([a-zA-Z0-9_]+)\s*\(([^)]*)\)/);
        if (rsFn) {
          symbols.push({
            name: rsFn[1],
            kind: 'function',
            filePath,
            lineNumber: lineNum,
            column: line.indexOf(rsFn[1]) + 1,
            signature: `fn ${rsFn[1]}(${rsFn[2]})`,
            documentation: `Rust function in ${filePath}`
          });
        }
        const rsStruct = line.match(/(?:pub\s+)?struct\s+([a-zA-Z0-9_]+)/);
        if (rsStruct) {
          symbols.push({
            name: rsStruct[1],
            kind: 'struct',
            filePath,
            lineNumber: lineNum,
            column: line.indexOf(rsStruct[1]) + 1,
            signature: `struct ${rsStruct[1]}`,
            documentation: `Rust struct in ${filePath}`
          });
        }
      }
    });

    this.symbolIndex.set(filePath, symbols);
    this.runWorkspaceDiagnostics(filePath, content);
  }

  /**
   * Index entire workspace array of files
   */
  public indexWorkspace(files: Array<{ path: string; content: string }>): void {
    files.forEach(f => this.indexFile(f.path, f.content));
  }

  /**
   * Find definition of a symbol across all indexed workspace files
   */
  public findDefinition(symbolName: string): WorkspaceSymbol | undefined {
    for (const [, symbols] of this.symbolIndex) {
      const match = symbols.find(s => s.name === symbolName);
      if (match) return match;
    }
    return undefined;
  }

  /**
   * Search all symbols matching query
   */
  public searchSymbols(query: string): WorkspaceSymbol[] {
    const q = query.toLowerCase();
    const results: WorkspaceSymbol[] = [];
    for (const [, symbols] of this.symbolIndex) {
      for (const sym of symbols) {
        if (sym.name.toLowerCase().includes(q)) {
          results.push(sym);
        }
      }
    }
    return results;
  }

  /**
   * Run multi-file workspace diagnostics (broken imports, unused vars)
   */
  private runWorkspaceDiagnostics(filePath: string, content: string): void {
    const diagnostics: WorkspaceDiagnostic[] = [];
    const lines = content.split('\n');

    lines.forEach((line, idx) => {
      // Check relative JS/TS import existence
      const importMatch = line.match(/import\s+.*\s+from\s+['"](\.\/|\.\.\/)([^'"]+)['"]/);
      if (importMatch) {
        const importRel = importMatch[1] + importMatch[2];
        const currentDir = filePath.substring(0, filePath.lastIndexOf('/'));
        let targetPath = `${currentDir}/${importRel.replace(/^\.\//, '')}`;
        
        // Normalize target path
        if (!targetPath.endsWith('.ts') && !targetPath.endsWith('.tsx') && !targetPath.endsWith('.js') && !targetPath.endsWith('.jsx')) {
          if (this.fileContents.has(`${targetPath}.ts`)) targetPath += '.ts';
          else if (this.fileContents.has(`${targetPath}.tsx`)) targetPath += '.tsx';
          else if (this.fileContents.has(`${targetPath}.js`)) targetPath += '.js';
          else if (this.fileContents.has(`${targetPath}.jsx`)) targetPath += '.jsx';
          else if (this.fileContents.has(`${targetPath}/index.ts`)) targetPath += '/index.ts';
        }

        if (this.fileContents.size > 0 && !this.fileContents.has(targetPath)) {
          diagnostics.push({
            filePath,
            lineNumber: idx + 1,
            column: line.indexOf(importMatch[0]) + 1,
            message: `Workspace LSP Warning: Target module '${importRel}' does not exist in workspace.`,
            severity: 'warning'
          });
        }
      }
    });

    this.diagnosticsCache.set(filePath, diagnostics);
  }

  public getDiagnostics(filePath: string): WorkspaceDiagnostic[] {
    return this.diagnosticsCache.get(filePath) || [];
  }

  public getAllDiagnostics(): WorkspaceDiagnostic[] {
    const all: WorkspaceDiagnostic[] = [];
    for (const [, diagList] of this.diagnosticsCache) {
      all.push(...diagList);
    }
    return all;
  }
}

export const workspaceLSP = new WorkspaceLSP();
