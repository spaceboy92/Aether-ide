// ============================================================================
// LOW-LEVEL PROCESSING ENGINE & GLSL SHADER SYNTHESIZER
// Direct TypedArray geometry generation, GLSL Custom Vertex/Fragment Shaders,
// Procedural Web Audio API DSP nodes, and Canvas ImageData pixel buffers.
// ============================================================================

export interface CustomGLSLShader {
  id: string;
  name: string;
  type: 'surface' | 'terrain' | 'post_process' | 'particle' | 'atmosphere';
  vertexShader: string;
  fragmentShader: string;
  uniforms: Record<string, { type: 'f' | 'v2' | 'v3' | 'c' | 't'; value: any }>;
}

export const PRESET_GLSL_SHADERS: Record<string, CustomGLSLShader> = {
  pbrTerrain: {
    id: 'pbrTerrain',
    name: 'Low-Level Multi-Octave Noise Terrain GLSL',
    type: 'terrain',
    vertexShader: `
      varying vec2 vUv;
      varying vec3 vNormal;
      varying vec3 vPosition;
      uniform float uTime;
      uniform float uElevationScale;

      float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
      float noise(vec2 p) {
        vec2 i = floor(p); vec2 f = fract(p);
        f = f*f*(3.0-2.0*f);
        return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), f.x),
                   mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), f.x), f.y);
      }

      void main() {
        vUv = uv;
        vNormal = normal;
        vec3 pos = position;
        float h = noise(pos.xz * 0.05) * 4.0 + noise(pos.xz * 0.1) * 2.0;
        pos.y += h * uElevationScale;
        vPosition = pos;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
      }
    `,
    fragmentShader: `
      varying vec2 vUv;
      varying vec3 vNormal;
      varying vec3 vPosition;
      uniform vec3 uGrassColor;
      uniform vec3 uRockColor;

      void main() {
        float slope = 1.0 - abs(vNormal.y);
        vec3 baseColor = mix(uGrassColor, uRockColor, smoothstep(0.3, 0.7, slope));
        float heightFactor = clamp(vPosition.y / 10.0, 0.0, 1.0);
        vec3 finalColor = mix(baseColor, vec3(0.9, 0.95, 1.0), smoothstep(0.6, 1.0, heightFactor));
        gl_FragColor = vec4(finalColor, 1.0);
      }
    `,
    uniforms: {
      uTime: { type: 'f', value: 0 },
      uElevationScale: { type: 'f', value: 1.0 },
      uGrassColor: { type: 'c', value: '#3a5e2a' },
      uRockColor: { type: 'c', value: '#52525b' }
    }
  },
  waterDisplacement: {
    id: 'waterDisplacement',
    name: 'Low-Level Real-Time Gerstner Ocean Waves GLSL',
    type: 'surface',
    vertexShader: `
      varying vec2 vUv;
      varying vec3 vPosition;
      varying vec3 vNormal;
      uniform float uTime;
      uniform float uWaveHeight;
      uniform float uWaveSpeed;

      void main() {
        vUv = uv;
        vec3 pos = position;
        float t = uTime * uWaveSpeed;
        
        // Multi-directional Gerstner wave superposition
        float w1 = sin(pos.x * 0.15 + pos.z * 0.15 + t * 1.5) * uWaveHeight;
        float w2 = cos(pos.x * -0.22 + pos.z * 0.18 + t * 1.8) * (uWaveHeight * 0.6);
        float w3 = sin(pos.x * 0.4 - pos.z * 0.3 + t * 2.6) * (uWaveHeight * 0.25);
        
        pos.y += w1 + w2 + w3;
        vPosition = pos;

        // Normal approximation
        float dx = cos(pos.x * 0.15 + pos.z * 0.15 + t * 1.5) * 0.15 * uWaveHeight;
        float dz = cos(pos.x * 0.15 + pos.z * 0.15 + t * 1.5) * 0.15 * uWaveHeight;
        vNormal = normalize(vec3(-dx, 1.0, -dz));

        gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
      }
    `,
    fragmentShader: `
      varying vec2 vUv;
      varying vec3 vPosition;
      varying vec3 vNormal;
      uniform float uTime;
      uniform vec3 uDeepWater;
      uniform vec3 uShallowWater;
      uniform vec3 uFoamColor;

      void main() {
        float peakFactor = clamp((vPosition.y + 0.4) / 1.4, 0.0, 1.0);
        vec3 waterCol = mix(uDeepWater, uShallowWater, peakFactor);
        
        // Foam crests at high wave points
        float foamFactor = smoothstep(0.65, 0.95, peakFactor);
        vec3 finalColor = mix(waterCol, uFoamColor, foamFactor);

        // Specular sun glint
        vec3 lightDir = normalize(vec3(0.5, 1.0, 0.3));
        float spec = pow(max(0.0, dot(vNormal, lightDir)), 32.0) * 0.6;
        finalColor += vec3(spec);

        gl_FragColor = vec4(finalColor, 0.88);
      }
    `,
    uniforms: {
      uTime: { type: 'f', value: 0 },
      uWaveHeight: { type: 'f', value: 0.6 },
      uWaveSpeed: { type: 'f', value: 1.5 },
      uDeepWater: { type: 'c', value: '#082f49' },
      uShallowWater: { type: 'c', value: '#06b6d4' },
      uFoamColor: { type: 'c', value: '#f0fdfa' }
    }
  },
  hologramShield: {
    id: 'hologramShield',
    name: 'Sci-Fi Hologram Energy Shield GLSL',
    type: 'surface',
    vertexShader: `
      varying vec3 vNormal;
      varying vec3 vViewPosition;
      void main() {
        vNormal = normalize(normalMatrix * normal);
        vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
        vViewPosition = -mvPosition.xyz;
        gl_Position = projectionMatrix * mvPosition;
      }
    `,
    fragmentShader: `
      varying vec3 vNormal;
      varying vec3 vViewPosition;
      uniform float uTime;
      uniform vec3 uColor;

      void main() {
        vec3 normal = normalize(vNormal);
        vec3 viewDir = normalize(vViewPosition);
        float fresnel = pow(1.0 - abs(dot(normal, viewDir)), 3.0);
        float grid = sin(gl_FragCoord.y * 0.2 + uTime * 4.0) * 0.5 + 0.5;
        gl_FragColor = vec4(uColor * (fresnel + grid * 0.4), clamp(fresnel + 0.2, 0.0, 0.9));
      }
    `,
    uniforms: {
      uTime: { type: 'f', value: 0 },
      uColor: { type: 'c', value: '#06b6d4' }
    }
  }
};

// Low-Level TypedArray Geometry Builder (200,000+ Triangles High-Density Standard)
export function generateProceduralMeshBuffers(subdivisions: number = 320): {
  positions: Float32Array;
  normals: Float32Array;
  uvs: Float32Array;
  indices: Uint32Array;
} {
  const count = (subdivisions + 1) * (subdivisions + 1);
  const positions = new Float32Array(count * 3);
  const normals = new Float32Array(count * 3);
  const uvs = new Float32Array(count * 2);
  const indices = new Uint32Array(subdivisions * subdivisions * 6);

  let pIdx = 0, nIdx = 0, uIdx = 0, iIdx = 0;

  for (let i = 0; i <= subdivisions; i++) {
    const v = i / subdivisions;
    const z = (v - 0.5) * 100;

    for (let j = 0; j <= subdivisions; j++) {
      const u = j / subdivisions;
      const x = (u - 0.5) * 100;
      const y = Math.sin(u * Math.PI * 4) * Math.cos(v * Math.PI * 4) * 2.0;

      positions[pIdx++] = x;
      positions[pIdx++] = y;
      positions[pIdx++] = z;

      normals[nIdx++] = 0;
      normals[nIdx++] = 1;
      normals[nIdx++] = 0;

      uvs[uIdx++] = u;
      uvs[uIdx++] = v;
    }
  }

  for (let i = 0; i < subdivisions; i++) {
    for (let j = 0; j < subdivisions; j++) {
      const a = i * (subdivisions + 1) + j;
      const b = a + 1;
      const c = (i + 1) * (subdivisions + 1) + j;
      const d = c + 1;

      indices[iIdx++] = a;
      indices[iIdx++] = c;
      indices[iIdx++] = b;

      indices[iIdx++] = b;
      indices[iIdx++] = c;
      indices[iIdx++] = d;
    }
  }

  return { positions, normals, uvs, indices };
}

// Low-Level Web Audio API Procedural SFX Synthesizer
export function playProceduralSFX(type: 'laser' | 'explosion' | 'engine' | 'footstep' | 'powerup' | 'water_splash' | 'ocean_wave') {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();

    if (type === 'laser') {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(880, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(110, ctx.currentTime + 0.15);
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.15);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.15);
    } else if (type === 'explosion') {
      const bufferSize = ctx.sampleRate * 0.4;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      const noise = ctx.createBufferSource();
      noise.buffer = buffer;
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(1000, ctx.currentTime);
      filter.frequency.exponentialRampToValueAtTime(40, ctx.currentTime + 0.4);
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.5, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
      noise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      noise.start();
    } else if (type === 'water_splash') {
      const bufferSize = Math.floor(ctx.sampleRate * 0.5);
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        const decay = 1.0 - (i / bufferSize);
        data[i] = (Math.random() * 2 - 1) * Math.pow(decay, 1.6);
      }
      const noise = ctx.createBufferSource();
      noise.buffer = buffer;
      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(750, ctx.currentTime);
      filter.frequency.exponentialRampToValueAtTime(240, ctx.currentTime + 0.5);
      filter.Q.setValueAtTime(3.0, ctx.currentTime);
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.35, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);
      noise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      noise.start();
    } else if (type === 'ocean_wave') {
      const bufferSize = Math.floor(ctx.sampleRate * 1.5);
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      const noise = ctx.createBufferSource();
      noise.buffer = buffer;
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(220, ctx.currentTime);
      filter.frequency.linearRampToValueAtTime(650, ctx.currentTime + 0.7);
      filter.frequency.exponentialRampToValueAtTime(150, ctx.currentTime + 1.5);
      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.05, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.3, ctx.currentTime + 0.7);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.5);
      noise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      noise.start();
    }
  } catch (e) {
    // Ignore audio context autoplay restriction errors
  }
}
