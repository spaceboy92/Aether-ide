export interface AetherExtension {
  id: string;
  name: string;
  version: string;
  author: string;
  description: string;
  category: 'theme' | 'keymap' | 'tool' | 'linter' | 'snippet';
  icon: string;
  installed: boolean;
  themeConfig?: {
    base: 'vs-dark' | 'vs-light';
    colors: Record<string, string>;
  };
  snippetPack?: Array<{
    label: string;
    body: string;
    description: string;
    language: string;
  }>;
}

export const BUILTIN_EXTENSIONS: AetherExtension[] = [
  {
    id: 'theme-dracula-pro',
    name: 'Dracula Official Theme',
    version: '2.4.0',
    author: 'Dracula Theme',
    description: 'Dark theme for Aether IDE with rich token contrast and neon accents',
    category: 'theme',
    icon: '🧛',
    installed: true,
    themeConfig: {
      base: 'vs-dark',
      colors: {
        'editor.background': '#282a36',
        'editor.foreground': '#f8f8f2',
        'editorCursor.foreground': '#ff79c6',
        'editor.lineHighlightBackground': '#44475a',
        'editorLineNumber.foreground': '#6272a4',
        'editor.selectionBackground': '#44475a'
      }
    }
  },
  {
    id: 'theme-tokyo-night',
    name: 'Tokyo Night Storm',
    version: '3.1.0',
    author: 'folke',
    description: 'A clean, dark Tokyo Night theme celebrating neon lights of Tokyo at night',
    category: 'theme',
    icon: '🌃',
    installed: true,
    themeConfig: {
      base: 'vs-dark',
      colors: {
        'editor.background': '#1a1b26',
        'editor.foreground': '#a9b1d6',
        'editorCursor.foreground': '#7aa2f7',
        'editor.lineHighlightBackground': '#24283b',
        'editorLineNumber.foreground': '#565f89',
        'editor.selectionBackground': '#33467c'
      }
    }
  },
  {
    id: 'theme-one-dark-pro',
    name: 'One Dark Pro',
    version: '3.10.1',
    author: 'binaryify',
    description: "Atom's iconic One Dark theme for Monaco Editor",
    category: 'theme',
    icon: '⚛️',
    installed: false,
    themeConfig: {
      base: 'vs-dark',
      colors: {
        'editor.background': '#282c34',
        'editor.foreground': '#abb2bf',
        'editorCursor.foreground': '#528bff',
        'editor.lineHighlightBackground': '#2c313c',
        'editorLineNumber.foreground': '#4b5263'
      }
    }
  },
  {
    id: 'keymap-vim-emulation',
    name: 'Vim Mode Emulation',
    version: '1.2.0',
    author: 'Aether Team',
    description: 'Modal editing keybindings (Normal, Insert, Visual mode) inside Monaco',
    category: 'keymap',
    icon: '⌨️',
    installed: true
  },
  {
    id: 'snippets-python-data-science',
    name: 'Python Data Science Snippets',
    version: '1.0.5',
    author: 'PyData',
    description: 'Snippets for NumPy, Pandas, Matplotlib, Scikit-Learn, and PyTorch',
    category: 'snippet',
    icon: '🐍',
    installed: true,
    snippetPack: [
      {
        label: 'import pandas as pd',
        body: 'import pandas as pd\nimport numpy as np\n\ndf = pd.read_csv("${1:data.csv}")\nprint(df.head())',
        description: 'Standard Pandas CSV loading template',
        language: 'python'
      },
      {
        label: 'import matplotlib.pyplot as plt',
        body: 'import matplotlib.pyplot as plt\n\nplt.figure(figsize=(10, 6))\nplt.plot(${1:x}, ${2:y}, label="${3:Series}")\nplt.title("${4:Chart}")\nplt.legend()\nplt.savefig("${5:plot.png}")\nplt.show()',
        description: 'Matplotlib line plot template',
        language: 'python'
      }
    ]
  },
  {
    id: 'linter-eslint-prettier',
    name: 'ESLint & Prettier Auto-Fixer',
    version: '2.1.0',
    author: 'Formatters',
    description: 'On-save linting and code formatting for JS, TS, HTML, and CSS',
    category: 'linter',
    icon: '✨',
    installed: true
  }
];

class ExtensionManager {
  private extensions: Map<string, AetherExtension> = new Map();

  constructor() {
    this.loadInstalledExtensions();
  }

  private loadInstalledExtensions() {
    BUILTIN_EXTENSIONS.forEach(ext => this.extensions.set(ext.id, ext));
    try {
      const stored = localStorage.getItem('aether_installed_extensions');
      if (stored) {
        const parsed: AetherExtension[] = JSON.parse(stored);
        parsed.forEach(ext => this.extensions.set(ext.id, ext));
      }
    } catch (e) {}
  }

  public getExtensions(): AetherExtension[] {
    return Array.from(this.extensions.values());
  }

  public toggleInstall(extensionId: string): boolean {
    const ext = this.extensions.get(extensionId);
    if (!ext) return false;
    ext.installed = !ext.installed;
    this.save();
    return ext.installed;
  }

  private save() {
    try {
      localStorage.setItem('aether_installed_extensions', JSON.stringify(this.getExtensions()));
    } catch (e) {}
  }
}

export const extensionManager = new ExtensionManager();
