import Dexie, { type Table } from 'dexie';

export interface LocalFile {
  id?: string; // Changed to string to match FileNode.id
  sessionId: string; // Added sessionId association
  name: string; // Changed from path to name to match FileNode
  content: string;
  language: string;
  updatedAt: number;
}

export interface LocalTask {
  id: string;
  content: string;
  column: 'todo' | 'progress' | 'done';
  priority: 'low' | 'medium' | 'high';
  updatedAt: number;
}

export interface LocalSession {
  id: string;
  title: string;
  description?: string;
  tags?: string[];
  thumbnailUrl?: string;
  snapshots?: any[];
  messages: any[];
  updatedAt: number;
}

export class ApplicationDatabase extends Dexie {
  files!: Table<LocalFile>;
  tasks!: Table<LocalTask>;
  sessions!: Table<LocalSession>;

  constructor() {
    super('AetherAppDatabase');
    this.version(1).stores({
      files: 'id, sessionId, name, updatedAt',
      tasks: 'id, column, priority, updatedAt',
      sessions: 'id, updatedAt'
    });
  }
}

export const db = new ApplicationDatabase();

export const storageService = {
  // Files
  async saveFile(sessionId: string, file: any) {
    const data = {
      ...file,
      sessionId,
      updatedAt: Date.now()
    };
    return db.files.put(data);
  },

  async saveFiles(sessionId: string, files: any[]) {
    const data = files.map(f => ({
      ...f,
      sessionId,
      updatedAt: Date.now()
    }));
    return db.files.bulkPut(data);
  },

  async getFilesForSession(sessionId: string) {
    return db.files.where('sessionId').equals(sessionId).toArray();
  },

  async deleteFile(id: string) {
    return db.files.delete(id);
  },

  async deleteFilesForSession(sessionId: string) {
    return db.files.where('sessionId').equals(sessionId).delete();
  },

  async getFile(id: string) {
    return db.files.get(id);
  },

  async getAllFiles() {
    return db.files.toArray();
  },

  // Tasks
  async saveTasks(tasks: LocalTask[]) {
    return db.tasks.bulkPut(tasks.map(t => ({ ...t, updatedAt: Date.now() })));
  },

  async getAllTasks() {
    return db.tasks.toArray();
  },

  // Sessions
  async saveSession(session: LocalSession) {
    return db.sessions.put({ ...session, updatedAt: Date.now() });
  },

  async getAllSessions() {
    return db.sessions.orderBy('updatedAt').reverse().toArray();
  },

  async deleteSession(id: string) {
    return db.sessions.delete(id);
  },

  async clearAll() {
    await db.files.clear();
    await db.tasks.clear();
    await db.sessions.clear();
  }
};
