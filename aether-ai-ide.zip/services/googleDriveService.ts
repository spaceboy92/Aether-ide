
import JSZip from 'jszip';
import { FileNode, ChatSession } from '../types';

const GOOGLE_API_KEY = process.env.GOOGLE_API_KEY; // Optional, for public files

async function retryWithBackoff<T extends Response | any>(fn: () => Promise<T>, retries = 3, delay = 1000): Promise<T> {
    try {
        const response = await fn();
        if (response instanceof Response && !response.ok) {
            if (response.status === 401) {
                localStorage.removeItem("google_drive_access_token");
                throw new Error("Google Drive auth expired");
            }
            if (response.status === 429) {
                throw Object.assign(new Error("Rate Limit"), { status: 429 });
            }
        }
        return response;
    } catch (error: any) {
        if (retries > 0 && (error?.status === 429 || error?.message?.includes('429'))) {
            console.warn(`Drive Rate limit hit, retrying in ${delay}ms... (Retries left: ${retries})`);
            await new Promise(resolve => setTimeout(resolve, delay));
            return retryWithBackoff(fn, retries - 1, delay * 2);
        }
        throw error;
    }
}

export const getGoogleAuthUrl = async () => {
    const response = await retryWithBackoff(() => fetch('/api/auth/google/url'));
    const data = await response.json();
    return data.url;
};

export const saveUserConfigToDrive = async (tokens: any, userConfig: any) => {
    const accessToken = tokens.access_token;
    const folderName = 'Aether IDE';
    let folderId = await getOrCreateFolder(accessToken, folderName);
    
    const fileName = 'user_config.json';
    const content = JSON.stringify(userConfig, null, 2);
    
    await saveFileToDrive(accessToken, folderId, fileName, content);
};

export const saveSessionToDrive = async (tokens: any, session: ChatSession): Promise<string> => {
    const accessToken = tokens.access_token;
    const folderName = 'Aether IDE';
    
    // 1. Find or create the master folder
    let folderId = await getOrCreateFolder(accessToken, folderName);

    // 2. Save session as separate JSON file
    const fileName = `${session.id}.json`;
    const content = JSON.stringify(session, null, 2);
    
    await saveFileToDrive(accessToken, folderId, fileName, content);
    return folderId;
};

export const deleteSessionFromDrive = async (tokens: any, sessionId: string) => {
    const accessToken = tokens.access_token;
    const folderName = 'Aether IDE';
    let folderId = await getOrCreateFolder(accessToken, folderName);

    const fileName = `${sessionId}.json`;
    const searchRes = await retryWithBackoff(() => fetch(`https://www.googleapis.com/drive/v3/files?q=name='${fileName}' and '${folderId}' in parents and trashed=false`, {
        headers: { 'Authorization': `Bearer ${accessToken}` }
    }));
    const searchData = await searchRes.json();
    const existingFile = searchData.files && searchData.files[0];

    if (existingFile) {
        await retryWithBackoff(() => fetch(`https://www.googleapis.com/drive/v3/files/${existingFile.id}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${accessToken}` }
        }));
        console.log(`Deleted session ${sessionId} from Drive.`);
    }
};

export const deleteAllSessionsFromDrive = async (tokens: any) => {
    const accessToken = tokens.access_token;
    const folderName = 'Aether IDE';
    let folderId = await getOrCreateFolder(accessToken, folderName);

    const searchRes = await retryWithBackoff(() => fetch(`https://www.googleapis.com/drive/v3/files?q=name contains '.json' and '${folderId}' in parents and trashed=false and name != 'user_config.json'`, {
        headers: { 'Authorization': `Bearer ${accessToken}` }
    }));
    const searchData = await searchRes.json();
    
    if (searchData.files && searchData.files.length > 0) {
        for (const file of searchData.files) {
            await retryWithBackoff(() => fetch(`https://www.googleapis.com/drive/v3/files/${file.id}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${accessToken}` }
            }));
        }
        console.log(`Deleted ${searchData.files.length} sessions from Drive.`);
    }
};

export const getAllSessionsFromDrive = async (tokens: { access_token: string }): Promise<ChatSession[]> => {
    const accessToken = tokens.access_token;
    const folderName = 'Aether IDE';
    let folderId = await getOrCreateFolder(accessToken, folderName);

    const searchRes = await retryWithBackoff(() => fetch(`https://www.googleapis.com/drive/v3/files?q=name contains '.json' and '${folderId}' in parents and trashed=false and name != 'user_config.json'`, {
        headers: { 'Authorization': `Bearer ${accessToken}` }
    }));
    const searchData = await searchRes.json();
    
    const sessions: ChatSession[] = [];
    // Only fetch first 20 sessions to avoid massive rate limits on start
    const filesToFetch = (searchData.files || []).slice(0, 20);
    
    for (const file of filesToFetch) {
        try {
            const fileRes = await retryWithBackoff(() => fetch(`https://www.googleapis.com/drive/v3/files/${file.id}?alt=media`, {
                headers: { 'Authorization': `Bearer ${accessToken}` }
            }));
            if (fileRes.ok) {
                sessions.push(await fileRes.json());
            }
        } catch (e) {
            console.error(`Failed to fetch session file ${file.id}:`, e);
        }
    }
    return sessions;
};

export const getUserConfigFromDrive = async (tokens: any): Promise<any | null> => {
    const accessToken = tokens.access_token;
    const folderName = 'Aether IDE';
    let folderId = await getOrCreateFolder(accessToken, folderName);

    const searchRes = await retryWithBackoff(() => fetch(`https://www.googleapis.com/drive/v3/files?q=name='user_config.json' and '${folderId}' in parents and trashed=false`, {
        headers: { 'Authorization': `Bearer ${accessToken}` }
    }));
    const searchData = await searchRes.json();
    const existingFile = searchData.files && searchData.files[0];

    if (!existingFile) return null;

    const fileRes = await retryWithBackoff(() => fetch(`https://www.googleapis.com/drive/v3/files/${existingFile.id}?alt=media`, {
        headers: { 'Authorization': `Bearer ${accessToken}` }
    }));
    
    if (fileRes.ok) {
        return await fileRes.json();
    }
    return null;
};

export const syncProjectToDrive = async (tokens: any, projectName: string, files: FileNode[]) => {
    const accessToken = tokens.access_token;
    const folderName = 'Aether Projects';
    let folderId = await getOrCreateFolder(accessToken, folderName);
    
    const zip = new JSZip();
    files.forEach(file => {
        zip.file(file.path || file.name, file.content);
    });
    
    const blob = await zip.generateAsync({ type: 'blob' });
    const fileName = `${projectName}.zip`;
    
    // We need a specialized save for blobs
    await saveBlobToDrive(accessToken, folderId, fileName, blob);
};

async function saveBlobToDrive(accessToken: string, folderId: string, fileName: string, blob: Blob) {
    const searchRes = await retryWithBackoff(() => fetch(`https://www.googleapis.com/drive/v3/files?q=name='${fileName}' and '${folderId}' in parents and trashed=false`, {
        headers: { 'Authorization': `Bearer ${accessToken}` }
    }));
    const searchData = await searchRes.json();
    const existingFile = searchData.files && searchData.files[0];

    const metadata: any = {
        name: fileName,
        mimeType: 'application/zip'
    };

    if (!existingFile) {
        metadata.parents = [folderId];
    }

    const boundary = '-------314159265358979323846';
    const delimiter = "\r\n--" + boundary + "\r\n";
    const close_delim = "\r\n--" + boundary + "--";

    // Convert blob to base64 or arrayBuffer for multipart
    const arrayBuffer = await blob.arrayBuffer();
    
    const multipartBody = new Blob([
        delimiter,
        'Content-Type: application/json; charset=UTF-8\r\n\r\n',
        JSON.stringify(metadata),
        delimiter,
        'Content-Type: application/zip\r\n\r\n',
        arrayBuffer,
        close_delim
    ], { type: `multipart/related; boundary=${boundary}` });

    let url = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';
    let method = 'POST';

    if (existingFile) {
        url = `https://www.googleapis.com/upload/drive/v3/files/${existingFile.id}?uploadType=multipart`;
        method = 'PATCH';
    }

    const response = await retryWithBackoff(() => fetch(url, {
        method: method,
        headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': `multipart/related; boundary=${boundary}`
        },
        body: multipartBody
    }));

    if (!response.ok) {
        throw new Error(`Project sync failed: ${response.status}`);
    }
    console.log('Project synced to Google Drive.');
}

async function getOrCreateFolder(accessToken: string, folderName: string): Promise<string> {
    const searchRes = await retryWithBackoff(() => fetch(`https://www.googleapis.com/drive/v3/files?q=name='${folderName}' and mimeType='application/vnd.google-apps.folder' and trashed=false`, {
        headers: { 'Authorization': `Bearer ${accessToken}` }
    }));
    const searchData = await searchRes.json();
    if (searchData.files && searchData.files.length > 0) return searchData.files[0].id;

    const createRes = await retryWithBackoff(() => fetch(`https://www.googleapis.com/drive/v3/files`, {
        method: 'POST',
        headers: { 
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            name: folderName,
            mimeType: 'application/vnd.google-apps.folder'
        })
    }));
    const folderData = await createRes.json();
    return folderData.id;
}

async function saveFileToDrive(accessToken: string, folderId: string, fileName: string, content: string) {
    const searchRes = await retryWithBackoff(() => fetch(`https://www.googleapis.com/drive/v3/files?q=name='${fileName}' and '${folderId}' in parents and trashed=false`, {
        headers: { 'Authorization': `Bearer ${accessToken}` }
    }));
    const searchData = await searchRes.json();
    const existingFile = searchData.files && searchData.files[0];

    const metadata: any = {
        name: fileName,
        mimeType: 'application/json'
    };

    if (!existingFile) {
        metadata.parents = [folderId];
    }

    const boundary = '-------314159265358979323846';
    const delimiter = "\r\n--" + boundary + "\r\n";
    const close_delim = "\r\n--" + boundary + "--";

    const getMultipartBody = (metaObj: any) => {
        return delimiter +
            'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
            JSON.stringify(metaObj) +
            delimiter +
            'Content-Type: application/json\r\n\r\n' +
            content +
            close_delim;
    };

    const multipartBody = getMultipartBody(metadata);

    let url = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';
    let method = 'POST';

    if (existingFile) {
        url = `https://www.googleapis.com/upload/drive/v3/files/${existingFile.id}?uploadType=multipart`;
        method = 'PATCH';
    }

    let urlToUse = url;
    let methodToUse = method;

    let response = await retryWithBackoff(() => fetch(urlToUse, {
        method: methodToUse,
        headers: {
            'Authorization': `Bearer ${accessToken}`,
            'Content-Type': `multipart/related; boundary=${boundary}`
        },
        body: multipartBody
    }));

    if (!response.ok && methodToUse === 'PATCH') {
        console.warn(`Drive PATCH failed with status ${response.status}. Falling back to POST (create new file).`);
        urlToUse = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';
        methodToUse = 'POST';
        const fallbackMetadata = {
            ...metadata,
            parents: [folderId]
        };
        const fallbackBody = getMultipartBody(fallbackMetadata);
        response = await retryWithBackoff(() => fetch(urlToUse, {
            method: methodToUse,
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': `multipart/related; boundary=${boundary}`
            },
            body: fallbackBody
        }));
    }

    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        console.error('Google Drive Upload Failed:', response.status, errorData);
        
        if (response.status === 401) {
            localStorage.removeItem("google_drive_access_token");
        }
        
        throw new Error(`Upload failed: ${response.status} ${response.statusText || 'Unknown Error'}`);
    }
    console.log('Google Drive Upload Successful.');
}
