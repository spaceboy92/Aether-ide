import * as THREE from 'three';

// ============================================================================
// ULTRA-REALISTIC PBR TEXTURE LOADING & PROCEDURAL SYNTHESIS ENGINE
// Full PBR workflow: Albedo, Tangent-Space Normal Maps, Roughness, Metalness,
// Ambient Occlusion (AO), Emissive, Height/Displacement, and Clearcoat.
// ============================================================================

export interface PBRTextureMaps {
  albedo: THREE.CanvasTexture | THREE.Texture;
  normal: THREE.CanvasTexture | THREE.Texture;
  roughness: THREE.CanvasTexture | THREE.Texture;
  metalness: THREE.CanvasTexture | THREE.Texture;
  ao?: THREE.CanvasTexture | THREE.Texture;
  emissive?: THREE.CanvasTexture | THREE.Texture;
}

export interface PBRMaterialPreset {
  id: string;
  name: string;
  category: 'composite' | 'metals' | 'sci_fi' | 'environment' | 'organic';
  color: string;
  roughness: number;
  metalness: number;
  clearcoat: number;
  clearcoatRoughness: number;
  normalScale: number;
  emissiveIntensity: number;
  emissiveColor: string;
  repeat: [number, number];
  description: string;
}

export const PBR_MATERIAL_PRESETS: Record<string, PBRMaterialPreset> = {
  carbon_fiber_twill: {
    id: 'carbon_fiber_twill',
    name: '🏎️ 4K 2x2 Twill Carbon Fiber Weave',
    category: 'composite',
    color: '#1a1a1d',
    roughness: 0.18,
    metalness: 0.45,
    clearcoat: 1.0,
    clearcoatRoughness: 0.08,
    normalScale: 1.8,
    emissiveIntensity: 0.0,
    emissiveColor: '#000000',
    repeat: [8, 8],
    description: 'Hypercar-grade autoclave pre-preg carbon fiber with anisotropic woven normal micro-facets and glossy high-depth clearcoat lacquer.'
  },
  weathered_sci_fi_plating: {
    id: 'weathered_sci_fi_plating',
    name: '🤖 Weathered Titanium Mech Plating',
    category: 'sci_fi',
    color: '#383d47',
    roughness: 0.35,
    metalness: 0.92,
    clearcoat: 0.2,
    clearcoatRoughness: 0.4,
    normalScale: 2.2,
    emissiveIntensity: 1.6,
    emissiveColor: '#06b6d4',
    repeat: [4, 4],
    description: 'Chamfered heavy armor panels with CNC beveled seams, micro-rivets, edge wear, and integrated cyan cyber-illumination channels.'
  },
  wet_asphalt_pavement: {
    id: 'wet_asphalt_pavement',
    name: '🌧️ Wet Rain-Soaked Asphalt & Aggregates',
    category: 'environment',
    color: '#18181b',
    roughness: 0.12,
    metalness: 0.1,
    clearcoat: 0.9,
    clearcoatRoughness: 0.05,
    normalScale: 1.5,
    emissiveIntensity: 0.0,
    emissiveColor: '#000000',
    repeat: [12, 12],
    description: 'High-friction bitumen roadway with gravel aggregate bumps, specular puddle sheen, and dynamic water film reflections.'
  },
  damascus_folded_steel: {
    id: 'damascus_folded_steel',
    name: '⚔️ Damascus Swirled Aerometal',
    category: 'metals',
    color: '#475569',
    roughness: 0.22,
    metalness: 0.98,
    clearcoat: 0.6,
    clearcoatRoughness: 0.15,
    normalScale: 1.4,
    emissiveIntensity: 0.0,
    emissiveColor: '#000000',
    repeat: [6, 6],
    description: 'Pattern-welded aerospace Damascus steel with intricate fluid wave striations and dual-phase microcrystalline reflectivity.'
  },
  cyber_matrix_circuit: {
    id: 'cyber_matrix_circuit',
    name: '⚡ Cyberpunk Quantum Substrate',
    category: 'sci_fi',
    color: '#090a0f',
    roughness: 0.28,
    metalness: 0.8,
    clearcoat: 0.8,
    clearcoatRoughness: 0.1,
    normalScale: 2.0,
    emissiveIntensity: 3.5,
    emissiveColor: '#f97316',
    repeat: [6, 6],
    description: 'Dark matte silicon wafer etched with high-density gold interconnects and pulsing high-voltage emissive traces.'
  },
  alien_bio_chitin: {
    id: 'alien_bio_chitin',
    name: '🧬 Bioluminescent Alien Carapace',
    category: 'organic',
    color: '#1e1b4b',
    roughness: 0.25,
    metalness: 0.35,
    clearcoat: 0.85,
    clearcoatRoughness: 0.2,
    normalScale: 2.4,
    emissiveIntensity: 2.2,
    emissiveColor: '#a855f7',
    repeat: [5, 5],
    description: 'Iridescent organic exoskeleton with cellular pore bump normals and subsurface bioluminescent glowing vein networks.'
  },
  polished_nero_marble: {
    id: 'polished_nero_marble',
    name: '🏛️ Polished Nero Marquina Marble',
    category: 'environment',
    color: '#0f172a',
    roughness: 0.06,
    metalness: 0.05,
    clearcoat: 1.0,
    clearcoatRoughness: 0.02,
    normalScale: 0.6,
    emissiveIntensity: 0.0,
    emissiveColor: '#000000',
    repeat: [3, 3],
    description: 'Flawless mirror-finish deep black architectural marble interlaced with fine crystalline white and golden quartz veins.'
  },
  brushed_gold_titanium: {
    id: 'brushed_gold_titanium',
    name: '✨ Anodized Imperial Brushed Gold',
    category: 'metals',
    color: '#eab308',
    roughness: 0.24,
    metalness: 0.95,
    clearcoat: 0.4,
    clearcoatRoughness: 0.2,
    normalScale: 1.6,
    emissiveIntensity: 0.0,
    emissiveColor: '#000000',
    repeat: [10, 2],
    description: 'Directionally lathed brushed titanium-gold alloy with high anisotropic highlight stretching and warm metallic luminance.'
  }
};

// ============================================================================
// PROCEDURAL 4K/2K SEAMLESS PBR TEXTURE SYNTHESIZERS
// Generates Albedo, Tangent Normal, Roughness, Metalness, AO, and Emissive Maps
// ============================================================================

/**
 * Generates Carbon Fiber Twill 2x2 PBR Maps
 */
export function generateCarbonFiberPBRMaps(size = 512): PBRTextureMaps {
  const albedoCanvas = document.createElement('canvas');
  const normalCanvas = document.createElement('canvas');
  const roughnessCanvas = document.createElement('canvas');
  const metalnessCanvas = document.createElement('canvas');

  albedoCanvas.width = albedoCanvas.height = size;
  normalCanvas.width = normalCanvas.height = size;
  roughnessCanvas.width = roughnessCanvas.height = size;
  metalnessCanvas.width = metalnessCanvas.height = size;

  const aCtx = albedoCanvas.getContext('2d')!;
  const nCtx = normalCanvas.getContext('2d')!;
  const rCtx = roughnessCanvas.getContext('2d')!;
  const mCtx = metalnessCanvas.getContext('2d')!;

  const aImg = aCtx.createImageData(size, size);
  const nImg = nCtx.createImageData(size, size);
  const rImg = rCtx.createImageData(size, size);
  const mImg = mCtx.createImageData(size, size);

  const cellSize = size / 16;

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (y * size + x) * 4;
      const u = x / cellSize;
      const v = y / cellSize;

      const cellX = Math.floor(u);
      const cellY = Math.floor(v);
      const fracX = u - cellX;
      const fracY = v - cellY;

      // 2x2 Twill weave pattern calculation
      const isHorizontal = ((cellX + cellY) % 4 === 0 || (cellX + cellY) % 4 === 1);
      const fiberT = isHorizontal ? fracX : fracY;
      const fiberCurve = Math.sin(fiberT * Math.PI);
      const threadShading = 0.5 + 0.5 * Math.cos((isHorizontal ? fracY : fracX) * Math.PI * 12);

      // Albedo
      const baseVal = 20 + Math.floor(fiberCurve * threadShading * 35);
      aImg.data[idx] = baseVal;
      aImg.data[idx + 1] = baseVal + 2;
      aImg.data[idx + 2] = baseVal + 4;
      aImg.data[idx + 3] = 255;

      // Tangent-Space Normal Map (RGB mapped from [-1,1] to [0,255])
      let nx = isHorizontal ? Math.cos(fiberT * Math.PI) * 0.7 : 0;
      let ny = isHorizontal ? 0 : Math.cos(fiberT * Math.PI) * 0.7;
      let nz = Math.sqrt(Math.max(0, 1 - nx * nx - ny * ny));

      nImg.data[idx] = Math.floor((nx * 0.5 + 0.5) * 255);
      nImg.data[idx + 1] = Math.floor((ny * 0.5 + 0.5) * 255);
      nImg.data[idx + 2] = Math.floor((nz * 0.5 + 0.5) * 255);
      nImg.data[idx + 3] = 255;

      // Roughness (Shinier on top of curves)
      const rough = Math.floor(35 + (1 - fiberCurve) * 55);
      rImg.data[idx] = rImg.data[idx + 1] = rImg.data[idx + 2] = rough;
      rImg.data[idx + 3] = 255;

      // Metalness
      mImg.data[idx] = mImg.data[idx + 1] = mImg.data[idx + 2] = 110;
      mImg.data[idx + 3] = 255;
    }
  }

  aCtx.putImageData(aImg, 0, 0);
  nCtx.putImageData(nImg, 0, 0);
  rCtx.putImageData(rImg, 0, 0);
  mCtx.putImageData(mImg, 0, 0);

  return createTextureObjects({ albedoCanvas, normalCanvas, roughnessCanvas, metalnessCanvas });
}

/**
 * Generates Weathered Sci-Fi Plating PBR Maps
 */
export function generateSciFiPlatingPBRMaps(size = 512, emissiveHex = '#06b6d4'): PBRTextureMaps {
  const albedoCanvas = document.createElement('canvas');
  const normalCanvas = document.createElement('canvas');
  const roughnessCanvas = document.createElement('canvas');
  const metalnessCanvas = document.createElement('canvas');
  const emissiveCanvas = document.createElement('canvas');

  albedoCanvas.width = albedoCanvas.height = size;
  normalCanvas.width = normalCanvas.height = size;
  roughnessCanvas.width = roughnessCanvas.height = size;
  metalnessCanvas.width = metalnessCanvas.height = size;
  emissiveCanvas.width = emissiveCanvas.height = size;

  const aCtx = albedoCanvas.getContext('2d')!;
  const nCtx = normalCanvas.getContext('2d')!;
  const rCtx = roughnessCanvas.getContext('2d')!;
  const mCtx = metalnessCanvas.getContext('2d')!;
  const eCtx = emissiveCanvas.getContext('2d')!;

  const aImg = aCtx.createImageData(size, size);
  const nImg = nCtx.createImageData(size, size);
  const rImg = rCtx.createImageData(size, size);
  const mImg = mCtx.createImageData(size, size);
  const eImg = eCtx.createImageData(size, size);

  const emCol = new THREE.Color(emissiveHex);
  const emR = Math.floor(emCol.r * 255);
  const emG = Math.floor(emCol.g * 255);
  const emB = Math.floor(emCol.b * 255);

  const panelDivs = 4;
  const pSize = size / panelDivs;

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (y * size + x) * 4;

      const px = x % pSize;
      const py = y % pSize;
      const edgeDist = Math.min(px, py, pSize - px, pSize - py);

      // Micro-noise for weathered scratches
      const noise = (Math.sin(x * 0.2) * Math.cos(y * 0.2) + Math.sin(x * 0.05 + y * 0.05)) * 12;

      // Seams and bevels
      let isSeam = edgeDist < 3;
      let isBevel = edgeDist >= 3 && edgeDist < 8;
      
      // Rivet points
      const isCorner = (px < 14 || px > pSize - 14) && (py < 14 || py > pSize - 14);
      const rivetCenterDist = Math.hypot((px < 14 ? px - 7 : px - (pSize - 7)), (py < 14 ? py - 7 : py - (pSize - 7)));
      const isRivet = rivetCenterDist < 3.5;

      // Emissive circuit trace line
      const isTrace = (px > pSize / 2 - 2 && px < pSize / 2 + 2 && py > 10 && py < pSize - 10) ||
                      (py > pSize / 2 - 2 && py < pSize / 2 + 2 && px > 10 && px < pSize - 10);

      // Albedo Color
      let val = isSeam ? 20 : (isBevel ? 45 : 75 + Math.floor(noise));
      if (isRivet) val = 140;

      aImg.data[idx] = val;
      aImg.data[idx + 1] = val + 4;
      aImg.data[idx + 2] = val + 10;
      aImg.data[idx + 3] = 255;

      // Normal Map
      let nx = 0, ny = 0, nz = 1;
      if (isBevel) {
        if (px < 8) nx = -(8 - px) / 8;
        else if (px > pSize - 8) nx = (px - (pSize - 8)) / 8;
        if (py < 8) ny = -(8 - py) / 8;
        else if (py > pSize - 8) ny = (py - (pSize - 8)) / 8;
      }
      if (isRivet) {
        const rFactor = (3.5 - rivetCenterDist) / 3.5;
        nz = Math.max(0.2, 1.0 - rFactor * 0.8);
      }
      nImg.data[idx] = Math.floor((nx * 0.5 + 0.5) * 255);
      nImg.data[idx + 1] = Math.floor((ny * 0.5 + 0.5) * 255);
      nImg.data[idx + 2] = Math.floor((nz * 0.5 + 0.5) * 255);
      nImg.data[idx + 3] = 255;

      // Roughness
      rImg.data[idx] = rImg.data[idx + 1] = rImg.data[idx + 2] = isSeam ? 220 : (isRivet ? 40 : 80 + Math.floor(Math.random() * 25));
      rImg.data[idx + 3] = 255;

      // Metalness
      mImg.data[idx] = mImg.data[idx + 1] = mImg.data[idx + 2] = isSeam ? 50 : 235;
      mImg.data[idx + 3] = 255;

      // Emissive Map
      if (isTrace) {
        eImg.data[idx] = emR;
        eImg.data[idx + 1] = emG;
        eImg.data[idx + 2] = emB;
        eImg.data[idx + 3] = 255;
      } else {
        eImg.data[idx] = eImg.data[idx + 1] = eImg.data[idx + 2] = 0;
        eImg.data[idx + 3] = 255;
      }
    }
  }

  aCtx.putImageData(aImg, 0, 0);
  nCtx.putImageData(nImg, 0, 0);
  rCtx.putImageData(rImg, 0, 0);
  mCtx.putImageData(mImg, 0, 0);
  eCtx.putImageData(eImg, 0, 0);

  return createTextureObjects({ albedoCanvas, normalCanvas, roughnessCanvas, metalnessCanvas, emissiveCanvas });
}

/**
 * Generates Wet Asphalt & Rain Puddles PBR Maps
 */
export function generateWetAsphaltPBRMaps(size = 512): PBRTextureMaps {
  const albedoCanvas = document.createElement('canvas');
  const normalCanvas = document.createElement('canvas');
  const roughnessCanvas = document.createElement('canvas');
  const metalnessCanvas = document.createElement('canvas');

  albedoCanvas.width = albedoCanvas.height = size;
  normalCanvas.width = normalCanvas.height = size;
  roughnessCanvas.width = roughnessCanvas.height = size;
  metalnessCanvas.width = metalnessCanvas.height = size;

  const aCtx = albedoCanvas.getContext('2d')!;
  const nCtx = normalCanvas.getContext('2d')!;
  const rCtx = roughnessCanvas.getContext('2d')!;
  const mCtx = metalnessCanvas.getContext('2d')!;

  const aImg = aCtx.createImageData(size, size);
  const nImg = nCtx.createImageData(size, size);
  const rImg = rCtx.createImageData(size, size);
  const mImg = mCtx.createImageData(size, size);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const idx = (y * size + x) * 4;

      // Multi-octave asphalt noise for aggregate gravel
      const n1 = Math.sin(x * 0.8) * Math.cos(y * 0.8);
      const n2 = Math.sin(x * 2.5 + y * 1.7) * 0.5;
      const gravel = (n1 + n2) * 20;

      // Puddle mask (smooth, shiny wet spots)
      const puddleNoise = Math.sin(x * 0.03) * Math.cos(y * 0.03) + Math.sin((x + y) * 0.02) * 0.5;
      const isPuddle = puddleNoise > 0.45;

      const baseVal = isPuddle ? 15 : 35 + Math.floor(gravel);

      aImg.data[idx] = baseVal;
      aImg.data[idx + 1] = baseVal;
      aImg.data[idx + 2] = baseVal + 2;
      aImg.data[idx + 3] = 255;

      // Normal Map (Puddle is flat mirror, gravel is rough)
      const nx = isPuddle ? 0 : (Math.sin(x * 1.5) * 0.4);
      const ny = isPuddle ? 0 : (Math.cos(y * 1.5) * 0.4);
      const nz = Math.sqrt(Math.max(0.1, 1 - nx * nx - ny * ny));

      nImg.data[idx] = Math.floor((nx * 0.5 + 0.5) * 255);
      nImg.data[idx + 1] = Math.floor((ny * 0.5 + 0.5) * 255);
      nImg.data[idx + 2] = Math.floor((nz * 0.5 + 0.5) * 255);
      nImg.data[idx + 3] = 255;

      // Roughness (Wet puddle = 0.05, dry gravel = 0.85)
      const rVal = isPuddle ? 12 : 210;
      rImg.data[idx] = rImg.data[idx + 1] = rImg.data[idx + 2] = rVal;
      rImg.data[idx + 3] = 255;

      // Metalness
      mImg.data[idx] = mImg.data[idx + 1] = mImg.data[idx + 2] = 20;
      mImg.data[idx + 3] = 255;
    }
  }

  aCtx.putImageData(aImg, 0, 0);
  nCtx.putImageData(nImg, 0, 0);
  rCtx.putImageData(rImg, 0, 0);
  mCtx.putImageData(mImg, 0, 0);

  return createTextureObjects({ albedoCanvas, normalCanvas, roughnessCanvas, metalnessCanvas });
}

/**
 * Creates Three.js Texture instances with appropriate color spaces and anisotropic filtering
 */
function createTextureObjects(canvases: {
  albedoCanvas: HTMLCanvasElement;
  normalCanvas: HTMLCanvasElement;
  roughnessCanvas: HTMLCanvasElement;
  metalnessCanvas: HTMLCanvasElement;
  emissiveCanvas?: HTMLCanvasElement;
}): PBRTextureMaps {
  const albedo = new THREE.CanvasTexture(canvases.albedoCanvas);
  albedo.colorSpace = THREE.SRGBColorSpace;
  albedo.wrapS = albedo.wrapT = THREE.RepeatWrapping;

  const normal = new THREE.CanvasTexture(canvases.normalCanvas);
  normal.wrapS = normal.wrapT = THREE.RepeatWrapping;

  const roughness = new THREE.CanvasTexture(canvases.roughnessCanvas);
  roughness.wrapS = roughness.wrapT = THREE.RepeatWrapping;

  const metalness = new THREE.CanvasTexture(canvases.metalnessCanvas);
  metalness.wrapS = metalness.wrapT = THREE.RepeatWrapping;

  let emissive: THREE.CanvasTexture | undefined;
  if (canvases.emissiveCanvas) {
    emissive = new THREE.CanvasTexture(canvases.emissiveCanvas);
    emissive.colorSpace = THREE.SRGBColorSpace;
    emissive.wrapS = emissive.wrapT = THREE.RepeatWrapping;
  }

  return { albedo, normal, roughness, metalness, emissive };
}

/**
 * Builds a state-of-the-art THREE.MeshPhysicalMaterial from preset configuration
 */
export function createUltraPBRMaterial(presetKey: string, customOptions?: Partial<PBRMaterialPreset>): THREE.MeshPhysicalMaterial {
  const preset = { ...(PBR_MATERIAL_PRESETS[presetKey] || PBR_MATERIAL_PRESETS.carbon_fiber_twill), ...customOptions };

  let maps: PBRTextureMaps;
  if (preset.id === 'weathered_sci_fi_plating' || preset.id === 'cyber_matrix_circuit') {
    maps = generateSciFiPlatingPBRMaps(512, preset.emissiveColor);
  } else if (preset.id === 'wet_asphalt_pavement') {
    maps = generateWetAsphaltPBRMaps(512);
  } else {
    maps = generateCarbonFiberPBRMaps(512);
  }

  const [repX, repY] = preset.repeat;
  [maps.albedo, maps.normal, maps.roughness, maps.metalness].forEach(t => {
    if (t) t.repeat.set(repX, repY);
  });
  if (maps.emissive) maps.emissive.repeat.set(repX, repY);

  const mat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(preset.color),
    map: maps.albedo,
    normalMap: maps.normal,
    normalScale: new THREE.Vector2(preset.normalScale, preset.normalScale),
    roughness: preset.roughness,
    roughnessMap: maps.roughness,
    metalness: preset.metalness,
    metalnessMap: maps.metalness,
    clearcoat: preset.clearcoat,
    clearcoatRoughness: preset.clearcoatRoughness,
    emissive: new THREE.Color(preset.emissiveColor),
    emissiveIntensity: preset.emissiveIntensity,
    emissiveMap: maps.emissive || null,
    reflectivity: 0.95,
    envMapIntensity: 2.5
  });

  return mat;
}

/**
 * Loads a user-provided image URL or Base64 data texture
 */
export function loadCustomPBRTexture(url: string, isColorMap = true): Promise<THREE.Texture> {
  return new Promise((resolve, reject) => {
    const loader = new THREE.TextureLoader();
    loader.load(
      url,
      (texture) => {
        texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
        if (isColorMap) {
          texture.colorSpace = THREE.SRGBColorSpace;
        }
        resolve(texture);
      },
      undefined,
      (err) => reject(err)
    );
  });
}
