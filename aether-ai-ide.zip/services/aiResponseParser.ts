import { sanitizeAndRepairCode } from './fileService';

export interface SimpleAIResponse {
  thoughts?: string;
  message: string;
  reasoningSteps?: { step: string; status: string }[];
  files?: {
    operation: 'create' | 'update' | 'delete';
    path: string;
    code: string;
  }[];
  commands?: string[];
  groundingLinks?: { uri: string; title: string }[];
  customModels?: {
    id: string;
    name: string;
    description: string;
    systemInstruction: string;
    temperature?: number;
  }[];
}

/**
 * Robust scanner to recover code files even when JSON output hits token limits mid-string or mid-file.
 */
function extractPartialJSONFiles(jsonString: string): { operation: 'create' | 'update' | 'delete'; path: string; code: string }[] {
  const files: { operation: 'create' | 'update' | 'delete'; path: string; code: string }[] = [];
  
  // Match file objects by operation, path, and code start
  const pattern = /\{\s*"operation"\s*:\s*"([^"]+)"\s*,\s*"path"\s*:\s*"([^"]+)"\s*,\s*"code"\s*:\s*"/g;
  let match;
  
  while ((match = pattern.exec(jsonString)) !== null) {
    let operation: 'create' | 'update' | 'delete' = 'update';
    const rawOp = (match[1] || '').toLowerCase();
    if (rawOp === 'delete') {
      operation = 'delete';
    } else if (rawOp === 'create') {
      operation = 'create';
    } else {
      // 'update', 'surgical_edit', 'patch', 'edit', 'modify'
      operation = 'update';
    }
    const path = match[2];
    const codeStartIndex = match.index + match[0].length;
    
    let codeEndIndex = -1;
    let isEscaped = false;
    for (let i = codeStartIndex; i < jsonString.length; i++) {
      const char = jsonString[i];
      if (isEscaped) {
        isEscaped = false;
        continue;
      }
      if (char === '\\') {
        isEscaped = true;
        continue;
      }
      if (char === '"') {
        codeEndIndex = i;
        break;
      }
    }
    
    let rawCode = "";
    if (codeEndIndex !== -1) {
      rawCode = jsonString.slice(codeStartIndex, codeEndIndex);
    } else {
      // String was truncated mid-file by max output token limit
      rawCode = jsonString.slice(codeStartIndex);
    }
    
    const code = rawCode
      .replace(/\\n/g, '\n')
      .replace(/\\t/g, '\t')
      .replace(/\\r/g, '\r')
      .replace(/\\"/g, '"')
      .replace(/\\\\/g, '\\');
      
    if (path && (code || operation === 'delete')) {
      files.push({ operation, path, code });
    }
  }
  
  return files;
}

export const parseAIResponse = (text: string, accumulatedThoughts = ""): SimpleAIResponse => {
  let parsed: any = null;

  // 1. Extract any <think> or <thought> tags
  let extractedThink = "";
  const thinkMatch = text.match(/<(?:think|thought|reasoning|reasoning_content)>([\s\S]*?)(?:<\/(?:think|thought|reasoning|reasoning_content)>|$)/i);
  if (thinkMatch && thinkMatch[1]) {
    extractedThink = thinkMatch[1].trim();
    text = text.replace(/<(?:think|thought|reasoning|reasoning_content)>[\s\S]*?(?:<\/(?:think|thought|reasoning|reasoning_content)>|$)/gi, '').trim();
  }

  // 2. Separate preamble before '{'
  let clean = text.replace(/```json/gi, '').replace(/```/g, '').trim();
  const firstBraceIdx = clean.indexOf('{');
  let preambleText = "";
  let jsonCandidate = clean;

  if (firstBraceIdx > 0) {
    preambleText = clean.slice(0, firstBraceIdx).trim();
    jsonCandidate = clean.slice(firstBraceIdx).trim();
  }

  // 3. Direct or repaired JSON parsing
  try {
    parsed = JSON.parse(jsonCandidate);
  } catch (e1) {
    const lastBraceIdx = jsonCandidate.lastIndexOf('}');
    if (lastBraceIdx > 0) {
      try {
        parsed = JSON.parse(jsonCandidate.slice(0, lastBraceIdx + 1));
      } catch (e2) {}
    }

    if (!parsed) {
      const repairSuffixes = ['}', '"}', ']}', '"]}', '"]}]}', '"}]}', '"}]}}'];
      for (const suffix of repairSuffixes) {
        try {
          parsed = JSON.parse(jsonCandidate + suffix);
          if (parsed) break;
        } catch {}
      }
    }

    if (!parsed) {
      let extractedMsg = preambleText;
      const msgMatch = jsonCandidate.match(/"message"\s*:\s*"((?:[^"\\]|\\.)*)/);
      if (msgMatch && msgMatch[1]) {
        extractedMsg = msgMatch[1].replace(/\\n/g, '\n').replace(/\\"/g, '"').replace(/\\\\/g, '\\');
      }

      let extractedThoughtsFromRegex = "";
      const thoughtsMatch = jsonCandidate.match(/"thoughts"\s*:\s*"((?:[^"\\]|\\.)*)/);
      if (thoughtsMatch && thoughtsMatch[1]) {
        extractedThoughtsFromRegex = thoughtsMatch[1].replace(/\\n/g, '\n').replace(/\\"/g, '"').replace(/\\\\/g, '\\');
      }

      const files = extractPartialJSONFiles(jsonCandidate);
      if (files.length === 0) {
        const fileRegex = /"operation"\s*:\s*"([^"]+)",\s*"path"\s*:\s*"([^"]+)",\s*"code"\s*:\s*"([\s\S]*?)(?:"\s*\}|"$|\}\s*,|\}\s*\])/g;
        let match;
        while ((match = fileRegex.exec(jsonCandidate)) !== null) {
          const rawOp = (match[1] || '').toLowerCase();
          const op: 'create' | 'update' | 'delete' = rawOp === 'delete' ? 'delete' : rawOp === 'create' ? 'create' : 'update';
          files.push({
            operation: op,
            path: match[2],
            code: match[3].replace(/\\n/g, '\n').replace(/\\"/g, '"').replace(/\\\\/g, '\\')
          });
        }
      }

      parsed = {
        message: extractedMsg || preambleText || (clean.startsWith("Error:") || clean.includes("error") ? clean : "I have updated your application code and components."),
        thoughts: extractedThoughtsFromRegex,
        files: files
      };
    }
  }

  if (!parsed) {
    parsed = { message: preambleText || clean || "I have updated your application code and components.", files: [] };
  }

  if (!Array.isArray(parsed.files)) {
    parsed.files = [];
  }

  if (parsed.message && (parsed.message.includes('{"thoughts"') || parsed.message.includes('{ "thoughts"'))) {
    const bracePos = parsed.message.indexOf('{');
    if (bracePos !== -1) {
      const cleanMsg = parsed.message.slice(0, bracePos).trim();
      parsed.message = cleanMsg.length > 5 ? cleanMsg : "I have updated your application code and components.";
    }
  }

  if (!parsed.message && preambleText) {
    parsed.message = preambleText;
  }

  if (parsed.files.length === 0) {
    const sourceTextToSearch = (parsed.message || "") + "\n\n" + text;
    const extractedFiles: { operation: 'create' | 'update' | 'delete'; path: string; code: string }[] = [];

    const blockRegex = /(?:###?\s*[`"']?([a-zA-Z0-9_\-./]+\.[a-zA-Z0-9]+)[`"']?\s*\n+)?```(?:(\w+)(?:[:\s]+(?:file|filename|path)?[:\s=]*([a-zA-Z0-9_\-./]+\.[a-zA-Z0-9]+))?)?\r?\n([\s\S]*?)```/gi;
    let blockMatch;

    while ((blockMatch = blockRegex.exec(sourceTextToSearch)) !== null) {
      const headerPath = blockMatch[1];
      const lang = (blockMatch[2] || "").toLowerCase();
      const inlinePath = blockMatch[3];
      const rawCode = blockMatch[4]?.trim();

      if (!rawCode || rawCode.length < 5) continue;
      if (lang === 'json' && (rawCode.startsWith('{\n  "thoughts"') || rawCode.startsWith('{\n  "message"'))) continue;

      let detectedPath = headerPath || inlinePath || "";

      if (!detectedPath) {
        const commentMatch = rawCode.match(/(?:\/\/\s*|\/\*\s*|<!--\s*|#\s*)(?:file|filename|path)?[:\s=]*([a-zA-Z0-9_\-./]+\.[a-zA-Z0-9]+)/i);
        if (commentMatch && commentMatch[1]) {
          detectedPath = commentMatch[1].trim();
        }
      }

      if (!detectedPath) {
        if (lang === 'html' || rawCode.includes('<!DOCTYPE html') || rawCode.includes('<html') || rawCode.includes('<head>')) {
          detectedPath = 'index.html';
        } else if (lang === 'css' || rawCode.includes('@keyframes') || (rawCode.includes('{') && rawCode.includes(':') && (rawCode.includes('margin') || rawCode.includes('padding') || rawCode.includes('color') || rawCode.includes('background')))) {
          detectedPath = 'style.css';
        } else if (lang === 'tsx' || lang === 'jsx' || rawCode.includes('import React') || rawCode.includes('export default function App')) {
          detectedPath = 'src/App.tsx';
        } else if (lang === 'js' || lang === 'javascript' || lang === 'ts' || lang === 'typescript') {
          detectedPath = 'script.js';
        } else if (lang === 'python' || lang === 'py') {
          detectedPath = 'main.py';
        } else if (lang === 'rust' || lang === 'rs') {
          detectedPath = 'main.rs';
        }
      }

      if (detectedPath) {
        const existing = extractedFiles.find(f => f.path === detectedPath);
        if (existing) {
          existing.code = rawCode;
        } else {
          extractedFiles.push({
            operation: 'update',
            path: detectedPath,
            code: rawCode
          });
        }
      }
    }

    if (extractedFiles.length > 0) {
      parsed.files = extractedFiles;
      if (parsed.message && parsed.message.includes('```')) {
        const introMsg = parsed.message.split('```')[0].trim();
        if (introMsg.length > 10) {
          parsed.message = introMsg + `\n\nUpdated ${extractedFiles.map(f => `\`${f.path}\``).join(', ')} directly in your workspace.`;
        } else {
          parsed.message = `Applied updates to ${extractedFiles.map(f => `\`${f.path}\``).join(', ')} directly in your workspace.`;
        }
      }
    }
  }

  if (parsed.files && Array.isArray(parsed.files)) {
    parsed.files = parsed.files.map((f: any) => ({
      ...f,
      code: sanitizeAndRepairCode(f.code || '', f.path || '')
    }));
  }

  const finalThoughts = [parsed.thoughts, accumulatedThoughts, extractedThink]
    .filter(Boolean)
    .filter((t, idx, arr) => arr.indexOf(t) === idx)
    .join("\n\n");

  if (finalThoughts) {
    parsed.thoughts = finalThoughts;
  }

  return parsed;
};
