import { FileNode, Snapshot } from '../types';
import { DEFAULT_FILES } from '../constants';
import JSZip from 'jszip';
import Babel from '@babel/standalone';
import { syncAppStateToDrive, loadAppStateFromDrive } from './workspaceService';
import { auth } from './firebase';
import { storageService } from './storageService';
import { opfsService } from './opfsService';

export const getFiles = async (projectId: string): Promise<FileNode[]> => {
  if (!projectId) return [];

  // 1. Try modern OPFS Cache first for extreme performance & offline-resilience
  try {
    const opfsFiles = await opfsService.loadFromOPFSCache(projectId);
    if (opfsFiles && opfsFiles.length > 0) {
      console.log(`[OPFS] Recovered ${opfsFiles.length} files from private cache`);
      return opfsFiles;
    }
  } catch (e) {
    console.warn('[OPFS] Cache retrieval failed, falling back to db layers', e);
  }
  
  // 2. Try Express API
  try {
     const response = await fetch(`/api/sessions/${projectId}`);
     if (response.ok) {
        const data = await response.json();
        if (data.files && data.files.length > 0) {
          // Warm up OPFS cache in the background
          opfsService.saveToOPFSCache(projectId, data.files).catch(console.error);
          return data.files;
        }
     }
  } catch (e) {}

  // 3. Use consolidated storageService (Dexie)
  const stored = await storageService.getFilesForSession(projectId);
  if (stored && stored.length > 0) {
    const files = stored.map(f => ({
      id: f.id!,
      name: f.name,
      content: f.content,
      language: f.language,
      lastModified: f.updatedAt,
      isBinary: (f as any).isBinary
    }));
    // Warm up OPFS cache in the background
    opfsService.saveToOPFSCache(projectId, files).catch(console.error);
    return files;
  }

  // 4. Fallback to Cloud Firestore
  try {
    const { firestoreService } = await import('./firestoreService');
    const cloudFiles = await firestoreService.getFiles(projectId);
    if (cloudFiles && cloudFiles.length > 0) {
      // Cache them locally for offline speed
      await storageService.saveFiles(projectId, cloudFiles);
      opfsService.saveToOPFSCache(projectId, cloudFiles).catch(console.error);
      return cloudFiles;
    }
  } catch (e) {
    console.error("Firestore getFiles fallback failed:", e);
  }
  
  return []; // Return empty array instead of fallback to DEFAULT_FILES
};

export const getDefaultTemplate = (projectId: string): FileNode[] => {
  return DEFAULT_FILES.map(f => ({
    ...f,
    id: `${f.id}_${projectId}_${Date.now()}`,
    lastModified: Date.now()
  }));
};

export const saveFullSession = async (sessions: any[], files: FileNode[]): Promise<void> => {
    // 1. Save to local Server Workspace first (so terminal / compilers can run on it)
    try {
        const activeSession = sessions[0]; // Or we find the active session
        if (activeSession) {
            await fetch('/api/sessions/save', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ session: activeSession, files })
            });
        }
    } catch (e) {
        console.error("Failed to save session to Server Workspace", e);
    }

    // 2. Google Drive Sync
    try {
        await syncAppStateToDrive({ sessions, files });
    } catch (e) {
        console.error("Failed to backup to Google Drive", e);
    }
};

export const getRemoteSessions = async (): Promise<any[]> => {
    try {
        const data = await loadAppStateFromDrive();
        if (data && data.session) {
            return [data.session];
        } else if (data && data.sessions) {
            return data.sessions;
        }
    } catch (e) {
        console.error("Google Drive Session List failed", e);
    }
    return [];
};

export const saveFile = async (projectId: string, file: FileNode): Promise<void> => {
  if (!projectId) return;
  await storageService.saveFile(projectId, file);

  if (auth.currentUser) {
    try {
      const { firestoreService } = await import('./firestoreService');
      await firestoreService.saveFile(projectId, file);
    } catch (e) {
      console.error("Firestore saveFile failed:", e);
    }
  }
};

export const saveFiles = async (projectId: string, files: FileNode[]): Promise<void> => {
  if (!projectId || !files.length) return;
  await storageService.saveFiles(projectId, files);

  if (auth.currentUser) {
    try {
      const { firestoreService } = await import('./firestoreService');
      await firestoreService.saveFiles(projectId, files);
    } catch (e) {
      console.error("Firestore saveFiles failed:", e);
    }
  }
};

export const deleteFile = async (projectId: string, fileId: string): Promise<void> => {
  if (!projectId) return;
  await storageService.deleteFile(fileId);

  if (auth.currentUser) {
    try {
      const { firestoreService } = await import('./firestoreService');
      await firestoreService.deleteFile(projectId, fileId);
    } catch (e) {
      console.error("Firestore deleteFile failed:", e);
    }
  }
};

const readFileContent = (file: File): Promise<{ content: string, isBinary: boolean }> => {
  return new Promise((resolve) => {
    const isBinary = file.type.startsWith('image/') || file.name.endsWith('.glb') || file.name.endsWith('.obj') || file.name.endsWith('.png') || file.name.endsWith('.jpg') || file.name.endsWith('.jpeg') || file.name.endsWith('.webp') || file.name.endsWith('.gif') || file.name.endsWith('.ico') || file.name.endsWith('.mp3') || file.name.endsWith('.wav');
    const reader = new FileReader();
    reader.onload = (e) => {
      resolve({ content: e.target?.result as string, isBinary });
    };
    if (isBinary) reader.readAsDataURL(file);
    else reader.readAsText(file);
  });
};

export const processUploadedFiles = async (projectIdOrFiles: string | FileList | File[], optionalFiles?: FileList | File[]): Promise<FileNode[]> => {
  let projectId = "";
  let files: FileList | File[] = [];

  if (typeof projectIdOrFiles === "string") {
    projectId = projectIdOrFiles;
    files = optionalFiles || [];
  } else {
    files = projectIdOrFiles;
  }
  const newFiles: FileNode[] = [];
  const fileArray = Array.from(files);

  for (const file of fileArray) {
    if (file.name.toLowerCase().endsWith('.zip')) {
      try {
        const zip = new JSZip();
        const zipContent = await zip.loadAsync(file);
        for (const [relativePath, zipEntry] of Object.entries(zipContent.files)) {
          if (!zipEntry.dir) {
            const ext = relativePath.split('.').pop()?.toLowerCase() || 'txt';
            const isBin = ['png', 'jpg', 'jpeg', 'webp', 'gif', 'svg', 'glb', 'obj', 'mp3', 'wav', 'ico'].includes(ext);
            let content = '';
            if (isBin) {
              const base64 = await zipEntry.async('base64');
              const mime = ext === 'svg' ? 'image/svg+xml' : `image/${ext}`;
              content = `data:${mime};base64,${base64}`;
            } else {
              content = await zipEntry.async('string');
            }
            const lang = isBin ? 'image' : (['js', 'ts', 'tsx', 'jsx'].includes(ext) ? 'typescript' : (['html', 'css', 'json', 'py', 'rs'].includes(ext) ? ext : 'plaintext'));
            newFiles.push({
              id: `f_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
              name: relativePath.replace(/^\//, ''),
              content,
              language: lang,
              lastModified: Date.now(),
              isBinary: isBin
            });
          }
        }
      } catch (err) {
        console.error("Failed to unpack zip file:", err);
      }
    } else {
      const { content, isBinary } = await readFileContent(file);
      const filePath = (file as any).webkitRelativePath || file.name;
      const cleanPath = filePath.replace(/^\//, '');
      const ext = cleanPath.split('.').pop()?.toLowerCase() || 'txt';
      const lang = isBinary ? 'image' : (['js', 'ts', 'tsx', 'jsx'].includes(ext) ? 'typescript' : (['html', 'css', 'json', 'py', 'rs'].includes(ext) ? ext : 'plaintext'));

      newFiles.push({
        id: `f_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        name: cleanPath,
        content,
        language: lang,
        lastModified: Date.now(),
        isBinary
      });
    }
  }

  if (projectId && newFiles.length > 0) {
    for (const f of newFiles) {
      await saveFile(projectId, f);
    }
    return getFiles(projectId);
  }
  return newFiles;
};

export const processDroppedFiles = async (projectId: string, items: DataTransferItemList): Promise<FileNode[]> => {
    const newFiles: FileNode[] = [];
    const traverseFileTree = async (item: any, path: string = '') => {
        if (item.isFile) {
            const file = await new Promise<File>((resolve) => item.file(resolve));
            if (file.name.toLowerCase().endsWith('.zip')) {
              const zipFiles = await processUploadedFiles(projectId, [file]);
              newFiles.push(...zipFiles);
              return;
            }
            const { content, isBinary } = await readFileContent(file);
            const ext = file.name.split('.').pop()?.toLowerCase() || 'txt';
            let lang = isBinary ? 'image' : (['js', 'ts', 'tsx'].includes(ext) ? 'javascript' : ext);
            
            newFiles.push({
                id: `f_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                name: path + file.name,
                content,
                language: lang,
                lastModified: Date.now(),
                isBinary
            });
        } else if (item.isDirectory) {
            const dirReader = item.createReader();
            const entries = await new Promise<any[]>((resolve) => dirReader.readEntries(resolve));
            for (const entry of entries) {
                await traverseFileTree(entry, path + item.name + '/');
            }
        }
    };

    for (let i = 0; i < items.length; i++) {
        const item = items[i].webkitGetAsEntry();
        if (item) await traverseFileTree(item);
    }

    if (projectId && newFiles.length > 0) {
        for (const f of newFiles) {
            await saveFile(projectId, f);
        }
        return getFiles(projectId);
    }
    return newFiles;
};

export const takeSnapshot = async (projectId: string, description: string): Promise<Snapshot> => {
  const files = await getFiles(projectId);
  const snapshot: Snapshot = {
    id: `snap_${Date.now()}`,
    timestamp: Date.now(),
    description,
    files: JSON.parse(JSON.stringify(files))
  };
  
  // Snapshots could be stored in a separate table in Dexie if needed
  // For now, let's just keep it in memory or simple LS if preferred
  const snapshotsKey = `aether_project_${projectId}_snapshots`;
  const stored = localStorage.getItem(snapshotsKey);
  const snapshots = stored ? JSON.parse(stored) : [];
  const newSnapshots = [snapshot, ...snapshots].slice(0, 10);
  localStorage.setItem(snapshotsKey, JSON.stringify(newSnapshots));
  
  return snapshot;
};

// --- Code Sanitization & Auto-Repair Engine ---
export const sanitizeAndRepairCode = (content: string, filename: string): string => {
  if (!content || typeof content !== 'string') return '';

  let cleaned = content.trim();

  // If the content is a diff or contains search/replace hunks, do NOT run auto-bracket repair or destructive trimming
  const isDiff = /<{3,7}\s*(?:SEARCH|ORIGINAL|HEAD)|@@\s*-\d+|={3,7}[^\n\r]*\r?\n|>{3,7}\s*(?:REPLACE|UPDATED|END)/i.test(cleaned);
  if (isDiff) {
    if (cleaned.startsWith('```')) {
      cleaned = cleaned.replace(/^```[a-zA-Z0-9_\-]*\r?\n/, '');
      if (cleaned.endsWith('```')) {
        cleaned = cleaned.slice(0, -3).trimEnd();
      }
    }
    return cleaned;
  }

  // 1. Strip accidental wrapping markdown code blocks if the LLM embedded them inside the JSON field
  if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```[a-zA-Z0-9_\-]*\r?\n/, '');
    if (cleaned.endsWith('```')) {
      cleaned = cleaned.slice(0, -3).trimEnd();
    }
  }

  // 2. Strip accidental conversational preamble / postamble outside diff or code blocks
  if (filename.endsWith('.js') || filename.endsWith('.ts') || filename.endsWith('.tsx') || filename.endsWith('.jsx')) {
    // If the file starts with non-code conversational text like "Here is the updated script.js:\nconst..."
    const conversationalStart = cleaned.match(/^(?:Here is (?:the|your)|Sure,? I have|Below is the|I updated the|Here's the|Updated code:)[^\n]*\n+/i);
    if (conversationalStart) {
      cleaned = cleaned.slice(conversationalStart[0].length).trimStart();
    }
  } else if (filename.endsWith('.html')) {
    // Ensure HTML starts with <!DOCTYPE or <html or a clean element tag
    const docTypeIdx = cleaned.indexOf('<!DOCTYPE');
    const htmlIdx = cleaned.indexOf('<html');
    const firstTagIdx = docTypeIdx !== -1 ? docTypeIdx : htmlIdx;
    if (firstTagIdx > 0) {
      cleaned = cleaned.slice(firstTagIdx).trimStart();
    }
  }

  // 3. Auto-heal common syntax issues (unclosed template literals, unclosed brackets at end of truncated code)
  if (filename.endsWith('.js') || filename.endsWith('.ts') || filename.endsWith('.tsx') || filename.endsWith('.jsx')) {
    // Check if open template literals are unclosed
    const backtickCount = (cleaned.match(/(?<!\\)`/g) || []).length;
    if (backtickCount % 2 !== 0) {
      cleaned += '`;';
    }

    // Check bracket balance at end of file
    let openCurly = 0;
    let openParen = 0;
    let openSquare = 0;
    let inString: string | null = null;

    for (let i = 0; i < cleaned.length; i++) {
      const char = cleaned[i];
      const prev = i > 0 ? cleaned[i - 1] : '';

      if (inString) {
        if (char === inString && prev !== '\\') {
          inString = null;
        }
      } else {
        if ((char === '"' || char === "'" || char === '`') && prev !== '\\') {
          inString = char;
        } else if (char === '{') openCurly++;
        else if (char === '}') openCurly = Math.max(0, openCurly - 1);
        else if (char === '(') openParen++;
        else if (char === ')') openParen = Math.max(0, openParen - 1);
        else if (char === '[') openSquare++;
        else if (char === ']') openSquare = Math.max(0, openSquare - 1);
      }
    }

    if (inString) {
      cleaned += inString + ';';
    }

    if (openSquare > 0) cleaned += ']'.repeat(openSquare);
    if (openParen > 0) cleaned += ')'.repeat(openParen);
    if (openCurly > 0) cleaned += '\n' + '}'.repeat(openCurly);
  }

  return cleaned;
};

export interface SurgicalHunk {
  id: string;
  searchBlock: string;
  replaceBlock: string;
  startLineApprox?: number;
  matchedIndex?: number;
  status?: 'pending' | 'applied' | 'failed';
  diffStats?: {
    added: number;
    removed: number;
  };
}

export interface SurgicalEditResult {
  content: string;
  appliedCount: number;
  totalHunks: number;
  hunks: SurgicalHunk[];
  isSurgical: boolean;
  summary: string;
}

/**
 * Extracts surgical hunks from patch content. Supports:
 * 1. Standard <<<<<<< SEARCH ... ======= ... >>>>>>> REPLACE (3-7 angle brackets)
 * 2. <<<<<<< ORIGINAL ... ======= ... >>>>>>> UPDATED
 * 3. <<<<<<< HEAD ... ======= ... >>>>>>>
 * 4. Unified diff blocks (@@ -start,len +start,len @@)
 */
export const extractSurgicalHunks = (patchContent: string): SurgicalHunk[] => {
  if (!patchContent) return [];
  const hunks: SurgicalHunk[] = [];

  // Pattern 1: Search & Replace blocks (flexible angle brackets, optional trailing spaces/comments)
  const searchReplaceRegex = /<{3,7}\s*(?:SEARCH|ORIGINAL|HEAD)[^\n\r]*\r?\n([\s\S]*?)\r?\n={3,7}[^\n\r]*\r?\n([\s\S]*?)\r?\n>{3,7}\s*(?:REPLACE|UPDATED|END)?/gi;
  let match: RegExpExecArray | null;
  let hunkIndex = 0;

  while ((match = searchReplaceRegex.exec(patchContent)) !== null) {
    const searchBlock = match[1];
    const replaceBlock = match[2];
    const removedCount = searchBlock ? searchBlock.split('\n').length : 0;
    const addedCount = replaceBlock ? replaceBlock.split('\n').length : 0;

    hunks.push({
      id: `hunk-${Date.now()}-${hunkIndex++}`,
      searchBlock,
      replaceBlock,
      status: 'pending',
      diffStats: {
        added: addedCount,
        removed: removedCount
      }
    });
  }

  // Pattern 2: Unified diff hunks (e.g. @@ -10,4 +10,5 @@ ...)
  if (hunks.length === 0 && patchContent.includes('@@')) {
    const unifiedRegex = /@@\s*-\d+(?:,\d+)?\s+\+\d+(?:,\d+)?\s*@@[^\n\r]*\r?\n([\s\S]*?)(?=@@|\s*$)/g;
    let uMatch: RegExpExecArray | null;

    while ((uMatch = unifiedRegex.exec(patchContent)) !== null) {
      const chunk = uMatch[1];
      const lines = chunk.split(/\r?\n/);
      const searchLines: string[] = [];
      const replaceLines: string[] = [];

      for (const line of lines) {
        if (line.startsWith('-')) {
          searchLines.push(line.slice(1));
        } else if (line.startsWith('+')) {
          replaceLines.push(line.slice(1));
        } else if (line.startsWith(' ')) {
          searchLines.push(line.slice(1));
          replaceLines.push(line.slice(1));
        }
      }

      if (searchLines.length > 0 || replaceLines.length > 0) {
        hunks.push({
          id: `hunk-${Date.now()}-${hunkIndex++}`,
          searchBlock: searchLines.join('\n'),
          replaceBlock: replaceLines.join('\n'),
          status: 'pending',
          diffStats: {
            added: replaceLines.length,
            removed: searchLines.length
          }
        });
      }
    }
  }

  return hunks;
};

// Helper: Normalize tokens (normalize quotes, strip extra whitespace, normalize semicolons)
const normalizeTokens = (str: string): string => {
  return str
    .replace(/["'`]/g, '"')
    .replace(/;\s*$/g, '')
    .replace(/\s+/g, ' ')
    .trim();
};

/**
 * Applies a single surgical hunk to a file content using multi-tier matching:
 * Level 1: Exact substring match
 * Level 2: Line ending normalization (\r\n vs \n)
 * Level 3: Fuzzy line-by-line trimmed matching with smart indentation preservation
 * Level 3.5: Token-normalized line matching (ignoring quote style, semicolons, extra spacing)
 * Level 3.8: Single-character / single-line partial substring locator
 * Level 4: Anchor matching (first and last non-empty lines with context)
 * Level 5: Substring sequence matching with adaptive indentation
 */
export const applySurgicalHunk = (
  content: string, 
  hunk: SurgicalHunk
): { newContent: string; success: boolean } => {
  const { searchBlock, replaceBlock } = hunk;

  if (!searchBlock && replaceBlock) {
    // Pure insertion / append
    return { newContent: content + '\n' + replaceBlock, success: true };
  }

  // Level 1: Exact substring match
  if (content.includes(searchBlock)) {
    return {
      newContent: content.replace(searchBlock, replaceBlock),
      success: true
    };
  }

  // Level 2: Line ending normalization
  const normContent = content.replace(/\r\n/g, '\n');
  const normSearch = searchBlock.replace(/\r\n/g, '\n');
  const normReplace = replaceBlock.replace(/\r\n/g, '\n');

  if (normContent.includes(normSearch)) {
    return {
      newContent: normContent.replace(normSearch, normReplace),
      success: true
    };
  }

  // Level 3: Fuzzy line-by-line trimmed matching with smart indentation preservation
  const searchLines = normSearch.split('\n');
  const searchTrimmed = searchLines.map(l => l.trim()).filter(Boolean);
  const docLines = normContent.split('\n');

  if (searchTrimmed.length > 0) {
    for (let i = 0; i <= docLines.length - searchTrimmed.length; i++) {
      let allMatch = true;
      for (let j = 0; j < searchTrimmed.length; j++) {
        if (docLines[i + j].trim() !== searchTrimmed[j]) {
          allMatch = false;
          break;
        }
      }

      if (allMatch) {
        // Detect base indentation of target code
        const targetIndentation = docLines[i].match(/^\s*/)?.[0] || '';
        const searchBaseIndentation = searchLines[0]?.match(/^\s*/)?.[0] || '';

        const replaceLines = normReplace.split('\n').map(line => {
          if (!line.trim()) return '';
          // If the replace block has same relative indentation, adapt to target file's indentation
          if (line.startsWith(searchBaseIndentation)) {
            return targetIndentation + line.slice(searchBaseIndentation.length);
          }
          return targetIndentation + line.trim();
        });

        const newDocLines = [...docLines];
        newDocLines.splice(i, searchTrimmed.length, ...replaceLines);
        return {
          newContent: newDocLines.join('\n'),
          success: true
        };
      }
    }
  }

  // Level 3.5: Token-normalized line matching (handles quote style variations, missing/extra semicolons)
  if (searchTrimmed.length > 0) {
    const searchTokens = searchTrimmed.map(l => normalizeTokens(l));
    for (let i = 0; i <= docLines.length - searchTokens.length; i++) {
      let allTokenMatch = true;
      for (let j = 0; j < searchTokens.length; j++) {
        if (normalizeTokens(docLines[i + j]) !== searchTokens[j]) {
          allTokenMatch = false;
          break;
        }
      }

      if (allTokenMatch) {
        const targetIndentation = docLines[i].match(/^\s*/)?.[0] || '';
        const replaceLines = normReplace.split('\n').map(line => {
          if (!line.trim()) return '';
          return targetIndentation + line.trim();
        });

        const newDocLines = [...docLines];
        newDocLines.splice(i, searchTokens.length, ...replaceLines);
        return {
          newContent: newDocLines.join('\n'),
          success: true
        };
      }
    }
  }

  // Level 3.8: Single-line or single-character/token partial locator
  if (searchLines.length === 1 && searchLines[0].trim().length > 0) {
    const singleSearch = searchLines[0].trim();
    const singleReplace = normReplace.trim();

    // Check if any line in document contains this exact token or character sequence
    for (let i = 0; i < docLines.length; i++) {
      if (docLines[i].includes(singleSearch)) {
        const newDocLines = [...docLines];
        newDocLines[i] = docLines[i].replace(singleSearch, singleReplace);
        return {
          newContent: newDocLines.join('\n'),
          success: true
        };
      }
    }

    // Check token-normalized match on a single line
    const searchTokenNorm = normalizeTokens(singleSearch);
    for (let i = 0; i < docLines.length; i++) {
      if (normalizeTokens(docLines[i]).includes(searchTokenNorm)) {
        const targetIndentation = docLines[i].match(/^\s*/)?.[0] || '';
        const newDocLines = [...docLines];
        newDocLines[i] = targetIndentation + singleReplace;
        return {
          newContent: newDocLines.join('\n'),
          success: true
        };
      }
    }
  }

  // Level 4: Anchor matching (first and last lines)
  if (searchTrimmed.length >= 3) {
    const firstAnchor = searchTrimmed[0];
    const lastAnchor = searchTrimmed[searchTrimmed.length - 1];
    let anchorStart = -1;
    let anchorEnd = -1;

    for (let i = 0; i < docLines.length; i++) {
      if (docLines[i].trim() === firstAnchor || normalizeTokens(docLines[i]) === normalizeTokens(firstAnchor)) {
        anchorStart = i;
        const scanLimit = Math.min(docLines.length, i + searchTrimmed.length + 25);
        for (let j = i + 1; j < scanLimit; j++) {
          if (docLines[j].trim() === lastAnchor || normalizeTokens(docLines[j]) === normalizeTokens(lastAnchor)) {
            anchorEnd = j;
            break;
          }
        }
        if (anchorEnd !== -1) break;
      }
    }

    if (anchorStart !== -1 && anchorEnd !== -1 && anchorEnd > anchorStart) {
      const targetIndentation = docLines[anchorStart].match(/^\s*/)?.[0] || '';
      const replaceLines = normReplace.split('\n').map(l => l.trim() ? targetIndentation + l.trim() : '');
      const newDocLines = [...docLines];
      newDocLines.splice(anchorStart, anchorEnd - anchorStart + 1, ...replaceLines);
      return {
        newContent: newDocLines.join('\n'),
        success: true
      };
    }
  }

  return { newContent: content, success: false };
};

/**
 * Detailed surgical edit result calculator
 */
export const applySurgicalEditWithDetails = (
  originalContent: string, 
  patchContent: string
): SurgicalEditResult => {
  if (!patchContent) {
    return {
      content: originalContent || '',
      appliedCount: 0,
      totalHunks: 0,
      hunks: [],
      isSurgical: false,
      summary: 'No patch provided'
    };
  }

  const hunks = extractSurgicalHunks(patchContent);

  if (hunks.length === 0) {
    // Non-diff or full content
    const updated = applySearchReplace(originalContent, patchContent);
    return {
      content: updated,
      appliedCount: 0,
      totalHunks: 0,
      hunks: [],
      isSurgical: false,
      summary: 'Full file rewrite / direct update'
    };
  }

  let currentContent = originalContent;
  let appliedCount = 0;

  const processedHunks = hunks.map(hunk => {
    const result = applySurgicalHunk(currentContent, hunk);
    if (result.success) {
      currentContent = result.newContent;
      appliedCount++;
      return { ...hunk, status: 'applied' as const };
    } else {
      return { ...hunk, status: 'failed' as const };
    }
  });

  return {
    content: currentContent,
    appliedCount,
    totalHunks: hunks.length,
    hunks: processedHunks,
    isSurgical: true,
    summary: `Applied ${appliedCount}/${hunks.length} surgical hunks successfully`
  };
};

export const applySearchReplace = (originalContent: string, patchContent: string): string => {
  if (!patchContent) return originalContent || '';
  if (!originalContent) return sanitizeAndRepairCode(patchContent, '');

  // 1. Process via Advanced Surgical Hunks Engine
  const surgicalHunks = extractSurgicalHunks(patchContent);
  if (surgicalHunks.length > 0) {
    let result = originalContent;
    let replacedAny = false;

    for (const hunk of surgicalHunks) {
      const application = applySurgicalHunk(result, hunk);
      if (application.success) {
        result = application.newContent;
        replacedAny = true;
      }
    }

    if (replacedAny) {
      return result;
    }
  }

  const sanitizedPatch = sanitizeAndRepairCode(patchContent, '');

  // 2. Intelligent Partial Snippet Merging:
  const trimmedPatch = sanitizedPatch.trim();
  const trimmedOrig = originalContent.trim();

  // Check if patch is likely a partial snippet vs a full file
  const isPatchFullFile = trimmedPatch.includes('<!DOCTYPE html') || 
    (trimmedPatch.includes('import ') && trimmedPatch.includes('export default')) ||
    (trimmedPatch.startsWith('//') && trimmedPatch.length > trimmedOrig.length * 0.8) ||
    trimmedPatch.length > 2500;

  if (!isPatchFullFile && trimmedOrig.length > 100) {
    // Check if patch defines or modifies specific top-level functions or methods
    const fnRegex = /(?:async\s+)?(?:function\s+([a-zA-Z0-9_$]+)|(?:const|let|var)\s+([a-zA-Z0-9_$]+)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>|([a-zA-Z0-9_$]+)\s*\([^)]*\)\s*\{)/g;
    let fnMatch;
    let foundFunctionNames: string[] = [];

    while ((fnMatch = fnRegex.exec(trimmedPatch)) !== null) {
      const name = fnMatch[1] || fnMatch[2] || fnMatch[3];
      if (name && !['if', 'for', 'while', 'switch', 'catch', 'constructor'].includes(name)) {
        foundFunctionNames.push(name);
      }
    }

    // If we detected function names in the snippet:
    if (foundFunctionNames.length > 0) {
      let modified = originalContent;
      let anyFnReplaced = false;

      for (const fnName of foundFunctionNames) {
        // Find if this function already exists in the original file
        const origFnRegex = new RegExp(`(?:async\\s+)?(?:function\\s+${fnName}|(?:const|let|var)\\s+${fnName}\\s*=\\s*(?:async\\s*)?\\([^)]*\\)\\s*=>|${fnName}\\s*\\([^)]*\\)\\s*\\{)[\\s\\S]*?\\n(?=\\s*(?:async\\s+)?(?:function|(?:const|let|var)\\s+[a-zA-Z0-9_$]+\\s*=|class|[a-zA-Z0-9_$]+\\s*\\([^)]*\\)\\s*\\{|window\\.|document\\.|animate\\(|init\\(|$))`, 'g');
        
        if (origFnRegex.test(originalContent)) {
          // Replace existing function definition
          modified = modified.replace(origFnRegex, trimmedPatch + '\n\n');
          anyFnReplaced = true;
          break;
        }
      }

      if (anyFnReplaced) {
        return modified;
      }

      // If the function is new, inject it before main animation loop or append
      if (!anyFnReplaced) {
        if (modified.includes('function animate()') || modified.includes('const animate =') || modified.includes('function loop()')) {
          modified = modified.replace(/(?=(?:function\s+animate|const\s+animate\s*=|function\s+loop))/, `\n// --- AI Added Feature ---\n${trimmedPatch}\n\n`);
          return modified;
        } else if (modified.includes('requestAnimationFrame(')) {
          const rafIdx = modified.indexOf('requestAnimationFrame(');
          const lineStart = modified.lastIndexOf('\n', rafIdx);
          if (lineStart !== -1) {
            return modified.slice(0, lineStart) + `\n\n// --- AI Added Feature ---\n${trimmedPatch}\n\n` + modified.slice(lineStart);
          }
        }
        // Fallback: Append to end of file
        return modified + `\n\n// --- AI Added Feature ---\n${trimmedPatch}\n`;
      }
    }
  }

  // 3. If full file replacement is intended, return the sanitized content
  return sanitizedPatch;
};

export const generateStandaloneHTML = (files: FileNode[], targetHtmlName?: string): string => {
  // 1. Resolve target HTML file or entry component
  let htmlFile: FileNode | undefined;
  if (targetHtmlName) {
    const cleanTarget = targetHtmlName.replace(/^\.\//, '').replace(/^\//, '');
    htmlFile = files.find(f => 
      f.name === cleanTarget || 
      f.name === targetHtmlName || 
      f.name.endsWith('/' + cleanTarget) ||
      f.name.replace(/^\.\//, '') === cleanTarget
    );
  }

  if (!htmlFile) {
    htmlFile = files.find(f => f.name === 'index.html' || f.name === 'index.htm' || f.name === 'main.html' || f.name === 'app.html') ||
               files.find(f => f.name.endsWith('.html') || f.name.endsWith('.htm'));
  }
  
  let content = '';
  if (htmlFile && (htmlFile.name.endsWith('.html') || htmlFile.name.endsWith('.htm'))) {
    content = htmlFile.content;
  } else {
    content = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Application Preview</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
      html, body { margin: 0; padding: 0; width: 100%; min-height: 100%; background: #0a0c10; color: #f8fafc; font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif; box-sizing: border-box; }
      #root, #app { width: 100%; min-height: 100vh; }
    </style>
</head>
<body>
    <div id="root"></div>
</body>
</html>`;
  }

  // 2. Process all CSS stylesheets and neutralize local stylesheet links
  const cssFiles = files.filter(f => f.name.endsWith('.css'));
  if (cssFiles.length > 0) {
    const styles = cssFiles.map(f => `<style id="aether-css-${f.name.replace(/[^a-zA-Z0-9_-]/g, '_')}">/* ${f.name} */\n${f.content}</style>`).join('\n');
    if (content.includes('</head>')) {
      content = content.replace('</head>', `${styles}\n</head>`);
    } else {
      content += `\n${styles}`;
    }
  }

  // Remove local <link rel="stylesheet"> tags pointing to local workspace files so browser doesn't 404
  content = content.replace(/<link\b([^>]*?)href=["']([^"']+)["']([^>]*?)>/gi, (match, before, href, after) => {
    const isStylesheet = /rel=["']stylesheet["']/i.test(match) || /rel=["']preload["']/i.test(match);
    if (!isStylesheet) return match;
    if (href.startsWith('http://') || href.startsWith('https://') || href.startsWith('//') || href.startsWith('data:')) {
      return match;
    }
    return `<!-- inlined stylesheet: ${href} -->`;
  });

  // 3. Auto-inject Tailwind CSS CDN if Tailwind classes or styling directives are present
  const hasTailwindSignals = content.includes('className=') || 
                             content.includes('class=') || 
                             content.includes('@tailwindcss') ||
                             content.includes('@import "tailwindcss"') ||
                             files.some(f => (f.name.endsWith('.tsx') || f.name.endsWith('.jsx') || f.name.endsWith('.css') || f.name.endsWith('.js') || f.name.endsWith('.ts')) && (f.content.includes('className=') || f.content.includes('tailwind')));
  
  if (hasTailwindSignals && !content.includes('tailwindcss.com') && !content.includes('@tailwindcss/browser')) {
    const tailwindScript = `<script src="https://cdn.tailwindcss.com"></script>`;
    if (content.includes('</head>')) {
      content = content.replace('</head>', `${tailwindScript}\n</head>`);
    } else {
      content = `${tailwindScript}\n` + content;
    }
  }

  // 4. Comprehensive Modern ESM Import Map with React 18, Icons, UI libs & Helpers
  const importMap: Record<string, string> = {
    "react": "https://esm.sh/react@18.3.1?dev",
    "react/": "https://esm.sh/react@18.3.1/",
    "react/jsx-runtime": "https://esm.sh/react@18.3.1/jsx-runtime",
    "react/jsx-dev-runtime": "https://esm.sh/react@18.3.1/jsx-dev-runtime",
    "react-dom": "https://esm.sh/react-dom@18.3.1?dev",
    "react-dom/": "https://esm.sh/react-dom@18.3.1/",
    "react-dom/client": "https://esm.sh/react-dom@18.3.1/client?dev",
    "react-is": "https://esm.sh/react-is@18.3.1",
    "https://esm.sh/react@18.2.0": "https://esm.sh/react@18.3.1?dev",
    "https://esm.sh/react@18.2.0/": "https://esm.sh/react@18.3.1/",
    "https://esm.sh/react@18.3.1": "https://esm.sh/react@18.3.1?dev",
    "https://esm.sh/react@18.3.1/": "https://esm.sh/react@18.3.1/",
    "https://esm.sh/react-dom@18.2.0": "https://esm.sh/react-dom@18.3.1?dev",
    "https://esm.sh/react-dom@18.2.0/client": "https://esm.sh/react-dom@18.3.1/client?dev",
    "https://esm.sh/react-dom@18.3.1": "https://esm.sh/react-dom@18.3.1?dev",
    "https://esm.sh/react-dom@18.3.1/client": "https://esm.sh/react-dom@18.3.1/client?dev",
    "https://unpkg.com/react@18/": "https://esm.sh/react@18.3.1/",
    "https://unpkg.com/react-dom@18/": "https://esm.sh/react-dom@18.3.1/",
    "https://cdn.jsdelivr.net/npm/react@18/": "https://esm.sh/react@18.3.1/",
    "https://cdn.jsdelivr.net/npm/react-dom@18/": "https://esm.sh/react-dom@18.3.1/",
    "react-icons": "https://esm.sh/react-icons@5.4.0?external=react",
    "react-icons/": "https://esm.sh/react-icons@5.4.0/",
    "react-icons/fa": "https://esm.sh/react-icons@5.4.0/fa?external=react",
    "react-icons/fi": "https://esm.sh/react-icons@5.4.0/fi?external=react",
    "react-icons/ai": "https://esm.sh/react-icons@5.4.0/ai?external=react",
    "react-icons/bi": "https://esm.sh/react-icons@5.4.0/bi?external=react",
    "react-icons/bs": "https://esm.sh/react-icons@5.4.0/bs?external=react",
    "react-icons/md": "https://esm.sh/react-icons@5.4.0/md?external=react",
    "react-icons/hi": "https://esm.sh/react-icons@5.4.0/hi?external=react",
    "react-icons/ri": "https://esm.sh/react-icons@5.4.0/ri?external=react",
    "react-icons/tb": "https://esm.sh/react-icons@5.4.0/tb?external=react",
    "react-icons/lu": "https://esm.sh/react-icons@5.4.0/lu?external=react",
    "react-icons/io5": "https://esm.sh/react-icons@5.4.0/io5?external=react",
    "react-hook-form": "https://esm.sh/react-hook-form@7.54.2?external=react",
    "@tanstack/react-query": "https://esm.sh/@tanstack/react-query@5.66.0?external=react,react-dom",
    "swr": "https://esm.sh/swr@2.3.2?external=react",
    "@react-spring/web": "https://esm.sh/@react-spring/web@9.7.5?external=react,react-dom",
    "htm": "https://esm.sh/htm@3.1.1?external=react",
    "htm/": "https://esm.sh/htm@3.1.1?external=react/",
    "https://esm.sh/htm": "https://esm.sh/htm@3.1.1?external=react",
    "https://esm.sh/htm@3.1.1": "https://esm.sh/htm@3.1.1?external=react",
    "react-router-dom": "https://esm.sh/react-router-dom@6.28.0?external=react,react-dom",
    "react-router-dom/": "https://esm.sh/react-router-dom@6.28.0&external=react,react-dom/",
    "react-router": "https://esm.sh/react-router@6.28.0?external=react,react-dom",
    "wouter": "https://esm.sh/wouter@3.3.5?external=react,react-dom",
    "lucide-react": "https://esm.sh/lucide-react@0.469.0?external=react",
    "lucide-react/": "https://esm.sh/lucide-react@0.469.0/",
    "lucide": "https://esm.sh/lucide@0.469.0",
    "framer-motion": "https://esm.sh/framer-motion@11.15.0?external=react,react-dom",
    "framer-motion/": "https://esm.sh/framer-motion@11.15.0?external=react,react-dom/",
    "motion": "https://esm.sh/motion@12.4.7?external=react,react-dom",
    "motion/": "https://esm.sh/motion@12.4.7?external=react,react-dom/",
    "motion/react": "https://esm.sh/motion@12.4.7/react?external=react,react-dom",
    "recharts": "https://esm.sh/recharts@2.15.1?external=react,react-dom",
    "chart.js": "https://esm.sh/chart.js@4.4.7",
    "chart.js/auto": "https://esm.sh/chart.js@4.4.7/auto",
    "react-chartjs-2": "https://esm.sh/react-chartjs-2@5.3.0?external=react,react-dom,chart.js",
    "canvas-confetti": "https://esm.sh/canvas-confetti@1.9.3",
    "canvas-confetti/": "https://esm.sh/canvas-confetti@1.9.3/",
    "d3": "https://esm.sh/d3@7.9.0",
    "d3/": "https://esm.sh/d3@7.9.0/",
    "lodash": "https://esm.sh/lodash@4.17.21",
    "lodash/": "https://esm.sh/lodash@4.17.21/",
    "clsx": "https://esm.sh/clsx@2.1.1",
    "tailwind-merge": "https://esm.sh/tailwind-merge@2.6.0",
    "axios": "https://esm.sh/axios@1.7.9",
    "date-fns": "https://esm.sh/date-fns@3.6.0",
    "zustand": "https://esm.sh/zustand@4.5.2?external=react",
    "zustand/": "https://esm.sh/zustand@4.5.2/",
    "sonner": "https://esm.sh/sonner@1.4.41?external=react,react-dom",
    "nanoid": "https://esm.sh/nanoid@5.0.7",
    "three": "https://esm.sh/three@0.160.0",
    "three/": "https://esm.sh/three@0.160.0/",
    "three-stdlib": "https://esm.sh/three-stdlib@2.29.4?external=three",
    "@react-three/fiber": "https://esm.sh/@react-three/fiber@8.18.0?external=react,react-dom,three",
    "@react-three/drei": "https://esm.sh/@react-three/drei@9.122.0?external=react,react-dom,three,@react-three/fiber",
    "@radix-ui/react-slot": "https://esm.sh/@radix-ui/react-slot@1.0.2?external=react,react-dom",
    "@radix-ui/react-dialog": "https://esm.sh/@radix-ui/react-dialog@1.0.5?external=react,react-dom",
    "@radix-ui/react-dropdown-menu": "https://esm.sh/@radix-ui/react-dropdown-menu@2.0.6?external=react,react-dom",
    "@radix-ui/react-tabs": "https://esm.sh/@radix-ui/react-tabs@1.0.4?external=react,react-dom",
    "@radix-ui/react-tooltip": "https://esm.sh/@radix-ui/react-tooltip@1.0.7?external=react,react-dom",
    "@radix-ui/react-popover": "https://esm.sh/@radix-ui/react-popover@1.0.7?external=react,react-dom",
    "@radix-ui/react-select": "https://esm.sh/@radix-ui/react-select@2.0.0?external=react,react-dom",
    "class-variance-authority": "https://esm.sh/class-variance-authority@0.7.0",
    "@monaco-editor/react": "https://esm.sh/@monaco-editor/react@4.6.0?external=react,react-dom",
    "monaco-editor": "https://esm.sh/monaco-editor@0.45.0",
    "monaco-editor/": "https://esm.sh/monaco-editor@0.45.0/",
    "@uiw/react-codemirror": "https://esm.sh/@uiw/react-codemirror@4.23.0?external=react,react-dom",
    "@codemirror/state": "https://esm.sh/@codemirror/state@6.4.1",
    "@codemirror/view": "https://esm.sh/@codemirror/view@6.26.3",
    "@codemirror/language": "https://esm.sh/@codemirror/language@6.10.1",
    "@codemirror/commands": "https://esm.sh/@codemirror/commands@6.5.0",
    "@codemirror/lang-javascript": "https://esm.sh/@codemirror/lang-javascript@6.2.2",
    "@codemirror/lang-html": "https://esm.sh/@codemirror/lang-html@6.4.8",
    "@codemirror/lang-css": "https://esm.sh/@codemirror/lang-css@6.2.1",
    "@codemirror/lang-json": "https://esm.sh/@codemirror/lang-json@6.0.1",
    "@codemirror/theme-one-dark": "https://esm.sh/@codemirror/theme-one-dark@6.1.2",
    "@uiw/codemirror-theme-vscode": "https://esm.sh/@uiw/codemirror-theme-vscode@4.23.0",
    "react-ace": "https://esm.sh/react-ace@10.1.0?external=react,react-dom",
    "ace-builds": "https://esm.sh/ace-builds@1.32.7",
    "prismjs": "https://esm.sh/prismjs@1.29.0",
    "react-simple-code-editor": "https://esm.sh/react-simple-code-editor@0.13.1?external=react,react-dom",
    "konva": "https://esm.sh/konva@9.3.6",
    "react-konva": "https://esm.sh/react-konva@18.2.10?external=react,react-dom,konva",
    "roughjs": "https://esm.sh/roughjs@4.6.6",
    "peerjs": "https://esm.sh/peerjs@1.5.2",
    "yjs": "https://esm.sh/yjs@13.6.14",
    "y-websocket": "https://esm.sh/y-websocket@1.5.0",
    "y-webrtc": "https://esm.sh/y-webrtc@10.2.5",
    "leaflet": "https://esm.sh/leaflet@1.9.4",
    "leaflet/": "https://esm.sh/leaflet@1.9.4/",
    "react-leaflet": "https://esm.sh/react-leaflet@4.2.1?external=react,react-dom,leaflet",
    "react-leaflet/": "https://esm.sh/react-leaflet@4.2.1/?external=react,react-dom,leaflet",
    "maplibre-gl": "https://esm.sh/maplibre-gl@4.3.2",
    "maplibre-gl/": "https://esm.sh/maplibre-gl@4.3.2/",
    "mapbox-gl": "https://esm.sh/mapbox-gl@3.4.0",
    "mapbox-gl/": "https://esm.sh/mapbox-gl@3.4.0/",
    "ol": "https://esm.sh/ol@9.2.4",
    "ol/": "https://esm.sh/ol@9.2.4/",
    "@turf/turf": "https://esm.sh/@turf/turf@7.0.0",
    "osmtogeojson": "https://esm.sh/osmtogeojson@3.0.0-beta.5",
    "pbf": "https://esm.sh/pbf@3.2.1"
  };

  const vfsMap: Record<string, string> = {};
  const moduleFiles = files.filter(f => (f.name.endsWith('.js') || f.name.endsWith('.ts') || f.name.endsWith('.tsx') || f.name.endsWith('.jsx')) && !f.name.includes('node_modules'));
  const compiledModules: Record<string, string> = {};

  // 5. Dynamic NPM Package Scanner: scan all module files for imports like `import ... from 'package'`
  files.forEach(f => {
    if (f.name.endsWith('.js') || f.name.endsWith('.ts') || f.name.endsWith('.tsx') || f.name.endsWith('.jsx') || f.name.endsWith('.html')) {
      const importRegex = /(?:import\s+(?:[\w*\s{},]*\s+from\s+)?['"]([^'"./][^'"]*)['"]|from\s+['"]([^'"./][^'"]*)['"]|import\(['"]([^'"./][^'"]*)['"]\))/g;
      let match;
      while ((match = importRegex.exec(f.content)) !== null) {
        const pkg = match[1] || match[2] || match[3];
        if (pkg && !importMap[pkg] && !pkg.startsWith('http://') && !pkg.startsWith('https://') && !pkg.startsWith('data:') && !pkg.startsWith('aether_mod:')) {
          let pkgUrl = `https://esm.sh/${pkg}`;
          if (pkg.includes('react') || pkg.startsWith('@radix-ui/') || pkg.startsWith('@uiw/') || pkg.startsWith('@monaco-editor/') || pkg.startsWith('lucide')) {
            pkgUrl += '?external=react,react-dom';
          }
          importMap[pkg] = pkgUrl;
          if (!pkg.endsWith('/')) {
            importMap[`${pkg}/`] = `${pkgUrl}/`;
          }
        }
      }
    }
  });

  // Relative Path Resolver helper
  const normalizePath = (p: string) => p.replace(/^\.\//, '').replace(/^\//, '');

  const resolveImportPath = (currentFilePath: string, specifier: string): string | null => {
    const cleanSpec = specifier.trim();
    if (cleanSpec.startsWith('http://') || cleanSpec.startsWith('https://') || cleanSpec.startsWith('data:') || cleanSpec.startsWith('//')) {
      return null;
    }

    const cleanCurrent = normalizePath(currentFilePath);
    const currentDir = cleanCurrent.includes('/') ? cleanCurrent.split('/').slice(0, -1).join('/') : '';

    let targetPath = '';
    if (cleanSpec.startsWith('./') || cleanSpec.startsWith('../')) {
      const segments = (currentDir ? currentDir.split('/') : []).concat(cleanSpec.split('/'));
      const resolvedSegments: string[] = [];
      for (const seg of segments) {
        if (!seg || seg === '.') continue;
        if (seg === '..') {
          resolvedSegments.pop();
        } else {
          resolvedSegments.push(seg);
        }
      }
      targetPath = resolvedSegments.join('/');
    } else if (cleanSpec.startsWith('@/') || cleanSpec.startsWith('~/')) {
      targetPath = cleanSpec.slice(2);
      if (!targetPath.startsWith('src/') && files.some(f => normalizePath(f.name).startsWith('src/' + targetPath))) {
        targetPath = 'src/' + targetPath;
      }
    } else if (!cleanSpec.includes('/') && files.some(f => normalizePath(f.name) === cleanSpec || normalizePath(f.name).endsWith('/' + cleanSpec))) {
      const match = files.find(f => normalizePath(f.name) === cleanSpec || normalizePath(f.name).endsWith('/' + cleanSpec));
      if (match) targetPath = normalizePath(match.name);
    }

    if (!targetPath) return null;

    const candidates = [
      targetPath,
      `${targetPath}.tsx`,
      `${targetPath}.ts`,
      `${targetPath}.jsx`,
      `${targetPath}.js`,
      `${targetPath}.css`,
      `${targetPath}.json`,
      `${targetPath}/index.tsx`,
      `${targetPath}/index.ts`,
      `${targetPath}/index.jsx`,
      `${targetPath}/index.js`,
      `src/${targetPath}`,
      `src/${targetPath}.tsx`,
      `src/${targetPath}.ts`,
      `src/${targetPath}.jsx`,
      `src/${targetPath}.js`
    ];

    for (const c of candidates) {
      const found = files.find(f => normalizePath(f.name) === normalizePath(c));
      if (found) return normalizePath(found.name);
    }

    return targetPath;
  };

  const rewriteLocalImports = (code: string, currentFilePath: string): string => {
    return code.replace(/(from\s+['"])([^'"]+)(['"])|(import\s*\(\s*['"])([^'"]+)(['"]\s*\))/g, (match, p1, spec1, p3, p4, spec2, p6) => {
      const isDynamic = !!p4;
      const spec = spec1 || spec2;
      if (!spec) return match;

      if (spec.startsWith('./') || spec.startsWith('../') || spec.startsWith('@/') || spec.startsWith('~/') || spec.endsWith('.css') || spec.endsWith('.json') || spec.endsWith('.png') || spec.endsWith('.jpg') || spec.endsWith('.svg')) {
        const resolved = resolveImportPath(currentFilePath, spec);
        if (resolved) {
          const virtualKey = `aether_mod:/${resolved}`;
          if (isDynamic) {
            return `${p4}${virtualKey}${p6}`;
          }
          return `${p1}${virtualKey}${p3}`;
        }
      }
      return match;
    });
  };

  // 6. Transpile all JS / JSX / TS / TSX files with Babel and create VFS Data URLs
  const safeBabelTransform = (codeToCompile: string, filename: string): string => {
    try {
      const transformFn = 
        (Babel as any)?.transform || 
        (Babel as any)?.default?.transform || 
        (typeof window !== 'undefined' && (window as any).Babel?.transform);

      if (typeof transformFn === 'function') {
        const res = transformFn(codeToCompile, {
          presets: [
            ['env', { modules: false, targets: { esmodules: true } }],
            ['react', { runtime: 'classic' }],
            'typescript'
          ],
          filename
        });
        return res?.code || codeToCompile;
      }
    } catch (err) {
      console.warn(`[Compiler] Babel transform issue for ${filename}:`, err);
    }
    return codeToCompile;
  };

  // Pre-process CSS files into ES module data URLs first
  cssFiles.forEach(f => {
    const cssClean = normalizePath(f.name);
    const dummyCssModule = `/* ${f.name} injected into DOM */ export default {};`;
    const cssBase64 = btoa(unescape(encodeURIComponent(dummyCssModule)));
    const cssDataUrl = `data:text/javascript;charset=utf-8;base64,${cssBase64}`;
    
    importMap[`aether_mod:/${cssClean}`] = cssDataUrl;
    importMap[f.name] = cssDataUrl;
    importMap[cssClean] = cssDataUrl;
    importMap[`./${cssClean}`] = cssDataUrl;
    importMap[`/${cssClean}`] = cssDataUrl;
    if (cssClean.startsWith('src/')) {
      const sub = cssClean.replace(/^src\//, '');
      importMap[`aether_mod:/${sub}`] = cssDataUrl;
      importMap[sub] = cssDataUrl;
      importMap[`./${sub}`] = cssDataUrl;
      importMap[`@/${sub}`] = cssDataUrl;
    }
  });

  // Compile Module Files
  moduleFiles.forEach(f => {
    try {
      let codeToCompile = f.content;
      
      // Auto-normalize `import { React, ... } from '...'` to `import React, { ... } from '...'`
      codeToCompile = codeToCompile.replace(/import\s*\{\s*React\s*,\s*([^}]+)\}\s*from\s*(['"][^'"]+['"])/g, 'import React, { $1 } from $2');
      codeToCompile = codeToCompile.replace(/import\s*\{\s*([^}]+),\s*React\s*\}\s*from\s*(['"][^'"]+['"])/g, 'import React, { $1 } from $2');
      codeToCompile = codeToCompile.replace(/import\s*\{\s*React\s*\}\s*from\s*(['"][^'"]+['"])/g, 'import React from $1');

      // Ensure React is imported if JSX or React references are used
      if ((codeToCompile.includes('React.') || codeToCompile.includes('useState') || codeToCompile.includes('useEffect') || /<[A-Z]/.test(codeToCompile)) && !/import\s+.*React/.test(codeToCompile)) {
        codeToCompile = `import React from 'react';\n` + codeToCompile;
      }

      // Rewrite relative and alias imports into exact virtual module keys
      codeToCompile = rewriteLocalImports(codeToCompile, f.name);

      let compiled = codeToCompile;
      if (f.name.endsWith('.ts') || f.name.endsWith('.tsx') || f.name.endsWith('.jsx') || f.name.endsWith('.js')) {
        compiled = safeBabelTransform(codeToCompile, f.name);
      }
      
      const base64 = btoa(unescape(encodeURIComponent(compiled)));
      const dataUrl = `data:text/javascript;charset=utf-8;base64,${base64}`;

      const clean = normalizePath(f.name);
      const noExt = clean.replace(/\.(tsx|ts|jsx|js)$/, '');
      const baseName = clean.split('/').pop() || clean;
      const baseNoExt = baseName.replace(/\.(tsx|ts|jsx|js)$/, '');

      compiledModules[clean] = dataUrl;
      compiledModules[f.name] = dataUrl;
      compiledModules[`./${clean}`] = dataUrl;
      compiledModules[`/${clean}`] = dataUrl;

      // Register virtual module mappings
      importMap[`aether_mod:/${clean}`] = dataUrl;
      importMap[`aether_mod:/${noExt}`] = dataUrl;
      importMap[`aether_mod:/${baseName}`] = dataUrl;
      importMap[`aether_mod:/${baseNoExt}`] = dataUrl;

      const aliases = [
        clean, `./${clean}`, `/${clean}`,
        noExt, `./${noExt}`, `/${noExt}`
      ];

      if (clean.startsWith('src/')) {
        const sub = clean.replace(/^src\//, '');
        const subNoExt = sub.replace(/\.(tsx|ts|jsx|js)$/, '');
        importMap[`aether_mod:/${sub}`] = dataUrl;
        importMap[`aether_mod:/${subNoExt}`] = dataUrl;
        aliases.push(
          sub, `./${sub}`, `/${sub}`, `../${sub}`,
          subNoExt, `./${subNoExt}`, `/${subNoExt}`, `../${subNoExt}`,
          `@/${sub}`, `@/${subNoExt}`
        );
      } else {
        aliases.push(
          `@/${clean}`, `@/${noExt}`,
          `../${clean}`, `../${noExt}`
        );
      }

      if (clean.includes('/')) {
        const parts = clean.split('/');
        const dir = parts.slice(0, -1).join('/');
        const last = parts[parts.length - 1];
        const lastNoExt = last.replace(/\.(tsx|ts|jsx|js)$/, '');
        aliases.push(
          `../${dir}/${last}`, `../${dir}/${lastNoExt}`, 
          `./${dir}/${last}`, `./${dir}/${lastNoExt}`,
          `${dir}/${last}`, `${dir}/${lastNoExt}`
        );
      } else {
        aliases.push(baseName, `./${baseName}`, baseNoExt, `./${baseNoExt}`);
      }

      aliases.forEach(alias => {
        importMap[alias] = dataUrl;
      });
    } catch (e) {
      console.warn(`[Compiler] Module processing error for ${f.name}:`, e);
    }
  });

  // 7. Resolve Entry Component
  const entryFile = (targetHtmlName && moduleFiles.find(f => f.name === targetHtmlName || f.name.endsWith('/' + targetHtmlName))) ||
                    files.find(f => f.name === 'src/main.tsx' || f.name === 'main.tsx' || f.name === 'index.tsx' || f.name === 'src/index.tsx') ||
                    files.find(f => f.name === 'src/App.tsx' || f.name === 'App.tsx' || f.name === 'src/App.jsx' || f.name === 'App.jsx') ||
                    files.find(f => f.name === 'index.js' || f.name === 'src/index.js' || f.name === 'src/main.js' || f.name === 'main.js') ||
                    moduleFiles[0];

  const entryDataUrl = entryFile ? (compiledModules[entryFile.name] || compiledModules[entryFile.name.replace(/^\.\//, '').replace(/^\//, '')]) : null;

  // 8. Process static assets (images, binary, JSON, 3D models) into VFS & ES Module data URLs
  files.forEach(f => {
    let type = f.isBinary ? "application/octet-stream" : "text/plain";
    if (f.name.endsWith('.json')) type = "application/json";
    if (f.name.endsWith('.obj') || f.name.endsWith('.stl')) type = "text/plain";
    if (f.name.endsWith('.gltf')) type = "application/json";
    if (f.name.endsWith('.csv')) type = "text/csv";
    if (f.name.endsWith('.svg')) type = "image/svg+xml";
    if (f.name.endsWith('.png')) type = "image/png";
    if (f.name.endsWith('.jpg') || f.name.endsWith('.jpeg')) type = "image/jpeg";
    if (f.name.endsWith('.webp')) type = "image/webp";

    const isImage = f.isBinary || f.language === 'image' || ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg'].some(ext => f.name.toLowerCase().endsWith(`.${ext}`));

    let assetUrl = '';
    if (f.content && (f.content.startsWith('http://') || f.content.startsWith('https://') || f.content.startsWith('data:'))) {
      assetUrl = f.content;
    } else if (f.isBinary) {
      assetUrl = f.content.startsWith('data:') ? f.content : `data:${type};base64,${f.content}`;
    } else if (!f.name.endsWith('.js') && !f.name.endsWith('.ts') && !f.name.endsWith('.tsx') && !f.name.endsWith('.jsx') && !f.name.endsWith('.html') && !f.name.endsWith('.css')) {
      try {
        const base64Content = btoa(unescape(encodeURIComponent(f.content)));
        assetUrl = `data:${type};base64,${base64Content}`;
      } catch (e) {
        assetUrl = f.content;
      }
    }

    if (assetUrl) {
      const clean = f.name.replace(/^\.\//, '').replace(/^\//, '');
      const baseName = clean.split('/').pop() || clean;
      
      vfsMap[f.name] = assetUrl;
      vfsMap[clean] = assetUrl;
      vfsMap['./' + clean] = assetUrl;
      vfsMap['/' + clean] = assetUrl;
      vfsMap['../' + clean] = assetUrl;

      if (clean.startsWith('public/')) {
        const noPublic = clean.replace(/^public\//, '');
        vfsMap[noPublic] = assetUrl;
        vfsMap['/' + noPublic] = assetUrl;
        vfsMap['./' + noPublic] = assetUrl;
        vfsMap['../' + noPublic] = assetUrl;
      }

      // If image or JSON asset, allow ES module imports (e.g. `import logo from './logo.png'`)
      if (isImage || f.name.endsWith('.json')) {
        const moduleJs = f.name.endsWith('.json') 
          ? `export default ${f.content || '{}'};` 
          : `export default "${assetUrl}";`;
        const jsBase64 = btoa(unescape(encodeURIComponent(moduleJs)));
        const jsDataUrl = `data:text/javascript;charset=utf-8;base64,${jsBase64}`;

        const assetAliases = [
          clean, `./${clean}`, `/${clean}`, `../${clean}`,
          baseName, `./${baseName}`, `/${baseName}`, `../${baseName}`
        ];
        if (clean.startsWith('public/')) {
          const noPub = clean.replace(/^public\//, '');
          assetAliases.push(noPub, `./${noPub}`, `/${noPub}`, `../${noPub}`);
        }
        assetAliases.forEach(a => {
          importMap[a] = jsDataUrl;
        });
      }
    }
  });

  // 9. React In-HTML Script Pre-compilation & JSX Transformation
  content = content.replace(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi, (match, attrs, code) => {
    const isBabel = /type=["'](text\/babel|text\/jsx|text\/tsx|text\/typescript)["']/i.test(attrs);
    const hasJSX = /<[A-Za-z][\s\S]*>|React\.createElement|ReactDOM\.createRoot|ReactDOM\.render|useState\(|useEffect\(/.test(code);
    const hasSrc = /src=["']([^"']+)["']/i.test(attrs);

    if (hasSrc) return match;

    if (isBabel || (hasJSX && !code.includes('Babel.transform'))) {
      try {
        let cleanInline = code;
        cleanInline = cleanInline.replace(/import\s*\{\s*React\s*,\s*([^}]+)\}\s*from\s*(['"][^'"]+['"])/g, 'import React, { $1 } from $2');
        cleanInline = cleanInline.replace(/import\s*\{\s*([^}]+),\s*React\s*\}\s*from\s*(['"][^'"]+['"])/g, 'import React, { $1 } from $2');
        cleanInline = cleanInline.replace(/import\s*\{\s*React\s*\}\s*from\s*(['"][^'"]+['"])/g, 'import React from $1');

        const transformed = safeBabelTransform(cleanInline, 'inline-script.tsx');

        const cleanAttrs = attrs
          .replace(/type=["'](text\/babel|text\/jsx|text\/tsx|text\/typescript)["']/gi, '')
          .trim();

        return `<script type="module" ${cleanAttrs}>\n${transformed}\n</script>`;
      } catch (err) {
        console.warn('[Compiler] Inline Babel transform failed:', err);
        return match;
      }
    }
    return match;
  });

  // Importmap declaration script
  const importMapScript = `<script type="importmap">{"imports":${JSON.stringify(importMap)}}</script>`;

  // Global Environment & Browser Capability Bridge Script
  const globalEnvBridge = `
    <script>
      (function() {
        window.global = window;
        window.process = window.process || { env: { NODE_ENV: 'development' } };

        // 1. Safe Storage Polyfill for Sandboxed iframes (Prevents SecurityError/DOMException crashing entire apps)
        try {
          const _testKey = '__aether_storage_test__';
          window.localStorage.setItem(_testKey, _testKey);
          window.localStorage.removeItem(_testKey);
        } catch (e) {
          const _createStoragePolyfill = () => {
            let _store = {};
            return {
              getItem: (k) => Object.prototype.hasOwnProperty.call(_store, k) ? _store[k] : null,
              setItem: (k, v) => { _store[k] = String(v); },
              removeItem: (k) => { delete _store[k]; },
              clear: () => { _store = {}; },
              key: (i) => Object.keys(_store)[i] || null,
              get length() { return Object.keys(_store).length; }
            };
          };
          try {
            Object.defineProperty(window, 'localStorage', { value: _createStoragePolyfill(), writable: true, configurable: true });
          } catch(_) {
            try { (window as any).localStorage = _createStoragePolyfill(); } catch(__) {}
          }
        }

        try {
          const _testKey = '__aether_session_test__';
          window.sessionStorage.setItem(_testKey, _testKey);
          window.sessionStorage.removeItem(_testKey);
        } catch (e) {
          const _createStoragePolyfill = () => {
            let _store = {};
            return {
              getItem: (k) => Object.prototype.hasOwnProperty.call(_store, k) ? _store[k] : null,
              setItem: (k, v) => { _store[k] = String(v); },
              removeItem: (k) => { delete _store[k]; },
              clear: () => { _store = {}; },
              key: (i) => Object.keys(_store)[i] || null,
              get length() { return Object.keys(_store).length; }
            };
          };
          try {
            Object.defineProperty(window, 'sessionStorage', { value: _createStoragePolyfill(), writable: true, configurable: true });
          } catch(_) {
            try { (window as any).sessionStorage = _createStoragePolyfill(); } catch(__) {}
          }
        }

        // 2. Safe Fallback Stubs for common third-party CDN libraries (prevent premature ReferenceErrors)
        if (typeof window.hljs === 'undefined') {
          window.hljs = {
            getLanguage: function() { return false; },
            highlight: function(code) { return { value: code }; },
            highlightAuto: function(code) { return { value: code }; },
            highlightAll: function() {}
          };
        }

        if (typeof window.DOMPurify === 'undefined') {
          window.DOMPurify = {
            sanitize: function(html) { return html; }
          };
        }

        if (typeof window.lucide === 'undefined') {
          window.lucide = {
            createIcons: function() {}
          };
        }

        // 3. Zero-Race Lifecycle Event Listener Polyfill
        const _origAddEventListener = EventTarget.prototype.addEventListener;
        EventTarget.prototype.addEventListener = function(type, listener, options) {
          if (this === window || this === document) {
            if (type === 'DOMContentLoaded' && (document.readyState === 'interactive' || document.readyState === 'complete')) {
              try { setTimeout(listener, 0); } catch(e) { console.error(e); }
              return;
            }
            if (type === 'load' && document.readyState === 'complete') {
              try { setTimeout(listener, 0); } catch(e) { console.error(e); }
              return;
            }
          }
          return _origAddEventListener.call(this, type, listener, options);
        };

        // 4. Safe BroadcastChannel Polyfill (Sandboxed/Opaque Origin Resilient)
        try {
          if (typeof window.BroadcastChannel !== 'undefined') {
            const testCh = new window.BroadcastChannel('__aether_test__');
            testCh.close();
          }
        } catch (e) {
          // Native BroadcastChannel throws SecurityError in opaque sandbox; install postMessage bridge
          window.BroadcastChannel = class AetherBroadcastChannel {
            constructor(name) {
              this.name = name;
              this.onmessage = null;
              this._id = Math.random().toString(36).slice(2);
              this._handler = (event) => {
                if (event.data && event.data.__aether_bc === this.name && event.data.__sender !== this._id) {
                  if (typeof this.onmessage === 'function') {
                    this.onmessage({ data: event.data.payload });
                  }
                }
              };
              window.addEventListener('message', this._handler);
            }
            postMessage(payload) {
              const msg = { __aether_bc: this.name, __sender: this._id, payload };
              window.postMessage(msg, '*');
              if (window.parent && window.parent !== window) {
                try { window.parent.postMessage(msg, '*'); } catch(_) {}
              }
            }
            close() {
              window.removeEventListener('message', this._handler);
            }
          };
        }

        // 5. Canvas 2D roundRect Polyfill
        if (typeof CanvasRenderingContext2D !== 'undefined' && !CanvasRenderingContext2D.prototype.roundRect) {
          CanvasRenderingContext2D.prototype.roundRect = function(x, y, w, h, radii) {
            if (w < 0) { x += w; w = Math.abs(w); }
            if (h < 0) { y += h; h = Math.abs(h); }
            let r = radii || 0;
            if (typeof r === 'number') r = [r, r, r, r];
            else if (Array.isArray(r)) {
              if (r.length === 1) r = [r[0], r[0], r[0], r[0]];
              else if (r.length === 2) r = [r[0], r[1], r[0], r[1]];
              else if (r.length === 3) r = [r[0], r[1], r[2], r[1]];
            }
            const [tl, tr, br, bl] = r;
            this.beginPath();
            this.moveTo(x + tl, y);
            this.lineTo(x + w - tr, y);
            this.quadraticCurveTo(x + w, y, x + w, y + tr);
            this.lineTo(x + w, y + h - br);
            this.quadraticCurveTo(x + w, y + h, x + w - br, y + h);
            this.lineTo(x + bl, y + h);
            this.quadraticCurveTo(x, y + h, x, y + h - bl);
            this.lineTo(x, y + tl);
            this.quadraticCurveTo(x, y, x + tl, y);
            this.closePath();
            return this;
          };
        }

        // 6. Universal CORS Proxy Bypass Interceptor (Bypasses CORS for external APIs, CDNs, Arbitrary IPs & Chat URLs)
        window.__AETHER_CORS_BYPASS_ENABLED__ = true;
        const _origFetch = window.fetch;
        if (typeof _origFetch === 'function') {
          window.fetch = async function(input, init) {
            let url = typeof input === 'string' ? input : (input instanceof URL ? input.href : (input && input.url ? input.url : ''));
            
            const isLocalVfsOrInternal = typeof url === 'string' && (
              url.startsWith('blob:') || 
              url.startsWith('data:') || 
              url.startsWith('/__vfs__') || 
              url.startsWith('/api/') || 
              url.startsWith(window.location.origin)
            );

            const isExternalOrIp = typeof url === 'string' && !isLocalVfsOrInternal && (
              url.startsWith('http://') || 
              url.startsWith('https://') || 
              url.startsWith('//') || 
              /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(url)
            );

            if (isExternalOrIp && window.__AETHER_CORS_BYPASS_ENABLED__) {
              try {
                // Try direct request first
                const res = await _origFetch(input, init);
                return res;
              } catch (err) {
                // Direct request failed (CORS or network policy) -> Seamlessly retry via Server-Side CORS Proxy!
                const proxyUrl = '/api/cors-proxy?url=' + encodeURIComponent(url);
                const method = (init && init.method) || (input && input.method) || 'GET';
                const headers = (init && init.headers) || (input && input.headers) || {};
                const body = init && init.body;
                
                return await _origFetch(proxyUrl, {
                  method,
                  headers,
                  body
                });
              }
            }
            return _origFetch(input, init);
          };
        }

        const _origXHR = window.XMLHttpRequest;
        if (_origXHR) {
          window.XMLHttpRequest = class AetherProxyXHR extends _origXHR {
            open(method, url, ...rest) {
              let finalUrl = url;
              const isLocalVfsOrInternal = typeof url === 'string' && (
                url.startsWith('blob:') || 
                url.startsWith('data:') || 
                url.startsWith('/__vfs__') || 
                url.startsWith('/api/') || 
                url.startsWith(window.location.origin)
              );
              const isExternalOrIp = typeof url === 'string' && !isLocalVfsOrInternal && (
                url.startsWith('http://') || 
                url.startsWith('https://') || 
                url.startsWith('//') || 
                /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(url)
              );

              if (isExternalOrIp && window.__AETHER_CORS_BYPASS_ENABLED__) {
                finalUrl = '/api/cors-proxy?url=' + encodeURIComponent(url);
              }
              return super.open(method, finalUrl, ...rest);
            }
          };
        }

        // 7. Auto Asset Error Recovery for external scripts and stylesheets
        window.addEventListener('error', function(event) {
          const target = event.target;
          if (target && target.tagName === 'SCRIPT' && target.src && !target.src.includes('/api/proxy') && !target.src.includes('/api/cors-proxy')) {
            if (target.src.startsWith('http://') || target.src.startsWith('https://')) {
              console.warn('[Aether Proxy] External script failed to load directly, retrying via CORS bypass proxy:', target.src);
              const retryScript = document.createElement('script');
              retryScript.src = '/api/cors-proxy?url=' + encodeURIComponent(target.src);
              retryScript.crossOrigin = 'anonymous';
              document.head.appendChild(retryScript);
            }
          }
        }, true);
      })();
    </script>
  `;

  const vfsScript = `
    <script>
      (function() {
        window.__VFS__ = ${JSON.stringify(vfsMap)};

        // Universal VFS & Geospatial Fetch Interceptor (Stripping unsafe headers & auto-proxying OSM/Nominatim/Overpass)
        const originalFetch = window.fetch;
        window.fetch = async function(resource, init) {
           let urlStr = typeof resource === 'string' ? resource : (resource instanceof Request ? resource.url : String(resource));
           if (urlStr.startsWith('//')) urlStr = 'https:' + urlStr;
           
           // Clean headers if user-agent is passed (prevent browser CORS preflight crash)
           let cleanInit = init ? { ...init } : {};
           if (cleanInit.headers) {
             const cleanHeaders = {};
             if (cleanInit.headers instanceof Headers) {
               cleanInit.headers.forEach((val, key) => {
                 if (key.toLowerCase() !== 'user-agent') cleanHeaders[key] = val;
               });
             } else if (typeof cleanInit.headers === 'object') {
               for (const [k, v] of Object.entries(cleanInit.headers)) {
                 if (k.toLowerCase() !== 'user-agent') cleanHeaders[k] = v;
               }
             }
             cleanInit.headers = cleanHeaders;
           }

           // Check if resource is in virtual filesystem
           if (window.__VFS__[urlStr]) return originalFetch(window.__VFS__[urlStr], cleanInit);
           const cleanUrl = urlStr.replace(/^about:srcdoc\/?/, '').replace(/^blob:.*?\/?/, '');
           if (window.__VFS__[cleanUrl]) return originalFetch(window.__VFS__[cleanUrl], cleanInit);
           if (window.__VFS__['./' + cleanUrl]) return originalFetch(window.__VFS__['./' + cleanUrl], cleanInit);
           if (window.__VFS__['/' + cleanUrl]) return originalFetch(window.__VFS__['/' + cleanUrl], cleanInit);

           // Direct external fetch with auto proxy fallback for Nominatim, Overpass, and OpenStreetMap APIs
           if (urlStr.startsWith('http://') || urlStr.startsWith('https://')) {
             const isGeospatialOrOverpass = urlStr.includes('nominatim.openstreetmap.org') || 
                                            urlStr.includes('overpass-api.de') || 
                                            urlStr.includes('overpass.kumi.systems') ||
                                            urlStr.includes('openstreetmap.org/api');
             if (isGeospatialOrOverpass) {
               try {
                 const proxyUrl = '/api/proxy?url=' + encodeURIComponent(urlStr);
                 return await originalFetch(proxyUrl, cleanInit);
               } catch(err) {
                 return await originalFetch(resource, cleanInit);
               }
             }

             try {
               const resp = await originalFetch(resource, cleanInit);
               if (resp.ok) return resp;
               if (resp.status === 403 || resp.status === 429 || resp.status === 0) {
                 const proxyUrl = '/api/proxy?url=' + encodeURIComponent(urlStr);
                 return await originalFetch(proxyUrl, cleanInit);
               }
               return resp;
             } catch (fetchErr) {
               try {
                 const proxyUrl = '/api/proxy?url=' + encodeURIComponent(urlStr);
                 return await originalFetch(proxyUrl, cleanInit);
               } catch(_) {}
               throw fetchErr;
             }
           }

           return originalFetch(resource, cleanInit);
        };

        // Universal VFS XMLHttpRequest Interceptor
        if (typeof XMLHttpRequest !== 'undefined') {
          const originalOpen = XMLHttpRequest.prototype.open;
          XMLHttpRequest.prototype.open = function(method, url, ...args) {
            let urlStr = String(url);
            if (!urlStr.startsWith('http://') && !urlStr.startsWith('https://') && !urlStr.startsWith('//') && !urlStr.startsWith('data:') && !urlStr.startsWith('blob:')) {
              const cleanUrl = urlStr.replace(/^about:srcdoc\/?/, '').replace(/^blob:.*?\/?/, '');
              if (window.__VFS__[cleanUrl]) urlStr = window.__VFS__[cleanUrl];
              else if (window.__VFS__['./' + cleanUrl]) urlStr = window.__VFS__['./' + cleanUrl];
              else if (window.__VFS__['/' + cleanUrl]) urlStr = window.__VFS__['/' + cleanUrl];
            }
            return originalOpen.call(this, method, urlStr, ...args);
          };
        }
      })();
    </script>
  `;

  const runtimeResilienceScript = `
    <script>
      (function() {
        // Global Error Interceptor for IDE Live Feedback
        window.addEventListener('error', function(e) {
          try {
            window.parent.postMessage({
              type: 'AETHER_PREVIEW_LOG',
              level: 'error',
              message: (e.message || 'Script runtime error') + (e.filename ? ' in ' + e.filename + ':' + (e.lineno || 0) : '')
            }, '*');
          } catch (_) {}
        });

        window.addEventListener('unhandledrejection', function(e) {
          try {
            window.parent.postMessage({
              type: 'AETHER_PREVIEW_LOG',
              level: 'error',
              message: 'Unhandled Promise Rejection: ' + (e.reason && (e.reason.message || e.reason.stack) ? (e.reason.message || e.reason.stack) : String(e.reason))
            }, '*');
          } catch (_) {}
        });

        // Intercept internal page navigation inside preview iframe
        document.addEventListener('click', function(e) {
          const anchor = e.target.closest('a');
          if (anchor && anchor.getAttribute('href')) {
            const href = anchor.getAttribute('href');
            if (href && !href.startsWith('http://') && !href.startsWith('https://') && !href.startsWith('#') && !href.startsWith('mailto:') && !href.startsWith('tel:') && !href.startsWith('javascript:')) {
              e.preventDefault();
              const cleanTarget = href.replace(/^\.\//, '').replace(/^\//, '');
              window.parent.postMessage({ type: 'AETHER_NAVIGATE_WORKSPACE', target: cleanTarget }, '*');
            }
          }
        });

        // Auto-resume AudioContext on user interaction
        function resumeAllAudio() {
          try {
            if (window.AudioContext || window.webkitAudioContext) {
              // Contexts will resume on interaction
            }
          } catch (_) {}
        }
        document.addEventListener('pointerdown', resumeAllAudio, { once: true });
        document.addEventListener('keydown', resumeAllAudio, { once: true });

        // Global Monaco Editor Environment Bridge for Sandboxed Preview
        window.MonacoEnvironment = window.MonacoEnvironment || {
          getWorkerUrl: function(workerId, label) {
            return 'data:text/javascript;charset=utf-8,' + encodeURIComponent(
              'self.MonacoEnvironment = { baseUrl: "https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/" };' +
              'importScripts("https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/vs/base/worker/workerMain.js");'
            );
          }
        };

        // Auto-initialize Lucide Icons if loaded via CDN
        function initLucideIcons() {
          try {
            if (window.lucide && typeof window.lucide.createIcons === 'function') {
              window.lucide.createIcons();
            }
          } catch (_) {}
        }
        window.addEventListener('DOMContentLoaded', initLucideIcons);
        window.addEventListener('load', initLucideIcons);
        
        // Observe DOM for newly inserted data-lucide icons
        if (typeof MutationObserver !== 'undefined') {
          const iconObserver = new MutationObserver(function() {
            initLucideIcons();
          });
          document.addEventListener('DOMContentLoaded', function() {
            if (document.body) {
              iconObserver.observe(document.body, { childList: true, subtree: true });
            }
          });
        }

        // ==========================================
        // ROBUST GEOSPATIAL & OPENSTREETMAP ENGINE
        // ==========================================
        function patchLeaflet(leaflet) {
          if (!leaflet || !leaflet.Map || !leaflet.TileLayer || leaflet._aetherPatched) return;
          leaflet._aetherPatched = true;

          try {
            // 1. Fix default marker icon resolution in sandboxed preview
            if (leaflet.Icon && leaflet.Icon.Default) {
              delete leaflet.Icon.Default.prototype._getIconUrl;
              leaflet.Icon.Default.mergeOptions({
                iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
                iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
                shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
              });
            }

            // 2. Resilient Tile Layer with Direct Tile Loading and Fallback Mirrors
            if (leaflet.TileLayer && leaflet.TileLayer.prototype) {
              leaflet.TileLayer.prototype.options.keepBuffer = 32;
              leaflet.TileLayer.prototype.options.maxNativeZoom = 19;
              leaflet.TileLayer.prototype.options.updateWhenIdle = false;
              leaflet.TileLayer.prototype.options.updateWhenZooming = true;
              
              const origCreateTile = leaflet.TileLayer.prototype.createTile;
              leaflet.TileLayer.prototype.createTile = function(coords, done) {
                const tile = origCreateTile.call(this, coords, done);
                tile.loading = 'eager';
                tile.decoding = 'async';

                let retryCount = 0;
                tile.onerror = function() {
                  retryCount++;
                  const mirrors = [
                    'https://a.basemaps.cartocdn.com/rastertiles/voyager/',
                    'https://a.basemaps.cartocdn.com/dark_all/',
                    'https://tile.openstreetmap.fr/osmfr/',
                    'https://tile.openstreetmap.org/'
                  ];
                  if (retryCount <= mirrors.length) {
                    const z = coords.z;
                    const x = coords.x;
                    const y = coords.y;
                    const base = mirrors[(retryCount - 1) % mirrors.length];
                    tile.src = base + z + '/' + x + '/' + y + '.png';
                  }
                };
                return tile;
              };
            }

            // 3. Auto InvalidateSize so maps in tabs, modals, flex containers NEVER collapse or get stuck gray
            if (leaflet.Map && leaflet.Map.prototype) {
              const origMapInit = leaflet.Map.prototype.initialize;
              leaflet.Map.prototype.initialize = function(id, options) {
                // Ensure container has physical height
                let targetEl = null;
                if (typeof id === 'string') {
                  targetEl = document.getElementById(id);
                } else if (id instanceof HTMLElement) {
                  targetEl = id;
                }

                if (targetEl && (targetEl.clientHeight === 0 || targetEl.offsetHeight === 0)) {
                  if (!targetEl.style.minHeight) {
                    targetEl.style.minHeight = '300px';
                  }
                  if (!targetEl.style.height) {
                    targetEl.style.height = '100%';
                  }
                }

                const map = origMapInit.call(this, id, options);
                const triggerInvalidate = () => {
                  try { 
                    map.invalidateSize({ animate: false, pan: false });
                  } catch(_) {}
                };
                
                [20, 100, 250, 500, 1000, 2000, 4000].forEach(ms => setTimeout(triggerInvalidate, ms));

                if (window.ResizeObserver && this._container) {
                  const ro = new ResizeObserver(() => {
                    requestAnimationFrame(triggerInvalidate);
                  });
                  ro.observe(this._container);
                  if (this._container.parentElement) {
                    ro.observe(this._container.parentElement);
                  }
                }

                window.addEventListener('resize', triggerInvalidate);
                document.addEventListener('visibilitychange', () => {
                  if (!document.hidden) triggerInvalidate();
                });

                return map;
              };
            }
          } catch(err) {
            console.warn('[Aether Leaflet Engine] Patch notice:', err);
          }
        }

        function checkAndPatchLeaflet() {
          if (window.L && window.L.Map && !window.L._aetherPatched) {
            patchLeaflet(window.L);
          }
        }

        checkAndPatchLeaflet();
        const mapPatchInterval = setInterval(checkAndPatchLeaflet, 200);
        window.addEventListener('DOMContentLoaded', checkAndPatchLeaflet);
        window.addEventListener('load', () => {
          checkAndPatchLeaflet();
          setTimeout(() => clearInterval(mapPatchInterval), 10000);
        });

        // WebGL & Canvas Context Loss Resiliency
        if (typeof HTMLCanvasElement !== 'undefined') {
          const origGetContext = HTMLCanvasElement.prototype.getContext;
          HTMLCanvasElement.prototype.getContext = function(type, ...args) {
            const ctx = origGetContext.call(this, type, ...args);
            if (ctx && (type === 'webgl' || type === 'webgl2' || type === 'experimental-webgl')) {
              this.addEventListener('webglcontextlost', function(e) {
                e.preventDefault();
                console.warn('[Aether Render Engine] WebGL Context Restored');
              }, false);
            }
            return ctx;
          };
        }
      })();
    </script>
  `;

  // Base full-viewport reset CSS to ensure zero-margin and 100% height + Leaflet/Map container stability
  const baseResetStyle = `
    <!-- Preloaded Universal Leaflet Map Stylesheet -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <style id="aether-preview-base-reset">
      html, body {
        margin: 0;
        padding: 0;
        width: 100%;
        min-height: 100%;
        height: 100%;
        box-sizing: border-box;
      }
      #root, #app {
        width: 100%;
        min-height: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
      }
      /* Ensure leaflet containers don't collapse to 0 height */
      .leaflet-container {
        width: 100%;
        height: 100%;
        min-height: 200px;
        background: #09090b !important;
      }
      .leaflet-pane {
        z-index: 400 !important;
      }
      .leaflet-tile-pane {
        z-index: 200 !important;
      }
      .leaflet-overlay-pane {
        z-index: 400 !important;
      }
      .leaflet-shadow-pane {
        z-index: 500 !important;
      }
      .leaflet-marker-pane {
        z-index: 600 !important;
      }
      .leaflet-tooltip-pane {
        z-index: 650 !important;
      }
      .leaflet-popup-pane {
        z-index: 700 !important;
      }
      .leaflet-top, .leaflet-bottom {
        z-index: 1000 !important;
      }
      .leaflet-tile {
        visibility: visible !important;
        opacity: 1 !important;
      }
    </style>
  `;

  // Inject scripts into <head> (importmap MUST precede module scripts)
  const headInject = `${baseResetStyle}\n${importMapScript}\n${globalEnvBridge}\n${vfsScript}\n${runtimeResilienceScript}`;

  if (content.includes('</head>')) {
    content = content.replace('</head>', `${headInject}\n</head>`);
  } else {
    content = `${headInject}\n` + content;
  }

  // 10. Replace all local script src references in HTML with their direct inlined compiled code or Data URLs
  const replacedScriptPaths = new Set<string>();
  content = content.replace(/<script\b([^>]*)src=["']([^"']+)["']([^>]*?)>([\s\S]*?)<\/script>/gi, (match, before, src, after) => {
    if (src.startsWith('http://') || src.startsWith('https://') || src.startsWith('//') || src.startsWith('data:')) {
      return match;
    }
    const cleanSrc = src.replace(/^\.\//, '').replace(/^\//, '');
    const fileObj = files.find(f => {
      const normName = normalizePath(f.name);
      const normSrc = normalizePath(cleanSrc);
      return normName === normSrc || 
             normName === `src/${normSrc}` || 
             normName === `js/${normSrc}` || 
             normName === `scripts/${normSrc}` || 
             normName.endsWith('/' + normSrc) ||
             normSrc.endsWith('/' + normName);
    });
    
    if (fileObj) {
      replacedScriptPaths.add(cleanSrc);
      replacedScriptPaths.add(`src/${cleanSrc}`);
      replacedScriptPaths.add(fileObj.name);
      if (entryFile && (entryFile.name === cleanSrc || entryFile.name === `src/${cleanSrc}` || entryFile.name === fileObj.name)) {
        replacedScriptPaths.add(entryFile.name);
      }
      
      const isESModule = (fileObj.content && (fileObj.content.includes('import ') || fileObj.content.includes('export ') || fileObj.content.includes('import('))) ||
                         cleanSrc.endsWith('.tsx') || cleanSrc.endsWith('.jsx') || cleanSrc.endsWith('.ts') ||
                         /type=["']module["']/i.test(before + after);

      let transformedCode = fileObj.content;
      if (cleanSrc.endsWith('.ts') || cleanSrc.endsWith('.tsx') || cleanSrc.endsWith('.jsx') || isESModule) {
        transformedCode = rewriteLocalImports(transformedCode, fileObj.name);
        transformedCode = safeBabelTransform(transformedCode, fileObj.name);
      }

      // Safeguard against </script> inside JS strings/regex breaking HTML parser
      transformedCode = transformedCode.replace(/<\/script/gi, '<\\/script');

      const cleanAttrs = (before + ' ' + after)
        .replace(/type=["'](text\/babel|text\/jsx|text\/tsx|text\/typescript|module)["']/gi, '')
        .replace(/defer|async/gi, '')
        .trim();

      if (isESModule) {
        return `<script type="module" ${cleanAttrs}>\n/* ${fileObj.name} */\n${transformedCode}\n</script>`;
      } else {
        return `<script ${cleanAttrs}>\n/* ${fileObj.name} */\n${transformedCode}\n</script>`;
      }
    }
    return match;
  });

  // Ensure root mount container is present ONLY if no container element exists
  const hasContainer = content.includes('id="root"') || 
                       content.includes("id='root'") || 
                       content.includes('id="app"') || 
                       content.includes("id='app'") ||
                       content.includes('id="main"') ||
                       content.includes("id='main'");

  if (!hasContainer) {
    if (content.includes('</body>')) {
      content = content.replace('</body>', `<div id="root"></div>\n</body>`);
    } else {
      content += `\n<div id="root"></div>`;
    }
  }

  // 11. Entry Script Auto-Mounter & Error Boundary:
  // ONLY inject auto-mounter if entry file is NOT already referenced in a script tag in HTML
  if (entryFile && entryDataUrl && !replacedScriptPaths.has(entryFile.name) && !replacedScriptPaths.has(entryFile.name.replace(/^\.\//, '').replace(/^\//, '')) && !content.includes(entryFile.name)) {
    const isExplicitReactComponent = entryFile.name.endsWith('.tsx') || 
                                    entryFile.name.endsWith('.jsx') || 
                                    (entryFile.content && (
                                      entryFile.content.includes('import React') ||
                                      entryFile.content.includes("from 'react'") ||
                                      entryFile.content.includes('from "react"') ||
                                      entryFile.content.includes('React.createElement') ||
                                      /<[A-Z][A-Za-z0-9]*[\s/>]/.test(entryFile.content)
                                    ));
    
    if (isExplicitReactComponent) {
      const autoMountScript = `
        <script type="module">
          import React from 'react';
          import ReactDOM from 'react-dom/client';
          import * as EntryModule from '${entryDataUrl}';

          // React Error Boundary for Preview Diagnostics
          class AetherErrorBoundary extends React.Component {
            constructor(props) {
              super(props);
              this.state = { hasError: false, error: null, errorInfo: null };
            }
            static getDerivedStateFromError(error) {
              return { hasError: true, error };
            }
            componentDidCatch(error, errorInfo) {
              this.setState({ errorInfo });
              try {
                window.parent.postMessage({
                  type: 'AETHER_PREVIEW_LOG',
                  level: 'error',
                  message: 'React Runtime Error: ' + (error.message || String(error))
                }, '*');
              } catch (_) {}
            }
            render() {
              if (this.state.hasError) {
                return React.createElement('div', {
                  style: {
                    padding: '24px',
                    margin: '20px',
                    backgroundColor: '#111318',
                    color: '#f43f5e',
                    borderRadius: '16px',
                    fontFamily: 'monospace',
                    border: '1px solid rgba(244,63,94,0.3)',
                    boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.5)'
                  }
                },
                  React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' } },
                    React.createElement('span', { style: { fontSize: '18px' } }, '⚠️'),
                    React.createElement('h3', { style: { margin: 0, fontSize: '15px', fontWeight: 'bold', color: '#fda4af' } }, 'React Preview Render Exception')
                  ),
                  React.createElement('p', { style: { color: '#e4e4e7', fontSize: '13px', margin: '0 0 16px 0', lineHeight: 1.5 } }, this.state.error?.message || String(this.state.error)),
                  React.createElement('button', {
                    onClick: () => this.setState({ hasError: false, error: null }),
                    style: {
                      padding: '8px 16px',
                      backgroundColor: '#f43f5e',
                      color: '#ffffff',
                      border: 'none',
                      borderRadius: '8px',
                      cursor: 'pointer',
                      fontWeight: 'bold',
                      fontSize: '12px'
                    }
                  }, 'Reload Component')
                );
              }
              return this.props.children;
            }
          }

          const ComponentToRender = EntryModule.default || EntryModule.App || EntryModule.Main || (typeof EntryModule === 'function' ? EntryModule : null) || Object.values(EntryModule).find(v => typeof v === 'function');

          const rootElement = document.getElementById('root') || document.getElementById('app') || document.getElementById('main') || document.body.appendChild(document.createElement('div'));
          if (!rootElement.id) rootElement.id = 'root';

          if (ComponentToRender && !window.__AETHER_REACT_MOUNTED__ && rootElement.children.length === 0) {
            window.__AETHER_REACT_MOUNTED__ = true;
            try {
              const root = ReactDOM.createRoot(rootElement);
              root.render(React.createElement(AetherErrorBoundary, null, React.createElement(ComponentToRender)));
            } catch (err) {
              console.error('Failed to mount React component:', err);
            }
          }
        </script>
      `;

      if (content.includes('</body>')) {
        content = content.replace('</body>', `${autoMountScript}\n</body>`);
      } else {
        content += `\n${autoMountScript}`;
      }
    } else {
      // Auto-inject non-React Vanilla JS script entry
      const isESModule = (entryFile.content && (entryFile.content.includes('import ') || entryFile.content.includes('export ') || entryFile.content.includes('import('))) || entryFile.name.endsWith('.ts');
      const vanillaScriptTag = isESModule 
        ? `<script type="module" src="${entryDataUrl}"></script>`
        : `<script src="${entryDataUrl}"></script>`;
      if (content.includes('</body>')) {
        content = content.replace('</body>', `${vanillaScriptTag}\n</body>`);
      } else {
        content += `\n${vanillaScriptTag}`;
      }
    }
  }

  return content;
};

export const deployProjectToBlobUrl = (files: FileNode[], targetHtmlName?: string): string => {
  const htmlContent = generateStandaloneHTML(files, targetHtmlName);
  const blob = new Blob([htmlContent], { type: 'text/html' });
  return URL.createObjectURL(blob);
};

export const exportProjectToZip = async (files: FileNode[], returnAsBase64 = false): Promise<any> => {
  const zip = new JSZip();
  files.forEach(file => {
    if (file.isBinary && file.content.includes(',')) {
      const base64Data = file.content.split(',')[1];
      zip.file(file.name, base64Data, { base64: true });
    } else {
      zip.file(file.name, file.content);
    }
  });
  return await zip.generateAsync({ type: returnAsBase64 ? 'base64' : 'blob' });
};

export const triggerFileDownload = (blob: Blob, filename: string) => {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

export const importProjectFromZip = async (zipFile: File, projectId: string): Promise<FileNode[]> => {
  const zip = new JSZip();
  const loadedZip = await zip.loadAsync(zipFile);
  const newFiles: FileNode[] = [];

  for (const [relativePath, zipEntry] of Object.entries(loadedZip.files)) {
    if (zipEntry.dir) continue; // skip directories

    // Ignore system files (like Mac __MACOSX, .DS_Store, etc.)
    if (relativePath.includes('__MACOSX') || relativePath.endsWith('.DS_Store')) continue;

    const ext = relativePath.split('.').pop() || 'txt';
    const isBinary = ['png', 'jpg', 'jpeg', 'gif', 'webp', 'glb', 'obj', 'stl', 'woff', 'woff2', 'ttf'].includes(ext.toLowerCase());

    let content = '';
    if (isBinary) {
      const blob = await zipEntry.async('blob');
      content = await new Promise<string>((resolve) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(blob);
      });
    } else {
      content = await zipEntry.async('string');
    }

    const lang = isBinary ? 'image' : (['js', 'ts', 'tsx', 'jsx', 'html', 'css', 'json'].includes(ext) ? (ext === 'js' ? 'javascript' : ext === 'ts' ? 'typescript' : ext) : 'plaintext');

    newFiles.push({
      id: `f_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      name: relativePath,
      content,
      language: lang,
      lastModified: Date.now(),
      isBinary
    });
  }

  // Save to database
  if (projectId && newFiles.length > 0) {
    await storageService.saveFiles(projectId, newFiles);
    // Warm up OPFS Cache
    await opfsService.saveToOPFSCache(projectId, newFiles);
    
    // Try syncing to Server Workspace
    try {
      await fetch('/api/sessions/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          session: { id: projectId, title: "Imported Project", messages: [], lastUpdated: Date.now() },
          files: newFiles
        })
      });
    } catch (e) {
      console.error("Failed to save imported ZIP to server workspace", e);
    }
  }

  return newFiles;
};
