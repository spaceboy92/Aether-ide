import { FileNode, ChatMessage } from '../types';
import { parseAIResponse, SimpleAIResponse } from './aiResponseParser';
import { parseProgressiveStream } from './progressiveStreamParser';

export const chatWithAnthropicStream = async (
  modelId: string,
  prompt: string,
  currentFiles: FileNode[],
  history: ChatMessage[],
  onChunk: (thoughts: string, message: string, steps?: { step: string; status: string }[], codeFragment?: string, metrics?: any) => void,
  onRawChunk?: (text: string) => void
): Promise<SimpleAIResponse> => {
  try {
    const streamStartTime = Date.now();
    const clientApiKey = typeof window !== 'undefined' ? (localStorage.getItem('anthropic_api_key') || '') : '';
    onChunk("", `Connecting to Anthropic AI (${modelId})...`, [{ step: `Routing query to Anthropic ${modelId}...`, status: "active" }]);

    const response = await fetch('/api/anthropic/stream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        modelId,
        prompt,
        currentFiles,
        history,
        apiKey: clientApiKey
      })
    });

    if (!response.ok || !response.body) {
      const errText = await response.text().catch(() => '');
      throw new Error(`Anthropic stream endpoint returned status ${response.status}: ${errText.slice(0, 200)}`);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let fullText = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value, { stream: true });
      if (chunk) {
        fullText += chunk;
        if (onRawChunk) onRawChunk(chunk);

        try {
          const parsedState = parseProgressiveStream(fullText, streamStartTime);
          const fragments: Record<string, string> = {};
          Object.values(parsedState.files).forEach(f => {
            fragments[f.path] = f.code;
          });

          onChunk(
            parsedState.thoughts,
            parsedState.message,
            parsedState.reasoningSteps,
            Object.keys(fragments).length > 0 ? JSON.stringify(fragments) : undefined,
            parsedState.metrics
          );
        } catch (e) {
          // progressive stream error
        }
      }
    }

    return parseAIResponse(fullText);
  } catch (err: any) {
    console.error("Anthropic stream failed:", err);
    throw err;
  }
};

export const chatWithAnthropic = async (
  modelId: string,
  prompt: string,
  currentFiles: FileNode[],
  history: ChatMessage[]
): Promise<SimpleAIResponse> => {
  try {
    const clientApiKey = typeof window !== 'undefined' ? (localStorage.getItem('anthropic_api_key') || '') : '';
    const res = await fetch('/api/anthropic/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        modelId,
        prompt,
        currentFiles,
        history,
        apiKey: clientApiKey
      })
    });
    const data = await res.json();
    if (data.text) {
      return parseAIResponse(data.text);
    }
    throw new Error(data.error || "Failed to generate content with Anthropic");
  } catch (err: any) {
    console.error("Anthropic chat call failed:", err);
    return {
      message: `Anthropic AI request failed: ${err.message || 'Failed to connect'}`,
      thoughts: `Error: ${err.message}`,
      files: [],
      commands: []
    };
  }
};
