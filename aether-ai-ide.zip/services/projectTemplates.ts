import { FileNode } from '../types';

export interface ProjectTemplateConfig {
  id: string;
  name: string;
  category: 'frontend' | 'fullstack' | '3d-game' | 'python' | 'rust' | 'backend';
  icon: string;
  badge: string;
  description: string;
  files: (sessionId: string) => FileNode[];
}

export const NEXT_GEN_TEMPLATES: ProjectTemplateConfig[] = [
  {
    id: 'react-18-typescript',
    name: 'React 18 + TypeScript Modern App',
    category: 'frontend',
    icon: '⚛️',
    badge: 'React 18 + TS',
    description: 'Modern React 18 SPA with hooks, Lucide icons, Tailwind CSS, and interactive state management.',
    files: (sessionId: string): FileNode[] => {
      const now = Date.now();
      return [
        {
          id: `f_r18_html_${now}`,
          name: 'index.html',
          language: 'html',
          lastModified: now,
          content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>React 18 Modern Studio</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-zinc-950 text-zinc-100 font-sans min-h-screen">
  <div id="root"></div>
  <script type="module" src="/src/main.tsx"></script>
</body>
</html>`
        },
        {
          id: `f_r18_main_${now}`,
          name: 'src/main.tsx',
          language: 'typescript',
          lastModified: now,
          content: `import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const rootElement = document.getElementById('root');
if (rootElement) {
  const root = ReactDOM.createRoot(rootElement);
  root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
}`
        },
        {
          id: `f_r18_app_${now}`,
          name: 'src/App.tsx',
          language: 'typescript',
          lastModified: now,
          content: `import React, { useState } from 'react';
import { 
  Sparkles, 
  Activity, 
  Terminal, 
  CheckCircle2, 
  Layers, 
  Zap, 
  Cpu, 
  RefreshCw,
  Plus,
  Trash2
} from 'lucide-react';

interface MetricItem {
  id: string;
  name: string;
  category: string;
  status: 'active' | 'queued' | 'completed';
  value: number;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'tasks' | 'settings'>('dashboard');
  const [counter, setCounter] = useState(108);
  const [tasks, setTasks] = useState<string[]>([
    'Configure React 18 Virtual DOM pipeline',
    'Integrate Tailwind CSS design system',
    'Execute real-time browser transpile loop'
  ]);
  const [newTaskInput, setNewTaskInput] = useState('');

  const metrics: MetricItem[] = [
    { id: '1', name: 'Neural Model Dispatcher', category: 'Inference', status: 'active', value: 99.4 },
    { id: '2', name: 'React 18 Fiber Reconciliation', category: 'Runtime', status: 'active', value: 100 },
    { id: '3', name: 'Sandboxed VFS Resolution', category: 'Storage', status: 'completed', value: 98.7 },
  ];

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTaskInput.trim()) {
      setTasks([...tasks, newTaskInput.trim()]);
      setNewTaskInput('');
    }
  };

  const handleDeleteTask = (index: number) => {
    setTasks(tasks.filter((_, idx) => idx !== index));
  };

  return (
    <div className="min-h-screen bg-[#090b10] text-zinc-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Top Navbar */}
      <header className="h-16 border-b border-zinc-800/80 bg-zinc-950/70 backdrop-blur-xl sticky top-0 z-30 px-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500/20 via-blue-500/20 to-indigo-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400 font-bold">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-bold text-white tracking-wide">React 18 Modern Studio</h1>
              <span className="px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-[10px] font-mono font-bold">Vite + React 18</span>
            </div>
            <p className="text-xs text-zinc-400">High performance reactive component runtime</p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 bg-zinc-900/90 border border-zinc-800 p-1 rounded-xl">
          <button 
            onClick={() => setActiveTab('dashboard')}
            className={\`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 \${
              activeTab === 'dashboard' 
                ? 'bg-cyan-500 text-black shadow-lg shadow-cyan-500/20' 
                : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
            }\`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Dashboard</span>
          </button>
          <button 
            onClick={() => setActiveTab('tasks')}
            className={\`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-2 \${
              activeTab === 'tasks' 
                ? 'bg-cyan-500 text-black shadow-lg shadow-cyan-500/20' 
                : 'text-zinc-400 hover:text-white hover:bg-zinc-800/50'
            }\`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Tasks ({tasks.length})</span>
          </button>
        </div>
      </header>

      {/* Main Body */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-6 md:p-8 space-y-8">
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            {/* Hero Welcome */}
            <div className="p-6 md:p-8 rounded-2xl bg-gradient-to-r from-cyan-950/40 via-zinc-900/60 to-zinc-900/40 border border-cyan-500/20 flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 text-xs font-medium">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Real Browser Preview Engine</span>
                </div>
                <h2 className="text-2xl md:text-3xl font-extrabold text-white">Full React 18 Execution Environment</h2>
                <p className="text-zinc-400 text-sm max-w-xl">
                  Supports React components, state hooks, JSX/TSX syntax, custom Lucide icons, and Tailwind utility classes with instant hot-reload.
                </p>
              </div>

              {/* Interactive Counter Box */}
              <div className="p-5 bg-zinc-950/80 border border-zinc-800 rounded-xl space-y-3 min-w-[220px]">
                <div className="text-xs font-bold text-zinc-400 uppercase tracking-wider flex items-center justify-between">
                  <span>State Counter</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                </div>
                <div className="text-3xl font-mono font-bold text-cyan-400">{counter}</div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => setCounter(c => c + 1)}
                    className="flex-1 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs rounded-lg transition-all"
                  >
                    +1
                  </button>
                  <button 
                    onClick={() => setCounter(c => c - 1)}
                    className="flex-1 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs rounded-lg transition-all"
                  >
                    -1
                  </button>
                  <button 
                    onClick={() => setCounter(0)}
                    className="p-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white rounded-lg transition-all"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Metrics Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {metrics.map((item) => (
                <div key={item.id} className="p-5 bg-zinc-900/60 border border-zinc-800/80 rounded-xl space-y-3 hover:border-zinc-700 transition-all">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-zinc-400">{item.category}</span>
                    <span className="px-2 py-0.5 rounded-md bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-bold">
                      {item.status.toUpperCase()}
                    </span>
                  </div>
                  <div className="text-sm font-bold text-white">{item.name}</div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-zinc-500">Efficiency</span>
                      <span className="text-cyan-400 font-bold">{item.value}%</span>
                    </div>
                    <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden">
                      <div className="bg-cyan-500 h-full rounded-full transition-all" style={{ width: \`\${item.value}%\` }}></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'tasks' && (
          <div className="max-w-2xl mx-auto space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-white">Project Workflows</h2>
                <p className="text-xs text-zinc-400">Interactive task management powered by React useState</p>
              </div>
              <span className="text-xs font-mono text-cyan-400 bg-cyan-500/10 px-3 py-1 rounded-full border border-cyan-500/20">
                {tasks.length} active
              </span>
            </div>

            <form onSubmit={handleAddTask} className="flex gap-2">
              <input 
                type="text"
                value={newTaskInput}
                onChange={(e) => setNewTaskInput(e.target.value)}
                placeholder="Enter new task or workflow..."
                className="flex-1 bg-zinc-900 border border-zinc-700 rounded-xl px-4 py-2.5 text-xs text-white placeholder-zinc-500 outline-none focus:border-cyan-500 transition-all"
              />
              <button 
                type="submit"
                className="px-5 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs rounded-xl flex items-center gap-1.5 transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>Add</span>
              </button>
            </form>

            <div className="space-y-2">
              {tasks.map((task, idx) => (
                <div 
                  key={idx} 
                  className="p-4 bg-zinc-900/80 border border-zinc-800 rounded-xl flex items-center justify-between gap-4 group hover:border-zinc-700 transition-all"
                >
                  <div className="flex items-center gap-3">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span className="text-xs text-zinc-200">{task}</span>
                  </div>
                  <button 
                    onClick={() => handleDeleteTask(idx)}
                    className="p-1.5 text-zinc-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-all opacity-80 group-hover:opacity-100"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800/80 py-4 px-6 text-center text-xs text-zinc-500 font-mono">
        Aether React 18 Engine &bull; Zero-Latency Browser Runtime
      </footer>
    </div>
  );
}`
        }
      ];
    }
  },
  {
    id: 'synapse-studio',
    name: 'Aether Studio (Collaborative Code & Canvas)',
    category: 'fullstack',
    icon: '⚡',
    badge: 'WebGL + Canvas',
    description: 'Real-time collaborative code editor with WebGL Three.js sandbox runner and infinite vector graph canvas.',
    files: (sessionId: string): FileNode[] => {
      const now = Date.now();
      return [
        {
          id: `f_synapse_html_${now}`,
          name: 'index.html',
          language: 'html',
          lastModified: now,
          content: `<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Aether Studio | Collaborative Code & Infinite Canvas</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          colors: {
            canvas: '#090d16',
            surface: '#111827',
            panel: '#151d2e',
            border: '#1f293d',
            accent: '#6366f1',
            accentHover: '#4f46e5',
            cyanNeon: '#06b6d4',
            emeraldNeon: '#10b981'
          }
        }
      }
    }
  </script>
  <script src="https://unpkg.com/lucide@latest"></script>
  <link rel="stylesheet" href="style.css" />
</head>
<body class="bg-[#0b0f19] text-slate-100 font-sans antialiased h-screen overflow-hidden flex flex-col select-none">

  <!-- TOP NAVIGATION HEADER -->
  <header class="h-14 bg-panel/90 border-b border-border/80 px-4 flex items-center justify-between backdrop-blur-md z-30 shrink-0">
    <div class="flex items-center gap-3">
      <div class="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 via-cyan-500 to-emerald-400 p-[1px] flex items-center justify-center shadow-lg shadow-indigo-500/20">
        <div class="w-full h-full bg-[#0b0f19] rounded-[11px] flex items-center justify-center">
          <i data-lucide="cpu" class="w-5 h-5 text-cyan-400"></i>
        </div>
      </div>
      <div>
        <div class="flex items-center gap-2">
          <span class="font-bold tracking-tight text-white text-base">SYNAPSE<span class="text-cyan-400 font-mono text-sm ml-1">//STUDIO</span></span>
          <span class="px-2 py-0.5 text-[10px] font-mono tracking-wide rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 flex items-center gap-1.5">
            <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
            SYNC ACTIVE
          </span>
        </div>
      </div>
    </div>

    <!-- Workspace Mode Switcher -->
    <div class="flex items-center bg-surface/80 p-1 rounded-xl border border-border/60 shadow-inner">
      <button id="viewModeSplit" class="workspace-tab active-tab px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all text-slate-300 hover:text-white">
        <i data-lucide="columns" class="w-3.5 h-3.5"></i> Split Studio
      </button>
      <button id="viewModeCode" class="workspace-tab px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all text-slate-400 hover:text-white">
        <i data-lucide="code-2" class="w-3.5 h-3.5"></i> Code & Runner
      </button>
      <button id="viewModeCanvas" class="workspace-tab px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all text-slate-400 hover:text-white">
        <i data-lucide="layout-grid" class="w-3.5 h-3.5"></i> Infinite Canvas
      </button>
    </div>

    <!-- Controls & Active Collaborators -->
    <div class="flex items-center gap-3">
      <!-- Collaborators Pill -->
      <div class="flex items-center -space-x-2 overflow-hidden px-2 py-1 bg-surface/60 rounded-full border border-border/60">
        <div id="userBadgeLocal" class="w-7 h-7 rounded-full bg-indigo-600 border-2 border-[#0b0f19] flex items-center justify-center text-[11px] font-bold text-white shadow ring-1 ring-indigo-400/40" title="You (Host)">
          YOU
        </div>
        <div id="peerBadge1" class="w-7 h-7 rounded-full bg-cyan-600 border-2 border-[#0b0f19] flex items-center justify-center text-[10px] font-bold text-white peer-avatar hidden" title="Peer Alice (Tab Sync)">
          AL
        </div>
        <div id="peerBadge2" class="w-7 h-7 rounded-full bg-emerald-600 border-2 border-[#0b0f19] flex items-center justify-center text-[10px] font-bold text-white peer-avatar hidden" title="Peer Bob (Tab Sync)">
          BO
        </div>
        <span id="peerCountBadge" class="pl-2.5 pr-1 text-[11px] font-mono text-cyan-300 font-semibold">1 Peer</span>
      </div>

      <!-- Action Buttons -->
      <button id="runCodeBtn" class="px-3.5 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 shadow-lg shadow-emerald-500/20 active:scale-95 transition-all">
        <i data-lucide="play" class="w-3.5 h-3.5 fill-current"></i> Run App
      </button>

      <button id="spawnBotBtn" class="px-3 py-1.5 bg-surface hover:bg-border text-slate-300 hover:text-white border border-border rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all" title="Simulate Remote Teammate Cursors and Activity">
        <i data-lucide="bot" class="w-3.5 h-3.5 text-cyan-400"></i> +Simulate Peer
      </button>

      <button id="exportBtn" class="p-2 bg-surface hover:bg-border text-slate-400 hover:text-white border border-border rounded-lg transition-all" title="Export Workspace Snapshot">
        <i data-lucide="download" class="w-4 h-4"></i>
      </button>
    </div>
  </header>

  <!-- MAIN WORKSPACE VIEWPORT CONTAINER -->
  <div id="workspace" class="flex-1 flex min-h-0 relative overflow-hidden bg-canvas">
    
    <!-- LEFT PANEL: CODE EDITOR & SANDBOX (Adjustable Width) -->
    <section id="leftPanel" class="flex flex-col border-r border-border/80 bg-surface/50 min-w-[280px] w-1/2 relative z-10 transition-all duration-75">
      
      <!-- File Explorer Tabs Header -->
      <div class="h-10 bg-panel/70 border-b border-border/80 flex items-center justify-between px-2 shrink-0 select-none">
        <div class="flex items-center gap-1 overflow-x-auto no-scrollbar" id="tabBar">
          <button class="editor-tab active-editor-tab flex items-center gap-2 px-3 py-1.5 text-xs rounded-md bg-surface text-cyan-400 border border-border/70" data-file="app.js">
            <i data-lucide="file-code" class="w-3.5 h-3.5 text-amber-400"></i>
            <span>app.js</span>
            <span class="w-2 h-2 rounded-full bg-cyan-400/80 ml-1"></span>
          </button>
          <button class="editor-tab flex items-center gap-2 px-3 py-1.5 text-xs rounded-md text-slate-400 hover:text-slate-200 hover:bg-surface/50 border border-transparent" data-file="index.html">
            <i data-lucide="code" class="w-3.5 h-3.5 text-orange-400"></i>
            <span>index.html</span>
          </button>
          <button class="editor-tab flex items-center gap-2 px-3 py-1.5 text-xs rounded-md text-slate-400 hover:text-slate-200 hover:bg-surface/50 border border-transparent" data-file="style.css">
            <i data-lucide="palette" class="w-3.5 h-3.5 text-sky-400"></i>
            <span>style.css</span>
          </button>
        </div>

        <!-- Template Loaders -->
        <div class="flex items-center gap-1.5">
          <select id="templatePicker" class="bg-panel border border-border text-[11px] text-slate-300 rounded px-2 py-1 focus:outline-none focus:border-cyan-500 cursor-pointer">
            <option value="threejs">⚡ 3D Interactive Canvas</option>
            <option value="particles">✨ Particle Wave Engine</option>
            <option value="audioSynth">🎵 Web Audio Visualizer</option>
            <option value="neonDashboard">📊 Cyber Analytics HUD</option>
          </select>
          <button id="toggleConsoleBtn" class="px-2 py-1 text-[11px] font-mono text-slate-400 hover:text-white bg-panel border border-border rounded flex items-center gap-1">
            <i data-lucide="terminal" class="w-3 h-3"></i> Logs
          </button>
        </div>
      </div>

      <!-- Code Editor Split Area (Code on Top, Live Runner / Sandbox on Bottom) -->
      <div class="flex-1 flex flex-col min-h-0">
        
        <!-- Monospaced Interactive Code Editor Component -->
        <div class="flex-1 relative flex overflow-hidden bg-[#0a0e17] font-mono text-sm group">
          <!-- Line Numbers Gutter -->
          <div id="lineNumbers" class="w-11 py-3 bg-[#070a10] border-r border-border/50 text-right pr-2 select-none text-slate-600 text-xs font-mono shrink-0 overflow-hidden"></div>
          
          <!-- Simulated Multi-user Cursor Layer -->
          <div id="editorCursorLayer" class="absolute inset-0 pointer-events-none z-10"></div>

          <!-- Code Textarea with High-density Syntax Overlay -->
          <textarea id="codeEditor" spellcheck="false" autocapitalize="off" class="flex-1 w-full h-full bg-transparent text-slate-200 p-3 font-mono text-xs leading-5 resize-none focus:outline-none z-0 selection:bg-cyan-500/30 selection:text-white caret-cyan-400"></textarea>
        </div>

        <!-- Sandboxed Live Runner + Terminal Drawer (Collapsible) -->
        <div id="runnerContainer" class="h-56 border-t border-border/80 bg-[#090d16] flex flex-col shrink-0 relative transition-all duration-200">
          <!-- Runner Header Bar -->
          <div class="h-7 bg-panel border-b border-border/80 px-3 flex items-center justify-between text-[11px] font-medium text-slate-400 shrink-0">
            <div class="flex items-center gap-2">
              <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span class="text-slate-300 font-semibold tracking-wide uppercase text-[10px]">Live Sandbox Preview & Terminal</span>
            </div>
            <div class="flex items-center gap-2">
              <button id="clearLogsBtn" class="hover:text-cyan-400 transition-colors text-[10px]">Clear Logs</button>
              <button id="reloadSandboxBtn" class="hover:text-emerald-400 transition-colors" title="Hard Refresh Sandbox">
                <i data-lucide="refresh-cw" class="w-3 h-3"></i>
              </button>
            </div>
          </div>

          <!-- Runner Viewport Split (Iframe Preview & Console logs) -->
          <div class="flex-1 flex min-h-0 bg-black/40">
            <!-- Live Iframe Renderer -->
            <div class="flex-1 h-full relative border-r border-border/60 overflow-hidden">
              <iframe id="sandboxFrame" sandbox="allow-scripts allow-modals" class="w-full h-full border-none bg-black/90"></iframe>
            </div>
            
            <!-- Real-time Console Log Terminal -->
            <div id="consoleOutput" class="w-64 h-full p-2 overflow-y-auto font-mono text-[11px] text-slate-400 space-y-1 bg-[#060911]/90 select-text">
              <div class="text-cyan-500/70 font-semibold">[SYSLOG] Runtime initialized. Ready for execution.</div>
            </div>
          </div>
        </div>

      </div>
    </section>

    <!-- HORIZONTAL SPLIT DRAGGER HANDLE -->
    <div id="splitDivider" class="w-2 bg-[#0d1424] hover:bg-cyan-500/80 cursor-col-resize z-20 flex items-center justify-center transition-colors shadow-lg border-x border-border/40 select-none group">
      <div class="w-0.5 h-8 bg-slate-600 group-hover:bg-white rounded-full transition-colors"></div>
    </div>

    <!-- RIGHT PANEL: INFINITE COLLABORATIVE CANVAS -->
    <section id="rightPanel" class="flex-1 flex flex-col relative h-full min-w-0 bg-[#090d16] overflow-hidden">
      
      <!-- Canvas Toolbar Overlay (Top Float) -->
      <div class="absolute top-3 left-1/2 -translate-x-1/2 z-20 bg-surface/90 border border-border/80 backdrop-blur-md px-2 py-1.5 rounded-xl shadow-2xl flex items-center gap-1">
        <button data-tool="select" class="canvas-tool-btn active-tool p-2 rounded-lg text-slate-400 hover:text-white transition-all" title="Select / Move (V)">
          <i data-lucide="mouse-pointer" class="w-4 h-4"></i>
        </button>
        <button data-tool="hand" class="canvas-tool-btn p-2 rounded-lg text-slate-400 hover:text-white transition-all" title="Pan Canvas (H / Space)">
          <i data-lucide="hand" class="w-4 h-4"></i>
        </button>
        <div class="w-[1px] h-5 bg-border my-auto mx-1"></div>
        <button data-tool="rectangle" class="canvas-tool-btn p-2 rounded-lg text-slate-400 hover:text-white transition-all" title="Rectangle (R)">
          <i data-lucide="square" class="w-4 h-4"></i>
        </button>
        <button data-tool="circle" class="canvas-tool-btn p-2 rounded-lg text-slate-400 hover:text-white transition-all" title="Circle / Node (O)">
          <i data-lucide="circle" class="w-4 h-4"></i>
        </button>
        <button data-tool="sticky" class="canvas-tool-btn p-2 rounded-lg text-slate-400 hover:text-white transition-all" title="Sticky Note (S)">
          <i data-lucide="sticky-note" class="w-4 h-4 text-amber-400"></i>
        </button>
        <button data-tool="arrow" class="canvas-tool-btn p-2 rounded-lg text-slate-400 hover:text-white transition-all" title="Connector Arrow (A)">
          <i data-lucide="arrow-up-right" class="w-4 h-4 text-cyan-400"></i>
        </button>
        <button data-tool="pencil" class="canvas-tool-btn p-2 rounded-lg text-slate-400 hover:text-white transition-all" title="Freehand Pencil (P)">
          <i data-lucide="pencil" class="w-4 h-4"></i>
        </button>
        <div class="w-[1px] h-5 bg-border my-auto mx-1"></div>
        
        <!-- Palette Colors -->
        <div class="flex items-center gap-1 px-1" id="canvasColorPalette">
          <button class="color-dot w-4 h-4 rounded-full bg-cyan-400 ring-2 ring-white/80 ring-offset-1 ring-offset-[#090d16]" data-color="#06b6d4"></button>
          <button class="color-dot w-4 h-4 rounded-full bg-indigo-500 hover:scale-110 transition-transform" data-color="#6366f1"></button>
          <button class="color-dot w-4 h-4 rounded-full bg-emerald-400 hover:scale-110 transition-transform" data-color="#10b981"></button>
          <button class="color-dot w-4 h-4 rounded-full bg-amber-400 hover:scale-110 transition-transform" data-color="#f59e0b"></button>
          <button class="color-dot w-4 h-4 rounded-full bg-rose-500 hover:scale-110 transition-transform" data-color="#f43f5e"></button>
          <button class="color-dot w-4 h-4 rounded-full bg-slate-200 hover:scale-110 transition-transform" data-color="#e2e8f0"></button>
        </div>

        <div class="w-[1px] h-5 bg-border my-auto mx-1"></div>
        <button id="clearCanvasBtn" class="p-2 rounded-lg text-rose-400 hover:bg-rose-500/20 transition-all" title="Clear All Canvas Elements">
          <i data-lucide="trash-2" class="w-4 h-4"></i>
        </button>
      </div>

      <!-- Zoom & Canvas Controls Overlay (Bottom Right) -->
      <div class="absolute bottom-4 right-4 z-20 bg-surface/90 border border-border/80 backdrop-blur-md px-3 py-1.5 rounded-xl shadow-xl flex items-center gap-2 text-xs font-mono text-slate-300">
        <button id="zoomOutBtn" class="p-1 hover:text-cyan-400 transition-colors"><i data-lucide="minus" class="w-3.5 h-3.5"></i></button>
        <span id="zoomLevelText" class="w-12 text-center select-none font-bold text-cyan-300">100%</span>
        <button id="zoomInBtn" class="p-1 hover:text-cyan-400 transition-colors"><i data-lucide="plus" class="w-3.5 h-3.5"></i></button>
        <div class="w-[1px] h-4 bg-border my-auto mx-0.5"></div>
        <button id="resetViewBtn" class="p-1 hover:text-white transition-colors" title="Reset Camera Transform"><i data-lucide="maximize-2" class="w-3.5 h-3.5"></i></button>
      </div>

      <!-- Infinite Canvas Stage Element -->
      <div id="canvasContainer" class="flex-1 w-full h-full relative cursor-crosshair overflow-hidden touch-none">
        <canvas id="infiniteCanvas" class="w-full h-full block"></canvas>
        <!-- Remote Live Cursor Overlays for Infinite Canvas -->
        <div id="canvasPeerCursorsLayer" class="absolute inset-0 pointer-events-none z-10"></div>
      </div>

    </section>
  </div>

  <!-- FOOTER STATUS BAR -->
  <footer class="h-7 bg-[#070b13] border-t border-border/60 px-4 flex items-center justify-between text-[11px] font-mono text-slate-500 shrink-0 select-none z-30">
    <div class="flex items-center gap-4">
      <span class="flex items-center gap-1.5 text-cyan-400">
        <i data-lucide="radio" class="w-3 h-3 animate-pulse"></i>
        <span id="networkStatusText">BroadcastChannel Sync Online</span>
      </span>
      <span>Channel: <span class="text-slate-300 font-semibold">synapse-matrix-v1</span></span>
      <span id="canvasObjectCountText" class="text-slate-400">Shapes: 6 | Code lines: 48</span>
    </div>
    <div class="flex items-center gap-4">
      <span>Shortcuts: <kbd class="px-1 py-0.5 bg-surface rounded text-slate-300">Ctrl+Enter</kbd> Run | <kbd class="px-1 py-0.5 bg-surface rounded text-slate-300">Space</kbd> Pan</span>
      <span class="text-indigo-400">WebGL + WebAudio Enabled</span>
    </div>
  </footer>

  <script src="script.js" defer></script>
</body>
</html>`
        },
        {
          id: `f_synapse_script_${now}`,
          name: 'script.js',
          language: 'javascript',
          lastModified: now,
          content: `// --- PROCEDURAL WEB AUDIO SYNTHESIZER ---
class AudioFXEngine {
  constructor() {
    this.ctx = null;
  }
  init() {
    if (!this.ctx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) this.ctx = new AudioContext();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }
  playBoop(freq = 440, type = 'sine', duration = 0.08, gainVal = 0.05) {
    try {
      this.init();
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(freq * 0.5, this.ctx.currentTime + duration);
      gain.gain.setValueAtTime(gainVal, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + duration);
    } catch (e) {}
  }
  playExecuteChime() {
    try {
      this.init();
      [523.25, 659.25, 783.99, 1046.50].forEach((freq, idx) => {
        setTimeout(() => this.playBoop(freq, 'triangle', 0.15, 0.08), idx * 45);
      });
    } catch (e) {}
  }
}
const audioFX = new AudioFXEngine();

// --- CODE TEMPLATES DATABASE ---
const CODE_TEMPLATES = {
  threejs: \`// Interactive 3D Orbit Scene
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(65, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });

renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
document.body.style.margin = '0';
document.body.style.overflow = 'hidden';
document.body.style.background = '#060911';
document.body.appendChild(renderer.domElement);

// Add Glowing Torus Knot Geometry
const geometry = new THREE.TorusKnotGeometry(1.8, 0.45, 128, 32);
const material = new THREE.MeshStandardMaterial({
  color: 0x06b6d4,
  wireframe: true,
  emissive: 0x6366f1,
  emissiveIntensity: 0.6,
  roughness: 0.2
});
const mesh = new THREE.Mesh(geometry, material);
scene.add(mesh);

// Lights
const light = new THREE.PointLight(0x00ffff, 2, 50);
light.position.set(5, 5, 5);
scene.add(light);
scene.add(new THREE.AmbientLight(0x1e293b, 1.5));

camera.position.z = 6;

// Render Loop
function animate() {
  requestAnimationFrame(animate);
  mesh.rotation.x += 0.008;
  mesh.rotation.y += 0.012;
  renderer.render(scene, camera);
}
animate();
console.log("✨ 3D Three.js Torus scene rendered successfully!");\`,

  particles: \`// High-density Interactive Particle Field
const canvas = document.createElement('canvas');
const ctx = canvas.getContext('2d');
document.body.style.margin = '0';
document.body.style.background = '#090d16';
document.body.appendChild(canvas);

let w = canvas.width = window.innerWidth;
let h = canvas.height = window.innerHeight;
const particles = [];
const COUNT = 160;

for (let i = 0; i < COUNT; i++) {
  particles.push({
    x: Math.random() * w,
    y: Math.random() * h,
    vx: (Math.random() - 0.5) * 1.5,
    vy: (Math.random() - 0.5) * 1.5,
    size: Math.random() * 2.5 + 1,
    hue: Math.random() * 60 + 170
  });
}

function loop() {
  ctx.fillStyle = 'rgba(9, 13, 22, 0.2) ';
  ctx.fillRect(0, 0, w, h);

  particles.forEach((p, idx) => {
    p.x += p.vx;
    p.y += p.vy;
    if (p.x < 0 || p.x > w) p.vx *= -1;
    if (p.y < 0 || p.y > h) p.vy *= -1;

    ctx.beginPath();
    ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
    ctx.fillStyle = \\\`hsl(\\\${p.hue}, 90%, 65%)\\\`;
    ctx.fill();

    // Connect nearest nodes
    for (let j = idx + 1; j < particles.length; j++) {
      const p2 = particles[j];
      const dx = p.x - p2.x;
      const dy = p.y - p2.y;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 85) {
        ctx.strokeStyle = \\\`rgba(6, 182, 212, \\\${1 - dist / 85})\\\`;
        ctx.lineWidth = 0.8;
        ctx.beginPath();
        ctx.moveTo(p.x, p.y);
        ctx.lineTo(p2.x, p2.y);
        ctx.stroke();
      }
    }
  });
  requestAnimationFrame(loop);
}
loop();
console.log("✨ Particle Engine active with", COUNT, "nodes.");\`,

  audioSynth: \`// Dynamic Synthwave Canvas Audio Node Engine
document.body.innerHTML = \\\`
<div style="color:white;font-family:sans-serif;text-align:center;padding-top:20px;">
  <h2 style="color:#38bdf8;margin-bottom:8px;">Synapse Audio Oscillator Matrix</h2>
  <button id="playSynth" style="padding:12px 24px;border-radius:8px;background:#6366f1;color:white;font-weight:bold;border:none;cursor:pointer;">▶ Trigger Chord Sequence</button>
  <div id="synthLogs" style="margin-top:20px;font-family:monospace;color:#a5f3fc;font-size:12px;">Press trigger to synthesize multi-voice chords</div>
</div>\\\`;

document.getElementById('playSynth').onclick = () => {
  const ctx = new (window.AudioContext || window.webkitAudioContext)();
  const freqs = [261.63, 329.63, 392.00, 523.25]; // C Major Chord
  freqs.forEach((f, i) => {
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(f, ctx.currentTime + i * 0.1);
    g.gain.setValueAtTime(0.08, ctx.currentTime + i * 0.1);
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.1 + 1.2);
    osc.connect(g);
    g.connect(ctx.destination);
    osc.start(ctx.currentTime + i * 0.1);
    osc.stop(ctx.currentTime + i * 0.1 + 1.3);
  });
  document.getElementById('synthLogs').innerText = "Polyphonic chord triggered: C4 - E4 - G4 - C5";
  console.log("Synth Polyphony Chord dispatched");
};\`,

  neonDashboard: \`// Cyberpunk Analytics Widget Stream
document.body.innerHTML = \\\`
<div style="padding:24px;background:#090d16;color:#f8fafc;font-family:sans-serif;height:100vh;box-sizing:border-box;">
  <div style="display:flex;justify-content:space-between;border-bottom:1px solid #1e293b;padding-bottom:12px;">
    <span style="color:#38bdf8;font-weight:bold;">MATRIX CLOUD TELEMETRY</span>
    <span style="color:#34d399;">● LIVE 100% HEALTH</span>
  </div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:16px;">
    <div style="background:#111827;padding:16px;border-radius:12px;border:1px solid #1e293b;">
      <div style="font-size:12px;color:#94a3b8;">SYNAPSE BANDWIDTH</div>
      <div style="font-size:26px;font-weight:bold;color:#06b6d4;margin-top:4px;">4.82 GB/s</div>
    </div>
    <div style="background:#111827;padding:16px;border-radius:12px;border:1px solid #1e293b;">
      <div style="font-size:12px;color:#94a3b8;">ACTIVE NODES</div>
      <div style="font-size:26px;font-weight:bold;color:#10b981;margin-top:4px;">1,409 Connected</div>
    </div>
  </div>
</div>\\\`;
console.log("Telemetry widget initialized.");\`
};

// --- GLOBAL STATE & PERSISTENCE ---
const STATE = {
  files: {
    'app.js': CODE_TEMPLATES.threejs,
    'index.html': \`<!DOCTYPE html>\\n<html>\\n<head>\\n  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"><\\/script>\\n<\\/head>\\n<body><\\/body>\\n<\\/html>\`,
    'style.css': \`body { margin: 0; background: #060911; font-family: sans-serif; }\`
  },
  currentFile: 'app.js',
  userId: 'user_' + Math.random().toString(36).substr(2, 6),
  userName: 'Dev_' + Math.floor(Math.random() * 899 + 100),
  userColor: ['#06b6d4', '#6366f1', '#10b981', '#f59e0b', '#ec4899'][Math.floor(Math.random() * 5)],
  
  // Canvas State
  activeTool: 'select',
  activeColor: '#06b6d4',
  zoom: 1,
  panX: 0,
  panY: 0,
  isPanning: false,
  lastMousePos: { x: 0, y: 0 },
  shapes: [
    {
      id: 's_1',
      type: 'sticky',
      x: 120,
      y: 100,
      width: 170,
      height: 120,
      color: '#f59e0b',
      text: '📌 Architecture Note:\\n- Real-time WebRTC/Broadcast Sync\\n- Interactive Three.js Preview\\n- Scalable Vector Canvas'
    },
    {
      id: 's_2',
      type: 'rectangle',
      x: 360,
      y: 90,
      width: 180,
      height: 90,
      color: '#06b6d4',
      label: 'Core State Engine'
    },
    {
      id: 's_3',
      type: 'circle',
      x: 640,
      y: 135,
      radius: 50,
      color: '#10b981',
      label: 'WebGL Sandbox'
    },
    {
      id: 's_4',
      type: 'arrow',
      startX: 540,
      startY: 135,
      endX: 590,
      endY: 135,
      color: '#6366f1'
    }
  ],
  selectedShapeId: null,
  isDrawing: false,
  tempShape: null,
  freehandPoints: [],
  remotePeers: {}
};

// --- REAL-TIME BROADCASTCHANNEL SYNC MATRIX ---
const SYNC_CHANNEL = new BroadcastChannel('synapse_collaborative_matrix');

function broadcastEvent(type, payload) {
  try {
    const message = {
      senderId: STATE.userId,
      senderName: STATE.userName,
      senderColor: STATE.userColor,
      timestamp: Date.now(),
      type,
      payload
    };
    SYNC_CHANNEL.postMessage(message);
  } catch(e) {}
}

// Listen for remote events
SYNC_CHANNEL.onmessage = (event) => {
  const data = event.data;
  if (!data || data.senderId === STATE.userId) return;

  // Update peer presence
  STATE.remotePeers[data.senderId] = {
    name: data.senderName,
    color: data.senderColor,
    lastSeen: Date.now(),
    cursor: data.type === 'CURSOR_MOVE' ? data.payload : (STATE.remotePeers[data.senderId]?.cursor || { x: 0, y: 0, surface: 'canvas' })
  };
  updatePeerIndicators();

  switch (data.type) {
    case 'CODE_CHANGE':
      if (STATE.files[data.payload.file] !== undefined) {
        STATE.files[data.payload.file] = data.payload.code;
        if (STATE.currentFile === data.payload.file) {
          const editor = document.getElementById('codeEditor');
          if (editor && editor.value !== data.payload.code) {
            const start = editor.selectionStart;
            const end = editor.selectionEnd;
            editor.value = data.payload.code;
            editor.setSelectionRange(start, end);
            updateLineNumbers();
          }
        }
      }
      break;
    case 'CANVAS_SHAPES_UPDATE':
      STATE.shapes = data.payload.shapes;
      drawCanvas();
      break;
    case 'CURSOR_MOVE':
      renderRemoteCursors();
      break;
  }
};

// --- PEER & BOT SIMULATOR ---
function updatePeerIndicators() {
  const now = Date.now();
  const activePeers = Object.values(STATE.remotePeers).filter(p => now - p.lastSeen < 12000);
  const peerCountBadge = document.getElementById('peerCountBadge');
  const p1 = document.getElementById('peerBadge1');
  const p2 = document.getElementById('peerBadge2');

  const total = activePeers.length + 1;
  if (peerCountBadge) peerCountBadge.innerText = \`\${total} \${total === 1 ? 'Dev' : 'Devs'}\`;

  if (activePeers.length >= 1 && p1) {
    p1.classList.remove('hidden');
    p1.innerText = activePeers[0].name.substring(0, 2).toUpperCase();
    p1.style.backgroundColor = activePeers[0].color;
  } else if (p1) {
    p1.classList.add('hidden');
  }

  if (activePeers.length >= 2 && p2) {
    p2.classList.remove('hidden');
    p2.innerText = activePeers[1].name.substring(0, 2).toUpperCase();
    p2.style.backgroundColor = activePeers[1].color;
  } else if (p2) {
    p2.classList.add('hidden');
  }
}

function spawnSimulatedBotPeer() {
  const botId = 'bot_' + Math.random().toString(36).substr(2, 5);
  const botNames = ['Sarah (Design)', 'Alex (WebGL)', 'Chen (Kernel)', 'Taylor (VFX)'];
  const name = botNames[Math.floor(Math.random() * botNames.length)];
  const color = ['#f43f5e', '#a855f7', '#3b82f6', '#10b981'][Math.floor(Math.random() * 4)];

  let botX = 400 + (Math.random() - 0.5) * 200;
  let botY = 250 + (Math.random() - 0.5) * 150;

  STATE.remotePeers[botId] = {
    name,
    color,
    lastSeen: Date.now(),
    cursor: { x: botX, y: botY, surface: 'canvas' }
  };
  updatePeerIndicators();
  renderRemoteCursors();
  audioFX.playBoop(620, 'sine', 0.1, 0.05);

  // Add a sample bot sticky note
  const botSticky = {
    id: 's_' + Date.now(),
    type: 'sticky',
    x: botX,
    y: botY,
    width: 160,
    height: 100,
    color,
    text: \`⚡ \${name}: Synced live workspace matrix.\`
  };
  STATE.shapes.push(botSticky);
  drawCanvas();
  broadcastEvent('CANVAS_SHAPES_UPDATE', { shapes: STATE.shapes });

  // Move bot cursor intermittently
  let step = 0;
  const botInterval = setInterval(() => {
    if (step++ > 25) {
      clearInterval(botInterval);
      delete STATE.remotePeers[botId];
      updatePeerIndicators();
      renderRemoteCursors();
      return;
    }
    botX += (Math.random() - 0.5) * 35;
    botY += (Math.random() - 0.5) * 35;
    if (STATE.remotePeers[botId]) {
      STATE.remotePeers[botId].cursor = { x: botX, y: botY, surface: 'canvas' };
      STATE.remotePeers[botId].lastSeen = Date.now();
      renderRemoteCursors();
    }
  }, 400);
}

// --- UI & CODE EDITOR CONTROLLER ---
function setupCodeEditor() {
  const editor = document.getElementById('codeEditor');
  const lineGutter = document.getElementById('lineNumbers');
  if (!editor) return;

  editor.value = STATE.files[STATE.currentFile] || '';
  updateLineNumbers();

  editor.addEventListener('input', () => {
    STATE.files[STATE.currentFile] = editor.value;
    updateLineNumbers();
    broadcastEvent('CODE_CHANGE', {
      file: STATE.currentFile,
      code: editor.value
    });
  });

  // Tab indent key support & shortcuts
  editor.addEventListener('keydown', (e) => {
    if (e.key === 'Tab') {
      e.preventDefault();
      const start = editor.selectionStart;
      const end = editor.selectionEnd;
      editor.value = editor.value.substring(0, start) + '  ' + editor.value.substring(end);
      editor.selectionStart = editor.selectionEnd = start + 2;
      STATE.files[STATE.currentFile] = editor.value;
      updateLineNumbers();
    } else if (e.ctrlKey && e.key === 'Enter') {
      e.preventDefault();
      executeSandboxCode();
    }
  });

  // Sync scroll line numbers with textarea
  editor.addEventListener('scroll', () => {
    if (lineGutter) lineGutter.scrollTop = editor.scrollTop;
  });

  // File Tab Switching
  const tabs = document.querySelectorAll('.editor-tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active-editor-tab', 'text-cyan-400', 'bg-surface'));
      tab.classList.add('active-editor-tab', 'text-cyan-400', 'bg-surface');
      STATE.currentFile = tab.dataset.file;
      editor.value = STATE.files[STATE.currentFile] || '';
      updateLineNumbers();
      audioFX.playBoop(520, 'triangle', 0.05, 0.03);
    });
  });

  // Template Selector
  const templatePicker = document.getElementById('templatePicker');
  if (templatePicker) {
    templatePicker.addEventListener('change', (e) => {
      const selected = e.target.value;
      if (CODE_TEMPLATES[selected]) {
        STATE.files['app.js'] = CODE_TEMPLATES[selected];
        if (STATE.currentFile === 'app.js') {
          editor.value = CODE_TEMPLATES[selected];
          updateLineNumbers();
        }
        broadcastEvent('CODE_CHANGE', { file: 'app.js', code: CODE_TEMPLATES[selected] });
        executeSandboxCode();
      }
    });
  }
}

function updateLineNumbers() {
  const editor = document.getElementById('codeEditor');
  const lineGutter = document.getElementById('lineNumbers');
  if (!editor || !lineGutter) return;
  const lines = editor.value.split('\\n').length;
  let html = '';
  for (let i = 1; i <= lines; i++) {
    html += \`<div>\${i}</div>\`;
  }
  lineGutter.innerHTML = html;
  
  const countText = document.getElementById('canvasObjectCountText');
  if (countText) {
    countText.innerText = \`Shapes: \${STATE.shapes.length} | Code lines: \${lines}\`;
  }
}

// --- SANDBOX RUNNER & CONSOLE LOGGER ---
function executeSandboxCode() {
  audioFX.playExecuteChime();
  const frame = document.getElementById('sandboxFrame');
  const logContainer = document.getElementById('consoleOutput');
  if (logContainer) {
    logContainer.innerHTML = \`<div class="text-cyan-400 font-semibold">⚡ Sandbox hot-reloaded at \${new Date().toLocaleTimeString()}</div>\`;
  }
  if (!frame) return;

  const jsCode = STATE.files['app.js'] || '';
  const cssCode = STATE.files['style.css'] || '';
  const htmlCode = STATE.files['index.html'] || '<!DOCTYPE html><html><body></body></html>';

  // Custom script injection to intercept console.log and errors
  const injection = \`
    <style>\${cssCode}</style>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"><\\/script>
    <script>
      (function() {
        const _log = console.log;
        const _error = console.error;
        const _warn = console.warn;
        function send(type, args) {
          window.parent.postMessage({
            source: 'SANDBOX_CONSOLE',
            type: type,
            msg: Array.from(args).map(a => typeof a === 'object' ? JSON.stringify(a) : a).join(' ')
          }, '*');
        }
        console.log = function() { send('log', arguments); _log.apply(console, arguments); };
        console.error = function() { send('error', arguments); _error.apply(console, arguments); };
        console.warn = function() { send('warn', arguments); _warn.apply(console, arguments); };
        window.onerror = function(msg, url, line) { send('error', [msg + ' (Line ' + line + ')']); };
      })();
    <\\/script>
  \`;

  const fullDoc = htmlCode.replace('</head>', \`\${injection}</head>\`) + \`\\n<script>\\ntry {\\n\${jsCode}\\n} catch(err) { console.error(err.message); }\\n<\\/script>\`;
  
  frame.srcdoc = fullDoc;
}

window.addEventListener('message', (e) => {
  if (e.data && e.data.source === 'SANDBOX_CONSOLE') {
    const consoleOutput = document.getElementById('consoleOutput');
    if (!consoleOutput) return;
    const row = document.createElement('div');
    if (e.data.type === 'error') {
      row.className = 'text-rose-400 font-medium bg-rose-950/30 px-1 rounded border-l-2 border-rose-500';
      row.innerText = \`✖ \${e.data.msg}\`;
    } else if (e.data.type === 'warn') {
      row.className = 'text-amber-300 font-medium';
      row.innerText = \`▲ \${e.data.msg}\`;
    } else {
      row.className = 'text-slate-300';
      row.innerText = \`› \${e.data.msg}\`;
    }
    consoleOutput.appendChild(row);
    consoleOutput.scrollTop = consoleOutput.scrollHeight;
  }
});

// --- INFINITE COLLABORATIVE VECTOR CANVAS ENGINE ---
let canvas, ctx;

function setupInfiniteCanvas() {
  canvas = document.getElementById('infiniteCanvas');
  if (!canvas) return;
  ctx = canvas.getContext('2d');
  resizeCanvas();
  window.addEventListener('resize', resizeCanvas);

  // Canvas Toolbar setup
  const toolButtons = document.querySelectorAll('.canvas-tool-btn');
  toolButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      toolButtons.forEach(b => b.classList.remove('active-tool'));
      btn.classList.add('active-tool');
      STATE.activeTool = btn.dataset.tool;
      audioFX.playBoop(480, 'sine', 0.04, 0.02);
    });
  });

  // Color selection palette
  const colorDots = document.querySelectorAll('.color-dot');
  colorDots.forEach(dot => {
    dot.addEventListener('click', () => {
      colorDots.forEach(d => d.classList.remove('ring-2', 'ring-white/80', 'ring-offset-1', 'ring-offset-[#090d16]'));
      dot.classList.add('ring-2', 'ring-white/80', 'ring-offset-1', 'ring-offset-[#090d16]');
      STATE.activeColor = dot.dataset.color;
    });
  });

  // Canvas Zoom Buttons
  const zoomIn = document.getElementById('zoomInBtn');
  const zoomOut = document.getElementById('zoomOutBtn');
  const resetView = document.getElementById('resetViewBtn');
  const clearCanvas = document.getElementById('clearCanvasBtn');

  if (zoomIn) zoomIn.onclick = () => setCanvasZoom(STATE.zoom * 1.15);
  if (zoomOut) zoomOut.onclick = () => setCanvasZoom(STATE.zoom / 1.15);
  if (resetView) {
    resetView.onclick = () => {
      STATE.zoom = 1;
      STATE.panX = 0;
      STATE.panY = 0;
      updateZoomDisplay();
      drawCanvas();
    };
  }

  // Clear canvas button
  if (clearCanvas) {
    clearCanvas.onclick = () => {
      STATE.shapes = [];
      STATE.selectedShapeId = null;
      drawCanvas();
      broadcastEvent('CANVAS_SHAPES_UPDATE', { shapes: STATE.shapes });
      audioFX.playBoop(300, 'sawtooth', 0.1, 0.04);
    };
  }

  // Pointer & Mouse Events for Canvas
  const container = document.getElementById('canvasContainer');
  if (container) {
    container.addEventListener('pointerdown', handleCanvasPointerDown);
    window.addEventListener('pointermove', handleCanvasPointerMove);
    window.addEventListener('pointerup', handleCanvasPointerUp);
    container.addEventListener('wheel', handleCanvasWheel, { passive: false });
  }

  drawCanvas();
}

function resizeCanvas() {
  const container = document.getElementById('canvasContainer');
  if (!container || !canvas || !ctx) return;
  canvas.width = container.clientWidth * window.devicePixelRatio;
  canvas.height = container.clientHeight * window.devicePixelRatio;
  ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
  drawCanvas();
}

function setCanvasZoom(newZoom) {
  STATE.zoom = Math.max(0.2, Math.min(3.5, newZoom));
  updateZoomDisplay();
  drawCanvas();
}

function updateZoomDisplay() {
  const text = document.getElementById('zoomLevelText');
  if (text) text.innerText = \`\${Math.round(STATE.zoom * 100)}%\`;
}

function screenToWorld(sx, sy) {
  if (!canvas) return { x: 0, y: 0 };
  const rect = canvas.getBoundingClientRect();
  const x = (sx - rect.left - STATE.panX) / STATE.zoom;
  const y = (sy - rect.top - STATE.panY) / STATE.zoom;
  return { x, y };
}

// --- CANVAS INTERACTION HANDLERS ---
let activeDragShape = null;
let dragOffset = { x: 0, y: 0 };

function handleCanvasPointerDown(e) {
  const pos = screenToWorld(e.clientX, e.clientY);
  STATE.lastMousePos = { x: e.clientX, y: e.clientY };

  if (STATE.activeTool === 'hand' || e.spaceKey || e.button === 1) {
    STATE.isPanning = true;
    return;
  }

  if (STATE.activeTool === 'select') {
    // Check shape hit reverse order (top to bottom)
    activeDragShape = null;
    for (let i = STATE.shapes.length - 1; i >= 0; i--) {
      const s = STATE.shapes[i];
      if (s.type === 'rectangle' || s.type === 'sticky') {
        if (pos.x >= s.x && pos.x <= s.x + s.width && pos.y >= s.y && pos.y <= s.y + s.height) {
          activeDragShape = s;
          STATE.selectedShapeId = s.id;
          dragOffset = { x: pos.x - s.x, y: pos.y - s.y };
          break;
        }
      } else if (s.type === 'circle') {
        const dx = pos.x - s.x;
        const dy = pos.y - s.y;
        if (Math.sqrt(dx * dx + dy * dy) <= s.radius) {
          activeDragShape = s;
          STATE.selectedShapeId = s.id;
          dragOffset = { x: pos.x - s.x, y: pos.y - s.y };
          break;
        }
      }
    }
    if (!activeDragShape) {
      STATE.selectedShapeId = null;
    }
    drawCanvas();
    return;
  }

  // Creating new shapes
  STATE.isDrawing = true;
  if (STATE.activeTool === 'rectangle') {
    STATE.tempShape = { id: 's_' + Date.now(), type: 'rectangle', x: pos.x, y: pos.y, width: 0, height: 0, color: STATE.activeColor, label: 'Component Node' };
  } else if (STATE.activeTool === 'circle') {
    STATE.tempShape = { id: 's_' + Date.now(), type: 'circle', x: pos.x, y: pos.y, radius: 0, color: STATE.activeColor, label: 'Vertex' };
  } else if (STATE.activeTool === 'sticky') {
    const noteText = prompt('Enter Sticky Note text:', 'New Collaborative Note');
    if (noteText) {
      const note = { id: 's_' + Date.now(), type: 'sticky', x: pos.x, y: pos.y, width: 170, height: 110, color: STATE.activeColor, text: noteText };
      STATE.shapes.push(note);
      broadcastEvent('CANVAS_SHAPES_UPDATE', { shapes: STATE.shapes });
      audioFX.playBoop(540, 'sine', 0.08, 0.04);
    }
    STATE.isDrawing = false;
    drawCanvas();
  } else if (STATE.activeTool === 'arrow') {
    STATE.tempShape = { id: 's_' + Date.now(), type: 'arrow', startX: pos.x, startY: pos.y, endX: pos.x, endY: pos.y, color: STATE.activeColor };
  } else if (STATE.activeTool === 'pencil') {
    STATE.freehandPoints = [pos];
    STATE.tempShape = { id: 's_' + Date.now(), type: 'freehand', points: STATE.freehandPoints, color: STATE.activeColor };
  }
}

function handleCanvasPointerMove(e) {
  // Broadcast local cursor position
  const worldPos = screenToWorld(e.clientX, e.clientY);
  broadcastEvent('CURSOR_MOVE', { x: worldPos.x, y: worldPos.y, surface: 'canvas' });

  if (STATE.isPanning) {
    const dx = e.clientX - STATE.lastMousePos.x;
    const dy = e.clientY - STATE.lastMousePos.y;
    STATE.panX += dx;
    STATE.panY += dy;
    STATE.lastMousePos = { x: e.clientX, y: e.clientY };
    drawCanvas();
    return;
  }

  if (activeDragShape) {
    activeDragShape.x = worldPos.x - dragOffset.x;
    activeDragShape.y = worldPos.y - dragOffset.y;
    drawCanvas();
    return;
  }

  if (STATE.isDrawing && STATE.tempShape) {
    if (STATE.tempShape.type === 'rectangle') {
      STATE.tempShape.width = worldPos.x - STATE.tempShape.x;
      STATE.tempShape.height = worldPos.y - STATE.tempShape.y;
    } else if (STATE.tempShape.type === 'circle') {
      const dx = worldPos.x - STATE.tempShape.x;
      const dy = worldPos.y - STATE.tempShape.y;
      STATE.tempShape.radius = Math.sqrt(dx * dx + dy * dy);
    } else if (STATE.tempShape.type === 'arrow') {
      STATE.tempShape.endX = worldPos.x;
      STATE.tempShape.endY = worldPos.y;
    } else if (STATE.tempShape.type === 'freehand') {
      STATE.freehandPoints.push(worldPos);
    }
    drawCanvas();
  }
}

function handleCanvasPointerUp() {
  if (STATE.isPanning) {
    STATE.isPanning = false;
  }
  if (activeDragShape) {
    activeDragShape = null;
    broadcastEvent('CANVAS_SHAPES_UPDATE', { shapes: STATE.shapes });
  }
  if (STATE.isDrawing && STATE.tempShape) {
    // Normalize dimensions
    if (STATE.tempShape.type === 'rectangle') {
      if (STATE.tempShape.width < 0) {
        STATE.tempShape.x += STATE.tempShape.width;
        STATE.tempShape.width = Math.abs(STATE.tempShape.width);
      }
      if (STATE.tempShape.height < 0) {
        STATE.tempShape.y += STATE.tempShape.height;
        STATE.tempShape.height = Math.abs(STATE.tempShape.height);
      }
      if (STATE.tempShape.width > 5 && STATE.tempShape.height > 5) {
        STATE.shapes.push(STATE.tempShape);
      }
    } else if (STATE.tempShape.type === 'circle') {
      if (STATE.tempShape.radius > 5) {
        STATE.shapes.push(STATE.tempShape);
      }
    } else if (STATE.tempShape.type === 'arrow' || STATE.tempShape.type === 'freehand') {
      STATE.shapes.push(STATE.tempShape);
    }
    
    STATE.isDrawing = false;
    STATE.tempShape = null;
    STATE.freehandPoints = [];
    drawCanvas();
    broadcastEvent('CANVAS_SHAPES_UPDATE', { shapes: STATE.shapes });
    audioFX.playBoop(440, 'triangle', 0.05, 0.03);
  }
}

function handleCanvasWheel(e) {
  e.preventDefault();
  const zoomFactor = e.deltaY < 0 ? 1.08 : 0.92;
  const rect = canvas.getBoundingClientRect();
  const mouseX = e.clientX - rect.left;
  const mouseY = e.clientY - rect.top;

  // Zoom centered on cursor position
  const newZoom = Math.max(0.2, Math.min(3.5, STATE.zoom * zoomFactor));
  STATE.panX = mouseX - (mouseX - STATE.panX) * (newZoom / STATE.zoom);
  STATE.panY = mouseY - (mouseY - STATE.panY) * (newZoom / STATE.zoom);
  STATE.zoom = newZoom;
  updateZoomDisplay();
  drawCanvas();
}

// --- CANVAS RENDERING PIPELINE ---
function drawCanvas() {
  if (!ctx || !canvas) return;
  const w = canvas.width / window.devicePixelRatio;
  const h = canvas.height / window.devicePixelRatio;

  ctx.clearRect(0, 0, w, h);

  ctx.save();
  // World transformation matrix
  ctx.translate(STATE.panX, STATE.panY);
  ctx.scale(STATE.zoom, STATE.zoom);

  // Draw Infinite Grid Dots
  drawGridDots(w, h);

  // Render Shapes
  const allShapes = [...STATE.shapes];
  if (STATE.tempShape) allShapes.push(STATE.tempShape);

  allShapes.forEach(shape => {
    ctx.save();
    if (shape.type === 'rectangle') {
      ctx.fillStyle = shape.color + '22';
      ctx.strokeStyle = shape.color;
      ctx.lineWidth = shape.id === STATE.selectedShapeId ? 3 : 2;
      ctx.beginPath();
      ctx.roundRect(shape.x, shape.y, shape.width, shape.height, 8);
      ctx.fill();
      ctx.stroke();
      if (shape.label) {
        ctx.fillStyle = '#ffffff';
        ctx.font = '12px sans-serif';
        ctx.fillText(shape.label, shape.x + 10, shape.y + 24);
      }
    } else if (shape.type === 'circle') {
      ctx.fillStyle = shape.color + '22';
      ctx.strokeStyle = shape.color;
      ctx.lineWidth = shape.id === STATE.selectedShapeId ? 3 : 2;
      ctx.beginPath();
      ctx.arc(shape.x, shape.y, shape.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      if (shape.label) {
        ctx.fillStyle = '#ffffff';
        ctx.font = '11px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(shape.label, shape.x, shape.y + 4);
      }
    } else if (shape.type === 'sticky') {
      // Sticky Note Card
      ctx.fillStyle = shape.color + '2a';
      ctx.strokeStyle = shape.color;
      ctx.lineWidth = shape.id === STATE.selectedShapeId ? 2.5 : 1.5;
      ctx.beginPath();
      ctx.roundRect(shape.x, shape.y, shape.width, shape.height, 10);
      ctx.fill();
      ctx.stroke();
      // Top Pin Tag
      ctx.fillStyle = shape.color;
      ctx.beginPath();
      ctx.roundRect(shape.x + 12, shape.y + 6, 24, 4, 2);
      ctx.fill();
      // Sticky Text
      ctx.fillStyle = '#f8fafc';
      ctx.font = '11px monospace';
      const lines = (shape.text || '').split('\\n');
      lines.forEach((line, idx) => {
        ctx.fillText(line, shape.x + 10, shape.y + 28 + (idx * 16));
      });
    } else if (shape.type === 'arrow') {
      // Directional Vector Arrow
      ctx.strokeStyle = shape.color || '#6366f1';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(shape.startX, shape.startY);
      ctx.lineTo(shape.endX, shape.endY);
      ctx.stroke();
      // Arrowhead
      const angle = Math.atan2(shape.endY - shape.startY, shape.endX - shape.startX);
      ctx.fillStyle = shape.color || '#6366f1';
      ctx.beginPath();
      ctx.moveTo(shape.endX, shape.endY);
      ctx.lineTo(shape.endX - 12 * Math.cos(angle - Math.PI / 6), shape.endY - 12 * Math.sin(angle - Math.PI / 6));
      ctx.lineTo(shape.endX - 12 * Math.cos(angle + Math.PI / 6), shape.endY - 12 * Math.sin(angle + Math.PI / 6));
      ctx.closePath();
      ctx.fill();
    } else if (shape.type === 'freehand' && shape.points && shape.points.length > 1) {
      ctx.strokeStyle = shape.color;
      ctx.lineWidth = 2.5;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();
      ctx.moveTo(shape.points[0].x, shape.points[0].y);
      for (let i = 1; i < shape.points.length; i++) {
        ctx.lineTo(shape.points[i].x, shape.points[i].y);
      }
      ctx.stroke();
    }
    ctx.restore();
  });

  ctx.restore();
}

function drawGridDots(w, h) {
  const gridSize = 28;
  const startX = Math.floor((-STATE.panX / STATE.zoom) / gridSize) * gridSize;
  const endX = startX + (w / STATE.zoom) + gridSize;
  const startY = Math.floor((-STATE.panY / STATE.zoom) / gridSize) * gridSize;
  const endY = startY + (h / STATE.zoom) + gridSize;

  ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
  for (let x = startX; x < endX; x += gridSize) {
    for (let y = startY; y < endY; y += gridSize) {
      ctx.beginPath();
      ctx.arc(x, y, 1.2, 0, Math.PI * 2);
      ctx.fill();
    }
  }
}

// --- REMOTE CURSORS OVERLAY ---
function renderRemoteCursors() {
  const layer = document.getElementById('canvasPeerCursorsLayer');
  if (!layer) return;
  layer.innerHTML = '';

  Object.entries(STATE.remotePeers).forEach(([id, peer]) => {
    if (!peer.cursor) return;
    const screenX = peer.cursor.x * STATE.zoom + STATE.panX;
    const screenY = peer.cursor.y * STATE.zoom + STATE.panY;

    const cursorEl = document.createElement('div');
    cursorEl.className = 'remote-cursor';
    cursorEl.style.transform = \`translate3d(\${screenX}px, \${screenY}px, 0)\`;
    cursorEl.innerHTML = \`
      <svg width="18" height="18" viewBox="0 0 24 24" fill="\${peer.color}" stroke="#090d16" stroke-width="1.5">
        <path d="M3 3l7 18 3-7 7-3L3 3z"/>
      </svg>
      <span class="remote-cursor-tag" style="background-color:\${peer.color}">\${peer.name}</span>
    \`;
    layer.appendChild(cursorEl);
  });
}

// --- WORKSPACE VIEW MODE SWITCHER & RESIZER ---
function setupWorkspaceLayout() {
  const leftPanel = document.getElementById('leftPanel');
  const rightPanel = document.getElementById('rightPanel');
  const splitDivider = document.getElementById('splitDivider');
  
  const btnSplit = document.getElementById('viewModeSplit');
  const btnCode = document.getElementById('viewModeCode');
  const btnCanvas = document.getElementById('viewModeCanvas');

  function setMode(mode) {
    if (!btnSplit || !btnCode || !btnCanvas) return;
    [btnSplit, btnCode, btnCanvas].forEach(b => b.classList.remove('active-tab', 'text-slate-300'));
    if (mode === 'split') {
      btnSplit.classList.add('active-tab');
      if (leftPanel) { leftPanel.style.display = 'flex'; leftPanel.style.width = '50%'; }
      if (rightPanel) rightPanel.style.display = 'flex';
      if (splitDivider) splitDivider.style.display = 'flex';
    } else if (mode === 'code') {
      btnCode.classList.add('active-tab');
      if (leftPanel) { leftPanel.style.display = 'flex'; leftPanel.style.width = '100%'; }
      if (rightPanel) rightPanel.style.display = 'none';
      if (splitDivider) splitDivider.style.display = 'none';
    } else if (mode === 'canvas') {
      btnCanvas.classList.add('active-tab');
      if (leftPanel) leftPanel.style.display = 'none';
      if (rightPanel) { rightPanel.style.display = 'flex'; rightPanel.style.width = '100%'; }
      if (splitDivider) splitDivider.style.display = 'none';
    }
    setTimeout(resizeCanvas, 50);
  }

  if (btnSplit) btnSplit.onclick = () => setMode('split');
  if (btnCode) btnCode.onclick = () => setMode('code');
  if (btnCanvas) btnCanvas.onclick = () => setMode('canvas');

  // Draggable Split Divider
  if (splitDivider && leftPanel) {
    let isSplitting = false;
    splitDivider.addEventListener('mousedown', () => { isSplitting = true; });
    window.addEventListener('mousemove', (e) => {
      if (!isSplitting) return;
      const totalWidth = window.innerWidth;
      const percentage = Math.min(80, Math.max(20, (e.clientX / totalWidth) * 100));
      leftPanel.style.width = \`\${percentage}%\`;
      resizeCanvas();
    });
    window.addEventListener('mouseup', () => { isSplitting = false; });
  }

  // Console Drawer Toggle
  const runner = document.getElementById('runnerContainer');
  const toggleBtn = document.getElementById('toggleConsoleBtn');
  if (toggleBtn && runner) {
    toggleBtn.onclick = () => {
      runner.classList.toggle('hidden');
    };
  }

  // Action Buttons
  const runBtn = document.getElementById('runCodeBtn');
  const reloadBtn = document.getElementById('reloadSandboxBtn');
  const clearLogs = document.getElementById('clearLogsBtn');
  const spawnBot = document.getElementById('spawnBotBtn');
  const exportBtn = document.getElementById('exportBtn');

  if (runBtn) runBtn.onclick = executeSandboxCode;
  if (reloadBtn) reloadBtn.onclick = executeSandboxCode;
  if (clearLogs) {
    clearLogs.onclick = () => {
      const out = document.getElementById('consoleOutput');
      if (out) out.innerHTML = '<div class="text-cyan-500/70">[Console logs cleared]</div>';
    };
  }
  if (spawnBot) spawnBot.onclick = spawnSimulatedBotPeer;
  
  if (exportBtn) {
    exportBtn.onclick = () => {
      const snapshot = {
        version: '1.0',
        files: STATE.files,
        shapes: STATE.shapes,
        exportedAt: new Date().toISOString()
      };
      const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = \`synapse-workspace-\${Date.now()}.json\`;
      a.click();
      URL.revokeObjectURL(url);
      audioFX.playBoop(600, 'triangle', 0.1, 0.05);
    };
  }
}

// --- BOOTSTRAP SYSTEM ON DOM LOAD ---
function bootstrapApp() {
  if (window.lucide && typeof window.lucide.createIcons === 'function') {
    window.lucide.createIcons();
  }
  setupCodeEditor();
  setupInfiniteCanvas();
  setupWorkspaceLayout();
  
  // Initialize local user badge
  const userBadge = document.getElementById('userBadgeLocal');
  if (userBadge) {
    userBadge.style.backgroundColor = STATE.userColor;
  }

  // Run default Three.js template sandbox
  setTimeout(executeSandboxCode, 200);

  // Unlock AudioContext on first user interaction
  document.addEventListener('pointerdown', () => {
    audioFX.init();
  }, { once: true });
}

if (document.readyState === 'loading') {
  window.addEventListener('DOMContentLoaded', bootstrapApp);
} else {
  bootstrapApp();
}
`
        },
        {
          id: `f_synapse_css_${now}`,
          name: 'style.css',
          language: 'css',
          lastModified: now,
          content: `/* Custom Aesthetics & Workspace Layouts */
::-webkit-scrollbar {
  width: 6px;
  height: 6px;
}
::-webkit-scrollbar-track {
  background: #090d16;
}
::-webkit-scrollbar-thumb {
  background: #1e293b;
  border-radius: 4px;
}
::-webkit-scrollbar-thumb:hover {
  background: #334155;
}

.no-scrollbar::-webkit-scrollbar {
  display: none;
}
.no-scrollbar {
  -ms-overflow-style: none;
  scrollbar-width: none;
}

/* Active States */
.active-tab {
  background: linear-gradient(135deg, rgba(99, 102, 241, 0.25), rgba(6, 182, 212, 0.15)) !important;
  color: #38bdf8 !important;
  border: 1px solid rgba(6, 182, 212, 0.4) !important;
}

.active-editor-tab {
  background: #111827 !important;
  border-color: rgba(6, 182, 212, 0.4) !important;
  color: #38bdf8 !important;
}

.active-tool {
  background: rgba(99, 102, 241, 0.25) !important;
  color: #38bdf8 !important;
  border: 1px solid rgba(6, 182, 212, 0.5) !important;
}

/* Remote Collaborator Cursors */
.remote-cursor {
  position: absolute;
  pointer-events: none;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  z-index: 50;
  transition: transform 0.08s ease-out;
}

.remote-cursor-tag {
  font-size: 10px;
  font-weight: 600;
  font-family: monospace;
  padding: 2px 6px;
  border-radius: 4px;
  color: white;
  margin-top: 2px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
  white-space: nowrap;
}

/* Interactive Glass Glows */
.glow-cyan {
  box-shadow: 0 0 25px rgba(6, 182, 212, 0.25);
}

@keyframes pulse-subtle {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.85; transform: scale(1.02); }
}

.animate-subtle {
  animation: pulse-subtle 4s infinite ease-in-out;
}
`
        }
      ];
    }
  },
  {
    id: 'multi-page-vanilla',
    name: 'HTML5 & Vanilla JS Web Platform',
    category: 'frontend',
    icon: '🌐',
    badge: 'HTML5 + JS',
    description: 'Clean HTML5, Tailwind CSS, Lucide icons, and Vanilla JS architecture.',
    files: (sessionId: string): FileNode[] => {
      const now = Date.now();
      return [
        {
          id: `f_idx_${now}`,
          name: 'index.html',
          language: 'html',
          lastModified: now,
          content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Aether Web Application</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/lucide@latest"></script>
  <link rel="stylesheet" href="style.css">
</head>
<body class="bg-zinc-950 text-white min-h-screen">
  <!-- Navbar -->
  <header class="border-b border-zinc-800 bg-zinc-950/80 backdrop-blur-md sticky top-0 z-40">
    <div class="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
      <div class="flex items-center gap-3 cursor-pointer" id="navBrand">
        <div class="w-9 h-9 rounded-xl bg-amber-500 text-black flex items-center justify-center font-bold shadow-lg shadow-amber-500/20">
          <i data-lucide="layers"></i>
        </div>
        <span class="font-extrabold text-lg tracking-tight bg-gradient-to-r from-white to-zinc-400 bg-clip-text text-transparent">
          Aether Platform
        </span>
      </div>

      <nav class="flex items-center gap-2">
        <button id="navHome" class="px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer bg-amber-500/15 text-amber-400 border border-amber-500/30">
          <i data-lucide="home" class="w-4 h-4"></i> <span>Home</span>
        </button>
        <button id="navDashboard" class="px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer text-zinc-400 hover:text-white hover:bg-white/5">
          <i data-lucide="layout-dashboard" class="w-4 h-4"></i> <span>Dashboard</span>
        </button>
      </nav>
    </div>
  </header>

  <!-- Main Content -->
  <main id="app" class="p-6 max-w-7xl mx-auto">
    <!-- Home View -->
    <section id="viewHome" class="max-w-4xl mx-auto py-12 text-center space-y-6">
      <div class="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold">
        <i data-lucide="sparkles" class="w-4 h-4"></i> <span>Pure HTML, CSS & Vanilla JavaScript</span>
      </div>
      <h1 class="text-5xl font-extrabold tracking-tight text-white">
        Web Application Matrix
      </h1>
      <p class="text-zinc-400 text-base max-w-2xl mx-auto">
        Ultra-fast, responsive web application powered by HTML5, Tailwind CSS, and Vanilla JS.
      </p>
      <div class="pt-4 flex justify-center gap-4">
        <button id="btnExplore" class="px-6 py-3 bg-amber-500 hover:bg-amber-400 text-black font-extrabold rounded-xl transition-all cursor-pointer">
          Launch Dashboard
        </button>
      </div>
    </section>

    <!-- Dashboard View -->
    <section id="viewDashboard" class="hidden space-y-6">
      <h2 class="text-2xl font-bold">System Status</h2>
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="p-6 bg-zinc-900 border border-zinc-800 rounded-2xl">
          <div class="text-xs text-zinc-500 uppercase font-bold">Runtime Engine</div>
          <div class="text-2xl font-bold text-amber-400 mt-2">Pure HTML5 / JS</div>
        </div>
        <div class="p-6 bg-zinc-900 border border-zinc-800 rounded-2xl">
          <div class="text-xs text-zinc-500 uppercase font-bold">Latency</div>
          <div class="text-2xl font-bold text-emerald-400 mt-2">&lt; 1 ms (Native)</div>
        </div>
        <div class="p-6 bg-zinc-900 border border-zinc-800 rounded-2xl">
          <div class="text-xs text-zinc-500 uppercase font-bold">Status</div>
          <div class="text-2xl font-bold text-cyan-400 mt-2">Active</div>
        </div>
      </div>
    </section>
  </main>

  <script src="script.js" defer></script>
</body>
</html>`
        },
        {
          id: `f_css_${now}`,
          name: 'style.css',
          language: 'css',
          lastModified: now,
          content: `/* Custom Web Application Styling */
body {
  font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}`
        },
        {
          id: `f_js_${now}`,
          name: 'script.js',
          language: 'javascript',
          lastModified: now,
          content: `document.addEventListener('DOMContentLoaded', () => {
  if (window.lucide) {
    lucide.createIcons();
  }

  const viewHome = document.getElementById('viewHome');
  const viewDashboard = document.getElementById('viewDashboard');
  const navHome = document.getElementById('navHome');
  const navDashboard = document.getElementById('navDashboard');
  const btnExplore = document.getElementById('btnExplore');

  function showView(view) {
    if (view === 'home') {
      viewHome.classList.remove('hidden');
      viewDashboard.classList.add('hidden');
      navHome.className = 'px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer bg-amber-500/15 text-amber-400 border border-amber-500/30';
      navDashboard.className = 'px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer text-zinc-400 hover:text-white hover:bg-white/5';
    } else {
      viewHome.classList.add('hidden');
      viewDashboard.classList.remove('hidden');
      navDashboard.className = 'px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer bg-amber-500/15 text-amber-400 border border-amber-500/30';
      navHome.className = 'px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer text-zinc-400 hover:text-white hover:bg-white/5';
    }
  }

  if (navHome) navHome.addEventListener('click', () => showView('home'));
  if (navDashboard) navDashboard.addEventListener('click', () => showView('dashboard'));
  if (btnExplore) btnExplore.addEventListener('click', () => showView('dashboard'));
});`
        }
      ];
    }
  },

  {
    id: '3d-cyberpunk-game',
    name: '3D Cyberpunk Three.js Game Engine',
    category: '3d-game',
    icon: '🎮',
    badge: 'Three.js 3D',
    description: 'Hardware-accelerated 3D engine with dynamic neon lighting, flying hover-pod, particles & HUD.',
    files: (sessionId: string): FileNode[] => {
      const now = Date.now();
      return [
        {
          id: `f_3d_html_${now}`,
          name: 'index.html',
          language: 'html',
          lastModified: now,
          content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>3D Cyberpunk Flight Engine</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
  <style>
    body, html { margin: 0; padding: 0; width: 100%; height: 100%; overflow: hidden; background: #000; }
    #canvas3d { position: absolute; inset: 0; width: 100%; height: 100%; }
  </style>
</head>
<body className="bg-black text-white font-mono select-none">
  <canvas id="canvas3d"></canvas>

  {/* Futuristic HUD Overlay */}
  <div className="absolute inset-0 pointer-events-none p-6 flex flex-col justify-between z-10">
    <div className="flex justify-between items-start">
      <div className="bg-black/60 backdrop-blur-md border border-cyan-500/40 p-4 rounded-xl shadow-[0_0_20px_rgba(6,182,212,0.2)]">
        <div className="text-[10px] text-cyan-400 font-bold tracking-widest uppercase">CYBER-ORBIT 3D CORE</div>
        <div className="text-xl font-black text-white mt-1">SPEED: <span id="speedGauge" className="text-cyan-300">840</span> KM/H</div>
        <div className="text-xs text-zinc-400 mt-0.5">ALTITUDE: <span id="altGauge" className="text-purple-300">1,240</span> M</div>
      </div>

      <div className="bg-black/60 backdrop-blur-md border border-pink-500/40 p-3 rounded-xl text-right">
        <div className="text-[10px] text-pink-400 font-bold uppercase">PROPULSION</div>
        <div className="text-sm font-bold text-white mt-0.5">PBR NEON PARTICLES ACTIVE</div>
      </div>
    </div>

    <div className="flex justify-between items-end">
      <div className="text-xs text-zinc-400 bg-black/70 p-3 rounded-xl border border-zinc-800">
        🎮 <span className="text-white font-bold">CONTROLS:</span> Move mouse to steer ship · Click to Boost Turbo
      </div>
      <div className="text-xs font-bold text-cyan-400 animate-pulse bg-cyan-500/10 border border-cyan-500/30 px-3 py-1.5 rounded-lg">
        SYSTEM READY
      </div>
    </div>
  </div>

  <script src="src/game.js"></script>
</body>
</html>`
        },
        {
          id: `f_3d_js_${now}`,
          name: 'src/game.js',
          language: 'javascript',
          lastModified: now,
          content: `// 3D Cyberpunk Three.js Flight Simulation
(function initGame() {
  const canvas = document.getElementById('canvas3d');
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

  const scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x050510, 0.008);

  const camera = new THREE.PerspectiveCamera(65, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.set(0, 3, 10);

  // Lighting
  const ambient = new THREE.AmbientLight(0x221133, 1.5);
  scene.add(ambient);

  const neonLight = new THREE.PointLight(0x00ffff, 4, 50);
  neonLight.position.set(0, 5, 5);
  scene.add(neonLight);

  const pinkLight = new THREE.PointLight(0xff0077, 3, 50);
  pinkLight.position.set(0, -2, 0);
  scene.add(pinkLight);

  // Grid Floor
  const gridHelper = new THREE.GridHelper(400, 80, 0x00ffff, 0x331155);
  gridHelper.position.y = -2;
  scene.add(gridHelper);

  // Futuristic Buildings / Monoliths
  const buildingGeo = new THREE.BoxGeometry(4, 20, 4);
  const buildingMat = new THREE.MeshStandardMaterial({
    color: 0x0f1123,
    roughness: 0.2,
    metalness: 0.8
  });

  const buildings = [];
  for (let i = 0; i < 40; i++) {
    const mesh = new THREE.Mesh(buildingGeo, buildingMat);
    mesh.position.x = (Math.random() - 0.5) * 120;
    mesh.position.z = -Math.random() * 200;
    mesh.position.y = 8 + (Math.random() * 10);
    scene.add(mesh);
    buildings.push(mesh);
  }

  // Hover Ship
  const shipGroup = new THREE.Group();
  const bodyGeo = new THREE.ConeGeometry(0.8, 2.5, 4);
  const bodyMat = new THREE.MeshStandardMaterial({ color: 0x00f3ff, roughness: 0.1, metalness: 0.9 });
  const shipBody = new THREE.Mesh(bodyGeo, bodyMat);
  shipBody.rotation.x = Math.PI / 2;
  shipGroup.add(shipBody);

  const wingGeo = new THREE.BoxGeometry(2.8, 0.1, 1);
  const wingMat = new THREE.MeshStandardMaterial({ color: 0xff0055, roughness: 0.2 });
  const wings = new THREE.Mesh(wingGeo, wingMat);
  wings.position.z = 0.5;
  shipGroup.add(wings);

  scene.add(shipGroup);
  shipGroup.position.set(0, 0, 4);

  // Mouse steer handler
  let targetX = 0;
  let targetY = 0;
  window.addEventListener('mousemove', (e) => {
    targetX = ((e.clientX / window.innerWidth) - 0.5) * 12;
    targetY = -((e.clientY / window.innerHeight) - 0.5) * 6;
  });

  let speed = 1.2;
  window.addEventListener('mousedown', () => { speed = 2.5; });
  window.addEventListener('mouseup', () => { speed = 1.2; });

  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });

  // Animation Loop
  let frame = 0;
  function animate() {
    requestAnimationFrame(animate);
    frame++;

    shipGroup.position.x += (targetX - shipGroup.position.x) * 0.08;
    shipGroup.position.y += (targetY - shipGroup.position.y) * 0.08;
    shipGroup.rotation.z = (shipGroup.position.x - targetX) * 0.1;
    shipGroup.rotation.x = (targetY - shipGroup.position.y) * 0.05;

    gridHelper.position.z = (gridHelper.position.z + speed) % 5;

    buildings.forEach(b => {
      b.position.z += speed;
      if (b.position.z > 20) {
        b.position.z = -200;
        b.position.x = (Math.random() - 0.5) * 120;
      }
    });

    const speedEl = document.getElementById('speedGauge');
    if (speedEl && frame % 10 === 0) {
      speedEl.innerText = Math.round(speed * 700 + Math.random() * 20);
    }

    renderer.render(scene, camera);
  }

  animate();
})();`
        }
      ];
    }
  },

  {
    id: 'python-pyodide-lab',
    name: 'Python & Pyodide Data Lab',
    category: 'python',
    icon: '🐍',
    badge: 'Python Lab',
    description: 'In-browser Python VM with interactive script runner, live stdout terminal & charts.',
    files: (sessionId: string): FileNode[] => {
      const now = Date.now();
      return [
        {
          id: `f_py_html_${now}`,
          name: 'index.html',
          language: 'html',
          lastModified: now,
          content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Python Pyodide Data Lab</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.jsdelivr.net/pyodide/v0.25.0/full/pyodide.js"></script>
</head>
<body className="bg-zinc-950 text-zinc-100 font-sans p-6 min-h-screen">
  <div className="max-w-4xl mx-auto space-y-6">
    <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-yellow-500/10 border border-yellow-500/20 text-yellow-400 flex items-center justify-center font-bold text-xl">
          🐍
        </div>
        <div>
          <h1 className="text-xl font-bold text-white">Python Data Science VM</h1>
          <p className="text-xs text-zinc-400">WebAssembly Pyodide runtime with math & matrix operations</p>
        </div>
      </div>
      <button id="runBtn" className="px-5 py-2 bg-yellow-500 hover:bg-yellow-400 text-black font-bold text-xs rounded-xl transition-all shadow-lg shadow-yellow-500/20 cursor-pointer">
        ▶ Run Python Script
      </button>
    </div>

    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      <div className="space-y-2">
        <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider">Python Source Code (<code className="text-yellow-400">main.py</code>)</label>
        <textarea id="pyCode" className="w-full h-80 bg-zinc-900 border border-zinc-800 rounded-xl p-4 font-mono text-xs text-yellow-300 outline-none focus:border-yellow-500/60" spellcheck="false">
import math
import random

print("=== Python VM Initialized ===")
print("Calculating Fibonacci & Statistical Data Points...")

def fibonacci(n):
    a, b = 0, 1
    series = []
    for _ in range(n):
        series.append(a)
        a, b = b, a + b
    return series

data = [random.randint(10, 100) for _ in range(10)]
mean = sum(data) / len(data)
variance = sum((x - mean) ** 2 for x in data) / len(data)
std_dev = math.sqrt(variance)

print(f"Fibonacci (12 terms): {fibonacci(12)}")
print(f"Sample Dataset: {data}")
print(f"Mean: {mean:.2f}")
print(f"Std Deviation: {std_dev:.2f}")
print("Computation completed successfully.")
        </textarea>
      </div>

      <div className="space-y-2">
        <label className="text-xs font-bold text-zinc-400 uppercase tracking-wider">Terminal Output</label>
        <div id="output" className="w-full h-80 bg-black border border-zinc-800 rounded-xl p-4 font-mono text-xs text-emerald-400 overflow-auto whitespace-pre-wrap">
Loading Pyodide WebAssembly runtime...
        </div>
      </div>
    </div>
  </div>

  <script>
    let pyodide = null;
    const outputEl = document.getElementById('output');
    const runBtn = document.getElementById('runBtn');

    async function loadPy() {
      try {
        pyodide = await loadPyodide({
          stdout: (text) => {
            outputEl.innerText += text + '\\n';
          },
          stderr: (text) => {
            outputEl.innerText += '[ERROR] ' + text + '\\n';
          }
        });
        outputEl.innerText = "Python 3.11 Runtime Ready! Click 'Run Python Script'.\\n";
      } catch (err) {
        outputEl.innerText = "Error loading Pyodide: " + err;
      }
    }

    runBtn.addEventListener('click', async () => {
      if (!pyodide) {
        outputEl.innerText += "Waiting for Python runtime...\\n";
        return;
      }
      const code = document.getElementById('pyCode').value;
      outputEl.innerText = "";
      try {
        await pyodide.runPythonAsync(code);
      } catch (e) {
        outputEl.innerText += "\\nExecution Exception: " + e;
      }
    });

    loadPy();
  </script>
</body>
</html>`
        },
        {
          id: `f_main_py_${now}`,
          name: 'main.py',
          language: 'python',
          lastModified: now,
          content: `import math
import random

print("=== Python VM Initialized ===")
print("Calculating Fibonacci & Statistical Data Points...")

def fibonacci(n):
    a, b = 0, 1
    series = []
    for _ in range(n):
        series.append(a)
        a, b = b, a + b
    return series

data = [random.randint(10, 100) for _ in range(10)]
mean = sum(data) / len(data)
variance = sum((x - mean) ** 2 for x in data) / len(data)
std_dev = math.sqrt(variance)

print(f"Fibonacci (12 terms): {fibonacci(12)}")
print(f"Sample Dataset: {data}")
print(f"Mean: {mean:.2f}")
print(f"Std Deviation: {std_dev:.2f}")
`
        }
      ];
    }
  },

  {
    id: 'vue3-studio',
    name: 'Vue 3 Reactive Web App',
    category: 'frontend',
    icon: '🟢',
    badge: 'Vue 3',
    description: 'Vue 3 Composition API reactive components with responsive state store & Tailwind.',
    files: (sessionId: string): FileNode[] => {
      const now = Date.now();
      return [
        {
          id: `f_vue_html_${now}`,
          name: 'index.html',
          language: 'html',
          lastModified: now,
          content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Vue 3 Reactive Studio</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
</head>
<body className="bg-zinc-950 text-zinc-100 font-sans min-h-screen p-8">
  <div id="app" className="max-w-4xl mx-auto space-y-8">
    <header className="flex items-center justify-between border-b border-zinc-800 pb-4">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xl">
          🟢
        </div>
        <div>
          <h1 className="text-xl font-bold text-white">{{ title }}</h1>
          <p className="text-xs text-zinc-400">Vue 3 Composition API & Reactive State</p>
        </div>
      </div>
      <div className="px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-mono font-bold">
        Items: {{ items.length }}
      </div>
    </header>

    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="p-6 bg-zinc-900 border border-zinc-800 rounded-2xl space-y-4">
        <h2 className="text-sm font-bold text-zinc-300 uppercase tracking-wider">Reactive Counter</h2>
        <div className="text-4xl font-extrabold text-emerald-400 font-mono">{{ count }}</div>
        <div className="flex gap-2">
          <button @click="count++" className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs rounded-xl transition-all">
            + Increment
          </button>
          <button @click="count--" className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs rounded-xl transition-all">
            - Decrement
          </button>
          <button @click="count = 0" className="px-4 py-2 text-zinc-500 hover:text-zinc-300 text-xs">
            Reset
          </button>
        </div>
      </div>

      <div className="p-6 bg-zinc-900 border border-zinc-800 rounded-2xl space-y-4">
        <h2 className="text-sm font-bold text-zinc-300 uppercase tracking-wider">Add Reactive Task</h2>
        <form @submit.prevent="addItem" className="flex gap-2">
          <input 
            v-model="newItem" 
            placeholder="Type task description..." 
            className="flex-1 bg-black border border-zinc-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-emerald-500" 
          />
          <button type="submit" className="px-4 py-2 bg-emerald-500 text-black font-bold text-xs rounded-xl">Add</button>
        </form>
        <ul className="space-y-2 mt-4">
          <li v-for="(item, idx) in items" :key="idx" className="flex items-center justify-between p-2.5 bg-black/40 rounded-lg text-xs">
            <span>{{ item }}</span>
            <button @click="items.splice(idx, 1)" className="text-zinc-500 hover:text-red-400">✕</button>
          </li>
        </ul>
      </div>
    </div>
  </div>

  <script>
    const { createApp, ref } = Vue;
    createApp({
      setup() {
        const title = ref('Vue 3 Reactive Studio');
        const count = ref(42);
        const items = ref(['Explore Vue 3 Single Page Flow', 'Connect Reactive Computed Stores', 'Deploy Next-Gen UI']);
        const newItem = ref('');

        const addItem = () => {
          if (newItem.value.trim()) {
            items.value.push(newItem.value.trim());
            newItem.value = '';
          }
        };

        return { title, count, items, newItem, addItem };
      }
    }).mount('#app');
  </script>
</body>
</html>`
        }
      ];
    }
  },

  {
    id: 'rust-wasm-core',
    name: 'Rust Native & WebAssembly Engine',
    category: 'rust',
    icon: '🦀',
    badge: 'Rust WASM',
    description: 'Rust native source with memory-safe computations and WebAssembly simulation.',
    files: (sessionId: string): FileNode[] => {
      const now = Date.now();
      return [
        {
          id: `f_cargo_${now}`,
          name: 'Cargo.toml',
          language: 'toml',
          lastModified: now,
          content: `[package]
name = "aether_rust_core"
version = "0.1.0"
edition = "2021"

[dependencies]
wasm-bindgen = "0.2"
`
        },
        {
          id: `f_rs_${now}`,
          name: 'src/main.rs',
          language: 'rust',
          lastModified: now,
          content: `// Rust Native Engine Core
fn main() {
    println!("=== Rust Native Core Execution ===");
    
    let numbers: Vec<i64> = (1..=100).collect();
    let sum: i64 = numbers.iter().sum();
    let is_prime = |n: i64| -> bool {
        if n <= 1 { return false; }
        for i in 2..=((n as f64).sqrt() as i64) {
            if n % i == 0 { return false; }
        }
        true
    };

    let prime_count = numbers.iter().filter(|&&x| is_prime(x)).count();

    println!("Sum of numbers 1..100: {}", sum);
    println!("Total prime numbers found: {}", prime_count);
    println!("Memory Safety Verified: Zero buffer overflows.");
}
`
        },
        {
          id: `f_rust_html_${now}`,
          name: 'index.html',
          language: 'html',
          lastModified: now,
          content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Rust Native & WASM Runner</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body className="bg-zinc-950 text-white font-mono p-8 min-h-screen">
  <div className="max-w-3xl mx-auto space-y-6">
    <div className="flex items-center gap-3 border-b border-zinc-800 pb-4">
      <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/20 text-orange-400 flex items-center justify-center font-bold text-xl">
        🦀
      </div>
      <div>
        <h1 className="text-xl font-bold text-white">Rust Native & WASM Engine</h1>
        <p className="text-xs text-zinc-400">High performance memory-safe computing</p>
      </div>
    </div>

    <div className="p-4 bg-zinc-900 rounded-xl border border-zinc-800 space-y-3">
      <div className="text-xs font-bold text-orange-400">RUST STDOUT / CARGO RUN:</div>
      <div className="p-4 bg-black rounded-lg text-emerald-400 text-xs leading-relaxed whitespace-pre-wrap">
=== Rust Native Core Execution ===
Compiling aether_rust_core v0.1.0 (/workspace)
    Finished dev [unoptimized + debuginfo] target(s) in 0.42s
     Running \`target/debug/aether_rust_core\`

Sum of numbers 1..100: 5050
Total prime numbers found: 25
Memory Safety Verified: Zero buffer overflows.
Execution finished with exit code 0.
      </div>
    </div>
  </div>
</body>
</html>`
        }
      ];
    }
  },

  {
    id: 'rest-api-microservice',
    name: 'REST API & Microservice Hub',
    category: 'backend',
    icon: '🛠️',
    badge: 'Express API',
    description: 'Modular Node.js / Express REST API endpoints with interactive Swagger-style testbench.',
    files: (sessionId: string): FileNode[] => {
      const now = Date.now();
      return [
        {
          id: `f_api_html_${now}`,
          name: 'index.html',
          language: 'html',
          lastModified: now,
          content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>REST API Test Bench</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body className="bg-zinc-950 text-zinc-100 font-sans p-8 min-h-screen">
  <div className="max-w-4xl mx-auto space-y-6">
    <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-xl">
          ⚡
        </div>
        <div>
          <h1 className="text-xl font-bold text-white">REST API Swagger Workbench</h1>
          <p className="text-xs text-zinc-400">Simulated Microservice Endpoints & JSON Payloads</p>
        </div>
      </div>
    </div>

    <div className="space-y-3">
      <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="px-2.5 py-1 rounded bg-emerald-500/20 text-emerald-400 font-mono text-xs font-bold">GET</span>
          <code className="text-xs text-white">/api/users</code>
        </div>
        <button onclick="testApi('/api/users')" className="px-3 py-1 bg-zinc-800 hover:bg-zinc-700 text-xs rounded-lg font-bold">Send Request</button>
      </div>

      <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="px-2.5 py-1 rounded bg-blue-500/20 text-blue-400 font-mono text-xs font-bold">POST</span>
          <code className="text-xs text-white">/api/orders</code>
        </div>
        <button onclick="testApi('/api/orders')" className="px-3 py-1 bg-zinc-800 hover:bg-zinc-700 text-xs rounded-lg font-bold">Send Request</button>
      </div>
    </div>

    <div className="p-4 bg-black border border-zinc-800 rounded-xl space-y-2">
      <div className="text-xs font-bold text-zinc-500 uppercase">Response Body (HTTP 200 OK)</div>
      <pre id="responseJson" className="text-xs font-mono text-emerald-400 whitespace-pre-wrap overflow-auto">
{
  "status": "ready",
  "service": "aether-microservice-node",
  "timestamp": 1724310000000,
  "endpoints": ["/api/users", "/api/orders", "/api/health"]
}
      </pre>
    </div>
  </div>

  <script>
    function testApi(endpoint) {
      const respEl = document.getElementById('responseJson');
      if (endpoint === '/api/users') {
        respEl.innerText = JSON.stringify({
          status: "success",
          total: 2,
          data: [
            { id: "usr_1", name: "Alice Vance", role: "Quantum Engineer" },
            { id: "usr_2", name: "David Thorne", role: "Core Architect" }
          ]
        }, null, 2);
      } else {
        respEl.innerText = JSON.stringify({
          status: "success",
          message: "Order #8491 created successfully",
          orderId: "ord_918239"
        }, null, 2);
      }
    }
  </script>
</body>
</html>`
        }
      ];
    }
  }
];

export const getTemplateById = (templateId: string, sessionId: string): FileNode[] | null => {
  const tmpl = NEXT_GEN_TEMPLATES.find(t => t.id === templateId);
  if (!tmpl) return null;
  return tmpl.files(sessionId);
};
