// Rust & WebAssembly Service for Aether IDE

export interface RustExecutionResult {
  success: boolean;
  stdout: string;
  stderr: string;
  exitDetail?: string;
  durationMs?: number;
  runtime?: string;
  files?: { path: string; code: string }[];
  error?: string;
}

export interface RustTemplate {
  id: string;
  name: string;
  description: string;
  code: string;
}

export const RUST_TEMPLATES: RustTemplate[] = [
  {
    id: "hello_wasm",
    name: "WebAssembly Fast Math & Computation",
    description: "High-speed prime calculation and memory-safe mathematical algorithms compiled to WebAssembly.",
    code: `// Aether IDE - Rust WebAssembly Engine
// High-performance compute kernel

fn is_prime(n: u64) -> bool {
    if n <= 1 { return false; }
    if n <= 3 { return true; }
    if n % 2 == 0 || n % 3 == 0 { return false; }
    let mut i = 5;
    while i * i <= n {
        if n % i == 0 || n % (i + 2) == 0 {
            return false;
        }
        i += 6;
    }
    true
}

fn main() {
    println!("=============================================");
    println!("  🦀 Aether Rust Engine - WebAssembly Kernel");
    println!("=============================================");
    
    let limit = 1000;
    let mut primes = Vec::new();
    
    for num in 2..limit {
        if is_prime(num) {
            primes.push(num);
        }
    }
    
    println!("Found {} primes below {}:", primes.len(), limit);
    println!("First 15 primes: {:?}", &primes[..15.min(primes.len())]);
    println!("Largest prime found: {}", primes.last().unwrap_or(&0));
    println!("Memory safety: Guaranteed by Rust Borrow Checker.");
    println!("Status: READY for WASM Web Execution.");
}
`
  },
  {
    id: "vector_matrix",
    name: "3D Vector & Matrix Transformations",
    description: "Fast linear algebra computations for 3D graphics, physics simulations, and WebGL pipelines.",
    code: `// Aether IDE - 3D Math & Matrix Transformation Engine

#[derive(Debug, Clone, Copy)]
struct Vec3 {
    x: f64,
    y: f64,
    z: f64,
}

impl Vec3 {
    fn new(x: f64, y: f64, z: f64) -> Self {
        Self { x, y, z }
    }

    fn length(&self) -> f64 {
        (self.x * self.x + self.y * self.y + self.z * self.z).sqrt()
    }

    fn normalize(&self) -> Self {
        let len = self.length();
        if len > 0.0 {
            Self::new(self.x / len, self.y / len, self.z / len)
        } else {
            *self
        }
    }

    fn cross(&self, other: &Vec3) -> Self {
        Self::new(
            self.y * other.z - self.z * other.y,
            self.z * other.x - self.x * other.z,
            self.x * other.y - self.y * other.x,
        )
    }

    fn dot(&self, other: &Vec3) -> f64 {
        self.x * other.x + self.y * other.y + self.z * other.z
    }
}

fn main() {
    let forward = Vec3::new(0.0, 0.0, -1.0);
    let up = Vec3::new(0.0, 1.0, 0.0);
    let right = forward.cross(&up).normalize();

    println!("⚡ Rust 3D Coordinate Pipeline");
    println!("-----------------------------");
    println!("Forward Vector: {:?}", forward);
    println!("Up Vector:      {:?}", up);
    println!("Right (Normal): {:?}", right);
    println!("Dot Product:    {}", forward.dot(&up));
}
`
  },
  {
    id: "raytracer_ascii",
    name: "Procedural 3D ASCII Sphere Raymarcher",
    description: "Compact 3D Raymarcher that computes real-time shading and specular highlights.",
    code: `// Aether IDE - 3D ASCII Raymarcher in Pure Rust

fn main() {
    let width = 60;
    let height = 30;
    let light_dir = (0.577, -0.577, -0.577);
    let shades = [' ', '.', ':', '-', '=', '+', '*', '#', '%', '@'];

    println!("--- 3D RAYMARCHED SPHERE (Rust Engine) ---");
    for y in 0..height {
        let mut line = String::new();
        for x in 0..width {
            let u = (x as f64 / width as f64) * 2.0 - 1.0;
            let v = ((y as f64 / height as f64) * 2.0 - 1.0) * (height as f64 / width as f64) * 2.0;

            let dist_sq = u * u + v * v;
            if dist_sq <= 1.0 {
                let z = -(1.0 - dist_sq).sqrt();
                let normal = (u, v, z);
                let diff = (normal.0 * -light_dir.0 + normal.1 * -light_dir.1 + normal.2 * -light_dir.2).max(0.0);
                let idx = ((diff * (shades.len() - 1) as f64).round() as usize).min(shades.len() - 1);
                line.push(shades[idx]);
            } else {
                line.push(' ');
            }
        }
        println!("{}", line);
    }
    println!("--- Render Completed with Zero Garbage Collection ---");
}
`
  }
];

export const executeRustCode = async (
  code: string,
  edition: string = "2021",
  mode: "debug" | "release" = "debug"
): Promise<RustExecutionResult> => {
  try {
    const res = await fetch('/api/rust/execute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, edition, mode })
    });

    if (res.ok) {
      return await res.json();
    }
    const err = await res.json().catch(() => ({}));
    return {
      success: false,
      stdout: "",
      stderr: err.stderr || err.error || `Rust compilation failed (HTTP ${res.status})`,
      error: err.error || "Compilation failed"
    };
  } catch (err: any) {
    return {
      success: false,
      stdout: "",
      stderr: err.message || "Network error communicating with Rust compiler",
      error: err.message
    };
  }
};

export const compileRustToWasmBundle = async (
  code: string,
  moduleName: string = "aether_rust_wasm"
): Promise<RustExecutionResult> => {
  try {
    const res = await fetch('/api/rust/compile-wasm', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ code, moduleName })
    });

    if (res.ok) {
      return await res.json();
    }
    const err = await res.json().catch(() => ({}));
    return {
      success: false,
      stdout: "",
      stderr: err.stderr || err.error || `WASM build failed (HTTP ${res.status})`
    };
  } catch (err: any) {
    return {
      success: false,
      stdout: "",
      stderr: err.message || "Failed to compile WASM bundle"
    };
  }
};
