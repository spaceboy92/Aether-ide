// Image Generation Tool Service
// Generates images, sends inline previews into chat, and automatically saves assets to the File Explorer

import { FileNode } from '../types';

export interface ImageGenOptions {
  prompt: string;
  fileName?: string;
  folderPath?: string;
  width?: number;
  height?: number;
  style?: string;
}

export interface GeneratedAssetResult {
  imageUrl: string;
  assetPath: string;
  fileName: string;
  prompt: string;
  fileNode: FileNode;
}

/**
 * Generates an image asset and saves it directly to the workspace as a real physical FileNode in File Explorer.
 */
export const generateImageTool = async (
  promptOrOptions: string | ImageGenOptions,
  optionalFileName?: string,
  optionalFolderPath: string = 'public/images'
): Promise<FileNode> => {
  let prompt = '';
  let fileName = optionalFileName;
  let folderPath = optionalFolderPath;
  let width = 1024;
  let height = 1024;
  let style = 'general';

  if (typeof promptOrOptions === 'object') {
    prompt = promptOrOptions.prompt || 'modern UI asset';
    fileName = promptOrOptions.fileName || fileName;
    folderPath = promptOrOptions.folderPath || folderPath;
    width = promptOrOptions.width || 1024;
    height = promptOrOptions.height || 1024;
    style = promptOrOptions.style || 'general';
  } else {
    prompt = (promptOrOptions || 'modern UI asset').trim();
  }

  // Sanitize path and filename
  let fullPath = '';
  if (fileName && fileName.includes('/')) {
    fullPath = fileName.replace(/^\/+/, '');
  } else {
    const rawName = fileName || prompt.slice(0, 24).toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/(^-|-$)+/g, '') || 'asset';
    const safeName = rawName.endsWith('.png') || rawName.endsWith('.jpg') || rawName.endsWith('.svg') || rawName.endsWith('.webp') 
      ? rawName 
      : `${rawName}.png`;
    const cleanFolder = folderPath.replace(/\/$/, '').replace(/^\//, '') || 'public/images';
    fullPath = `${cleanFolder}/${safeName}`;
  }

  // Pollinations AI high quality image generator endpoint with seed & parameters
  const encodedPrompt = encodeURIComponent(prompt);
  const seed = Math.floor(Math.random() * 999999);
  const imageUrl = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=${width}&height=${height}&nologo=true&seed=${seed}&model=flux`;

  const fileNode: FileNode = {
    id: 'asset_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
    name: fullPath,
    content: imageUrl,
    language: 'image',
    isBinary: true,
    lastModified: Date.now()
  };

  return fileNode;
};

/**
 * Parses raw AI response text for image tool call signatures like:
 * [IMAGE_TOOL: "prompt description", path: "public/images/logo.png"]
 * and executes them to generate real FileNodes.
 */
export const extractAndExecuteImageToolCalls = async (text: string): Promise<GeneratedAssetResult[]> => {
  const results: GeneratedAssetResult[] = [];
  const regex = /\[IMAGE_TOOL:\s*"([^"]+)"(?:,\s*path:\s*"([^"]+)")?\]/g;
  let match;

  while ((match = regex.exec(text)) !== null) {
    const prompt = match[1];
    const path = match[2];
    let folder = 'public/images';
    let file = undefined;

    if (path) {
      const parts = path.split('/');
      file = parts.pop();
      folder = parts.join('/') || 'public/images';
    }

    try {
      const fileNode = await generateImageTool(prompt, file, folder);
      results.push({
        imageUrl: fileNode.content,
        assetPath: fileNode.name,
        fileName: fileNode.name.split('/').pop() || 'asset.png',
        prompt,
        fileNode
      });
    } catch (e) {
      console.error('Image tool execution failed:', e);
    }
  }

  return results;
};
