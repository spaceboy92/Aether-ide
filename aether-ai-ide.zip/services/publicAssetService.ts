// ============================================================================
// PUBLIC INTERNET 3D ASSETS, TEXTURES & SOUND CDN MARKETPLACE & IMPORTER
// Fetches publicly available open-source GLTF/OBJ 3D models, CC0 textures, and SFX
// ============================================================================

export interface Public3DAsset {
  id: string;
  name: string;
  category: 'character' | 'vehicle' | 'weapon' | 'prop' | 'architecture' | 'foliage' | 'texture' | 'audio';
  format: 'gltf' | 'glb' | 'obj' | 'texture_png' | 'audio_mp3';
  sourceUrl: string;
  previewImage: string;
  license: string;
  tags: string[];
  filesizeKb: number;
}

export const CURATED_PUBLIC_ASSETS: Public3DAsset[] = [
  {
    id: 'khronos_damaged_helmet',
    name: 'PBR Damaged Sci-Fi Helmet',
    category: 'prop',
    format: 'gltf',
    sourceUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/main/2.0/DamagedHelmet/glTF/DamagedHelmet.gltf',
    previewImage: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/main/2.0/DamagedHelmet/screenshot/screenshot.png',
    license: 'CC-BY 4.0',
    tags: ['helmet', 'pbr', 'sci-fi', 'armour'],
    filesizeKb: 3400
  },
  {
    id: 'khronos_fox_animated',
    name: 'Animated Forest Fox',
    category: 'character',
    format: 'glb',
    sourceUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/main/2.0/Fox/glTF-Binary/Fox.glb',
    previewImage: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/main/2.0/Fox/screenshot/screenshot.jpg',
    license: 'CC0 Public Domain',
    tags: ['fox', 'animal', 'animated', 'character'],
    filesizeKb: 2100
  },
  {
    id: 'khronos_duck',
    name: 'Classic 3D Duck',
    category: 'prop',
    format: 'glb',
    sourceUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/main/2.0/Duck/glTF-Binary/Duck.glb',
    previewImage: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/main/2.0/Duck/screenshot/screenshot.png',
    license: 'CC0',
    tags: ['duck', 'toy', 'vehicle'],
    filesizeKb: 1200
  },
  {
    id: 'khronos_avocado',
    name: 'Photorealistic Avocado',
    category: 'prop',
    format: 'glb',
    sourceUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/main/2.0/Avocado/glTF-Binary/Avocado.glb',
    previewImage: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/main/2.0/Avocado/screenshot/screenshot.jpg',
    license: 'CC0',
    tags: ['avocado', 'food', 'nature'],
    filesizeKb: 850
  },
  {
    id: 'khronos_boombox',
    name: 'PBR Retro Boombox',
    category: 'prop',
    format: 'glb',
    sourceUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/main/2.0/BoomBox/glTF-Binary/BoomBox.glb',
    previewImage: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/main/2.0/BoomBox/screenshot/screenshot.png',
    license: 'CC-BY',
    tags: ['audio', 'boombox', 'electronics'],
    filesizeKb: 4200
  },
  {
    id: 'khronos_water_bottle',
    name: 'PBR Metal Water Bottle',
    category: 'prop',
    format: 'glb',
    sourceUrl: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/main/2.0/WaterBottle/glTF-Binary/WaterBottle.glb',
    previewImage: 'https://raw.githubusercontent.com/KhronosGroup/glTF-Sample-Models/main/2.0/WaterBottle/screenshot/screenshot.png',
    license: 'CC0',
    tags: ['bottle', 'gear', 'item'],
    filesizeKb: 1100
  },
  {
    id: 'kenney_car_sedan',
    name: 'Kenney Low-Poly Sedan Car',
    category: 'vehicle',
    format: 'glb',
    sourceUrl: 'https://cdn.jsdelivr.net/gh/mrdoob/three.js@master/examples/models/gltf/Ferrari458/ferrari.glb',
    previewImage: 'https://threejs.org/examples/files/models/gltf/Ferrari458/thumbnail.png',
    license: 'CC0 Public Domain',
    tags: ['car', 'racing', 'vehicle', 'ferrari'],
    filesizeKb: 2800
  },
  {
    id: 'three_shadow_plane',
    name: 'High-Res Asphalt PBR Texture',
    category: 'texture',
    format: 'texture_png',
    sourceUrl: 'https://threejs.org/examples/textures/terrain/grasslight-big.jpg',
    previewImage: 'https://threejs.org/examples/textures/terrain/grasslight-big.jpg',
    license: 'CC0',
    tags: ['grass', 'ground', 'texture', 'terrain'],
    filesizeKb: 650
  }
];

export async function searchPublicAssets(query: string, category?: string): Promise<Public3DAsset[]> {
  const q = query.toLowerCase().trim();
  return CURATED_PUBLIC_ASSETS.filter(asset => {
    const matchesCategory = !category || category === 'all' || asset.category === category;
    const matchesQuery = !q || asset.name.toLowerCase().includes(q) || asset.tags.some(t => t.toLowerCase().includes(q));
    return matchesCategory && matchesQuery;
  });
}

export function generateAssetImportThreeCode(asset: Public3DAsset): string {
  if (asset.format === 'gltf' || asset.format === 'glb') {
    return `// Public GLTF Importer Agent Code for ${asset.name}
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';

const loader = new GLTFLoader();
loader.load('${asset.sourceUrl}', (gltf) => {
  const model = gltf.scene;
  model.position.set(0, 0, 0);
  model.traverse((child) => {
    if (child.isMesh) {
      child.castShadow = true;
      child.receiveShadow = true;
    }
  });
  scene.add(model);
  console.log('Successfully loaded internet public 3D asset: ${asset.name}');
}, undefined, (error) => {
  console.error('Error fetching public GLTF asset:', error);
});`;
  }
  return `// Asset URL: ${asset.sourceUrl}`;
}
