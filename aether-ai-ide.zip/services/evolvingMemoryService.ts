// Self-Evolving AI Memory & Preference Adaptation Service

export interface EvolvingUserProfile {
  version: number;
  userTone: 'concise' | 'detailed' | 'conversational' | 'technical';
  preferredStyling: string;
  preferredFramework: string;
  preferredArchitecture: string;
  frequentCorrections: string[];
  learnedInsights: string[];
  totalInteractions: number;
  lastEvolvedAt: string;
}

const DEFAULT_PROFILE: EvolvingUserProfile = {
  version: 1,
  userTone: 'technical',
  preferredStyling: 'Tailwind CSS, clean modern dark/light contrast UI',
  preferredFramework: 'React + TypeScript + Vite / Multi-Page Web Apps',
  preferredArchitecture: 'Modular files, real physical folder trees, explicit TS types, zero bloat',
  frequentCorrections: [
    'Always use real physical folder trees (e.g., src/pages/Home.tsx, public/images/asset.png)',
    'Support multi-page web app structures with full routing and navigation',
    'Include inline image generation and save assets directly to File Explorer'
  ],
  learnedInsights: [
    'User prefers clean modular file layouts over monolithic single-file code',
    'User builds both React single-page apps and multi-page web applications',
    'User expects real physical folder hierarchies in workspace'
  ],
  totalInteractions: 1,
  lastEvolvedAt: new Date().toISOString()
};

const STORAGE_KEY = 'aether_evolving_user_profile';

export const getEvolvingProfile = (): EvolvingUserProfile => {
  if (typeof window === 'undefined') return DEFAULT_PROFILE;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_PROFILE));
      return DEFAULT_PROFILE;
    }
    return JSON.parse(raw);
  } catch (e) {
    console.error('Failed to parse evolving user profile:', e);
    return DEFAULT_PROFILE;
  }
};

export const updateEvolvingProfile = (partial: Partial<EvolvingUserProfile>): EvolvingUserProfile => {
  const current = getEvolvingProfile();
  const updated: EvolvingUserProfile = {
    ...current,
    ...partial,
    totalInteractions: current.totalInteractions + 1,
    lastEvolvedAt: new Date().toISOString()
  };
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  }
  return updated;
};

export const recordUserInteraction = (prompt: string, userFeedback?: string): EvolvingUserProfile => {
  const profile = getEvolvingProfile();
  const newInsights = [...profile.learnedInsights];
  const newCorrections = [...profile.frequentCorrections];

  const lowerPrompt = (prompt || '').toLowerCase();
  const lowerFeedback = (userFeedback || '').toLowerCase();

  // Pattern detection for automated evolution
  if (lowerPrompt.includes('multi page') || lowerPrompt.includes('multipage') || lowerPrompt.includes('multiple html') || lowerPrompt.includes('multiple pages')) {
    if (!newInsights.includes('User frequently creates multi-page web applications')) {
      newInsights.push('User frequently creates multi-page web applications');
    }
  }

  if (lowerPrompt.includes('folder') || lowerPrompt.includes('directory') || lowerPrompt.includes('tree')) {
    if (!newInsights.includes('User values physical nested folder tree hierarchy')) {
      newInsights.push('User values physical nested folder tree hierarchy');
    }
  }

  if (lowerPrompt.includes('image') || lowerPrompt.includes('asset') || lowerPrompt.includes('logo') || lowerPrompt.includes('banner')) {
    if (!newInsights.includes('User uses AI image generation for UI assets and chat media')) {
      newInsights.push('User uses AI image generation for UI assets and chat media');
    }
  }

  if (lowerFeedback.includes('don\'t') || lowerFeedback.includes('instead of') || lowerFeedback.includes('fix') || lowerFeedback.includes('change')) {
    const cleanFeedback = userFeedback?.slice(0, 150) || '';
    if (cleanFeedback && !newCorrections.includes(cleanFeedback)) {
      newCorrections.push(cleanFeedback);
      if (newCorrections.length > 10) newCorrections.shift(); // keep latest 10
    }
  }

  return updateEvolvingProfile({
    learnedInsights: newInsights,
    frequentCorrections: newCorrections
  });
};

export const getEvolvingSystemInstruction = (): string => {
  const profile = getEvolvingProfile();
  return `
[SELF-EVOLVING USER PREFERENCES & CODE STYLE PROFILE]:
- User Interaction Generation: #${profile.totalInteractions}
- Preferred Tone: ${profile.userTone}
- Preferred Styling Engine: ${profile.preferredStyling}
- Target Tech Stack: ${profile.preferredFramework}
- Architectural Pattern: ${profile.preferredArchitecture}
- Adaptive Insights Learned Over Time:
${profile.learnedInsights.map(i => `  • ${i}`).join('\n')}
- Frequent User Corrections & Preferences To Enforce:
${profile.frequentCorrections.map(c => `  • ${c}`).join('\n')}
`;
};

export const resetEvolvingProfile = (): EvolvingUserProfile => {
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_PROFILE));
  }
  return DEFAULT_PROFILE;
};
