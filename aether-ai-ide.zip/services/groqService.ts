import { FileNode, ChatMessage } from '../types';
import { parseAIResponse, SimpleAIResponse } from './aiResponseParser';
import { parseProgressiveStream } from './progressiveStreamParser';

/**
 * Trims context and history messages for Groq & OpenAI-compatible endpoints to fit TPM limits (e.g., 8000 TPM limit on Groq)
 */
export const budgetGroqPayload = (
  prompt: string,
  currentFiles: FileNode[],
  history: ChatMessage[]
) => {
  // Compact file context to fit under Groq 8000 TPM limit
  const budgetedFiles = (currentFiles || []).map(f => {
    if (f.isBinary) return f;
    let text = f.content || '';
    if (text.length > 1000) {
      text = text.slice(0, 500) + '\n... [content truncated for Groq TPM budget] ...\n' + text.slice(-400);
    }
    return { ...f, content: text };
  });

  // Slide history to latest 3 messages max
  const budgetedHistory = (history || []).slice(-3).map(msg => {
    let txt = msg.text || '';
    if (txt.length > 1000) txt = txt.slice(0, 500) + '...' + txt.slice(-400);
    return { ...msg, text: txt };
  });

  return {
    budgetedFiles,
    budgetedHistory,
    prompt
  };
};

export const chatWithGroqStream = async (
  modelId: string,
  prompt: string,
  currentFiles: FileNode[],
  history: ChatMessage[],
  onChunk: (thoughts: string, message: string, steps?: { step: string; status: string }[], codeFragment?: string, metrics?: any) => void,
  onRawChunk?: (text: string) => void,
  attachments: { mimeType: string; data: string }[] = []
): Promise<SimpleAIResponse> => {
  try {
    const streamStartTime = Date.now();
    const clientKey = typeof window !== 'undefined' ? (localStorage.getItem('ollama_api_key') || localStorage.getItem('openai_api_key') || '') : '';
    const serverUrl = typeof window !== 'undefined' ? (localStorage.getItem('ollama_server_url') || '') : '';

    const { budgetedFiles, budgetedHistory } = budgetGroqPayload(prompt, currentFiles, history);

    onChunk("", `Streaming via Groq/Custom AI Engine (${modelId})...`, [{ step: `Routing stream to Groq (${modelId})...`, status: "active" }]);

    const response = await fetch('/api/custom-ai/stream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        modelId,
        endpoint: serverUrl || undefined,
        apiKey: clientKey || undefined,
        prompt,
        currentFiles: budgetedFiles,
        history: budgetedHistory,
        attachments
      })
    });

    if (!response.ok || !response.body) {
      const errText = await response.text().catch(() => '');
      throw new Error(`Groq stream failed with status ${response.status}: ${errText.slice(0, 200)}`);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let fullText = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const chunk = decoder.decode(value, { stream: true });
      if (chunk) {
        fullText += chunk;
        if (onRawChunk) onRawChunk(chunk);

        try {
          const parsedState = parseProgressiveStream(fullText, streamStartTime);
          const fragments: Record<string, string> = {};
          Object.values(parsedState.files).forEach(f => {
            fragments[f.path] = f.code;
          });

          onChunk(
            parsedState.thoughts, 
            parsedState.message, 
            parsedState.reasoningSteps,
            Object.keys(fragments).length > 0 ? JSON.stringify(fragments) : undefined,
            parsedState.metrics
          );
        } catch (e) {
          // progressive parse error
        }
      }
    }

    if (!fullText) fullText = "{}";
    return parseAIResponse(fullText);
  } catch (err: any) {
    console.error("Groq stream execution error:", err);
    throw err;
  }
};
