import * as THREE from 'three';

export interface RiggedBoneInfo {
  name: string;
  position: [number, number, number];
  parentName?: string;
}

export interface AnimationClipInfo {
  name: string;
  duration: number;
  tracksCount: number;
}

export interface RiggedModelResult {
  skinnedMesh: THREE.SkinnedMesh;
  skeleton: THREE.Skeleton;
  bones: THREE.Bone[];
  mixer: THREE.AnimationMixer;
  clips: THREE.AnimationClip[];
  boneInfos: RiggedBoneInfo[];
}

/**
 * AI AUTO-RIGGING & ANIMATION SYNTHESIZER
 * Given any THREE.BufferGeometry or THREE.Mesh, automatically detects bounding box,
 * builds a humanoid/mech joint skeleton, calculates vertex skin weights,
 * and creates 6 procedural keyframe animation clips.
 */
export function autoRigAndAnimateModel(
  geometryInput: THREE.BufferGeometry,
  materialInput?: THREE.Material,
  modelScale = 1.0
): RiggedModelResult {
  // Ensure geometry is indexed and non-null
  let geometry = geometryInput.clone();
  geometry.computeBoundingBox();
  const bbox = geometry.boundingBox || new THREE.Box3(new THREE.Vector3(-1, 0, -1), new THREE.Vector3(1, 2, 1));
  const size = new THREE.Vector3();
  bbox.getSize(size);
  const center = new THREE.Vector3();
  bbox.getCenter(center);

  // Center geometry vertically at origin (feet at y=0)
  geometry.translate(-center.x, -bbox.min.y, -center.z);
  geometry.computeBoundingBox();
  const height = size.y > 0.1 ? size.y : 2.0;

  // Build Humanoid Bone Joint Structure
  const hips = new THREE.Bone();
  hips.name = 'root_hips';
  hips.position.set(0, height * 0.5, 0);

  const spine = new THREE.Bone();
  spine.name = 'spine';
  spine.position.set(0, height * 0.25, 0);
  hips.add(spine);

  const chest = new THREE.Bone();
  chest.name = 'chest';
  chest.position.set(0, height * 0.15, 0);
  spine.add(chest);

  const head = new THREE.Bone();
  head.name = 'head';
  head.position.set(0, height * 0.12, 0);
  chest.add(head);

  // Left Arm
  const leftShoulder = new THREE.Bone();
  leftShoulder.name = 'left_shoulder';
  leftShoulder.position.set(size.x * 0.35, height * 0.08, 0);
  chest.add(leftShoulder);

  const leftHand = new THREE.Bone();
  leftHand.name = 'left_hand';
  leftHand.position.set(size.x * 0.3, -height * 0.2, 0);
  leftShoulder.add(leftHand);

  // Right Arm
  const rightShoulder = new THREE.Bone();
  rightShoulder.name = 'right_shoulder';
  rightShoulder.position.set(-size.x * 0.35, height * 0.08, 0);
  chest.add(rightShoulder);

  const rightHand = new THREE.Bone();
  rightHand.name = 'right_hand';
  rightHand.position.set(-size.x * 0.3, -height * 0.2, 0);
  rightShoulder.add(rightHand);

  // Left Leg
  const leftHip = new THREE.Bone();
  leftHip.name = 'left_hip';
  leftHip.position.set(size.x * 0.2, -height * 0.05, 0);
  hips.add(leftHip);

  const leftKnee = new THREE.Bone();
  leftKnee.name = 'left_knee';
  leftKnee.position.set(0, -height * 0.22, 0);
  leftHip.add(leftKnee);

  const leftFoot = new THREE.Bone();
  leftFoot.name = 'left_foot';
  leftFoot.position.set(0, -height * 0.2, size.z * 0.15);
  leftKnee.add(leftFoot);

  // Right Leg
  const rightHip = new THREE.Bone();
  rightHip.name = 'right_hip';
  rightHip.position.set(-size.x * 0.2, -height * 0.05, 0);
  hips.add(rightHip);

  const rightKnee = new THREE.Bone();
  rightKnee.name = 'right_knee';
  rightKnee.position.set(0, -height * 0.22, 0);
  rightHip.add(rightKnee);

  const rightFoot = new THREE.Bone();
  rightFoot.name = 'right_foot';
  rightFoot.position.set(0, -height * 0.2, size.z * 0.15);
  rightKnee.add(rightFoot);

  const bones = [
    hips, spine, chest, head,
    leftShoulder, leftHand,
    rightShoulder, rightHand,
    leftHip, leftKnee, leftFoot,
    rightHip, rightKnee, rightFoot
  ];

  const skeleton = new THREE.Skeleton(bones);

  // Compute Vertex Skin Weights & Indices based on height & X position
  const posAttr = geometry.getAttribute('position');
  const vertexCount = posAttr.count;

  const skinIndices: number[] = [];
  const skinWeights: number[] = [];

  for (let i = 0; i < vertexCount; i++) {
    const x = posAttr.getX(i);
    const y = posAttr.getY(i);
    const z = posAttr.getZ(i);

    let primaryBone = 0;
    let secondaryBone = 1;
    let weight1 = 0.8;
    let weight2 = 0.2;

    const normY = Math.max(0, Math.min(1, y / height));

    if (normY < 0.25) {
      // Lower Legs / Feet
      if (x >= 0) {
        primaryBone = normY < 0.1 ? 10 : 9; // left foot/knee
        secondaryBone = 8; // left hip
      } else {
        primaryBone = normY < 0.1 ? 13 : 12; // right foot/knee
        secondaryBone = 11; // right hip
      }
    } else if (normY < 0.48) {
      // Upper Thighs / Hips
      primaryBone = x >= 0 ? 8 : 11;
      secondaryBone = 0; // hips
    } else if (normY < 0.65) {
      // Mid Spine
      primaryBone = 1; // spine
      secondaryBone = 2; // chest
    } else if (normY < 0.85) {
      // Arms / Chest
      if (Math.abs(x) > size.x * 0.18) {
        primaryBone = x > 0 ? 4 : 6; // shoulder
        secondaryBone = x > 0 ? 5 : 7; // hand
      } else {
        primaryBone = 2; // chest
        secondaryBone = 3; // head
      }
    } else {
      // Head
      primaryBone = 3; // head
      secondaryBone = 2; // chest
    }

    skinIndices.push(primaryBone, secondaryBone, 0, 0);
    skinWeights.push(weight1, weight2, 0, 0);
  }

  geometry.setAttribute('skinIndex', new THREE.Uint16BufferAttribute(skinIndices, 4));
  geometry.setAttribute('skinWeight', new THREE.Float32BufferAttribute(skinWeights, 4));

  // Default Material
  const material = materialInput || new THREE.MeshStandardMaterial({
    color: 0xa855f7,
    roughness: 0.25,
    metalness: 0.75,
    side: THREE.DoubleSide
  });

  const skinnedMesh = new THREE.SkinnedMesh(geometry, material);
  skinnedMesh.add(hips);
  skinnedMesh.bind(skeleton);
  skinnedMesh.scale.setScalar(modelScale);

  const mixer = new THREE.AnimationMixer(skinnedMesh);

  // Generate Keyframe Animations
  const clips: THREE.AnimationClip[] = [
    createIdleClip(bones),
    createWalkClip(bones),
    createRunClip(bones),
    createJumpClip(bones),
    createDanceClip(bones),
    createAttackClip(bones)
  ];

  const boneInfos: RiggedBoneInfo[] = bones.map(b => ({
    name: b.name,
    position: [b.position.x, b.position.y, b.position.z],
    parentName: b.parent?.name
  }));

  return {
    skinnedMesh,
    skeleton,
    bones,
    mixer,
    clips,
    boneInfos
  };
}

// 1. Idle Animation Clip
function createIdleClip(bones: THREE.Bone[]): THREE.AnimationClip {
  const times = [0, 1.0, 2.0];
  
  const hipsPosTrack = new THREE.VectorKeyframeTrack(
    'root_hips.position',
    times,
    [
      0, bones[0].position.y, 0,
      0, bones[0].position.y - 0.05, 0,
      0, bones[0].position.y, 0
    ]
  );

  const chestRotTrack = new THREE.QuaternionKeyframeTrack(
    'chest.quaternion',
    times,
    [
      0, 0, 0, 1,
      0, Math.sin(0.04), 0, Math.cos(0.04),
      0, 0, 0, 1
    ]
  );

  return new THREE.AnimationClip('Idle_Breath', 2.0, [hipsPosTrack, chestRotTrack]);
}

// 2. Walk Cycle Clip
function createWalkClip(bones: THREE.Bone[]): THREE.AnimationClip {
  const times = [0, 0.5, 1.0, 1.5, 2.0];

  const q0 = new THREE.Quaternion();
  const qLeftFwd = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), 0.35);
  const qLeftBack = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), -0.35);

  const leftHipRot = new THREE.QuaternionKeyframeTrack(
    'left_hip.quaternion',
    times,
    [
      ...qLeftFwd.toArray(),
      ...q0.toArray(),
      ...qLeftBack.toArray(),
      ...q0.toArray(),
      ...qLeftFwd.toArray()
    ]
  );

  const rightHipRot = new THREE.QuaternionKeyframeTrack(
    'right_hip.quaternion',
    times,
    [
      ...qLeftBack.toArray(),
      ...q0.toArray(),
      ...qLeftFwd.toArray(),
      ...q0.toArray(),
      ...qLeftBack.toArray()
    ]
  );

  return new THREE.AnimationClip('Walk_Cycle', 2.0, [leftHipRot, rightHipRot]);
}

// 3. Sprint Run Clip
function createRunClip(bones: THREE.Bone[]): THREE.AnimationClip {
  const times = [0, 0.25, 0.5, 0.75, 1.0];

  const qRun1 = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), 0.65);
  const qRun2 = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), -0.65);

  const leftLeg = new THREE.QuaternionKeyframeTrack(
    'left_hip.quaternion',
    times,
    [
      ...qRun1.toArray(),
      ...qRun2.toArray(),
      ...qRun1.toArray(),
      ...qRun2.toArray(),
      ...qRun1.toArray()
    ]
  );

  return new THREE.AnimationClip('Sprint_Run', 1.0, [leftLeg]);
}

// 4. Hero Jump Clip
function createJumpClip(bones: THREE.Bone[]): THREE.AnimationClip {
  const times = [0, 0.3, 0.7, 1.2];
  const yBase = bones[0].position.y;

  const jumpPos = new THREE.VectorKeyframeTrack(
    'root_hips.position',
    times,
    [
      0, yBase - 0.2, 0,
      0, yBase + 1.2, 0,
      0, yBase + 0.8, 0,
      0, yBase, 0
    ]
  );

  return new THREE.AnimationClip('Hero_Jump', 1.2, [jumpPos]);
}

// 5. Victory Dance Clip
function createDanceClip(bones: THREE.Bone[]): THREE.AnimationClip {
  const times = [0, 0.5, 1.0, 1.5, 2.0];
  const qLeft = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), 0.5);
  const qRight = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), -0.5);

  const hipsSpin = new THREE.QuaternionKeyframeTrack(
    'root_hips.quaternion',
    times,
    [
      ...qLeft.toArray(),
      ...qRight.toArray(),
      ...qLeft.toArray(),
      ...qRight.toArray(),
      ...qLeft.toArray()
    ]
  );

  return new THREE.AnimationClip('Victory_Dance', 2.0, [hipsSpin]);
}

// 6. Cyber Attack Clip
function createAttackClip(bones: THREE.Bone[]): THREE.AnimationClip {
  const times = [0, 0.3, 0.6, 1.0];
  const qAttack = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), 1.2);
  const qNormal = new THREE.Quaternion();

  const armSlash = new THREE.QuaternionKeyframeTrack(
    'right_shoulder.quaternion',
    times,
    [
      ...qNormal.toArray(),
      ...qAttack.toArray(),
      ...qAttack.toArray(),
      ...qNormal.toArray()
    ]
  );

  return new THREE.AnimationClip('Cyber_Attack', 1.0, [armSlash]);
}
