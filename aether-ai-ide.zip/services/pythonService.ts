export interface PythonExecResult {
  stdout: string;
  stderr: string;
  exitCode: number;
  durationMs: number;
  success: boolean;
  error?: string;
}

export interface PipPackage {
  name: string;
  version: string;
}

export const executePythonScript = async (script: string, args: string[] = []): Promise<PythonExecResult> => {
  try {
    const res = await fetch('/api/python/execute', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ script, args })
    });
    const data = await res.json();
    return data;
  } catch (err: any) {
    return {
      stdout: '',
      stderr: err?.message || 'Failed to connect to Python backend server',
      exitCode: 1,
      durationMs: 0,
      success: false,
      error: err?.message
    };
  }
};

export const getPythonVersion = async (): Promise<string> => {
  try {
    const res = await fetch('/api/python/version');
    const data = await res.json();
    return data.version || 'Python 3.10.12';
  } catch {
    return 'Python 3.10.12';
  }
};

export const fetchPipPackages = async (): Promise<PipPackage[]> => {
  try {
    const res = await fetch('/api/python/pip/list');
    const data = await res.json();
    return data.packages || [];
  } catch {
    return [];
  }
};

export const installPipPackage = async (packageName: string): Promise<{ success: boolean; stdout?: string; error?: string }> => {
  try {
    const res = await fetch('/api/python/pip/install', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ packageName })
    });
    const data = await res.json();
    return data;
  } catch (err: any) {
    return { success: false, error: err?.message || 'Installation request failed' };
  }
};
