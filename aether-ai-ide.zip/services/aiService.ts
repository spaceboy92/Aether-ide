import { chatWithNvidiaStream } from './geminiService';
import { chatWithGroqStream } from './groqService';
import { chatWithAnthropicStream } from './anthropicService';
import { chatWithOllamaStream } from './ollamaService';
import { chatWithOfflineQwenStream } from './offlineAiService';
import { recordUserInteraction } from './evolvingMemoryService';
import { FileNode, ChatMessage } from '../types';
import { SimpleAIResponse } from './aiResponseParser';

// Modern AI Service
export interface GenerationConfig {
  temperature?: number;
  topK?: number;
  topP?: number;
  maxOutputTokens?: number;
  responseMimeType?: string;
  systemInstruction?: string;
  customApiKey?: string;
  customEndpoint?: string;
}

export interface CustomAIModel {
  id: string;
  name: string;
  description: string;
  systemInstruction?: string;
  temperature?: number;
  topP?: number;
  topK?: number;
  responseMimeType?: string;
  tier: 'free' | 'premium';
  type?: string;
  isCustom?: boolean;
  powerScore?: number;
}

export const AVAILABLE_MODELS: CustomAIModel[] = [
  // Smart Orchestrator & Router
  {
    id: "aether-smart-router",
    name: "Aether AI Smart Router (Auto)",
    description: "Always routes prompts to the model with the least traffic that the user has added/accessed, prioritizing powerful models, and falling back to Gemini 2 family.",
    tier: "free",
    type: "gemini",
    powerScore: 100
  },
  // Flagship Gemini 3 Family
  {
    id: "gemini-3.7-flash",
    name: "Gemini 3.7 Flash",
    description: "Next-gen ultra-fast multimodal reasoning, instantaneous coding, and dynamic streaming.",
    tier: "free",
    type: "gemini",
    powerScore: 90
  },
  {
    id: "gemini-3.1-pro-preview",
    name: "Gemini 3.1 Pro",
    description: "Deep STEM logic, complex system architecture, and rigorous multi-file code synthesis.",
    tier: "free",
    type: "gemini",
    powerScore: 95
  },
  {
    id: "gemini-3.1-flash-lite",
    name: "Gemini 3.1 Flash Lite",
    description: "Ultra-low latency, lightweight, and cost-effective high-throughput assistant.",
    tier: "free",
    type: "gemini",
    powerScore: 82
  },

  // Groq LPU Family
  {
    id: "llama-3.3-70b-versatile",
    name: "Llama 3.3 70B (Groq)",
    description: "High-speed LPU accelerated reasoning and agentic coding via Groq cloud infrastructure.",
    tier: "free",
    type: "groq",
    powerScore: 92
  },
  {
    id: "llama-3.1-8b-instant",
    name: "Llama 3.1 8B Instant (Groq)",
    description: "Ultra-fast 128k context LPU model on Groq for instant responses.",
    tier: "free",
    type: "groq",
    powerScore: 80
  },

  // Anthropic Claude
  {
    id: "claude-3-7-sonnet-20250219",
    name: "Claude 3.7 Sonnet",
    description: "Hybrid reasoning architecture with deep thinking and high-precision full-stack synthesis.",
    tier: "premium",
    type: "anthropic",
    powerScore: 98
  },

  // DeepSeek AI
  {
    id: "deepseek-chat",
    name: "DeepSeek V3",
    description: "Elite open-weights code generation, refactoring, and logical deduction engine.",
    tier: "free",
    type: "deepseek",
    powerScore: 94
  },

  // Auxiliary Gemini Models
  {
    id: "gemini-2.5-flash",
    name: "Gemini 2.5 Flash",
    description: "Proven high-speed multimodal generation, quick answers, and active coding assistance.",
    tier: "free",
    type: "gemini",
    powerScore: 78
  },
  {
    id: "gemini-2.5-pro",
    name: "Gemini 2.5 Pro",
    description: "Deep multi-step reasoning, architectural planning, and complex refactoring.",
    tier: "free",
    type: "gemini",
    powerScore: 84
  }
];

// Model Traffic Registry
interface ModelTrafficEntry {
  activeRequests: number;
  lastErrorTimestamp: number;
  errorCount: number;
  lastUsedTimestamp: number;
}

const modelTrafficRegistry = new Map<string, ModelTrafficEntry>();

export const recordModelRequestStart = (modelId: string) => {
  const entry = modelTrafficRegistry.get(modelId) || { activeRequests: 0, lastErrorTimestamp: 0, errorCount: 0, lastUsedTimestamp: Date.now() };
  entry.activeRequests += 1;
  entry.lastUsedTimestamp = Date.now();
  modelTrafficRegistry.set(modelId, entry);
};

export const recordModelRequestEnd = (modelId: string, success: boolean = true) => {
  const entry = modelTrafficRegistry.get(modelId);
  if (entry) {
    entry.activeRequests = Math.max(0, entry.activeRequests - 1);
    if (!success) {
      entry.lastErrorTimestamp = Date.now();
      entry.errorCount += 1;
    }
    modelTrafficRegistry.set(modelId, entry);
  }
};

export const recordModelTrafficError = (modelId: string) => {
  recordModelRequestEnd(modelId, false);
};

export const getModelTrafficLoad = (modelId: string): number => {
  const entry = modelTrafficRegistry.get(modelId);
  if (!entry) return 0;
  const now = Date.now();
  const isRecentError = (now - entry.lastErrorTimestamp) < 120000;
  const errorPenalty = isRecentError ? (entry.errorCount * 25) : 0;
  return (entry.activeRequests * 10) + errorPenalty;
};

export const selectLowestTrafficPowerModel = (prompt: string = '', currentFiles: any[] = []): string => {
  const allModels = getAvailableModels();

  const hasAnthropicKey = typeof window !== 'undefined' && Boolean(localStorage.getItem('anthropic_api_key'));
  const hasGroqKey = typeof window !== 'undefined' && Boolean(localStorage.getItem('groq_api_key'));
  const hasOllamaKey = typeof window !== 'undefined' && Boolean(localStorage.getItem('ollama_api_key'));
  const hasOpenAIKey = typeof window !== 'undefined' && Boolean(localStorage.getItem('openai_api_key'));

  const accessibleModels = allModels.filter(m => {
    if (m.id === 'aether-smart-router') return false;
    if (m.isCustom) return true;
    if (m.type === 'anthropic' && !hasAnthropicKey) return false;
    if (m.type === 'groq' && !hasGroqKey) return false;
    if (m.type === 'openai' && !hasOpenAIKey) return false;
    if (m.type === 'ollama' && !hasOllamaKey) return false;
    return true;
  });

  const getPowerScore = (m: CustomAIModel): number => {
    if (m.powerScore) return m.powerScore;
    const id = m.id.toLowerCase();
    if (id.includes('claude-3-7') || id.includes('sonnet')) return 98;
    if (id.includes('gemini-3.1-pro') || id.includes('3.1-pro')) return 95;
    if (id.includes('deepseek') || id.includes('v3') || id.includes('r1')) return 94;
    if (id.includes('llama-3.3-70b') || id.includes('gpt-4o')) return 92;
    if (id.includes('gemini-3.7-flash') || id.includes('3.7-flash')) return 90;
    if (id.includes('gemini-2.5-pro') || id.includes('2.5-pro')) return 84;
    if (id.includes('gemini-2.5-flash') || id.includes('2.5-flash')) return 78;
    if (id.includes('gemini-2.0-flash') || id.includes('2.0-flash')) return 75;
    return 70;
  };

  // 1. Filter powerful models (powerScore >= 85) available to user
  const powerfulCandidates = accessibleModels.filter(m => getPowerScore(m) >= 85);

  // Exclude models with recent 503/429 traffic penalties (traffic load >= 25)
  const healthyPowerCandidates = powerfulCandidates.filter(m => getModelTrafficLoad(m.id) < 25);

  if (healthyPowerCandidates.length > 0) {
    healthyPowerCandidates.sort((a, b) => {
      const loadA = getModelTrafficLoad(a.id);
      const loadB = getModelTrafficLoad(b.id);
      if (loadA !== loadB) return loadA - loadB;
      return getPowerScore(b) - getPowerScore(a);
    });

    const chosen = healthyPowerCandidates[0];
    console.log(`[Aether Smart Router] Selected least-traffic power model: ${chosen.name} (${chosen.id}) | Traffic Load: ${getModelTrafficLoad(chosen.id)}`);
    return chosen.id;
  }

  // 2. Fallback to Gemini 2 family if all power models are busy or throttled
  console.warn('[Aether Smart Router] Powerful models currently experiencing high demand. Routing to Gemini 2 family fallback...');
  const gemini2Models = accessibleModels.filter(m => {
    const id = m.id.toLowerCase();
    return id.includes('2.5-pro') || id.includes('2.5-flash') || id.includes('2.0-flash') || id.includes('1.5');
  });

  if (gemini2Models.length > 0) {
    gemini2Models.sort((a, b) => getModelTrafficLoad(a.id) - getModelTrafficLoad(b.id));
    return gemini2Models[0].id;
  }

  return 'gemini-2.5-flash';
};

export const detectProviderFromEndpoint = (endpoint: string, modelName: string = ''): {
  type: string;
  providerName: string;
} => {
  const ep = (endpoint || '').toLowerCase();
  const mn = (modelName || '').toLowerCase();

  if (ep.includes('groq.com') || mn.includes('groq')) {
    return { type: 'groq', providerName: 'Groq' };
  }
  if (ep.includes('openrouter.ai') || mn.includes('openrouter')) {
    return { type: 'openrouter', providerName: 'OpenRouter' };
  }
  if (ep.includes('deepseek.com') || mn.includes('deepseek')) {
    return { type: 'deepseek', providerName: 'DeepSeek' };
  }
  if (ep.includes('together') || mn.includes('together')) {
    return { type: 'together', providerName: 'Together AI' };
  }
  if (ep.includes('openai.com') || mn.startsWith('gpt-') || mn.startsWith('o1') || mn.startsWith('o3')) {
    return { type: 'openai', providerName: 'OpenAI' };
  }
  if (ep.includes('anthropic.com') || mn.includes('claude')) {
    return { type: 'anthropic', providerName: 'Anthropic' };
  }
  if (ep.includes(':11434') || ep.includes('localhost') || ep.includes('127.0.0.1') || ep.includes('ollama')) {
    return { type: 'ollama', providerName: 'Ollama' };
  }
  return { type: 'custom', providerName: 'Custom AI' };
};

export const getAvailableModels = (): CustomAIModel[] => {
  if (typeof window === 'undefined') return AVAILABLE_MODELS;
  const saved = localStorage.getItem('aether_custom_ai_models');
  if (saved) {
    try {
      const parsed = JSON.parse(saved) as CustomAIModel[];
      const serverUrl = localStorage.getItem('ollama_server_url') || '';

      const validCustoms = parsed
        .filter(m => Boolean(m.id && m.name))
        .map(m => {
          const cleanId = m.id.replace(/^ollama_/i, '');
          const providerInfo = detectProviderFromEndpoint(serverUrl, cleanId);
          const cleanType = (m.type === 'ollama' && providerInfo.type !== 'ollama') ? providerInfo.type : (m.type || providerInfo.type);
          let cleanName = m.name;
          if (cleanName.includes('(Ollama)') && providerInfo.providerName !== 'Ollama') {
            cleanName = cleanName.replace(/\(Ollama\)$/i, `(${providerInfo.providerName})`);
          }

          return {
            ...m,
            id: cleanId,
            name: cleanName,
            type: cleanType,
            isCustom: true,
            tier: m.tier || ('free' as const)
          };
        });

      // Deduplicate by ID
      const baseIds = new Set(AVAILABLE_MODELS.map(m => m.id));
      const customUnique: CustomAIModel[] = [];
      const seenIds = new Set<string>();

      for (const m of validCustoms) {
        if (!baseIds.has(m.id) && !seenIds.has(m.id)) {
          seenIds.add(m.id);
          customUnique.push(m);
        }
      }

      return [...AVAILABLE_MODELS, ...customUnique];
    } catch (e) {
      // ignore
    }
  }
  return AVAILABLE_MODELS;
};

export const addCustomModel = (model: Omit<CustomAIModel, 'tier' | 'isCustom'>): CustomAIModel => {
  const newModel: CustomAIModel = {
    ...model,
    tier: 'free',
    isCustom: true
  };
  if (typeof window !== 'undefined') {
    const saved = localStorage.getItem('aether_custom_ai_models');
    let list: CustomAIModel[] = [];
    if (saved) {
      try { list = JSON.parse(saved); } catch (e) {}
    }
    // Filter duplicates
    list = list.filter(m => m.id !== newModel.id);
    list.push(newModel);
    localStorage.setItem('aether_custom_ai_models', JSON.stringify(list));
    window.dispatchEvent(new Event('aether_custom_models_updated'));
  }
  return newModel;
};

export const deleteCustomModel = (modelId: string): boolean => {
  if (typeof window !== 'undefined') {
    const saved = localStorage.getItem('aether_custom_ai_models');
    if (saved) {
      try {
        let list: CustomAIModel[] = JSON.parse(saved);
        const originalLength = list.length;
        list = list.filter(m => m.id !== modelId);
        if (list.length !== originalLength) {
          localStorage.setItem('aether_custom_ai_models', JSON.stringify(list));
          window.dispatchEvent(new Event('aether_custom_models_updated'));
          return true;
        }
      } catch (e) {}
    }
  }
  return false;
};

export const generateContent = async (
  modelId: string,
  prompt: string,
  config?: GenerationConfig,
  images?: { mimeType: string; data: string }[]
): Promise<string> => {
  try {
    const response = await fetch('/api/ai/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ modelId, prompt, config, images })
    });
    if (response.ok) {
      const data = await response.json();
      return data.text || '';
    }
    const err = await response.text();
    throw new Error(err || `Server error: ${response.status}`);
  } catch (e: any) {
    console.error("aiService generateContent failed:", e);
    throw e;
  }
};

export const generateContentStream = async function* (
  modelId: string,
  prompt: string,
  config?: GenerationConfig,
  images?: { mimeType: string; data: string }[]
) {
  try {
    const response = await fetch('/api/ai/generate-stream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ modelId, prompt, config, images })
    });
    
    if (!response.ok) {
      const err = await response.text();
      throw new Error(err || `Server error: ${response.status}`);
    }

    const reader = response.body?.getReader();
    const decoder = new TextDecoder();
    if (reader) {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        yield decoder.decode(value, { stream: true });
      }
    }
  } catch (e: any) {
    console.error("aiService generateContentStream failed:", e);
    throw e;
  }
};

/**
 * Universal Stream Dispatcher for all AI Providers
 */
export const chatWithModelStream = async (
  modelId: string,
  prompt: string,
  currentFiles: FileNode[],
  history: ChatMessage[],
  onChunk: (thoughts: string, message: string, steps?: { step: string; status: string }[], codeFragment?: string, metrics?: any) => void,
  onRawChunk?: (text: string) => void,
  maxOutputTokens?: number,
  isCompactMode?: boolean,
  attachments: { mimeType: string; data: string }[] = [],
  activeAgentIds?: string[]
): Promise<SimpleAIResponse> => {
  // Self-Evolving AI Model Adaptation
  recordUserInteraction(prompt);

  const norm = (modelId || '').toLowerCase().trim();
  const allModels = getAvailableModels();
  const selectedModel = allModels.find(m => m.id === modelId);
  const selectedType = selectedModel?.type || '';

  // 1. Browser-native WebLLM / Qwen Local Offline Model
  if (norm.includes('offline') || norm.startsWith('qwen')) {
    return chatWithOfflineQwenStream(modelId, prompt, currentFiles, history, onChunk, onRawChunk);
  }

  // 2. Local or Remote Ollama Model
  if (selectedType === 'ollama' || norm.startsWith('ollama_') || norm.startsWith('ollama:') || norm.startsWith('ollama/')) {
    return chatWithOllamaStream(modelId, prompt, currentFiles, history, onChunk, onRawChunk);
  }

  // 3. Anthropic Claude Family
  if (selectedType === 'anthropic' || norm.includes('claude') || norm.includes('anthropic')) {
    return chatWithAnthropicStream(modelId, prompt, currentFiles, history, onChunk, onRawChunk);
  }

  // 4. Groq / OpenAI / OpenRouter / DeepSeek / Custom AI
  if (
    selectedType === 'groq' ||
    selectedType === 'openai' ||
    selectedType === 'deepseek' ||
    selectedType === 'together' ||
    selectedType === 'openrouter' ||
    selectedType === 'custom' ||
    norm.startsWith('groq/') ||
    norm.includes('llama') ||
    norm.includes('mixtral') ||
    norm.includes('gemma') ||
    norm.includes('deepseek') ||
    norm.includes('together') ||
    norm.includes('openrouter') ||
    norm.includes('gpt') ||
    norm.includes('o1') ||
    norm.includes('o3')
  ) {
    try {
      return await chatWithGroqStream(modelId, prompt, currentFiles, history, onChunk, onRawChunk, attachments);
    } catch (groqErr: any) {
      console.warn(`Groq/Custom stream failed (${groqErr.message}). Auto-recovering via Gemini 3.7 Flash fallback:`, groqErr);
      onChunk(
        `Upstream provider notice: ${groqErr.message || 'Stream connection issue'}. Automatically recovering your request with high-speed Gemini 3.7 Flash...`,
        `Synthesizing response with Gemini 3.7 Flash fallback...`,
        [{ step: `Rerouting to Gemini 3.7 Flash fallback...`, status: "active" }]
      );
      return chatWithNvidiaStream('gemini-3.7-flash', prompt, currentFiles, history, onChunk, onRawChunk, maxOutputTokens, isCompactMode, attachments, activeAgentIds);
    }
  }

  // 5. Default Gemini Cloud Models
  return chatWithNvidiaStream(modelId, prompt, currentFiles, history, onChunk, onRawChunk, maxOutputTokens, isCompactMode, attachments, activeAgentIds);
};

