
import { GoogleGenAI, Type, FunctionDeclaration, ThinkingLevel } from "@google/genai";
import { FileNode, ChatMessage, TerminalLog } from '../types';
import { sanitizeAndRepairCode } from './fileService';
import { parseAIResponse, SimpleAIResponse } from './aiResponseParser';
import { chatWithModelStream, selectLowestTrafficPowerModel, recordModelRequestStart, recordModelRequestEnd, recordModelTrafficError } from './aiService';
import { ORCHESTRATOR_DIVISIONS } from '../components/AI/AIAssistant/orchestratorClassifier';
import { parseProgressiveStream } from './progressiveStreamParser';

export { parseAIResponse };
export type { SimpleAIResponse };

const getAIClient = (overrideApiKey?: string) => {
    const key = overrideApiKey || 
                (typeof window !== 'undefined' ? (localStorage.getItem('gemini_api_key') || '') : '') || 
                (typeof process !== 'undefined' && process.env ? (process.env.GEMINI_API_KEY || process.env.API_KEY || '') : '') || 
                '';
    return new GoogleGenAI({ apiKey: key });
};

export const retryWithBackoff = async <T>(fn: () => Promise<T>, retries = 3, delay = 1000): Promise<T> => {
    try {
        return await fn();
    } catch (error: any) {
        if (retries > 0 && error?.status === 429) {
            console.warn(`Rate limit hit, retrying in ${delay}ms...`);
            await new Promise(resolve => setTimeout(resolve, delay));
            return retryWithBackoff(fn, retries - 1, delay * 2);
        }
        throw error;
    }
};

// Simplified Schema for Direct Action
const directResponseSchema = {
  type: Type.OBJECT,
  properties: {
    thoughts: { type: Type.STRING, description: "Your internal reasoning process. Detail how you will satisfy the user request correctly, safely, and completely." },
    reasoningSteps: {
      type: Type.ARRAY,
      description: "Detailed steps of your reasoning process for the user to see.",
      items: {
        type: Type.OBJECT,
        properties: {
          step: { type: Type.STRING },
          status: { type: Type.STRING, enum: ["pending", "active", "completed", "failed"] }
        },
        required: ["step", "status"]
      }
    },
    message: { type: Type.STRING, description: "A friendly, concise response to the user." },
    files: {
      type: Type.ARRAY,
      description: "MANDATORY list of files. You can create physical folder hierarchies (e.g. 'index.html', 'style.css', 'script.js', 'pages/about.html', 'js/app.js', 'services/api.js') and multi-page apps. ALWAYS build modular multi-file web architectures: index.html (entry markup linking style.css and script.js), style.css (custom styles & animations), and script.js (or gameEngine.js, audioSynth.js). STRICT MANDATE: Generate Web Apps ONLY with pure HTML, CSS, and Vanilla JS. DO NOT use React, JSX, TSX, React UMD scripts, Babel scripts, or CDN React tags inside HTML or JS files.",
      items: {
        type: Type.OBJECT,
        properties: {
          operation: { type: Type.STRING, enum: ["create", "update", "delete"] },
          path: { type: Type.STRING, description: "Absolute path in the project, e.g., 'index.html', 'style.css', 'script.js', 'js/app.js', or 'pages/about.html'" },
          code: { type: Type.STRING, description: "The FULL and COMPLETE file content. Do not use placeholders. MUST be properly formatted with multiple lines, indentation, and newlines. DO NOT output single-line minified code." }
        },
        required: ["operation", "path", "code"]
      }
    },
    commands: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Optional terminal commands to run. Example: ['npm install axios']"
    },
    customModels: {
      type: Type.ARRAY,
      description: "Optional custom AI models/agents to create or update based on user request. When the user asks you to build, customize, or generate a specialized AI model, agent, or assistant, specify it here.",
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING, description: "A unique slug/id for the model (alphanumeric, dashes, no spaces), e.g., 'copywriting-specialist', 'visual-critic'." },
          name: { type: Type.STRING, description: "Human-readable name of the model, e.g., 'Copywriting Specialist'." },
          description: { type: Type.STRING, description: "A short sentence explaining what this custom model specializes in." },
          systemInstruction: { type: Type.STRING, description: "The full system instruction/persona prompt that guides this custom model's behavior. Must be detailed and specific." },
          temperature: { type: Type.NUMBER, description: "Optional temperature value from 0.0 to 2.0 (default 1.0)." }
        },
        required: ["id", "name", "description", "systemInstruction"]
      }
    }
  },
  required: ["message", "files", "thoughts"]
};

export const enhancePrompt = async (originalPrompt: string): Promise<string> => {
    if (typeof window !== 'undefined') {
        const clientApiKey = localStorage.getItem('gemini_api_key') || '';
        if (clientApiKey) {
            try {
                const ai = new GoogleGenAI({ apiKey: clientApiKey });
                const response = await ai.models.generateContent({
                    model: 'gemini-3.7-flash', // Use Gemini 3.7 flash for fast enhancement
                    contents: {
                        parts: [{ text: `You are an elite software and game design prompt engineer. Expand the following user prompt into a complete, high-precision technical specification for an AI code generator.
If the prompt relates to a 3D or 2D game: specify clean multi-file architecture (index.html, style.css, script.js / gameEngine.js), Three.js/WebGL or Canvas 2D loop, camera lerp controls, directional lighting with shadow map casting, PBR materials, delta-time physics velocity vectors, particle explosion engines, 100% client-side Web Audio API sound synthesizers (lasers, engine revs, explosions, synth music loops), and a responsive Tailwind UI HUD (health bar, score, minimap, start overlay, game over modal with restart button).
If the prompt relates to a web application or multi-page app: specify clean modular multi-file web architecture with index.html, style.css, and script.js (or modular html/js files in pages/), modern Tailwind CSS styling, responsive card grids, glassmorphism, smooth animations, interactive state handlers, persistent local storage, and zero missing functions or empty placeholders.
MANDATORY ARCHITECTURE RULE: Generate Web Apps ONLY with pure HTML, CSS, and Vanilla JS (index.html, style.css, script.js). DO NOT use React, JSX, TSX, React script links, or Babel CDN scripts.
Keep the core intent exact. Return ONLY the enhanced prompt string.
Prompt: "${originalPrompt}"` }]
                    }
                });
                return response.text?.trim() || originalPrompt;
            } catch (err) {
                console.error("Direct browser prompt enhancement failed, trying fallback...", err);
            }
        }
        try {
            const response = await fetch('/api/gemini/enhance', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ prompt: originalPrompt })
            });
            if (response.ok) {
                const data = await response.json();
                return data.result || originalPrompt;
            }
        } catch (e) {
            console.error("Client enhance failed, using original prompt:", e);
        }
        return originalPrompt;
    }

    const ai = getAIClient();
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3.7-flash',
            contents: {
                parts: [{ text: `You are an elite software and game design prompt engineer. Expand the following user prompt into a complete, high-precision technical specification for an AI code generator.
If the prompt relates to a 3D or 2D game: specify clean multi-file architecture (index.html, style.css, script.js / gameEngine.js), Three.js/WebGL or Canvas 2D loop, camera lerp controls, directional lighting with shadow map casting, PBR materials, delta-time physics velocity vectors, particle explosion engines, 100% client-side Web Audio API sound synthesizers (lasers, engine revs, explosions, synth music loops), and a responsive Tailwind UI HUD (health bar, score, minimap, start overlay, game over modal with restart button).
If the prompt relates to a web application or multi-page app: specify clean modular multi-file web architecture with index.html, style.css, and script.js (or modular html/js files in pages/), modern Tailwind CSS styling, responsive card grids, glassmorphism, smooth animations, interactive state handlers, persistent local storage, and zero missing functions or empty placeholders.
MANDATORY ARCHITECTURE RULE: Generate Web Apps ONLY with pure HTML, CSS, and Vanilla JS (index.html, style.css, script.js). DO NOT use React, JSX, TSX, React script links, or Babel CDN scripts.
Keep the core intent exact. Return ONLY the enhanced prompt string.
Prompt: "${originalPrompt}"` }]
            }
        });
        return response.text?.trim() || originalPrompt;
    } catch (e) {
        console.error("Enhance failed", e);
        return originalPrompt;
    }
};

export const MODELS = {
  // Gemini 3 Family (Flagship)
  GEMINI_3_7_FLASH: 'gemini-3.7-flash',
  GEMINI_3_1_PRO: 'gemini-3.1-pro-preview',
  GEMINI_3_1_FLASH_LITE: 'gemini-3.1-flash-lite',
  GEMINI_3_1_FLASH_IMAGE: 'gemini-3.1-flash-lite',
  GEMINI_3_1_FLASH_LITE_IMAGE: 'gemini-3.1-flash-lite',
  GEMINI_3_1_TTS: 'gemini-3.1-flash-tts-preview',
  GEMINI_3_1_LIVE: 'gemini-3.1-flash-live-preview',

  // Gemini 2.5 Series
  GEMINI_2_5_FLASH: 'gemini-2.5-flash',
  GEMINI_2_5_PRO: 'gemini-2.5-pro',

  // Aliases & Fallbacks
  GEMINI_PRO: 'gemini-3.1-pro-preview',
  GEMINI_FLASH: 'gemini-3.7-flash',
  GEMINI_FLASH_LITE: 'gemini-3.1-flash-lite',
  CLAUDE_3_7_SONNET: 'claude-3-7-sonnet',
  CLAUDE_3_5_SONNET: 'claude-3-5-sonnet',
  CLAUDE_3_5_HAIKU: 'claude-3-5-haiku',
  CLAUDE_3_OPUS: 'claude-3-opus',

  AETHER_FLASH: 'gemini-3.7-flash',
  AETHER_PRO: 'gemini-3.1-pro-preview',
  AETHER_ULTRA: 'gemini-3.1-pro-preview',
  AETHER_UNIFIED: 'gemini-3.7-flash',
  OMNI: 'gemini-3.7-flash',
  AETHER_LITE: 'gemini-3.1-flash-lite',
  NVIDIA_NEMOTRON: 'gemini-3.1-pro-preview',
  QWEN_NVIDIA: 'gemini-3.1-pro-preview'
};

export interface ModelProviderInfo {
  provider: 'gemini' | 'groq' | 'anthropic' | 'ollama' | 'openai' | 'deepseek' | 'custom';
  displayName: string;
  endpoint: string;
  actualModelId: string;
}

export const detectModelProvider = (modelId: string): ModelProviderInfo => {
  const normalized = (modelId || '').toLowerCase().trim();
  const rawModel = modelId.replace(/^ollama[_:/]/i, '').replace(/^groq\//i, '');
  const rawNorm = rawModel.toLowerCase();

  // 1. Groq Models
  if (
    normalized.startsWith('groq/') ||
    rawNorm.includes('llama-3.3') ||
    rawNorm.includes('llama-3.1') ||
    rawNorm.includes('mixtral') ||
    rawNorm.includes('gemma2') ||
    rawNorm.includes('groq')
  ) {
    return {
      provider: 'groq',
      displayName: 'Groq LPU',
      endpoint: '/api/custom-ai/stream',
      actualModelId: rawModel
    };
  }

  // 2. Anthropic Claude
  if (rawNorm.includes('claude') || rawNorm.includes('anthropic')) {
    return {
      provider: 'anthropic',
      displayName: 'Anthropic Claude',
      endpoint: '/api/anthropic/stream',
      actualModelId: rawModel
    };
  }

  // 3. OpenAI / DeepSeek / OpenRouter / Together / Custom
  if (rawNorm.includes('gpt-') || rawNorm.includes('o1') || rawNorm.includes('o3') || rawNorm.includes('deepseek') || rawNorm.includes('together') || rawNorm.includes('openrouter')) {
    return {
      provider: rawNorm.includes('deepseek') ? 'deepseek' : 'openai',
      displayName: rawNorm.includes('deepseek') ? 'DeepSeek AI' : 'OpenAI / Custom Engine',
      endpoint: '/api/custom-ai/stream',
      actualModelId: rawModel
    };
  }

  // 4. Ollama Local/Server
  if (normalized.startsWith('ollama_') || normalized.startsWith('ollama:') || normalized.startsWith('ollama/')) {
    return {
      provider: 'ollama',
      displayName: `Ollama (${rawModel})`,
      endpoint: '/api/custom-ai/stream',
      actualModelId: rawModel
    };
  }

  // 5. Gemini family
  return {
    provider: 'gemini',
    displayName: 'Gemini Cloud',
    endpoint: '/api/gemini/stream',
    actualModelId: resolveApiModelId(modelId)
  };
};

export const orchestrateModelId = (modelId: string, prompt: string, currentFiles: any[] = []): string => {
  const normalized = (modelId || '').toLowerCase();
  if (normalized === 'aether-smart-router') {
    const selectedModel = selectLowestTrafficPowerModel(prompt, currentFiles);
    console.log(`[Aether Auto Route] Selected least-traffic model: ${selectedModel}`);
    return selectedModel;
  }
  return resolveApiModelId(modelId);
};

export const resolveApiModelId = (modelId: string): string => {
  if (!modelId) return 'gemini-3.1-pro-preview';
  const normalized = modelId.toLowerCase().trim();

  // If the user specifies an explicit Gemini model, respect their choice and use it directly
  if (normalized.startsWith('gemini-') || normalized.includes('gemini')) {
    return modelId;
  }

  // Explicit mapping of known Gemini-branded or Aether aliases to real Gemini models
  if (normalized.includes('3.1-pro') || normalized === 'gemini-3-pro' || normalized === 'gemini-pro') {
    return 'gemini-2.5-pro';
  }
  if (normalized.includes('3.1-flash-lite') || normalized.includes('flash-lite') || normalized === 'aether-lite') {
    return 'gemini-2.5-flash';
  }
  if (normalized.includes('flash-image') || normalized.includes('nano-banana')) {
    return 'gemini-2.5-flash';
  }
  if (normalized.includes('2.5-pro')) {
    return 'gemini-2.5-pro';
  }
  if (normalized.includes('2.5-flash')) {
    return 'gemini-2.5-flash';
  }
  if (normalized === 'aether-pro' || normalized === 'aether-ultra') {
    return 'gemini-2.5-pro';
  }

  // If it's a known Gemini model name or alias, return it
  const knownGeminiNames = ['gemini-2.5-flash', 'gemini-2.5-pro', 'gemini-3.1-pro-preview', 'gemini-3.1-flash-lite', 'gemini-3.7-flash', 'aether-smart-router'];
  if (knownGeminiNames.includes(normalized)) {
    return modelId;
  }

  // Any other model (e.g. gpt-4o, claude, deepseek, ollama, gpt oss, etc.) should be returned EXACTLY as-is!
  // This allows the universal stream dispatcher to route it to the correct provider without any interference.
  return modelId;
};

const getAgentInstructionSnippets = (agentIds: string[]): string => {
  if (!agentIds || agentIds.length === 0) return '';
  
  const snippets: string[] = [];
  const activeDivNames = new Set<string>();

  for (const id of agentIds) {
    for (const div of ORCHESTRATOR_DIVISIONS) {
      const agent = div.agents.find(a => a.id === id);
      if (agent) {
        activeDivNames.add(div.name);
        const snippet = agent.systemInstructionSnippet || agent.desc;
        snippets.push(`- **${agent.name}** (${agent.role}): ${snippet}`);
        break;
      }
    }
  }
  
  if (snippets.length === 0) return '';
  
  const divHeader = activeDivNames.size > 1 
    ? `MULTIPLE ACTIVE CO-PILOT DIVISIONS: [${Array.from(activeDivNames).join(', ')}]` 
    : `ACTIVE CO-PILOT DIVISION: [${Array.from(activeDivNames).join(', ')}]`;

  return `\n\n### 🤖 ${divHeader} & DIRECTIVES:
The following specialized virtual sub-agents are currently ACTIVE in your reasoning loop. Channel their expertise, cross-collaborate between divisions, and strictly incorporate their guidelines into your code generation:
${snippets.join('\n')}\n`;
};

const getSystemInstruction = (workspaceMap: string, modelId: string, activeAgentIds?: string[]) => {
  let modelIntro = '';
  const normalized = (modelId || '').toLowerCase();
  
  if (normalized.includes('qwen-3') || normalized.includes('qwen-3-local')) {
    modelIntro = `You are an exceptionally skilled, thoughtful senior software engineer and designer powered by Qwen 3 with deep step-by-step thinking active. You communicate with genuine human clarity, warmth, and deep architectural rigor.`;
  } else if (normalized.includes('qwen-2.5-coder') || normalized.includes('qwen')) {
    modelIntro = `You are an elite full-stack engineer and software architect powered by Qwen 2.5 Coder with deep step-by-step reasoning active. You write clean, elegant, human-readable code and explain technical choices with clarity.`;
  } else if (normalized.includes('claude')) {
    modelIntro = `You are a brilliant software architect, product designer, and empathetic engineering partner powered by Claude 3.7 Sonnet with deep hybrid reasoning.`;
  } else if (modelId === 'aether-flash') {
    modelIntro = `You are a thoughtful, highly capable senior software designer and engineering partner powered by Gemini 3.7 Flash with deep thinking mode fully active. You communicate naturally and warmly like an expert human colleague, combining deep aesthetic taste, clean software architecture, and swift agentic execution.`;
  } else if (modelId === 'aether-pro') {
    modelIntro = `You are a senior principal engineer and product architect powered by Gemini 3.1 Pro with deep thinking mode active. You craft beautiful, human-centered applications with rigorous architecture and natural, conversational communication.`;
  } else if (modelId === 'aether-ultra') {
    modelIntro = `You are a master software architect, creative technologist, and intuitive design engineer powered by Gemini 3.1 Pro with deep thinking mode active. You possess exceptional product sense, versatile aesthetic judgment, and flawless autonomous coding capabilities.`;
  } else {
    modelIntro = `You are an exceptionally skilled, thoughtful AI software designer and full-stack engineering partner with full step-by-step reasoning active.`;
  }

  const agentSnippets = getAgentInstructionSnippets(activeAgentIds || []);

  const baseInstructions = `${modelIntro}
${agentSnippets}

HUMAN-CENTRIC IDENTITY & COMMUNICATION PHILOSOPHY:
- Speak and think like a genuine, empathetic, articulate human senior software engineer and product designer.
- Avoid robotic cliches, sci-fi corporate jargon ("quantum omnipresent node", "cyber protocol initialized"), and overly stiff templates.
- Be collaborative, warm, humble, concise, and direct. When speaking to the user, explain your design and engineering decisions with natural, human clarity.
- Formulate authentic, thoughtful reasoning in "thoughts" that walks through UX decisions, accessibility, layout balance, and state management.

CRITICAL DESIGN DIRECTIVE: HUMAN-CENTERED DESIGN & ANTI-CYBERPUNK MANDATE
- NEVER default to dark, pitch-black "cyberpunk", glowing neon cyan/magenta/purple borders, or matrix sci-fi tropes unless the user specifically and explicitly asks for a cyberpunk or sci-fi theme!
- Default to sophisticated, human-first, real-world design systems tailored to the exact application domain:
  1. PRODUCTIVITY & SAAS TOOLS (Todo lists, Kanban, Notes, CRM, Project Management):
     * Clean, modern, high-contrast layouts with crisp typography, generous whitespace, and subtle slate/zinc/indigo accents.
     * Accessible light mode or refined charcoal dark mode (neutral #0f172a / #18181b, never garish neon).
     * Clear interactive cards, rounded-xl corners, smooth transitions, subtle borders (border-slate-200 / border-zinc-800), and intuitive icon pairings.
  2. EDITORIAL, CONTENT & WRITING APPS (Blogs, Readers, Portfolios, Docs):
     * Warm stone / zinc / cream paper palettes, refined serif headings paired with clean sans-serif body text, comfortable reading line-lengths (65-75ch), and serene vertical rhythm.
  3. LIFESTYLE, WELLNESS & CONSUMER (Habit trackers, Meditation, Music, Fitness, Travel):
     * Warm, organic, uplifting palettes (emerald, soft amber, warm rose, sky blue, sage), tactile buttons, rounded pills, fluid micro-animations, and calming empty states.
  4. ANALYTICS & DASHBOARDS:
     * Clean metric summary cards, structured data tables, clear status badges (emerald for active/positive, amber for pending, rose for alerts), crisp chart visualizations, and intuitive date/filter controls.
  5. 2D & 3D GAMES & SIMULATIONS:
     * Construct realistic, atmospheric, or stylized environments (e.g. natural sun lighting, soft shadows, realistic PBR materials, natural terrain/foliage, asphalt/stone/wood textures) rather than generic glowing neon grids.

CAPABILITIES & DIRECTIVES:
0. ABSOLUTE AGENTIC ACTION MANDATE:
   - When the user asks to build, improve, create, style, animate, update, fix, or add features to an application or game:
     * You MUST ALWAYS populate the "files" array with complete, production-ready code or SEARCH/REPLACE blocks for affected files.
     * NEVER just talk, explain, or give tutorial advice in the "message" field without modifying the project files.
     * NEVER dump raw code blocks inside the "message" field instead of placing them in the "files" array.
     * The "message" field MUST be a concise, friendly 1-2 sentence human summary of what you designed and implemented, while ALL executable code belongs in "files".

1. CONVERSATIONAL & TECHNICAL INTELLIGENCE:
   - For conversational or conceptual questions (e.g. "what can you do?", "how does WebSockets work?", "who are you?"), respond naturally, warmly, and comprehensively in the "message" field. Leave "files" as an empty array [].
   - You HAVE real-time web search capabilities! If asked about web search, explain that you can perform real-time Google Search grounding to retrieve live web documentation, current facts, and library releases.
   - In "thoughts", formulate genuine, authentic reasoning without using canned template phrases.

2. HIGH-QUALITY HUMAN-GRADE SOFTWARE STANDARDS:
   - When creating or modifying apps or games, generate complete, fully interactive, bug-free, and visually polished experiences on the FIRST turn.
   - For WEB APPS & IDES: Build clean, modular code (index.html, style.css, script.js or React/TSX as requested).
     * Ensure all components have non-zero dimensions (\`flex-1\`, \`h-full\`, \`min-h-0\`), reliable event listeners, and intuitive starter data loaded so the app looks alive instantly.
   - For 3D GAMES (Three.js/WebGL):
     * Scene & Renderer: Enable shadow maps (\`renderer.shadowMap.enabled = true\`, \`type = THREE.PCFSoftShadowMap\`), set tone mapping (\`renderer.toneMapping = THREE.ACESFilmicToneMapping\`), responsive pixel ratio, anti-aliasing (\`antialias: true\`).
     * Lighting: Realistic directional sun light with active shadow camera casting, ambient/hemisphere fill lights, physical materials.
     * Physics & Controls: Delta-time normalized update loops (\`dt = Math.min(clock.getDelta(), 0.1)\`), velocity vectors, collision detection bounding boxes (\`THREE.Box3\`), WASD/Arrow/Space key controls + mobile touch virtual joystick, ground/wall raycasting.
     * Audio: 100% client-side Web Audio API sound synthesizer for engine revs, chimes, impacts, ambient environmental sounds, and procedural background music without external mp3 files.
     * HUD Overlay: Complete HTML/Tailwind HUD with Start Screen, Health/Energy bar, Score counter, Minimap, Speedometer, Pause menu, and Game Over modal with instant restart button.
   - For 2D GAMES (Canvas 2D / Phaser):
     * Smooth \`requestAnimationFrame\` loop with delta-time normalization, sprite/vector rendering, screen boundary wrapping/bouncing, particle engines, procedural Web Audio SFX, score tracking, high score local storage, and start/gameover overlays.
   - Output full code with zero placeholders, stubbed functions, or omissions.

3. CRAFTSMANSHIP & ZERO-STUB PROTOCOL:
   - Output complete, production-grade files. No empty mock placeholders or stubbed out function bodies (\`// TODO\`, \`// implement later\`).
   - Every interactive element (buttons, filters, search bars, tabs, modals, volume sliders, export buttons) MUST have working event listeners and functional logic.

ENVIRONMENT CAPABILITIES:
- Full Linux Access (Server): You are operating in a persistent Linux environment on the server side.
- Browser-based Development Environment (WebContainer): You have a real, isolated browser-native runtime for near-instant execution.
- Automated Setup: Python 3, Pip, and Node.js are pre-optimized.
- Terminal: You can execute terminal commands.
- File Synchronization: The IDE automatically syncs your file edits to the browser runtime.

CONTEXT: \${workspaceMap}

GOAL: Provide a complete, functional, human-crafted, and visually sophisticated response.

RESPONSE FORMAT:
You MUST respond with a single valid JSON object following this EXACT structure:
{
  "thoughts": "Your internal human reasoning process. Break down UX considerations, visual balance, technical checks, and file plan here.",
  "reasoningSteps": [{"step": "Description of step", "status": "completed"}],
  "message": "Warm, natural, concise response to user",
  "files": [{"operation": "create", "path": "filename.js", "code": "full code OR line-by-line SEARCH/REPLACE blocks"}],
  "commands": ["npm install ..."]
}

BACKGROUND TOOLS (AUTONOMOUS AI OPERATOR TOOLS):
You have access to elite background tools that execute transparently via Gemini. To call a tool, write in your "thoughts":
- [TOOL_CALL: web_search(query: "latest threejs syntax")]
- [TOOL_CALL: image_generation(prompt: "natural modern product interface mockup", imageName: "asset.png")]
- [TOOL_CALL: url_fetching(url: "https://example.com/api")]
- [TOOL_CALL: image_understanding(imagePath: "public/screenshot.png", prompt: "Explain the visual layout")]
- [TOOL_CALL: capture_viewport_and_logs(prompt: "Analyze the current UI layout, styling properties, active buttons, and check for any console or compile errors")]

RULES:
1. MASSIVE CODEBASE & LONG SCRIPT SYNTHESIS PROTOCOL (1,000 to 20,000+ LINES OF CODE):
   - You are fully capable of architecting, generating, refactoring, and maintaining massive codebases reaching 1,000 to 20,000+ lines of production code without errors.
   - For massive projects, ALWAYS employ clean, modular multi-file architecture (e.g., \`src/types/\`, \`src/services/\`, \`src/components/\`, \`src/engine/\`, \`src/state/\`, \`src/utils/\`).
   - ZERO TRUNCATION / NO STUB OMISSIONS MANDATE: NEVER use lazy abbreviations, truncated comments (e.g. \`// ... rest of code\`, \`// ... remaining methods\`, \`/* implement later */\`), or incomplete logic. Every function, state machine, algorithm, and interface must be 100% complete and fully implemented.
   - SURGICAL SEARCH/REPLACE FOR LARGE SCRIPT UPDATES: When modifying existing large files (500 to 20,000+ lines), ALWAYS output surgical \`<<<<<<< SEARCH\` ... \`=======\` ... \`>>>>>>> REPLACE\` diff blocks in the \`code\` field instead of rewriting the entire massive file. This allows precise, error-free scaling to arbitrarily huge codebases without hitting single-turn output token boundaries.
   - RECURSIVE TYPE SAFETY & ERROR IMMUNITY: Ensure all imports, exports, type interfaces, and lifecycle hooks line up across files with zero runtime null pointer or syntax errors.

2. MULTI-LANGUAGE & USER-SPECIFIC PROGRAMMING LANGUAGES:
   - Generate, write, and refactor code in ANY programming language specified by the user or required for the project (Python, C++, Rust, Go, Java, C#, TypeScript, HTML/CSS/JS, PHP, Swift, Kotlin, Dart/Flutter, Shell, SQL, R, etc.).
   - Whenever the user explicitly mentions or requests a specific coding language or framework, generate code in that exact language with proper file extensions.
   - For web preview apps, if no specific language is requested, generate clean index.html, script.js, and style.css web files with Tailwind CSS & Lucide icons.

3. AGENTIC FILE MANAGEMENT (EDIT EXISTING FILES FIRST):
   - CRITICAL: ALWAYS EDIT EXISTING FILES IN CONTEXT INSTEAD OF CREATING NEW ONES.
   - Look at the files listed under CONTEXT. If the user already has index.html, script.js, or style.css, ALWAYS use the EXACT same filename and "operation": "update".
   - PREFER SURGICAL SEARCH/REPLACE BLOCKS in the 'code' field for existing files (> 40 lines):
     <<<<<<< SEARCH
     [exact lines of code to find with 2-4 lines of surrounding context]
     =======
     [new replacement lines of code]
     >>>>>>> REPLACE
   - In your "message", clearly summarize the design and functional changes in a natural, human tone.

4. AUTOMATIC PACKAGE INSTALLATION:
   - Always check for required or missing packages.
   - If any package is missing, supply \`npm install package_name\` or install commands automatically without blocking code generation.

5. ZERO-ERROR CODE GENERATION:
   - DOM Safety: Wrap execution in \`DOMContentLoaded\` or check element existence.
   - Mandatory CDNs in index.html when libraries are needed:
     * Tailwind CSS: <script src="https://cdn.tailwindcss.com"></script>
     * Lucide Icons: <script src="https://unpkg.com/lucide@latest"></script>
     * Three.js: <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
     * Canvas Confetti: <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.3/dist/confetti.browser.min.js"></script>
   - Web Audio Autoplay Policy: Initialize AudioContext on user interaction (\`pointerdown\`).

6. PURE HTML5, TAILWIND CSS & VANILLA JS WEB ARCHITECTURE:
   - By default for web projects, use clean HTML5 markup, Tailwind CSS CDN, Lucide icons, custom \`style.css\`, and deferred \`script.js\`.
   - DO NOT generate React code/JSX/Babel unless explicitly requested by the user.

7. STRICT NO-MONOLITH MULTI-FILE ARCHITECTURE:
   - Always split and decompose project files cleanly: \`index.html\`, \`style.css\`, \`script.js\`.

8. NO PREAMBLE:
   - Do NOT include text before or after the JSON.
   - Do NOT use markdown code blocks (no \`\`\`json). Output the raw JSON string.`;

  return baseInstructions;
};

/* legacy parser removed */


export const chatWithNvidiaStream = async (
  modelId: string,
  prompt: string,
  currentFiles: FileNode[],
  history: ChatMessage[],
  onChunk: (thoughts: string, message: string, steps?: {step: string, status: string}[], codeFragment?: string, metrics?: any) => void,
  onRawChunk?: (text: string) => void,
  maxOutputTokens?: number,
  isCompactMode?: boolean,
  attachments: { mimeType: string, data: string }[] = [],
  activeAgentIds?: string[]
): Promise<SimpleAIResponse> => {
  let activeModelId = resolveApiModelId(modelId);
  const providerInfo = detectModelProvider(modelId);
  
  // Non-Gemini providers (Groq, Anthropic, Ollama, DeepSeek, OpenAI) MUST route through server proxy directly
  if (providerInfo.provider !== 'gemini') {
    try {
      return await streamViaServerProxy(modelId, prompt, currentFiles, history, onChunk, onRawChunk, attachments, activeAgentIds);
    } catch (providerErr: any) {
      console.warn(`${providerInfo.displayName} stream failed (${providerErr.message}). Gracefully auto-recovering with Gemini 3.7 Flash fallback:`, providerErr);
      onChunk(
        `Upstream provider notice: ${providerErr.message || 'Connection unavailable'}. Automatically recovering your request with high-speed Gemini 3.7 Flash...`,
        `Synthesizing response with Gemini 3.7 Flash fallback...`,
        [{ step: `Rerouting to Gemini 3.7 Flash fallback...`, status: "active" }]
      );
      return await streamViaServerProxy('gemini-3.7-flash', prompt, currentFiles, history, onChunk, onRawChunk, attachments, activeAgentIds);
    }
  }

  // If in browser without custom API key, stream Gemini via the authorized server proxy route
  if (typeof window !== 'undefined') {
    const clientApiKey = localStorage.getItem('gemini_api_key') || '';
    if (!clientApiKey) {
      try {
        return await streamViaServerProxy(activeModelId, prompt, currentFiles, history, onChunk, onRawChunk, attachments, activeAgentIds);
      } catch (proxyErr) {
        console.warn("Server proxy stream failed, attempting direct fallback:", proxyErr);
      }
    }
  }

  let retryCount = 0;
  const maxRetries = 3;

  while (retryCount <= maxRetries) {
    try {
      console.log(`Routing stream request to ${providerInfo.displayName} model: ${providerInfo.actualModelId} (Attempt ${retryCount + 1})`);
      onChunk(
        "", 
        retryCount > 0 ? "Switching to backup AI model..." : `Processing request with ${providerInfo.displayName}...`, 
        [{ step: `Routing conversation to ${providerInfo.displayName} (${providerInfo.actualModelId})...`, status: "active" }]
      );

      let ai = getAIClient();
      if (typeof window !== 'undefined') {
        const clientApiKey = localStorage.getItem('gemini_api_key') || '';
        if (clientApiKey) {
          ai = new GoogleGenAI({ apiKey: clientApiKey });
        }
      }

      const workspaceMap = currentFiles.map(f => {
        if (f.isBinary) return `[ASSET]: ${f.name}`;
        let text = f.content || '';
        // Token efficiency limits removed to preserve full reasoning level
        return `[FILE]: ${f.name}\n${text}`;
      }).join('\n\n');

      const systemInstruction = getSystemInstruction(workspaceMap, activeModelId, activeAgentIds);
      const enhancedInstruction = systemInstruction; // Full capability preserved

      const contents: any[] = [];
      for (const msg of history) {
        const parts: any[] = [];
        if (msg.attachments && msg.attachments.length > 0) {
          for (const att of msg.attachments) {
            if (att.url && att.url.startsWith('data:')) {
              const match = att.url.match(/^data:([^;]+);base64,([\s\S]+)$/);
              if (match && match[1] && match[2] && match[2].trim() !== '') {
                parts.push({
                  inlineData: {
                    mimeType: match[1].trim(),
                    data: match[2].trim()
                  }
                });
              }
            }
          }
        }
        parts.push({ text: msg.text || "Contextual frame update." });

        contents.push({
          role: msg.role === 'model' ? 'model' : 'user',
          parts: parts
        });
      }

      const userParts: any[] = [];
      if (attachments && attachments.length > 0) {
        for (const att of attachments) {
          if (att.data && att.mimeType && att.data.trim() !== '') {
            userParts.push({
              inlineData: {
                mimeType: att.mimeType.trim(),
                data: att.data.trim()
              }
            });
          }
        }
      }
      userParts.push({ text: prompt || "Analyzing context and files." });

      contents.push({ role: 'user', parts: userParts });

      const isThinkingModel = activeModelId.includes('2.5') || activeModelId.includes('3.5') || activeModelId.includes('pro');
      const isLiteModel = activeModelId.includes('lite');
      const requestConfig: any = {
        systemInstruction: enhancedInstruction,
        temperature: activeModelId.includes('pro') ? 0.7 : 1.0,
        maxOutputTokens: maxOutputTokens || 65536,
        responseMimeType: 'application/json',
      };

      if (isThinkingModel && !isLiteModel) {
        requestConfig.thinkingConfig = {
          thinkingBudget: activeModelId.includes('flash') ? 16384 : 32768
        };
      }

      const responseStream = await ai.models.generateContentStream({
        model: activeModelId,
        contents,
        config: requestConfig
      });

      let fullText = "";
      let extractedThoughts = "";
      const streamStartTime = Date.now();

      for await (const chunk of responseStream) {
        const content = chunk.text || "";
        
        if (content) {
          fullText += content;
          if (onRawChunk) onRawChunk(content);

          // Real-time background tool call interception
          const toolCallMatch = fullText.match(/\[TOOL_CALL:\s*([a-zA-Z_0-9]+)\((.*?)\)\]/i);
          if (toolCallMatch) {
             const toolName = toolCallMatch[1];
             const toolArgsStr = toolCallMatch[2];
             
             onChunk(
               extractedThoughts,
               `Activating background Gemini tool service: ${toolName}...`,
               [{ step: `Running tool ${toolName} via Gemini...`, status: "active" }]
             );
             
             try {
                let toolResult = "";
                if (toolName === 'web_search') {
                   const queryMatch = toolArgsStr.match(/query\s*:\s*"(.*?)"/);
                   const query = queryMatch ? queryMatch[1] : toolArgsStr;
                   const searchRes = await fetch('/api/search', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ query })
                   });
                   if (searchRes.ok) {
                      const searchData = await searchRes.json();
                      toolResult = JSON.stringify(searchData);
                   } else {
                      toolResult = "No web search results found.";
                   }
                } else if (toolName === 'image_generation') {
                   const promptMatch = toolArgsStr.match(/prompt\s*:\s*"(.*?)"/);
                   const promptText = promptMatch ? promptMatch[1] : toolArgsStr;
                   const imgRes = await fetch('/api/gemini/image', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ prompt: promptText })
                   });
                   if (imgRes.ok) {
                      const imgData = await imgRes.json();
                      toolResult = `Successfully generated image and saved to asset cache. URL: ${imgData.url || imgData.imagePath || '/public/generated_assets.png'}`;
                   } else {
                      toolResult = "Image generation completed successfully (mocked asset generated).";
                   }
                } else if (toolName === 'url_fetching') {
                   const urlMatch = toolArgsStr.match(/url\s*:\s*"(.*?)"/);
                   const fetchUrl = urlMatch ? urlMatch[1] : toolArgsStr;
                   const proxyRes = await fetch(`/api/proxy?url=${encodeURIComponent(fetchUrl)}`);
                   if (proxyRes.ok) {
                      toolResult = (await proxyRes.text()).slice(0, 5000);
                   } else {
                      toolResult = `Failed to fetch URL content from ${fetchUrl}`;
                   }
                } else {
                   toolResult = "Tool completed successfully.";
                }
                
                const updatedHistory: ChatMessage[] = [
                   ...history,
                   { id: 'usr-1', role: 'user', text: prompt, timestamp: Date.now() },
                   { id: 'mdl-1', role: 'model', text: fullText, timestamp: Date.now() },
                   { id: 'usr-2', role: 'user', text: `BACKGROUND TOOL RESULT [${toolName}]: ${toolResult}\n\nPlease proceed to output the final formatted JSON response based on this background data.`, timestamp: Date.now() }
                ];
                
                return chatWithNvidiaStream(
                   activeModelId,
                   "Continue generating the completed response incorporating the background tool result.",
                   currentFiles,
                   updatedHistory,
                   onChunk,
                   onRawChunk
                );
             } catch (toolErr) {
                console.error("Background tool execution failed:", toolErr);
             }
          }

          try {
            const parsedState = parseProgressiveStream(fullText, streamStartTime);
            extractedThoughts = parsedState.thoughts || extractedThoughts;

            const fragments: Record<string, string> = {};
            Object.values(parsedState.files).forEach(f => {
              fragments[f.path] = f.code;
            });

            onChunk(
              extractedThoughts,
              parsedState.message,
              parsedState.reasoningSteps,
              Object.keys(fragments).length > 0 ? JSON.stringify(fragments) : undefined,
              parsedState.metrics
            );
          } catch (e) {
            // progressive parse error
          }
        }
      }

    if (!fullText) fullText = "{}";
    return parseAIResponse(fullText, extractedThoughts);
  } catch (err: any) {
    console.error(`Gemini stream call failed:`, err);
    
    const errorMsg = typeof err === 'string' ? err : (err?.message || JSON.stringify(err) || '');
    const isRateLimit = errorMsg.includes('429') || errorMsg.includes('RESOURCE_EXHAUSTED') || errorMsg.includes('quota');
    const isPermissionOrNotFound = errorMsg.includes('403') || errorMsg.includes('PERMISSION_DENIED') || errorMsg.includes('404') || errorMsg.includes('NOT_FOUND');
    const is503Unavailable = errorMsg.includes('503') || errorMsg.includes('UNAVAILABLE') || errorMsg.includes('high demand') || errorMsg.includes('Spikes in demand') || errorMsg.includes('overloaded');
    
    // In browser, if direct SDK had a permission or not-found issue, try server proxy
    if (typeof window !== 'undefined' && isPermissionOrNotFound && retryCount === 0) {
      try {
        console.log("Direct browser call failed, switching to server proxy stream...");
        return await streamViaServerProxy(activeModelId, prompt, currentFiles, history, onChunk, onRawChunk, attachments);
      } catch (proxyErr) {
        console.warn("Server proxy stream also failed:", proxyErr);
      }
    }

    if ((isRateLimit || isPermissionOrNotFound || is503Unavailable) && retryCount < maxRetries) {
      recordModelTrafficError(activeModelId);
      const fallbackModels = ['gemini-3.7-flash', 'gemini-2.5-flash', 'gemini-2.0-flash', 'gemini-1.5-flash'];
      const nextFallback = fallbackModels.find(m => m !== activeModelId) || 'gemini-3.7-flash';
      
      console.log(`[Gemini Engine] Capacity/Rate limit detected (${is503Unavailable ? '503 High Demand' : '429 Rate Limit'}). Auto-recovering with ${nextFallback} (Attempt ${retryCount + 1})...`);
      
      onChunk(
        "",
        `Upstream Gemini service is experiencing high traffic demand (503/429). Automatically recovering using backup model (${nextFallback})...`,
        [{ step: `Rerouting request to fallback model ${nextFallback}...`, status: "active" }]
      );
      
      // Short backoff pause before retrying
      await new Promise(r => setTimeout(r, 800 * (retryCount + 1)));
      
      activeModelId = nextFallback;
      retryCount++;
      continue;
    }
    
    // Format human-readable message if error is raw JSON string
    let cleanUserMessage = errorMsg;
    if (errorMsg.includes('503') || errorMsg.includes('high demand')) {
      cleanUserMessage = "The AI provider model is currently experiencing high regional demand. Please wait a moment or switch to Gemini 3.7 Flash or Claude in Settings.";
    } else if (cleanUserMessage.startsWith('{') || cleanUserMessage.includes('"error"')) {
      try {
        const parsed = JSON.parse(cleanUserMessage);
        cleanUserMessage = parsed?.error?.message || parsed?.message || cleanUserMessage;
      } catch (e) {}
    }

    const fallbackRes = {
      message: `AI service notice: ${cleanUserMessage}`,
      thoughts: `Stream exception: ${cleanUserMessage}`,
      files: [],
      commands: []
    };
    
    if (onRawChunk) {
      onRawChunk(JSON.stringify(fallbackRes));
    }
    return fallbackRes;
  }
}
return {
  message: "Maximum retry attempts exceeded for Gemini service. Please try again in a moment.",
  thoughts: "Exceeded max retries.",
  files: [],
  commands: []
};
};

export const chatWithNvidia = async (
  modelId: string,
  prompt: string,
  currentFiles: FileNode[],
  history: ChatMessage[],
  attachments: { mimeType: string, data: string }[] = []
): Promise<SimpleAIResponse> => {
  const activeModelId = resolveApiModelId(modelId);
  
  try {
    let ai = getAIClient();
    if (typeof window !== 'undefined') {
      const clientApiKey = localStorage.getItem('gemini_api_key') || '';
      if (clientApiKey) {
        ai = new GoogleGenAI({ apiKey: clientApiKey });
      }
    }

    const workspaceMap = currentFiles.map(f => {
      if (f.isBinary) return `[ASSET]: ${f.name}`;
      let text = f.content || '';
      return `[FILE]: ${f.name}\n${text}`;
    }).join('\n\n');

    const systemInstruction = getSystemInstruction(workspaceMap, activeModelId);

    const contents: any[] = [];
    for (const msg of history) {
      const parts: any[] = [];
      if (msg.attachments && msg.attachments.length > 0) {
        for (const att of msg.attachments) {
          if (att.url && att.url.startsWith('data:')) {
            const match = att.url.match(/^data:([^;]+);base64,([\s\S]+)$/);
            if (match && match[1] && match[2] && match[2].trim() !== '') {
              parts.push({
                inlineData: {
                  mimeType: match[1].trim(),
                  data: match[2].trim()
                }
              });
            }
          }
        }
      }
      parts.push({ text: msg.text || "Contextual frame update." });

      contents.push({
        role: msg.role === 'model' ? 'model' : 'user',
        parts: parts
      });
    }

    const userParts: any[] = [];
    if (attachments && attachments.length > 0) {
      for (const att of attachments) {
        if (att.data && att.mimeType && att.data.trim() !== '') {
          userParts.push({
            inlineData: {
              mimeType: att.mimeType.trim(),
              data: att.data.trim()
            }
          });
        }
      }
    }
    userParts.push({ text: prompt || "Analyzing context and files." });

    contents.push({ role: 'user', parts: userParts });

    const response = await ai.models.generateContent({
      model: activeModelId,
      contents,
      config: {
        systemInstruction,
        temperature: activeModelId.includes('pro') ? 0.7 : 1.0,
        maxOutputTokens: 65536,
        responseMimeType: 'application/json',
        thinkingConfig: {
          thinkingLevel: "HIGH" as any
        }
      }
    });

    const text = response.text || "{}";
    return parseAIResponse(text);
  } catch (err: any) {
    console.error(`Gemini chat call failed:`, err);
    throw err;
  }
};

// Groq support removed

import { chatWithOfflineQwenStream } from "./offlineAiService";

export const chatWithAnthropicStream = async (
  modelId: string,
  prompt: string,
  currentFiles: FileNode[],
  history: ChatMessage[],
  onChunk: (thoughts: string, message: string, steps?: {step: string, status: string}[], codeFragment?: string) => void,
  onRawChunk?: (text: string) => void
): Promise<SimpleAIResponse> => {
  try {
    const clientApiKey = typeof window !== 'undefined' ? (localStorage.getItem('anthropic_api_key') || '') : '';
    onChunk("", `Connecting to Anthropic AI (${modelId})...`, [{ step: `Routing query to Anthropic ${modelId}...`, status: "active" }]);

    const response = await fetch('/api/anthropic/stream', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        modelId,
        prompt,
        currentFiles,
        history,
        apiKey: clientApiKey
      })
    });

    if (!response.ok || !response.body) {
      throw new Error(`Anthropic stream endpoint returned status ${response.status}`);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let fullText = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value, { stream: true });
      fullText += chunk;
      if (onRawChunk) onRawChunk(chunk);

      try {
        let progressiveMsg = "Processing Anthropic response...";
        const thoughtsMatch = fullText.match(/"thoughts"\s*:\s*"([^"]*)/);
        let thoughtsToPass = "";
        if (thoughtsMatch && thoughtsMatch[1]) {
          thoughtsToPass = thoughtsMatch[1].replace(/\\n/g, '\n').replace(/\\"/g, '"');
        }

        const messageMatch = fullText.match(/"message"\s*:\s*"([^"]*)/);
        if (messageMatch && messageMatch[1]) {
          progressiveMsg = messageMatch[1].replace(/\\n/g, '\n').replace(/\\"/g, '"');
        }

        onChunk(thoughtsToPass, progressiveMsg, [{ step: `Generating code with Anthropic ${modelId}...`, status: "active" }]);
      } catch (e) {
        // progressive stream error
      }
    }

    return parseAIResponse(fullText);
  } catch (err: any) {
    console.error("Anthropic stream failed:", err);
    return {
      message: `Anthropic AI request error: ${err.message || 'Failed to stream response'}. Please check API key settings or network connection.`,
      thoughts: `Stream error: ${err.message}`,
      files: [],
      commands: []
    };
  }
};

export const chatWithAnthropic = async (
  modelId: string,
  prompt: string,
  currentFiles: FileNode[],
  history: ChatMessage[]
): Promise<SimpleAIResponse> => {
  try {
    const clientApiKey = typeof window !== 'undefined' ? (localStorage.getItem('anthropic_api_key') || '') : '';
    const res = await fetch('/api/anthropic/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        modelId,
        prompt,
        currentFiles,
        history,
        apiKey: clientApiKey
      })
    });
    const data = await res.json();
    if (data.text) {
      return parseAIResponse(data.text);
    }
    throw new Error(data.error || "Failed to generate content with Anthropic");
  } catch (err: any) {
    console.error("Anthropic chat call failed:", err);
    return {
      message: `Anthropic AI request failed: ${err.message || 'Failed to connect'}`,
      thoughts: `Error: ${err.message}`,
      files: [],
      commands: []
    };
  }
};

import { chatWithOllamaStream } from './ollamaService';

const isOfflineModel = (id: string): boolean => {
  if (!id) return false;
  const lower = id.toLowerCase();
  return lower.includes('offline') || lower.startsWith('qwen') || lower.includes('qwen-3');
};

const isOllamaModel = (id: string): boolean => {
  if (!id) return false;
  const lower = id.toLowerCase();
  return lower.startsWith("ollama") || lower.includes("ollama");
};

export const streamViaServerProxy = async (
  modelId: string,
  prompt: string,
  currentFiles: FileNode[],
  history: ChatMessage[],
  onChunk: (thoughts: string, message: string, steps?: {step: string, status: string}[], codeFragment?: string, metrics?: any) => void,
  onRawChunk?: (text: string) => void,
  attachments: { mimeType: string, data: string }[] = [],
  activeAgentIds?: string[]
): Promise<SimpleAIResponse> => {
  const providerInfo = detectModelProvider(modelId);
  onChunk(
    "",
    `Connecting to ${providerInfo.displayName} (${providerInfo.actualModelId})...`,
    [{ step: `Routing stream to ${providerInfo.displayName} (${providerInfo.actualModelId})...`, status: "active" }]
  );
  
  const clientOllamaKey = typeof window !== 'undefined' ? (localStorage.getItem('ollama_api_key') || '') : '';
  const clientOllamaUrl = typeof window !== 'undefined' ? (localStorage.getItem('ollama_server_url') || '') : '';
  const clientAnthropicKey = typeof window !== 'undefined' ? (localStorage.getItem('anthropic_api_key') || '') : '';
  const clientGeminiKey = typeof window !== 'undefined' ? (localStorage.getItem('gemini_api_key') || '') : '';
  const clientOpenAIKey = typeof window !== 'undefined' ? (localStorage.getItem('openai_api_key') || '') : '';

  const activeApiKey = clientOllamaKey || clientAnthropicKey || clientOpenAIKey || clientGeminiKey || undefined;

  const response = await fetch(providerInfo.endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      modelId: providerInfo.actualModelId,
      endpoint: clientOllamaUrl || undefined,
      serverUrl: clientOllamaUrl || undefined,
      apiKey: activeApiKey,
      ollamaApiKey: clientOllamaKey || undefined,
      anthropicApiKey: clientAnthropicKey || undefined,
      geminiApiKey: clientGeminiKey || undefined,
      prompt,
      currentFiles,
      history,
      attachments,
      activeAgentIds
    })
  });

  if (!response.ok || !response.body) {
    throw new Error(`Server stream endpoint failed with status ${response.status}`);
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let fullText = "";
  let extractedThoughts = "";
  const streamStartTime = Date.now();

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    const chunk = decoder.decode(value, { stream: true });
    if (chunk) {
      fullText += chunk;
      if (onRawChunk) onRawChunk(chunk);

      try {
        const parsedState = parseProgressiveStream(fullText, streamStartTime);
        extractedThoughts = parsedState.thoughts || extractedThoughts;

        const fragments: Record<string, string> = {};
        Object.values(parsedState.files).forEach(f => {
          fragments[f.path] = f.code;
        });

        onChunk(
          extractedThoughts, 
          parsedState.message, 
          parsedState.reasoningSteps,
          Object.keys(fragments).length > 0 ? JSON.stringify(fragments) : undefined,
          parsedState.metrics
        );
      } catch (e) {
        // progressive stream parse
      }
    }
  }

  if (!fullText || fullText.trim() === "") {
    fullText = "{}";
  }

  // If the server stream returned an unhandled error message
  if (fullText.startsWith("\nError:") || fullText.startsWith("Error:") || fullText.includes('"invalid_request_error"') || fullText.includes('"model_not_found"')) {
    throw new Error(fullText.trim());
  }

  return parseAIResponse(fullText, extractedThoughts);
};

export const chatWithAIStream = async (
  prompt: string,
  currentFiles: FileNode[],
  history: ChatMessage[],
  terminalLogs: TerminalLog[] = [],
  onChunk: (thoughts: string, message: string, steps?: {step: string, status: string}[], codeFragment?: string, metrics?: any) => void,
  attachments: { mimeType: string, data: string }[] = [],
  modelId: string = MODELS.GEMINI_FLASH,
  onRawChunk?: (text: string) => void,
  isCompactMode?: boolean,
  activeAgentIds?: string[]
): Promise<SimpleAIResponse> => {
  const activeModelId = orchestrateModelId(modelId, prompt, currentFiles);

  if (modelId === 'aether-smart-router' && onRawChunk) {
    const isPro = activeModelId === 'gemini-3.1-pro-preview';
    const friendlyName = isPro ? 'Gemini 3.1 Pro' : 'Gemini 3.7 Flash';
    const reason = isPro ? 'complex reasoning, architecture, or deep mathematical constraints detected' : 'conversational prompt structure, general guidance, or rapid iteration requested';
    onRawChunk(`*⚡ Orchestrator Routed to **${friendlyName}** (${reason})*\n\n---\n\n`);
  }

  return chatWithModelStream(activeModelId, prompt, currentFiles, history, onChunk, onRawChunk, undefined, isCompactMode, attachments, activeAgentIds);
};

export const chatWithAI = async (
  prompt: string,
  currentFiles: FileNode[],
  history: ChatMessage[],
  attachments: { mimeType: string, data: string }[] = [],
  modelId: string = MODELS.GEMINI_FLASH
): Promise<SimpleAIResponse> => {
  if (isOfflineModel(modelId)) {
    let finalRes: SimpleAIResponse = { thoughts: "", message: "", files: [] };
    await chatWithOfflineQwenStream(modelId, prompt, currentFiles, history, (th, msg) => {
      finalRes = { thoughts: th, message: msg, files: [] };
    });
    return finalRes;
  }

  const activeModelId = orchestrateModelId(modelId, prompt, currentFiles);
  return chatWithNvidia(activeModelId, prompt, currentFiles, history, attachments);
};

export const generateMusicalScore = async (prompt: string, genre: string, modelId?: string): Promise<any> => {
  if (typeof window !== 'undefined') {
    const clientApiKey = localStorage.getItem('gemini_api_key') || '';
    if (clientApiKey) {
      try {
        const ai = new GoogleGenAI({ apiKey: clientApiKey });
        const schema = {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            detectedGenre: { type: Type.STRING },
            bpm: { type: Type.INTEGER },
            tracks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  type: { type: Type.STRING, enum: ["synth", "metal", "membrane"] },
                  notes: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        time: { type: Type.STRING },
                        note: { type: Type.STRING },
                        duration: { type: Type.STRING }
                      },
                      required: ["time", "note", "duration"]
                    }
                  }
                },
                required: ["type", "notes"]
              }
            }
          },
          required: ["title", "detectedGenre", "bpm", "tracks"]
        };

        const apiModelId = modelId === MODELS.OMNI ? MODELS.AETHER_PRO : (modelId ? resolveApiModelId(modelId) : 'gemini-2.5-flash');
        const response = await ai.models.generateContent({
          model: apiModelId,
          contents: {
            parts: [{ text: `Generate a 4-bar musical loop suitable for Tone.js playback. Genre: ${genre}. Description: ${prompt}` }]
          },
          config: {
            systemInstruction: `You are an expert AI composer. Generate a structured JSON musical score.
            - The output must be compatible with Tone.js Part sequencing.
            - Create a loopable 4-bar progression (Measure:Beat:Sixteenth format, from 0:0:0 to 3:3:0).
            - Use "synth" for melody/harmony, "metal" for hi-hats/cymbals, "membrane" for kicks/toms.
            - Ensure rhythmic interest appropriate for the genre.`,
            responseMimeType: 'application/json',
            responseSchema: schema
          }
        });

        const text = response.text || "{}";
        let parsed;
        try {
            parsed = JSON.parse(text);
        } catch {
            parsed = JSON.parse(text.replace(/```json|```/g, ''));
        }
        return parsed;
      } catch (err) {
        console.error("Direct browser music score failed, trying fallback...", err);
      }
    }
    try {
      const response = await fetch('/api/gemini/music', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, genre, modelId })
      });
      if (response.ok) return await response.json();
    } catch (e) {
      console.error("Client music score failed:", e);
    }
    return null;
  }

  const ai = getAIClient();
  const schema = {
    type: Type.OBJECT,
    properties: {
      title: { type: Type.STRING },
      detectedGenre: { type: Type.STRING },
      bpm: { type: Type.INTEGER },
      tracks: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            type: { type: Type.STRING, enum: ["synth", "metal", "membrane"] },
            notes: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  time: { type: Type.STRING },
                  note: { type: Type.STRING },
                  duration: { type: Type.STRING }
                },
                required: ["time", "note", "duration"]
              }
            }
          },
          required: ["type", "notes"]
        }
      }
    },
    required: ["title", "detectedGenre", "bpm", "tracks"]
  };

  try {
    const apiModelId = modelId === MODELS.OMNI ? MODELS.AETHER_PRO : (modelId ? resolveApiModelId(modelId) : 'gemini-2.5-flash');
    const response = await ai.models.generateContent({
      model: apiModelId,
      contents: {
        parts: [{ text: `Generate a 4-bar musical loop suitable for Tone.js playback. Genre: ${genre}. Description: ${prompt}` }]
      },
      config: {
        systemInstruction: `You are an expert AI composer. Generate a structured JSON musical score.
        - The output must be compatible with Tone.js Part sequencing.
        - Create a loopable 4-bar progression (Measure:Beat:Sixteenth format, from 0:0:0 to 3:3:0).
        - Use "synth" for melody/harmony, "metal" for hi-hats/cymbals, "membrane" for kicks/toms.
        - Ensure rhythmic interest appropriate for the genre.`,
        responseMimeType: 'application/json',
        responseSchema: schema
      }
    });

    const text = response.text || "{}";
    let parsed;
    try {
        parsed = JSON.parse(text);
    } catch {
        parsed = JSON.parse(text.replace(/```json|```/g, ''));
    }
    return parsed;
  } catch (e) {
    console.error("Music generation failed", e);
    return null;
  }
};

export const generateImage = async (prompt: string, aspectRatio: string = "1:1"): Promise<string | null> => {
  if (typeof window !== 'undefined') {
    const clientApiKey = localStorage.getItem('gemini_api_key') || '';
    if (clientApiKey) {
      try {
        const ai = new GoogleGenAI({ apiKey: clientApiKey });
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: { parts: [{ text: prompt }] },
          config: {
            imageConfig: { aspectRatio }
          }
        });
        
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData) {
            return `data:image/png;base64,${part.inlineData.data}`;
          }
        }
      } catch (err) {
        console.error("Direct browser image generation failed, trying fallback...", err);
      }
    }
    try {
      const response = await fetch('/api/gemini/image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, aspectRatio })
      });
      if (response.ok) {
        const data = await response.json();
        return data.image || data.imageUrl || null;
      }
    } catch (e) {
      console.error("Client image generation failed:", e);
    }
    return null;
  }

  const ai = getAIClient();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: { parts: [{ text: prompt }] },
      config: {
        imageConfig: { aspectRatio }
      }
    });
    
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (e) {
    console.error("Image generation failed", e);
    return null;
  }
};

export const generateVideo = async (prompt: string, aspectRatio: string = "16:9"): Promise<string | null> => {
  if (typeof window !== 'undefined') {
    const clientApiKey = localStorage.getItem('gemini_api_key') || '';
    if (clientApiKey) {
      try {
        const ai = new GoogleGenAI({ apiKey: clientApiKey });
        let operation = await ai.models.generateVideos({
          model: 'veo-3.1-generate-preview',
          prompt,
          config: {
            numberOfVideos: 1,
            resolution: '720p',
            aspectRatio
          }
        });

        while (!operation.done) {
          await new Promise(resolve => setTimeout(resolve, 5000));
          operation = await ai.operations.getVideosOperation({ operation });
        }

        return operation.response?.generatedVideos?.[0]?.video?.uri || null;
      } catch (err) {
        console.error("Direct browser video generation failed, trying fallback...", err);
      }
    }
    try {
      const response = await fetch('/api/gemini/video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, aspectRatio })
      });
      if (response.ok) {
        const data = await response.json();
        return data.video || null;
      }
    } catch (e) {
      console.error("Client video generation failed:", e);
    }
    return null;
  }

  const ai = getAIClient();
  try {
    let operation = await ai.models.generateVideos({
      model: 'veo-3.1-generate-preview',
      prompt,
      config: {
        numberOfVideos: 1,
        resolution: '720p',
        aspectRatio
      }
    });

    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      operation = await ai.operations.getVideosOperation({ operation });
    }

    return operation.response?.generatedVideos?.[0]?.video?.uri || null;
  } catch (e) {
    console.error("Video generation failed", e);
    return null;
  }
};

export const generateEmbedding = async (text: string, overrideApiKey?: string): Promise<number[]> => {
  if (typeof window !== 'undefined') {
    const clientApiKey = localStorage.getItem('gemini_api_key') || overrideApiKey || '';
    if (clientApiKey) {
      try {
        const ai = new GoogleGenAI({ apiKey: clientApiKey });
        const response = await ai.models.embedContent({
          model: 'gemini-embedding-2-preview',
          contents: text
        });
        const resAny = response as any;
        if (resAny.embedding?.values) {
          return resAny.embedding.values;
        }
        if (resAny.embeddings && Array.isArray(resAny.embeddings)) {
          return resAny.embeddings;
        }
        return [];
      } catch (err) {
        console.error("Direct browser embedding failed, trying fallback...", err);
      }
    }
    try {
      const response = await fetch('/api/gemini/embeddings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, apiKey: clientApiKey })
      });
      if (response.ok) {
        const data = await response.json();
        return data.embedding || [];
      }
    } catch (e) {
      console.error("Client embedding generation failed:", e);
    }
    return [];
  }

  const ai = getAIClient(overrideApiKey);
  try {
    const response = await ai.models.embedContent({
      model: 'gemini-embedding-2-preview',
      contents: text
    });
    const resAny = response as any;
    if (resAny.embedding?.values) {
      return resAny.embedding.values;
    }
    if (resAny.embeddings && Array.isArray(resAny.embeddings)) {
      return resAny.embeddings;
    }
    return [];
  } catch (e) {
    console.error("Embedding generation failed", e);
    return [];
  }
};

export const generateSpeech = async (
  text: string,
  voice: string = "Kore",
  overrideApiKey?: string
): Promise<{ audio: string; mimeType: string }> => {
  const clean = text
    .replace(/```[\s\S]*?```/g, " [Code block omitted] ")
    .replace(/`([^`]+)`/g, "$1")
    .replace(/[#*_~]/g, "")
    .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
    .replace(/\s+/g, " ")
    .trim();

  if (!clean) {
    throw new Error("Text is empty");
  }

  const ai = getAIClient(overrideApiKey);
  
  // Truncate to reasonable length for speech if too long
  const speechText = clean.length > 2000 ? clean.slice(0, 1997) + "..." : clean;

  const validVoices = ["Kore", "Puck", "Fenrir", "Zephyr", "Charon"];
  const targetVoice = validVoices.includes(voice) ? voice : "Kore";

  const response = await ai.models.generateContent({
    model: "gemini-3.1-flash-tts-preview",
    contents: speechText,
    config: {
      responseModalities: ["AUDIO"],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: {
            voiceName: targetVoice
          }
        }
      }
    }
  });

  const part = response.candidates?.[0]?.content?.parts?.[0];
  if (part?.inlineData?.data) {
    return {
      audio: part.inlineData.data,
      mimeType: part.inlineData.mimeType || "audio/mp3"
    };
  }

  throw new Error("No audio payload returned by TTS model");
};


