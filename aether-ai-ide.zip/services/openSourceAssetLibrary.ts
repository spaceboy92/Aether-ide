import * as THREE from 'three';
import {
  createAuthenticCarMesh,
  createAuthenticRobotMesh,
  createAuthenticTankMesh,
  createAuthenticStarfighterMesh,
  generateHighPolyErosionTerrain
} from './proceduralMeshEngine';

export interface OpenSourceAssetItem {
  id: string;
  name: string;
  category: 'characters' | 'vehicles' | 'weapons' | 'props' | 'environment';
  polyCount: string;
  license: string;
  description: string;
  color: string;
  tags: string[];
  generator: () => THREE.Object3D;
}

export const OPEN_SOURCE_3D_ASSETS: OpenSourceAssetItem[] = [
  {
    id: 'cyber_mech',
    name: 'Cyberpunk Battle Mech',
    category: 'characters',
    polyCount: '18,400 Tris',
    license: 'CC0 Open Source',
    description: 'Heavy assault mech with twin shoulder plasma canons and articulated limbs.',
    color: '#a855f7',
    tags: ['character', 'robot', 'mech', 'rigged', 'sci-fi'],
    generator: () => createAuthenticRobotMesh('#a855f7').group
  },
  {
    id: 'starfighter_v1',
    name: 'Quantum Starfighter Cruiser',
    category: 'vehicles',
    polyCount: '24,200 Tris',
    license: 'MIT License',
    description: 'High-speed interceptor spacecraft with sleek delta wing geometry.',
    color: '#06b6d4',
    tags: ['vehicle', 'spaceship', 'sci-fi', 'flyer'],
    generator: () => createAuthenticStarfighterMesh('#06b6d4').group
  },
  {
    id: 'hypercar_v2',
    name: 'Apex Neon Hypercar',
    category: 'vehicles',
    polyCount: '32,000 Tris',
    license: 'CC0 Open Source',
    description: 'Aerodynamic sports car with carbon fiber chassis and alloy wheels.',
    color: '#f97316',
    tags: ['vehicle', 'car', 'racing', 'supercar'],
    generator: () => createAuthenticCarMesh('#f97316').group
  },
  {
    id: 'plasma_blade',
    name: 'Energy Katana Blade',
    category: 'weapons',
    polyCount: '4,100 Tris',
    license: 'MIT License',
    description: 'Futuristic light-katana with glowing plasma edge and hilt controls.',
    color: '#ec4899',
    tags: ['weapon', 'sword', 'katana', 'sci-fi'],
    generator: () => {
      const g = new THREE.Group();
      const hiltGeo = new THREE.CylinderGeometry(0.08, 0.1, 0.8, 16);
      const hiltMat = new THREE.MeshStandardMaterial({ color: 0x18181b, metalness: 0.9, roughness: 0.1 });
      const hilt = new THREE.Mesh(hiltGeo, hiltMat);
      hilt.position.y = 0.4;
      g.add(hilt);

      const bladeGeo = new THREE.BoxGeometry(0.04, 2.8, 0.2);
      const bladeMat = new THREE.MeshStandardMaterial({
        color: 0xec4899,
        emissive: 0xec4899,
        emissiveIntensity: 0.8,
        roughness: 0.1,
        metalness: 0.5
      });
      const blade = new THREE.Mesh(bladeGeo, bladeMat);
      blade.position.y = 2.2;
      g.add(blade);
      return g;
    }
  },
  {
    id: 'recon_drone',
    name: 'Aether Recon Hover Drone',
    category: 'props',
    polyCount: '8,600 Tris',
    license: 'CC0 Open Source',
    description: 'Autonomous quad-rotor surveillance drone with central camera eye.',
    color: '#10b981',
    tags: ['drone', 'prop', 'bot', 'hover'],
    generator: () => {
      const g = new THREE.Group();
      const bodyGeo = new THREE.SphereGeometry(0.6, 24, 24);
      const bodyMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.85, roughness: 0.2 });
      const body = new THREE.Mesh(bodyGeo, bodyMat);
      g.add(body);

      const eyeGeo = new THREE.SphereGeometry(0.25, 16, 16);
      const eyeMat = new THREE.MeshStandardMaterial({ color: 0x10b981, emissive: 0x10b981, emissiveIntensity: 1.0 });
      const eye = new THREE.Mesh(eyeGeo, eyeMat);
      eye.position.set(0, 0, 0.5);
      g.add(eye);
      return g;
    }
  },
  {
    id: 'cyber_pylon',
    name: 'Quantum Crystal Core',
    category: 'props',
    polyCount: '3,200 Tris',
    license: 'MIT License',
    description: 'Pulsating energy crystal mounted on an octagon metallic pedestal.',
    color: '#8b5cf6',
    tags: ['crystal', 'prop', 'energy', 'powerup'],
    generator: () => {
      const g = new THREE.Group();
      const baseGeo = new THREE.CylinderGeometry(0.8, 1.1, 0.4, 8);
      const baseMat = new THREE.MeshStandardMaterial({ color: 0x3f3f46, metalness: 0.9, roughness: 0.2 });
      const base = new THREE.Mesh(baseGeo, baseMat);
      g.add(base);

      const cryGeo = new THREE.OctahedronGeometry(1.2, 0);
      const cryMat = new THREE.MeshStandardMaterial({
        color: 0x8b5cf6,
        emissive: 0x8b5cf6,
        emissiveIntensity: 0.7,
        wireframe: false,
        roughness: 0.1
      });
      const crystal = new THREE.Mesh(cryGeo, cryMat);
      crystal.position.y = 1.6;
      g.add(crystal);
      return g;
    }
  },
  {
    id: 'assault_tank',
    name: 'Heavy Armored Hover Tank',
    category: 'vehicles',
    polyCount: '28,000 Tris',
    license: 'CC0 Open Source',
    description: 'Double-turret battle tank with reinforced tread armor plates.',
    color: '#eab308',
    tags: ['vehicle', 'tank', 'military', 'armor'],
    generator: () => createAuthenticTankMesh('#eab308').group
  },
  {
    id: 'erosion_terrain',
    name: 'High-Poly Erosion Mountain',
    category: 'environment',
    polyCount: '65,000 Tris',
    license: 'MIT License',
    description: 'Procedurally eroded mountain terrain with altitude gradient texturing.',
    color: '#14b8a6',
    tags: ['environment', 'terrain', 'mountain', 'landscape'],
    generator: () => new THREE.Mesh(generateHighPolyErosionTerrain(), new THREE.MeshStandardMaterial({ color: 0x14b8a6, roughness: 0.8 }))
  },
  {
    id: 'pine_tree',
    name: 'Low-Poly Evergreen Tree',
    category: 'environment',
    polyCount: '1,200 Tris',
    license: 'CC0 Open Source',
    description: 'Stylized pine tree for nature scenes and open-world environments.',
    color: '#22c55e',
    tags: ['tree', 'environment', 'nature', 'foliage'],
    generator: () => {
      const g = new THREE.Group();
      const trunkGeo = new THREE.CylinderGeometry(0.15, 0.25, 1.2, 8);
      const trunkMat = new THREE.MeshStandardMaterial({ color: 0x78350f });
      const trunk = new THREE.Mesh(trunkGeo, trunkMat);
      trunk.position.y = 0.6;
      g.add(trunk);

      for (let i = 0; i < 3; i++) {
        const coneGeo = new THREE.ConeGeometry(1.2 - i * 0.25, 1.5, 8);
        const coneMat = new THREE.MeshStandardMaterial({ color: 0x15803d, roughness: 0.8 });
        const cone = new THREE.Mesh(coneGeo, coneMat);
        cone.position.y = 1.4 + i * 0.9;
        g.add(cone);
      }
      return g;
    }
  },
  {
    id: 'hex_shield_prop',
    name: 'Hexagonal Energy Shield',
    category: 'props',
    polyCount: '6,400 Tris',
    license: 'MIT License',
    description: 'Curved forcefield barrier with animated honeycomb energy weave.',
    color: '#3b82f6',
    tags: ['shield', 'energy', 'prop', 'barrier'],
    generator: () => {
      const g = new THREE.Group();
      const shieldGeo = new THREE.IcosahedronGeometry(2, 2);
      const shieldMat = new THREE.MeshStandardMaterial({
        color: 0x3b82f6,
        wireframe: true,
        emissive: 0x3b82f6,
        emissiveIntensity: 0.6
      });
      const shield = new THREE.Mesh(shieldGeo, shieldMat);
      g.add(shield);
      return g;
    }
  }
];
