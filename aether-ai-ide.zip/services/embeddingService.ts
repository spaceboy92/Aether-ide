import Dexie, { type Table } from 'dexie';
import { FileNode } from '../types';

export interface CodeChunk {
  id: string; // fileId + chunkIndex
  fileId: string;
  filePath: string;
  text: string;
  type: 'function' | 'comment' | 'block' | 'import';
  vector: number[];
  signature?: string;
}

class EmbeddingsDatabase extends Dexie {
  chunks!: Table<CodeChunk>;

  constructor() {
    super('AetherEmbeddingsDatabase');
    this.version(1).stores({
      chunks: 'id, fileId, filePath, type'
    });
  }
}

const edb = new EmbeddingsDatabase();

// Cosine similarity helper
export function cosineSimilarity(vecA: number[], vecB: number[]): number {
  if (!vecA || !vecB || vecA.length !== vecB.length || vecA.length === 0) return 0;
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += vecA[i] * vecA[i];
    normB += vecB[i] * vecB[i];
  }
  if (normA === 0 || normB === 0) return 0;
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

// Fallback lightweight string-vector generator (TF-IDF/bag-of-words approximation) for instant fallback
function generateKeywordVector(text: string, dimensions = 768): number[] {
  const clean = text.toLowerCase().replace(/[^a-z0-9\s]/g, ' ');
  const words = clean.split(/\s+/).filter(w => w.length > 2);
  const vector = new Array(dimensions).fill(0);
  
  words.forEach(word => {
    // Simple hash to map words into dimensions
    let hash = 0;
    for (let i = 0; i < word.length; i++) {
      hash = (hash << 5) - hash + word.charCodeAt(i);
      hash |= 0;
    }
    const idx = Math.abs(hash) % dimensions;
    vector[idx] += 1;
  });
  
  // Normalize vector
  const magnitude = Math.sqrt(vector.reduce((sum, val) => sum + val * val, 0));
  if (magnitude > 0) {
    for (let i = 0; i < dimensions; i++) {
      vector[i] /= magnitude;
    }
  }
  return vector;
}

// Bypassing local Xenova transformers to avoid iframe/sandbox CORS and network errors.
// Using server-side high-fidelity Gemini API embeddings (gemini-embedding-2-preview) or local keyword vector fallback.
let extractor: any = null;
async function getExtractor() {
  return null;
}

// Generate premium vector embeddings
export async function getEmbedding(text: string): Promise<number[]> {
  if (!text || !text.trim()) {
    return new Array(768).fill(0);
  }

  // 1. Try Server-Side Gemini API embeddings proxy (gemini-embedding-2-preview)
  try {
    const res = await fetch('/api/gemini/embeddings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });
    if (res.ok) {
      const data = await res.json();
      if (data.embedding && Array.isArray(data.embedding)) {
        return data.embedding;
      }
    }
  } catch (e) {
    // server API error or offline
  }

  // 2. Dual-redundant local keyword hash vector (768 dimensions)
  return generateKeywordVector(text, 768);
}

// Code chunking utilities
export function chunkCodeFile(file: FileNode): Omit<CodeChunk, 'vector'>[] {
  const chunks: Omit<CodeChunk, 'vector'>[] = [];
  const content = file.content || '';
  if (!content.trim()) return [];

  const lines = content.split('\n');

  // Regex patterns to detect structure
  const jsFuncPattern = /(?:async\s+)?function\s+([a-zA-Z0-9_$]+)\s*\(|const\s+([a-zA-Z0-9_$]+)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>|(?:export\s+)?class\s+([a-zA-Z0-9_$]+)/;
  const pyFuncPattern = /def\s+([a-zA-Z0-9_$]+)\s*\(|class\s+([a-zA-Z0-9_$]+)/;
  const commentPattern = /^\s*(\/\/|\/\*|\*|#|"""|'''|\*\/)/;
  const importPattern = /^(import\s+|from\s+|require\()/;

  let currentChunkText: string[] = [];
  let chunkStartIndex = 0;

  const commitChunk = (type: CodeChunk['type'], name?: string) => {
    if (currentChunkText.length === 0) return;
    const chunkText = currentChunkText.join('\n');
    if (chunkText.trim().length > 15) {
      chunks.push({
        id: `${file.id}-chunk-${chunks.length}`,
        fileId: file.id,
        filePath: file.name,
        text: chunkText,
        type,
        signature: name || undefined
      });
    }
    currentChunkText = [];
  };

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const isImport = importPattern.test(line);
    const isComment = commentPattern.test(line);
    
    // Detect functions/methods
    const isJSFunc = file.name.endsWith('.ts') || file.name.endsWith('.tsx') || file.name.endsWith('.js') || file.name.endsWith('.jsx');
    const isPyFunc = file.name.endsWith('.py');

    let funcName = '';
    let isFuncStart = false;

    if (isJSFunc) {
      const match = line.match(jsFuncPattern);
      if (match) {
        funcName = match[1] || match[2] || match[3] || '';
        isFuncStart = true;
      }
    } else if (isPyFunc) {
      const match = line.match(pyFuncPattern);
      if (match) {
        funcName = match[1] || match[2] || '';
        isFuncStart = true;
      }
    }

    if (isImport) {
      commitChunk('block');
      currentChunkText.push(line);
      commitChunk('import');
    } else if (isComment) {
      if (currentChunkText.length > 0 && chunks.length > 0 && chunks[chunks.length - 1].type !== 'comment') {
        commitChunk('block');
      }
      currentChunkText.push(line);
      if (i === lines.length - 1 || !commentPattern.test(lines[i + 1])) {
        commitChunk('comment');
      }
    } else if (isFuncStart) {
      commitChunk('block');
      currentChunkText.push(line);
      // capture some context lines of function body
      let bodyLines = 0;
      while (i + 1 < lines.length && bodyLines < 15) {
        const nextLine = lines[i + 1];
        if (importPattern.test(nextLine) || jsFuncPattern.test(nextLine) || pyFuncPattern.test(nextLine)) {
          break;
        }
        currentChunkText.push(nextLine);
        i++;
        bodyLines++;
      }
      commitChunk('function', funcName);
    } else {
      currentChunkText.push(line);
      if (currentChunkText.length >= 25) {
        commitChunk('block');
      }
    }
  }
  
  commitChunk('block');
  return chunks;
}

export const embeddingService = {
  // Index files and store their vector representations in Dexie
  async indexFiles(files: FileNode[], onProgress?: (msg: string) => void) {
    if (onProgress) onProgress('Parsing codebase structures...');
    
    const allChunks: CodeChunk[] = [];
    
    for (const file of files) {
      if (file.isBinary || file.name.includes('node_modules') || file.name.includes('dist')) continue;
      
      const rawChunks = chunkCodeFile(file);
      if (rawChunks.length === 0) continue;
      
      if (onProgress) onProgress(`Generating brain maps for ${file.name}...`);
      
      for (const rc of rawChunks) {
        const vector = await getEmbedding(rc.text);
        allChunks.push({
          ...rc,
          vector
        });
      }
    }

    if (allChunks.length > 0) {
      await edb.chunks.clear();
      await edb.chunks.bulkPut(allChunks);
      if (onProgress) onProgress(`Semantic Brain Maps ready! Built ${allChunks.length} neural vectors.`);
    }
  },

  // Semantic query search
  async semanticSearch(query: string, limit = 5): Promise<(CodeChunk & { similarity: number })[]> {
    const queryVector = await getEmbedding(query);
    const allChunks = await edb.chunks.toArray();
    
    const scored = allChunks.map(chunk => {
      const similarity = cosineSimilarity(queryVector, chunk.vector);
      return {
        ...chunk,
        similarity
      };
    });

    // Sort by descending similarity
    return scored
      .filter(s => s.similarity > 0.15)
      .sort((a, b) => b.similarity - a.similarity)
      .slice(0, limit);
  },

  // Find similar functions based on semantic descriptions
  async findSimilarFunctions(description: string): Promise<string> {
    const results = await this.semanticSearch(description, 3);
    const functions = results.filter(r => r.type === 'function');
    if (functions.length === 0) {
      return `No highly matching function signatures found semantically. Here are the closest logical blocks:\n\n` + 
        results.map(r => `\`${r.filePath}\` (Similarity: ${(r.similarity * 100).toFixed(1)}%):\n\`\`\`\n${r.text.slice(0, 300)}\n\`\`\``).join('\n\n');
    }
    
    return `### Found Semantically Similar Functions:\n\n` +
      functions.map(f => `**File**: \`${f.filePath}\` | **Signature**: \`${f.signature || 'Anonymous'}\` (Match: ${(f.similarity * 100).toFixed(1)}%)\n\`\`\`typescript\n${f.text}\n\`\`\``).join('\n\n');
  },

  // Diagnose why a stack trace fails semantically
  async explainWhyThisFails(stackTrace: string): Promise<string> {
    const results = await this.semanticSearch(stackTrace, 3);
    if (results.length === 0) {
      return `I analyzed the logs but couldn't find matches in the workspace codebase. Check file formats or stack paths.`;
    }

    return `### Cognitive Analysis of Failure Path:\n\nBased on your stack trace, I mapped the closest codebase files with high-dimensional matches:\n\n` +
      results.map((r, i) => `**[Candidate ${i+1}] ${r.filePath}** (Match Confidence: ${(r.similarity * 100).toFixed(1)}%)\n` + 
      `*Code segment corresponding to trace signature:*\n\`\`\`typescript\n${r.text.slice(0, 400)}\n\`\`\``).join('\n\n') +
      `\n\n**Neural Recommendation**: Inspect variables and boundary conditions around these segments.`;
  },

  // Scan project and find semantically duplicate or unused elements
  async findUnusedImports(): Promise<string> {
    const allChunks = await edb.chunks.toArray();
    const imports = allChunks.filter(c => c.type === 'import');
    const nonImports = allChunks.filter(c => c.type !== 'import');
    
    const unused: string[] = [];
    
    imports.forEach(imp => {
      // Find what names this import defines (e.g. import { x, y } from 'z')
      const importNames = imp.text.match(/\{([^}]+)\}/);
      if (importNames && importNames[1]) {
        const names = importNames[1].split(',').map(n => n.trim());
        names.forEach(name => {
          // Check if name is referenced anywhere in other chunks of the same file
          const sameFileChunks = nonImports.filter(c => c.filePath === imp.filePath);
          const isUsed = sameFileChunks.some(c => c.text.includes(name));
          if (!isUsed && name && !unused.includes(`\`${name}\` in \`${imp.filePath}\``)) {
            unused.push(`\`${name}\` in \`${imp.filePath}\``);
          }
        });
      }
    });

    if (unused.length === 0) {
      return `All analyzed ES module bindings seem active and referenced correctly! No dead code detected.`;
    }

    return `### Semantically Detected Unused Imports / Dead Code:\n\n` + 
      unused.map(u => `- ${u}`).join('\n') + 
      `\n\n*Tip: Clean these up to reduce bundling overhead and increase compiler efficiency!*`;
  },

  // Highlight long complex functions that should be refactored
  async suggestRefactor(description: string): Promise<string> {
    const results = await this.semanticSearch(description || 'long complex nested loops callback hell', 3);
    const functions = results.filter(r => r.type === 'function' || r.text.split('\n').length > 25);
    
    if (functions.length === 0) {
      return `Your codebase is clean, well-modularized, and exhibits high readability! No refactoring suggestions necessary.`;
    }

    return `### Refactoring & Decomposition Suggestions:\n\n` +
      functions.map(f => `**File**: \`${f.filePath}\` | **Block Match**: \`${f.signature || 'Anonymous Block'}\` (Complexity Match: ${(f.similarity * 100).toFixed(1)}%)\n` +
      `*Target snippet for modular extraction:*\n\`\`\`typescript\n${f.text.slice(0, 300)}...\n\`\`\`\n` +
      `*Modularization Strategy:* Extract this block into a dedicated helper or custom React hook in a separate file under \`/components\` or \`/utils\` to improve dry-ness.`).join('\n\n');
  }
};
