import * as THREE from 'three';

// ============================================================================
// AETHER 3D GAME ENGINE - COMPREHENSIVE WATER & WAVE SIMULATION ENGINE
// Dynamic Gerstner Ocean Waves, Real-time Buoyancy Physics, Multi-emitter Water
// Particle Physics (Splashes, Wakes, Mist, Rain, Bubbles), Web Audio Water DSP,
// and Authentic Speedboat / Hydrofoil Procedural Models.
// ============================================================================

export interface WaterWaveParams {
  waveHeight: number;        // Amplitude (0.1 to 3.0)
  waveSpeed: number;         // Animation Speed (0.2 to 4.0)
  waveFrequency: number;     // Spatial frequency / wavelength (0.02 to 0.4)
  steepness: number;         // Gerstner crest sharpness (0.0 to 1.0)
  waterColor: string;        // Surface / shallow tint (e.g. #06b6d4)
  deepWaterColor: string;    // Deep depth tint (e.g. #082f49)
  foamColor: string;         // Wave peak foam tint (e.g. #e0f2fe)
  transparency: number;      // Opacity (0.2 to 1.0)
  roughness: number;         // Surface roughness (0.0 to 0.8)
  metalness: number;         // Surface reflectivity (0.0 to 1.0)
  enableBuoyancy: boolean;   // Enable real-time floating simulation
  particleDensity: number;   // Splash & wake particle multiplier (0.2 to 3.0)
}

export const DEFAULT_WATER_PARAMS: WaterWaveParams = {
  waveHeight: 0.65,
  waveSpeed: 1.4,
  waveFrequency: 0.08,
  steepness: 0.45,
  waterColor: '#06b6d4',
  deepWaterColor: '#0c4a6e',
  foamColor: '#f0fdfa',
  transparency: 0.88,
  roughness: 0.12,
  metalness: 0.85,
  enableBuoyancy: true,
  particleDensity: 1.2
};

export const WATER_THEME_PRESETS: Record<string, { name: string; params: Partial<WaterWaveParams> }> = {
  caribbean_lagoon: {
    name: 'Caribbean Turquoise Lagoon',
    params: {
      waterColor: '#22d3ee',
      deepWaterColor: '#0284c7',
      foamColor: '#ffffff',
      waveHeight: 0.35,
      waveSpeed: 1.1,
      waveFrequency: 0.06,
      transparency: 0.92
    }
  },
  deep_ocean_tempest: {
    name: 'Stormy Deep Ocean Swells',
    params: {
      waterColor: '#0369a1',
      deepWaterColor: '#020617',
      foamColor: '#f8fafc',
      waveHeight: 1.6,
      waveSpeed: 2.2,
      waveFrequency: 0.05,
      steepness: 0.75,
      transparency: 0.95
    }
  },
  cyberpunk_neon_harbor: {
    name: 'Cyberpunk Neon Toxic Harbor',
    params: {
      waterColor: '#06b6d4',
      deepWaterColor: '#1e1b4b',
      foamColor: '#f43f5e',
      waveHeight: 0.5,
      waveSpeed: 1.8,
      waveFrequency: 0.12,
      roughness: 0.05,
      metalness: 0.95,
      transparency: 0.85
    }
  },
  emerald_mountain_lake: {
    name: 'Emerald Alpine Mountain Lake',
    params: {
      waterColor: '#10b981',
      deepWaterColor: '#064e3b',
      foamColor: '#e6fffa',
      waveHeight: 0.25,
      waveSpeed: 0.8,
      waveFrequency: 0.09,
      transparency: 0.9
    }
  },
  volcanic_magma_water: {
    name: 'Volcanic Boiling Sulfur Basin',
    params: {
      waterColor: '#f97316',
      deepWaterColor: '#450a0a',
      foamColor: '#fbbf24',
      waveHeight: 0.9,
      waveSpeed: 2.5,
      waveFrequency: 0.15,
      transparency: 0.92
    }
  }
};

/**
 * Mathematical Gerstner Wave Displacement & Elevation Calculation
 * Superposition of 4 multi-directional Gerstner wave vectors with crest sharpening.
 */
export function calculateGerstnerWaterHeight(
  x: number,
  z: number,
  time: number,
  params: WaterWaveParams = DEFAULT_WATER_PARAMS
): { y: number; normal: THREE.Vector3; foam: number } {
  const t = time * params.waveSpeed;
  const freq = params.waveFrequency;
  const amp = params.waveHeight;
  const steep = params.steepness;

  // Wave 1: Primary Swell (Direction: [0.707, 0.707])
  const d1x = 0.707, d1z = 0.707;
  const dot1 = (d1x * x + d1z * z) * freq + t;
  const s1 = Math.sin(dot1);
  const c1 = Math.cos(dot1);

  // Wave 2: Secondary Diagonal Cross-Wave (Direction: [-0.6, 0.8])
  const d2x = -0.6, d2z = 0.8;
  const dot2 = (d2x * x + d2z * z) * (freq * 1.6) + t * 1.3;
  const s2 = Math.sin(dot2);
  const c2 = Math.cos(dot2);

  // Wave 3: High-Frequency Wind Ripple (Direction: [0.9, -0.43])
  const d3x = 0.9, d3z = -0.43;
  const dot3 = (d3x * x + d3z * z) * (freq * 2.8) + t * 2.1;
  const s3 = Math.sin(dot3);
  const c3 = Math.cos(dot3);

  // Wave 4: Micro-Chop Wave (Direction: [-0.3, -0.95])
  const d4x = -0.3, d4z = -0.95;
  const dot4 = (d4x * x + d4z * z) * (freq * 4.2) + t * 3.0;
  const s4 = Math.sin(dot4);
  const c4 = Math.cos(dot4);

  // Elevation Superposition
  const y = (s1 * 0.5 + s2 * 0.28 + s3 * 0.14 + s4 * 0.08) * amp;

  // Partial derivatives for accurate surface normal
  const dy_dx = (c1 * d1x * 0.5 + c2 * d2x * 0.28 * 1.6 + c3 * d3x * 0.14 * 2.8 + c4 * d4x * 0.08 * 4.2) * amp * freq;
  const dy_dz = (c1 * d1z * 0.5 + c2 * d2z * 0.28 * 1.6 + c3 * d3z * 0.14 * 2.8 + c4 * d4z * 0.08 * 4.2) * amp * freq;

  const normal = new THREE.Vector3(-dy_dx, 1.0, -dy_dz).normalize();

  // Foam intensity increases at wave peaks and steep gradients
  const peakFactor = Math.max(0, (y / (amp + 0.001)) - 0.45) * 2.2;
  const steepFactor = (Math.abs(dy_dx) + Math.abs(dy_dz)) * steep * 1.5;
  const foam = Math.min(1.0, Math.max(0.0, peakFactor + steepFactor));

  return { y, normal, foam };
}

/**
 * Create High-Fidelity Animated Three.js Water Mesh
 */
export function createDynamicWaterMesh(
  size = 500,
  subdivisions = 160,
  params: WaterWaveParams = DEFAULT_WATER_PARAMS
): { mesh: THREE.Mesh; update: (time: number) => void; geometry: THREE.PlaneGeometry; material: THREE.MeshStandardMaterial } {
  const geometry = new THREE.PlaneGeometry(size, size, subdivisions, subdivisions);
  geometry.rotateX(-Math.PI / 2);

  const material = new THREE.MeshStandardMaterial({
    color: new THREE.Color(params.waterColor),
    roughness: params.roughness,
    metalness: params.metalness,
    transparent: true,
    opacity: params.transparency,
    flatShading: false,
    side: THREE.DoubleSide
  });

  const mesh = new THREE.Mesh(geometry, material);
  mesh.receiveShadow = true;
  mesh.castShadow = false;

  const originalPositions = (geometry.attributes.position.array as Float32Array).slice();

  const update = (time: number) => {
    const posAttr = geometry.attributes.position;
    const count = posAttr.count;

    for (let i = 0; i < count; i++) {
      const origX = originalPositions[i * 3];
      const origZ = originalPositions[i * 3 + 2];

      const { y } = calculateGerstnerWaterHeight(origX, origZ, time, params);
      posAttr.setY(i, y);
    }

    posAttr.needsUpdate = true;
    geometry.computeVertexNormals();
  };

  return { mesh, update, geometry, material };
}

/**
 * WATER PARTICLE ENGINE
 * Handles:
 * 1. Wake Foam & Water Spray behind moving vessels/vehicles
 * 2. Impact Splash Bursts (fountains of water droplets)
 * 3. Water Ripple Wave Rings (expanding concentric wave rings)
 * 4. Waterfall & Mist Emitters
 * 5. Dynamic Raindrops with Floor Splashes
 * 6. Underwater Rising Bubble Streams
 */

export interface WaterParticle {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
  size: number;
  opacity: number;
  type: 'spray' | 'foam' | 'bubble' | 'rain' | 'ripple';
  color: THREE.Color;
}

export class WaterParticleSystem {
  public group: THREE.Group;
  private particles: WaterParticle[] = [];
  private sprayPoints: THREE.Points;
  private sprayGeo: THREE.BufferGeometry;
  private sprayMat: THREE.PointsMaterial;
  private maxParticles = 3500;
  private rippleMeshes: Array<{ mesh: THREE.Mesh; life: number; maxLife: number }> = [];

  constructor(scene?: THREE.Scene) {
    this.group = new THREE.Group();

    // Points Buffer Setup
    this.sprayGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(this.maxParticles * 3);
    const colors = new Float32Array(this.maxParticles * 3);

    this.sprayGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    this.sprayGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    this.sprayMat = new THREE.PointsMaterial({
      size: 0.35,
      vertexColors: true,
      transparent: true,
      opacity: 0.85,
      blending: THREE.NormalBlending,
      depthWrite: false
    });

    this.sprayPoints = new THREE.Points(this.sprayGeo, this.sprayMat);
    this.group.add(this.sprayPoints);

    if (scene) {
      scene.add(this.group);
    }
  }

  /**
   * Spawn dynamic wake spray behind a moving object on water
   */
  public emitWakeSpray(
    origin: THREE.Vector3,
    heading: number,
    speed: number,
    waterColor = '#e0f2fe',
    multiplier = 1.0
  ) {
    if (Math.abs(speed) < 0.05) return;

    const count = Math.min(18, Math.floor(Math.abs(speed) * 35 * multiplier));
    const baseColor = new THREE.Color(waterColor);

    for (let i = 0; i < count; i++) {
      if (this.particles.length >= this.maxParticles) break;

      // Lateral spray dispersion to left and right of vessel hull
      const side = (i % 2 === 0 ? 1 : -1) * (0.6 + Math.random() * 0.8);
      const sideAngle = heading + (side > 0 ? Math.PI * 0.45 : -Math.PI * 0.45);

      const spraySpeed = (0.2 + Math.random() * 0.5) * Math.abs(speed) * 4.0;
      const vx = Math.sin(sideAngle) * spraySpeed + (Math.random() - 0.5) * 0.1;
      const vz = Math.cos(sideAngle) * spraySpeed + (Math.random() - 0.5) * 0.1;
      const vy = (0.3 + Math.random() * 0.6) * Math.abs(speed) * 3.5;

      const pColor = baseColor.clone().offsetHSL(0, 0, (Math.random() - 0.5) * 0.1);

      this.particles.push({
        x: origin.x + (Math.random() - 0.5) * 0.4,
        y: origin.y + 0.1,
        z: origin.z + (Math.random() - 0.5) * 0.4,
        vx,
        vy,
        vz,
        life: 0,
        maxLife: 0.6 + Math.random() * 0.5,
        size: 0.25 + Math.random() * 0.35,
        opacity: 0.9,
        type: 'spray',
        color: pColor
      });
    }
  }

  /**
   * Spawn 360-degree Impact Water Splash Burst
   */
  public triggerSplashBurst(
    position: THREE.Vector3,
    intensity = 1.0,
    waterColor = '#bae6fd'
  ) {
    const count = Math.floor(120 * intensity);
    const baseColor = new THREE.Color(waterColor);

    for (let i = 0; i < count; i++) {
      if (this.particles.length >= this.maxParticles) break;

      const angle = Math.random() * Math.PI * 2;
      const radiusSpeed = (0.4 + Math.random() * 0.9) * intensity * 3.2;
      const vx = Math.cos(angle) * radiusSpeed;
      const vz = Math.sin(angle) * radiusSpeed;
      const vy = (0.8 + Math.random() * 1.5) * intensity * 4.0;

      this.particles.push({
        x: position.x + (Math.random() - 0.5) * 0.5,
        y: position.y + 0.1,
        z: position.z + (Math.random() - 0.5) * 0.5,
        vx,
        vy,
        vz,
        life: 0,
        maxLife: 0.8 + Math.random() * 0.7,
        size: 0.3 + Math.random() * 0.4,
        opacity: 1.0,
        type: 'spray',
        color: baseColor.clone()
      });
    }

    // Spawn Expanding Water Ripple Ring Mesh
    this.spawnWaterRipple(position, intensity * 2.5);
  }

  /**
   * Spawn expanding circular water wave ring decal
   */
  public spawnWaterRipple(position: THREE.Vector3, scale = 1.0) {
    const ringGeo = new THREE.RingGeometry(0.2, 0.45, 32);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x93c5fd,
      transparent: true,
      opacity: 0.8,
      side: THREE.DoubleSide,
      depthWrite: false
    });

    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = -Math.PI / 2;
    ring.position.set(position.x, position.y + 0.05, position.z);
    this.group.add(ring);

    this.rippleMeshes.push({
      mesh: ring,
      life: 0,
      maxLife: 1.2 * scale
    });
  }

  /**
   * Emit Atmospheric Rain Storm Drops
   */
  public emitRainDrops(center: THREE.Vector3, radius = 60, count = 25) {
    for (let i = 0; i < count; i++) {
      if (this.particles.length >= this.maxParticles) break;

      const angle = Math.random() * Math.PI * 2;
      const dist = Math.sqrt(Math.random()) * radius;
      const rx = center.x + Math.cos(angle) * dist;
      const rz = center.z + Math.sin(angle) * dist;
      const ry = center.y + 25 + Math.random() * 15;

      this.particles.push({
        x: rx,
        y: ry,
        z: rz,
        vx: -0.15,
        vy: -24.0 - Math.random() * 8.0,
        vz: 0.1,
        life: 0,
        maxLife: 1.5,
        size: 0.18,
        opacity: 0.7,
        type: 'rain',
        color: new THREE.Color(0xa5f3fc)
      });
    }
  }

  /**
   * Emit Waterfall Column & Misty Pool Fog
   */
  public emitWaterfallColumn(cliffPosition: THREE.Vector3, width = 6, height = 15, count = 12) {
    for (let i = 0; i < count; i++) {
      if (this.particles.length >= this.maxParticles) break;

      const offsetW = (Math.random() - 0.5) * width;
      this.particles.push({
        x: cliffPosition.x + offsetW,
        y: cliffPosition.y + (Math.random() - 0.5) * 0.5,
        z: cliffPosition.z + (Math.random() - 0.5) * 0.5,
        vx: (Math.random() - 0.5) * 0.4,
        vy: -7.0 - Math.random() * 4.0,
        vz: (Math.random() - 0.5) * 0.4,
        life: 0,
        maxLife: height / 8.0,
        size: 0.4 + Math.random() * 0.4,
        opacity: 0.8,
        type: 'spray',
        color: new THREE.Color(0xe0f2fe)
      });
    }
  }

  /**
   * Main Physics Tick & Attribute Buffer Update
   */
  public update(delta: number, waterLevelY = 0) {
    const gravity = -9.8;
    const positions = this.sprayGeo.attributes.position.array as Float32Array;
    const colors = this.sprayGeo.attributes.color.array as Float32Array;

    let activeCount = 0;

    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life += delta;

      if (p.life >= p.maxLife) {
        this.particles.splice(i, 1);
        continue;
      }

      // Physics Integration
      if (p.type === 'spray') {
        p.vy += gravity * delta * 1.2;
        p.vx *= 0.97;
        p.vz *= 0.97;
      } else if (p.type === 'bubble') {
        p.vy = Math.min(2.5, p.vy + 3.5 * delta); // Buoyancy rises
        p.vx += Math.sin(p.life * 10) * 0.05;
      }

      p.x += p.vx * delta;
      p.y += p.vy * delta;
      p.z += p.vz * delta;

      // Water Surface Collision
      if (p.type === 'spray' && p.y < waterLevelY && p.vy < 0) {
        p.vy = -p.vy * 0.25; // Bounce / damp
        p.y = waterLevelY;
      }
      if (p.type === 'rain' && p.y <= waterLevelY) {
        this.particles.splice(i, 1);
        continue;
      }

      const lifeRatio = 1.0 - (p.life / p.maxLife);
      const alpha = p.opacity * lifeRatio;

      const idx = activeCount * 3;
      positions[idx] = p.x;
      positions[idx + 1] = p.y;
      positions[idx + 2] = p.z;

      colors[idx] = p.color.r * alpha;
      colors[idx + 1] = p.color.g * alpha;
      colors[idx + 2] = p.color.b * alpha;

      activeCount++;
      if (activeCount >= this.maxParticles) break;
    }

    // Zero out unused particle buffer slots
    for (let i = activeCount; i < this.maxParticles; i++) {
      const idx = i * 3;
      positions[idx] = 0;
      positions[idx + 1] = -9999;
      positions[idx + 2] = 0;
    }

    this.sprayGeo.attributes.position.needsUpdate = true;
    this.sprayGeo.attributes.color.needsUpdate = true;
    this.sprayGeo.setDrawRange(0, activeCount);

    // Update Expanding Ripple Ring Meshes
    for (let i = this.rippleMeshes.length - 1; i >= 0; i--) {
      const item = this.rippleMeshes[i];
      item.life += delta;
      const rRatio = item.life / item.maxLife;

      if (rRatio >= 1.0) {
        this.group.remove(item.mesh);
        item.mesh.geometry.dispose();
        (item.mesh.material as THREE.Material).dispose();
        this.rippleMeshes.splice(i, 1);
      } else {
        const s = 1.0 + rRatio * 6.0;
        item.mesh.scale.set(s, s, 1.0);
        const mat = item.mesh.material as THREE.MeshBasicMaterial;
        mat.opacity = 0.8 * (1.0 - rRatio);
      }
    }
  }

  public dispose() {
    this.sprayGeo.dispose();
    this.sprayMat.dispose();
    this.rippleMeshes.forEach(r => {
      r.mesh.geometry.dispose();
      (r.mesh.material as THREE.Material).dispose();
    });
    this.particles = [];
  }
}

/**
 * 3D PROCEDURAL SPEEDBOAT & HYDROFOIL COMPOSITE MESH GENERATOR
 * Streamlined aerodynamic/hydrodynamic V-hull, dual cockpit windshield,
 * twin-propeller outboard motors with spinning propellers, and stabilizer fins.
 */
export function createAuthenticSpeedboatMesh(
  primaryColor = '#06b6d4',
  trimColor = '#f97316'
): { group: THREE.Group; propellers: THREE.Object3D[]; wakeOrigin: THREE.Vector3 } {
  const group = new THREE.Group();
  const propellers: THREE.Object3D[] = [];

  // 1. Sleek V-Hull
  const hullShape = new THREE.Shape();
  hullShape.moveTo(0, 0.4);
  hullShape.lineTo(1.1, 0.5);
  hullShape.lineTo(0.9, -0.4);
  hullShape.lineTo(0, -0.8);
  hullShape.lineTo(-0.9, -0.4);
  hullShape.lineTo(-1.1, 0.5);
  hullShape.closePath();

  const extrudeSettings = {
    steps: 12,
    depth: 5.2,
    bevelEnabled: true,
    bevelThickness: 0.3,
    bevelSize: 0.2,
    bevelSegments: 4
  };

  const hullGeo = new THREE.ExtrudeGeometry(hullShape, extrudeSettings);
  hullGeo.rotateY(Math.PI);
  hullGeo.center();

  const hullMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(primaryColor),
    metalness: 0.85,
    roughness: 0.15,
    envMapIntensity: 2.0
  });

  const hullMesh = new THREE.Mesh(hullGeo, hullMat);
  hullMesh.castShadow = true;
  hullMesh.receiveShadow = true;
  hullMesh.position.y = 0.35;
  group.add(hullMesh);

  // 2. Deck Inlay & Teak Wood Texture Simulator
  const deckGeo = new THREE.BoxGeometry(1.6, 0.15, 3.8);
  const deckMat = new THREE.MeshStandardMaterial({
    color: 0xd97706,
    roughness: 0.6,
    metalness: 0.1
  });
  const deckMesh = new THREE.Mesh(deckGeo, deckMat);
  deckMesh.position.set(0, 0.65, -0.2);
  group.add(deckMesh);

  // 3. Aerodynamic Tinted Windshield
  const shieldGeo = new THREE.CylinderGeometry(0.85, 0.95, 0.5, 16, 1, false, 0, Math.PI);
  const shieldMat = new THREE.MeshPhysicalMaterial({
    color: 0x1e293b,
    transparent: true,
    opacity: 0.65,
    roughness: 0.05,
    transmission: 0.6,
    thickness: 0.4
  });
  const windshield = new THREE.Mesh(shieldGeo, shieldMat);
  windshield.rotation.x = Math.PI * 0.15;
  windshield.position.set(0, 0.95, -0.4);
  group.add(windshield);

  // 4. Twin Racing Seats
  const seatGeo = new THREE.BoxGeometry(0.5, 0.6, 0.5);
  const seatMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.8 });
  const seatL = new THREE.Mesh(seatGeo, seatMat);
  seatL.position.set(-0.4, 0.8, -0.1);
  const seatR = new THREE.Mesh(seatGeo, seatMat);
  seatR.position.set(0.4, 0.8, -0.1);
  group.add(seatL, seatR);

  // 5. Dual Outboard Engines & Spinning Propellers
  const engineMat = new THREE.MeshStandardMaterial({ color: new THREE.Color(trimColor), metalness: 0.9, roughness: 0.2 });
  const propMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.95, roughness: 0.1 });

  [-0.45, 0.45].forEach((offsetX) => {
    const engGroup = new THREE.Group();
    const engBlock = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.7, 0.4), engineMat);
    engBlock.position.set(0, 0.2, 0);
    engGroup.add(engBlock);

    // Propeller Shaft & Blades
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.3), propMat);
    shaft.rotation.x = Math.PI / 2;
    shaft.position.set(0, -0.2, 0.2);
    engGroup.add(shaft);

    const propGroup = new THREE.Group();
    for (let b = 0; b < 3; b++) {
      const blade = new THREE.Mesh(new THREE.BoxGeometry(0.04, 0.28, 0.08), propMat);
      blade.rotation.z = (b * Math.PI * 2) / 3;
      blade.position.y = 0.12;
      propGroup.add(blade);
    }
    propGroup.position.set(0, -0.2, 0.35);
    engGroup.add(propGroup);
    propellers.push(propGroup);

    engGroup.position.set(offsetX, 0.35, 2.4);
    group.add(engGroup);
  });

  return {
    group,
    propellers,
    wakeOrigin: new THREE.Vector3(0, 0, 2.5)
  };
}

/**
 * PROCEDURAL WATER SFX SYNTHESIZER (Web Audio API)
 * Generates organic wave crashes, high-speed wake turbulence, and rain drops.
 */

export function playProceduralWaterSplash(ctx: AudioContext, intensity = 1.0) {
  try {
    const duration = 0.6 * intensity;
    const bufferSize = Math.floor(ctx.sampleRate * duration);
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);

    // Generate filtered bubble noise
    for (let i = 0; i < bufferSize; i++) {
      const decay = 1.0 - (i / bufferSize);
      data[i] = (Math.random() * 2 - 1) * Math.pow(decay, 1.8);
    }

    const noiseSource = ctx.createBufferSource();
    noiseSource.buffer = buffer;

    // Bandpass filter to simulate water bubbling frequency
    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(650, ctx.currentTime);
    filter.frequency.exponentialRampToValueAtTime(220, ctx.currentTime + duration);
    filter.Q.setValueAtTime(3.5, ctx.currentTime);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.25 * intensity, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

    noiseSource.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);

    noiseSource.start();
  } catch (e) {
    console.warn('Audio splash error:', e);
  }
}

export function startProceduralOceanAmbience(ctx: AudioContext): { stop: () => void; setVolume: (v: number) => void } {
  let isRunning = true;
  const masterGain = ctx.createGain();
  masterGain.gain.setValueAtTime(0.08, ctx.currentTime);
  masterGain.connect(ctx.destination);

  // Pink noise generator for ocean roar
  const bufferSize = ctx.sampleRate * 2;
  const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const data = noiseBuffer.getChannelData(0);
  let b0 = 0, b1 = 0, b2 = 0;
  for (let i = 0; i < bufferSize; i++) {
    const white = Math.random() * 2 - 1;
    b0 = 0.99886 * b0 + white * 0.0555179;
    b1 = 0.99332 * b1 + white * 0.0750759;
    b2 = 0.96900 * b2 + white * 0.1538520;
    data[i] = (b0 + b1 + b2) * 0.3;
  }

  const noiseSource = ctx.createBufferSource();
  noiseSource.buffer = noiseBuffer;
  noiseSource.loop = true;

  const lowpass = ctx.createBiquadFilter();
  lowpass.type = 'lowpass';
  lowpass.frequency.setValueAtTime(400, ctx.currentTime);

  noiseSource.connect(lowpass);
  lowpass.connect(masterGain);
  noiseSource.start();

  // Low frequency oscillator for wave swell rhythm (period ~6s)
  const swellLFO = () => {
    if (!isRunning) return;
    const now = ctx.currentTime;
    lowpass.frequency.setValueAtTime(250, now);
    lowpass.frequency.linearRampToValueAtTime(800, now + 3.0);
    lowpass.frequency.linearRampToValueAtTime(250, now + 6.0);
    setTimeout(swellLFO, 6000);
  };
  swellLFO();

  return {
    stop: () => {
      isRunning = false;
      try {
        noiseSource.stop();
        masterGain.disconnect();
      } catch (e) {}
    },
    setVolume: (vol: number) => {
      masterGain.gain.setTargetAtTime(vol, ctx.currentTime, 0.1);
    }
  };
}
