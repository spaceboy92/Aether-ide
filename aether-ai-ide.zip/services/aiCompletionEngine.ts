/**
 * Fast AI Inline Code Completion Engine with Local AST Pattern Matching & LRU Cache
 */

interface CompletionCacheEntry {
  prefix: string;
  completion: string;
  timestamp: number;
}

class AICompletionEngine {
  private cache: Map<string, CompletionCacheEntry> = new Map();
  private maxCacheSize = 200;

  /**
   * Get instant speculative completion based on local syntax patterns
   */
  public getLocalSpeculativeCompletion(
    prefixCode: string,
    suffixCode: string,
    language: string
  ): string | null {
    const lastLine = prefixCode.split('\n').pop()?.trim() || '';

    // Fast local AST snippet completions
    if (['typescript', 'javascript'].includes(language)) {
      if (lastLine.endsWith('.map(')) return 'item => {\n  return item;\n})';
      if (lastLine.endsWith('.filter(')) return 'item => Boolean(item))';
      if (lastLine.startsWith('import ') && !lastLine.includes('from')) return "{ } from './';";
      if (lastLine.startsWith('const [') && lastLine.includes('] = useState')) return '(initialValue);';
      if (lastLine.includes('useEffect(() => {') && !suffixCode.includes('}, []')) return '\n  return () => {};\n}, []);';
      if (lastLine.startsWith('async function ') && lastLine.endsWith('{')) return '\n  try {\n    \n  } catch (error) {\n    console.error(error);\n  }\n}';
      if (lastLine.startsWith('interface ') && lastLine.endsWith('{')) return '\n  id: string;\n  name: string;\n  createdAt: Date;\n}';
    }

    if (language === 'python') {
      if (lastLine.startsWith('def ') && lastLine.endsWith(':')) return '\n    """Function docstring."""\n    pass';
      if (lastLine.startsWith('class ') && lastLine.endsWith(':')) return '\n    def __init__(self):\n        pass';
      if (lastLine.startsWith('if __name__ ==') || lastLine.includes('__main__')) return ' "__main__":\n    main()';
      if (lastLine.startsWith('try:')) return '\n    pass\nexcept Exception as e:\n    print(f"Error: {e}")';
    }

    if (language === 'rust') {
      if (lastLine.startsWith('fn ') && lastLine.endsWith('{')) return '\n    unimplemented!()\n}';
      if (lastLine.startsWith('pub struct ') && lastLine.endsWith('{')) return '\n    pub id: String,\n}';
      if (lastLine.startsWith('impl ') && lastLine.endsWith('{')) return '\n    pub fn new() -> Self {\n        Self {}\n    }\n}';
    }

    return null;
  }

  /**
   * Fetch fast debounced AI completion from server with fallback to local speculation
   */
  public async getAICompletion(
    prefixCode: string,
    suffixCode: string,
    language: string,
    filePath: string
  ): Promise<string | null> {
    const cacheKey = `${language}:${filePath}:${prefixCode.slice(-100)}`;
    
    // Check LRU cache
    const cached = this.cache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < 30000) {
      return cached.completion;
    }

    // Try local instant completion first (< 10ms)
    const local = this.getLocalSpeculativeCompletion(prefixCode, suffixCode, language);
    if (local) {
      this.addToCache(cacheKey, prefixCode.slice(-100), local);
      return local;
    }

    // AI HTTP completion call
    try {
      const res = await fetch('/api/ai/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prefix: prefixCode.slice(-1000),
          suffix: suffixCode.slice(0, 500),
          language,
          filePath
        })
      });

      if (res.ok) {
        const data = await res.json();
        if (data.completion) {
          this.addToCache(cacheKey, prefixCode.slice(-100), data.completion);
          return data.completion;
        }
      }
    } catch {
      // Graceful fallback
    }

    return null;
  }

  private addToCache(key: string, prefix: string, completion: string) {
    if (this.cache.size >= this.maxCacheSize) {
      const firstKey = this.cache.keys().next().value;
      if (firstKey) this.cache.delete(firstKey);
    }
    this.cache.set(key, { prefix, completion, timestamp: Date.now() });
  }
}

export const aiCompletionEngine = new AICompletionEngine();
