import html2canvas from 'html2canvas';
import { ChatSession, FileNode, SessionSnapshot } from '../types';
import { storageService } from './storageService';

function generateSVGThumbnail(title: string, activeFileName: string, fileCount: number, codeSnippet: string): string {
  const cleanSnippet = (codeSnippet || '').slice(0, 150).replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="240" viewBox="0 0 400 240" fill="none">
    <rect width="400" height="240" rx="16" fill="#09090b"/>
    <rect x="1" y="1" width="398" height="238" rx="15" stroke="#27272a" stroke-width="1"/>
    <!-- Top Bar -->
    <rect x="12" y="12" width="376" height="28" rx="6" fill="#18181b"/>
    <circle cx="28" cy="26" r="4" fill="#ef4444"/>
    <circle cx="42" cy="26" r="4" fill="#eab308"/>
    <circle cx="56" cy="26" r="4" fill="#22c55e"/>
    <text x="76" y="30" fill="#a1a1aa" font-family="monospace" font-size="11">${activeFileName || 'index.tsx'}</text>
    <text x="320" y="30" fill="#f97316" font-family="monospace" font-size="10" font-weight="bold">${fileCount} files</text>

    <!-- Content Area / Code Mock -->
    <rect x="12" y="48" width="376" height="180" rx="8" fill="#121215"/>
    <text x="24" y="72" fill="#38bdf8" font-family="monospace" font-size="11" font-weight="bold">${title.slice(0, 32)}</text>
    <line x1="24" y1="84" x2="376" y2="84" stroke="#27272a" stroke-width="1"/>

    <!-- Code Preview Lines -->
    <text x="24" y="106" fill="#a1a1aa" font-family="monospace" font-size="9" opacity="0.8">${cleanSnippet.slice(0, 50)}</text>
    <text x="24" y="122" fill="#818cf8" font-family="monospace" font-size="9" opacity="0.8">${cleanSnippet.slice(50, 100)}</text>
    <text x="24" y="138" fill="#34d399" font-family="monospace" font-size="9" opacity="0.8">${cleanSnippet.slice(100, 150)}</text>

    <rect x="24" y="160" width="120" height="22" rx="4" fill="#f97316" fill-opacity="0.15" stroke="#f97316" stroke-opacity="0.3"/>
    <text x="36" y="175" fill="#fb923c" font-family="sans-serif" font-size="10" font-weight="bold">Auto Snapshot</text>
  </svg>`;

  return `data:image/svg+xml;base64,${btoa(unescape(encodeURIComponent(svg)))}`;
}

class SnapshotService {
  private lastSnapshotTime: Record<string, number> = {};
  private lastFilesHash: Record<string, string> = {};

  private computeFilesHash(files: FileNode[]): string {
    return files.map(f => `${f.id}:${f.name}:${f.content?.length || 0}`).join('|');
  }

  async captureSessionSnapshot(
    session: ChatSession,
    files: FileNode[],
    activeFileId: string | null,
    targetElement?: HTMLElement | null
  ): Promise<SessionSnapshot | null> {
    if (!session || !session.id || !files || files.length === 0) return null;

    const currentHash = this.computeFilesHash(files);
    const lastHash = this.lastFilesHash[session.id];
    const now = Date.now();

    // Skip duplicate snapshot if files haven't changed and last snapshot was less than 2 mins ago
    if (lastHash === currentHash && this.lastSnapshotTime[session.id] && now - this.lastSnapshotTime[session.id] < 120000) {
      return null;
    }

    const activeFile = files.find(f => f.id === activeFileId) || files[0];
    const totalLines = files.reduce((acc, f) => acc + (f.content?.split('\n').length || 0), 0);

    let thumbnailUrl = '';

    // Attempt HTML2Canvas preview element capture if element provided
    if (targetElement && targetElement.clientWidth > 0 && targetElement.clientHeight > 0) {
      try {
        const canvas = await html2canvas(targetElement, {
          useCORS: true,
          allowTaint: true,
          backgroundColor: '#09090b',
          scale: 0.5,
          logging: false,
          width: Math.min(targetElement.clientWidth, 800),
          height: Math.min(targetElement.clientHeight, 600)
        });
        thumbnailUrl = canvas.toDataURL('image/jpeg', 0.7);
      } catch (err) {
        // Fallback to SVG thumbnail
        thumbnailUrl = generateSVGThumbnail(
          session.title,
          activeFile?.name || 'index.tsx',
          files.length,
          activeFile?.content || ''
        );
      }
    } else {
      thumbnailUrl = generateSVGThumbnail(
        session.title,
        activeFile?.name || 'index.tsx',
        files.length,
        activeFile?.content || ''
      );
    }

    const snapshot: SessionSnapshot = {
      id: `snap_${now}_${Math.random().toString(36).substring(2, 7)}`,
      timestamp: now,
      thumbnailUrl,
      activeFileName: activeFile?.name || 'index.tsx',
      fileCount: files.length,
      totalLines,
      summary: `Automated snapshot (${files.length} files, ${totalLines} LOC)`,
      filesSnapshot: JSON.parse(JSON.stringify(files))
    };

    const updatedSnapshots = [snapshot, ...(session.snapshots || [])].slice(0, 15);
    const updatedSession: ChatSession = {
      ...session,
      thumbnailUrl,
      snapshots: updatedSnapshots,
      lastUpdated: now
    };

    this.lastSnapshotTime[session.id] = now;
    this.lastFilesHash[session.id] = currentHash;

    // Save to IndexedDB/Storage
    try {
      await storageService.saveSession({
        id: updatedSession.id,
        title: updatedSession.title,
        description: updatedSession.description,
        tags: updatedSession.tags,
        thumbnailUrl: updatedSession.thumbnailUrl,
        snapshots: updatedSession.snapshots,
        messages: updatedSession.messages,
        updatedAt: now
      });
      localStorage.setItem(`aether_snapshot_${session.id}_latest`, JSON.stringify(snapshot));
    } catch (e) {
      console.warn('Snapshot storage warning:', e);
    }

    // Dispatch global event for instant UI update
    window.dispatchEvent(
      new CustomEvent('aether_session_snapshot_created', {
        detail: { sessionId: session.id, snapshot, session: updatedSession }
      })
    );

    return snapshot;
  }
}

export const snapshotService = new SnapshotService();
