import { FileNode } from '../types';

/**
 * Service to manage high-performance workspace file caching using
 * the modern Origin Private File System (OPFS).
 * Falls back gracefully to IndexedDB or resolves to null if unsupported.
 */
export const opfsService = {
  isSupported(): boolean {
    return typeof navigator !== 'undefined' && !!navigator.storage && typeof navigator.storage.getDirectory === 'function';
  },

  async saveToOPFSCache(sessionId: string, files: FileNode[]): Promise<boolean> {
    if (!this.isSupported() || !sessionId) return false;

    try {
      const root = await navigator.storage.getDirectory();
      
      // Get or create session folder
      const sessionDir = await root.getDirectoryHandle(`session_${sessionId}`, { create: true });
      
      // Clean up previous files first to avoid stale files
      for await (const name of (sessionDir as any).keys()) {
        await sessionDir.removeEntry(name, { recursive: true });
      }

      // Write each file in the virtual file system to OPFS
      for (const file of files) {
        // Sanitize path names to be safe for directory structure
        const safeName = file.name.replace(/\//g, '___');
        const fileHandle = await sessionDir.getFileHandle(safeName, { create: true });
        
        // Write content
        const writable = await (fileHandle as any).createWritable();
        await writable.write(JSON.stringify({
          id: file.id,
          name: file.name,
          content: file.content,
          language: file.language,
          lastModified: file.lastModified,
          isBinary: file.isBinary
        }));
        await writable.close();
      }
      return true;
    } catch (e) {
      console.warn('[OPFS] Failed to write files to cache', e);
      return false;
    }
  },

  async loadFromOPFSCache(sessionId: string): Promise<FileNode[] | null> {
    if (!this.isSupported() || !sessionId) return null;

    try {
      const root = await navigator.storage.getDirectory();
      const sessionDir = await root.getDirectoryHandle(`session_${sessionId}`);
      
      const files: FileNode[] = [];
      for await (const entry of (sessionDir as any).values()) {
        if (entry.kind === 'file') {
          const file = await entry.getFile();
          const text = await file.text();
          if (!text || !text.trim()) continue;
          try {
            const parsed = JSON.parse(text);
            if (parsed && parsed.id && parsed.name) {
              files.push(parsed);
            }
          } catch (err) {
            console.warn('[OPFS] Skipped unparseable cache entry:', entry.name);
          }
        }
      }
      
      return files.length > 0 ? files : null;
    } catch (e) {
      // Folder might not exist yet, which is normal
      return null;
    }
  },

  async clearSessionCache(sessionId: string): Promise<boolean> {
    if (!this.isSupported() || !sessionId) return false;
    try {
      const root = await navigator.storage.getDirectory();
      await root.removeEntry(`session_${sessionId}`, { recursive: true });
      return true;
    } catch (e) {
      return false;
    }
  }
};
