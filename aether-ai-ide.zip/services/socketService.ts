import { io, Socket } from 'socket.io-client';

class SocketService {
  private socket: Socket | null = null;

  private latency: number = 0;
  private onLatencyUpdate: ((lat: number) => void) | null = null;

  setLatencyCallback(cb: (lat: number) => void) {
    this.onLatencyUpdate = cb;
  }

  connect() {
    if (this.socket) return;
    this.socket = io(window.location.origin, {
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
    });

    this.socket.on('connect', () => {
      console.log('Real-time Node Connected:', this.socket?.id);
      this.startHeartbeat();
    });

    this.socket.on('heartbeat-ack', (data: { timestamp: number }) => {
      let actualLatency = Date.now() - data.timestamp;
      this.latency = actualLatency;
      if (this.onLatencyUpdate) this.onLatencyUpdate(this.latency);
    });
  }

  private heartbeatInterval: NodeJS.Timeout | null = null;

  private startHeartbeat() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
    }
    this.heartbeatInterval = setInterval(() => {
      if (this.socket?.connected) {
        this.socket.emit('heartbeat', { timestamp: Date.now() });
      }
    }, 10000); // 10-second heartbeat to optimize internet usage
  }

  emit(event: string, data: any) {
    this.socket?.emit(event, data);
  }

  joinSession(sessionId: string) {
    if (!this.socket?.connected) return;
    this.socket?.emit('join-session', sessionId);
  }

  registerUser(user: { id: string, name: string, photoURL: string }) {
    if (!this.socket?.connected) return;
    this.socket?.emit('register-user', user);
  }

  onPresenceUpdate(callback: (users: any[]) => void) {
    if (!this.socket) return;
    this.socket?.on('presence-update', callback);
  }

  emitTyping(sessionId: string, user: string) {
    if (!this.socket?.connected) return;
    this.socket?.emit('typing', { sessionId, user });
  }

  emitCursor(sessionId: string, userId: string, position: { x: number, y: number }) {
    if (!this.socket?.connected) return;
    this.socket?.emit('cursor-move', { sessionId, userId, position });
  }

  onTyping(callback: (data: { user: string }) => void) {
    this.socket?.on('user-typing', callback);
  }

  onCursor(callback: (data: { userId: string, position: { x: number, y: number } }) => void) {
    this.socket?.on('user-cursor-moved', callback);
  }

  onNeuralFlux(callback: (data: { status: string, steps: any }) => void) {
    this.socket?.on('ai-neural-flux', callback);
  }

  onTerminalEvent(callback: (data: any) => void) {
    this.socket?.on('terminal-event', callback);
  }

  off(event: string, callback?: any) {
    if (callback) {
      this.socket?.off(event, callback);
    } else {
      this.socket?.off(event);
    }
  }

  disconnect() {
    if (this.socket && this.socket.connected) {
      this.socket.disconnect();
    }
    this.socket = null;
  }
}

export const socketService = new SocketService();
