/**
 * Aether Local Companion CLI & Native App Desktop Installer Generator (.BAT)
 * Generates standalone, downloadable .bat (Windows Batch) scripts that compile
 * and install a custom native Windows desktop application (AetherIDE.exe) right on
 * the user's PC, with persistent user sessions and zero local source-code exposure.
 */

export interface LocalCliPackage {
  filename: string;
  code: string;
  readme: string;
  installCommand: string;
}

export function generateLocalCliBatScript(apiUrl: string = window.location.origin): string {
  const cloudUrl = apiUrl || "http://localhost:3000";
  return `@echo off
:: ==============================================================================
::                  AETHER NATIVE APP COMPILER AND INSTALLER (.BAT)
::              Builds Standalone AetherIDE.exe Native Desktop Client
:: ==============================================================================
:: Compiles and installs a custom native Windows GUI application (AetherIDE.exe)
:: on the local machine with persistent user sessions and zero source-code exposure.

chcp 65001 >nul
title Aether Native Desktop App Builder v2.6.0
setlocal enabledelayedexpansion

set "AETHER_VERSION=2.6.0"
set "AETHER_APP_NAME=Aether AI IDE"
set "AETHER_CLOUD_URL=${cloudUrl}"
set "AETHER_PORT=9222"
set "AETHER_INSTALL_DIR=%LOCALAPPDATA%\\AetherIDE"
set "AETHER_USER_DATA=%LOCALAPPDATA%\\AetherIDE\\Profile"
set "AETHER_EXE=%AETHER_INSTALL_DIR%\\AetherIDE.exe"

if "%~1"=="" goto INTERACTIVE_MENU
if /i "%~1"=="install" goto CMD_INSTALL
if /i "%~1"=="build" goto CMD_INSTALL
if /i "%~1"=="launch" goto CMD_LAUNCH
if /i "%~1"=="app" goto CMD_LAUNCH
if /i "%~1"=="start" goto CMD_LAUNCH
if /i "%~1"=="uninstall" goto CMD_UNINSTALL
if /i "%~1"=="help" goto CMD_HELP
if /i "%~1"=="/?" goto CMD_HELP
if /i "%~1"=="-h" goto CMD_HELP
if /i "%~1"=="--help" goto CMD_HELP
if /i "%~1"=="doctor" goto CMD_DOCTOR
if /i "%~1"=="connect" goto CMD_CONNECT
if /i "%~1"=="bridge" goto CMD_CONNECT
if /i "%~1"=="daemon" goto CMD_CONNECT
if /i "%~1"=="run" goto CMD_RUN
if /i "%~1"=="exec" goto CMD_RUN
if /i "%~1"=="tree" goto CMD_TREE
if /i "%~1"=="read" goto CMD_READ
if /i "%~1"=="write" goto CMD_WRITE
if /i "%~1"=="serve" goto CMD_SERVE
if /i "%~1"=="sync" goto CMD_SYNC
if /i "%~1"=="version" goto CMD_VERSION
if /i "%~1"=="-v" goto CMD_VERSION

echo [ERROR] Unknown command: "%~1"
echo Type "aether-install.bat help" to view all available commands.
echo.
pause
exit /b 1

:: ==============================================================================
:: 1. BANNER DISPLAY
:: ==============================================================================
:PRINT_BANNER
echo.
echo ==============================================================================
echo                 AETHER NATIVE APP COMPILER AND INSTALLER
echo       Builds Custom AetherIDE.exe -- Zero Source-Code Exposure -- Standalone App
echo ==============================================================================
echo  Version: %AETHER_VERSION% -- Host: Windows -- Target: %AETHER_CLOUD_URL%
echo.
exit /b 0

:: ==============================================================================
:: 2. INTERACTIVE MENU
:: ==============================================================================
:INTERACTIVE_MENU
cls
call :PRINT_BANNER
echo Select an action:
echo.
echo  ==================== NATIVE DESKTOP APP ====================
echo  [1] Build and Install Custom Native App (AetherIDE.exe)
echo  [2] Launch AetherIDE.exe Desktop Application
echo  [3] Uninstall Native App and Clean Desktop Shortcuts
echo.
echo  ==================== LOCAL COMPANION BRIDGE ==================
echo  [4] Start Local Storage Bridge and Daemon (Connect Local Folder)
echo  [5] Run Environment and Compiler Diagnostics Doctor
echo  [6] Inspect Local Directory Tree
echo  [7] Execute Local Shell Command
echo  [8] Launch Instant Local Static Web Preview Server
echo  [9] View Command-Line Manual
echo  [0] Exit
echo.
set /p CHOICE="Enter choice (0-9): "

if "%CHOICE%"=="1" goto CMD_INSTALL
if "%CHOICE%"=="2" goto CMD_LAUNCH
if "%CHOICE%"=="3" goto CMD_UNINSTALL
if "%CHOICE%"=="4" goto CMD_CONNECT
if "%CHOICE%"=="5" goto CMD_DOCTOR
if "%CHOICE%"=="6" goto CMD_TREE
if "%CHOICE%"=="7" goto MENU_RUN
if "%CHOICE%"=="8" goto CMD_SERVE
if "%CHOICE%"=="9" goto CMD_HELP
if "%CHOICE%"=="0" exit /b 0

echo Invalid selection.
pause
goto INTERACTIVE_MENU

:MENU_RUN
echo.
set /p USER_CMD="Enter shell command to execute: "
if not "%USER_CMD%"=="" (
  call :EXECUTE_COMMAND "%USER_CMD%"
)
echo.
pause
goto INTERACTIVE_MENU

:: ==============================================================================
:: 3. NATIVE DESKTOP APP COMPILATION AND INSTALLATION
:: ==============================================================================
:CMD_INSTALL
call :PRINT_BANNER
echo [INSTALLER] Setting up standalone custom native desktop app (AetherIDE.exe)...
echo.

:: 1. Create installation directories
if not exist "%AETHER_INSTALL_DIR%" mkdir "%AETHER_INSTALL_DIR%"
if not exist "%AETHER_USER_DATA%" mkdir "%AETHER_USER_DATA%"

:: 2. Locate built-in Windows C# Compiler (csc.exe)
set "CSC_EXE="
if exist "%SystemRoot%\\Microsoft.NET\\Framework64\\v4.0.30319\\csc.exe" (
  set "CSC_EXE=%SystemRoot%\\Microsoft.NET\\Framework64\\v4.0.30319\\csc.exe"
) else if exist "%SystemRoot%\\Microsoft.NET\\Framework\\v4.0.30319\\csc.exe" (
  set "CSC_EXE=%SystemRoot%\\Microsoft.NET\\Framework\\v4.0.30319\\csc.exe"
) else (
  for /f "tokens=*" %%i in ('where csc.exe 2^>nul') do set "CSC_EXE=%%i"
)

:: 3. Detect Underlying Rendering Engine (Edge / Chrome)
set "RENDER_ENGINE="
if exist "%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe" (
  set "RENDER_ENGINE=%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe"
) else if exist "%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe" (
  set "RENDER_ENGINE=%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe"
) else if exist "%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe" (
  set "RENDER_ENGINE=%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe"
) else if exist "%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe" (
  set "RENDER_ENGINE=%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe"
) else if exist "%LOCALAPPDATA%\\Google\\Chrome\\Application\\chrome.exe" (
  set "RENDER_ENGINE=%LOCALAPPDATA%\\Google\\Chrome\\Application\\chrome.exe"
)

echo [+] Target Installation Directory : %AETHER_INSTALL_DIR%
echo [+] Isolated User Profile Store   : %AETHER_USER_DATA%
if not "%RENDER_ENGINE%"=="" (
  echo [+] Detected Engine Runtime       : %RENDER_ENGINE%
)

:: 4. Generate C# Source Code via PowerShell to guarantee flawless character escaping
echo [+] Generating custom native application source code...
set "CS_SOURCE=%AETHER_INSTALL_DIR%\\AetherApp.cs"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$code = @'
using System;
using System.IO;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace AetherNativeStudio {
  static class Program {
    [DllImport(\"user32.dll\")]
    private static extern bool SetProcessDPIAware();

    [STAThread]
    static void Main(string[] args) {
      try { SetProcessDPIAware(); } catch { }
      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);

      string cloudUrl = \"__CLOUD_URL__\";
      string profileDir = @\"__PROFILE_DIR__\";
      string engineExe = @\"__ENGINE_EXE__\";

      if (!string.IsNullOrEmpty(engineExe) && File.Exists(engineExe)) {
        ProcessStartInfo psi = new ProcessStartInfo();
        psi.FileName = engineExe;
        psi.Arguments = \"--app=\" + cloudUrl + \" --user-data-dir=\"\"\" + profileDir + \"\"\" --window-size=1440,900 --start-maximized --disable-features=Translate,OptimizationGuideModelDownloading --no-default-browser-check --no-first-run\";
        psi.UseShellExecute = true;
        try {
          Process.Start(psi);
          return;
        } catch { }
      }

      Application.Run(new AetherFallbackForm(cloudUrl));
    }
  }

  public class AetherFallbackForm : Form {
    private WebBrowser browser;
    public AetherFallbackForm(string url) {
      this.Text = \"Aether AI IDE - Autonomous Native Engineering Studio\";
      this.Width = 1440;
      this.Height = 900;
      this.StartPosition = FormStartPosition.CenterScreen;
      this.BackColor = Color.FromArgb(10, 10, 15);
      this.WindowState = FormWindowState.Maximized;

      browser = new WebBrowser();
      browser.Dock = DockStyle.Fill;
      browser.ScriptErrorsSuppressed = true;
      browser.IsWebBrowserContextMenuEnabled = false;
      browser.Navigate(url);
      this.Controls.Add(browser);
    }
  }
}
'@;
$code = $code.Replace('__CLOUD_URL__', '%AETHER_CLOUD_URL%').Replace('__PROFILE_DIR__', '%AETHER_USER_DATA%').Replace('__ENGINE_EXE__', '%RENDER_ENGINE%');
[System.IO.File]::WriteAllText('%CS_SOURCE%', $code, [System.Text.Encoding]::UTF8);
"

:: 5. Compile into AetherIDE.exe using native .NET csc.exe
if not "%CSC_EXE%"=="" (
  echo [+] Compiling native binary using Windows .NET Compiler (%CSC_EXE%)...
  "%CSC_EXE%" /nologo /target:winexe /optimize+ /out:"%AETHER_EXE%" "%CS_SOURCE%" /r:System.Windows.Forms.dll,System.Drawing.dll,System.dll
  if exist "%AETHER_EXE%" (
    echo [+] Successfully compiled native executable: %AETHER_EXE%
  ) else (
    echo [-] Note: Falling back to direct native launcher engine.
  )
) else (
  echo [-] Windows .NET compiler not found. Using direct native app launcher.
)

:: 6. Generate resilient direct native launcher script as backup
(
  echo @echo off
  if not "%RENDER_ENGINE%"=="" (
    echo start "" "%RENDER_ENGINE%" --app="%AETHER_CLOUD_URL%" --user-data-dir="%AETHER_USER_DATA%" --window-size=1440,900 --start-maximized --disable-features=Translate,OptimizationGuideModelDownloading --no-default-browser-check --no-first-run
  ) else (
    echo start "" "%AETHER_CLOUD_URL%"
  )
) > "%AETHER_INSTALL_DIR%\\launch.bat"

:: 7. Create Native Windows Desktop and Start Menu Shortcuts
echo [+] Creating Windows Desktop and Start Menu shortcuts...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$desktop = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::Desktop); " ^
  "if (-not [string]::IsNullOrWhiteSpace($desktop) -and -not (Test-Path $desktop)) { New-Item -ItemType Directory -Force -Path $desktop | Out-Null }; " ^
  "$programs = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::Programs); " ^
  "if (-not [string]::IsNullOrWhiteSpace($programs) -and -not (Test-Path $programs)) { New-Item -ItemType Directory -Force -Path $programs | Out-Null }; " ^
  "$exe = '%AETHER_EXE%'; " ^
  "$useEngine = $false; " ^
  "if (-not (Test-Path $exe)) { $exe = '%RENDER_ENGINE%'; $useEngine = $true; }; " ^
  "if ([string]::IsNullOrWhiteSpace($exe)) { $exe = '%AETHER_INSTALL_DIR%\\launch.bat'; $useEngine = $false; }; " ^
  "$WshShell = New-Object -ComObject WScript.Shell; " ^
  "if (-not [string]::IsNullOrWhiteSpace($desktop)) { " ^
  "  $deskLnk = Join-Path $desktop '%AETHER_APP_NAME%.lnk'; " ^
  "  $Shortcut = $WshShell.CreateShortcut($deskLnk); " ^
  "  $Shortcut.TargetPath = $exe; " ^
  "  if ($useEngine) { $Shortcut.Arguments = '--app=%AETHER_CLOUD_URL% --user-data-dir=\"%AETHER_USER_DATA%\" --window-size=1440,900 --start-maximized --disable-features=Translate,OptimizationGuideModelDownloading --no-default-browser-check --no-first-run' }; " ^
  "  $Shortcut.Description = 'Aether AI IDE - Autonomous Native Engineering Studio'; " ^
  "  $Shortcut.WorkingDirectory = '%AETHER_INSTALL_DIR%'; " ^
  "  $Shortcut.Save(); " ^
  "  Write-Host ('  [+] Desktop Shortcut saved: ' + $deskLnk); " ^
  "}; " ^
  "if (-not [string]::IsNullOrWhiteSpace($programs)) { " ^
  "  $progLnk = Join-Path $programs '%AETHER_APP_NAME%.lnk'; " ^
  "  $StartMenu = $WshShell.CreateShortcut($progLnk); " ^
  "  $StartMenu.TargetPath = $exe; " ^
  "  if ($useEngine) { $StartMenu.Arguments = '--app=%AETHER_CLOUD_URL% --user-data-dir=\"%AETHER_USER_DATA%\" --window-size=1440,900 --start-maximized --disable-features=Translate,OptimizationGuideModelDownloading --no-default-browser-check --no-first-run' }; " ^
  "  $StartMenu.Description = 'Aether AI IDE - Autonomous Native Engineering Studio'; " ^
  "  $StartMenu.WorkingDirectory = '%AETHER_INSTALL_DIR%'; " ^
  "  $StartMenu.Save(); " ^
  "  Write-Host ('  [+] Start Menu Shortcut saved: ' + $progLnk); " ^
  "}; "

echo.
echo ==============================================================================
echo [SUCCESS] Aether AI IDE Native Application Installed Successfully!
echo ==============================================================================
echo  - Native App Location : %AETHER_INSTALL_DIR%
echo  - User Profile Store   : %AETHER_USER_DATA%
echo  - Source Code Status   : 100%% Cloud-Secured (Zero local source code exposure)
echo ==============================================================================
echo.
echo Launching Aether Native App now...

if exist "%AETHER_EXE%" (
  start "" "%AETHER_EXE%"
) else if not "%RENDER_ENGINE%"=="" (
  start "" "%RENDER_ENGINE%" --app="%AETHER_CLOUD_URL%" --user-data-dir="%AETHER_USER_DATA%" --window-size=1440,900 --start-maximized --disable-features=Translate,OptimizationGuideModelDownloading --no-default-browser-check --no-first-run
) else (
  start "" "%AETHER_CLOUD_URL%"
)

echo.
echo ==============================================================================
echo App launched! You can now access Aether AI IDE anytime from your Desktop shortcut.
echo ==============================================================================
echo.
pause
exit /b 0

:: ==============================================================================
:: 4. LAUNCH NATIVE APP DIRECTLY
:: ==============================================================================
:CMD_LAUNCH
if exist "%AETHER_EXE%" (
  echo Starting %AETHER_EXE%...
  start "" "%AETHER_EXE%"
  echo Launched!
  pause
  exit /b 0
)

set "RENDER_ENGINE="
if exist "%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe" (
  set "RENDER_ENGINE=%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe"
) else if exist "%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe" (
  set "RENDER_ENGINE=%ProgramFiles%\\Microsoft\\Edge\\Application\\msedge.exe"
) else if exist "%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe" (
  set "RENDER_ENGINE=%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe"
) else if exist "%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe" (
  set "RENDER_ENGINE=%ProgramFiles(x86)%\\Google\\Chrome\\Application\\chrome.exe"
) else if exist "%LOCALAPPDATA%\\Google\\Chrome\\Application\\chrome.exe" (
  set "RENDER_ENGINE=%LOCALAPPDATA%\\Google\\Chrome\\Application\\chrome.exe"
)

if not "%RENDER_ENGINE%"=="" (
  echo Starting Aether Native Window...
  start "" "%RENDER_ENGINE%" --app="%AETHER_CLOUD_URL%" --user-data-dir="%AETHER_USER_DATA%" --window-size=1440,900 --start-maximized --disable-features=Translate,OptimizationGuideModelDownloading --no-default-browser-check --no-first-run
  echo Launched!
  pause
  exit /b 0
)

start "" "%AETHER_CLOUD_URL%"
echo Launched!
pause
exit /b 0

:: ==============================================================================
:: 5. UNINSTALL SHORTCUTS AND LOCAL CACHE
:: ==============================================================================
:CMD_UNINSTALL
call :PRINT_BANNER
echo [UNINSTALLER] Removing Aether Native App and shortcuts...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$desktop = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::Desktop); " ^
  "if (-not [string]::IsNullOrWhiteSpace($desktop)) { $f = Join-Path $desktop '%AETHER_APP_NAME%.lnk'; if (Test-Path $f) { Remove-Item -Force $f; Write-Host ('Removed: ' + $f) } }; " ^
  "$programs = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::Programs); " ^
  "if (-not [string]::IsNullOrWhiteSpace($programs)) { $f = Join-Path $programs '%AETHER_APP_NAME%.lnk'; if (Test-Path $f) { Remove-Item -Force $f; Write-Host ('Removed: ' + $f) } }; "

echo [+] Shortcuts removed from Desktop and Start Menu.
set /p DEL_DATA="Do you also want to remove local cached user profile data? (y/N): "
if /i "%DEL_DATA%"=="y" (
  if exist "%AETHER_INSTALL_DIR%" rmdir /s /q "%AETHER_INSTALL_DIR%"
  echo [+] Cleaned %AETHER_INSTALL_DIR%
)
echo [SUCCESS] Uninstallation completed.
echo.
pause
exit /b 0

:: ==============================================================================
:: 6. HELP MANUAL
:: ==============================================================================
:CMD_HELP
call :PRINT_BANNER
echo USAGE:
echo   aether-install.bat [command] [options]
echo.
echo NATIVE APP COMMANDS:
echo   install                     Compile and install AetherIDE.exe native desktop app
echo   launch                      Open native application window directly
echo   uninstall                   Remove desktop shortcuts and local cached profile
echo.
echo STORAGE AND BRIDGE COMMANDS:
echo   connect [port]              Start local bridge daemon to link local files with Aether IDE
echo   sync [local_dir]            Bi-directional sync between local folder and Aether IDE
echo   tree [path]                 Print visual directory tree of local file system
echo   read [file_path]            Read and display local file content
echo   write [file_path] [text]    Write text directly to a local file
echo.
echo LOCAL EXECUTION AND TOOLS:
echo   run "[shell_cmd]"           Execute a local terminal command (e.g., aether-install.bat run "npm test")
echo   serve [port]                Launch instant local preview web server (default port: 8080)
echo   doctor                      Diagnose local Windows environment, Git, Node, and storage
echo   version                     Display Aether Batch CLI version
echo.
echo SECURITY GUARANTEE:
echo   All core AI logic and IDE system modules run securely in the cloud container.
echo   Users receive the full native desktop app experience without local source code exposure.
echo.
pause
exit /b 0

:: ==============================================================================
:: 7. ENVIRONMENT DOCTOR
:: ==============================================================================
:CMD_DOCTOR
call :PRINT_BANNER
echo Checking Local Machine Environment...
echo.
echo   [*] OS Platform              : %OS% (%PROCESSOR_ARCHITECTURE%)
echo   [*] Working Directory        : %CD%
echo   [*] Cloud Ingress Target     : %AETHER_CLOUD_URL%

:: Check .NET C# Compiler (csc.exe)
if exist "%SystemRoot%\\Microsoft.NET\\Framework64\\v4.0.30319\\csc.exe" (
  echo   [+] Windows .NET C# Compiler : Installed (Framework64 v4.0.30319)
) else if exist "%SystemRoot%\\Microsoft.NET\\Framework\\v4.0.30319\\csc.exe" (
  echo   [+] Windows .NET C# Compiler : Installed (Framework v4.0.30319)
) else (
  echo   [-] Windows .NET C# Compiler : Standard native wrapper mode
)

:: Check Render Engine
if exist "%ProgramFiles(x86)%\\Microsoft\\Edge\\Application\\msedge.exe" (
  echo   [+] Native Rendering Engine  : Microsoft Edge Engine (Ready)
) else if exist "%ProgramFiles%\\Google\\Chrome\\Application\\chrome.exe" (
  echo   [+] Native Rendering Engine  : Google Chrome Engine (Ready)
) else (
  echo   [-] Native Rendering Engine  : Standard Windows Web Component
)

:: Check PowerShell
powershell -Command "$PSVersionTable.PSVersion" >nul 2>&1
if %errorlevel% equ 0 (
  echo   [+] PowerShell Engine        : Installed and Ready
) else (
  echo   [-] PowerShell Engine        : Not Found
)

:: Check Node.js
where node >nul 2>&1
if %errorlevel% equ 0 (
  for /f "tokens=*" %%i in ('node -v') do echo   [+] Node.js Runtime          : %%i
) else (
  echo   [-] Node.js Runtime          : Not installed (Native Batch engine used)
)

:: Check Git
where git >nul 2>&1
if %errorlevel% equ 0 (
  for /f "tokens=*" %%i in ('git --version') do echo   [+] Git Version Control      : %%i
) else (
  echo   [-] Git Version Control      : Not installed (Optional)
)

echo.
echo [SUCCESS] Environment is fully configured for Native Desktop App and Local Bridge.
echo.
pause
exit /b 0

:: ==============================================================================
:: 8. LOCAL STORAGE BRIDGE DAEMON
:: ==============================================================================
:CMD_CONNECT
call :PRINT_BANNER
if not "%~2"=="" set "AETHER_PORT=%~2"
echo [AETHER BRIDGE DAEMON] Starting local storage bridge on port %AETHER_PORT%...
echo.
echo Linking Local Directory: %CD%
echo.
echo Starting standalone lightweight HTTP listener via PowerShell...
echo Bridge active at: http://localhost:%AETHER_PORT%
echo.
echo Press Ctrl+C in this window at any time to stop the bridge.
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$port = %AETHER_PORT%; $listener = New-Object System.Net.HttpListener; $listener.Prefixes.Add('http://localhost:' + $port + '/'); $listener.Start(); Write-Host ('[BRIDGE ACTIVE] Local Storage Server running at http://localhost:' + $port + '/'); while ($listener.IsListening) { $context = $listener.GetContext(); $req = $context.Request; $res = $context.Response; $res.Headers.Add('Access-Control-Allow-Origin', '*'); $res.Headers.Add('Access-Control-Allow-Methods', 'GET, POST, OPTIONS'); $res.Headers.Add('Access-Control-Allow-Headers', '*'); if ($req.HttpMethod -eq 'OPTIONS') { $res.StatusCode = 204; $res.Close(); continue; } if ($req.Url.AbsolutePath -eq '/api/bridge/status') { $json = '{\"status\":\"connected\",\"platform\":\"win32\",\"cwd\":\"' + ($pwd.Path -replace '\\\\','/') + '\",\"version\":\"%AETHER_VERSION%\"}'; $buf = [System.Text.Encoding]::UTF8.GetBytes($json); $res.ContentType = 'application/json'; $res.OutputStream.Write($buf,0,$buf.Length); $res.Close(); continue; } if ($req.Url.AbsolutePath -eq '/api/bridge/files') { $files = Get-ChildItem -Recurse -File | Where-Object { $_.FullName -notmatch '(node_modules|\.git|dist)' } | Select-Object -First 100 | ForEach-Object { '{\"path\":\"' + ($_.FullName.Substring($pwd.Path.Length + 1) -replace '\\\\','/') + '\",\"size\":' + $_.Length + '}' }; $json = '{\"files\":[' + ($files -join ',') + ']}'; $buf = [System.Text.Encoding]::UTF8.GetBytes($json); $res.ContentType = 'application/json'; $res.OutputStream.Write($buf,0,$buf.Length); $res.Close(); continue; } if ($req.Url.AbsolutePath -eq '/api/bridge/exec') { $reader = New-Object System.IO.StreamReader($req.InputStream); $body = $reader.ReadToEnd(); $cmd = (ConvertFrom-Json $body).command; Write-Host ('[EXEC] ' + $cmd); $output = Invoke-Expression $cmd 2>&1 | Out-String; $json = '{\"stdout\":\"' + ($output -replace '\"','\\\"' -replace '\r\n','\n' -replace '\n','\\n') + '\",\"exitCode\":0}'; $buf = [System.Text.Encoding]::UTF8.GetBytes($json); $res.ContentType = 'application/json'; $res.OutputStream.Write($buf,0,$buf.Length); $res.Close(); continue; } $res.StatusCode = 404; $res.Close(); }"

exit /b 0

:: ==============================================================================
:: 9. DIRECTORY TREE
:: ==============================================================================
:CMD_TREE
call :PRINT_BANNER
set "TARGET_PATH=%~2"
if "%TARGET_PATH%"=="" set "TARGET_PATH=."
echo Visual Directory Tree [%TARGET_PATH%]:
echo.
tree "%TARGET_PATH%" /A /F
echo.
pause
exit /b 0

:: ==============================================================================
:: 10. EXECUTE SHELL COMMAND
:: ==============================================================================
:CMD_RUN
set "CMD_TO_RUN=%~2"
if "%CMD_TO_RUN%"=="" (
  echo [ERROR] No command specified. Example: aether-install.bat run "npm test"
  echo.
  pause
  exit /b 1
)
call :EXECUTE_COMMAND "%CMD_TO_RUN%"
echo.
pause
exit /b 0

:EXECUTE_COMMAND
echo.
echo [Executing Command: %~1]
echo.
cmd /c %~1
set "EXIT_CODE=%errorlevel%"
echo.
if %EXIT_CODE% equ 0 (
  echo [Command completed successfully with Exit Code: 0]
) else (
  echo [Command finished with Exit Code: %EXIT_CODE%]
)
exit /b %EXIT_CODE%

:: ==============================================================================
:: 11. READ / WRITE LOCAL FILES
:: ==============================================================================
:CMD_READ
if "%~2"=="" (
  echo [ERROR] Please provide a file path. Example: aether-install.bat read package.json
  echo.
  pause
  exit /b 1
)
if not exist "%~2" (
  echo [ERROR] File "%~2" not found.
  echo.
  pause
  exit /b 1
)
echo Content of "%~2":
echo.
type "%~2"
echo.
pause
exit /b 0

:CMD_WRITE
if "%~2"=="" (
  echo [ERROR] Please provide a file path and content.
  echo Example: aether-install.bat write notes.txt "Hello World"
  echo.
  pause
  exit /b 1
)
echo %~3 > "%~2"
echo [SUCCESS] Wrote content to "%~2".
echo.
pause
exit /b 0

:: ==============================================================================
:: 12. LOCAL PREVIEW SERVER
:: ==============================================================================
:CMD_SERVE
call :PRINT_BANNER
set "SERVE_PORT=%~2"
if "%SERVE_PORT%"=="" set "SERVE_PORT=8080"
echo Launching local static web preview server on port %SERVE_PORT%...
echo Serving folder: %CD%
echo.
echo Open in browser: http://localhost:%SERVE_PORT%
echo Press Ctrl+C to stop the web server.
echo.

where python >nul 2>&1
if %errorlevel% equ 0 (
  python -m http.server %SERVE_PORT%
  exit /b 0
)

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$port = %SERVE_PORT%; $listener = New-Object System.Net.HttpListener; $listener.Prefixes.Add('http://localhost:' + $port + '/'); $listener.Start(); Write-Host ('Server running at http://localhost:' + $port + '/'); while ($listener.IsListening) { $context = $listener.GetContext(); $path = Join-Path $pwd ($context.Request.Url.LocalPath.TrimStart('/')); if (-not (Test-Path $path) -or (Test-Path $path -PathType Container)) { $path = Join-Path $pwd 'index.html' }; if (Test-Path $path) { [byte[]]$bytes = [System.IO.File]::ReadAllBytes($path); $context.Response.OutputStream.Write($bytes, 0, $bytes.Length); } else { $context.Response.StatusCode = 404; } $context.Response.Close(); }"

exit /b 0

:: ==============================================================================
:: 13. LOCAL SYNC
:: ==============================================================================
:CMD_SYNC
call :PRINT_BANNER
echo [AETHER SYNC] Synchronizing directory: %CD%
echo Scanning local files...
powershell -Command "Get-ChildItem -Recurse -File | Where-Object { $_.FullName -notmatch '(node_modules|\.git|dist)' } | Select-Object FullName, Length, LastWriteTime"
echo.
echo [SUCCESS] Local directory state scanned. Connect bridge (aether-install.bat connect) for real-time cloud pairing.
echo.
pause
exit /b 0

:: ==============================================================================
:: 14. VERSION
:: ==============================================================================
:CMD_VERSION
echo Aether Native Desktop Application and Companion (.BAT) v%AETHER_VERSION%
echo.
pause
exit /b 0
`;
}

/**
 * Triggers a browser download of the standalone Aether Native App Installer & Companion Batch (.bat) file.
 */
export function downloadLocalCliFile(): void {
  const scriptContent = generateLocalCliBatScript(window.location.origin);
  const blob = new Blob([scriptContent], { type: 'application/x-bat;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'aether-install.bat';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Generates and downloads the standalone Windows PowerShell compilation script (.ps1)
 * that produces and publishes AetherIDE.exe directly on the local machine with 1-click execution.
 */
export function downloadNativeExeCompilerScript(): void {
  const cloudUrl = window.location.origin || "http://localhost:3000";
  const psScript = `# ==============================================================================
#                 AETHER NATIVE APP COMPILER & PUBLISHER (.PS1)
#           Compiles and Publishes AetherIDE.exe Directly on Local Windows PC
# ==============================================================================

$ErrorActionPreference = "Continue"
Write-Host "==============================================================================" -ForegroundColor Cyan
Write-Host "                AETHER AI IDE - NATIVE EXE COMPILER & PUBLISHER                " -ForegroundColor Cyan
Write-Host "==============================================================================" -ForegroundColor Cyan
Write-Host "Target Cloud Studio : ${cloudUrl}" -ForegroundColor Yellow
Write-Host ""

$installDir = Join-Path $env:LOCALAPPDATA "AetherIDE"
$profileDir = Join-Path $installDir "Profile"
$exePath = Join-Path $installDir "AetherIDE.exe"

if (-not (Test-Path $installDir)) { New-Item -ItemType Directory -Force -Path $installDir | Out-Null }
if (-not (Test-Path $profileDir)) { New-Item -ItemType Directory -Force -Path $profileDir | Out-Null }

# Locate Rendering Engine
$engine = ""
$edgePaths = @(
  "\${env:ProgramFiles(x86)}\\Microsoft\\Edge\\Application\\msedge.exe",
  "$env:ProgramFiles\\Microsoft\\Edge\\Application\\msedge.exe",
  "$env:ProgramFiles\\Google\\Chrome\\Application\\chrome.exe",
  "\${env:ProgramFiles(x86)}\\Google\\Chrome\\Application\\chrome.exe",
  "$env:LOCALAPPDATA\\Google\\Chrome\\Application\\chrome.exe"
)
foreach ($p in $edgePaths) {
  if (Test-Path $p) { $engine = $p; break }
}

Write-Host "[1/4] Generating C# Native Desktop Application Source Code..." -ForegroundColor Green
$csSource = Join-Path $installDir "AetherApp.cs"
$code = @"
using System;
using System.IO;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace AetherNativeStudio {
  static class Program {
    [DllImport("user32.dll")]
    private static extern bool SetProcessDPIAware();

    [STAThread]
    static void Main(string[] args) {
      try { SetProcessDPIAware(); } catch { }
      Application.EnableVisualStyles();
      Application.SetCompatibleTextRenderingDefault(false);

      string cloudUrl = "${cloudUrl}";
      string profileDir = @"$profileDir";
      string engineExe = @"$engine";

      if (!string.IsNullOrEmpty(engineExe) && File.Exists(engineExe)) {
        ProcessStartInfo psi = new ProcessStartInfo();
        psi.FileName = engineExe;
        psi.Arguments = "--app=" + cloudUrl + " --user-data-dir=\\"" + profileDir + "\\" --window-size=1440,900 --start-maximized --disable-features=Translate,OptimizationGuideModelDownloading --no-default-browser-check --no-first-run";
        psi.UseShellExecute = true;
        try {
          Process.Start(psi);
          return;
        } catch { }
      }

      Application.Run(new AetherFallbackForm(cloudUrl));
    }
  }

  public class AetherFallbackForm : Form {
    private WebBrowser browser;
    public AetherFallbackForm(string url) {
      this.Text = "Aether AI IDE - Autonomous Native Engineering Studio";
      this.Width = 1440;
      this.Height = 900;
      this.StartPosition = FormStartPosition.CenterScreen;
      this.BackColor = Color.FromArgb(10, 10, 15);
      this.WindowState = FormWindowState.Maximized;

      browser = new WebBrowser();
      browser.Dock = DockStyle.Fill;
      browser.ScriptErrorsSuppressed = true;
      browser.IsWebBrowserContextMenuEnabled = false;
      browser.Navigate(url);
      this.Controls.Add(browser);
    }
  }
}
"@

[System.IO.File]::WriteAllText($csSource, $code, [System.Text.Encoding]::UTF8)

Write-Host "[2/4] Locating Windows .NET Framework C# Compiler (csc.exe)..." -ForegroundColor Green
$csc = "$env:SystemRoot\\Microsoft.NET\\Framework64\\v4.0.30319\\csc.exe"
if (-not (Test-Path $csc)) {
  $csc = "$env:SystemRoot\\Microsoft.NET\\Framework\\v4.0.30319\\csc.exe"
}
if (-not (Test-Path $csc)) {
  $csc = (Get-Command csc.exe -ErrorAction SilentlyContinue).Source
}

if ($csc -and (Test-Path $csc)) {
  Write-Host "      Compiler found: $csc" -ForegroundColor DarkGray
  Write-Host "[3/4] Compiling AetherIDE.exe native Windows binary..." -ForegroundColor Green
  & "$csc" /nologo /target:winexe /optimize+ /out:"$exePath" "$csSource" /r:System.Windows.Forms.dll,System.Drawing.dll,System.dll
  if (Test-Path $exePath) {
    Write-Host "      ✔ AetherIDE.exe compiled successfully!" -ForegroundColor Green
  } else {
    Write-Host "      Note: Using direct engine wrapper" -ForegroundColor Yellow
  }
} else {
  Write-Host "      .NET compiler not present; configuring direct engine launcher" -ForegroundColor Yellow
}

Write-Host "[4/4] Creating Desktop & Start Menu Shortcuts..." -ForegroundColor Green
$desktop = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::Desktop)
$programs = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::Programs)

$target = $exePath
$useArgs = $false
if (-not (Test-Path $target)) {
  $target = $engine
  $useArgs = $true
}

$WshShell = New-Object -ComObject WScript.Shell
if (-not [string]::IsNullOrWhiteSpace($desktop)) {
  $deskLnk = Join-Path $desktop "Aether AI IDE.lnk"
  $Shortcut = $WshShell.CreateShortcut($deskLnk)
  $Shortcut.TargetPath = $target
  if ($useArgs) { $Shortcut.Arguments = "--app=${cloudUrl} --user-data-dir=\\"$profileDir\\" --window-size=1440,900 --start-maximized --disable-features=Translate,OptimizationGuideModelDownloading --no-default-browser-check --no-first-run" }
  $Shortcut.Description = "Aether AI IDE - Autonomous Native Engineering Studio"
  $Shortcut.WorkingDirectory = $installDir
  $Shortcut.Save()
  Write-Host "      ✔ Desktop Shortcut Created: $deskLnk" -ForegroundColor Green
}

if (-not [string]::IsNullOrWhiteSpace($programs)) {
  $progLnk = Join-Path $programs "Aether AI IDE.lnk"
  $StartMenu = $WshShell.CreateShortcut($progLnk)
  $StartMenu.TargetPath = $target
  if ($useArgs) { $StartMenu.Arguments = "--app=${cloudUrl} --user-data-dir=\\"$profileDir\\" --window-size=1440,900 --start-maximized --disable-features=Translate,OptimizationGuideModelDownloading --no-default-browser-check --no-first-run" }
  $StartMenu.Description = "Aether AI IDE - Autonomous Native Engineering Studio"
  $StartMenu.WorkingDirectory = $installDir
  $StartMenu.Save()
  Write-Host "      ✔ Start Menu Shortcut Created: $progLnk" -ForegroundColor Green
}

Write-Host ""
Write-Host "==============================================================================" -ForegroundColor Cyan
Write-Host " [SUCCESS] AetherIDE.exe Compiled & Published Successfully!" -ForegroundColor Green
Write-Host "==============================================================================" -ForegroundColor Cyan
Write-Host " - Binary Location : $exePath"
Write-Host " - Profile Storage : $profileDir"
Write-Host " - Zero Local Code : 100% Cloud-Secured"
Write-Host "==============================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Launching Aether Native App now..." -ForegroundColor Yellow

if (Test-Path $exePath) {
  Start-Process "$exePath"
} elseif (-not [string]::IsNullOrWhiteSpace($engine)) {
  Start-Process "$engine" -ArgumentList "--app=${cloudUrl} --user-data-dir=\\"$profileDir\\" --window-size=1440,900 --start-maximized --disable-features=Translate,OptimizationGuideModelDownloading --no-default-browser-check --no-first-run"
} else {
  Start-Process "${cloudUrl}"
}

Write-Host ""
Write-Host "Done! Press Enter to close this window..." -ForegroundColor Cyan
Read-Host
`;

  const blob = new Blob([psScript], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'compile-aether-exe.ps1';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}


