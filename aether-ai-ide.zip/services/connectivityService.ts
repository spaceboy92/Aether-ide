type ConnectionStatus = 'online' | 'offline';

export const connectivityService = {
  getStatus(): ConnectionStatus {
    return navigator.onLine ? 'online' : 'offline';
  },

  subscribe(callback: (status: ConnectionStatus) => void) {
    const handleOnline = () => callback('online');
    const handleOffline = () => callback('offline');

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }
};
