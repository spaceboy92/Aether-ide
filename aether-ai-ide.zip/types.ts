
export interface Task {
  id: string;
  title: string;
  description: string;
  status: 'todo' | 'in-progress' | 'done';
  projectId: string;
  createdAt: number;
  updatedAt: number;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  ownerId: string;
  createdAt: number;
  updatedAt: number;
  tasks: Task[];
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  photoURL: string;
  isGuest?: boolean;
  syncEnabled?: boolean;
  driveConnected?: boolean;
  lastSync?: number;
  storageUsed?: string;
  accessToken?: string;
  googleTokens?: any;
  autoSaveInterval?: number;
  isMature?: boolean;
  bio?: string;
  followers?: number;
  following?: number;
  posts?: number;
  items?: string[];
  theme?: string;
  font?: string;
  twoFactorEnabled?: boolean;
  passkeys?: string[];
  hardwareAcceleration?: boolean;
  privacyMode?: boolean;
  coins?: number;
  isPremium?: boolean;
  tvMode?: boolean;
  offlineMode?: boolean;
  performanceMode?: 'high' | 'low';
  autoPerfMode?: boolean;
  accountType?: 'Researcher' | 'Creative' | 'Developer' | 'Enterprise';
  customizerSettings?: {
      uiDensity?: 'compact' | 'cozy';
      animationSpeed?: number;
      particleEffects?: boolean;
      sidebarOpacity?: number;
      borderRadius?: number;
      accentColor?: string;
      fontScale?: number;
      inputSounds?: boolean;
      networkViz?: boolean;
      terminalTransparency?: number;
      uiBackground?: string;
      motionPreset?: 'Fluid' | 'Snap' | 'Reduced';
  };
  savedThemes?: { name: string, settings: any }[];
  checkpoints?: { id: string; timestamp: number; settings: any }[];
  editorSettings?: {
    minimap?: boolean;
    ligatures?: boolean;
    vimMode?: boolean;
    fontSize?: number;
    wordWrap?: boolean;
  };
  aiSettings?: {
    defaultModel?: string;
    reasoningLevel?: 'fast' | 'balanced' | 'deep';
    customInstructions?: string;
  };
}

export interface FileNode {
  id: string;
  name: string;
  path?: string;
  content: string;
  language: string;
  lastModified: number;
  isBinary?: boolean;
}

export interface GroundingLink {
  uri: string;
  title?: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  thoughts?: string; 
  timestamp: number;
  isAction?: boolean; 
  attachments?: {
    type: 'image' | 'video' | 'file';
    url: string;
    name: string;
  }[];
  groundingLinks?: GroundingLink[];
  executionSteps?: ExecutionStep[];
  reasoningSteps?: { step: string, status: string }[];
  pendingPlanSteps?: {
    id: string;
    type: 'file' | 'command';
    label: string;
    action: any;
    status: 'pending' | 'executing' | 'completed' | 'failed';
  }[];
  currentCodeFragment?: string;
  isExcluded?: boolean;
  isPinned?: boolean;
  commitHash?: string;
  commitSnapshot?: FileNode[];
  modelId?: string;
  modelName?: string;
  latencyMs?: number;
  feedback?: 'like' | 'dislike';
  streamMetrics?: {
    tokensPerSec?: number;
    totalTokens?: number;
    totalChars?: number;
    elapsedMs?: number;
    phase?: string;
    activeFile?: string;
  };
}

export interface ExecutionStep {
  id: string;
  label: string;
  status: 'pending' | 'running' | 'success' | 'error';
  details?: string;
  timestamp: number;
}

export interface ProjectSettings {
  customInstructions?: string;
  defaultModel?: string;
  isPublic?: boolean;
  theme?: string;
}

export interface SessionSnapshot {
  id: string;
  timestamp: number;
  thumbnailUrl?: string;
  activeFileName?: string;
  fileCount: number;
  totalLines: number;
  summary?: string;
  filesSnapshot?: FileNode[];
}

export interface ChatSession {
  id: string;
  title: string;
  description?: string;
  tags?: string[];
  aiGeneratedIdentity?: boolean;
  messages: ChatMessage[];
  lastUpdated: number;
  ownerId?: string;
  collaborators?: string[];
  memoryNodes?: string[]; // Persistent task context
  settings?: ProjectSettings;
  thumbnailUrl?: string;
  snapshots?: SessionSnapshot[];
}

export enum ViewMode {
  HOME = 'HOME',
  FILES = 'FILES',
  EDITOR = 'EDITOR',
  PREVIEW = 'PREVIEW',
  CHAT = 'CHAT',
  SETTINGS = 'SETTINGS',
  GAME_STUDIO_3D = 'GAME_STUDIO_3D',
  GAME_STUDIO_2D = 'GAME_STUDIO_2D',
  BROWSER = 'BROWSER',
  SOCIAL = 'SOCIAL',
  PROFILE = 'PROFILE',
  APP_BUILDER = 'APP_BUILDER',
  CLOUD = 'CLOUD'
}

export type ViewportType = 'desktop' | 'tablet' | 'mobile';

export interface AgentAction {
  action: 'create' | 'update' | 'delete' | 'terminal_command' | 'snapshot';
  path?: string;
  content?: string;
  command?: string;
}

export interface AgentResponse {
  message: string;
  actions: AgentAction[];
}

export interface TerminalLog {
  id: string;
  type: 'info' | 'error' | 'warn' | 'success' | 'system' | 'ai' | 'console' | 'test' | 'runtime';
  message: string;
  timestamp: number;
  source?: string;
}

export type RuntimeType = 'browser-node' | 'webassembly' | 'remote-linux' | 'local' | 'unsupported';

export interface RuntimeStatus {
  type: RuntimeType;
  version?: string;
  packageManager?: string;
  isReady: boolean;
  isBooting: boolean;
  error?: string;
  storageUsed?: number;
  openPorts?: number[];
  memoryUsage?: number;
}

export interface RuntimeProcess {
  id: string;
  command: string;
  status: 'running' | 'stopped' | 'failed';
  startTime: number;
  exitCode?: number;
}

export interface RuntimeEnvironment {
  status: RuntimeStatus;
  processes: RuntimeProcess[];
  envVars: Record<string, string>;
}

export type AutoAgentState = 'IDLE' | 'PROCESSING'; // Simplified

export interface Snapshot {
  id: string;
  timestamp: number;
  description: string;
  files: FileNode[];
  diffSummary?: string;
}

export interface MarketItem {
  id: string;
  title: string;
  description: string;
  icon: string;
  price: number;
  category: 'theme' | 'plugin' | 'font' | 'premium' | 'tool' | 'sound';
  isInstalled: boolean;
  isPremium: boolean;
}

export const PROJECT_TEMPLATES = {
  VANILLA: 'vanilla',
  GAME_3D: 'game-3d',
  GAME_2D: 'game-2d',
  REACT_MOCK: 'react-mock'
};
