const fs = require('fs');
let content = fs.readFileSync('index.html', 'utf8');

const regex = /<!-- App Logo Image -->[\s\S]*?<\/div>/;

if (regex.test(content)) {
  const replacement = `<!-- Sideways Blackhole SVG -->
        <div style="position:relative;z-index:10;animation:pulseGlow 3s ease-in-out infinite;transform:rotate(-12deg);">
          <svg viewBox="0 0 100 100" width="160" height="160" style="filter: drop-shadow(0 0 18px rgba(249,115,22,0.65));">
            <defs>
              <!-- Radial disk glow gradient -->
              <radialGradient id="bh-disk-grad" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stop-color="#ffffff" stop-opacity="1" />
                <stop offset="25%" stop-color="#ffea9f" stop-opacity="0.95" />
                <stop offset="55%" stop-color="#ff7700" stop-opacity="0.8" />
                <stop offset="85%" stop-color="#ff2200" stop-opacity="0.3" />
                <stop offset="100%" stop-color="#020205" stop-opacity="0" />
              </radialGradient>
              <!-- Doppler Beaming Linear Gradient (Brighter on the left) -->
              <linearGradient id="bh-doppler-linear" x1="0%" y1="50%" x2="100%" y2="50%">
                <stop offset="0%" stop-color="#ffffff" stop-opacity="1" />
                <stop offset="20%" stop-color="#ffe699" stop-opacity="0.95" />
                <stop offset="45%" stop-color="#ff7300" stop-opacity="0.8" />
                <stop offset="75%" stop-color="#ff2200" stop-opacity="0.4" />
                <stop offset="100%" stop-color="#ff2200" stop-opacity="0" />
              </linearGradient>
              <!-- Einstein Ring soft glow filter -->
              <filter id="bh-glow-orange" x="-30%" y="-30%" width="160%" height="160%">
                <feGaussianBlur stdDeviation="3" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>
            <!-- 1. Upper Lensed Arch (Einstein lens warping behind) -->
            <path 
               d="M 12 50 A 38 31 0 0 1 88 50 A 35 22 0 0 0 12 50" 
               fill="url(#bh-disk-grad)" 
               opacity="0.9" 
             />
            <path 
               d="M 24 48 A 26 22 0 0 1 76 48" 
               fill="none" 
               stroke="#ffffff" 
               stroke-width="1.25" 
               opacity="0.85" 
             />
            <path 
               d="M 18 50 A 32 26 0 0 1 82 50" 
               fill="none" 
               stroke="#ff9900" 
               stroke-width="3.5" 
               filter="url(#bh-glow-orange)" 
               opacity="0.6" 
             />
            <!-- 2. Lower Lensed Arch (Underneath background light) -->
            <path 
               d="M 16 50 A 34 26 0 0 0 84 50 A 30 17 0 0 1 16 50" 
               fill="url(#bh-disk-grad)" 
               opacity="0.75" 
             />
            <path 
               d="M 28 52 A 22 18 0 0 0 72 52" 
               fill="none" 
               stroke="#ff5500" 
               stroke-width="1.0" 
               opacity="0.7" 
             />
            <!-- 3. Einstein Ring / Photon Sphere -->
            <circle cx="50" cy="50" r="16" fill="none" stroke="#ffa366" stroke-width="4.0" filter="url(#bh-glow-orange)" opacity="0.5" />
            <circle cx="50" cy="50" r="14.5" fill="none" stroke="#ffffff" stroke-width="1.5" opacity="0.9" />
            <!-- 4. Event Horizon Core (Solid absolute black trap) -->
            <circle cx="50" cy="50" r="13" fill="#010103" />
            <!-- 5. Foreground Accretion Disk (Passing in front) -->
            <path 
               d="M 8 50 C 18 61, 82 61, 92 50 C 76 50.5, 24 50.5, 8 50" 
               fill="url(#bh-disk-grad)" 
               opacity="0.95" 
             />
            <path 
               d="M 8 50 C 20 57.5, 80 57.5, 92 50" 
               fill="none" 
               stroke="url(#bh-doppler-linear)" 
               stroke-width="3.2" 
               stroke-linecap="round"
            />
            <path 
               d="M 14 50 C 25 54.5, 75 54.5, 86 50" 
               fill="none" 
               stroke="#ffffff" 
               stroke-width="1.0" 
               stroke-linecap="round"
              opacity="0.9"
            />
            <!-- Doppler beaming hot-spot highlight on left side -->
            <circle cx="26" cy="52" r="5" fill="#ffeeb0" filter="url(#bh-glow-orange)" opacity="0.35" />
          </svg>
        </div>`;
  content = content.replace(regex, replacement);
  fs.writeFileSync('index.html', content);
  console.log("Patched index.html");
} else {
  console.error("Regex not matched");
}
