import { FileNode } from '../types';

/**
 * Aether Studio - Limitless Agent Toolset for File & Directory Management
 * Allows AI agents to dynamically create, update, delete, and structure arbitrary files and folders.
 */

export interface ToolExecutionResult {
  success: boolean;
  message: string;
  createdFiles?: string[];
  error?: string;
}

export class LimitlessAgentTools {
  /**
   * Dynamically ensures that any folder path exists in the workspace file tree.
   */
  static ensureFolderPath(files: FileNode[], folderPath: string): FileNode[] {
    const cleanPath = folderPath.replace(/^\/+|\/+$/g, '');
    if (!cleanPath) return files;

    const parts = cleanPath.split('/');
    let currentPath = '';
    let updatedFiles = [...files];

    for (const part of parts) {
      currentPath = currentPath ? `${currentPath}/${part}` : part;
      const exists = updatedFiles.some(f => f.name === currentPath || f.path === currentPath);
      if (!exists) {
        updatedFiles.push({
          id: `folder_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
          name: currentPath,
          path: currentPath,
          content: '',
          isFolder: true,
          isOpen: true,
          children: []
        });
      }
    }

    return updatedFiles;
  }

  /**
   * Creates or updates a file in the limitless virtual file system.
   */
  static upsertFile(files: FileNode[], path: string, content: string): FileNode[] {
    const cleanPath = path.replace(/^\/+/, '');
    const lastSlash = cleanPath.lastIndexOf('/');
    let updatedFiles = [...files];

    if (lastSlash !== -1) {
      const folderPath = cleanPath.substring(0, lastSlash);
      updatedFiles = this.ensureFolderPath(updatedFiles, folderPath);
    }

    const existingIndex = updatedFiles.findIndex(f => f.path === cleanPath || f.name === cleanPath);
    if (existingIndex !== -1) {
      updatedFiles[existingIndex] = {
        ...updatedFiles[existingIndex],
        content: content,
        updatedAt: Date.now()
      };
    } else {
      updatedFiles.push({
        id: `file_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        name: cleanPath,
        path: cleanPath,
        content: content,
        isFolder: false,
        updatedAt: Date.now()
      });
    }

    return updatedFiles;
  }
}
