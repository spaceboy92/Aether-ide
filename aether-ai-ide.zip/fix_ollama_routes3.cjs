const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf8');

const oldModelsPost = `  app.post("/api/ollama/models", async (req, res) => {
    const { endpoint = "http://127.0.0.1:11434", apiKey } = req.body;
    try {
      const cleanServerUrl = endpoint.replace(/\\/+$/, "");
      const headers: any = {};
      if (apiKey) headers["Authorization"] = \`Bearer \${apiKey}\`;

      try {
        const url = \`\${cleanServerUrl}/api/tags\`;
        const response = await axios.get(url, { headers, timeout: 5000 });
        if (response.data && response.data.models) {
          return res.json(response.data);
        }
      } catch (err) {
        try {
          const v1Url = cleanServerUrl.endsWith('/v1') ? \`\${cleanServerUrl}/models\` : \`\${cleanServerUrl}/v1/models\`;
          const responseV1 = await axios.get(v1Url, { headers, timeout: 5000 });
          if (responseV1.data && responseV1.data.data) {
             const models = responseV1.data.data.map((m: any) => ({
                name: m.id,
                size: 0
             }));
             return res.json({ models });
          }
        } catch (v1Err: any) {
          throw v1Err;
        }
        throw err;
      }
      res.json({ models: [] });
    } catch (error: any) {
      const isHtml = error.response?.data && typeof error.response.data === 'string' && error.response.data.toLowerCase().includes('<!doctype');
      res.status(502).json({ 
        error: \`Could not connect to AI Provider at \${endpoint}.\`,
        details: isHtml ? "Received HTML error page (Check your endpoint URL)" : error.message 
      });
    }
  });`;

const newModelsPost = `  app.post("/api/ollama/models", async (req, res) => {
    const { endpoint = "http://127.0.0.1:11434", apiKey } = req.body;
    try {
      const cleanServerUrl = endpoint.replace(/\\/+$/, "");
      const headers: any = {};
      if (apiKey) {
        // Together AI and OpenAI often require the bearer token
        headers["Authorization"] = \`Bearer \${apiKey}\`;
      }

      // 1. Try standard Ollama endpoint
      try {
        const url = \`\${cleanServerUrl}/api/tags\`;
        const response = await axios.get(url, { headers, timeout: 5000 });
        if (response.data && response.data.models) {
          return res.json(response.data);
        }
      } catch (err: any) {
        // If it's a 401 or 404, we'll try the v1 models fallback.
        // Otherwise, if it's a network error, it might be entirely dead.
      }

      // 2. Try v1 models endpoint (OpenAI standard)
      try {
        const v1Url = cleanServerUrl.endsWith('/v1') ? \`\${cleanServerUrl}/models\` : \`\${cleanServerUrl}/v1/models\`;
        const responseV1 = await axios.get(v1Url, { headers, timeout: 5000 });
        if (responseV1.data && responseV1.data.data) {
           const models = responseV1.data.data.map((m: any) => ({
              name: m.id,
              size: 0
           }));
           return res.json({ models });
        }
      } catch (v1Err: any) {
        throw v1Err; // Throw this one so it gets caught below
      }

      res.json({ models: [] });
    } catch (error: any) {
      const isHtml = error.response?.data && typeof error.response.data === 'string' && error.response.data.toLowerCase().includes('<!doctype');
      const errStatus = error.response?.status;
      const detailsMsg = isHtml 
        ? "Received HTML error page (Check your endpoint URL)" 
        : (error.response?.data?.error?.message || error.message);

      res.status(errStatus || 502).json({ 
        error: \`Could not connect to AI Provider at \${endpoint}.\`,
        details: detailsMsg
      });
    }
  });`;

if(code.includes(oldModelsPost)) {
  code = code.replace(oldModelsPost, newModelsPost);
  console.log("Patched models route v2");
} else {
  console.log("Could not find target string for models route");
}

fs.writeFileSync('server.ts', code);
