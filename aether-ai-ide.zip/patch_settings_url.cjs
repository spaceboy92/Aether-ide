const fs = require('fs');
let code = fs.readFileSync('components/Settings/SettingsView.tsx', 'utf8');

const target1 = `<label className="text-[10px] font-bold uppercase text-zinc-400 tracking-wider">Ollama Server Endpoint URL</label>
                    <input
                      type="text"
                      value={ollamaServerUrl}
                      onChange={e => {
                        setOllamaServerUrlState(e.target.value);
                        localStorage.setItem('ollama_server_url', e.target.value);
                      }}
                      placeholder="http://192.168.1.50:11434 or https://xxxx.ngrok-free.app"
                      className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-orange-500"
                    />`;

const replacement1 = `<div className="flex justify-between items-center mb-1">
                      <label className="text-[10px] font-bold uppercase text-zinc-400 tracking-wider">AI Provider Endpoint URL</label>
                      <select 
                        className="bg-black text-[10px] text-zinc-300 border border-white/10 rounded px-1.5 py-0.5 cursor-pointer focus:outline-none focus:border-orange-500 outline-none"
                        onChange={e => {
                          if (e.target.value && e.target.value !== 'custom') {
                            setOllamaServerUrlState(e.target.value);
                            localStorage.setItem('ollama_server_url', e.target.value);
                          } else if (e.target.value === 'custom') {
                            setOllamaServerUrlState('');
                            localStorage.setItem('ollama_server_url', '');
                          }
                        }}
                        value={
                          ['https://api.openai.com/v1', 'https://api.groq.com/openai/v1', 'https://openrouter.ai/api/v1', 'https://api.together.xyz/v1', 'https://api.deepseek.com/v1', 'http://localhost:11434'].includes(ollamaServerUrl) ? ollamaServerUrl : 'custom'
                        }
                      >
                        <option value="custom">Custom / Other</option>
                        <option value="https://openrouter.ai/api/v1">OpenRouter</option>
                        <option value="https://api.groq.com/openai/v1">Groq</option>
                        <option value="https://api.openai.com/v1">OpenAI</option>
                        <option value="https://api.together.xyz/v1">Together AI</option>
                        <option value="https://api.deepseek.com/v1">DeepSeek</option>
                        <option value="http://localhost:11434">Local Ollama</option>
                      </select>
                    </div>
                    <input
                      type="text"
                      value={ollamaServerUrl}
                      onChange={e => {
                        setOllamaServerUrlState(e.target.value);
                        localStorage.setItem('ollama_server_url', e.target.value);
                      }}
                      placeholder="e.g. https://openrouter.ai/api/v1"
                      className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-orange-500"
                    />`;

const target2 = `<label className="text-[10px] font-bold uppercase text-zinc-400 tracking-wider">Ollama Server Endpoint URL</label>
                      <input
                        type="text"
                        value={ollamaServerUrl}
                        onChange={e => {
                          setOllamaServerUrlState(e.target.value);
                          localStorage.setItem('ollama_server_url', e.target.value);
                        }}
                        placeholder="https://your-cloud-ollama.com"
                        className="w-full bg-black/60 border border-white/10 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-orange-500"
                      />`;

const replacement2 = replacement1;

let patched = false;
if (code.includes(target1)) {
  code = code.replace(target1, replacement1);
  patched = true;
  console.log("Patched URL mode input");
}
if (code.includes(target2)) {
  code = code.replace(target2, replacement2);
  patched = true;
  console.log("Patched Key mode input");
}

if(patched) {
  fs.writeFileSync('components/Settings/SettingsView.tsx', code);
} else {
  console.log("Could not find targets");
}
