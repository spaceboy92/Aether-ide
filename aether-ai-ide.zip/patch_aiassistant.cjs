const fs = require('fs');

let content = fs.readFileSync('components/AI/AIAssistant.tsx', 'utf8');

const dynamicShortcutsCode = `
  const dynamicShortcuts = useMemo(() => {
    const shortcuts = [];
    
    // Check if React files exist
    const hasReact = files.some(f => f.name.endsWith('.tsx') || f.name.endsWith('.jsx'));
    // Check if three.js or canvas is used (scene.json, etc.)
    const has3D = files.some(f => f.name.includes('scene') || f.name.includes('three') || f.content?.includes('THREE'));
    // Check if audio is used
    const hasAudio = files.some(f => f.name.includes('audio') || f.name.includes('sound') || f.content?.includes('AudioContext'));
    // Check if python or backend is used
    const hasPython = files.some(f => f.name.endsWith('.py'));
    const hasNode = files.some(f => f.name === 'server.ts' || f.name === 'server.js');
    const hasCSS = files.some(f => f.name.endsWith('.css'));
    const hasHTML = files.some(f => f.name.endsWith('.html'));
    const hasGameEngine = files.some(f => f.name.includes('Game') || f.name.includes('Arena') || f.name.includes('Engine'));

    if (hasReact) {
      shortcuts.push({ label: "🎨 Refine UI", color: "from-blue-500/10 to-indigo-500/10 text-blue-400 border-blue-500/20", prompt: "Improve the UI design and layout in the React components." });
      shortcuts.push({ label: "⚡ Optimize React", color: "from-emerald-500/10 to-teal-500/10 text-emerald-400 border-emerald-500/20", prompt: "Optimize the React components for better performance." });
    }
    
    if (has3D || hasGameEngine) {
      shortcuts.push({ label: "👾 Gladiator Arena", color: "from-indigo-500/10 to-blue-500/10 text-indigo-400 border-indigo-500/20", prompt: "Construct a massive gladiator arena with spectator platforms, ancient cyber pillars, and multiple enemy spawns." });
      shortcuts.push({ label: "👑 Summon Boss", color: "from-red-500/10 to-orange-500/10 text-red-400 border-red-500/20", prompt: "Spawn a giant scaled boss entity with high health and custom projectile emission rules." });
    }

    if (hasAudio) {
      shortcuts.push({ label: "🔊 Synthesize SFX", color: "from-emerald-500/10 to-teal-500/10 text-emerald-400 border-emerald-500/20", prompt: "Implement interactive audio sound effects using standard client Web Audio API oscillators." });
    }

    if (hasPython) {
      shortcuts.push({ label: "🐍 Python Refactor", color: "from-yellow-500/10 to-orange-500/10 text-yellow-400 border-yellow-500/20", prompt: "Refactor the python code to be more idiomatic and efficient." });
    }

    if (hasNode) {
      shortcuts.push({ label: "🔌 Add API Endpoint", color: "from-green-500/10 to-emerald-500/10 text-green-400 border-green-500/20", prompt: "Add a new API endpoint to the backend server." });
    }

    if (hasCSS && !hasReact) {
      shortcuts.push({ label: "💅 Modernize CSS", color: "from-pink-500/10 to-rose-500/10 text-pink-400 border-pink-500/20", prompt: "Update the CSS to use modern styling with flexbox/grid and better color schemes." });
    }

    if (hasHTML && !hasReact) {
      shortcuts.push({ label: "📝 Add HTML Section", color: "from-orange-500/10 to-amber-500/10 text-orange-400 border-orange-500/20", prompt: "Add a new interactive section to the HTML structure." });
    }

    // Default fallbacks if we don't have enough
    if (shortcuts.length < 5) {
      if (!shortcuts.find(s => s.label === "🐛 Fix Bugs")) shortcuts.push({ label: "🐛 Fix Bugs", color: "from-red-500/10 to-orange-500/10 text-red-400 border-red-500/20", prompt: "Analyze the code for potential bugs and fix them." });
      if (!shortcuts.find(s => s.label === "📝 Document Code")) shortcuts.push({ label: "📝 Document Code", color: "from-gray-500/10 to-slate-500/10 text-gray-400 border-gray-500/20", prompt: "Add comments and documentation to the main functions." });
      if (!shortcuts.find(s => s.label === "🚀 Optimize")) shortcuts.push({ label: "🚀 Optimize", color: "from-purple-500/10 to-violet-500/10 text-purple-400 border-purple-500/20", prompt: "Optimize the current codebase for speed and efficiency." });
      if (!shortcuts.find(s => s.label === "✨ Code Audit")) shortcuts.push({ label: "✨ Code Audit", color: "from-cyan-500/10 to-blue-500/10 text-cyan-400 border-cyan-500/20", prompt: "Perform a deep security and stability audit on the current code." });
    }

    return shortcuts.slice(0, 5);
  }, [files]);
`;

content = content.replace(
  'const [isThinkingMode, setIsThinkingMode] = useState(true);',
  'const [isThinkingMode, setIsThinkingMode] = useState(true);\n' + dynamicShortcutsCode
);

const oldMapRegex = /\{\[\s*\{\s*label:\s*"🤖 Combat Autopilot"[\s\S]*?\]\.map\(\(shortcut,\s*idx\)/;
content = content.replace(
  oldMapRegex,
  '{dynamicShortcuts.map((shortcut, idx)'
);

fs.writeFileSync('components/AI/AIAssistant.tsx', content, 'utf8');
