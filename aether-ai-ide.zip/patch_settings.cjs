const fs = require('fs');
let code = fs.readFileSync('components/Settings/SettingsView.tsx', 'utf8');

// Change tab titles and labels
code = code.replace(/Cloud AI & Local Models Setup/g, "Cloud AI Providers");
code = code.replace(/OLLAMA CLOUD \/ LOCAL SYNC/g, "CLOUD AI PROVIDERS");
code = code.replace(/Ollama API Bearer Token \/ Key/g, "Provider API Key");
code = code.replace(/Ollama Server Endpoint URL/g, "Provider Endpoint URL");

// Remove local ollama from selects and change default
code = code.replace(/<option value="http:\/\/localhost:11434">Local Ollama<\/option>/g, "");
code = code.replace(/http:\/\/localhost:11434/g, "https://openrouter.ai/api/v1");
code = code.replace(/Ollama Cloud \/ Local Model/g, "Cloud Provider Model");

// Fix dropdowns includes array
code = code.replace(/\['https:\/\/api\.openai\.com\/v1', 'https:\/\/api\.groq\.com\/openai\/v1', 'https:\/\/openrouter\.ai\/api\/v1', 'https:\/\/api\.together\.xyz\/v1', 'https:\/\/api\.deepseek\.com\/v1', 'https:\/\/openrouter\.ai\/api\/v1'\]/g, "['https://api.openai.com/v1', 'https://api.groq.com/openai/v1', 'https://openrouter.ai/api/v1', 'https://api.together.xyz/v1', 'https://api.deepseek.com/v1']");

fs.writeFileSync('components/Settings/SettingsView.tsx', code);

let modalCode = fs.readFileSync('components/Tools/OllamaIntegrationModal.tsx', 'utf8');
modalCode = modalCode.replace(/<option value="http:\/\/127\.0\.0\.1:11434">Local Ollama<\/option>/g, "");
modalCode = modalCode.replace(/http:\/\/127\.0\.0\.1:11434/g, "https://openrouter.ai/api/v1");
modalCode = modalCode.replace(/http:\/\/localhost:11434/g, "https://openrouter.ai/api/v1");
modalCode = modalCode.replace(/Ollama Cloud \/ Local Model/g, "Cloud Provider Model");
modalCode = modalCode.replace(/Ollama Endpoint URL/g, "Provider Endpoint URL");
modalCode = modalCode.replace(/Ollama Connected!/g, "Provider Connected!");
modalCode = modalCode.replace(/Local Models Found/g, "Models Found");
modalCode = modalCode.replace(/Ollama Mobile & Desktop Setup/g, "Cloud AI Provider Setup");
modalCode = modalCode.replace(/scanLocalOllama/g, "scanCloudProvider");
modalCode = modalCode.replace(/\['https:\/\/api\.openai\.com\/v1', 'https:\/\/api\.groq\.com\/openai\/v1', 'https:\/\/openrouter\.ai\/api\/v1', 'https:\/\/api\.together\.xyz\/v1', 'https:\/\/api\.deepseek\.com\/v1', 'https:\/\/openrouter\.ai\/api\/v1', 'https:\/\/openrouter\.ai\/api\/v1'\]/g, "['https://api.openai.com/v1', 'https://api.groq.com/openai/v1', 'https://openrouter.ai/api/v1', 'https://api.together.xyz/v1', 'https://api.deepseek.com/v1']");

fs.writeFileSync('components/Tools/OllamaIntegrationModal.tsx', modalCode);

console.log("Patched settings and modal to remove Ollama and Local references.");
