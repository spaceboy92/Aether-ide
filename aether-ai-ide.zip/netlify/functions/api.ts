import serverless from 'serverless-http';
import express from 'express';
import cors from 'cors';
import { GoogleGenAI } from '@google/genai';

const app = express();

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// Netlify Function API Health Endpoint
app.get(['/api/health', '/.netlify/functions/api/health'], (req, res) => {
  res.json({ 
    status: 'ok', 
    environment: 'Netlify Unified Serverless Engine',
    timestamp: new Date().toISOString()
  });
});

// Universal Web & API Proxy Endpoint for Netlify Functions
app.all(['/api/proxy', '/api/proxy/open', '/api/cors-proxy', '/.netlify/functions/api/proxy', '/.netlify/functions/api/cors-proxy'], async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS, HEAD');
  res.setHeader('Access-Control-Allow-Headers', '*');

  if (req.method === 'OPTIONS') return res.status(204).end();

  let rawUrl = (req.query.url || req.headers['x-target-url'] || req.headers['x-forward-url'] || req.body?.url) as string;

  if (!rawUrl && req.url.includes('url=')) {
    try {
      const parsed = new URL(req.url, 'http://localhost');
      rawUrl = parsed.searchParams.get('url') || '';
    } catch (_) {}
  }

  if (!rawUrl || typeof rawUrl !== 'string') {
    if (req.query.q) {
      rawUrl = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(String(req.query.q))}`;
    } else {
      return res.status(400).json({ error: 'Target URL is required (?url=... or x-target-url header)' });
    }
  }

  let finalUrl = rawUrl.trim();

  // Handle Google search CAPTCHA avoidance: Route Google search queries through DuckDuckGo HTML search
  if (finalUrl.includes('google.com/search') || (!finalUrl.startsWith('http://') && !finalUrl.startsWith('https://'))) {
    const searchMatch = finalUrl.match(/q=([^&]+)/);
    const searchQuery = searchMatch ? decodeURIComponent(searchMatch[1]) : finalUrl;
    finalUrl = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(searchQuery)}`;
  }

  try {
    const fetchHeaders: Record<string, string> = {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.9',
    };

    const response = await fetch(finalUrl, { headers: fetchHeaders, redirect: 'follow' });
    let body = await response.text();

    // Check if body was blocked by Google bot check
    if (body.includes('unusual traffic') || body.includes('checks to see if it\'s really you sending')) {
      const searchMatch = finalUrl.match(/q=([^&]+)/);
      const searchQuery = searchMatch ? decodeURIComponent(searchMatch[1]) : 'web search';
      const ddgRes = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(searchQuery)}`, { headers: fetchHeaders });
      body = await ddgRes.text();
    }

    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    return res.status(200).send(body);
  } catch (err: any) {
    return res.status(500).json({ error: err?.message || 'Proxy request failed' });
  }
});

// Netlify Function Gemini Stream Proxy
app.post(['/api/gemini/stream', '/.netlify/functions/api/gemini/stream'], async (req, res) => {
  try {
    const { model, prompt, apiKey: clientKey } = req.body;
    const apiKey = clientKey || process.env.GEMINI_API_KEY;
    
    if (!apiKey) {
      return res.status(400).json({ error: 'GEMINI_API_KEY is missing in Netlify environment variables' });
    }

    const ai = new GoogleGenAI({ apiKey });
    const activeModel = model || 'gemini-3.7-flash';
    const result = await ai.models.generateContent({
      model: activeModel,
      contents: prompt,
    });

    return res.json({ text: result.text });
  } catch (err: any) {
    console.error('Netlify Gemini Function Error:', err);
    return res.status(500).json({ error: err?.message || 'Netlify Serverless Execution Error' });
  }
});

// Ollama / Custom API Proxy
app.post(['/api/ollama/models', '/.netlify/functions/api/ollama/models'], async (req, res) => {
  const { endpoint, apiKey } = req.body;
  const targetUrl = endpoint || 'https://openrouter.ai/api/v1';
  try {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (apiKey) headers['Authorization'] = `Bearer ${apiKey}`;
    const response = await fetch(`${targetUrl.replace(/\/$/, '')}/models`, { headers });
    const data = await response.json();
    return res.json(data);
  } catch (e: any) {
    return res.status(500).json({ error: e?.message || 'Failed to proxy request via Netlify Function' });
  }
});

// Catch-all API endpoint
app.all(['/api/*', '/.netlify/functions/api/*'], (req, res) => {
  res.json({ status: 'ok', route: req.path, message: 'Unified Netlify Serverless API endpoint active' });
});

export const handler = serverless(app);
