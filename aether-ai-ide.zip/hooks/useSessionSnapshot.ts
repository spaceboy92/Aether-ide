import { useEffect, useRef } from 'react';
import { ChatSession, FileNode } from '../types';
import { snapshotService } from '../services/snapshotService';

interface UseSessionSnapshotProps {
  activeSession: ChatSession | null;
  files: FileNode[];
  activeFileId: string | null;
  onUpdateSession: (session: ChatSession) => void;
  previewRef?: React.RefObject<HTMLElement | null>;
  isProcessing?: boolean;
}

export const useSessionSnapshot = ({
  activeSession,
  files,
  activeFileId,
  onUpdateSession,
  previewRef,
  isProcessing = false,
}: UseSessionSnapshotProps) => {
  const activeSessionRef = useRef(activeSession);
  activeSessionRef.current = activeSession;
  const filesRef = useRef(files);
  filesRef.current = files;
  const activeFileIdRef = useRef(activeFileId);
  activeFileIdRef.current = activeFileId;

  // Periodic Snapshot Loop (runs every 45s if workspace is modified)
  useEffect(() => {
    if (!activeSession?.id || files.length === 0 || isProcessing) return;

    const captureCurrentState = async () => {
      const currentSession = activeSessionRef.current;
      if (!currentSession || !currentSession.id) return;

      const targetEl = previewRef?.current || document.getElementById('aether-live-preview-frame');
      const snap = await snapshotService.captureSessionSnapshot(
        currentSession,
        filesRef.current,
        activeFileIdRef.current,
        targetEl
      );

      if (snap) {
        onUpdateSession({
          ...currentSession,
          thumbnailUrl: snap.thumbnailUrl,
          snapshots: [snap, ...(currentSession.snapshots || [])].slice(0, 15),
          lastUpdated: Date.now()
        });
      }
    };

    const timer = setInterval(() => {
      captureCurrentState();
    }, 45000);

    // Also trigger initial snapshot after 3s delay
    const initialTimer = setTimeout(() => {
      captureCurrentState();
    }, 3000);

    return () => {
      clearInterval(timer);
      clearTimeout(initialTimer);
    };
  }, [activeSession?.id, files.length, isProcessing, onUpdateSession, previewRef]);

  // Handle global snapshot trigger events (e.g. after AI agent file updates or code changes)
  useEffect(() => {
    const handleSnapshotEvent = (e: any) => {
      if (e.detail?.session) {
        onUpdateSession(e.detail.session);
      }
    };

    window.addEventListener('aether_session_snapshot_created', handleSnapshotEvent as EventListener);
    return () => {
      window.removeEventListener('aether_session_snapshot_created', handleSnapshotEvent as EventListener);
    };
  }, [onUpdateSession]);
};
