import { useState, useCallback, useEffect } from 'react';
import { ChatSession } from '../types';

export const useCloudSync = (
  user: any, 
  connectivityStatus: string, 
  addLog: (type: any, msg: string) => void
) => {
  const [googleDriveConnected, setGoogleDriveConnected] = useState(
    !!localStorage.getItem("google_drive_access_token")
  );
  
  useEffect(() => {
    const checkDrive = () => {
      setGoogleDriveConnected(
        !!localStorage.getItem("google_drive_access_token"),
      );
    };
    const interval = setInterval(checkDrive, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleSyncToDrive = useCallback(async (sessions: ChatSession[], setIsSyncing: (val: boolean) => void) => {
    addLog("system", "Cloud Sync: Manual Cloud Backup initialized.");
    setIsSyncing(true);
    try {
        const token = localStorage.getItem("google_drive_access_token");
        if (token) {
            const { saveSessionToDrive } = await import("../services/googleDriveService");
            for (const session of sessions) {
                await saveSessionToDrive({ access_token: token }, session);
            }
            addLog("success", "Workspace synchronized with Google Drive.");
        } else {
            addLog("warn", "Google Drive not connected.");
        }
    } catch (e: any) {
        addLog("error", "Failed to sync to Drive.");
        console.error(e);
    } finally {
        setIsSyncing(false);
    }
  }, [addLog]);

  return {
    googleDriveConnected,
    handleSyncToDrive,
  };
};
