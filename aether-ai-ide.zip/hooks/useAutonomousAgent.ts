
import { useState, useCallback, useEffect, useRef } from 'react';
import { FileNode, AgentAction, ChatSession, ChatMessage, TerminalLog, ExecutionStep } from '../types';
import { chatWithAIStream, MODELS } from '../services/geminiService';
import { connectivityService } from '../services/connectivityService';
import { addCustomModel } from '../services/aiService';
import { embeddingService } from '../services/embeddingService';
import { runGameEngineOrchestrator } from '../services/gameEngineAI';
import { versionControlService } from '../services/versionControlService';
import { generateSmartChatIdentity, formatSmartTitleFromPrompt, extractAppNameFromFiles } from '../services/chatIdentityService';
import { socketService } from '../services/socketService';
import { generateId } from '../utils/id';
import { classifyIntentAndDivision } from '../components/AI/AIAssistant/orchestratorClassifier';

interface UseAIAssistantProps {
  files: FileNode[];
  activeSession: ChatSession | null;
  onUpdateSession: (session: ChatSession) => void;
  onAgentAction: (actions: AgentAction[]) => Promise<void>;
  onToolCall?: (name: string, args: any) => void;
  addLog: (type: any, msg: string) => void;
  terminalLogs: TerminalLog[];
}

export const useAutonomousAgent = ({ files, activeSession, onUpdateSession, onAgentAction, onToolCall, addLog, terminalLogs }: UseAIAssistantProps) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const activeSessionRef = useRef(activeSession);
  activeSessionRef.current = activeSession;
  const filesRef = useRef(files);
  filesRef.current = files;

  // Session Reload / Refresh Recovery Hook: check for active server tasks
  useEffect(() => {
    if (!activeSession?.id) return;
    const sessionId = activeSession.id;

    // Check if there is an ongoing or newly completed server task for this session
    fetch(`/api/ai/active-task-for-session/${sessionId}`)
      .then(res => res.json())
      .then(async (data) => {
        if (data.active && data.task) {
          const task = data.task;
          if (task.status === 'completed' && task.result && !task.acknowledged) {
            // Task finished while user was away / reloading: apply actions
            addLog('system', `🔄 Recovered completed AI generation task from server.`);
            const finalResponse = task.result;
            const actions: AgentAction[] = (finalResponse.files || []).map((f: any) => ({
              action: f.operation,
              path: f.path,
              content: f.code
            }));
            if (actions.length > 0) {
              await onAgentAction(actions);
            }
            fetch(`/api/ai/acknowledge-task/${task.taskId}`, { method: 'POST' }).catch(() => {});
          }
        }
      })
      .catch(() => {});
  }, [activeSession?.id]);

  const sendMessage = useCallback(async (
    text: string, 
    attachments: { mimeType: string, data: string }[] = [], 
    modelId: string = MODELS.GEMINI_FLASH, 
    isCompactMode?: boolean,
    sessionOverride?: ChatSession,
    activeAgentIds?: string[]
  ) => {
    const currentSession = sessionOverride || activeSession;
    if (isProcessing || !currentSession) return;
    setIsProcessing(true);

    // Add user message immediately
    const userMsg: ChatMessage = { 
      id: generateId('u'), 
      role: 'user', 
      text: text, 
      timestamp: Date.now(),
      attachments: attachments.map((a, i) => ({
          type: a.mimeType.startsWith('image/') ? 'image' : 'file',
          url: a.mimeType.startsWith('image/') ? `data:${a.mimeType};base64,${a.data}` : '', 
          name: `Attachment ${i + 1}` 
      }))
    };
    
    // AI-driven Smart Chat Identity (Name and Description)
    const isFirstUserMessage = currentSession.messages.filter(m => m.role === 'user').length === 0;
    const isGenericTitle = !currentSession.title || currentSession.title === "New Node" || currentSession.title === "Untitled App" || !currentSession.aiGeneratedIdentity;
    
    const appNameFromFiles = extractAppNameFromFiles(filesRef.current);
    let initialSessionTitle = appNameFromFiles || currentSession.title;
    if (isFirstUserMessage || isGenericTitle) {
      initialSessionTitle = appNameFromFiles || formatSmartTitleFromPrompt(text);
    }
    let initialSessionDesc = currentSession.description;
    let initialSessionTags = currentSession.tags;

    const updatedSessionWithUser: ChatSession = { 
      ...currentSession, 
      title: initialSessionTitle,
      description: initialSessionDesc,
      tags: initialSessionTags,
      messages: [...currentSession.messages, userMsg],
      lastUpdated: Date.now()
    };
    onUpdateSession(updatedSessionWithUser);

    // Kick off asynchronous AI-based chat identity generation for smart contextual naming
    if (isFirstUserMessage || isGenericTitle) {
      generateSmartChatIdentity(text, filesRef.current).then((identity) => {
        const latest = activeSessionRef.current;
        const targetSession = (latest && latest.id === currentSession.id) ? latest : currentSession;
        const currentAppName = extractAppNameFromFiles(filesRef.current);
        onUpdateSession({
          ...targetSession,
          title: currentAppName || identity.title,
          description: identity.description,
          tags: identity.tags,
          aiGeneratedIdentity: true,
          lastUpdated: Date.now()
        });
      }).catch(console.warn);
    }

    // Create a placeholder bot message for streaming
    const botMsgId = generateId('b');
    const initialBotMsg: ChatMessage = {
        id: botMsgId,
        role: 'model',
        text: '...',
        timestamp: Date.now()
    };

    const sessionWithPlaceholder = {
        ...updatedSessionWithUser,
        messages: [...updatedSessionWithUser.messages, initialBotMsg]
    };
    onUpdateSession(sessionWithPlaceholder);

    // Resolve specialized orchestrator sub-agents dynamically if not passed directly
    const resolvedAgentIds = (activeAgentIds && activeAgentIds.length > 0)
      ? activeAgentIds
      : classifyIntentAndDivision(text, "", text, filesRef.current, 'AUTO', []).spawnedAgents;

    try {
        let finalResponse: any;
        let semanticContext = "";
        try {
            const matches = await embeddingService.semanticSearch(text, 3);
            if (matches && matches.length > 0) {
                semanticContext = "\n\n[COGNITIVE LAYER CONTEXT RETRIEVED]:\n" + 
                    matches.map(m => `### File: ${m.filePath}\n\`\`\`\n${m.text}\n\`\`\``).join("\n\n");
            }
        } catch (semanticErr) {
            console.warn("Could not retrieve semantic context:", semanticErr);
        }

        const messagesToPass = updatedSessionWithUser.messages.filter(m => !m.isExcluded);

        let lastFlushTime = 0;
        let pendingFrameId: number | null = null;
        let latestBuffer: {
            thoughts: string;
            message: string;
            steps?: { step: string; status: string }[];
            codeFragment?: string;
            metrics?: any;
        } = {
            thoughts: "",
            message: "",
            steps: undefined,
            codeFragment: undefined,
            metrics: undefined
        };

        const flushStreamUpdate = () => {
            lastFlushTime = performance.now();
            onUpdateSession({
                ...updatedSessionWithUser,
                messages: [
                    ...updatedSessionWithUser.messages,
                    { 
                        ...initialBotMsg, 
                        text: latestBuffer.message, 
                        thoughts: latestBuffer.thoughts, 
                        reasoningSteps: latestBuffer.steps, 
                        currentCodeFragment: latestBuffer.codeFragment,
                        streamMetrics: latestBuffer.metrics
                    }
                ]
            });

            if (activeSession?.id && latestBuffer.message) {
                socketService.emit('ai-status-update', { 
                    sessionId: activeSession.id, 
                    status: latestBuffer.message, 
                    steps: latestBuffer.steps 
                });
            }
        };

        finalResponse = await chatWithAIStream(
            text + semanticContext, 
            filesRef.current, 
            messagesToPass, 
            terminalLogs,
            (thoughts, message, steps, codeFragment, metrics) => {
                latestBuffer = { thoughts, message, steps, codeFragment, metrics };
                const now = performance.now();
                
                // Adaptive throttle: update immediately on start or at smooth ~24ms display rate
                if (now - lastFlushTime >= 24) {
                    if (pendingFrameId) {
                        cancelAnimationFrame(pendingFrameId);
                        pendingFrameId = null;
                    }
                    flushStreamUpdate();
                } else if (!pendingFrameId) {
                    pendingFrameId = requestAnimationFrame(() => {
                        pendingFrameId = null;
                        flushStreamUpdate();
                    });
                }
            },
            attachments, 
            modelId,
            undefined, // onRawChunk
            isCompactMode,
            resolvedAgentIds
        );

        if (pendingFrameId) {
            cancelAnimationFrame(pendingFrameId);
            pendingFrameId = null;
        }
        flushStreamUpdate();

        // Convert file operations to AgentActions
        const actions: AgentAction[] = (finalResponse.files || []).map((f: any) => ({
            action: f.operation,
            path: f.path,
            content: f.code
        }));

        if (finalResponse.commands) {
            finalResponse.commands.forEach((cmd: string) => actions.push({ action: 'terminal_command', command: cmd }));
        }

        let commitHash: string | undefined;
        let commitSnapshot: FileNode[] | undefined;

        if (actions.length > 0) {
            await onAgentAction(actions);

            // AUTO-COMMIT: Git version control based on time, date, prompt and AI author
            try {
              const commit = await versionControlService.createCommit({
                prompt: text,
                files: filesRef.current,
                author: 'ai',
                sessionId: currentSession.id
              });
              commitHash = commit.hash;
              commitSnapshot = commit.filesSnapshot;
              addLog('system', `🌿 Git snapshot [${commit.shortHash}] committed for AI response: "${text.slice(0, 45)}..."`);
            } catch (gitErr) {
              console.warn('Git auto-commit notice:', gitErr);
            }
        }

        // Register custom models created dynamically by the general chat AI
        if (finalResponse.customModels && finalResponse.customModels.length > 0) {
            finalResponse.customModels.forEach((model: any) => {
                addCustomModel({
                    id: model.id,
                    name: model.name,
                    description: model.description,
                    systemInstruction: model.systemInstruction,
                    temperature: model.temperature ?? 1.0
                });
                addLog('system', `Registered custom AI model/persona: ${model.name}`);
            });
        }

        // Final Bot Message update for standard / auto run
        const finalExecutionSteps: ExecutionStep[] = actions.map((a, i) => ({
             id: `step-${Date.now()}-${i}`,
             label: a.action === 'terminal_command' ? `Ran command: ${a.command}` : `${a.action === 'create' ? 'Created' : a.action === 'update' ? 'Updated' : 'Deleted'} file ${a.path}`,
             status: 'success',
             timestamp: Date.now()
        }));

        const finalBotMsg: ChatMessage = {
            id: botMsgId,
            role: 'model',
            text: finalResponse.message,
            thoughts: finalResponse.thoughts,
            executionSteps: finalExecutionSteps.length > 0 ? finalExecutionSteps : undefined,
            timestamp: Date.now(),
            groundingLinks: finalResponse.groundingLinks,
            commitHash,
            commitSnapshot,
            modelId: modelId || 'gemini-2.5-flash'
        };

        const latestAppName = extractAppNameFromFiles(filesRef.current);
        onUpdateSession({
            ...updatedSessionWithUser,
            title: latestAppName || updatedSessionWithUser.title,
            messages: [...updatedSessionWithUser.messages, finalBotMsg],
            lastUpdated: Date.now()
        });

    } catch (error) {
        addLog('error', 'AI Processing Failed');
        const errorMsg: ChatMessage = {
            id: generateId('err'),
            role: 'model',
            text: "I couldn't process that request. Connection interrupted.",
            timestamp: Date.now()
        };
        onUpdateSession({ ...updatedSessionWithUser, messages: [...updatedSessionWithUser.messages, errorMsg] });
    } finally {
        setIsProcessing(false);
    }
  }, [activeSession, files, isProcessing, onUpdateSession, onAgentAction, addLog, terminalLogs]);

  const stopProcessing = useCallback(() => {
    setIsProcessing(false);
    addLog('warning', 'Agent execution forcefully interrupted.');
  }, [addLog]);

  return { isProcessing, sendMessage, stopProcessing };
};
