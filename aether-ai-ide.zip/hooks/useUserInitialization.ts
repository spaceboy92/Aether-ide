import { useEffect, useRef } from "react";
import { UserProfile, TerminalLog } from "../types";

export const useUserInitialization = (
  user: UserProfile | null,
  updateUser: (user: UserProfile) => void,
  completeLogin: (user: UserProfile) => void,
  addLog: (type: TerminalLog["type"], message: string, source?: string) => void,
  setPerfMode: (mode: "high" | "low") => void
) => {
  const initializedUserIdRef = useRef<string | null>(null);

  useEffect(() => {
    if (!user || initializedUserIdRef.current === user.id) {
      return;
    }

    let updatedUser = { ...user };
    let needsUpdate = false;

    if (user.coins === undefined) {
      updatedUser.coins = 1000;
      updatedUser.items = user.items || [];
      needsUpdate = true;
    }

    if (!user.aiSettings) {
      updatedUser.aiSettings = {
        defaultModel: 'gemini-3.1-pro-preview',
        reasoningLevel: 'deep'
      };
      needsUpdate = true;
    } else if (user.aiSettings.reasoningLevel === undefined || user.aiSettings.defaultModel === 'gemini-3.7-flash') {
      updatedUser.aiSettings = {
        ...user.aiSettings,
        defaultModel: user.aiSettings.defaultModel === 'gemini-3.7-flash' ? 'gemini-3.1-pro-preview' : user.aiSettings.defaultModel,
        reasoningLevel: user.aiSettings.reasoningLevel || 'deep'
      };
      needsUpdate = true;
    }

    if (user.tvMode === undefined) {
      const ua = navigator.userAgent.toLowerCase();
      const isTV = /smart-tv|smarttv|googletv|appletv|hbbtv|pov_tv|netcast.tv|webos|tizen|viera|bravia|philips-tv|sharp-tv|sony-tv|hisense-tv|toshiba-tv|roku|firetv|fire-tv|chromecast/.test(ua);
      const isLargeScreen = window.innerWidth >= 1920 && window.innerHeight >= 1080;

      if (isTV || isLargeScreen) {
        updatedUser.tvMode = true;
        needsUpdate = true;
        addLog("system", "TV_HARDWARE_DETECTED: Optimizing interface for large display.");
      }
    }

    if (user.performanceMode === undefined) {
      const cores = navigator.hardwareConcurrency || 4;
      const memory = (navigator as any).deviceMemory || 4;
      const isOldOS = /android [4-8]|iphone os ([7-9]|10|11)|ipad; cpu os ([7-9]|10|11)/i.test(navigator.userAgent);
      const isMobile = window.innerWidth < 768;

      if (cores <= 4 || memory <= 2 || isOldOS || isMobile) {
        setPerfMode("low");
        updatedUser.performanceMode = "low";
        needsUpdate = true;
        addLog("system", "LOW_END_HARDWARE_DETECTED: Engaging Maximum Performance Mode.");
      } else {
        updatedUser.performanceMode = "high";
        needsUpdate = true;
      }
    } else {
      setPerfMode(user.performanceMode);
    }

    initializedUserIdRef.current = user.id;

    if (needsUpdate) {
      updateUser(updatedUser);
      completeLogin(updatedUser);
    }
  }, [user?.id]);
};
