import { useState, useEffect, useCallback } from 'react';
import { UserProfile } from '../types';
import { generateId } from '../utils/id';
import { useFirebase } from '../components/Auth/FirebaseProvider';
import { auth } from '../services/firebase';

const safeStorage = {
  getItem: (key: string): string | null => {
    try {
      return localStorage.getItem(key);
    } catch (e) {
      console.warn(`[safeStorage] Failed to read ${key}:`, e);
      return null;
    }
  },
  setItem: (key: string, value: string): void => {
    try {
      localStorage.setItem(key, value);
    } catch (e) {
      console.warn(`[safeStorage] Failed to write ${key}:`, e);
    }
  },
  removeItem: (key: string): void => {
    try {
      localStorage.removeItem(key);
    } catch (e) {
      console.warn(`[safeStorage] Failed to remove ${key}:`, e);
    }
  },
  clear: (): void => {
    try {
      localStorage.clear();
    } catch (e) {
      console.warn('[safeStorage] Failed to clear storage:', e);
    }
  }
};

export const useAuth = () => {
  const { profile: firebaseProfile, loading: firebaseLoading, signIn, logout: firebaseLogout } = useFirebase();
  
  // Synchronously initialize user from local storage to guarantee 0ms instant boot
  const [user, setUser] = useState<UserProfile | null>(() => {
    if (safeStorage.getItem("aether_logged_out") === "true") {
      return null;
    }
    const storedUser = safeStorage.getItem("aether_user_profile");
    if (storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser) as UserProfile;
        if (parsedUser && parsedUser.id) return parsedUser;
      } catch (e) {
        // Fallthrough to guest creation
      }
    }
    // Default guest profile so app never hangs
    const guestUser: UserProfile = {
      id: `guest_${generateId()}`,
      name: 'Explorer',
      email: '',
      photoURL: `https://ui-avatars.com/api/?name=Explorer&background=2a2f3a&color=00d4ff`,
      isGuest: true,
      syncEnabled: false,
      coins: 1000,
      items: [],
    };
    safeStorage.setItem("aether_user_profile", JSON.stringify(guestUser));
    return guestUser;
  });

  // Fast loading state that never blocks rendering
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // If Firebase Auth provides a profile, sync it
    if (firebaseProfile) {
      setUser(firebaseProfile);
      safeStorage.setItem("aether_user_profile", JSON.stringify(firebaseProfile));
      safeStorage.removeItem("aether_logged_out");
    }
  }, [firebaseProfile]);

  // Safety fallback to guarantee loading is never stuck true
  useEffect(() => {
    if (loading) {
      const timer = setTimeout(() => setLoading(false), 200);
      return () => clearTimeout(timer);
    }
  }, [loading]);

  const login = async (): Promise<void> => {
    await signIn();
  };

  const completeLogin = useCallback(async (profile: UserProfile) => {
    safeStorage.removeItem("aether_logged_out");
    safeStorage.setItem("aether_user_profile", JSON.stringify(profile));
    setUser(profile);
  }, []);

  const loginGuest = async (force = false, email?: string) => {
    if (!force && safeStorage.getItem("aether_logged_out") === "true") {
        setLoading(false);
        return;
    }
    setLoading(true);
    
    safeStorage.removeItem("aether_logged_out");
    const safeEmail = email || '';
    const guestId = safeEmail ? `user_${btoa(safeEmail).substring(0, 12)}` : `guest_${generateId()}`;
    const guestUser: UserProfile = {
      id: guestId,
      name: safeEmail ? safeEmail.split('@')[0] : 'Guest Explorer',
      email: safeEmail,
      photoURL: `https://ui-avatars.com/api/?name=${safeEmail || 'Guest'}&background=2a2f3a&color=00d4ff`,
      isGuest: !safeEmail,
      syncEnabled: false,
      coins: 1000,
      items: [],
    };
    
    safeStorage.setItem("aether_user_profile", JSON.stringify(guestUser));
    setUser(guestUser);
    setLoading(false);
  };

  const logout = async () => {
    try {
      safeStorage.setItem("aether_logged_out", "true");
      safeStorage.removeItem("aether_user_profile");
      await firebaseLogout();
      setUser(null);
      setTimeout(() => {
        window.location.href = '/?loggedOut=true';
      }, 100);
    } catch (error) {
      console.error("Logout failed", error);
    }
  };

  const nuclearReset = async () => {
    try {
      setLoading(true);
      await firebaseLogout();
      safeStorage.clear();
      sessionStorage.clear();
      setUser(null);
      window.location.href = '/?reset=true';
    } catch (error) {
      console.error("Nuclear reset failed", error);
      window.location.reload();
    }
  };

  return { 
    user, 
    loading, 
    login, 
    completeLogin, 
    loginGuest, 
    logout, 
    nuclearReset,
    updateUser: useCallback(async (u: UserProfile) => { 
      setUser(u); 
      safeStorage.setItem("aether_user_profile", JSON.stringify(u)); 
      
      if (auth.currentUser) {
        const { doc, setDoc } = await import('firebase/firestore');
        const { db } = await import('../services/firebase');
        
        // Use JSON.parse(JSON.stringify(...)) to strip out undefined values
        const sanitizedUser = JSON.parse(JSON.stringify(u, (k, v) => v === undefined ? null : v));
        
        await setDoc(doc(db, 'users', auth.currentUser.uid), {
          ...sanitizedUser,
          updatedAt: Date.now()
        }, { merge: true });
      }
    }, []) 
  };
};
