import { useState, useEffect, useCallback, useRef } from "react";
import { ChatSession, UserProfile, TerminalLog, FileNode } from "../types";
import { storageService } from "../services/storageService";
import { connectivityService } from "../services/connectivityService";
import { getRemoteSessions, saveFullSession } from "../services/fileService";
import { generateId } from "../utils/id";
import { auth } from "../services/firebase";

const safeStorage = {
  getItem: (key: string): string | null => {
    try {
      return localStorage.getItem(key);
    } catch (e) {
      return null;
    }
  },
  setItem: (key: string, value: string): void => {
    try {
      localStorage.setItem(key, value);
    } catch (e) {}
  },
  removeItem: (key: string): void => {
    try {
      localStorage.removeItem(key);
    } catch (e) {}
  }
};

export const useAppSessions = (
  user: UserProfile | null, 
  googleDriveConnected: boolean,
  addLog: (type: TerminalLog["type"], message: string, source?: string) => void
) => {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(() => {
    try {
      if (typeof window !== "undefined") {
        const url = new URL(window.location.href);
        const sessionParam = url.searchParams.get("session");
        if (sessionParam) {
          return sessionParam;
        }
      }
    } catch (e) {}
    safeStorage.removeItem('aether_active_session_id');
    return null;
  });

  useEffect(() => {
    if (activeSessionId) {
      const url = new URL(window.location.href);
      if (url.searchParams.get("session") !== activeSessionId) {
        url.searchParams.set("session", activeSessionId);
        window.history.replaceState({}, '', url.toString());
      }
    } else {
      safeStorage.removeItem('aether_active_session_id');
      try {
        const url = new URL(window.location.href);
        if (url.searchParams.has("session")) {
          url.searchParams.delete("session");
          window.history.replaceState({}, '', url.toString());
        }
      } catch (e) {}
    }
  }, [activeSessionId]);

  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const autoSave = useCallback(
    async (
      sessionId: string,
      currentFiles: FileNode[],
      currentSessions: ChatSession[],
    ) => {
      if (!user) return;

      // Update localStorage immediately for instant local persistence
      try {
        localStorage.setItem(
          `aether_sessions_${user.id}`,
          JSON.stringify(currentSessions),
        );
      } catch (e) {
        // ignore
      }

      // Debounce expensive remote/database writes to prevent streaming overload
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current);
      }

      saveTimeoutRef.current = setTimeout(async () => {
        try {
          const session = currentSessions.find((s) => s.id === sessionId);
          if (session) {
            if (connectivityService.getStatus() === "online") {
              try {
                await saveFullSession(currentSessions, currentFiles);
              } catch (e) {
                console.warn("Remote save failed, falling back to local only", e);
              }
            }

            const sessionData = {
              ...session,
              ownerId: user.id,
              lastUpdated: Date.now(),
            };

            await storageService.saveSession({
              id: session.id,
              title: session.title,
              messages: session.messages,
              updatedAt: session.lastUpdated || Date.now(),
            });

            if (auth.currentUser) {
              try {
                const { firestoreService } = await import("../services/firestoreService");
                await firestoreService.saveChatSession(session);
              } catch (err) {
                console.error("Firestore sync fail in autoSave:", err);
              }
            }
            
            if (googleDriveConnected) {
              const token = safeStorage.getItem("google_drive_access_token");
              if (token) {
                  const { saveSessionToDrive } = await import("../services/googleDriveService");
                  saveSessionToDrive({ access_token: token }, sessionData).catch(console.error);
              }
            }
          }
        } catch (error) {
          console.error("Local sync loop failure", error);
        }
      }, 1500); // 1.5-second debounce is ideal for stream pacing
    },
    [user, googleDriveConnected],
  );

  useEffect(() => {
    if (!user) return;

    const loadSessions = async () => {
      // 0. Fetch shared session from Firestore if accessed via shared link
      try {
        if (typeof window !== "undefined") {
          const urlParams = new URLSearchParams(window.location.search);
          const urlSessionId = urlParams.get("session");
          if (urlSessionId) {
            const { firestoreService } = await import("../services/firestoreService");
            const singleSession = await firestoreService.getSingleChatSession(urlSessionId);
            if (singleSession) {
              await storageService.saveSession({
                id: singleSession.id,
                title: singleSession.title,
                messages: singleSession.messages || [],
                updatedAt: singleSession.lastUpdated || Date.now(),
              });
              // Fetch and cache files associated with this shared session
              const cloudFiles = await firestoreService.getFiles(urlSessionId);
              if (cloudFiles && cloudFiles.length > 0) {
                await storageService.saveFiles(urlSessionId, cloudFiles);
                const { opfsService } = await import("../services/opfsService");
                await opfsService.saveToOPFSCache(urlSessionId, cloudFiles).catch(() => {});
              }
            }
          }
        }
      } catch (err) {
        console.error("Failed to pre-fetch shared session on load:", err);
      }

      // 1. Fetch from Firestore if authenticated to sync first
      if (auth.currentUser) {
        try {
          const { firestoreService } = await import("../services/firestoreService");
          const cloudSessions = await firestoreService.getChatSessions();
          if (cloudSessions && cloudSessions.length > 0) {
            for (const cs of cloudSessions) {
              await storageService.saveSession({
                id: cs.id,
                title: cs.title,
                messages: cs.messages || [],
                updatedAt: cs.lastUpdated || Date.now(),
              });
            }
          }
        } catch (e) {
          console.error("Failed to fetch sessions from Firestore on initialization:", e);
        }
      }

      const localSessions = await storageService.getAllSessions();
      if (localSessions.length > 0) {
        const mapped = localSessions.map((ls) => ({
          id: ls.id,
          title: ls.title,
          messages: ls.messages,
          lastUpdated: ls.updatedAt,
        }));
        setSessions(mapped);

        if (connectivityService.getStatus() === "online") {
          getRemoteSessions().then((remote) => {
            if (remote.length > 0) {
              setSessions((prev) => {
                const sessionMap = new Map<string, ChatSession>();
                prev.forEach(s => sessionMap.set(s.id, s));
                remote.forEach(r => {
                  const existing = sessionMap.get(r.id);
                  if (!existing || (r.lastUpdated || 0) > (existing.lastUpdated || 0)) {
                    sessionMap.set(r.id, r);
                  }
                });
                return Array.from(sessionMap.values()).sort(
                  (a, b) => (b.lastUpdated || 0) - (a.lastUpdated || 0),
                );
              });
            }
          });
        }
        return;
      }

      const remoteSessions = await getRemoteSessions();
      if (remoteSessions.length > 0) {
        setSessions(
          remoteSessions.sort(
            (a, b) => (b.lastUpdated || 0) - (a.lastUpdated || 0),
          ),
        );
        remoteSessions.forEach((s) =>
          storageService.saveSession({
            id: s.id,
            title: s.title,
            messages: s.messages,
            updatedAt: s.lastUpdated || Date.now(),
          }),
        );
        return;
      }

      const stored = safeStorage.getItem(`aether_sessions_${user.id}`);
      if (stored) {
        try {
          const parsed = JSON.parse(stored) as ChatSession[];
          setSessions(parsed.sort((a, b) => b.lastUpdated - a.lastUpdated));
          parsed.forEach((s) =>
            storageService.saveSession({
              id: s.id,
              title: s.title,
              messages: s.messages,
              updatedAt: s.lastUpdated || Date.now(),
            }),
          );
        } catch (err) {
          console.error("Failed to load local sessions", err);
        }
      }
    };

    loadSessions();
  }, [user]);

  return {
    sessions,
    setSessions,
    activeSessionId,
    setActiveSessionId,
    autoSave
  };
};
