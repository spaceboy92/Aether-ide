import { useState, useEffect, useCallback } from "react";
import { FileNode } from "../types";
import { getFiles } from "../services/fileService";

export const useAppFileSystem = (activeSessionId: string | null) => {
  const [files, setFiles] = useState<FileNode[]>([]);
  const [activeFileId, setActiveFileId] = useState<string | null>(null);
  const [filesLoading, setFilesLoading] = useState(false);

  useEffect(() => {
    if (activeSessionId && activeFileId) {
      localStorage.setItem(`aether_active_file_id_${activeSessionId}`, activeFileId);
    }
  }, [activeFileId, activeSessionId]);

  useEffect(() => {
    if (activeSessionId) {
      setFilesLoading(true);
      
      // Clear current files first to avoid flicker/leakage during transition
      setFiles([]);
      setActiveFileId(null);

      getFiles(activeSessionId).then((f) => {
        setFiles(f || []);
        
        const params = new URLSearchParams(window.location.search);
        const targetFileId = params.get("file");
        const restoredFileId = localStorage.getItem(`aether_active_file_id_${activeSessionId}`);
        const found = f?.find(file => file.id === targetFileId || file.name === targetFileId || file.id === restoredFileId);

        if (found) {
          setActiveFileId(found.id);
        } else if (f && f.length > 0) {
          setActiveFileId(f[0].id);
        } else {
          setActiveFileId(null);
        }
        setFilesLoading(false);
      }).catch(err => {
        console.error("Failed to load files", err);
        setFilesLoading(false);
      });
    } else {
      setFiles([]);
      setActiveFileId(null);
      setFilesLoading(false);
    }
  }, [activeSessionId]);

  const handleRenameFile = useCallback((id: string, newName: string) => {
    setFiles((prev) =>
      prev.map((f) => (f.id === id ? { ...f, name: newName } : f)),
    );
  }, []);

  return {
    files,
    setFiles,
    activeFileId,
    setActiveFileId,
    filesLoading,
    handleRenameFile
  };
};
