import { useState, useEffect } from "react";
import { ViewMode } from "../types";

export const useAppUI = () => {
  const [isPC, setIsPC] = useState(false);
  const [usePCWorkspace, setUsePCWorkspace] = useState(true);
  const [activeTab, setActiveTab] = useState<"dashboard" | "editor" | "preview" | "chat" | "game" | "gallery" | "chats">("dashboard");
  const [sidebarMode, setSidebarMode] = useState<
    | "files" | "settings" | "customizer" | "search" | "health" | "marketplace" | "evolution" | "deployment" | "analytics" | "playstudio" | "history" | "terminal" | "extensions" | "linux" | "blackhole" | "api_playground" | "security" | "database" | "datatransformer" | "profiler" | string | null
  >(null);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showInfoModal, setShowInfoModal] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);
  const [showTerminal, setShowTerminal] = useState(false);
  const [showCommandPalette, setShowCommandPalette] = useState(false);
  const [zenMode, setZenMode] = useState(false);
  const [focusMode, setFocusMode] = useState(false);
  const [showProjectGraph, setShowProjectGraph] = useState(false);
  const [showRadio, setShowRadio] = useState(false);
  const [showJwtDecoder, setShowJwtDecoder] = useState(false);
  const [showEnvManager, setShowEnvManager] = useState(false);

  useEffect(() => {
    const checkIsPC = () => {
      const mobileDevice = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
      const isLargeScreen = window.innerWidth >= 1024;
      setIsPC(!mobileDevice && isLargeScreen);
    };
    checkIsPC();
    window.addEventListener("resize", checkIsPC);
    return () => window.removeEventListener("resize", checkIsPC);
  }, []);

  return {
    isPC,
    setIsPC,
    usePCWorkspace,
    setUsePCWorkspace,
    activeTab,
    setActiveTab,
    sidebarMode,
    setSidebarMode,
    showMobileMenu,
    setShowMobileMenu,
    showInfoModal,
    setShowInfoModal,
    showShareModal,
    setShowShareModal,
    showTerminal,
    setShowTerminal,
    showCommandPalette,
    setShowCommandPalette,
    zenMode,
    setZenMode,
    focusMode,
    setFocusMode,
    showProjectGraph,
    setShowProjectGraph,
    showRadio,
    setShowRadio,
    showJwtDecoder,
    setShowJwtDecoder,
    showEnvManager,
    setShowEnvManager
  };
};
