import { useState, useEffect, useRef } from "react";

export const useAIAudio = (isProcessing: boolean, lastBotMessageId: string | undefined, onSpeakFinished?: () => void) => {
  const [aetherAudioMode, setAetherAudioMode] = useState<"muted" | "browser" | "premium">(() => {
    return (localStorage.getItem("aether_audio_mode") as any) || "muted";
  });
  const [aetherVoice, setAetherVoice] = useState<"Kore" | "Puck" | "Fenrir" | "Zephyr" | "Charon">(() => {
    return (localStorage.getItem("aether_voice") as any) || "Kore";
  });
  const [isSpeaking, setIsSpeaking] = useState<string | null>(null);
  const activeAudioRef = useRef<{ source: AudioBufferSourceNode; ctx: AudioContext } | null>(null);
  const prevIsProcessing = useRef(isProcessing);

  useEffect(() => {
    localStorage.setItem("aether_audio_mode", aetherAudioMode);
  }, [aetherAudioMode]);

  useEffect(() => {
    localStorage.setItem("aether_voice", aetherVoice);
  }, [aetherVoice]);

  const stopAllSpeech = () => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    if (activeAudioRef.current) {
      try {
        activeAudioRef.current.source.stop();
        activeAudioRef.current.ctx.close();
      } catch (e) {}
      activeAudioRef.current = null;
    }
    setIsSpeaking(null);
  };

  useEffect(() => {
    return () => stopAllSpeech();
  }, []);

  const handleSpeak = async (text: string, msgId: string, forceMode?: "browser" | "premium") => {
    if (isSpeaking === msgId) {
      stopAllSpeech();
      return;
    }

    stopAllSpeech();
    setIsSpeaking(msgId);

    const mode = forceMode || (aetherAudioMode === "muted" ? "premium" : aetherAudioMode);

    if (mode === "premium") {
      try {
        const cleanText = text
          .replace(/[#*`_~]/g, "")
          .replace(/\[.*?\]\(.*?\)/g, "")
          .replace(/```[\s\S]*?```/g, "[Generated code omitted from voice]")
          .trim();

        const response = await fetch("/api/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: cleanText, voice: aetherVoice }),
        });

        if (!response.ok) throw new Error("TTS endpoint failed");

        const data = await response.json();
        if (data.success && data.audio) {
          const binaryString = atob(data.audio);
          const len = binaryString.length;
          const bytes = new Uint8Array(len);
          const view = new DataView(bytes.buffer);
          for (let i = 0; i < len; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }

          const numSamples = len / 2;
          const float32Data = new Float32Array(numSamples);
          for (let i = 0; i < numSamples; i++) {
            const sample = view.getInt16(i * 2, true);
            float32Data[i] = sample / 32768.0;
          }

          const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
          if (!AudioContextClass) throw new Error("AudioContext unsupported");

          const audioCtx = new AudioContextClass();
          const audioBuffer = audioCtx.createBuffer(1, numSamples, 24000);
          audioBuffer.getChannelData(0).set(float32Data);

          const source = audioCtx.createBufferSource();
          source.buffer = audioBuffer;
          source.connect(audioCtx.destination);

          source.onended = () => {
            if (activeAudioRef.current?.source === source) {
              setIsSpeaking(null);
            }
          };

          source.start(0);
          activeAudioRef.current = { source, ctx: audioCtx };
        } else {
          throw new Error("Invalid speech payload");
        }
      } catch (err) {
        console.warn("Application premium transcription failed, falling back to browser speak...", err);
        const utterance = new SpeechSynthesisUtterance(text.replace(/[#*`_~]/g, ""));
        utterance.onend = () => setIsSpeaking(null);
        window.speechSynthesis.speak(utterance);
      }
    } else if (mode === "browser") {
      const utterance = new SpeechSynthesisUtterance(text.replace(/[#*`_~]/g, ""));
      utterance.onend = () => setIsSpeaking(null);
      window.speechSynthesis.speak(utterance);
    }
  };

  return {
    aetherAudioMode,
    setAetherAudioMode,
    aetherVoice,
    setAetherVoice,
    isSpeaking,
    handleSpeak,
    stopAllSpeech
  };
};
