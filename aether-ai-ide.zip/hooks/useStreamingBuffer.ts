import { useRef, useCallback, useEffect } from "react";

export interface StreamBufferOptions {
  flushIntervalMs?: number; // default ~24ms (matches high refresh rate displays)
  onFlush: (bufferedData: {
    thoughts: string;
    message: string;
    steps?: { step: string; status: string }[];
    codeFragment?: string;
    metrics?: any;
  }) => void;
}

/**
 * High-performance animation frame buffer to prevent React DOM chokes
 * during high-speed AI streaming (100+ tokens/sec).
 */
export function useStreamingBuffer({ flushIntervalMs = 24, onFlush }: StreamBufferOptions) {
  const latestDataRef = useRef<{
    thoughts: string;
    message: string;
    steps?: { step: string; status: string }[];
    codeFragment?: string;
    metrics?: any;
    hasUpdate: boolean;
  }>({
    thoughts: "",
    message: "",
    hasUpdate: false
  });

  const animFrameIdRef = useRef<number | null>(null);
  const lastFlushTimeRef = useRef<number>(0);
  const onFlushRef = useRef(onFlush);
  onFlushRef.current = onFlush;

  const flush = useCallback(() => {
    if (latestDataRef.current.hasUpdate) {
      latestDataRef.current.hasUpdate = false;
      lastFlushTimeRef.current = performance.now();
      onFlushRef.current({
        thoughts: latestDataRef.current.thoughts,
        message: latestDataRef.current.message,
        steps: latestDataRef.current.steps,
        codeFragment: latestDataRef.current.codeFragment,
        metrics: latestDataRef.current.metrics
      });
    }
  }, []);

  const pushChunk = useCallback((
    thoughts: string,
    message: string,
    steps?: { step: string; status: string }[],
    codeFragment?: string,
    metrics?: any
  ) => {
    latestDataRef.current = {
      thoughts,
      message,
      steps,
      codeFragment,
      metrics,
      hasUpdate: true
    };

    const now = performance.now();
    if (now - lastFlushTimeRef.current >= flushIntervalMs) {
      flush();
    } else if (!animFrameIdRef.current) {
      animFrameIdRef.current = requestAnimationFrame(() => {
        animFrameIdRef.current = null;
        flush();
      });
    }
  }, [flush, flushIntervalMs]);

  const forceFlush = useCallback(() => {
    if (animFrameIdRef.current) {
      cancelAnimationFrame(animFrameIdRef.current);
      animFrameIdRef.current = null;
    }
    flush();
  }, [flush]);

  useEffect(() => {
    return () => {
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
    };
  }, []);

  return {
    pushChunk,
    forceFlush
  };
}
