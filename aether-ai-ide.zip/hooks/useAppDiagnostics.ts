import { useState, useEffect, useCallback } from "react";
import { TerminalLog } from "../types";
import { generateId } from "../utils/id";
import { terminalService } from "../services/terminalService";

export const useAppDiagnostics = () => {
  const [terminalLogs, setTerminalLogs] = useState<TerminalLog[]>([]);
  const [systemStats, setSystemStats] = useState({
    cpu: "0.0",
    mem: "0%",
    uptime: "0h",
    packetLoss: "0.0%",
  });

  const addLog = useCallback(
    (type: TerminalLog["type"], message: string, source: string = "SYSTEM") => {
      setTerminalLogs((prev) => [
        ...prev,
        { id: generateId("log"), type, message, timestamp: Date.now(), source },
      ]);

      // Forward to global terminal service
      if (type === 'error') {
        terminalService.logError(message, source);
      } else {
        terminalService.logOutput(message, source);
      }
    },
    [],
  );

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await fetch("/api/stats");
        if (res.ok) {
          const data = await res.json();
          setSystemStats({
            ...data,
            packetLoss: (Math.random() * 2).toFixed(1) + "%"
          });
        }
      } catch (e) {}
    };
    fetchStats();
    const interval = setInterval(fetchStats, 10000);
    return () => clearInterval(interval);
  }, []);

  return {
    terminalLogs,
    setTerminalLogs,
    systemStats,
    setSystemStats,
    addLog
  };
};
